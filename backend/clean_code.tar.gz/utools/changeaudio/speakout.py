#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量将讲稿文本转语音，输出到同级目录下的 speech_audio 文件夹。

用法：
    python speakout.py <voice_id> <讲稿文件夹>

行为：
    - 讲稿文件夹内的每个 .txt 会生成同名 .wav 到 <讲稿文件夹>/speech_audio。
    - 使用现有 minimax_env 与 batch_minimax_tts.py。
    - 不做声线克隆，只使用传入的 voice_id。
"""

import argparse
import os
import subprocess
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description="根据指定 voice_id 批量合成讲稿语音")
    parser.add_argument("voice_id", help="已存在的 Minimax 声线 ID")
    parser.add_argument("script_dir", help="讲稿文件夹，内含若干 .txt")
    args = parser.parse_args()

    script_dir = Path(args.script_dir).resolve()
    if not script_dir.is_dir():
        print(f"❌ 讲稿目录不存在: {script_dir}")
        raise SystemExit(1)

    output_dir = script_dir / "speech_audio"
    output_dir.mkdir(parents=True, exist_ok=True)

    # 组装命令，直接使用 voice_id，不克隆
    cmd = [
        "/bin/bash",
        "-c",
        (
            "source /home/EduAgent/miniconda3/etc/profile.d/conda.sh && "
            "conda activate minimax_env && "
            "python /home/TeachMasterAppV2/backend/batch_minimax_tts.py "
            f"--input_dir {script_dir} "
            f"--output_dir {output_dir} "
            f"--voice_id {args.voice_id} "
            "--model speech-02-hd "
            "--use_existing_voice "
        ),
    ]

    print("🔊 开始批量合成语音...")
    result = subprocess.run(cmd, text=True)
    if result.returncode == 0:
        print(f"✅ 完成，输出目录: {output_dir}")
    else:
        print("❌ 语音合成失败")
        raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
