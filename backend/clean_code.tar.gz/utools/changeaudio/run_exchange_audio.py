#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
一键从“已有讲稿+Manim代码”开始，完成：
1) 语音合成（指定 voice_id）
2) 插入断点
3) 根据音频时长生成 wait 语句
4) 替换背景图
5) 渲染无声视频
6) 合并音频
7) 生成中文字幕

用法：
    python run_exchange_audio.py <manim代码目录> <讲稿目录> <背景图路径> <voice_id>

输出目录（相对于讲稿目录的父级）：
    speech_audio/                 合成的 wav
    manim_codes_refined/          断点后的代码
    manim_codes_final/            加 wait 的终版代码（换好背景）
    video_wo_audio/               渲染出的无声视频
    video_w_audio/                合并音频后的视频
    video_w_audio_subtitle/       带中文字幕的视频
"""

import argparse
import subprocess
from pathlib import Path

PY_MINIMAX = "/home/EduAgent/miniconda3/envs/minimax_env/bin/python"
PY_MANIM = "/home/EduAgent/miniconda3/envs/manim_env/bin/python"
PY_AENEAS = "/home/EduAgent/miniconda3/envs/aeneas_env/bin/python"


def run(cmd, cwd=None):
    print("👉", " ".join(map(str, cmd)))
    result = subprocess.run(cmd, cwd=cwd, text=True)
    if result.returncode != 0:
        raise SystemExit(result.returncode)


def main():
    parser = argparse.ArgumentParser(description="从语音生成往后的一键流程")
    parser.add_argument("manim_dir", help="原始 Manim 代码目录（*.py）")
    parser.add_argument("script_dir", help="讲稿目录（*.txt）")
    parser.add_argument("bg_image", help="背景图片路径")
    parser.add_argument("voice_id", help="Minimax 声线 ID")
    parser.add_argument(
        "--with-subtitle",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="是否生成中文字幕（默认生成；用 --no-with-subtitle 关闭）",
    )
    args = parser.parse_args()

    manim_dir = Path(args.manim_dir).resolve()
    script_dir = Path(args.script_dir).resolve()
    bg_image = Path(args.bg_image).resolve()
    voice_id = args.voice_id

    if not manim_dir.is_dir():
        raise SystemExit(f"❌ Manim 目录不存在: {manim_dir}")
    if not script_dir.is_dir():
        raise SystemExit(f"❌ 讲稿目录不存在: {script_dir}")
    if not bg_image.exists():
        raise SystemExit(f"❌ 背景图片不存在: {bg_image}")

    base = script_dir.parent
    speech_audio = base / "speech_audio"
    refined_dir = base / "manim_codes_refined"
    final_dir = base / "manim_codes_final"
    video_wo = base / "video_wo_audio"
    video_w = base / "video_w_audio"
    video_sub = base / "video_w_audio_subtitle"

    # 1) 语音合成
    run([
        PY_MINIMAX,
        "/home/TeachMasterAppV2/backend/batch_minimax_tts.py",
        "--input_dir", str(script_dir),
        "--output_dir", str(speech_audio),
        "--voice_id", voice_id,
        "--model", "speech-02-hd",
        "--use_existing_voice",
    ])

    # 2) 插入断点
    run([
        PY_MANIM,
        "/home/TeachMasterAppV2/backend/manim_breakpoint_inserter.py",
        str(manim_dir),
        str(script_dir),
        str(refined_dir),
    ], cwd="/home/TeachMasterAppV2/backend")

    # 如果生成了 Code/Speech 子目录，则使用它们
    refined_code_dir = refined_dir / "Code" if (refined_dir / "Code").is_dir() else refined_dir
    refined_script_dir = refined_dir / "Speech" if (refined_dir / "Speech").is_dir() else script_dir

    # 3) 生成音频时长文件
    duration_file = speech_audio / "duration.txt"
    with duration_file.open("w") as f:
        import os, json, subprocess as sp
        for wav in speech_audio.glob("*.wav"):
            cmd = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/ffprobe",
                "-v", "error",
                "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1",
                str(wav),
            ]
            out = sp.check_output(cmd, text=True).strip()
            f.write(f"{wav.name} {out}\n")

    # 4) 自动插入 wait
    run([
        PY_MANIM,
        "/home/TeachMasterAppV2/backend/manim_auto_wait_generator.py",
        str(duration_file),
        str(refined_script_dir),
        str(refined_code_dir),
        str(final_dir),
    ], cwd="/home/TeachMasterAppV2/backend")

    # 5) 替换背景
    run([
        PY_MANIM,
        "/home/TeachMasterAppV2/backend/utools/changebackground/exchange_background.py",
        str(bg_image),
        str(final_dir),
    ], cwd="/home/TeachMasterAppV2/backend")

    # 6) 渲染无声视频
    run([
        PY_MANIM,
        "/home/TeachMasterAppV2/backend/batch_render_manim_for_effi_test.py",
        "--input_dir", str(final_dir),
        "--output_dir", str(video_wo),
        "--quality", "h",
    ], cwd="/home/TeachMasterAppV2/backend")

    # 7) 合并音频
    run([
        PY_MANIM,
        "/home/TeachMasterAppV2/backend/video_audio_merge_individual.py",
        str(speech_audio),
        str(video_wo),
        str(video_w),
    ], cwd="/home/TeachMasterAppV2/backend")

    # 8) 生成中文字幕（可选）
    if args.with_subtitle:
        run([
            PY_AENEAS,
            "/home/TeachMaster/ML/subtitle_generator_cn_effi.py",
            str(video_w),
            str(script_dir),
            str(video_sub),
        ], cwd="/home/TeachMasterAppV2/backend")
    else:
        print("💬 跳过字幕生成")

    print("✅ 全流程完成")


if __name__ == "__main__":
    main()
