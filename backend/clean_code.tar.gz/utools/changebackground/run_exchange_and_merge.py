#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
一键执行两步：
1) 调用 exchange_background.py 替换背景图片。
2) 调用 merge_code_audio.py 渲染并合并音频（默认生成中文字幕）。

用法：
  python run_exchange_and_merge.py <图片路径> <manim代码目录> <音频目录> <输出目录> \
      [--no-with-subtitle] [--text-dir <文本目录>] [--workers N]
"""

import argparse
import subprocess
import sys
from pathlib import Path


def run_cmd(cmd, cwd):
    result = subprocess.run(cmd, cwd=cwd, text=True)
    if result.returncode != 0:
        raise SystemExit(result.returncode)


def main():
    parser = argparse.ArgumentParser(
        description="先换背景，再渲染合并音频（可选中文字幕）"
    )
    parser.add_argument("image_path", help="新的背景图片路径")
    parser.add_argument("code_dir", help="Manim 代码目录")
    parser.add_argument("audio_dir", help="音频目录（*.wav）")
    parser.add_argument("out_dir", help="输出视频目录")
    parser.add_argument(
        "--with-subtitle",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="是否生成中文字幕（默认生成；用 --no-with-subtitle 关闭）",
    )
    parser.add_argument(
        "--text-dir",
        dest="text_dir",
        help="字幕文本目录，默认优先 <audio_dir>/../speech，其次 audio_dir",
    )
    parser.add_argument(
        "--workers", type=int, default=3, help="并发渲染/合并任务数，默认 3"
    )
    args = parser.parse_args()

    this_dir = Path(__file__).resolve().parent
    backend_dir = this_dir.parent.parent  # /backend

    exchange_script = this_dir / "exchange_background.py"
    merge_script = this_dir / "merge_code_audio.py"

    # 1) 换背景
    print("🖼️ 先替换背景图片...")
    cmd1 = [
        sys.executable,
        str(exchange_script),
        args.image_path,
        args.code_dir,
    ]
    run_cmd(cmd1, cwd=backend_dir)

    # 2) 渲染 + 合并 + 可选字幕
    print("🎬 渲染并合并音频...")
    cmd2 = [
        sys.executable,
        str(merge_script),
        args.code_dir,
        args.audio_dir,
        args.out_dir,
        f"--workers={args.workers}",
    ]
    if args.with_subtitle:
        cmd2.append("--with-subtitle")
    else:
        cmd2.append("--no-with-subtitle")
    if args.text_dir:
        cmd2.extend(["--text-dir", args.text_dir])

    run_cmd(cmd2, cwd=backend_dir)
    print("✅ 全部完成")


if __name__ == "__main__":
    main()
