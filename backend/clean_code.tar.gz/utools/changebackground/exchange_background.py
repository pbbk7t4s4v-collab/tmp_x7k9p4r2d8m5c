#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量替换 Manim 代码里的背景图片路径。

用法：
    python exchange_background.py <图片路径> <代码文件夹路径>

逻辑：
1) 全局替换形如 background_image="..." 的参数值。
2) 针对 ###BACKGROUND### ... ###BACKGROUND### 块内的 ImageMobject("...") 仅替换路径，
   避免误改其他 ImageMobject。
"""

import sys
import os
import re
from pathlib import Path


def replace_background_blocks(text: str, new_path: str) -> str:
    """仅在 ###BACKGROUND### 块内替换 ImageMobject 路径。"""
    block_pat = re.compile(r"###BACKGROUND###(.*?)###BACKGROUND###", re.S)
    img_pat = re.compile(r'(ImageMobject\(\s*[\'"])([^\'"]+)([\'"]\s*\))')

    def repl_block(m):
        block = m.group(1)

        def repl_img(img_match):
            return f"{img_match.group(1)}{new_path}{img_match.group(3)}"

        new_block = img_pat.sub(repl_img, block)
        return f"###BACKGROUND###{new_block}###BACKGROUND###"

    return block_pat.sub(repl_block, text)


def replace_background_kw(text: str, new_path: str) -> str:
    """替换 background_image='...' 形式的参数。"""
    kw_pat = re.compile(r'(background_image\s*=\s*[\'"])([^\'"]+)([\'"])')

    def repl_kw(m):
        return f"{m.group(1)}{new_path}{m.group(3)}"

    return kw_pat.sub(repl_kw, text)


def process_file(py_file: Path, new_path: str) -> bool:
    original = py_file.read_text(encoding="utf-8")
    updated = replace_background_kw(original, new_path)
    updated = replace_background_blocks(updated, new_path)

    if updated != original:
        py_file.write_text(updated, encoding="utf-8")
        return True
    return False


def main():
    if len(sys.argv) != 3:
        print("用法: python exchange_background.py <图片路径> <代码文件夹路径>")
        sys.exit(1)

    image_path = os.path.abspath(sys.argv[1])
    folder = Path(sys.argv[2]).resolve()

    if not os.path.exists(image_path):
        print(f"图片不存在: {image_path}")
        sys.exit(1)

    if not folder.exists() or not folder.is_dir():
        print(f"目录不存在或不是文件夹: {folder}")
        sys.exit(1)

    changed = 0
    total = 0
    for py_file in folder.rglob("*.py"):
        total += 1
        if process_file(py_file, image_path):
            changed += 1
            print(f"已替换: {py_file}")

    print(f"完成：扫描 {total} 个 .py 文件，修改 {changed} 个。")


if __name__ == "__main__":
    main()
