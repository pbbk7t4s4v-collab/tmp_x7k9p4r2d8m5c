#!/usr/bin/env python3
"""
Manim动画代码 - 已插入断点
原始文件: 3_2.py
处理时间: 2025-11-27 13:41:45
处理方式: 使用BreakPoint prompt自动插入配对断点
"""

from manim import *
import numpy as np

class IntegralImageAnalysis(Scene):
    def construct(self):
        # 1. 标题设置 (严格按照模板)
        title = Text("积分面积累积图像分析", 
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        
        title_group = VGroup(title, title_line)
        
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )
        #BREAKPOINT: 0

        # 2. 坐标系设置
        axes = Axes(
            x_range=[0, 7, 1],      # 0 到 2pi 约为 6.28
            y_range=[-1.5, 2.5, 1], # sin(x) 在 [-1,1], A(x) 在 [0,2]
            x_length=6,
            y_length=5,
            axis_config={"include_tip": True, "color": GREY},
        ).to_edge(LEFT, buff=1).shift(DOWN * 0.5)
        
        # 坐标轴标签
        x_label = axes.get_x_axis_label("x")
        y_label = axes.get_y_axis_label("y")
        
        # 关键点标记
        pi_tick = Line(UP*0.1, DOWN*0.1, color=WHITE).move_to(axes.c2p(PI, 0))
        pi_text = MathTex(r"\pi").next_to(pi_tick, DOWN, buff=0.1)
        
        two_pi_tick = Line(UP*0.1, DOWN*0.1, color=WHITE).move_to(axes.c2p(2*PI, 0))
        two_pi_text = MathTex(r"2\pi").next_to(two_pi_tick, DOWN, buff=0.1)
        
        axis_group = VGroup(axes, x_label, y_label, pi_tick, pi_text, two_pi_tick, two_pi_text)
        
        self.play(FadeIn(axis_group))
        #BREAKPOINT: 1

        # 3. 函数图像定义
        # sin(t) 图像 (被积函数)
        sin_graph = axes.plot(lambda x: np.sin(x), x_range=[0, 2*PI], color=BLUE_C)
        sin_label = MathTex(r"\sin(t)", color=BLUE_C, font_size=24).next_to(sin_graph, UP).shift(LEFT*2)
        
        # A(x) 图像 (累积函数 1 - cos(x))
        # integral of sin(t) from 0 to x is -cos(x) - (-cos(0)) = 1 - cos(x)
        acc_graph = axes.plot(lambda x: 1 - np.cos(x), x_range=[0, 2*PI], color=YELLOW)
        acc_label = MathTex(r"A(x)", color=YELLOW, font_size=24).next_to(axes.c2p(PI, 2), UP)

        # 4. 右侧文字说明 (分步展示)
        text_start_pos = UP * 2 + RIGHT * 1.5
        
        # 第一部分说明:[0, pi]
        text1_box = VGroup(
            Text("1. 区间 [0, π]:", font="AR PL UKai CN", font_size=24, color=WHITE),
            MathTex(r"\sin(t) > 0", font_size=26, color=BLUE_C),
            Text("A(x) 从 0 增至 2", font="AR PL UKai CN", font_size=24, color=YELLOW)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15).move_to(text_start_pos)
        
        # 对应的图像部分
        sin_part1 = axes.plot(lambda x: np.sin(x), x_range=[0, PI], color=BLUE_C)
        acc_part1 = axes.plot(lambda x: 1 - np.cos(x), x_range=[0, PI], color=YELLOW)
        area_part1 = axes.get_area(sin_part1, x_range=[0, PI], color=BLUE, opacity=0.3)

        self.play(
            FadeIn(text1_box, shift=LEFT),
            Create(sin_part1),
            FadeIn(sin_label),
            run_time=1.5
        )
        #BREAKPOINT: 2
        self.play(
            FadeIn(area_part1),
            Create(acc_part1),
            run_time=1.5
        )
        #BREAKPOINT: 3

        # 第二部分说明:x = pi
        text2_box = VGroup(
            Text("2. x = π 处:", font="AR PL UKai CN", font_size=24, color=WHITE),
            MathTex(r"\sin(\pi) = 0", font_size=26, color=BLUE_C),
            Text("A(x) 达最大值 2", font="AR PL UKai CN", font_size=24, color=YELLOW)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15).next_to(text1_box, DOWN, buff=0.4, aligned_edge=LEFT)
        
        # 辅助线
        line_at_pi = DashedLine(axes.c2p(PI, 0), axes.c2p(PI, 2), color=WHITE)
        dot_max = Dot(axes.c2p(PI, 2), color=YELLOW)

        self.play(
            FadeIn(text2_box, shift=LEFT),
            Create(line_at_pi),
            FadeIn(dot_max),
            FadeIn(acc_label),
            run_time=1.5
        )
        #BREAKPOINT: 4

        # 第三部分说明:[pi, 2pi]
        text3_box = VGroup(
            Text("3. 区间 [π, 2π]:", font="AR PL UKai CN", font_size=24, color=WHITE),
            MathTex(r"\sin(t) < 0", font_size=26, color=BLUE_C),
            Text("A(x) 从 2 落至 0", font="AR PL UKai CN", font_size=24, color=YELLOW)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15).next_to(text2_box, DOWN, buff=0.4, aligned_edge=LEFT)

        # 对应的图像部分
        sin_part2 = axes.plot(lambda x: np.sin(x), x_range=[PI, 2*PI], color=BLUE_C)
        acc_part2 = axes.plot(lambda x: 1 - np.cos(x), x_range=[PI, 2*PI], color=YELLOW)
        area_part2 = axes.get_area(sin_part2, x_range=[PI, 2*PI], color=RED, opacity=0.3) # 负面积用红色示意

        self.play(
            FadeIn(text3_box, shift=LEFT),
            Create(sin_part2),
            FadeIn(area_part2),
            Create(acc_part2),
            run_time=1.5
        )
        #BREAKPOINT: 5
        
        # 强调框
        rect = SurroundingRectangle(text2_box, color=ORANGE, buff=0.1)
        self.play(Create(rect), run_time=1)
        #BREAKPOINT: 6

        self.wait(2)
