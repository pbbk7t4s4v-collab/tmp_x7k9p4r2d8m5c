from manim import *

class IntegralAccumulation(Scene):
    def construct(self):
        # 1. 标题设置 (严格按照模板)
        title = Text("积分的面积累积图像", 
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        
        title_group = VGroup(title, title_line)
        
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # 2. 布局规划：左侧为图像，右侧为文字说明
        
        # --- 左侧：几何图像 ---
        # 创建坐标系
        ax = Axes(
            x_range=[0, 5, 1],
            y_range=[0, 4, 1],
            x_length=5,
            y_length=4,
            axis_config={"include_tip": True, "tip_width": 0.2, "tip_height": 0.2}
        ).to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)
        
        # 定义函数 f(t)
        def func(t):
            return 0.1 * (t - 2) ** 2 + 1.5

        graph = ax.plot(func, color=BLUE, x_range=[0, 4.5])
        graph_label = MathTex("f(t)", color=BLUE).next_to(graph, UP)

        # 动态面积累积
        x_tracker = ValueTracker(0)
        
        # always_redraw 用于每一帧重新绘制面积
        area = always_redraw(lambda: ax.get_area(
            graph,
            x_range=[0, x_tracker.get_value()],
            color=BLUE,
            opacity=0.5
        ))
        
        # 动态垂直线
        v_line = always_redraw(lambda: ax.get_vertical_line(
            ax.c2p(x_tracker.get_value(), func(x_tracker.get_value())),
            color=YELLOW
        ))
        
        # 动态标签 x
        x_label = always_redraw(lambda: MathTex("x").next_to(
            ax.c2p(x_tracker.get_value(), 0), DOWN
        ))

        # 积分公式展示
        formula = MathTex(r"S(x) = \int_0^x f(t) dt", font_size=36)
        formula.next_to(ax, UP, buff=0.2)
        
        # 框住公式
        box = SurroundingRectangle(formula, color=YELLOW, buff=0.1)

        # --- 右侧：应用意义文本 ---
        text_group = VGroup()
        
        # 使用 Text 而不是 BulletedList 以避免兼容性问题和字体问题
        item1 = Text("• 揭示定积分与不定积分的关系", font="AR PL UKai CN", font_size=24)
        item2 = Text("• 展示微积分基本定理几何意义", font="AR PL UKai CN", font_size=24)
        item3 = Text("• 直观呈现原函数的构造过程", font="AR PL UKai CN", font_size=24)
        
        text_group.add(item1, item2, item3)
        text_group.arrange(DOWN, aligned_edge=LEFT, buff=0.6)
        text_group.to_edge(RIGHT, buff=1.0).shift(UP * 0.5)

        # 3. 动画流程
        
        # 第一步：显示坐标系和曲线
        self.play(Create(ax), Create(graph), Write(graph_label), run_time=1.5)
        
        # 第二步：显示公式
        self.play(Write(formula), Create(box))
        
        # 第三步：同步进行面积累积和文字展示
        self.add(area, v_line, x_label)
        
        # 这里的动画让 x 从 0 移动到 4，模拟积分过程，同时右侧文字逐行出现
        self.play(
            x_tracker.animate.set_value(4),
            FadeIn(item1, shift=LEFT),
            run_time=2
        )
        
        self.play(FadeIn(item2, shift=LEFT), run_time=1)
        self.play(FadeIn(item3, shift=LEFT), run_time=1)

        self.wait(2)