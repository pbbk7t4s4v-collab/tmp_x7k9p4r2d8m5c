from manim import *

class AreaAccumulationDefinition(Scene):
    def construct(self):
        # ---------------------------------------------------------
        # 1. 标题部分 (根据模板要求)
        # ---------------------------------------------------------
        title = Text("面积累积函数的定义", 
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        
        # 组合标题元素
        title_group = VGroup(title, title_line)
        
        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # ---------------------------------------------------------
        # 2. 内容布局设计
        # ---------------------------------------------------------
        
        # 左侧：数学公式与文本解释
        # 公式 A(x) = ∫ₐˣ f(t) dt
        formula = Text("A(x) = ∫ₐˣ f(t) dt", font_size=42, font="AR PL UKai CN")
        
        # 使用 SurroundingRectangle 强调公式
        formula_box = SurroundingRectangle(formula, color=BLUE, buff=0.2)
        formula_group = VGroup(formula, formula_box)

        # 解释文本
        bullet_point_1 = Text("a : 固定的下限", font="AR PL UKai CN", font_size=24, color=GRAY_B)
        bullet_point_2 = Text("x : 变动的上限", font="AR PL UKai CN", font_size=24, color=YELLOW)
        bullet_point_3 = Text("A(x) : 曲线与t轴间的带符号面积", font="AR PL UKai CN", font_size=24)
        
        # 排版解释文本
        text_group = VGroup(bullet_point_1, bullet_point_2, bullet_point_3).arrange(DOWN, buff=0.3, aligned_edge=LEFT)
        
        # 组合左侧所有内容
        left_content = VGroup(formula_group, text_group).arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        left_content.to_edge(LEFT, buff=1).shift(DOWN * 0.5)

        # 右侧：几何可视化
        # 创建坐标系
        axes = Axes(
            x_range=[0, 6, 1],
            y_range=[0, 4, 1],
            x_length=6,
            y_length=4,
            axis_config={"include_tip": True, "font_size": 20},
        ).to_edge(RIGHT, buff=1).shift(DOWN * 0.5)

        labels = axes.get_axis_labels(
            x_label=Text("t", font_size=20, font="AR PL UKai CN"),
            y_label=Text("y", font_size=20, font="AR PL UKai CN")
        )

        # 定义函数 f(t) = 0.1*(t-2)^2 + 1.2 (平滑曲线)
        def func_curve(t):
            return 0.15 * (t - 2.5)**2 + 1.0

        graph = axes.plot(func_curve, x_range=[0, 5.5], color=BLUE_C)
        graph_label = axes.get_graph_label(
            graph,
            Text("f(t)", font_size=24, font="AR PL UKai CN"),
            x_val=5.5,
            direction=UP
        )

        # 设置固定下限 a
        a_val = 1.0
        line_a = axes.get_vertical_line(axes.c2p(a_val, func_curve(a_val)), color=WHITE, line_func=DashedLine)
        label_a = Text("a", font_size=24, font="AR PL UKai CN").next_to(axes.c2p(a_val, 0), DOWN)

        # 设置变动上限 x (使用 ValueTracker 实现动画)
        x_tracker = ValueTracker(a_val)

        # 动态绘制面积区域
        area = always_redraw(lambda: axes.get_area(
            graph,
            x_range=[a_val, x_tracker.get_value()],
            color=YELLOW,
            opacity=0.5
        ))

        # 动态绘制 x 的垂线
        line_x = always_redraw(lambda: axes.get_vertical_line(
            axes.c2p(x_tracker.get_value(), func_curve(x_tracker.get_value())),
            color=YELLOW
        ))

        # 动态绘制 x 的标签
        label_x = always_redraw(lambda: Text("x", color=YELLOW, font_size=24, font="AR PL UKai CN").next_to(
            axes.c2p(x_tracker.get_value(), 0), DOWN
        ))

        # ---------------------------------------------------------
        # 3. 动画流程
        # ---------------------------------------------------------
        
        # 步骤 1: 显示坐标系和函数曲线
        self.play(
            Create(axes),
            Write(labels),
            Create(graph),
            FadeIn(graph_label),
            run_time=2
        )

        # 步骤 2: 显示公式和解释
        self.play(
            Write(formula),
            Create(formula_box),
            run_time=1.5
        )
        self.play(FadeIn(text_group, shift=RIGHT), run_time=1)

        # 步骤 3: 演示积分累积过程
        # 先显示起点 a
        self.play(Create(line_a), Write(label_a))
        
        # 添加动态元素到场景
        self.add(area, line_x, label_x)
        
        # 动画：x 从 a 移动到 5，展示面积累积
        self.play(
            x_tracker.animate.set_value(5),
            run_time=4,
            rate_func=smooth
        )

        self.wait(1)
