from manim import *

class SlopeRelation(Scene):
    def construct(self):
        # 1. 标题设置
        title = Text("斜率与原函数的关系", 
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # 2. 核心公式展示
        # MathTex用于展示数学公式
        formula = MathTex(
            r"\frac{dA}{dx}", r"=", r"f(x)",
            font_size=60
        )
        formula.set_color_by_tex(r"dA", BLUE)
        formula.set_color_by_tex(r"f(x)", YELLOW)
        
        # 将公式放置在屏幕上方偏下的位置
        formula.move_to(UP * 0.5)

        # 添加外框强调
        box = SurroundingRectangle(formula, color=BLUE, buff=0.3)
        
        # 这里的文字解释
        desc = Text("面积累积函数的斜率 = 原函数的值", font="AR PL UKai CN", font_size=24, color=GRAY_A)
        desc.next_to(box, UP, buff=0.2)

        self.play(Write(desc))
        self.play(Write(formula))
        self.play(Create(box))
        
        # 3. 推论可视化展示
        # 创建两个推论的组，使用VGroup便于排版
        
        # 推论1: f(x) 越大 -> A(x) 越陡
        # 图标：一个陡峭的箭头
        icon_steep = Arrow(start=ORIGIN, end=UR*0.8 + UP*0.2, color=YELLOW, buff=0).scale(0.6)
        
        line1_tex = MathTex(r"f(x) \uparrow", color=YELLOW)
        line1_text = Text("意味着 A(x) 图像越陡峭", font="AR PL UKai CN", font_size=28)
        
        group1 = VGroup(line1_tex, line1_text, icon_steep)
        group1.arrange(RIGHT, buff=0.3)
        
        # 推论2: f(x) = 0 -> A(x) 水平
        # 图标：一个水平线段
        icon_flat = Line(LEFT, RIGHT, color=RED).scale(0.4)
        
        line2_tex = MathTex(r"f(x) = 0", color=RED)
        line2_text = Text("意味着 A(x) 出现水平切线", font="AR PL UKai CN", font_size=28)
        
        group2 = VGroup(line2_tex, line2_text, icon_flat)
        group2.arrange(RIGHT, buff=0.3)

        # 补充说明极值点
        extra_note = Text("(对应极值点)", font="AR PL UKai CN", font_size=24, color=GRAY)
        extra_note.next_to(group2, DOWN, buff=0.15)

        # 整体排版
        # 将两个推论组垂直排列
        conclusions = VGroup(group1, group2, extra_note)
        # 手动调整垂直间距
        group2.next_to(group1, DOWN, buff=0.6)
        extra_note.next_to(group2, DOWN, buff=0.15)
        
        # 放置在公式下方
        conclusions.next_to(box, DOWN, buff=1.0)

        # 4. 播放推论动画
        self.play(FadeIn(group1, shift=LEFT))
        self.wait(0.5)
        self.play(FadeIn(group2, shift=LEFT))
        self.play(Write(extra_note))

        self.wait(2)