from manim import *

class IntegralAccumulationAnalysis(Scene):
    def construct(self):
        # 1. 标题设置 (严格按照模板)
        title = Text("积分的面积累积图像分析", 
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.0), 
            GrowFromCenter(title_line, run_time=0.8)
        )

        # 2. 坐标系与函数图像 (左侧布局)
        # 创建坐标轴
        axes = Axes(
            x_range=[0, 5, 1],
            y_range=[0, 4, 1],
            x_length=5,
            y_length=3.5,
            axis_config={"include_tip": True, "color": GREY},
        ).to_edge(LEFT, buff=1).shift(DOWN * 0.5)
        
        labels = axes.get_axis_labels(x_label="x", y_label="f(t)")

        # 定义函数 f(t) = 0.1(t-2)^2 + 1.5 (平滑曲线)
        func = lambda x: 0.1 * (x - 2)**2 + 1.5
        graph = axes.plot(func, x_range=[0, 4.5], color=BLUE_C)
        
        # 3. 动态面积累积 (核心可视化)
        # 使用 ValueTracker 控制积分上限 x
        x_tracker = ValueTracker(0.5)
        
        # 动态绘制阴影面积 (从 0 到 x_tracker 的值)
        # always_redraw 确保每一帧都重新计算面积形状
        area = always_redraw(lambda: axes.get_area(
            graph,
            x_range=[0, x_tracker.get_value()],
            color=BLUE,
            opacity=0.5
        ))

        # 动态垂直线，指示当前的 x 位置
        v_line = always_redraw(lambda: axes.get_vertical_line(
            axes.c2p(x_tracker.get_value(), func(x_tracker.get_value())),
            color=YELLOW
        ))
        
        # x 的标签
        x_label_dynamic = always_redraw(lambda: MathTex("x").next_to(v_line, DOWN))

        # 4. 右侧文字说明与公式 (右侧布局)
        # 积分公式
        formula = MathTex(r"S(x) = \int_0^x f(t) dt", font_size=36)
        formula.to_edge(RIGHT, buff=1.5).shift(UP * 1)
        
        # 文字解释
        explanation_1 = Text("阴影面积 S(x) 随 x 变化", font="AR PL UKai CN", font_size=24, color=WHITE)
        explanation_1.next_to(formula, DOWN, buff=0.4)
        
        explanation_2 = Text("面积增长率 = 当前高度", font="AR PL UKai CN", font_size=24, color=YELLOW)
        explanation_2.next_to(explanation_1, DOWN, buff=0.3)

        # 结论公式
        conclusion = MathTex(r"S'(x) = f(x)", font_size=40, color=RED)
        conclusion.next_to(explanation_2, DOWN, buff=0.5)
        
        # 强调框
        box = SurroundingRectangle(conclusion, color=RED, buff=0.15)

        # 5. 动画流程 (控制在15秒内)
        # 第一阶段：展示坐标系和函数 (2秒)
        self.play(
            Create(axes), 
            Write(labels), 
            Create(graph), 
            run_time=2
        )
        
        # 第二阶段：展示公式并开始累积动画 (5秒)
        self.play(FadeIn(formula), Write(explanation_1))
        self.add(area, v_line, x_label_dynamic)
        # 移动 x 从 0.5 到 4.0
        self.play(x_tracker.animate.set_value(4.0), run_time=4, rate_func=linear)
        
        # 第三阶段：展示特征结论 (2秒)
        self.play(
            FadeIn(explanation_2),
            TransformFromCopy(explanation_1, conclusion),
            Create(box),
            run_time=2
        )

        self.wait(1)