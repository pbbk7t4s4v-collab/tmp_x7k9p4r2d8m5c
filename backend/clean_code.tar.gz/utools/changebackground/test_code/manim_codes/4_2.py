from manim import *

class IntegralPhysicalMeaning(Scene):
    def construct(self):
        # 1. 标题设置
        title = Text("积分函数的物理意义", 
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # 2. 绘制示意图 (图在上，文字在下)
        # 创建坐标轴
        axes = Axes(
            x_range=[0, 6, 1],
            y_range=[0, 5, 1],
            x_length=7,
            y_length=3,
            axis_config={"include_tip": True, "tip_shape": StealthTip},
        ).shift(UP * 0.5)

        # 轴标签
        x_label = Text("t").next_to(axes.x_axis, RIGHT)
        y_label = Text("f(t)").next_to(axes.y_axis, UP)

        # 绘制函数曲线
        curve = axes.plot(lambda t: 0.2 * (t - 2.5)**2 + 1.5, x_range=[0, 5.5], color=BLUE)
        
        # 绘制积分区域 (从 a 到 x)
        t_a = 1.0
        t_x = 4.0
        area = axes.get_area(curve, x_range=[t_a, t_x], color=TEAL, opacity=0.5)
        
        # 区域标签
        label_a = Text("a", font_size=24).next_to(axes.c2p(t_a, 0), DOWN)
        label_x = Text("x", font_size=24).next_to(axes.c2p(t_x, 0), DOWN)
        label_area = Text("A(x)", color=WHITE, font_size=30).move_to(axes.c2p((t_a+t_x)/2, 0.8))

        # 3. 物理意义文字说明
        font_config = {"font": "AR PL UKai CN", "font_size": 28}
        
        # 情景一：速度 -> 位移
        case1_label = Text("情景一：", **font_config, color=YELLOW)
        case1_cond = Text("f(t) = 速度", **font_config).scale(0.8)
        case1_arrow = Text("⇒").scale(0.8)
        case1_res = Text("A(x) = 位移累积", **font_config).scale(0.8)
        
        # 组合情景一
        row1 = VGroup(case1_label, case1_cond, case1_arrow, case1_res).arrange(RIGHT, buff=0.2)
        
        # 情景二：流量 -> 总流量
        case2_label = Text("情景二：", **font_config, color=YELLOW)
        case2_cond = Text("f(t) = 流量", **font_config).scale(0.8)
        case2_arrow = Text("⇒").scale(0.8)
        case2_res = Text("A(x) = 总流量", **font_config).scale(0.8)
        
        # 组合情景二
        row2 = VGroup(case2_label, case2_cond, case2_arrow, case2_res).arrange(RIGHT, buff=0.2)
        
        # 对齐两行文字
        # 让箭头对齐以保持美观
        row2.match_x(row1) 
        text_group = VGroup(row1, row2).arrange(DOWN, buff=0.5, aligned_edge=LEFT)
        text_group.next_to(axes, DOWN, buff=0.8)

        # 添加强调框
        rect1 = SurroundingRectangle(row1, color=BLUE_B, buff=0.15, corner_radius=0.1)
        rect2 = SurroundingRectangle(row2, color=GREEN_B, buff=0.15, corner_radius=0.1)

        # 4. 动画流程
        # 显现坐标系和曲线
        self.play(Create(axes), Write(x_label), Write(y_label), run_time=1)
        self.play(Create(curve), run_time=1)
        
        # 显现积分面积
        self.play(
            FadeIn(area), 
            Write(label_a), 
            Write(label_x), 
            Write(label_area),
            run_time=1
        )

        # 显现文字说明
        self.play(
            FadeIn(row1, shift=UP),
            Create(rect1),
            run_time=1.5
        )
        self.play(
            FadeIn(row2, shift=UP),
            Create(rect2),
            run_time=1.5
        )

        self.wait(2)
