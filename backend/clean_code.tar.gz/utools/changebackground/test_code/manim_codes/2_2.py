from manim import *

class AreaAccumulationEffect(Scene):
    def construct(self):
        # --- 1. 标题设置 (符合模板要求) ---
        title = Text("正负区域对累积函数的影响", 
                    font_size=34,
                    font="AR PL UKai CN", 
                    color=WHITE, 
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        
        title_group = VGroup(title, title_line)
        
        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # --- 2. 坐标系与函数定义 ---
        # 布局：左侧放两个上下对齐的坐标系，右侧放说明文字
        
        # 上方坐标系：f(x)
        axes_f = Axes(
            x_range=[0, 7, 1],
            y_range=[-1.5, 1.5, 1],
            x_length=6,
            y_length=2.2,
            axis_config={"include_tip": True, "tip_shape": StealthTip},
        ).to_edge(LEFT, buff=0.5).shift(UP * 1.2)
        
        label_f = MathTex("f(x)", color=BLUE).next_to(axes_f.y_axis, UP)

        # 下方坐标系：A(x)
        axes_A = Axes(
            x_range=[0, 7, 1],
            y_range=[-0.5, 2.5, 1],
            x_length=6,
            y_length=2.2,
            axis_config={"include_tip": True, "tip_shape": StealthTip},
        ).to_edge(LEFT, buff=0.5).shift(DOWN * 1.8)
        
        label_A = MathTex("A(x) = \int f(t)dt", color=YELLOW).next_to(axes_A.y_axis, UP)

        # 对齐坐标系原点
        axes_A.x_axis.align_to(axes_f.x_axis, LEFT)

        # 定义函数：f(x) = sin(x), A(x) = 1 - cos(x)
        # 范围取 0 到 2*PI (约为 6.28)
        curve_f = axes_f.plot(lambda x: np.sin(x), x_range=[0, 2*PI], color=BLUE)
        curve_A = axes_A.plot(lambda x: 1 - np.cos(x), x_range=[0, 2*PI], color=YELLOW)

        # 区域着色
        area_pos = axes_f.get_area(curve_f, x_range=[0, PI], color=GREEN, opacity=0.4)
        area_neg = axes_f.get_area(curve_f, x_range=[PI, 2*PI], color=RED, opacity=0.4)

        # 极值点虚线
        dashed_line = DashedLine(
            start=axes_f.c2p(PI, 0),
            end=axes_A.c2p(PI, 2),
            color=WHITE,
            stroke_opacity=0.6
        )

        # --- 3. 右侧说明文字 (使用 VGroup 手动排版避免 BulletedList 问题) ---
        
        # 文本样式辅助函数
        def create_text_row(math_str, text_str, color):
            m_tex = MathTex(math_str, color=color, font_size=32)
            t_tex = Text(text_str, font="AR PL UKai CN", font_size=28, color=WHITE)
            # 组合
            group = VGroup(m_tex, t_tex).arrange(RIGHT, buff=0.2)
            return group

        row1 = create_text_row("f(x) > 0", "→ A(x) 向上增长", GREEN)
        row2 = create_text_row("f(x) < 0", "→ A(x) 向下减少", RED)
        row3 = create_text_row("f(x) = 0", "→ A(x) 极值点", WHITE)

        text_group = VGroup(row1, row2, row3).arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        text_group.next_to(axes_f, RIGHT, buff=0.8).shift(DOWN * 0.5)

        # 给重点文字加框
        rect1 = SurroundingRectangle(row1, color=GREEN, buff=0.1, stroke_width=2)
        rect2 = SurroundingRectangle(row2, color=RED, buff=0.1, stroke_width=2)
        rect3 = SurroundingRectangle(row3, color=WHITE, buff=0.1, stroke_width=2)

        # --- 4. 动画流程 (控制在15秒内) ---
        
        # 第一步：显示坐标系和f(x)
        self.play(
            FadeIn(axes_f), FadeIn(axes_A), 
            Write(label_f), Write(label_A),
            Create(curve_f, run_time=1.5)
        )

        # 第二步：正区域 -> A(x) 增长
        self.play(
            FadeIn(area_pos),
            Write(row1),
            Create(rect1),
            Create(axes_A.plot(lambda x: 1 - np.cos(x), x_range=[0, PI], color=YELLOW), run_time=1.5)
        )

        # 第三步：负区域 -> A(x) 减少
        self.play(
            FadeIn(area_neg),
            Write(row2),
            Create(rect2),
            Create(axes_A.plot(lambda x: 1 - np.cos(x), x_range=[PI, 2*PI], color=YELLOW), run_time=1.5)
        )

        # 第四步：零点对应极值
        # 标记 f(x)=0 的点
        dot_zero = Dot(axes_f.c2p(PI, 0), color=WHITE)
        # 标记 A(x) 的极值点
        dot_peak = Dot(axes_A.c2p(PI, 2), color=YELLOW)
        
        self.play(
            Create(dashed_line),
            FadeIn(dot_zero),
            FadeIn(dot_peak),
            Write(row3),
            Create(rect3)
        )

        self.wait(2)