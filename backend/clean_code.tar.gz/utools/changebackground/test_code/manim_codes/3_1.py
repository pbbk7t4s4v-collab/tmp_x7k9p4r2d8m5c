from manim import *

class IntegralAccumulation(Scene):
    def construct(self):
        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("积分的面积累积图像", 
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        
        # 组合标题元素
        title_group = VGroup(title, title_line)
        
        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # ---------------------------------------------------------
        # 2. 公式展示
        # ---------------------------------------------------------
        # 定义函数公式
        func_tex = MathTex(r"f(t) = \sin(t)", color=BLUE, font_size=36)
        
        # 定义累积函数公式
        accum_tex = MathTex(
            r"A(x) = \int_0^x \sin(t)dt = 1 - \cos(x)", 
            color=RED, 
            font_size=36
        )
        
        # 排版公式
        formulas = VGroup(func_tex, accum_tex).arrange(RIGHT, buff=1.0)
        formulas.next_to(title_group, DOWN, buff=0.5)
        
        self.play(Write(formulas))

        # ---------------------------------------------------------
        # 3. 坐标系与图像构建
        # ---------------------------------------------------------
        # 创建坐标系
        axes = Axes(
            x_range=[0, 7, 1],      # x轴范围 [0, 7]
            y_range=[-1.5, 2.5, 1], # y轴范围 [-1.5, 2.5] 以容纳 1-cos(x)
            x_length=10,
            y_length=4.5,
            axis_config={"color": GREY, "include_tip": True},
            tips=False
        ).to_edge(DOWN, buff=0.5)
        
        # x轴标签
        x_label = axes.get_x_axis_label("t")
        y_label = axes.get_y_axis_label("y")
        labels = VGroup(x_label, y_label)

        # 绘制 sin(t) 图像
        sin_graph = axes.plot(lambda t: np.sin(t), color=BLUE, x_range=[0, 2*PI])
        sin_label = axes.get_graph_label(sin_graph, "f(t)", x_val=1, direction=UP, color=BLUE)

        # 绘制 A(x) = 1 - cos(x) 图像 (初始不显示，用于动画)
        accum_graph = axes.plot(lambda x: 1 - np.cos(x), color=RED, x_range=[0, 2*PI])
        accum_label = axes.get_graph_label(accum_graph, "A(x)", x_val=4, direction=UP, color=RED)

        # ---------------------------------------------------------
        # 4. 动画展示核心逻辑
        # ---------------------------------------------------------
        self.play(
            Create(axes), 
            FadeIn(labels),
            Create(sin_graph), 
            FadeIn(sin_label)
        )

        # 创建一个 ValueTracker 来控制 x 的位置
        x_tracker = ValueTracker(0)

        # 动态绘制面积 (始终重绘)
        # 注意：get_area 会自动处理正负区域的视觉效果
        area = always_redraw(lambda: axes.get_area(
            sin_graph,
            x_range=[0, x_tracker.get_value()],
            color=BLUE,
            opacity=0.3
        ))

        # 动态绘制红色曲线上的点，引导视线
        dot = always_redraw(lambda: Dot(
            point=axes.c2p(x_tracker.get_value(), 1 - np.cos(x_tracker.get_value())),
            color=RED
        ))

        # 使用矩形框强调最终结果公式
        box = SurroundingRectangle(accum_tex, color=YELLOW, buff=0.1)

        self.add(area, dot)

        # 同步播放：x 从 0 增加到 2*PI，同时绘制红色曲线
        self.play(
            x_tracker.animate.set_value(2 * PI),
            Create(accum_graph, run_time=6, rate_func=linear),
            Create(box, run_time=2),
            run_time=6,
            rate_func=linear
        )
        
        self.play(FadeIn(accum_label))

        self.wait(1)