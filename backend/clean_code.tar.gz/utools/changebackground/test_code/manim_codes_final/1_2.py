#!/usr/bin/env python3
"""
Manim动画代码 - 已插入wait语句
原始文件: 1_2.py
处理时间: 2025-11-27 13:44:26
语速设置: 5.38 字/秒 (0.186 秒/字)
自动生成: manim_auto_wait_generator.py
"""

#!/usr/bin/env python3
"""
Manim动画代码 - 已插入断点
原始文件: 1_2.py
处理时间: 2025-11-27 13:35:30
处理方式: 使用BreakPoint prompt自动插入配对断点
"""

from manim import *

class IntegralAccumulationProperties(Scene):
    def construct(self):
        ###BACKGROUND###
        bg = ImageMobject("/home/TeachMasterAppV2/backend/green_and_blue.png")
        bg.scale_to_fit_height(config.frame_height)
        bg.scale_to_fit_width(config.frame_width)
        bg.set_opacity(0.9)
        bg.move_to(ORIGIN)
        self.add(bg)
        ###BACKGROUND###
        # 1. 标题设置 (严格按照模板)
        title = Text("积分累积函数的关键性质", 
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        
        # 标题动画
        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))
        #BREAKPOINT: 0
        self.wait(6.3)  # 34字, 5.4字/秒

        # 2. 内容文本构建
        # 性质 1: f(t) > 0 -> 递增
        p1_cond = MathTex(r"f(t) > 0", color=BLUE)
        p1_res = Text("→ A(x) 单调递增", font="AR PL UKai CN", font_size=28)
        prop1 = VGroup(p1_cond, p1_res).arrange(RIGHT, buff=0.3)

        # 性质 2: f(t) < 0 -> 递减
        p2_cond = MathTex(r"f(t) < 0", color=RED)
        p2_res = Text("→ A(x) 单调递减", font="AR PL UKai CN", font_size=28)
        prop2 = VGroup(p2_cond, p2_res).arrange(RIGHT, buff=0.3)

        # 性质 3: 微积分基本定理
        p3_math = MathTex(r"A'(x) = f(x)", color=YELLOW)
        p3_desc = Text("(微积分基本定理)", font="AR PL UKai CN", font_size=24, color=GRAY_B)
        prop3 = VGroup(p3_math, p3_desc).arrange(RIGHT, buff=0.3)

        # 组合文本并排版
        text_group = VGroup(prop1, prop2, prop3).arrange(DOWN, buff=0.5, aligned_edge=LEFT)
        text_group.next_to(title_line, DOWN, buff=0.5)
        
        # 为重点公式添加框
        box = SurroundingRectangle(prop3, color=YELLOW, buff=0.15)

        # 3. 辅助可视化图形 (底部)
        # 创建坐标系
        axes = Axes(
            x_range=[0, 7],
            y_range=[-1.5, 1.5],
            x_length=8,
            y_length=2.5,
            axis_config={"include_tip": True, "color": GREY},
        )
        
        # 绘制函数 f(t) = sin(t - 0.5)
        func = axes.plot(lambda t: np.sin(t - 0.5), color=WHITE)
        func_label = MathTex("f(t)").scale(0.8).next_to(func, UP, buff=0.1)

        # 区域着色
        # 正区域 (递增)
        area_pos = axes.get_area(func, x_range=[0.5, 0.5 + PI], color=BLUE, opacity=0.3)
        label_pos = Text("增", font="AR PL UKai CN", color=BLUE, font_size=20).move_to(axes.c2p(2, 0.5))
        
        # 负区域 (递减)
        area_neg = axes.get_area(func, x_range=[0.5 + PI, 6.5], color=RED, opacity=0.3)
        label_neg = Text("减", font="AR PL UKai CN", color=RED, font_size=20).move_to(axes.c2p(5, -0.5))

        graph_group = VGroup(axes, func, area_pos, area_neg, label_pos, label_neg, func_label)
        graph_group.next_to(text_group, DOWN, buff=0.6)

        # 4. 动画展示流程
        # 展示前两条性质
        self.play(FadeIn(prop1, shift=RIGHT), run_time=0.8)
        #BREAKPOINT: 1
        self.wait(10.6)  # 57字, 5.4字/秒
        self.play(FadeIn(prop2, shift=RIGHT), run_time=0.8)
        #BREAKPOINT: 2
        self.wait(6.9)  # 37字, 5.4字/秒
        
        # 展示图形辅助理解
        self.play(Create(axes), Create(func), run_time=1.0)
        #BREAKPOINT: 3
        self.wait(3.0)  # 16字, 5.4字/秒
        self.play(FadeIn(area_pos), Write(label_pos), run_time=0.5) # 对应 f(t)>0
        #BREAKPOINT: 4
        self.wait(3.2)  # 17字, 5.4字/秒
        self.play(FadeIn(area_neg), Write(label_neg), run_time=0.5) # 对应 f(t)<0
        #BREAKPOINT: 5
        self.wait(3.0)  # 16字, 5.4字/秒
        
        # 最后展示核心定理
        self.play(Write(prop3), run_time=0.8)
        #BREAKPOINT: 6
        self.wait(10.8)  # 58字, 5.4字/秒
        self.play(Create(box), run_time=0.5)
        #BREAKPOINT: 7
        self.wait(8.0)  # 43字, 5.4字/秒

        self.wait(2)

        self.wait(5.22)
        to_fade = [m for m in self.mobjects if m != bg]
        self.play(FadeOut(*to_fade))