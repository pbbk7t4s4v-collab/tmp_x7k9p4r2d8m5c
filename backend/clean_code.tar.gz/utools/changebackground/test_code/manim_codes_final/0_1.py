# 自动生成的封面代码（中文）
import sys

# 确保可以找到 Demo_cn.py
backend_root = "/home/TeachMasterAppV2/backend"
if backend_root not in sys.path:
    sys.path.append(backend_root)

from Demo_cn import MergedLayoutScene2_cn


class Scene0_1(MergedLayoutScene2_cn):
    def __init__(self, **kwargs):
        super().__init__(
            class_title_text='课程名',
            avatar_image='/home/TeachMasterAppV2/backend/csh.png',
            professor_name='Timo',
            background_image='/home/TeachMasterAppV2/backend/green_and_blue.png',
            school='',
            university='',
            **kwargs
        )
