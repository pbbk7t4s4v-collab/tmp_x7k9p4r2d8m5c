#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量渲染 Manim 代码并合并对应音频。

用法：
    python merge_code_audio.py <manim代码文件夹> <audio文件夹> <输出文件夹>

约定：
- 代码文件名与音频文件名同名（code: foo.py，audio: foo.wav）。
- 使用 manim_env 环境下的 Python & ffmpeg。
- 合并时调用 backend/video_audio_merge_change.py（音频更长会拉长视频最后帧段）。
"""

import sys
import os
import subprocess
import shutil
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse

PYTHON_BIN = "/home/EduAgent/miniconda3/envs/manim_env/bin/python"


def find_rendered_video(media_root: Path, target_name: str) -> Path | None:
    """在 media/videos 下查找指定文件名的 mp4，返回最新的一个。"""
    latest = None
    latest_mtime = 0
    if not media_root.exists():
        return None
    for mp4 in media_root.rglob("*.mp4"):
        if mp4.name == target_name:
            mtime = mp4.stat().st_mtime
            if mtime > latest_mtime:
                latest_mtime = mtime
                latest = mp4
    return latest


def render_code(code_path: Path, backend_dir: Path, output_name: str, media_dir: Path) -> Path | None:
    """调用 manim 渲染单个代码文件，返回生成的 mp4 路径（在 media_dir/videos 内）。"""
    media_root = media_dir / "videos"
    if media_dir.exists():
        shutil.rmtree(media_dir)
    media_dir.mkdir(parents=True, exist_ok=True)

    cmd = [
        PYTHON_BIN,
        "-m",
        "manim",
        "render",
        code_path,
        "-q",
        "h",
        "--format",
        "mp4",
        "-o",
        output_name,
        "--media_dir",
        str(media_dir),
    ]
    result = subprocess.run(cmd, cwd=backend_dir, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"❌ 渲染失败 {code_path.name}: {result.stderr.strip()}")
        return None

    rendered = find_rendered_video(media_root, output_name)
    if not rendered:
        print(f"❌ 未找到渲染输出 {output_name}")
        return None
    return rendered


def merge_av(audio: Path, video: Path, output: Path, backend_dir: Path) -> bool:
    """调用改进版合并脚本，生成带音频视频。"""
    merge_script = backend_dir / "video_audio_merge_change.py"
    if not merge_script.exists():
        print(f"❌ 合并脚本不存在: {merge_script}")
        return False

    output.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        PYTHON_BIN,
        str(merge_script),
        str(audio),
        str(video),
        str(output),
    ]
    result = subprocess.run(cmd, cwd=backend_dir, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"❌ 合并失败 {video.name}: {result.stderr.strip()}")
        return False
    return True


def process_one(code_file: Path, audio_dir: Path, backend_dir: Path, tmp_video_dir: Path, out_dir: Path, media_base: Path) -> tuple[Path, bool]:
    """渲染 + 合并单个文件，返回 (code_file, success)。"""
    base = code_file.stem
    audio_file = audio_dir / f"{base}.wav"
    if not audio_file.exists():
        print(f"⚠️ 缺少对应音频，跳过: {audio_file}")
        return code_file, False

    media_dir = media_base / base

    print(f"🎬 渲染 {code_file.name} ...")
    rendered = render_code(code_file, backend_dir, f"{base}.mp4", media_dir)
    if not rendered:
        return code_file, False

    tmp_video_path = tmp_video_dir / f"{base}.mp4"
    shutil.copy2(rendered, tmp_video_path)

    final_output = out_dir / f"{base}.mp4"
    print(f"🎵 合并音频 {audio_file.name} -> {final_output.name}")
    ok = merge_av(audio_file, tmp_video_path, final_output, backend_dir)

    # 清理单独的 media 目录
    if media_dir.exists():
        shutil.rmtree(media_dir, ignore_errors=True)
    return code_file, ok


def main():
    parser = argparse.ArgumentParser(description="批量渲染 Manim 代码并合并音频，支持可选生成中文字幕")
    parser.add_argument("code_dir", help="Manim 代码文件夹（*.py）")
    parser.add_argument("audio_dir", help="音频文件夹（*.wav）")
    parser.add_argument("out_dir", help="输出文件夹（生成的视频）")
    parser.add_argument(
        "--with-subtitle",
        action=argparse.BooleanOptionalAction,
        default=True,
        dest="with_subtitle",
        help="是否生成中文字幕（默认生成；用 --no-with-subtitle 关闭）",
    )
    parser.add_argument("--text-dir", dest="text_dir", help="字幕对应的文本文件夹（默认优先使用 <audio_dir>/../speech，其次 audio_dir，要求同名 .txt）")
    parser.add_argument("--workers", type=int, default=3, help="并发渲染/合并任务数，默认3")
    args = parser.parse_args()

    code_dir = Path(args.code_dir).resolve()
    audio_dir = Path(args.audio_dir).resolve()
    out_dir = Path(args.out_dir).resolve()

    if not code_dir.is_dir():
        print(f"❌ 代码目录不存在: {code_dir}")
        sys.exit(1)
    if not audio_dir.is_dir():
        print(f"❌ 音频目录不存在: {audio_dir}")
        sys.exit(1)

    backend_dir = Path(__file__).resolve().parents[2]  # /backend
    tmp_video_dir = out_dir / "_video_tmp"
    tmp_video_dir.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)
    media_base = out_dir / "_media_tmp"
    media_base.mkdir(parents=True, exist_ok=True)

    py_files = sorted(code_dir.glob("*.py"))
    if not py_files:
        print("⚠️ 代码目录下没有 .py 文件")
        sys.exit(0)

    success_cnt = 0
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = {
            executor.submit(process_one, code_file, audio_dir, backend_dir, tmp_video_dir, out_dir, media_base): code_file
            for code_file in py_files
        }
        for fut in as_completed(futures):
            code_file, ok = fut.result()
            if ok:
                success_cnt += 1
    final_output_path = out_dir

    # 可选生成字幕（中文）
    if args.with_subtitle:
        subtitle_script = "/home/TeachMaster/ML/subtitle_generator_cn_effi.py"
        if args.text_dir:
            text_dir = Path(args.text_dir).resolve()
        else:
            candidate = audio_dir.parent / "speech"
            text_dir = candidate if candidate.is_dir() else audio_dir
        if not text_dir.is_dir():
            print(f"⚠️ 字幕开启但文本目录不存在: {text_dir}")
        else:
            subtitle_out = out_dir.parent / f"{out_dir.name}_subtitle"
            subtitle_out.mkdir(parents=True, exist_ok=True)
            cmd = [
                "/home/EduAgent/miniconda3/envs/aeneas_env/bin/python",
                subtitle_script,
                str(out_dir),
                str(text_dir),
                str(subtitle_out),
            ]
            print("🎬 生成中文字幕...")
            result = subprocess.run(cmd, cwd=backend_dir, capture_output=True, text=True)
            if result.returncode == 0:
                print("✅ 字幕生成完成")
                final_output_path = subtitle_out
            else:
                print(f"⚠️ 字幕生成失败: {result.stderr.strip()}")

    print(f"完成：处理 {len(py_files)} 个代码文件，成功输出 {success_cnt} 个。")
    print(f"最终视频目录: {final_output_path}")


if __name__ == "__main__":
    main()
