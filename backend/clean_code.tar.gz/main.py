#!/usr/bin/env python3
"""
FastAPI Backend for ML Education Platform
Main entry point for the application
"""

import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from app.db.database import init_db

from app.api import health, auth, content, tokens, tcoin, feedback, admin
from app.core.config import settings
from app.core.exception_handler import global_exception_handler

from redis import asyncio as aioredis
from arq import create_pool
from arq.connections import RedisSettings


ARQ_REDIS_SETTINGS = RedisSettings(host='localhost', port=6379)

# Create FastAPI instance
app = FastAPI(
    title="eachMaster Platform API",
    description="Backend API for automated machine learning education content generation",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

app.add_exception_handler(Exception, global_exception_handler)
# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    print("正在初始化数据库...")
    await init_db()
    print("数据库初始化完成。")
    # 创建 ARQ 可用的 redis 池
    app.state.redis = await create_pool(ARQ_REDIS_SETTINGS)

@app.on_event("shutdown")
async def shutdown_event():
    if app.state.redis:
        await app.state.redis.close()

# 依赖项，用于在路由中获取 redis 池
# async def get_redis():
#     return app.state.redis

# Add request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    print(request.method)
    if request.method == "OPTIONS":
        # 返回允许的 HTTP 方法和其他相关头部信息
        headers =  {
            "allow": "*",
            "Access-Control-Allow-Origin":"*",
            "Access-Control-Allow-Methods": "*",
            "Access-Control-Allow-Headers": "*",
        }
        return JSONResponse(content=None,status_code=200,headers=headers)
    # 如果不是 OPTIONS 请求，则继续处理请求
    response = await call_next(request)
    return response

app.mount("/static", StaticFiles(directory="static"), name="static")

# Include routers
app.include_router(health.router, prefix="/api/v1", tags=["health"])
app.include_router(auth.router, prefix="/api/v1/auth", tags=["authentication"])
app.include_router(content.router, prefix="/api/v1/content", tags=["content"])
app.include_router(tokens.router, prefix="/api/v1/tokens", tags=["Token Management"])
app.include_router(tcoin.router, prefix="/api/v1/tcoin", tags=["T-Coin Wallet"])
app.include_router(feedback.router, prefix="/api/v1/feedback", tags=["Feedback"])
app.include_router(admin.router, prefix="/api/v1/admin", tags=["Admin Dashboard"])

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint returning API information"""
    return {
        "message": "ML Education Platform API",
        "version": "1.0.0",
        "docs": "/docs",
        "status": "running"
    }



if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.TESTING,
        log_level="info"
    )