#!/usr/bin/env python3
"""
Markdown切割器：将分页后的markdown文件按分页标记切割成独立文件
根据 <!-- PAGE_BREAK --> 标记将 *_paginated.md 文件切割成 *_1.md, *_2.md 等
"""

import argparse
import os
import glob
import re


class MarkdownSplitter:
    """Markdown文件切割器"""
    
    def __init__(self, verbose=False):
        self.verbose = verbose
        self.page_break_pattern = re.compile(r'<!--\s*PAGE_BREAK\s*-->', re.IGNORECASE)
        # 识别 Markdown 标题行（最多 3 个前置空格，支持 1–6 级，忽略行尾多余 #）
        self.heading_line_pattern = re.compile(r'^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$', re.UNICODE)

    # 提取文本中的所有标题 (level:int, title:str)
    def _extract_headings(self, text):
        headings = []
        for line in text.splitlines():
            m = self.heading_line_pattern.match(line)
            if m:
                level = len(m.group(1))
                title = m.group(2).strip()
                headings.append((level, title))
        return headings

    # 按 Markdown 层级规则更新“最近标题栈”
    def _update_heading_stack(self, stack, headings):
        cur = list(stack)
        for level, title in headings:
            # 确保长度足够
            if level - 1 >= len(cur):
                cur.extend([None] * (level - 1 - len(cur) + 1))
            cur[level - 1] = title
            # 更低级标题失效
            del cur[level:]
        return cur

    # 生成上下文区块（用标准 Markdown #、##… 展示）
    def _format_context_block(self, stack):
        # 仅保留非空级别
        lines = [f'{"#" * (i+1)} {t}' for i, t in enumerate(stack) if t]
        if not lines:
            return ""
        header = "该部分所处的上下文位置（从最高级到当前）："
        body = "\n".join(lines)
        return f"\n\n<!-- CONTEXT:BEGIN -->\n{header}\n{body}\n<!-- CONTEXT:END -->\n"
    
    def split_markdown_file(self, file_path, verbose=False):
        """
        切割单个markdown文件
        
        Args:
            file_path: _paginated.md文件路径
            verbose: 是否显示详细过程
        
        Returns:
            切割结果信息
        """
        try:
            # 读取文件内容
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if verbose:
                print(f"正在处理文件: {file_path}")
                print(f"文件大小: {len(content)} 字符")
            
            # 按分页标记分割内容
            pages = self.page_break_pattern.split(content)
            
            # 清理空白页面
            pages = [page.strip() for page in pages if page.strip()]
            
            if verbose:
                print(f"分割成 {len(pages)} 个页面")
            
            # 生成输出文件名前缀
            dir_name = os.path.dirname(file_path)
            base_name = os.path.basename(file_path)
            
            # 移除 _paginated.md 后缀
            if base_name.endswith('_paginated.md'):
                prefix = base_name[:-13]  # 移除 '_paginated.md'
            else:
                prefix = os.path.splitext(base_name)[0]
            
            # 保存分割后的文件（为每页追加上下文位置）
            saved_files = []
            heading_stack = []  # 最近标题链（按层级存放）
            for i, page_content in enumerate(pages, 1):
                output_filename = f"{prefix}_{i}.md"
                output_path = os.path.join(dir_name, output_filename)
                
                # 计算“仅包含上级”的上下文：
                # - 若本页包含标题，则取本页第一个标题的父链（不含该标题本身）
                # - 若本页不含标题，则取当前标题栈去掉最后一级（即最近标题的上级链）
                page_headings = self._extract_headings(page_content)
                if page_headings:
                    first_level = page_headings[0][0]
                    context_stack = heading_stack[:max(0, first_level-1)]
                else:
                    context_stack = heading_stack[:-1] if len(heading_stack) > 1 else []
                page_with_context = page_content + self._format_context_block(context_stack)

                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(page_with_context)
                
                saved_files.append(output_path)
                
                if verbose:
                    print(f"  页面 {i}: {output_path} ({len(page_with_context)} 字符)")
                
                # 用“本页内”的标题更新标题栈，供下一页使用
                heading_stack = self._update_heading_stack(heading_stack, page_headings)
            
            return {
                'original_file': file_path,
                'pages_count': len(pages),
                'saved_files': saved_files,
                'status': 'success'
            }
            
        except Exception as e:
            print(f"处理文件 {file_path} 时出错: {e}")
            return {
                'original_file': file_path,
                'pages_count': 0,
                'saved_files': [],
                'status': 'failed',
                'error': str(e)
            }
    
    def process_directory(self, directory_path, verbose=True):
        """
        处理目录中的所有 _paginated.md 文件
        
        Args:
            directory_path: 目录路径
            verbose: 是否显示详细过程
        
        Returns:
            处理结果统计
        """
        if not os.path.exists(directory_path):
            print(f"目录不存在: {directory_path}")
            return None
        
        # 查找所有 _paginated.md 文件
        pattern = os.path.join(directory_path, "*_paginated.md")
        paginated_files = glob.glob(pattern)
        
        if not paginated_files:
            print(f"在目录 {directory_path} 中未找到 *_paginated.md 文件")
            return None
        
        if verbose:
            print(f"找到 {len(paginated_files)} 个分页文件")
            print("="*50)
        
        results = {
            'total_files': len(paginated_files),
            'success_files': 0,
            'failed_files': 0,
            'total_pages': 0,
            'details': []
        }
        
        # 逐个处理文件
        for i, paginated_file in enumerate(sorted(paginated_files), 1):
            if verbose:
                print(f"\n[{i}/{len(paginated_files)}] 处理: {os.path.basename(paginated_file)}")
            
            # 切割文件
            result = self.split_markdown_file(paginated_file, verbose=verbose)
            results['details'].append(result)
            
            if result['status'] == 'success':
                results['success_files'] += 1
                results['total_pages'] += result['pages_count']
            else:
                results['failed_files'] += 1
        
        return results
    
    def print_summary(self, results):
        """打印处理结果摘要"""
        if not results:
            return
        
        print("\n" + "="*50)
        print("文件切割完成!")
        print(f"总计文件: {results['total_files']}")
        print(f"成功处理: {results['success_files']}")
        print(f"处理失败: {results['failed_files']}")
        print(f"生成页面: {results['total_pages']}")
        
        # 显示成功处理的文件详情
        success_details = [d for d in results['details'] if d['status'] == 'success']
        if success_details:
            print("\n成功处理的文件:")
            for detail in success_details:
                original_name = os.path.basename(detail['original_file'])
                print(f"  {original_name} -> {detail['pages_count']} 个页面")
                for saved_file in detail['saved_files']:
                    print(f"    {os.path.basename(saved_file)}")
        
        # 显示失败的文件
        failed_details = [d for d in results['details'] if d['status'] == 'failed']
        if failed_details:
            print("\n处理失败的文件:")
            for detail in failed_details:
                print(f"  {os.path.basename(detail['original_file'])}: {detail.get('error', '未知错误')}")
    
    def clean_split_files(self, directory_path, verbose=True):
        """
        清理之前切割产生的文件（可选功能）
        
        Args:
            directory_path: 目录路径
            verbose: 是否显示详细过程
        """
        # 查找所有 *_数字.md 格式的文件
        pattern = os.path.join(directory_path, "*_[0-9]*.md")
        split_files = glob.glob(pattern)
        
        if not split_files:
            if verbose:
                print("没有找到需要清理的切割文件")
            return
        
        if verbose:
            print(f"找到 {len(split_files)} 个切割文件，准备清理...")
        
        for file_path in split_files:
            try:
                os.remove(file_path)
                if verbose:
                    print(f"已删除: {os.path.basename(file_path)}")
            except Exception as e:
                print(f"删除文件 {file_path} 时出错: {e}")

    def pipeline(self, directory_path, clean=True, verbose=True):
        """
        简化的流水线接口
        
        Args:
            directory_path: 目录路径
            verbose: 是否显示详细过程
        
        Returns:
            处理结果统计
        """
        if clean:
            self.clean_split_files(directory_path, verbose=verbose)
        return self.process_directory(directory_path, verbose=verbose)


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="Markdown切割器 - 将分页文件按分页标记切割成独立页面",
        epilog="示例: python splitter.py scripts/KNN_5288_sections/"
    )
    parser.add_argument(
        "directory",
        help="包含 *_paginated.md 文件的目录路径"
    )
    parser.add_argument(
        "--clean",
        action="store_true",
        help="在处理前清理目录中已存在的切割文件"
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="静默模式，只显示结果摘要"
    )
    
    args = parser.parse_args()
    
    try:
        # 创建切割器
        splitter = MarkdownSplitter()
        
        # 清理旧文件（如果指定）
        if args.clean:
            splitter.clean_split_files(args.directory, verbose=not args.quiet)
        
        # 处理目录
        results = splitter.process_directory(args.directory, verbose=not args.quiet)
        
        # 显示结果摘要
        splitter.print_summary(results)
        
    except Exception as e:
        print(f"错误: {e}")
        print("\n请确保:")
        print("1. 目录路径正确")
        print("2. 目录中包含 *_paginated.md 文件")
        print("3. 有足够的文件读写权限")


if __name__ == "__main__":
    main()
