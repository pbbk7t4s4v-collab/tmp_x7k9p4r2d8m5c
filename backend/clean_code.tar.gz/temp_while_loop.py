count = 0
while count < 5:
    print("计数：", count)
    count += 1