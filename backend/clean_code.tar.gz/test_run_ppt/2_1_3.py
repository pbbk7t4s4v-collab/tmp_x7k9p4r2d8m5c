#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Manim Community v0.19.0
from manim import *
# 降低分辨率与帧率以避免渲染超时
config.pixel_width = 1280
config.pixel_height = 720
config.frame_rate = 30

class KNNProsConsScene(Scene):
    def construct(self):
# 1. Title Setup
        title = Text("K-Nearest Neighbors: Pros and Cons", 
                     font_size=34,
                     color=WHITE,
                     weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )
        self.wait(0.5)

        # 2. Create two columns for Pros and Cons
        # Pros Column
        pros_title = Text("Advantages", font_size=28, color=GREEN, weight=BOLD)
        pros_list = BulletedList(
            "Simple, intuitive, no explicit training",
            "Models complex non-linear relationships",
            "Effective on low-dimensional data",
            font_size=24,
            buff=0.3
        )
        pros_group = VGroup(pros_title, pros_list).arrange(DOWN, buff=0.4, aligned_edge=LEFT)

        # Cons Column
        cons_title = Text("Disadvantages", font_size=28, color=RED, weight=BOLD)
        cons_list = BulletedList(
            "Poor in high dimensions ('Curse of Dimensionality')",
            "High prediction cost (calculates all distances)",
            "Sensitive to K value and distance metric",
            font_size=24,
            buff=0.3
        )
        cons_group = VGroup(cons_title, cons_list).arrange(DOWN, buff=0.4, aligned_edge=LEFT)

        # 3. Arrange columns on screen
        columns = VGroup(pros_group, cons_group).arrange(RIGHT, buff=1.2, aligned_edge=UP)
        columns.next_to(title_group, DOWN, buff=0.6)

        # 4. Animate the content progressively
        self.play(FadeIn(pros_title, shift=DOWN*0.5))
        self.play(LaggedStart(*[Write(item) for item in pros_list], lag_ratio=0.5, run_time=2.5))
        self.wait(0.5)

        self.play(FadeIn(cons_title, shift=DOWN*0.5))
        self.play(LaggedStart(*[Write(item) for item in cons_list], lag_ratio=0.5, run_time=3.0))
        self.wait(1)

        # 5. Highlight key disadvantages using SurroundingRectangle
        highlight_curse = SurroundingRectangle(cons_list.submobjects[0], color=YELLOW, buff=0.1)
        highlight_cost = SurroundingRectangle(cons_list.submobjects[1], color=YELLOW, buff=0.1)

        self.play(Create(highlight_curse), run_time=1)
        self.play(Create(highlight_cost), run_time=1)

        self.wait(2)

        self.wait(11.28)
