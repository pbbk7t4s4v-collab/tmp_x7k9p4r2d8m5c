#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Manim Community v0.19.0

from manim import *
import random

class KNNRegressionScene(Scene):
    def construct(self):
# ---- Title Setup ----
        title = Text("K-Nearest Neighbors (KNN) Regression",
                     font_size=34,
                     color=WHITE,
                     weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)
        
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )
        self.wait(0.5)

        # ---- Create Data Points ----
        # A simple plane for visual reference, not a full coordinate system
        plane = NumberPlane(
            x_range=[-1, 7, 1], y_range=[-1, 5, 1],
            background_line_style={"stroke_opacity": 0.3}
        ).shift(RIGHT * 3)

        # Training data points
        train_points_coords = [
            [0, 1], [1, 2.5], [1.5, 0.5], [2, 3], [3, 1.5],
            [4, 4], [4.5, 2], [5, 3.5], [5.5, 1]
        ]
        train_dots = VGroup(*[Dot(plane.c2p(*coord), color=BLUE) for coord in train_points_coords])
        
        # Test point
        test_coord = [2.8, 2.5]
        test_dot = Star(color=RED, stroke_color=RED, fill_opacity=1).scale(0.2)
        test_dot.move_to(plane.c2p(*test_coord))
        test_label = MathTex("x", color=RED).next_to(test_dot, UP, buff=0.1)
        test_point = VGroup(test_dot, test_label)

        # ---- Animation: Core Idea ----
        core_idea_text = Text("Core Idea: Find K nearest neighbors", font_size=28).to_edge(LEFT, buff=0.5).shift(UP*1.5)
        self.play(Write(core_idea_text))
        self.play(FadeIn(train_dots), FadeIn(test_point, scale=1.5))
        self.wait(0.5)

        # Find K=3 nearest neighbors
        K = 3
        distances = [(np.linalg.norm(test_dot.get_center() - dot.get_center()), dot) for dot in train_dots]
        distances.sort(key=lambda x: x[0])
        neighbors = VGroup(*[d[1] for d in distances[:K]])
        
        # Visualize finding neighbors with a circle
        radius = distances[K-1][0]
        circle = Circle(radius=radius, color=YELLOW, stroke_width=2).move_to(test_dot.get_center())
        
        self.play(Create(circle))
        self.play(neighbors.animate.set_color(ORANGE), run_time=0.5)
        avg_formula_title = Text("1. Simple Average", font_size=24, weight=BOLD).next_to(core_idea_text, DOWN, buff=0.5, aligned_edge=LEFT)
        avg_formula = MathTex(
            r"\hat{y}(\mathbf{x}) = \frac{1}{K} \sum_{i \in \mathcal{N}_K(\mathbf{x})} y_i",
            font_size=36
        ).next_to(avg_formula_title, DOWN, buff=0.2, aligned_edge=LEFT)
        
        self.play(FadeIn(avg_formula_title, shift=DOWN))
        self.play(Write(avg_formula))
        
        avg_box = SurroundingRectangle(avg_formula, color=BLUE, buff=0.1)
        self.play(Create(avg_box))
        self.play(FadeOut(avg_box))
        weighted_formula_title = Text("2. Weighted Average (more common)", font_size=24, weight=BOLD).next_to(avg_formula, DOWN, buff=0.8, aligned_edge=LEFT)
        weighted_formula = MathTex(
            r"\hat{y}(\mathbf{x}) = \frac{\sum w_i y_i}{\sum w_i}, \quad w_i = \frac{1}{d(\mathbf{x}, \mathbf{x}_i)+\epsilon}",
            font_size=36
        ).next_to(weighted_formula_title, DOWN, buff=0.2, aligned_edge=LEFT)

        self.play(FadeIn(weighted_formula_title, shift=DOWN))
        self.play(Write(weighted_formula))
        
        weighted_box = SurroundingRectangle(weighted_formula, color=GREEN, buff=0.1)
        self.play(Create(weighted_box))

        # Show distance lines for weighted average concept
        distance_lines = VGroup(*[Line(test_dot.get_center(), n.get_center(), stroke_width=2, color=GRAY) for n in neighbors])
        self.play(Create(distance_lines), run_time=1)

        self.wait(1.0)

        self.wait(1.0)
