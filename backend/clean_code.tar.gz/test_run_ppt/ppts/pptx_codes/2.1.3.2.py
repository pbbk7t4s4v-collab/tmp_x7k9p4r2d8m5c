import math
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Cm
from pptx.oxml import parse_xml
from pptx.oxml.ns import nsdecls

# 定义颜色
C_WHITE = RGBColor(255, 255, 255)
C_YELLOW = RGBColor(255, 255, 0)
C_GREEN = RGBColor(0, 255, 0)
C_RED = RGBColor(255, 0, 0)

# 标题固定模板
title_y = 0.5
title_width = Inches(12)
left_position = (prs.slide_width - title_width) / 2

title_box = slide.shapes.add_textbox(left_position, Inches(title_y), title_width, Inches(1.0))
tf = title_box.text_frame
tf.word_wrap = False

p = tf.paragraphs[0]
p.text = "K-Nearest Neighbors: Pros and Cons"
p.font.size = Pt(32)
p.font.bold = True
p.font.color.rgb = C_WHITE
p.font.name = "KaiTi"
p.alignment = PP_ALIGN.CENTER

# 标题下划线
line_width_inch = 9.0
line_height = 0

line_left = (prs.slide_width - Inches(line_width_inch)) / 2
line_top = Inches(1.1)

line_shape = slide.shapes.add_shape(
    MSO_SHAPE.RECTANGLE,
    line_left,
    line_top,
    Inches(line_width_inch),
    Pt(3)
)
line_shape.fill.solid()
line_shape.fill.fore_color.rgb = C_YELLOW
line_shape.line.fill.background()

# Pros Column (左侧)
pros_title_x, pros_title_y = manim_to_ppt_coords(-3.5, 1.8)
pros_title_tb = add_centered_textbox(slide, "Advantages", pros_title_x, pros_title_y, Inches(3.5), Inches(0.6), word_wrap=False)
pros_title_p = pros_title_tb.text_frame.paragraphs[0]
pros_title_p.font.size = Pt(26)
pros_title_p.font.bold = True
pros_title_p.font.color.rgb = C_GREEN
pros_title_p.font.name = "KaiTi"
pros_title_p.alignment = PP_ALIGN.LEFT

# Pros list items
pros_items = [
    "• Simple, intuitive, no explicit training",
    "• Models complex non-linear relationships",
    "• Effective on low-dimensional data"
]

pros_y_start = 1.2
for i, item in enumerate(pros_items):
    item_x, item_y = manim_to_ppt_coords(-3.5, pros_y_start - i * 0.6)
    item_tb = add_centered_textbox(slide, item, item_x, item_y, Inches(4.5), Inches(0.8), word_wrap=True)
    item_p = item_tb.text_frame.paragraphs[0]
    item_p.font.size = Pt(20)
    item_p.font.color.rgb = C_WHITE
    item_p.font.name = "KaiTi"
    item_p.alignment = PP_ALIGN.LEFT

# Cons Column (右侧)
cons_title_x, cons_title_y = manim_to_ppt_coords(3.5, 1.8)
cons_title_tb = add_centered_textbox(slide, "Disadvantages", cons_title_x, cons_title_y, Inches(3.5), Inches(0.6), word_wrap=False)
cons_title_p = cons_title_tb.text_frame.paragraphs[0]
cons_title_p.font.size = Pt(26)
cons_title_p.font.bold = True
cons_title_p.font.color.rgb = C_RED
cons_title_p.font.name = "KaiTi"
cons_title_p.alignment = PP_ALIGN.LEFT

# Cons list items
cons_items = [
    "• Poor in high dimensions ('Curse of Dimensionality')",
    "• High prediction cost (calculates all distances)",
    "• Sensitive to K value and distance metric"
]

cons_y_start = 1.2
for i, item in enumerate(cons_items):
    item_x, item_y = manim_to_ppt_coords(3.5, cons_y_start - i * 0.6)
    item_tb = add_centered_textbox(slide, item, item_x, item_y, Inches(4.5), Inches(0.8), word_wrap=True)
    item_p = item_tb.text_frame.paragraphs[0]
    item_p.font.size = Pt(20)
    item_p.font.color.rgb = C_WHITE
    item_p.font.name = "KaiTi"
    item_p.alignment = PP_ALIGN.LEFT

# Highlight rectangles for key disadvantages (第一项和第二项)
# 第一项高亮框
highlight1_x, highlight1_y = manim_to_ppt_coords(3.5, 1.2)
highlight1 = add_centered_shape(slide, MSO_SHAPE.RECTANGLE, highlight1_x, highlight1_y, Inches(4.7), Inches(0.9))
highlight1.fill.background()
highlight1.line.color.rgb = C_YELLOW
highlight1.line.width = Pt(2)

# 第二项高亮框
highlight2_x, highlight2_y = manim_to_ppt_coords(3.5, 0.6)
highlight2 = add_centered_shape(slide, MSO_SHAPE.RECTANGLE, highlight2_x, highlight2_y, Inches(4.7), Inches(0.9))
highlight2.fill.background()
highlight2.line.color.rgb = C_YELLOW
highlight2.line.width = Pt(2)