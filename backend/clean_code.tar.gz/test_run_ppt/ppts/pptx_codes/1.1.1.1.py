import math
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Cm
from pptx.oxml import parse_xml
from pptx.oxml.ns import nsdecls

# 定义颜色
C_WHITE = RGBColor(255, 255, 255)
C_YELLOW = RGBColor(255, 255, 0)
C_BLUE = RGBColor(88, 166, 255)
C_RED = RGBColor(252, 84, 84)
C_ORANGE = RGBColor(252, 186, 3)
C_GREEN = RGBColor(131, 211, 124)
C_GRAY = RGBColor(150, 150, 150)

# ---- 标题固定模板 ----
title_y = 0.5
title_width = Inches(12)
left_position = (prs.slide_width - title_width) / 2

title_box = slide.shapes.add_textbox(left_position, Inches(title_y), title_width, Inches(1.0))
tf = title_box.text_frame
tf.word_wrap = False

p = tf.paragraphs[0]
p.text = "K-Nearest Neighbors (KNN) Regression"
p.font.size = Pt(30)
p.font.bold = True
p.font.color.rgb = C_WHITE
p.font.name = "KaiTi"
p.alignment = PP_ALIGN.CENTER

line_width_inch = 9.0
line_height = 0

line_left = (prs.slide_width - Inches(line_width_inch)) / 2
line_top = Inches(1.1)

line_shape = slide.shapes.add_shape(
    MSO_SHAPE.RECTANGLE,
    line_left,
    line_top,
    Inches(line_width_inch),
    Pt(3)
)

line = line_shape.line
line.color.rgb = C_YELLOW
line.width = Pt(3)
line_shape.fill.background()

# ---- Core Idea 文本 ----
core_x, core_y = manim_to_ppt_coords(-3.5, 2.0)
core_tb = add_centered_textbox(slide, "Core Idea: Find K nearest neighbors", core_x, core_y, Inches(4.5), Inches(0.6), word_wrap=True)
core_p = core_tb.text_frame.paragraphs[0]
core_p.font.size = Pt(24)
core_p.font.color.rgb = C_WHITE
core_p.font.name = "KaiTi"
core_p.alignment = PP_ALIGN.LEFT

# ---- 绘制训练数据点 (蓝色圆点) ----
# 在 Manim 场景中，plane 向右偏移 3 个单位 (RIGHT * 3)
# 训练点的 Manim 坐标需要加上这个偏移
plane_shift_x = 3.0
train_points_coords = [
    [0, 1], [1, 2.5], [1.5, 0.5], [2, 3], [3, 1.5],
    [4, 4], [4.5, 2], [5, 3.5], [5.5, 1]
]

for coord in train_points_coords:
    manim_x = coord[0] + plane_shift_x
    manim_y = coord[1]
    dot_x, dot_y = manim_to_ppt_coords(manim_x, manim_y)
    dot = add_centered_shape(slide, MSO_SHAPE.OVAL, dot_x, dot_y, Inches(0.12), Inches(0.12))
    dot.fill.solid()
    dot.fill.fore_color.rgb = C_BLUE
    dot.line.color.rgb = C_BLUE

# ---- 绘制测试点 (红色星形) ----
test_coord = [2.8, 2.5]
test_manim_x = test_coord[0] + plane_shift_x
test_manim_y = test_coord[1]
test_x, test_y = manim_to_ppt_coords(test_manim_x, test_manim_y)

# 使用五角星代替星形
star = add_centered_shape(slide, MSO_SHAPE.STAR_5, test_x, test_y, Inches(0.25), Inches(0.25))
star.fill.solid()
star.fill.fore_color.rgb = C_RED
star.line.color.rgb = C_RED

# 测试点标签 "x"
test_label_tb = add_centered_textbox(slide, "x", test_x, test_y - Inches(0.25), Inches(0.3), Inches(0.25), word_wrap=False)
test_label_p = test_label_tb.text_frame.paragraphs[0]
test_label_p.font.size = Pt(18)
test_label_p.font.color.rgb = C_RED
test_label_p.font.name = "KaiTi"
test_label_p.alignment = PP_ALIGN.CENTER

# ---- 绘制黄色圆圈 (表示 K=3 邻域范围) ----
# 计算 K=3 最近邻的距离（这里简化，使用近似半径）
# 在 PPT 中，我们用一个圆来表示
circle_radius_inches = Inches(1.2)  # 根据视觉效果调整
circle = add_centered_shape(slide, MSO_SHAPE.OVAL, test_x, test_y, circle_radius_inches * 2, circle_radius_inches * 2)
circle.fill.background()
circle.line.color.rgb = C_YELLOW
circle.line.width = Pt(2)

# ---- 标记 K=3 个最近邻为橙色 ----
# 根据距离排序，找到最近的 3 个点
import math

def distance(x1, y1, x2, y2):
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

distances = []
for coord in train_points_coords:
    manim_x = coord[0] + plane_shift_x
    manim_y = coord[1]
    dot_x_ppt, dot_y_ppt = manim_to_ppt_coords(manim_x, manim_y)
    dist = distance(test_x.inches, test_y.inches, dot_x_ppt.inches, dot_y_ppt.inches)
    distances.append((dist, coord))

distances.sort(key=lambda x: x[0])
neighbors_coords = [d[1] for d in distances[:3]]

for coord in neighbors_coords:
    manim_x = coord[0] + plane_shift_x
    manim_y = coord[1]
    dot_x, dot_y = manim_to_ppt_coords(manim_x, manim_y)
    dot = add_centered_shape(slide, MSO_SHAPE.OVAL, dot_x, dot_y, Inches(0.12), Inches(0.12))
    dot.fill.solid()
    dot.fill.fore_color.rgb = C_ORANGE
    dot.line.color.rgb = C_ORANGE

# ---- 绘制距离线 (灰色) ----
for coord in neighbors_coords:
    manim_x = coord[0] + plane_shift_x
    manim_y = coord[1]
    neighbor_x, neighbor_y = manim_to_ppt_coords(manim_x, manim_y)
    
    connector = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, test_x, test_y, neighbor_x, neighbor_y)
    line = connector.line
    line.fill.solid()
    line.fill.fore_color.rgb = C_GRAY
    line.width = Pt(1.5)

# ---- 公式 1: Simple Average ----
avg_title_x, avg_title_y = manim_to_ppt_coords(-3.5, 0.8)
avg_title_tb = add_centered_textbox(slide, "1. Simple Average", avg_title_x, avg_title_y, Inches(4.0), Inches(0.5), word_wrap=True)
avg_title_p = avg_title_tb.text_frame.paragraphs[0]
avg_title_p.font.size = Pt(22)
avg_title_p.font.bold = True
avg_title_p.font.color.rgb = C_WHITE
avg_title_p.font.name = "KaiTi"
avg_title_p.alignment = PP_ALIGN.LEFT

avg_formula_x, avg_formula_y = manim_to_ppt_coords(-3.5, 0.2)
avg_formula_tb = add_centered_textbox(slide, "ŷ(x) = (1/K) Σ yᵢ", avg_formula_x, avg_formula_y, Inches(4.5), Inches(0.5), word_wrap=True)
avg_formula_p = avg_formula_tb.text_frame.paragraphs[0]
avg_formula_p.font.size = Pt(20)
avg_formula_p.font.color.rgb = C_WHITE
avg_formula_p.font.name = "KaiTi"
avg_formula_p.alignment = PP_ALIGN.LEFT

# 蓝色框（围绕公式1）
avg_box_x, avg_box_y = manim_to_ppt_coords(-3.5, 0.2)
avg_box = add_centered_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, avg_box_x, avg_box_y, Inches(3.5), Inches(0.6))
avg_box.fill.background()
avg_box.line.color.rgb = C_BLUE
avg_box.line.width = Pt(2)

# ---- 公式 2: Weighted Average ----
weighted_title_x, weighted_title_y = manim_to_ppt_coords(-3.5, -0.8)
weighted_title_tb = add_centered_textbox(slide, "2. Weighted Average (more common)", weighted_title_x, weighted_title_y, Inches(5.0), Inches(0.5), word_wrap=True)
weighted_title_p = weighted_title_tb.text_frame.paragraphs[0]
weighted_title_p.font.size = Pt(22)
weighted_title_p.font.bold = True
weighted_title_p.font.color.rgb = C_WHITE
weighted_title_p.font.name = "KaiTi"
weighted_title_p.alignment = PP_ALIGN.LEFT

weighted_formula_x, weighted_formula_y = manim_to_ppt_coords(-3.5, -1.5)
weighted_formula_tb = add_centered_textbox(slide, "ŷ(x) = Σ wᵢyᵢ / Σ wᵢ,  wᵢ = 1/(d(x,xᵢ)+ε)", weighted_formula_x, weighted_formula_y, Inches(6.0), Inches(0.6), word_wrap=True)
weighted_formula_p = weighted_formula_tb.text_frame.paragraphs[0]
weighted_formula_p.font.size = Pt(18)
weighted_formula_p.font.color.rgb = C_WHITE
weighted_formula_p.font.name = "KaiTi"
weighted_formula_p.alignment = PP_ALIGN.LEFT

# 绿色框（围绕公式2）
weighted_box_x, weighted_box_y = manim_to_ppt_coords(-3.5, -1.5)
weighted_box = add_centered_shape(slide, MSO_SHAPE.ROUNDED_RECTANGLE, weighted_box_x, weighted_box_y, Inches(5.5), Inches(0.7))
weighted_box.fill.background()
weighted_box.line.color.rgb = C_GREEN
weighted_box.line.width = Pt(2)