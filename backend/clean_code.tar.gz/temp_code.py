def say_hello(user_name):
    """打印简单的问候语"""
    message = "Hello " + user_name
    print(message)