"""
ML教育内容生成服务
"""

import asyncio
import os
import subprocess
import sys
import re
import uuid
import glob
import json
import time
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any
from app.models.schemas import GenerationRequest, JobStatus, ContentResponse
import shutil
import whisper
from app.services.token_service import token_service
import logging
import json

# 添加脚本路径以便导入ML模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
# 添加backend根目录路径
backend_root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')
sys.path.append(backend_root)
enable_subtitles=True
language_now = 'zh' 

# 导入ML生成器
try:
    from script_generator import ScriptGenerator
    from generate_manim_codes import ManimCodeGenerator
    from script_splitter import ScriptSplitter
    from paginator import Paginator
    from manim_breakpoint_inserter import ManimBreakpointInserter
    from manim_auto_wait_generator import ManimAutoWaitGenerator
    from manim_auto_wait_generator_en import ManimAutoWaitGenerator_en
    from generate_speech_scripts import SpeechScriptGenerator
    from splitter import MarkdownSplitter
    from outline_content_generator import OutlineContentGenerator
except ImportError as e:
    print(f"Warning: Could not import generator: {e}")

# 单独导入封面渲染模块
MergedLayoutScene2 = None
EndingScene = None
try:
    # 导入封面渲染模块
    from manim import config
    from Demo import MergedLayoutScene2
    from EndingDemo import EndingScene
    from Demo_cn import MergedLayoutScene2_cn
    from EndingDemo_cn import EndingScene_cn
    print("Successfully imported cover rendering modules")
except ImportError as e:
    print(f"Warning: Could not import cover rendering modules: {e}")
    print("Cover and ending generation will be disabled")

DEFAULT_BACKGROUND_IMAGE = "/home/EduPal_v2/jiezhang/web-app/backend/background_default.png"


class MLFullContentService:
    """机器学习教育内容生成服务"""
    
    def __init__(self):
        # In-memory storage for demo - replace with database in production
        self.jobs: Dict[str, JobStatus] = {}
        self.content: Dict[int, ContentResponse] = {}
        self.content_counter = 1
        
        self.script_generator = None
        self.scriptSplitter = None
        self.paginator = None
        self.markdownSplitter = None
        self.manimcode_generator = None
        self.speechScriptGenerator = None
        self.manimBreakpointInserter = None
        self.manimAutoWaitGenerator = None

        # 基础开销时间（秒），用于每个步骤的启动开销
        self.BASE_OVERHEAD_TIME = 5

        # 单位工作量耗时（秒）
        self.TIME_PER_CHAR_PREPROCESS_KW = 0.5        # [关键词模式]预处理。原值: 0.5,   测量值: 0.1343
        self.TIME_PER_CHAR_PREPROCESS_MD = 0.02       # [MD模式]预处理。   原值: 0.02,  测量值: 0.0004
        self.TIME_PER_FILE_SPLIT = 7                  # 脚本分割。         原值: 2,     测量值: 8.0911
        self.TIME_PER_FILE_PAGINATE = 0.01            # 分页处理。         原值: 5,     测量值: 0.0007
        self.TIME_PER_FILE_MD_SPLIT = 0.01            # Markdown分割。     原值: 1,     测量值: 0.0004
        self.TIME_PER_FILE_MANIM_CODE = 10            # 生成Manim代码。    原值: 20,    测量值: 63.0382
        self.TIME_PER_FILE_SPEECH_SCRIPT = 20         # 生成语音脚本。     原值: 8,     测量值: 141.7979
        self.TIME_PER_CHAR_AUDIO = 0.05              # 生成语音音频。     原值: 0.06,  测量值: 0.0700 (根据测量总时间213.3s / 总字符3047估算)
        self.TIME_PER_FILE_BREAKPOINT = 15            # 插入断点。         原值: 6,     测量值: 81.1560
        self.TIME_PER_FILE_AUTOWAIT = 0.01            # 自动等待时间。     原值: 4,     测量值: 0.0041
        self.TIME_PER_FILE_ALIGN = 0.2                # 音视频对齐。       原值: 3,     测量值: 0.1343
        self.TIME_PER_FILE_ADD_BG = 0.01              # 添加背景。         原值: 1,     测量值: 0.0039
        self.TIME_PER_VIDEO_RENDER = 60               # 渲染视频。         原值: 45,    测量值: 252.6682
        self.TIME_PER_VIDEO_MERGE_INDIVIDUAL = 0.05   # 合并单个音视频。   原值: 5,     测量值: 0.0059
        self.TIME_PER_VIDEO_CONCAT = 5              # 拼接多个视频。     原值: 2,     测量值: 25.6443
        self.TIME_FOR_COVER = 140                     # 封面生成固定耗时。 原值: 45,    测量值: 121.4141


        # 初始化ML生成器（如果可用）
        if 'ScriptGenerator' in globals():
            try:
                # 配置文件在backend根目录下
                config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'config.json')
                self.script_generator = ScriptGenerator(config_path=config_path)
                self.manimcode_generator = ManimCodeGenerator(config_path=config_path)
                self.scriptSplitter = ScriptSplitter()
                self.paginator = Paginator(config_path=config_path)
                self.markdownSplitter = MarkdownSplitter()
                self.manimBreakpointInserter = ManimBreakpointInserter(config_path=config_path)
                if language_now == 'zh':
                    self.manimAutoWaitGenerator = ManimAutoWaitGenerator()
                else:
                    self.manimAutoWaitGenerator = ManimAutoWaitGenerator_en()
                self.speechScriptGenerator = SpeechScriptGenerator(config_path=config_path)
                print("ML Content Generator initialized successfully")
            except Exception as e:
                print(f"Warning: Failed to initialize ML generator: {e}")
                self.script_generator = None
                self.scriptSplitter = None
                self.paginator = None
                self.markdownSplitter = None
                self.manimcode_generator = None
                self.speechScriptGenerator = None
                self.manimBreakpointInserter = None
                self.manimAutoWaitGenerator = None
        else:
            print("Warning: ScriptGenerator not available, using mock generation")

    # 日志记录
    def _setup_job_logger(self, job_id: str, log_dir: str) -> logging.Logger:
        """为指定的Job设置一个专用的日志记录器"""
        self.ensure_directory_exists(log_dir)
        log_file_path = os.path.join(log_dir, "generation_log.jsonl")
        
        logger = logging.getLogger(f"job_{job_id}")
        logger.setLevel(logging.INFO)
        
        # 防止重复添加handler
        if not logger.handlers:
            # 使用FileHandler将日志写入文件
            fh = logging.FileHandler(log_file_path, encoding='utf-8')
            fh.setLevel(logging.INFO)
            
            # 定义日志格式
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            fh.setFormatter(formatter)
            
            # 为logger添加handler
            logger.addHandler(fh)
            
        return logger
    
    def preprocess_keywords(self, keywords: str, request_output_dir: str, verbose: bool = False) -> str:
        """
        预处理关键词
        
        参数:
            keywords (str): 关键词
            request_output_dir (str): 请求输出目录
            verbose (bool, 可选): 是否输出详细信息. 默认是 False
        返回:
            脚本文件路径
        """
        # script_generator = ScriptGenerator(config_path="config.json")
        output_dir = os.path.join(request_output_dir, "scripts", "full")
        os.makedirs(output_dir, exist_ok=True)
        script_file_path = self.script_generator.pipeline(keywords, output_dir=output_dir)
        return script_file_path
    
    def ensure_directory_exists(self, directory: str) -> None:
        """确保目录存在，如果不存在则创建"""
        os.makedirs(directory, exist_ok=True)


    
    def run_subprocess_command(self, command: list, logger: logging.Logger, description: str = "", verbose: bool = True) -> bool:
        """
        运行子进程命令，提供更好的错误处理和日志
        
        参数:
            command: 命令列表
            logger: 用于记录日志的logger实例
            description: 命令描述
            verbose: 是否输出详细信息
        
        返回:
            是否成功执行
        """
        log_prefix = f"[{description}]" if description else "[Subprocess]"
        
        # 记录将要执行的命令
        logger.info(json.dumps({
            "event": "subprocess_start",
            "description": description,
            "command": ' '.join(command)
        }))

        if verbose and description:
            print(f"正在执行: {description}")
        
        try:
            result = subprocess.run(command, capture_output=True, text=True, check=False, encoding='utf-8')
            
            log_output = {
                "event": "subprocess_result",
                "description": description,
                "command": ' '.join(command),
                "return_code": result.returncode,
                "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip()
            }

            if result.returncode != 0:
                if verbose:
                    print(f"命令执行失败: {description}")
                    print(f"返回码: {result.returncode}")
                    if result.stdout: print(f"标准输出: {result.stdout}")
                    if result.stderr: print(f"标准错误: {result.stderr}")
                
                logger.error(json.dumps(log_output, ensure_ascii=False))
                return False
            
            if verbose and result.stdout:
                print(f"命令输出: {result.stdout}")
                
            logger.info(json.dumps(log_output, ensure_ascii=False))
            return True
            
        except Exception as e:
            if verbose:
                print(f"执行命令时发生异常: {description}")
                print(f"错误信息: {str(e)}")
            
            # 使用 logger.exception 记录异常信息（包含堆栈追踪）
            logger.exception(json.dumps({
                "event": "subprocess_exception",
                "description": description,
                "command": ' '.join(command),
                "error": str(e)
            }))
            return False

    def is_color(self, value: str) -> bool:
        return value.startswith("#") or value.isupper()

    def copy_image_to_target_dir(self, image_path: str, target_dir: str) -> str:
        """
        将图片文件拷贝到目标目录中
        
        Args:
            image_path (str): 原始图片路径
            target_dir (str): 目标目录
        
        Returns:
            str: 拷贝后的文件名（不含路径）
        """
        if not os.path.exists(image_path):
            print(f"警告：图片文件不存在: {image_path}")
            return os.path.basename(image_path)  # 返回文件名，让用户自己处理
        
        # 获取文件名
        image_filename = os.path.basename(image_path)
        target_path = os.path.join(target_dir, image_filename)
        
        try:
            # 如果目标文件已存在且内容相同，跳过拷贝
            if os.path.exists(target_path):
                if os.path.getsize(image_path) == os.path.getsize(target_path):
                    print(f"图片已存在，跳过拷贝: {image_filename}")
                    return image_filename
            
            # 拷贝文件
            shutil.copy2(image_path, target_path)
            print(f"图片拷贝成功: {image_path} -> {target_path}")
            return image_filename
        
        except Exception as e:
            print(f"拷贝图片失败: {str(e)}")
            return os.path.basename(image_path)

        
    def build_background_code(self, bg_input: str, image_filename: str = None) -> str:
        if self.is_color(bg_input):
            if bg_input.startswith("#"):
                return f'self.camera.background_color = Color("{bg_input}")  # 自定义颜色\n'
            else:
                return f'self.camera.background_color = {bg_input}  # 内置颜色\n'
        else:
            # 如果是图片，使用拷贝后的文件名，并确保使用绝对路径
            img_name = image_filename if image_filename else bg_input
            
            # 如果不是绝对路径，则构建绝对路径
            if not os.path.isabs(img_name):
                # 尝试多个可能的位置
                backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                possible_img_paths = [
                    os.path.join(backend_dir, img_name),  # backend/目录
                    os.path.join(os.path.dirname(backend_dir), img_name),  # 项目根目录
                    img_name  # 如果都不存在，保持原名
                ]
                
                for possible_path in possible_img_paths:
                    if os.path.exists(possible_path):
                        img_name = possible_path
                        break
                else:
                    print(f"⚠️ 找不到背景图片，尝试的路径: {possible_img_paths}")
                    print(f"⚠️ 使用原始路径: {img_name}")
            
            return (
                "###BACKGROUND###\n"
                f'bg = ImageMobject("{img_name}")\n'
                f'bg.scale_to_fit_height(config.frame_height)\n'
                f'bg.scale_to_fit_width(config.frame_width)\n'
                f'bg.set_opacity(0.9)\n'
                f'bg.move_to(ORIGIN)\n'
                f'self.add(bg)\n'
                "###BACKGROUND###\n"
            )


    def remove_existing_background(self, file_path: str):
        """
        删除文件中已有的背景代码(通过###BACKGROUND###标记识别)
        
        Args:
            file_path (str): 文件路径
        """
        with open(file_path, "r") as f:
            lines = f.readlines()
        
        new_lines = []
        in_bg_code = False
        
        for line in lines:
            
            # 检测背景代码开始标记
            if "###BACKGROUND###" in line and not in_bg_code:
                in_bg_code = True
                continue

            # 跳过背景代码块中的行
            if in_bg_code:
                if "###BACKGROUND###" in line:
                    in_bg_code = False
                continue
            print(line)
            new_lines.append(line)

        with open(file_path, "w") as f:
            f.writelines(new_lines)


    def insert_background_code(self, file_path: str, bg_code: str):
        self.remove_existing_background(file_path)
        with open(file_path, "r") as f:
            lines = f.readlines()

        new_lines = []
        inserted = False
        for line in lines:
            new_lines.append(line)
            if not inserted and re.match(r"\s*def construct\(self\):", line):
                indent = re.match(r"(\s*)", line).group(1) + "    "  # 四空格缩进
                bg_code_indented = "".join(indent + line for line in bg_code.splitlines(True))
                new_lines.append(bg_code_indented)
                inserted = True

        if inserted:
            with open(file_path, "w") as f:
                f.writelines(new_lines)
            print(f"插入成功: {file_path}")
        else:
            print(f"未找到 construct(self): 跳过: {file_path}")
    def add_background(self, target_dir: str, bg_input: str, logger: logging.Logger):
        """
        为目标目录中的所有Manim代码文件添加背景

        Args:
            target_dir (str): Manim代码文件夹路径
            bg_input (str): 背景图路径或颜色值
        """
        # 检查目标目录是否存在
        if not os.path.exists(target_dir):
            print(f"错误：目标目录不存在: {target_dir}")
            logger.error(json.dumps({"event": "step_error", "step": "add_background", "error": error_msg}))
            return
        image_filename = None
        # 如果是图片文件，先拷贝到目标目录
        if not self.is_color(bg_input):
            image_filename = self.copy_image_to_target_dir(bg_input, target_dir)
        # 生成背景代码
        bg_code = self.build_background_code(bg_input, image_filename)
        # 处理所有Python文件
        python_files = [f for f in os.listdir(target_dir) if f.endswith(".py")]
        if not python_files:    
            warn_msg = f"警告：在目录 {target_dir} 中没有找到Python文件"
            logger.warning(json.dumps({"event": "step_warning", "step": "add_background", "message": warn_msg}))
            return
        print(f"找到 {len(python_files)} 个Python文件，开始处理...")
        logger.info(json.dumps({
            "event": "background_addition_details",
            "bg_input": bg_input,
            "target_dir": target_dir,
            "file_count": len(python_files)
        }))
        success_count = 0
        failed_files = []
        for filename in python_files:
            file_path = os.path.join(target_dir, filename)
            try:
                self.insert_background_code(file_path, bg_code)
                success_count += 1
            except Exception as e:
                error_msg = f"处理文件失败 {filename}: {str(e)}"
                print(error_msg)
                logger.warning(json.dumps({
                    "event": "background_addition_file_error",
                    "file": filename,
                    "error": str(e)
                }))
                failed_files.append(filename)
                print(f"处理文件失败 {filename}: {str(e)}")

        summary_log = {
            "event": "background_addition_summary",
            "success_count": success_count,
            "total_files": len(python_files)
        }
        if failed_files:
            summary_log["failed_files"] = failed_files
        logger.info(json.dumps(summary_log))
        print(f"\n处理完成！成功处理 {success_count}/{len(python_files)} 个文件")
    

    def render_cover_and_ending(self, course_title: str, professor_name: str = "Prof. Siheng Chen", 
                               avatar_image: str = "csh.png", background_image: str = "SAI.png", 
                               output_dir: str = None, quality: str = "high",
                               reference_audio: str = None, reference_text: str = None, logger: logging.Logger=None) -> Dict[str, str]:
        """
        渲染课程封面和尾页视频
        
        Args:
            course_title: 课程标题
            professor_name: 教授姓名
            avatar_image: 头像图片路径
            background_image: 背景图片路径
            output_dir: 输出目录
            quality: 渲染质量
            reference_audio: 参考音频文件路径
            reference_text: 参考文本文件路径
            
        Returns:
            包含封面和尾页文件路径的字典
        """
        # 检查封面渲染模块是否可用

        if language_now == 'zh':
        # 如果是中文，则使用中文的渲染模块
            MergedLayoutScene = MergedLayoutScene2_cn
            EndingScene = EndingScene_cn
        else:
        # 默认使用英文的渲染模块
            MergedLayoutScene = MergedLayoutScene2
            EndingScene = EndingScene

        if MergedLayoutScene2 is None or EndingScene is None:
            print("❌ 封面渲染模块不可用，跳过封面和尾页生成")
            return {}
            
        if not output_dir:
            output_dir = "./output"
        
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # 设置质量参数
        quality_map = {
            "low": "low_quality",
            "medium": "medium_quality", 
            "high": "high_quality"
        }
        
        if quality not in quality_map:
            print(f"警告: 质量等级 '{quality}' 无效，使用默认高质量")
            quality = "high"
        
        print(f"开始渲染课程视频...")
        print(f"课程标题: {course_title}")
        print(f"教授姓名: {professor_name}")
        print(f"头像图片: {avatar_image}")
        print(f"背景图片: {background_image}")
        print(f"渲染质量: {quality}")
        
        results = {}
        
        try:
            # 渲染封面视频
            print("🎬 渲染封面视频...")
            cover_output = output_path / "cover.mp4"
            cover_file = self._render_single_video(
                scene_class=MergedLayoutScene2,
                title=course_title, avatar_image=avatar_image, professor_name=professor_name,
                background_image=background_image, output_path=str(cover_output), quality=quality,
                reference_audio=reference_audio, reference_text=reference_text,
                logger=logger
            )
            if cover_file:
                results['cover'] = str(cover_file)
                print(f"📹 封面视频: {cover_file}")
            
            # 渲染尾页视频
            print("🎬 渲染尾页视频...")
            ending_output = output_path / "ending.mp4"
            ending_file = self._render_single_video(
                scene_class=EndingScene,
                title=course_title, avatar_image=avatar_image, professor_name=professor_name,
                background_image=background_image, output_path=str(ending_output), quality=quality,
                reference_audio=reference_audio, reference_text=reference_text,
                logger=logger
            )
            if ending_file:
                results['ending'] = str(ending_file)
                print(f"📹 尾页视频: {ending_file}")
            
            print(f"✅ 封面和尾页渲染完成!")
            
        except Exception as e:
            print(f"❌ 封面/尾页渲染失败: {e}")
            import traceback
            traceback.print_exc()
        
        return results

    def _render_single_video(self, scene_class, title: str, avatar_image: str, professor_name: str, 
                            background_image: str, output_path: str, quality: str, 
                            reference_audio: str = None, reference_text: str = None, logger: logging.Logger=None) -> Optional[str]:
        """渲染单个视频文件"""
        try:
            # 设置质量参数
            quality_map = {
                "low": "low_quality",
                "medium": "medium_quality", 
                "high": "high_quality"
            }
            
            # 设置输出路径
            output_path_obj = Path(output_path).resolve()
            
            # 判断是文件路径还是目录路径
            if output_path.endswith('.mp4') or '.' in output_path_obj.name:
                # 包含文件名
                output_dir = output_path_obj.parent
                output_filename = output_path_obj.stem  # 不含扩展名
                print(f"输出目录: {output_dir}")
                print(f"文件名: {output_filename}.mp4")
            else:
                # 只是目录路径
                output_dir = output_path_obj
                output_filename = None
                print(f"输出目录: {output_dir}")
            
            # 创建输出目录
            output_dir.mkdir(parents=True, exist_ok=True)
            config.media_dir = str(output_dir)
            
            # 设置渲染参数
            config.quality = quality_map[quality]
            config.preview = True
            
            # 如果指定了文件名，设置场景名称
            if output_filename:
                config.scene_names = [output_filename]
            
            # 创建场景并渲染
            scene = scene_class(class_title_text=title, avatar_image=avatar_image, 
                               professor_name=professor_name, background_image=background_image)
            scene.render()
            
            # 查找并重命名输出文件
            final_output_file = None
            if output_dir:
                # 查找生成的视频文件，优先查找质量目录
                video_dir = output_dir / "videos" / f"{config.quality}"
                if not video_dir.exists():
                    # 如果质量目录不存在，查找所有可能的视频目录
                    video_dirs = list(output_dir.glob("videos/*/"))
                    if video_dirs:
                        for vdir in video_dirs:
                            if vdir.is_dir():
                                video_files = list(vdir.glob("*.mp4"))
                                if video_files:
                                    video_dir = vdir
                                    break
                
                if video_dir and video_dir.exists():
                    video_files = list(video_dir.glob("*.mp4"))
                    if video_files and output_filename:
                        # 重命名文件为指定名称
                        original_file = video_files[0]
                        new_file = output_dir / f"{output_filename}.mp4"
                        if original_file != new_file:
                            original_file.rename(new_file)
                            final_output_file = new_file
                        else:
                            final_output_file = original_file
                    elif video_files:
                        final_output_file = video_files[0]
                        
                # 生成对应的txt文件和语音
                if output_filename and final_output_file:
                    txt_file = output_dir / f"{output_filename}.txt"
                    scene_type = "封面" if scene_class == MergedLayoutScene2 else "尾页"
                    if scene_class == MergedLayoutScene2:
                        txt_content = f"大家好！欢迎大家聆听本学期的机器学习课程，我是授课老师{professor_name}，今天让我们一起走进{title}吧。"
                    else:
                        txt_content = f"感谢大家聆听本次{title}课程，希望大家都有所收获！我是授课老师{professor_name}，期待与大家下次课程再见。"
                    
                    # 保存文本文件
                    with open(txt_file, 'w', encoding='utf-8') as f:
                        f.write(txt_content)
                    print(f"📝 {scene_type}文本文件: {txt_file}")
                    
                    # 生成对应的语音文件
                    try:
                        audio_file = self._generate_cover_audio(txt_content, output_dir, output_filename, reference_audio, reference_text, logger=logger)
                        if audio_file:
                            print(f"🎵 {scene_type}语音文件: {audio_file}")
                            
                            # 进行音视频合并
                            merged_file = self._merge_cover_audio_video(
                                str(final_output_file), 
                                audio_file, 
                                output_dir, 
                                output_filename,
                                logger=logger
                            )
                            if merged_file:
                                print(f"🎬 {scene_type}合并文件: {merged_file}")
                                # 更新最终输出文件为合并后的文件
                                final_output_file = Path(merged_file)
                        
                    except Exception as e:
                        print(f"⚠️ {scene_type}语音生成失败: {e}")
                        # 继续执行，不中断视频渲染流程
            
            return str(final_output_file) if final_output_file else None
            
        except Exception as e:
            print(f"渲染单个视频失败: {e}")
            import traceback
            traceback.print_exc()
            return None

    def _generate_cover_audio(self, text_content: str, output_dir: Path, filename: str, 
                             reference_audio: str = None, reference_text: str = None, logger: logging.Logger=None) -> Optional[str]:
        """为封面/尾页文本生成语音文件"""
        try:
            # 创建临时文本输入目录
            temp_input_dir = output_dir / f"{filename}_input"
            temp_input_dir.mkdir(exist_ok=True)
            
            # 创建临时文本文件
            temp_text_file = temp_input_dir / f"{filename}.txt"
            with open(temp_text_file, 'w', encoding='utf-8') as f:
                f.write(text_content)
            
            # 创建临时输出目录
            temp_output_dir = output_dir / f"{filename}_output"
            temp_output_dir.mkdir(exist_ok=True)
            
            # 获取参考音频和文本路径
            DEFAULT_WAV_PATH = "/home/EduPal_v2/junhaoge/EduPal_v2/ML/UploadFiles/source/Prof_Chen.wav"
            DEFAULT_WAV_PROMPT_PATH = "/home/EduPal_v2/junhaoge/EduPal_v2/ML/UploadFiles/source/Prof_Chen.txt"
            
            wav_path = reference_audio or DEFAULT_WAV_PATH
            wav_prompt_path = reference_text or DEFAULT_WAV_PROMPT_PATH
            
            # 读取参考文本
            prompt_txt = ""
            if os.path.exists(wav_prompt_path):
                with open(wav_prompt_path, 'r', encoding='utf-8') as f:
                    prompt_txt = f.read().strip()
            
            # 调用 CosyVoice 生成音频文件
            cosyvoice_command = [
                "/home/EduAgent/miniconda3/envs/cosyvoice/bin/python",
                "/home/EduAgent/services/cosyvoice/run_cosyvoice_dynamic.py",
                str(temp_input_dir),
                str(temp_output_dir),
                "--prompt_wav", wav_path,
                "--prompt_text", prompt_txt,
            ]
            
            success = self.run_subprocess_command(command=cosyvoice_command, description=f"生成{filename}语音", logger=logger)
            
            # 查找生成的音频文件
            audio_file = None
            if success and temp_output_dir.exists():
                audio_files = list(temp_output_dir.glob("*.wav"))
                if audio_files:
                    # 将音频文件移动到目标位置
                    target_audio_file = output_dir / f"{filename}.wav"
                    audio_files[0].rename(target_audio_file)
                    audio_file = str(target_audio_file)
            
            # 清理临时目录
            if temp_input_dir.exists():
                import shutil
                shutil.rmtree(temp_input_dir)
            if temp_output_dir.exists():
                import shutil
                shutil.rmtree(temp_output_dir)
            
            return audio_file
                
        except Exception as e:
            print(f"生成封面语音失败: {e}")
            return None

    def _merge_cover_audio_video(self, video_file: str, audio_file: str, output_dir: Path, filename: str, logger: logging.Logger=None) -> Optional[str]:
        """合并封面/尾页的音频和视频"""
        try:
            output_file = output_dir / f"{filename}-padded.mp4"
            
            # 调用音视频合并脚本
            merge_command = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                "video_audio_merge_single.py",  # 单文件合并版本
                audio_file,        # 音频文件
                video_file,        # 视频文件  
                str(output_file)   # 输出文件
            ]
            
            success = self.run_subprocess_command(command=merge_command, description=f"合并{filename}音视频", logger=logger)
            
            if success and output_file.exists():
                return str(output_file)
            else:
                return None
                
        except Exception as e:
            print(f"合并封面音视频失败: {e}")
            return None

    def concatenate_videos(self, video_files: List[str], output_path: str, logger: logging.Logger) -> Optional[str]:
        """
        使用ffmpeg的concat demuxer拼接多个视频文件
        
        Args:
            video_files: 视频文件路径列表，按拼接顺序排列
            output_path: 输出视频文件路径
            
        Returns:
            成功返回输出文件路径，失败返回None
        """
        try:
            # 过滤掉不存在的视频文件
            existing_files = [f for f in video_files if f and os.path.exists(f)]
            
            if not existing_files:
                print("警告: 没有有效的视频文件可供拼接")
                return None
            
            if len(existing_files) == 1:
                # 只有一个文件，直接复制
                import shutil
                shutil.copy2(existing_files[0], output_path)
                print(f"只有一个视频文件，直接复制: {existing_files[0]} -> {output_path}")
                return output_path
            
            # 创建临时文件列表
            import tempfile
            temp_dir = os.path.dirname(output_path)
            file_list_path = os.path.join(temp_dir, "concat_list.txt")
            
            try:
                # 创建文件列表
                with open(file_list_path, 'w', encoding='utf-8') as f:
                    for video_file in existing_files:
                        # 使用绝对路径以避免路径问题
                        abs_path = os.path.abspath(video_file)
                        f.write(f"file '{abs_path}'\n")
                
                print(f"创建文件列表: {file_list_path}")
                print(f"拼接文件: {existing_files}")
                
                # 使用ffmpeg concat demuxer进行拼接
                command = [
                    "ffmpeg", "-y",  # 覆盖输出文件
                    "-f", "concat",  # 使用concat demuxer
                    "-safe", "0",    # 允许不安全的文件路径
                    "-i", file_list_path,  # 输入文件列表
                    "-c", "copy",    # 直接复制流，不重新编码
                    output_path
                ]
                
                print(f"拼接视频命令: {' '.join(command)}")
                
                success = self.run_subprocess_command(command=command, description=f"拼接{len(existing_files)}个视频文件", logger=logger)
                
                if success and os.path.exists(output_path):
                    print(f"视频拼接成功: {output_path}")
                    return output_path
                else:
                    print("视频拼接失败")
                    return None
                    
            finally:
                # 清理临时文件
                if os.path.exists(file_list_path):
                    os.remove(file_list_path)
                    
        except Exception as e:
            print(f"视频拼接过程中发生错误: {e}")
            if logger:
                logger.error(json.dumps({
                    "event": "error",
                    "message": f"视频拼接过程中发生错误: {e}",
                    "video_files": existing_files
                }, ensure_ascii=False))
            import traceback
            traceback.print_exc()
            return None
    

    
    def find_latest_file_with_keyword(self, query: str, directory: str, suffix: str = ".md") -> str:
        """
        在指定目录中查找包含关键词的最新文件
        
        参数:
            query (str): 关键词
            directory (str): 目录路径
            suffix (str, 可选): 文件后缀名. 默认是 ".md"
        
        返回:
            包含关键词的最新文件路径
        
        异常:
            FileNotFoundError: 如果找不到匹配的文件
        """
        if not os.path.exists(directory):
            raise FileNotFoundError(f"目录不存在: {directory}")
        
        # 在当前目录下查找指定后缀的文件
        files = [f for f in os.listdir(directory) if f.endswith(suffix)]
        if not files:
            raise FileNotFoundError(f"未找到 {suffix} 文件: {query} 在路径: {directory}")
        
        # 读取所有包含关键词的文件
        candidate_files = [f for f in files if query in f]
        if not candidate_files:
            raise FileNotFoundError(f"未找到包含 {query} 的 {suffix} 文件在路径: {directory}")
        
        # 获取最新的文件(假设文件名格式为 "file_时间戳.md")
        try:
            latest_file = max(candidate_files, key=lambda f: f.split('_')[-1].split('.')[0])
            return latest_file
        except (ValueError, IndexError):
            # 如果文件名格式不符合预期，按修改时间排序
            latest_file = max(candidate_files, key=lambda f: os.path.getmtime(os.path.join(directory, f)))
            return latest_file
        

    def preprocess_markdown(self, query: str, upload_file_path: str, request_output_dir: str, 
                        verbose: bool = False) -> str:
        """
        预处理 markdown 文件

        参数:
            query: 关键词或文件名
            upload_file_root_path: 上传文件根路径
            request_output_dir: 请求输出目录
            verbose: 是否输出详细信息
        
        返回:
            脚本文件路径
        """
        # 读取 markdown 文件内容
        if not os.path.exists(upload_file_path):
            raise FileNotFoundError(f"用户请求目录不存在: {upload_file_path}")
        
        # 在当前目录下查找 markdown 文件
        latest_file = self.find_latest_file_with_keyword(query, upload_file_path, suffix=".md")
        script_file_path = os.path.join(upload_file_path, latest_file)
        
        # 复制文件到输出目录
        full_script_save_dir = os.path.join(request_output_dir, "scripts", "full")
        os.makedirs(full_script_save_dir, exist_ok=True)
        full_script_path = os.path.join(full_script_save_dir, "script_full.md")
        
        # 使用shutil代替os.system更安全
        outline_content_generator = OutlineContentGenerator(config_path="./config.json", verbose=verbose)
        _ = outline_content_generator.pipeline(script_file_path, full_script_path, verbose=verbose)
        
        return full_script_path


    def generate_outline_with_attachments(self, query: str, upload_file_path: str, upload_attachment_dir: str, request_output_dir: str, verbose: bool = False) -> str:
        """
        生成带附件的大纲，并执行相应的命令行操作

        参数:
            query: 关键词或文件名
            upload_file_path: 上传文件路径
            upload_attachment_dir: 上传附件目录
            request_output_dir: 请求输出目录
            verbose: 是否输出详细信息
        
        返回:
            生成的大纲文件路径
        """
        # 检查附件文件夹是否非空
        if not os.path.exists(upload_attachment_dir):
            raise FileNotFoundError(f"附件文件夹不存在: {upload_attachment_dir}")

        if len(os.listdir(upload_attachment_dir)) == 0:
            raise FileNotFoundError(f"附件文件夹为空: {upload_attachment_dir}")

        # 查找对应的文件
        latest_file = self.find_latest_file_with_keyword(query, upload_file_path, suffix=".md")
        file_path = os.path.join(upload_file_path, latest_file)

        # 设置输出目录路径
        full_outline_save_dir = os.path.join(request_output_dir, "scripts", "full")
        os.makedirs(full_outline_save_dir, exist_ok=True)
        full_outline_path = os.path.join(full_outline_save_dir, "script_full.md")

        # 执行命令，生成大纲并处理附件
        command = [
            "/home/EduAgent/miniconda3/envs/edu_env/bin/python", "/home/TeachMaster/ML/outline_content_generator_attachment_test.py",
            "--outline", file_path,  # 传入找到的文件路径
            "--attachments", upload_attachment_dir,  # 附件文件夹路径
            "--output", full_outline_save_dir  # 输出目录
        ]

        try:
            # 执行命令
            subprocess.run(command, check=True)
            if verbose:
                print(f"大纲和附件处理完成，输出路径: {full_outline_path}")
        except subprocess.CalledProcessError as e:
            print(f"运行 outline_content_generator_attachment_test.py 失败: {e}")
            raise e

        return full_outline_path

    
    def move_specified_images(
        self,
        source_dir: str,        # 源图片目录（存放待移动图片的目录）
        target_dir: str,        # 目标目录（图片要移动到的目录）
        target_name: str,       # 指定的图片名称（可是完整名称或关键词）
        match_type: str = "contains",  # 匹配方式：contains（包含关键词）/ exact（精确匹配）
        image_extensions: List[str] = None  # 支持的图片格式
    ) -> None:
        """
        将源目录下符合名称条件的图片移动到目标目录
        
        参数说明：
        - source_dir: 源目录路径（例如：r"C:\\source_images" 或 "/home/user/source"）
        - target_dir: 目标目录路径（例如：r"C:\\target_images" 或 "/home/user/target"）
        - target_name: 指定的名称（例如："logo" 或 "product_001.jpg"）
        - match_type: 匹配规则（"contains"：文件名包含关键词；"exact"：文件名完全匹配）
        - image_extensions: 支持的图片格式，默认包含常见格式
        """
        # 设置默认支持的图片格式（小写，避免格式大小写问题）
        if image_extensions is None:
            image_extensions = [".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff"]
        
        # 1. 检查源目录是否存在
        if not os.path.exists(source_dir):
            raise FileNotFoundError(f"源目录不存在：{source_dir}")
        
        # 2. 创建目标目录（如果不存在）
        os.makedirs(target_dir, exist_ok=True)
        print(f"目标目录准备完成：{target_dir}")
        
        # 3. 遍历源目录下的所有文件
        moved_count = 0  # 统计移动成功的文件数
        for filename in os.listdir(source_dir):
            # 获取文件完整路径
            source_file_path = os.path.join(source_dir, filename)
            
            # 跳过目录（只处理文件）
            if os.path.isdir(source_file_path):
                continue
            
            # 4. 筛选：判断是否为图片（通过文件后缀）
            file_ext = os.path.splitext(filename)[1].lower()  # 获取小写后缀
            if file_ext not in image_extensions:
                continue
            
            # 5. 筛选：判断文件名是否符合指定条件
            filename_no_ext = os.path.splitext(filename)[0]  # 无后缀的文件名
            match_success = False
            
            if match_type == "exact":
                # 精确匹配（完整文件名，含后缀）
                if filename == target_name:
                    match_success = True
            elif match_type == "contains":
                # 包含关键词（文件名或后缀中包含，不区分大小写）
                if target_name.lower() in filename.lower():
                    match_success = True
            else:
                raise ValueError(f"无效的匹配方式：{match_type}，请使用 'contains' 或 'exact'")
            
            # 6. 移动符合条件的图片
            if match_success:
                target_file_path = os.path.join(target_dir, filename)
                
                # 处理目标目录已存在同名文件的情况（避免覆盖）
                if os.path.exists(target_file_path):
                    # 在文件名后添加数字后缀（例如：logo_1.png）
                    base_name, ext = os.path.splitext(filename)
                    counter = 1
                    while os.path.exists(os.path.join(target_dir, f"{base_name}_{counter}{ext}")):
                        counter += 1
                    target_file_path = os.path.join(target_dir, f"{base_name}_{counter}{ext}")
                    print(f"同名文件已存在，重命名为：{os.path.basename(target_file_path)}")
                
                # 执行移动操作
                try:
                    shutil.move(source_file_path, target_file_path)
                    print(f"成功移动：{filename} → {os.path.basename(target_file_path)}")
                    moved_count += 1
                except PermissionError:
                    print(f"权限不足，无法移动：{filename}")
                except Exception as e:
                    print(f"移动失败 {filename}：{str(e)}")
        
        # 输出最终统计结果
        print(f"\n移动完成！共处理 {moved_count} 个图片文件")

    def test_completed(self, job_id: str, request: GenerationRequest):
        
        """测试任务是否完成"""
        self.jobs[job_id] = JobStatus(
                job_id=job_id,
                user_id=request.user_id,
                status="completed",
                progress=100,
                created_at=datetime.now(),
                message="正在初始化生成环境...",
                access_token=request.access_token
            )

        self.jobs[job_id].settings = {
                    "course_title": "test course",
                    "professor_name": "zhangjie",
                    "avatar_image": "csh.png"
                }
        # 计算文件大小并生成最终结果
        final_video_path = f"generated_content/101/{job_id}/video_w_audio/Full.mp4"
        final_video_size = os.path.getsize(final_video_path) if os.path.exists(final_video_path) else 0
        
        # 创建结果数据
        result_files = [
            {"name": f"完整课程视频-test.mp4", "path": final_video_path, "size": final_video_size, "type": "video"}
        ]
        
        self.jobs[job_id].result = {
            "keyword": "test",
            "files": result_files
        }
    
    def _update_job_status(self, job_id: str, status: str, progress: int, message: str, estimated_time: int = 0):
        """一个集中的状态更新辅助函数"""
        job = self.jobs[job_id]
        job.status = status
        job.progress = progress
        job.message = message
        job.current_step_start_time = datetime.now().isoformat()
        job.current_step_estimated_time = estimated_time
        print(f"Job {job_id} Status: {status} - {message}")

    def generate_content_async(self, job_id: str, request: GenerationRequest):
        """异步内容生成任务"""
        """
        1. 预处理(关键词或markdown文件)
        2. 脚本分割
        3. 分页处理
        4. Markdown分割
        5. 生成Manim代码
        6. 生成语音脚本
        7. 生成语音音频
        8. 插入断点
        9. 自动等待时间生成
        10. 音视频对齐处理
        11. 添加背景
        12. 渲染视频
        13. 合并音频和视频
        """
        self.jobs[job_id] = JobStatus(
                job_id=job_id,
                user_id=request.user_id,
                status="initializing",
                progress=0,
                created_at=datetime.now(),
                message="正在初始化生成环境...",
                access_token=request.access_token
            )
        mode = request.mode
        verbose = True
        keywords = request.keyword
        user_id = request.user_id

        output_root_path = "generated_content"
        request_output_dir = os.path.join(output_root_path, str(user_id), str(job_id))
        logger = self._setup_job_logger(job_id, request_output_dir)

        # 定义默认文件路径  
        DEFAULT_BACKGROUND_IMAGE = "/home/EduPal_v2/jiezhang/web-app/backend/background_default.png"
        DEFAULT_WAV_PATH = "/home/EduPal_v2/junhaoge/EduPal_v2/ML/UploadFiles/source/Prof_Chen.wav"
        DEFAULT_WAV_PROMPT_PATH = "/home/EduPal_v2/junhaoge/EduPal_v2/ML/UploadFiles/source/Prof_Chen.txt"
        # wav_path = "/home/EduPal_v2/junhaoge/EduPal_v2/ML/UploadFiles/source/Prof_Chen.wav"
        # wav_prompt_path = "/home/EduPal_v2/junhaoge/EduPal_v2/ML/UploadFiles/source/Prof_Chen.txt"
        background_image_path = DEFAULT_BACKGROUND_IMAGE
        wav_path = DEFAULT_WAV_PATH
        wav_prompt_path = DEFAULT_WAV_PROMPT_PATH
        
        # 检查是否提供了自定义文件
        if request.background_image_id:
            # 查找用户上传的背景图
            background_image_dir = Path("uploads/backgrounds")
            for file in background_image_dir.iterdir():
                if file.name.startswith(request.background_image_id):
                    background_image_path = str(file)
                    break
        
        if request.reference_audio_id:
            # 查找用户上传的参考音频
            audio_dir = Path("uploads/audios")
            for file in audio_dir.iterdir():
                if file.name.startswith(request.reference_audio_id):
                    wav_path = str(file)
                    print("🚀 开始加载 Whisper 模型...")
                    # 'base', 'small', 'medium', 'large'。模型越大，效果越好，速度越慢。
                    # 首次运行会下载模型文件。
                    model = whisper.load_model("medium") 
                    print("✅ Whisper 模型加载完毕。")

                    print(f"🔊 正在识别音频文件: {wav_path}")
                    start_time = time.time()
                    
                    # 指定语言为 'yue' (Cantonese) 可以提高准确率
                    result = model.transcribe(wav_path, language="zh", fp16=False, initial_prompt="以下是普通话的句子。") # 如果有GPU，可以设为True
                    # 提取识别到的文本
                    transcribed_text = result['text']
                    print(f"🔊 识别到的文本: {transcribed_text}")
                    # 保存识别的文本到文本文件
                    text_dir = Path("uploads/texts")
                    text_file_path = text_dir / f"{str(uuid.uuid4())}.txt"
                    with open(text_file_path, "w", encoding="utf-8") as f:
                        f.write(transcribed_text)

                    wav_prompt_path = text_file_path
                    print(f"🔊 保存识别的文本到文件: {wav_prompt_path}")
                    logger.info(json.dumps({
                        "event": "reference_audio_log",
                        "reference_audio_id": request.reference_audio_id,
                        "wav_path": wav_path,
                        "wav_prompt_path": str(wav_prompt_path),
                        "transcribed_text": transcribed_text
                    }))
                    break

        upload_file_root_path = "./uploads"
        upload_user_dir = os.path.join(upload_file_root_path, str(user_id))
        upload_request_dir = os.path.join(upload_user_dir, job_id)
        upload_md_dir = os.path.join(upload_file_root_path, 'md')
        upload_attachment_dir = os.path.join(upload_request_dir, 'attachments')
        start_time = time.time()
        time_dict = {}

        # token_details = token_service.decrypt_token_info_with_ignore_expiration(request.access_token)
        # print(token_details)
        # page = token_details['page']
        page = 0
        try:
            

            # ===================== 初始化日志记录器 =======================
            
            logger.info(json.dumps({
                "event": "job_start", 
                "job_id": job_id, 
                "user_id": user_id,
                "page": page,
                "message": "Generation process started."
            }))
            
            # 记录用户输入（注意脱敏）
            try:
                request_dict = request.dict()
                if 'access_token' in request_dict:
                    request_dict['access_token'] = '***REDACTED***'
                logger.info(json.dumps({
                    "event": "user_input",
                    "request_data": request_dict
                }, ensure_ascii=False))
            except Exception as e:
                logger.error(json.dumps({"event": "logging_error", "error": f"Failed to serialize request: {e}"}))

            # =====================第0步: 生成封面和尾页=======================
            cover_files = {}
            if request.generate_cover:
                # MODIFICATION: 添加开始时间戳和固定估时
                self.jobs[job_id].status = "cover_generation"
                self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
                self.jobs[job_id].current_step_estimated_time = self.TIME_FOR_COVER
                self.jobs[job_id].progress = 4
                self.jobs[job_id].message = "生成封面和尾页..."
                print(f"预估封面生成时间: {self.TIME_FOR_COVER}秒 (固定值)")

                logger.info(json.dumps({"event": "step_start", "step": "render_cover_and_ending"}))

                # 获取封面参数
                course_title = request.course_title or keywords
                professor_name = request.professor_name or "Prof. Siheng Chen"
                
                # 获取头像图片路径
                avatar_image = "csh.png"  # 默认头像
                if request.avatar_image_id:
                    avatar_dir = Path("uploads/avatars")
                    for file in avatar_dir.iterdir():
                        if file.name.startswith(request.avatar_image_id):
                            avatar_image = str(file)
                            break
                
                # 获取封面背景图片路径
                cover_background = "SAI.png"  # 默认背景
                if request.cover_background_image_id:
                    background_dir = Path("uploads/backgrounds")
                    for file in background_dir.iterdir():
                        if file.name.startswith(request.cover_background_image_id):
                            cover_background = str(file)
                            break

                        # 保存使用的文件路径到作业状态中
                self.jobs[job_id].settings = {
                    "background_image": background_image_path,
                    "reference_audio": str(wav_path),
                    "reference_text": str(wav_prompt_path),
                    "course_title": course_title,
                    "professor_name": professor_name,
                    "avatar_image": avatar_image,
                    "keyword": request.keyword
                }

                logger.info(json.dumps({
                    "event": "settings_log", 
                    "step": "render_cover_and_ending",
                    "settings": self.jobs[job_id].settings
                }))
                
                # 渲染封面和尾页
                cover_output_dir = os.path.join(request_output_dir, "cover_ending")
                try:
                    cover_files = self.render_cover_and_ending(
                        course_title=course_title,
                        professor_name=professor_name,
                        avatar_image=avatar_image,
                        background_image=cover_background,
                        output_dir=cover_output_dir,
                        quality="high",  # 可配置
                        reference_audio=self.jobs[job_id].settings.get("reference_audio"),
                        reference_text=self.jobs[job_id].settings.get("reference_text"),
                        logger=logger 
                    )
                    print(f"封面和尾页生成完成: {cover_files}")
                    logger.info(json.dumps({
                        "event": "step_result", 
                        "step": "render_cover_and_ending",
                        "output": cover_files
                    }))
                except Exception as e:
                    print(f"警告: 封面和尾页生成失败: {e}")
                    logger.error(json.dumps({
                        "event": "step_error", 
                        "step": "render_cover_and_ending", 
                        "error": str(e)
                    }))

                    # 继续执行后续流程

            # 阶段1: 生成课程大纲
            # self.jobs[job_id].status = "pre_processing"
            # self.jobs[job_id].progress = 8
            # self.jobs[job_id].message = "预处理..."
            # self.jobs[job_id].current_step_estimated_time = 50
            # =======================1.预处理=======================
            # MODIFICATION: 动态估算预处理时间
            estimated_time = self.BASE_OVERHEAD_TIME
            if mode == 0: # 关键词模式
                estimated_time += int(len(keywords) * self.TIME_PER_CHAR_PREPROCESS_KW)
                print(f"预估预处理时间 (关键词模式): {estimated_time}秒 ({len(keywords)}个字符)")
            elif mode == 1: # markdown模式
                try:
                    md_file_path = self.find_latest_file_with_keyword(keywords, upload_md_dir, suffix=".md")
                    full_md_path = os.path.join(upload_md_dir, md_file_path)
                    with open(full_md_path, 'r', encoding='utf-8') as f:
                        content_len = len(f.read())
                    estimated_time += int(content_len * self.TIME_PER_CHAR_PREPROCESS_MD)
                    print(f"预估预处理时间 (MD模式): {estimated_time}秒 ({content_len}个字符)")
                except Exception:
                    estimated_time += 60 # 如果找不到文件，给一个默认值
            
            self.jobs[job_id].status = "pre_processing"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = estimated_time
            self.jobs[job_id].progress = 8
            self.jobs[job_id].message = "预处理..."

            # =======================1.预处理=======================
            logger.info(json.dumps({
                "event": "step_start", 
                "step": "preprocess",
                "mode": "keywords" if mode == 0 else "markdown",
                "input": keywords
            }))
            try:
                if mode == 0:  # 关键词模式
                    script_file_path = self.preprocess_keywords(keywords, request_output_dir, verbose=verbose)
                elif mode == 1:  # markdown模式
                    script_file_path = self.preprocess_markdown(query=keywords, upload_file_path=upload_md_dir, request_output_dir=request_output_dir, verbose=verbose)
                elif os.path.exists(upload_attachment_dir) and len(os.listdir(upload_attachment_dir)) > 0:  # 检查附件文件夹是否存在且非空
                    if verbose:
                        print(f"处理附件模式：{upload_attachment_dir}")
                    script_file_path = self.generate_outline_with_attachments(
                        query=keywords, 
                        upload_file_path=upload_md_dir,
                        upload_attachment_dir=upload_attachment_dir,
                        request_output_dir=request_output_dir,
                        verbose=verbose
                    )
                else:
                    raise ValueError(f"不支持的模式: {mode}")
                logger.info(json.dumps({
                    "event": "step_result", 
                    "step": "preprocess",
                    "output_path": script_file_path
                }))
            except Exception as e:
                logger.exception(json.dumps({"event": "step_error", "step": "preprocess", "error": str(e)}))
                if verbose:
                    print(f"预处理阶段失败: {str(e)}")
                raise e
            time_dict["preprocess_time"] = time.time() - start_time
            
            # =====================2. 脚本分割=======================
            # MODIFICATION: 动态估算 (基于预处理后的单个文件)
            estimated_time = self.BASE_OVERHEAD_TIME + self.TIME_PER_FILE_SPLIT # 只有一个文件
            
            self.jobs[job_id].status = "script_splitting"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = estimated_time
            self.jobs[job_id].progress = 16
            self.jobs[job_id].message = "脚本分割..."
            print(f"预估脚本分割时间: {estimated_time}秒")
            script_splited_output_folder = os.path.join(request_output_dir, "scripts", "splitted")
            self.ensure_directory_exists(script_splited_output_folder)
            logger.info(json.dumps({
                "event": "step_start",
                "step": "2_script_splitting",
                "input_file": script_file_path,
                "output_dir": script_splited_output_folder
            }))
            try:
                script_splitter = self.scriptSplitter                
                script_splitter.pipeline(script_file_path, output_dir=script_splited_output_folder, page=page)
                logger.info(json.dumps({
                    "event": "step_result", 
                    "step": "2_script_splitting",
                    "output_dir": script_splited_output_folder
                }))
            except Exception as e:
                logger.exception(json.dumps({"event": "step_error", "step": "2_script_splitting", "error": str(e)}))
                raise e
            time_dict["split_time"] = time.time() - start_time - time_dict["preprocess_time"]

            

            # ====================3. 分页处理=======================
            # MODIFICATION: 动态估算
            num_files = len(os.listdir(script_splited_output_folder))
            estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_FILE_PAGINATE

            self.jobs[job_id].status = "pagination"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = estimated_time
            self.jobs[job_id].progress = 24
            self.jobs[job_id].message = "分页处理..."
            print(f"预估分页处理时间: {estimated_time}秒 ({num_files}个文件)")
            
            try:
                paginator = self.paginator
                script_paginated_output_folder = os.path.join(request_output_dir, "scripts", "paginated")
                self.ensure_directory_exists(script_paginated_output_folder)
                logger.info(json.dumps({
                "event": "step_start",
                "step": "3_pagination",
                "input_dir": script_splited_output_folder,
                "output_dir": script_paginated_output_folder
            }))
                
                paginator.pipeline(script_splited_output_folder, output_dir=script_paginated_output_folder)
                logger.info(json.dumps({
                    "event": "step_result", 
                    "step": "3_pagination",
                    "output_dir": script_paginated_output_folder
                }))
                time_dict["paginate_time"] = time.time() - start_time - sum(time_dict.values())
            except Exception as e:
                logger.exception(json.dumps({"event": "step_error", "step": "3_pagination", "error": str(e)}))
                raise e

            

            # =====================4. Markdown分割==================
            # self.jobs[job_id].status = "markdown_splitting"
            # self.jobs[job_id].progress = 32
            # self.jobs[job_id].message = "Markdown分割..."
            # self.jobs[job_id].current_step_estimated_time = 50
            num_files = len(os.listdir(script_paginated_output_folder))
            estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_FILE_MD_SPLIT

            self.jobs[job_id].status = "markdown_splitting"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = estimated_time
            self.jobs[job_id].progress = 32
            self.jobs[job_id].message = "Markdown分割..."
            print(f"预估Markdown分割时间: {estimated_time}秒 ({num_files}个文件)")
            logger.info(json.dumps({
                "event": "step_start",
                "step": "4_markdown_splitting",
                "target_dir": script_paginated_output_folder
            })) 
            try:
                markdown_splitter = self.markdownSplitter
                markdown_splitter.pipeline(script_paginated_output_folder)
                logger.info(json.dumps({
                    "event": "step_result", 
                    "step": "4_markdown_splitting",
                    "target_dir": script_paginated_output_folder
                }))
                time_dict["markdown_split_time"] = time.time() - start_time - sum(time_dict.values())
            except Exception as e:
                logger.exception(json.dumps({"event": "step_error", "step": "4_markdown_splitting", "error": str(e)}))
                raise e

            
            
            # =====================5. 生成Manim代码===================
            # self.jobs[job_id].status = "manim_code_generation"
            # self.jobs[job_id].progress = 40
            # self.jobs[job_id].message = "生成Manim代码..."
            # self.jobs[job_id].current_step_estimated_time = 50
            num_files = len(os.listdir(script_paginated_output_folder))
            estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_FILE_MANIM_CODE

            self.jobs[job_id].status = "manim_code_generation"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = estimated_time
            self.jobs[job_id].progress = 40
            self.jobs[job_id].message = "生成Manim代码..."
            print(f"预估Manim代码生成时间: {estimated_time}秒 ({num_files}个文件)")
            
            try:
                manim_code_generator = self.manimcode_generator
                manim_code_output_path = os.path.join(request_output_dir, "manim_codes")
                self.ensure_directory_exists(manim_code_output_path)
                logger.info(json.dumps({
                    "event": "step_start",
                    "step": "5_manim_code_generation",
                    "input_dir": script_paginated_output_folder,
                    "output_dir": manim_code_output_path
                }))
            
                manim_code_generator.pipeline(script_paginated_output_folder, output_dir=manim_code_output_path)
                logger.info(json.dumps({
                    "event": "manim_debug", 
                    "step": "5_manim_code_generation",
                    "output_dir": manim_code_output_path
                }))

                
            except Exception as e:
                logger.exception(json.dumps({"event": "step_error", "step": "5_manim_code_generation", "error": str(e)}))
                raise e

            time_dict["manim_code_time"] = time.time() - start_time - sum(time_dict.values())

            
            
            # 6. 生成语音脚本
            # self.jobs[job_id].status = "speech_script_generation"
            # self.jobs[job_id].progress = 48
            # self.jobs[job_id].message = "生成语音脚本..."
            # self.jobs[job_id].current_step_estimated_time = 50
            num_files = len(os.listdir(script_paginated_output_folder))
            estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_FILE_SPEECH_SCRIPT

            self.jobs[job_id].status = "speech_script_generation"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = estimated_time
            self.jobs[job_id].progress = 48
            self.jobs[job_id].message = "生成语音脚本..."
            print(f"预估语音脚本生成时间: {estimated_time}秒 ({num_files}个文件)")
            
            try:
                speech_script_generator = self.speechScriptGenerator
                speech_output_path = os.path.join(request_output_dir, "speech")
                self.ensure_directory_exists(speech_output_path)
                logger.info(json.dumps({
                    "event": "step_start",
                    "step": "6_speech_script_generation",
                    "input_script_dir": script_paginated_output_folder,
                    "input_code_dir": manim_code_output_path,
                    "output_dir": speech_output_path
                }))
            
                speech_script_generator.pipeline(script_paginated_output_folder, manim_code_output_path, output_dir=speech_output_path)
            except Exception as e:
                logger.exception(json.dumps({"event": "step_error", "step": "6_speech_script_generation", "error": str(e)}))
                raise e
            time_dict["speech_time"] = time.time() - start_time - sum(time_dict.values())

            

            # 7. 生成语音音频
            # self.jobs[job_id].status = "speech_audio_generation"
            # self.jobs[job_id].progress = 56
            # self.jobs[job_id].message = "生成语音音频..."
            # self.jobs[job_id].current_step_estimated_time = 50
            total_chars = 0
            for filename in os.listdir(speech_output_path):
                if filename.endswith(".txt"):
                    with open(os.path.join(speech_output_path, filename), 'r', encoding='utf-8') as f:
                        total_chars += len(f.read())
            estimated_time = self.BASE_OVERHEAD_TIME + int(total_chars * self.TIME_PER_CHAR_AUDIO)

            self.jobs[job_id].status = "speech_audio_generation"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = estimated_time
            self.jobs[job_id].progress = 56
            self.jobs[job_id].message = "生成语音音频..."
            print(f"预估语音生成时间: {estimated_time}秒 ({total_chars}个字符)")
            
            
            speech_audio_output_path = os.path.join(request_output_dir, "speech_audio")
            self.ensure_directory_exists(speech_audio_output_path)
            logger.info(json.dumps({
                "event": "step_start",
                "step": "7_speech_audio_generation",
                "input_dir": speech_output_path,
                "output_dir": speech_audio_output_path
            }))

            prompt_txt = ""
            with open(self.jobs[job_id].settings.get("reference_text", wav_prompt_path), 'r', encoding='utf-8') as f:
                prompt_txt = f.read().strip()
            
            # cosyvoice_command = [
            #     "/home/EduAgent/miniconda3/envs/cosyvoice/bin/python",
            #     "/home/EduAgent/services/cosyvoice/run_cosyvoice_dynamic.py",
            #     speech_output_path,
            #     speech_audio_output_path,
            #     "--prompt_wav", self.jobs[job_id].settings.get("reference_audio", wav_path),
            #     "--prompt_text", prompt_txt,
            # ]
            cosyvoice_command = [
                "/home/EduAgent/miniconda3/envs/cosyvoice/bin/python",
                "/home/EduAgent/services/cosyvoice/run_cosyvoice_par.py",
                speech_output_path,
                speech_audio_output_path,
                "--prompt_wav", self.jobs[job_id].settings.get("reference_audio", wav_path),
                "--prompt_text", prompt_txt,
            ]
            
            success = self.run_subprocess_command(command=cosyvoice_command, description="生成语音音频", verbose=verbose, logger=logger)
            if not success:
                raise RuntimeError("语音音频生成失败")
            
            time_dict["speech_audio_time"] = time.time() - start_time - sum(time_dict.values())

            
            
            # 8. 插入断点
            # self.jobs[job_id].status = "breakpoint_insertion"
            # self.jobs[job_id].progress = 64
            # self.jobs[job_id].message = "插入断点..."
            # self.jobs[job_id].current_step_estimated_time = 50
            num_files = len(os.listdir(manim_code_output_path))
            estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_FILE_BREAKPOINT
            
            self.jobs[job_id].status = "breakpoint_insertion"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = estimated_time
            self.jobs[job_id].progress = 64
            self.jobs[job_id].message = "插入断点..."
            print(f"预估断点插入时间: {estimated_time}秒 ({num_files}个文件)")
            
            try:
            
                speech_time_file_path = os.path.join(speech_audio_output_path, "speech.txt")
                refined_output_path = os.path.join(request_output_dir, "manim_codes_refined")
                self.ensure_directory_exists(refined_output_path)
                
                manim_breakpoint_inserter = self.manimBreakpointInserter
                logger.info(json.dumps({
                    "event": "step_start",
                    "step": "8_breakpoint_insertion",
                    "input_code_dir": manim_code_output_path,
                    "input_speech_dir": speech_output_path,
                    "output_dir": refined_output_path
                }))
                manim_breakpoint_inserter.pipeline(manim_code_output_path, speech_output_path, refined_output_path)
                
                manim_code_refined_output_path = os.path.join(refined_output_path, "Code")
                speech_refined_output_path = os.path.join(refined_output_path, "Speech")
                logger.info(json.dumps({
                    "event": "step_result",
                    "step": "8_breakpoint_insertion",
                    "llm_module": "ManimBreakpointInserter",
                    "output_dir": refined_output_path
                }))
            except Exception as e:
                logger.exception(json.dumps({"event": "step_error", "step": "8_breakpoint_insertion", "error": str(e)}))
                raise e
            time_dict["breakpoint_time"] = time.time() - start_time - sum(time_dict.values())

            
            
            # 9. 自动等待时间生成
            # self.jobs[job_id].status = "auto_wait_time_generation"
            # self.jobs[job_id].progress = 72
            # self.jobs[job_id].message = "自动等待时间生成..."
            # self.jobs[job_id].current_step_estimated_time = 50
            num_files = len(os.listdir(manim_code_refined_output_path))
            estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_FILE_AUTOWAIT

            self.jobs[job_id].status = "auto_wait_time_generation"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = estimated_time
            self.jobs[job_id].progress = 72
            self.jobs[job_id].message = "自动等待时间生成..."
            print(f"预估自动等待时间生成: {estimated_time}秒 ({num_files}个文件)")
            
            try:

                manim_code_final_output_path = os.path.join(request_output_dir, "manim_codes_final")
                manim_auto_wait_generator = self.manimAutoWaitGenerator
                logger.info(json.dumps({
                    "event": "step_start",
                    "step": "9_auto_wait_time_generation",
                    "output_dir": manim_code_final_output_path
                }))
                manim_auto_wait_generator.pipeline(speech_time_file_path, speech_refined_output_path, 
                                                manim_code_refined_output_path, manim_code_final_output_path)
                logger.info(json.dumps({
                    "event": "step_result",
                    "step": "9_auto_wait_time_generation",
                    "output_dir": manim_code_final_output_path
                }))
            except Exception as e:
                logger.exception(json.dumps({"event": "step_error", "step": "9_auto_wait_time_generation", "error": str(e)}))
                raise e
            time_dict["auto_wait_time"] = time.time() - start_time - sum(time_dict.values())

            
            
            # 10. 音视频对齐处理
            num_files = len(os.listdir(manim_code_final_output_path))
            estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_FILE_ALIGN

            self.jobs[job_id].status = "video_audio_align"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = estimated_time
            self.jobs[job_id].progress = 80
            self.jobs[job_id].message = "音视频对齐处理..."
            print(f"预估音视频对齐时间: {estimated_time}秒 ({num_files}个文件)")
            logger.info(json.dumps({
                "event": "step_start",
                "step": "10_video_audio_align",
                "input_speech_file": speech_time_file_path,
                "input_manim_code_dir": manim_code_final_output_path,
            }))

            align_command = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                "video_audio_align.py",
                speech_time_file_path,
                manim_code_final_output_path
            ]
            
            success = self.run_subprocess_command(command=align_command, description="音视频对齐处理", verbose=verbose, logger=logger)
            if not success:
                print("警告: 音视频对齐处理失败，继续后续流程")
                logger.warning(json.dumps({"event": "step_warning", "step": "10_video_audio_align", "message": "Alignment script failed, continuing process."}))
            
            time_dict["align_time"] = time.time() - start_time - sum(time_dict.values())

            
            
            # 11. 添加背景
            num_files = len(os.listdir(manim_code_final_output_path))
            estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_FILE_ADD_BG

            self.jobs[job_id].status = "background_addition"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = estimated_time
            self.jobs[job_id].progress = 88
            self.jobs[job_id].message = "添加背景..."
            print(f"预估添加背景时间: {estimated_time}秒 ({num_files}个文件)")
            logger.info(json.dumps({
                "event": "step_start",
                "step": "11_background_addition",
                "target_dir": manim_code_final_output_path
            }))

            latest_background_image = None
            default_background_image = DEFAULT_BACKGROUND_IMAGE
            self.add_background(manim_code_final_output_path, self.jobs[job_id].settings.get("background_image", default_background_image), logger=logger)
            
            # 添加页码
            page_num_command = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                "add_pagenum.py",
                manim_code_final_output_path
            ]
            self.run_subprocess_command(command=page_num_command, description="添加页码", verbose=verbose, logger=logger)
            time_dict["add_background_time"] = time.time() - start_time - sum(time_dict.values())
            
            # 12. 渲染视频
            num_files = len(os.listdir(manim_code_final_output_path))
            estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_VIDEO_RENDER

            self.jobs[job_id].status = "video_rendering"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = estimated_time
            self.jobs[job_id].progress = 96
            self.jobs[job_id].message = "渲染视频..."
            print(f"预估视频渲染时间: {estimated_time}秒 ({num_files}个文件)")

            # 使用batch_debug.py开始对生成的manim代码进行AI-debug
            if language_now == 'zh':
                debug_command = ["python", "batch_debug_for_effi_test_cn.py", manim_code_final_output_path, manim_code_final_output_path]
            else:
                debug_command = ["python", "batch_debug_for_effi_test.py", manim_code_final_output_path, manim_code_final_output_path]
            success = self.run_subprocess_command(debug_command, logger=logger, description="AI-Debug Manim 代码", verbose=verbose)
            if not success:
                raise RuntimeError("AI-Debug Manim 代码失败")
                
            logger.info(json.dumps({
                "event": "manim_optimization_layout", 
                "step": "5_manim_code_generation",
                "input_dir": manim_code_final_output_path
            }))
            debugged_manim_code_output_path = os.path.join(request_output_dir, "manim_code_fixed")
            # 确保目录存在
            self.ensure_directory_exists(debugged_manim_code_output_path)

            # 复制占位图到指定文件夹
            shutil.copyfile(os.path.join(upload_file_root_path, "placeholder.png"), os.path.join(manim_code_final_output_path, "placeholder.png"))
            shutil.copyfile(os.path.join(upload_file_root_path, "placeholder.png"), os.path.join(debugged_manim_code_output_path, "placeholder.png"))
            shutil.copyfile("background_default.png", os.path.join(manim_code_final_output_path, "background_default.png"))
            shutil.copyfile(os.path.join(manim_code_final_output_path, "background_default.png"), os.path.join(debugged_manim_code_output_path, "background_default.png"))
            # 优化layout
            layout_command = [
                '/home/EduAgent/miniconda3/envs/manim_env/bin/python',
                '/home/TeachMaster/ML/batch_auto_fix_layout.py',
                manim_code_final_output_path
            ]
            self.run_subprocess_command(command=layout_command, logger=logger)
            
            
            video_wo_audio_output_path = os.path.join(request_output_dir, "video_wo_audio")

            # 修改为高清晰度渲染
            quality = "h"
            self.ensure_directory_exists(video_wo_audio_output_path)
            logger.info(json.dumps({
                "event": "step_start",
                "step": "12_video_rendering",
                "input_dir": debugged_manim_code_output_path,
                "output_dir": video_wo_audio_output_path
            }))
            
            render_command = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                "batch_render_manim.py",
                debugged_manim_code_output_path,
                video_wo_audio_output_path,
                "--quality", quality
            ]
            
            success = self.run_subprocess_command(command=render_command, description="渲染Manim视频", verbose=verbose, logger=logger)
            if not success:
                print("存在视频渲染失败")
                logger.warning(json.dumps({"event": "step_warning", "step": "12_video_rendering", "message": "Some videos failed to render."}))
            
            time_dict["render_time"] = time.time() - start_time - sum(time_dict.values())

            # 清理渲染过程中产生的media文件夹
            self._cleanup_media_folders_after_render(manim_code_final_output_path)

            # 步骤12后暂停，等待用户选择是否预览
            self.jobs[job_id].status = "awaiting_preview_decision"
            self.jobs[job_id].current_step_start_time = datetime.now().isoformat()
            self.jobs[job_id].current_step_estimated_time = 3600 # 预留1小时给用户预览
            self.jobs[job_id].progress = 95
            self.jobs[job_id].message = "视频渲染完成，等待预览选择..."
            
            # 保存预览所需数据路径
            self.jobs[job_id].preview_data = {
                "video_wo_audio_path": video_wo_audio_output_path,
                "manim_code_path": manim_code_final_output_path,
                "speech_script_path": os.path.join(refined_output_path, "Speech"),  # 打断点后的讲稿
                "speech_script_original_path": speech_output_path,  # 原始讲稿
                "speech_audio_path": speech_audio_output_path
            }
            logger.info(json.dumps({
                "event": "process_pause",
                "status": "awaiting_preview_decision",
                "message": "Rendering complete. Pausing for user preview decision.",
                "preview_data_paths": self.jobs[job_id].preview_data
            }))
            
            print("🔍 渲染完成，等待用户预览选择...")
            return  # 暂停流程，等待用户选择

        except KeyboardInterrupt:
            sys.exit(1)
        except Exception as e:
            if 'logger' in locals():
                logger.exception(json.dumps({
                    "event": "job_failed",
                    "job_id": job_id,
                    "error": f"Content generation failed: {str(e)}"
                }))
            # 标记为失败
            self.jobs[job_id].status = "failed"
            self.jobs[job_id].message = f"生成失败: {str(e)}"
            self.jobs[job_id].error = str(e)
            print(f"Content generation failed for job {job_id}: {e}")

    # def continue_generation_after_preview(self, job_id: str):
    #     """
    #     用户预览完成后继续生成流程
    #     """
    #     job = self.jobs.get(job_id)
    #     if not job or job.status != "awaiting_preview_decision":
    #         return False
            
    #     print("🔄 用户选择继续，恢复生成流程...")
        
    #     # 从保存的数据中恢复路径
    #     preview_data = job.preview_data
    #     video_wo_audio_output_path = preview_data["video_wo_audio_path"]
    #     manim_code_final_output_path = preview_data["manim_code_path"]
    #     speech_script_path = preview_data["speech_script_path"]
    #     speech_audio_output_path = preview_data["speech_audio_path"]
        
    #     # 继续原有的处理流程
    #     request_output_dir = os.path.dirname(video_wo_audio_output_path)
    #     verbose = True

    #     logger = self._setup_job_logger(job_id, request_output_dir)
    #     logger.info(json.dumps({
    #         "event": "job_continue",
    #         "job_id": job_id,
    #         "message": "Resuming generation process after user preview."
    #     }))
        
    #     try:
    #         # 13. 合并音频和视频（分两个子步骤）
    #         video_w_audio_output_path = os.path.join(request_output_dir, "video_w_audio")
    #         self.ensure_directory_exists(video_w_audio_output_path)
            
    #         # 13.1 音频与每个视频片段合并且填充
    #         # job.status = "individual_video_merging"
    #         # job.progress = 96
    #         # job.message = "合并音频与视频片段..."
    #         # self.jobs[job_id].current_step_estimated_time = 50
    #         num_files = len(os.listdir(video_wo_audio_output_path))
    #         estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_VIDEO_MERGE_INDIVIDUAL

    #         job.status = "individual_video_merging"
    #         job.current_step_start_time = datetime.now().isoformat()
    #         job.current_step_estimated_time = estimated_time
    #         job.progress = 96
    #         job.message = "合并音频与视频片段..."
    #         print(f"预估单片段合并时间: {estimated_time}秒 ({num_files}个文件)")
            
    #         logger.info(json.dumps({
    #             "event": "step_start",
    #             "step": "14_individual_video_merging",
    #             "message": "Merging audio with video segments and padding...",
    #             "input_speech_audio_path": speech_audio_output_path,
    #             "input_video_wo_audio_dir": video_wo_audio_output_path,
    #             "output_video_w_audio_dir": video_w_audio_output_path,
    #         }))
            
    #         print("🎬 Step 14: 音频与视频片段合并且填充...")
    #         merge_individual_command = [
    #             "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
    #             "video_audio_merge_individual.py",
    #             speech_audio_output_path,
    #             video_wo_audio_output_path,
    #             video_w_audio_output_path
    #         ]
            
    #         success = self.run_subprocess_command(command=merge_individual_command, description="合并音频与视频片段", verbose=verbose, logger=logger)
    #         if not success:
    #             raise RuntimeError("音频与视频片段合并失败")
            
    #         # 13.2 
    #         num_files = len(os.listdir(video_w_audio_output_path))
    #         estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_VIDEO_CONCAT

    #         job.status = "video_concatenation_internal"
    #         job.current_step_start_time = datetime.now().isoformat()
    #         job.current_step_estimated_time = estimated_time
    #         job.progress = 98
    #         job.message = "合并视频片段为完整视频..."
    #         print(f"预估多片段合并时间: {estimated_time}秒 ({num_files}个文件)")
    #         logger.info(json.dumps({
    #             "event": "step_start",
    #             "step": "15_video_concatenation_internal",
    #             "message": "Merging video segments for final concatenation...",
    #             "input_video_w_audio_dir": video_w_audio_output_path,
    #             "output_video_w_audio_path": os.path.join(video_w_audio_output_path, "Full.mp4")
    #         }))
            
    #         print("🎬 Step 15: 多个视频片段合并为完整视频...")
    #         concat_command = [
    #             "/home/EduAgent/miniconda3/envs/manim_env/bin/python", 
    #             "video_concat.py",
    #             video_w_audio_output_path,
    #             video_w_audio_output_path
    #         ]
            
    #         success = self.run_subprocess_command(command=concat_command, description="合并视频片段为完整视频", verbose=verbose, logger=logger)
    #         if not success:
    #             raise RuntimeError("视频片段合并失败")
            
    #         mp4Path = os.path.join(video_w_audio_output_path, "Full.mp4")
            
    #         # 获取原始请求数据
    #         keywords = job.keyword if hasattr(job, 'keyword') else 'unknown'
            
    #         # 继续后续步骤...（封面拼接等）
    #         self._continue_final_steps(job_id=job_id, mp4Path=mp4Path, request_output_dir=request_output_dir, keywords=keywords, logger=logger)
            
    #     except Exception as e:
    #         job.status = "failed"
    #         job.message = f"继续生成失败: {str(e)}"
    #         job.error = str(e)
    #         logger.exception(json.dumps({
    #             "event": "job_failed",
    #             "job_id": job_id,
    #             "stage": "continuation_after_preview",
    #             "error": str(e)
    #         }))
    #         print(f"Continue generation failed for job {job_id}: {e}")

    # def _continue_final_steps(self, job_id: str, mp4Path: str, request_output_dir: str, keywords: str, logger: logging.Logger):
    #     """继续执行最终步骤（封面拼接等）"""
    #     job = self.jobs[job_id]
        
    #     # 14. 拼接最终完整视频（包含封面、教学内容、尾页）
    #     final_video_path = mp4Path  # 默认使用教学视频
        
    #     # 提前定义课程标题和教授姓名变量
    #     _course_title = job.settings.get("course_title", "unknown")
    #     _professor_name = job.settings.get("professor_name", "unknown")
        
    #     # 获取封面文件（如果存在）
    #     cover_files = {}
    #     cover_output_dir = f"generated_content/{str(job.user_id)}/{str(job.job_id)}/cover_ending"
    #     if os.path.exists(cover_output_dir):
    #         cover_file = os.path.join(cover_output_dir, "cover-padded.mp4")
    #         ending_file = os.path.join(cover_output_dir, "ending-padded.mp4")
    #         if os.path.exists(cover_file):
    #             cover_files['cover'] = cover_file
    #         if os.path.exists(ending_file):
    #             cover_files['ending'] = ending_file
        
    #     if cover_files:
    #         # MODIFICATION: 动态估算
            
    #         print("🎬 Step 16: 拼接完整视频...")
            
    #         # 准备要拼接的视频文件列表（按顺序）
    #         videos_to_concat = []
            
    #         # 1. 封面视频
    #         if 'cover' in cover_files and os.path.exists(cover_files['cover']):
    #             videos_to_concat.append(cover_files['cover'])
    #             print(f"添加封面视频: {cover_files['cover']}")
            
    #         # 2. 教学内容视频
    #         if os.path.exists(mp4Path):
    #             videos_to_concat.append(mp4Path)
    #             print(f"添加教学视频: {mp4Path}")
    #         else:
    #             print(f"警告: 教学视频不存在: {mp4Path}")
            
    #         # 3. 尾页视频
    #         if 'ending' in cover_files and os.path.exists(cover_files['ending']):
    #             videos_to_concat.append(cover_files['ending'])
    #             print(f"添加尾页视频: {cover_files['ending']}")
            
    #         # 拼接的文件数 = 封面 + 教学视频 + 尾页 (最多3个)
    #         num_files = len(videos_to_concat)
    #         estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_VIDEO_CONCAT

    #         job.status = "video_concatenation"
    #         job.current_step_start_time = datetime.now().isoformat()
    #         job.current_step_estimated_time = estimated_time
    #         job.progress = 99.5
    #         job.message = "拼接完整视频..."
    #         print(f"预估最终拼接时间: {estimated_time}秒 ({num_files}个文件)")
            
            
    #         # 执行视频拼接
    #         if len(videos_to_concat) > 1:
    #             final_video_dir = os.path.join(request_output_dir, "final_video")
    #             self.ensure_directory_exists(final_video_dir)
    #             final_video_path = os.path.join(final_video_dir, f"完整课程-{_course_title}.mp4")
    #             logger.info(json.dumps({
    #                 "event": "step_start",
    #                 "step": "16_video_concatenation_final",
    #                 "message": "Concatenating final video with cover, content, and ending...",
    #                 "input_video_files": videos_to_concat,
    #                 "output_video_path": final_video_path
    #             }))
                
    #             print(f"开始拼接视频，共 {len(videos_to_concat)} 个文件")
    #             concatenated_path = self.concatenate_videos(video_files=videos_to_concat, output_path=final_video_path, logger=logger)
                
    #             if concatenated_path:
    #                 final_video_path = concatenated_path
    #                 print(f"视频拼接成功: {final_video_path}")
    #             else:
    #                 print("视频拼接失败，使用原始教学视频")
    #                 final_video_path = mp4Path
    #         else:
    #             print(f"只有 {len(videos_to_concat)} 个视频文件，无需拼接")

    #     readtxtPath = f"generated_content/{str(job.user_id)}/{str(job.job_id)}/speech"

    #     # 使用readtxt脚本合并讲稿
    #     readtxt_command = [
    #         "/home/EduAgent/miniconda3/envs/manim_env/bin/python", 
    #         "readtxt.py",
    #         readtxtPath,
    #         "--out",
    #         os.path.join(readtxtPath, "讲稿文件")
    #     ]
    #     self.run_subprocess_command(command=readtxt_command, description="合并讲稿", verbose=False, logger=logger)

    #     job.status = "completed"
    #     job.progress = 100
    #     job.message = "内容生成完成！"
        
    #     # 计算文件大小并生成最终结果
    #     final_video_size = os.path.getsize(final_video_path) if os.path.exists(final_video_path) else 0
    #     txt_size = os.path.getsize(os.path.join(readtxtPath, "讲稿文件.txt")) if os.path.exists(os.path.join(readtxtPath, "讲稿文件.txt")) else 0
    #     md_size = os.path.getsize(os.path.join(readtxtPath, "讲稿文件.md")) if os.path.exists(os.path.join(readtxtPath, "讲稿文件.md")) else 0

        
    #     # 创建结果数据
    #     result_files = [
    #         {"name": f"完整课程视频-{_course_title}-{_professor_name}.mp4", "path": final_video_path, "size": final_video_size, "type": "video"},
    #         {"name": f"完整课程讲稿文件-{_course_title}-{_professor_name}.md", "path": os.path.join(readtxtPath, "讲稿文件.md"), "size": md_size, "type": "markdown"},
    #         {"name": f"完整课程讲稿文件-{_course_title}-{_professor_name}.txt", "path": os.path.join(readtxtPath, "讲稿文件.txt"), "size": txt_size, "type": "txt"}
    #     ]
        
    #     job.result = {
    #         "keyword": job.settings.get("keyword", "unknown"),
    #         "files": result_files
    #     }
        
    #     # 销毁token
    #     token_service.use_token(job.access_token, job.job_id, str(job.user_id))
    #     logger.info(json.dumps({
    #         "event": "job_completed",
    #         "job_id": job_id,
    #         "result": job.result,
    #         "final_video_path": final_video_path,
    #         "final_video_size": final_video_size,
    #         "message": "内容生成完成！"
    #     }, ensure_ascii=False))
    #     print("✅ 生成流程完成！")

    def continue_generation_after_preview(self, job_id: str):
        """
        Users have finished previewing and chosen to continue.
        This function resumes the generation process, starting with audio-video merging.
        """
        job = self.jobs.get(job_id)
        if not job or job.status != "awaiting_preview_decision":
            return False
            
        print("🔄 User chose to continue, resuming generation process...")
        
        preview_data = job.preview_data
        video_wo_audio_output_path = preview_data["video_wo_audio_path"]
        speech_audio_output_path = preview_data["speech_audio_path"]
        
        request_output_dir = os.path.dirname(os.path.dirname(video_wo_audio_output_path))
        verbose = True

        logger = self._setup_job_logger(job_id, request_output_dir)
        logger.info(json.dumps({
            "event": "job_continue",
            "job_id": job_id,
            "message": "Resuming generation process after user preview."
        }))
        
        try:
            # Step 1: Merge audio with each individual video segment and add padding
            video_w_audio_output_path = os.path.join(request_output_dir, job_id, "video_w_audio")
            self.ensure_directory_exists(video_w_audio_output_path)
            
            num_files = len(os.listdir(video_wo_audio_output_path))
            estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_VIDEO_MERGE_INDIVIDUAL

            job.status = "individual_video_merging"
            job.current_step_start_time = datetime.now().isoformat()
            job.current_step_estimated_time = estimated_time
            job.progress = 96
            job.message = "Merging audio with video segments..."
            print(f"Estimating individual segment merge time: {estimated_time}s ({num_files} files)")
            
            merge_individual_command = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                "video_audio_merge_individual.py",
                speech_audio_output_path,
                video_wo_audio_output_path,
                video_w_audio_output_path
            ]
            
            success = self.run_subprocess_command(command=merge_individual_command, description="Merging audio with video segments", verbose=verbose, logger=logger)
            if not success:
                raise RuntimeError("Failed to merge audio with video segments.")
            
            if enable_subtitles == True:
                print("🎬 Generating subtitles...")
                video_dir = video_w_audio_output_path  # Path to the video with audio
                text_dir =  speech_output_path # Assuming text data is stored in a "text" folder
                output_dir = video_w_audio_output_path  # Path to save the generated subtitles

                # Ensure output directory exists
                self.ensure_directory_exists(output_dir)

                # Command for generating subtitles
                subtitle_command = [
                    "/home/EduAgent/miniconda3/envs/aeneas_env/bin/python", "/home/TeachMaster/ML/subtitle_generator_cn_effi.py",
                    video_dir, text_dir, output_dir
                ]

                # Run the subtitle generation process
                subtitle_generation_success = self.run_subprocess_command(command=subtitle_command, description="Generating subtitles", verbose=verbose, logger=logger)
                if not subtitle_generation_success:
                    raise RuntimeError("Failed to generate subtitles.")

                print("✅ Subtitle generation completed successfully.")
            
            # Step 2: Proceed to the final steps (concatenation, etc.)
            keywords = job.settings.get("keyword", "unknown")
            self._continue_final_steps(job_id=job_id, video_w_audio_dir=video_w_audio_output_path, request_output_dir=request_output_dir, keywords=keywords, logger=logger)
            
        except Exception as e:
            job.status = "failed"
            job.message = f"Failed to continue generation: {str(e)}"
            job.error = str(e)
            logger.exception(json.dumps({
                "event": "job_failed",
                "stage": "continuation_after_preview",
                "error": str(e)
            }))
            print(f"Continue generation failed for job {job_id}: {e}")

    def _continue_final_steps(self, job_id: str, video_w_audio_dir: str, request_output_dir: str, keywords: str, logger: logging.Logger):
        """
        Executes the final steps: concatenates all video parts (cover, segments, ending)
        and finalizes the job.
        """
        job = self.jobs[job_id]
        
        _course_title = job.settings.get("course_title", "unknown")
        _professor_name = job.settings.get("professor_name", "unknown")
        
        # --- Build the final list of videos to concatenate ---
        videos_to_concat = []
        
        # 1. Add Cover (if it exists)
        cover_output_dir = os.path.join(request_output_dir, job_id, "cover_ending")
        cover_file = os.path.join(cover_output_dir, "cover-padded.mp4")
        print("--cover_file--",cover_file)
        if os.path.exists(cover_file):
            videos_to_concat.append(cover_file)
            print(f"Adding cover video: {cover_file}")

        # 2. Add Main Content Segments (in the correct order)
        if "segment_order" in job.preview_data and job.preview_data["segment_order"]:
            print(f"Using custom segment order for concatenation: {job.preview_data['segment_order']}")
            for segment_id in job.preview_data["segment_order"]:
                segment_video_path = os.path.join(video_w_audio_dir, f"{segment_id}.mp4")
                if os.path.exists(segment_video_path):
                    videos_to_concat.append(segment_video_path)
                else:
                    print(f"⚠️ Warning: Video file for ordered segment not found: {segment_video_path}")
        else:
            # Fallback: get all padded videos and sort them naturally
            print("No custom segment order found. Concatenating all available videos in natural order.")
            all_padded_videos = sorted(glob.glob(os.path.join(video_w_audio_dir, "*-padded.mp4")))
            videos_to_concat.extend(all_padded_videos)

        # 3. Add Ending (if it exists)
        ending_file = os.path.join(cover_output_dir, job_id, "ending-padded.mp4")
        print("--end_file--",ending_file)
        if os.path.exists(ending_file):
            videos_to_concat.append(ending_file)
            print(f"Adding ending video: {ending_file}")

        # --- Perform the final concatenation ---
        final_video_path = ""
        if not videos_to_concat:
            job.status = "failed"
            job.message = "Generation failed: No video segments were found to merge."
            logger.error(json.dumps({"event": "job_failed", "message": "No video segments to concatenate."}))
            return
        elif len(videos_to_concat) == 1:
            final_video_path = os.path.join(request_output_dir,job_id, f"完整课程-{_course_title}.mp4")
            shutil.move(videos_to_concat[0], final_video_path)
            print(f"Only one segment, moving to final destination: {final_video_path}")
        else:
            num_files = len(videos_to_concat)
            estimated_time = self.BASE_OVERHEAD_TIME + num_files * self.TIME_PER_VIDEO_CONCAT
            job.status = "video_concatenation"
            job.current_step_start_time = datetime.now().isoformat()
            job.current_step_estimated_time = estimated_time
            job.progress = 99
            job.message = "Assembling final video..."
            
            final_video_path = os.path.join(request_output_dir, job_id, f"完整课程-{_course_title}.mp4")
            concatenated_path = self.concatenate_videos(video_files=videos_to_concat, output_path=final_video_path, logger=logger)
            
            if not concatenated_path:
                raise RuntimeError("Final video concatenation failed.")
        
        # --- Finalize the job (rest of the original function) ---
        readtxtPath = os.path.join(request_output_dir, job_id, "speech")
        readtxt_command = [
            "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
            "readtxt.py",
            readtxtPath,
            "--out",
            os.path.join(readtxtPath, "讲稿文件")
        ]
        self.run_subprocess_command(command=readtxt_command, description="Merging transcripts", verbose=False, logger=logger)

        job.status = "completed"
        job.progress = 100
        job.message = "Content generation complete!"
        
        final_video_size = os.path.getsize(final_video_path) if os.path.exists(final_video_path) else 0
        txt_path = os.path.join(readtxtPath, "讲稿文件.txt")
        md_path = os.path.join(readtxtPath, "讲稿文件.md")
        txt_size = os.path.getsize(txt_path) if os.path.exists(txt_path) else 0
        md_size = os.path.getsize(md_path) if os.path.exists(md_path) else 0

        result_files = [
            {"name": f"完整课程视频-{_course_title}-{_professor_name}.mp4", "path": final_video_path, "size": final_video_size, "type": "video"},
            {"name": f"完整课程讲稿文件-{_course_title}-{_professor_name}.md", "path": md_path, "size": md_size, "type": "markdown"},
            {"name": f"完整课程讲稿文件-{_course_title}-{_professor_name}.txt", "path": txt_path, "size": txt_size, "type": "txt"}
        ]
        
        job.result = {
            "keyword": job.settings.get("keyword", "unknown"),
            "files": result_files
        }
        
        token_service.use_token(job.access_token, job.job_id, str(job.user_id))
        logger.info(json.dumps({
            "event": "job_completed",
            "result": job.result,
        }, ensure_ascii=False))
        print("✅ Generation process complete!")

    def _fix_background_image_paths_in_code_file(self, code_file_path: str):
        """
        修复代码文件中的背景图片路径，确保使用绝对路径
        """
        try:
            print(f"🔧 修复背景图片路径: {code_file_path}")
            
            # 读取代码文件
            with open(code_file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 查找ImageMobject调用中的相对路径
            import re
            pattern = r'ImageMobject\("([^"]+)"\)'
            matches = re.findall(pattern, content)
            
            backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            modified = False
            
            for image_path in matches:
                # 如果是相对路径，尝试转换为绝对路径
                if not os.path.isabs(image_path):
                    print(f"   发现相对路径: {image_path}")
                    
                    # 尝试多个可能的位置
                    possible_paths = [
                        os.path.join(backend_dir, image_path),  # backend/目录
                        os.path.join(os.path.dirname(backend_dir), image_path),  # 项目根目录
                        os.path.join(os.path.dirname(code_file_path), image_path),  # 代码文件同目录
                    ]
                    
                    found_path = None
                    for possible_path in possible_paths:
                        if os.path.exists(possible_path):
                            found_path = possible_path
                            print(f"   ✅ 找到图片: {found_path}")
                            break
                    
                    if found_path:
                        # 替换路径
                        old_pattern = f'ImageMobject("{image_path}")'
                        new_pattern = f'ImageMobject("{found_path}")'
                        content = content.replace(old_pattern, new_pattern)
                        modified = True
                        print(f"   🔄 替换: {image_path} -> {found_path}")
                    else:
                        print(f"   ⚠️ 找不到图片文件: {image_path}")
                        print(f"   尝试的路径: {possible_paths}")
            
            # 如果有修改，写回文件
            if modified:
                with open(code_file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"✅ 背景图片路径修复完成")
            else:
                print(f"📁 无需修复背景图片路径")
                
        except Exception as e:
            print(f"⚠️ 修复背景图片路径时发生错误: {e}")
            # 不中断主流程
            import traceback
            traceback.print_exc()

    def _cleanup_media_folders_after_render(self, manim_code_final_output_path: str):
        """
        清理渲染过程中产生的media文件夹
        """
        try:
            # 1. 清理manim_codes_final目录中的media文件夹
            manim_media_dir = os.path.join(manim_code_final_output_path, "media")
            if os.path.exists(manim_media_dir):
                print(f"🧹 清理manim_codes_final中的media目录: {manim_media_dir}")
                shutil.rmtree(manim_media_dir)
                print(f"✅ 清理完成")
            else:
                print(f"📁 manim_codes_final中无media目录需要清理")
            
            # 2. 清理backend目录中的media文件夹（如果存在）
            backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            backend_media_dir = os.path.join(backend_dir, "media")
            if os.path.exists(backend_media_dir):
                print(f"🧹 清理backend中的media目录: {backend_media_dir}")
                shutil.rmtree(backend_media_dir)
                print(f"✅ 清理完成")
            else:
                print(f"📁 backend中无media目录需要清理")
                
            # 3. 清理可能存在的其他临时media目录
            # 检查manim_codes_final目录下所有子目录
            if os.path.exists(manim_code_final_output_path):
                for item in os.listdir(manim_code_final_output_path):
                    item_path = os.path.join(manim_code_final_output_path, item)
                    if os.path.isdir(item_path) and item == "media":
                        print(f"🧹 清理发现的额外media目录: {item_path}")
                        shutil.rmtree(item_path)
                        
        except Exception as e:
            print(f"⚠️ 清理media文件夹时发生错误: {e}")
            # 不中断主流程，只记录错误
            import traceback
            traceback.print_exc()

    def save_manim_code(self, job_id: str, segment_id: str, code_content: str) -> bool:
        """
        保存编辑后的Manim代码到文件
        """
        job = self.jobs.get(job_id)
        if not job or job.status != "awaiting_preview_decision":
            return False
            
        try:
            # 获取代码文件路径
            preview_data = job.preview_data
            manim_code_path = preview_data["manim_code_path"]
            
            # 构建代码文件路径
            code_file_path = os.path.join(manim_code_path, f"{segment_id}.py")
            
            # 保存代码到文件
            with open(code_file_path, 'w', encoding='utf-8') as f:
                f.write(code_content)
            
            print(f"✅ 代码保存成功: {code_file_path}")
            return True
            
        except Exception as e:
            print(f"❌ 保存代码失败: {e}")
            return False

    def save_original_script_content(self, job_id: str, segment_id: str, script_content: str) -> bool:
        """
        保存编辑后的原始讲稿内容到原始讲稿目录
        """
        job = self.jobs.get(job_id)
        if not job or job.status != "awaiting_preview_decision":
            return False
            
        try:
            # 获取原始讲稿文件路径
            preview_data = job.preview_data
            original_speech_script_path = preview_data.get("speech_script_original_path")
            
            if not original_speech_script_path:
                print(f"❌ 原始讲稿路径不存在")
                return False
            
            # 构建原始讲稿文件路径
            script_file_path = os.path.join(original_speech_script_path, f"{segment_id}.txt")
            
            # 保存讲稿到原始目录
            with open(script_file_path, 'w', encoding='utf-8') as f:
                f.write(script_content)
            
            print(f"✅ 原始讲稿保存成功: {script_file_path}")
            return True
            
        except Exception as e:
            print(f"❌ 保存原始讲稿失败: {e}")
            return False

    def save_script_content(self, job_id: str, segment_id: str, script_content: str) -> bool:
        """
        保存编辑后的讲稿内容到文件
        """
        job = self.jobs.get(job_id)
        if not job or job.status != "awaiting_preview_decision":
            return False
            
        try:
            # 获取讲稿文件路径
            preview_data = job.preview_data
            speech_script_path = preview_data["speech_script_path"]
            
            # 构建讲稿文件路径
            script_file_path = os.path.join(speech_script_path, f"{segment_id}.txt")
            
            # 保存讲稿到文件
            with open(script_file_path, 'w', encoding='utf-8') as f:
                f.write(script_content)
            
            print(f"✅ 讲稿保存成功: {script_file_path}")
            return True
            
        except Exception as e:
            print(f"❌ 保存讲稿失败: {e}")
            return False

    def regenerate_audio_segment(self, job_id: str, segment_id: str, logger: logging.Logger) -> bool:
        """
        重新生成指定片段的音频
        """
        job = self.jobs.get(job_id)
        if not job or job.status != "awaiting_preview_decision":
            print(f"❌ 任务不存在或不在预览状态: {job_id}")
            return False
        output_root_path = "generated_content"
        request_output_dir = os.path.join(output_root_path, str(job.user_id), str(job_id))
        logger = self._setup_job_logger(job_id, request_output_dir)
        try:
            # 获取相关路径
            preview_data = job.preview_data
            if not preview_data:
                print(f"❌ 预览数据不存在: {job_id}")
                return False
                
            speech_script_path = preview_data.get("speech_script_path")
            speech_audio_path = preview_data.get("speech_audio_path")
            video_wo_audio_path = preview_data.get("video_wo_audio_path")
            
            # 验证所有必需路径存在
            if not all([speech_script_path, speech_audio_path, video_wo_audio_path]):
                print(f"❌ 缺少必需的路径信息")
                return False
            
            print(f"🎵 开始重新生成音频片段: {segment_id}")
            
            # 构建讲稿文件路径
            script_file_path = os.path.join(speech_script_path, f"{segment_id}.txt")
            print(f"📝 讲稿文件路径: {script_file_path}")
            
            # 验证讲稿文件存在
            if not os.path.exists(script_file_path):
                print(f"❌ 讲稿文件不存在: {script_file_path}")
                return False
            
            # 创建临时目录用于单个音频生成
            temp_input_dir = os.path.join(os.path.dirname(speech_audio_path), f"temp_input_{segment_id}")
            temp_output_dir = os.path.join(os.path.dirname(speech_audio_path), f"temp_output_{segment_id}")
            
            try:
                # 创建临时目录
                os.makedirs(temp_input_dir, exist_ok=True)
                os.makedirs(temp_output_dir, exist_ok=True)
                
                # 复制讲稿文件到临时输入目录
                temp_script_file = os.path.join(temp_input_dir, f"{segment_id}.txt")
                shutil.copy2(script_file_path, temp_script_file)
                
                # 获取参考音频和文本路径
                DEFAULT_WAV_PATH = "/home/EduPal_v2/junhaoge/EduPal_v2/ML/UploadFiles/source/Prof_Chen.wav"
                DEFAULT_WAV_PROMPT_PATH = "/home/EduPal_v2/junhaoge/EduPal_v2/ML/UploadFiles/source/Prof_Chen.txt"
                
                wav_path = job.settings.get("reference_audio", DEFAULT_WAV_PATH)
                wav_prompt_path = job.settings.get("reference_text", DEFAULT_WAV_PROMPT_PATH)
                
                # 读取参考文本
                prompt_txt = ""
                if os.path.exists(wav_prompt_path):
                    with open(wav_prompt_path, 'r', encoding='utf-8') as f:
                        prompt_txt = f.read().strip()
                
                # 调用 CosyVoice 生成音频文件
                cosyvoice_command = [
                    "/home/EduAgent/miniconda3/envs/cosyvoice/bin/python",
                    "/home/EduAgent/services/cosyvoice/run_cosyvoice_dynamic.py",
                    temp_input_dir,
                    temp_output_dir,
                    "--prompt_wav", wav_path,
                    "--prompt_text", prompt_txt,
                ]
                
                print(f"🔧 音频生成命令: {' '.join(cosyvoice_command)}")
                
                success = self.run_subprocess_command(command=cosyvoice_command, description=f"生成{segment_id}音频", logger=logger)
                
                if not success:
                    print(f"❌ 音频生成命令执行失败")
                    return False
                
                # 查找生成的音频文件
                generated_audio_files = [f for f in os.listdir(temp_output_dir) if f.endswith('.wav')]
                if not generated_audio_files:
                    print(f"❌ 未找到生成的音频文件")
                    return False
                
                # 移动新音频文件到目标位置
                target_audio_path = os.path.join(speech_audio_path, f"{segment_id}.wav")
                source_audio_path = os.path.join(temp_output_dir, generated_audio_files[0])
                
                # 备份原音频文件
                if os.path.exists(target_audio_path):
                    backup_path = target_audio_path + ".backup"
                    shutil.copy2(target_audio_path, backup_path)
                    print(f"💾 备份原音频: {backup_path}")
                
                # 复制新音频文件
                shutil.copy2(source_audio_path, target_audio_path)
                print(f"✅ 新音频已复制到目标位置: {target_audio_path}")
                
                # 重新合并音频和视频
                print(f"🎬 开始重新合并音视频...")
                
                video_file_path = os.path.join(video_wo_audio_path, f"{segment_id}.mp4")
                if not os.path.exists(video_file_path):
                    print(f"⚠️ 视频文件不存在，跳过音视频合并: {video_file_path}")
                    return True
                
                # 创建临时输出文件
                temp_merged_path = video_file_path + ".temp.mp4"
                
                # 音视频合并命令
                backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                merge_script_path = os.path.join(backend_dir, "video_audio_merge_single.py")
                
                if os.path.exists(merge_script_path):
                    merge_command = [
                        "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                        merge_script_path,
                        target_audio_path,        # 音频文件
                        video_file_path,         # 视频文件  
                        temp_merged_path         # 输出文件
                    ]
                    
                    print(f"🔧 音视频合并命令: {' '.join(merge_command)}")
                    
                    # 执行合并命令
                    import subprocess
                    try:
                        result = subprocess.run(
                            merge_command, 
                            cwd=backend_dir,
                            capture_output=True, 
                            text=True, 
                            check=False
                        )
                        
                        if result.returncode == 0 and os.path.exists(temp_merged_path):
                            # 替换原视频文件
                            shutil.move(temp_merged_path, video_file_path)
                            print(f"✅ 音视频合并成功: {video_file_path}")
                        else:
                            print(f"⚠️ 音视频合并失败，使用原视频")
                            if result.stderr:
                                print(f"合并错误: {result.stderr}")
                                
                    except Exception as e:
                        print(f"⚠️ 执行音视频合并时发生异常: {str(e)}")
                else:
                    print(f"⚠️ 音视频合并脚本不存在: {merge_script_path}")
                
                print(f"🎉 音频重新生成完成: {segment_id}")
                return True
                
            finally:
                # 清理临时目录
                if os.path.exists(temp_input_dir):
                    shutil.rmtree(temp_input_dir)
                if os.path.exists(temp_output_dir):
                    shutil.rmtree(temp_output_dir)
                print(f"🧹 临时目录清理完成")
            
        except Exception as e:
            print(f"❌ 重新生成音频失败: {e}")
            import traceback
            traceback.print_exc()
            return False

    def regenerate_video_segment(self, job_id: str, segment_id: str) -> bool:
        """
        重新生成指定的视频片段
        """
        job = self.jobs.get(job_id)
        if not job or job.status != "awaiting_preview_decision":
            print(f"❌ 任务不存在或不在预览状态: {job_id}")
            return False
            
        try:
            # 获取相关路径
            preview_data = job.preview_data
            if not preview_data:
                print(f"❌ 预览数据不存在: {job_id}")
                return False
                
            manim_code_path = preview_data.get("manim_code_path")
            video_wo_audio_path = preview_data.get("video_wo_audio_path")
            speech_audio_path = preview_data.get("speech_audio_path")
            
            # 验证所有必需路径存在
            if not all([manim_code_path, video_wo_audio_path, speech_audio_path]):
                print(f"❌ 缺少必需的路径信息")
                print(f"Manim代码路径: {manim_code_path}")
                print(f"视频输出路径: {video_wo_audio_path}")
                print(f"音频路径: {speech_audio_path}")
                return False
            
            # 验证目录存在 - 处理相对路径
            backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            print(f"🔧 Backend目录: {backend_dir}")
            
            for path_name, path_value in [
                ("Manim代码目录", manim_code_path),
                ("视频输出目录", video_wo_audio_path),
                ("音频目录", speech_audio_path)
            ]:
                print(f"🔍 正在查找{path_name}: {path_value}")
                # 尝试不同的路径解析方式，优先使用绝对路径
                possible_paths = [
                    os.path.join(backend_dir, path_value),  # 基于backend目录 (绝对路径)
                    os.path.join(os.path.dirname(backend_dir), path_value),  # 基于backend父目录 (绝对路径)
                    os.path.abspath(path_value),  # 基于当前工作目录的绝对路径
                    path_value,  # 原始路径 (可能是相对路径)
                ]
                
                found_path = None
                print(f"   尝试的路径:")
                for test_path in possible_paths:
                    exists = os.path.exists(test_path)
                    print(f"     - {test_path} {'✅' if exists else '❌'}")
                    if exists and not found_path:
                        found_path = test_path  # 选择第一个存在的路径（已经是绝对路径优先）
                
                if not found_path:
                    print(f"❌ {path_name}不存在")
                    return False
                else:
                    print(f"✅ 找到{path_name}: {found_path}")
                    # 更新路径为找到的绝对路径
                    if path_name == "Manim代码目录":
                        manim_code_path = found_path
                    elif path_name == "视频输出目录":
                        video_wo_audio_path = found_path
                    elif path_name == "音频目录":
                        speech_audio_path = found_path
            
            # 确保所有路径都是绝对路径
            manim_code_path = os.path.abspath(manim_code_path)
            video_wo_audio_path = os.path.abspath(video_wo_audio_path)
            speech_audio_path = os.path.abspath(speech_audio_path)
            
            print(f"🔧 最终使用的绝对路径:")
            print(f"   Manim代码目录: {manim_code_path}")
            print(f"   视频输出目录: {video_wo_audio_path}")
            print(f"   音频目录: {speech_audio_path}")
            
            # 1. 重新渲染Manim视频（无音频）
            print(f"🎬 开始重新渲染视频片段: {segment_id}")
            
            # 构建代码文件路径 - 使用绝对路径
            code_file_path = os.path.join(manim_code_path, f"{segment_id}.py")
            print(f"📝 代码文件绝对路径: {code_file_path}")
            
            # 验证文件存在
            if not os.path.exists(code_file_path):
                print(f"❌ 代码文件不存在: {code_file_path}")
                return False
            
            # 修复代码文件中的背景图片路径
            self._fix_background_image_paths_in_code_file(code_file_path)
            
            # 清理旧的media目录避免冲突
            media_dir = os.path.join(backend_dir, "media")
            if os.path.exists(media_dir):
                print(f"🧹 清理旧的media目录: {media_dir}")
                shutil.rmtree(media_dir)
            
            # 使用最简单的Manim命令，传入绝对路径避免工作目录问题
            render_command = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                "-m", "manim",
                "render",
                code_file_path,  # 使用绝对路径
                "-q", "h",
                "--format", "mp4"
            ]
            
            print(f"🔧 渲染命令: {' '.join(render_command)}")
            
            # 执行命令 - 现在使用绝对路径，工作目录不重要
            import subprocess
            try:
                print(f"⏱️ 开始执行渲染命令（超时：10分钟）...")
                result = subprocess.run(
                    render_command, 
                    cwd=backend_dir,  # 保持在backend目录，让media输出到正确位置
                    capture_output=True, 
                    text=True, 
                    check=False,
                    timeout=600  # 10分钟超时
                )
                
                if result.returncode != 0:
                    print(f"❌ 渲染命令失败:")
                    print(f"返回码: {result.returncode}")
                    if result.stdout:
                        print(f"标准输出: {result.stdout}")
                    if result.stderr:
                        print(f"标准错误: {result.stderr}")
                    return False
                    
                print(f"✅ 渲染命令执行成功")
                
            except subprocess.TimeoutExpired:
                print(f"❌ 渲染命令超时（10分钟），可能是Manim代码存在问题")
                print(f"💡 建议检查代码语法或复杂度")
                return False
            except Exception as e:
                print(f"❌ 执行渲染命令时发生异常: {str(e)}")
                return False
            
            # 2. 查找生成的视频文件
            rendered_video = None
            
            # Manim默认输出路径
            expected_media_dir = os.path.join(backend_dir, "media", "videos")
            print(f"🔍 在默认media目录查找视频: {expected_media_dir}")
            
            if os.path.exists(expected_media_dir):
                # 递归查找最新的mp4文件
                latest_video = None
                latest_time = 0
                found_videos = []
                
                for root, dirs, files in os.walk(expected_media_dir):
                    print(f"📂 检查目录: {root}")
                    for file in files:
                        if file.endswith('.mp4'):
                            file_path = os.path.join(root, file)
                            try:
                                file_time = os.path.getmtime(file_path)
                                file_size = os.path.getsize(file_path)
                                found_videos.append((file_path, file_time, file_size))
                                print(f"🎬 找到视频: {file_path}")
                                print(f"   修改时间: {file_time}, 文件大小: {file_size} bytes")
                                
                                if file_time > latest_time:
                                    latest_time = file_time
                                    latest_video = file_path
                            except (OSError, IOError) as e:
                                print(f"⚠️ 无法访问文件 {file_path}: {e}")
                                continue
                
                print(f"📊 总共找到 {len(found_videos)} 个视频文件")
                if latest_video:
                    rendered_video = latest_video
                    print(f"✅ 选择最新视频: {rendered_video}")
                elif found_videos:
                    # 如果时间戳相同，选择文件大小最大的
                    rendered_video = max(found_videos, key=lambda x: (x[1], x[2]))[0]
                    print(f"✅ 选择最大视频文件: {rendered_video}")
            else:
                print(f"❌ Media目录不存在: {expected_media_dir}")
            
            if not rendered_video:
                print(f"❌ 找不到渲染后的视频文件")
                print(f"💡 可能的原因:")
                print(f"   1. Manim代码语法错误")
                print(f"   2. 渲染过程中发生错误")
                print(f"   3. 输出路径配置问题")
                # 清理media目录
                if os.path.exists(media_dir):
                    shutil.rmtree(media_dir)
                return False
            
            # 3. 将新视频复制到目标位置
            target_video_path = os.path.join(video_wo_audio_path, f"{segment_id}.mp4")
            print(f"📋 复制视频: {rendered_video} -> {target_video_path}")
            
            # 备份原视频
            if os.path.exists(target_video_path):
                backup_path = target_video_path + ".backup"
                shutil.copy2(target_video_path, backup_path)
                print(f"💾 备份原视频: {backup_path}")
            
            # 复制新视频
            shutil.copy2(rendered_video, target_video_path)
            print(f"✅ 新视频已复制到目标位置")
            
            # 4. 重新合并音频和新视频
            print(f"🎵 开始重新合并音频...")
            
            audio_file_path = os.path.join(speech_audio_path, f"{segment_id}.wav")
            if not os.path.exists(audio_file_path):
                print(f"⚠️ 音频文件不存在，跳过音频合并: {audio_file_path}")
                # 清理media目录
                if os.path.exists(media_dir):
                    shutil.rmtree(media_dir)
                return True
            
            # 创建临时输出文件
            temp_output_path = target_video_path + ".temp.mp4"
            
            # 音视频合并命令 - 确保在backend目录执行
            merge_script_path = os.path.join(backend_dir, "video_audio_merge_single.py")
            if not os.path.exists(merge_script_path):
                print(f"⚠️ 音频合并脚本不存在: {merge_script_path}")
                print(f"⚠️ 跳过音频合并，使用无音频版本")
                # 清理media目录
                if os.path.exists(media_dir):
                    shutil.rmtree(media_dir)
                return True
            
            merge_command = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                merge_script_path,
                audio_file_path,        # 音频文件
                target_video_path,      # 视频文件  
                temp_output_path        # 输出文件
            ]
            
            print(f"🔧 音频合并命令: {' '.join(merge_command)}")
            
            # 使用subprocess.run直接执行，确保在backend目录执行
            try:
                result = subprocess.run(
                    merge_command, 
                    cwd=backend_dir,  # 确保在backend目录执行
                    capture_output=True, 
                    text=True, 
                    check=False
                )
                
                if result.returncode != 0:
                    print(f"⚠️ 音频合并命令失败:")
                    print(f"返回码: {result.returncode}")
                    if result.stdout:
                        print(f"标准输出: {result.stdout}")
                    if result.stderr:
                        print(f"标准错误: {result.stderr}")
                    print(f"⚠️ 使用无音频版本")
                    merge_success = False
                else:
                    print(f"✅ 音频合并命令执行成功")
                    merge_success = True
                    
            except Exception as e:
                print(f"⚠️ 执行音频合并命令时发生异常: {str(e)}")
                print(f"⚠️ 使用无音频版本")
                merge_success = False
            
            if merge_success and os.path.exists(temp_output_path):
                # 替换原视频文件
                shutil.move(temp_output_path, target_video_path)
                print(f"✅ 音视频合并成功: {target_video_path}")
            else:
                print(f"⚠️ 音视频合并失败，使用无音频版本")
            
            # 5. 清理临时media目录
            if os.path.exists(media_dir):
                shutil.rmtree(media_dir)
                print(f"🧹 清理临时目录完成")
            
            print(f"🎉 视频片段重新生成完成: {segment_id}")
            return True
            
        except Exception as e:
            print(f"❌ 重新生成视频片段失败: {e}")
            import traceback
            traceback.print_exc()
            return False

    def reprocess_segment_complete(self, job_id: str, segment_id: str) -> bool:
        """
        完整重新处理指定的片段
        包括：语音生成 -> 与原始manim_code打断点 -> 对齐 -> 添加背景 -> 渲染
        """
        job = self.jobs.get(job_id)
        if not job or job.status != "awaiting_preview_decision":
            print(f"❌ 任务不存在或不在预览状态: {job_id}")
            return False
        
        output_root_path = "generated_content"
        request_output_dir = os.path.join(output_root_path, str(job.user_id), str(job_id))
        logger = self._setup_job_logger(job_id, request_output_dir)
            
        try:
            print(f"🔄 开始完整重新处理片段: {segment_id}")
            
            # 获取相关路径
            preview_data = job.preview_data
            if not preview_data:
                print(f"❌ 预览数据不存在: {job_id}")
                return False
                
            original_speech_script_path = preview_data.get("speech_script_original_path")
            original_manim_code_path = preview_data.get("manim_code_path").replace("_final", "")  # 获取原始代码路径
            speech_audio_path = preview_data.get("speech_audio_path")
            video_wo_audio_path = preview_data.get("video_wo_audio_path")
            
            # 验证所有必需路径存在
            if not all([original_speech_script_path, original_manim_code_path, speech_audio_path, video_wo_audio_path]):
                print(f"❌ 缺少必需的路径信息")
                return False
            
            # 构建文件路径
            script_file_path = os.path.join(original_speech_script_path, f"{segment_id}.txt")
            original_code_file_path = os.path.join(original_manim_code_path, f"{segment_id}.py")
            
            # 验证原始文件存在
            if not os.path.exists(script_file_path):
                print(f"❌ 原始讲稿文件不存在: {script_file_path}")
                return False
                
            if not os.path.exists(original_code_file_path):
                print(f"❌ 原始代码文件不存在: {original_code_file_path}")
                return False
            
            # 获取工作目录
            request_output_dir = os.path.dirname(os.path.dirname(speech_audio_path))
            print(f"📁 工作目录: {request_output_dir}")
            
            # 第1步：为单个片段重新生成语音
            print(f"🎵 第1步: 重新生成语音...")
            logger.info(json.dumps({
                "event": "regenerate_speech_single",
                "job_id": job_id,
                "message": "start regenerate speech single"
            }))
            success = self._regenerate_single_speech(segment_id, script_file_path, speech_audio_path, job.settings, logger=logger)
            if not success:
                print(f"❌ 语音生成失败")
                return False
            
            # 第2步：重新插入断点（只针对这一个片段）
            print(f"🔧 第2步: 重新插入断点...")
            logger.info(json.dumps({
                "event": "reinsert_breakpoints_single",
                "job_id": job_id,
                "message": "start reinsert breakpoints single"
            }))
            refined_output_path = os.path.join(request_output_dir, "manim_codes_refined")
            success = self._reinsert_breakpoints_single(segment_id, original_code_file_path, script_file_path, refined_output_path, logger=logger)
            if not success:
                print(f"❌ 断点插入失败")
                return False
            
            # 第3步：重新生成等待时间
            print(f"⏱️ 第3步: 重新生成等待时间...")
            logger.info(json.dumps({
                "event": "regenerate_wait_time_single",
                "job_id": job_id,
                "message": "start regenerate wait time single"
            }))
            final_output_path = os.path.join(request_output_dir, "manim_codes_final")
            success = self._regenerate_wait_time_single(segment_id, speech_audio_path, refined_output_path, final_output_path, logger=logger)
            if not success:
                print(f"❌ 等待时间生成失败")
                return False
            
            # 第4步：添加背景
            print(f"🖼️ 第4步: 重新添加背景...")
            logger.info(json.dumps({
                "event": "add_background_single",
                "job_id": job_id,
                "message": "start add background single"
            }))
            final_code_file_path = os.path.join(final_output_path, f"{segment_id}.py")
            background_image = job.settings.get("background_image", "/home/EduPal_v2/jiezhang/web-app/backend/background_default.png")
            self._add_background_single(final_code_file_path, background_image, logger=logger)
            
            # 第5步：重新渲染视频
            print(f"🎬 第5步: 重新渲染视频...")
            logger.info(json.dumps({
                "event": "render_single_video",
                "job_id": job_id,
                "message": "start render single video"
            }))
            success = self.__render_single_video(segment_id, final_code_file_path, video_wo_audio_path, logger=logger)
            if not success:
                print(f"❌ 视频渲染失败")
                return False
            
            # 第6步：重新合并音视频
            print(f"🎞️ 第6步: 重新合并音视频...")
            logger.info(json.dumps({
                "event": "merge_single_audio_video",
                "job_id": job_id,
                "message": "start merge single audio video"
            }))
            success = self._merge_single_audio_video(segment_id, speech_audio_path, video_wo_audio_path, logger=logger)
            if not success:
                print(f"⚠️ 音视频合并失败，但视频已重新渲染")
            
            print(f"✅ 片段完整重新处理完成: {segment_id}")
            return True
            
        except Exception as e:
            print(f"❌ 完整重新处理片段失败: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _regenerate_single_speech(self, segment_id: str, script_file_path: str, speech_audio_path: str, settings: dict, logger=logging.Logger) -> bool:
        """为单个片段重新生成语音"""
        try:
            # 创建临时目录用于单个音频生成
            temp_input_dir = os.path.join(os.path.dirname(speech_audio_path), f"temp_input_{segment_id}")
            temp_output_dir = os.path.join(os.path.dirname(speech_audio_path), f"temp_output_{segment_id}")
            
            try:
                # 创建临时目录
                os.makedirs(temp_input_dir, exist_ok=True)
                os.makedirs(temp_output_dir, exist_ok=True)
                
                # 复制讲稿文件到临时输入目录
                temp_script_file = os.path.join(temp_input_dir, f"{segment_id}.txt")
                shutil.copy2(script_file_path, temp_script_file)
                
                # 获取参考音频和文本路径
                DEFAULT_WAV_PATH = "/home/EduPal_v2/junhaoge/EduPal_v2/ML/UploadFiles/source/Prof_Chen.wav"
                DEFAULT_WAV_PROMPT_PATH = "/home/EduPal_v2/junhaoge/EduPal_v2/ML/UploadFiles/source/Prof_Chen.txt"
                
                wav_path = settings.get("reference_audio", DEFAULT_WAV_PATH)
                wav_prompt_path = settings.get("reference_text", DEFAULT_WAV_PROMPT_PATH)
                
                # 读取参考文本
                prompt_txt = ""
                if os.path.exists(wav_prompt_path):
                    with open(wav_prompt_path, 'r', encoding='utf-8') as f:
                        prompt_txt = f.read().strip()
                
                # 调用 CosyVoice 生成音频文件
                cosyvoice_command = [
                    "/home/EduAgent/miniconda3/envs/cosyvoice/bin/python",
                    "/home/EduAgent/services/cosyvoice/run_cosyvoice_dynamic.py",
                    temp_input_dir,
                    temp_output_dir,
                    "--prompt_wav", wav_path,
                    "--prompt_text", prompt_txt,
                ]
                
                success = self.run_subprocess_command(command=cosyvoice_command, description=f"生成{segment_id}语音", verbose=True, logger=logger)
                
                if not success:
                    print(f"❌ 音频生成命令执行失败")
                    return False
                
                # 查找生成的音频文件
                generated_audio_files = [f for f in os.listdir(temp_output_dir) if f.endswith('.wav')]
                if not generated_audio_files:
                    print(f"❌ 未找到生成的音频文件")
                    return False
                
                # 移动新音频文件到目标位置
                target_audio_path = os.path.join(speech_audio_path, f"{segment_id}.wav")
                source_audio_path = os.path.join(temp_output_dir, generated_audio_files[0])
                
                # 备份原音频文件
                if os.path.exists(target_audio_path):
                    backup_path = target_audio_path + ".backup"
                    shutil.copy2(target_audio_path, backup_path)
                    print(f"💾 备份原音频: {backup_path}")
                
                # 复制新音频文件
                shutil.copy2(source_audio_path, target_audio_path)
                print(f"✅ 新音频已复制到目标位置: {target_audio_path}")
                
                return True
                
            finally:
                # 清理临时目录
                if os.path.exists(temp_input_dir):
                    shutil.rmtree(temp_input_dir)
                if os.path.exists(temp_output_dir):
                    shutil.rmtree(temp_output_dir)
                    
        except Exception as e:
            print(f"❌ 重新生成单个语音失败: {e}")
            return False

    def _reinsert_breakpoints_single(self, segment_id: str, original_code_file_path: str, script_file_path: str, refined_output_path: str, logger=logging.Logger) -> bool:
        """为单个片段重新插入断点"""
        try:
            # 确保输出目录存在
            os.makedirs(refined_output_path, exist_ok=True)
            refined_code_dir = os.path.join(refined_output_path, "Code")
            refined_speech_dir = os.path.join(refined_output_path, "Speech")
            os.makedirs(refined_code_dir, exist_ok=True)
            os.makedirs(refined_speech_dir, exist_ok=True)
            
            # 创建临时目录结构用于断点插入器
            temp_code_dir = os.path.join(refined_output_path, f"temp_code_{segment_id}")
            temp_speech_dir = os.path.join(refined_output_path, f"temp_speech_{segment_id}")
            
            try:
                os.makedirs(temp_code_dir, exist_ok=True)
                os.makedirs(temp_speech_dir, exist_ok=True)
                
                # 复制单个文件到临时目录
                shutil.copy2(original_code_file_path, os.path.join(temp_code_dir, f"{segment_id}.py"))
                shutil.copy2(script_file_path, os.path.join(temp_speech_dir, f"{segment_id}.txt"))
                
                # 使用断点插入器处理单个片段
                if self.manimBreakpointInserter:
                    temp_output_dir = os.path.join(refined_output_path, f"temp_output_{segment_id}")
                    os.makedirs(temp_output_dir, exist_ok=True)
                    
                    self.manimBreakpointInserter.pipeline(temp_code_dir, temp_speech_dir, temp_output_dir)
                    
                    # 复制处理后的文件到最终位置
                    temp_refined_code_dir = os.path.join(temp_output_dir, "Code")
                    temp_refined_speech_dir = os.path.join(temp_output_dir, "Speech")
                    
                    if os.path.exists(os.path.join(temp_refined_code_dir, f"{segment_id}.py")):
                        shutil.copy2(os.path.join(temp_refined_code_dir, f"{segment_id}.py"), 
                                   os.path.join(refined_code_dir, f"{segment_id}.py"))
                    
                    if os.path.exists(os.path.join(temp_refined_speech_dir, f"{segment_id}.txt")):
                        shutil.copy2(os.path.join(temp_refined_speech_dir, f"{segment_id}.txt"), 
                                   os.path.join(refined_speech_dir, f"{segment_id}.txt"))
                    
                    # 清理临时输出
                    if os.path.exists(temp_output_dir):
                        shutil.rmtree(temp_output_dir)
                    
                    print(f"✅ 断点插入完成: {segment_id}")
                    return True
                else:
                    print(f"❌ 断点插入器不可用")
                    return False
                    
            finally:
                # 清理临时目录
                if os.path.exists(temp_code_dir):
                    shutil.rmtree(temp_code_dir)
                if os.path.exists(temp_speech_dir):
                    shutil.rmtree(temp_speech_dir)
                    
        except Exception as e:
            print(f"❌ 重新插入断点失败: {e}")
            return False

    def _regenerate_wait_time_single(self, segment_id: str, speech_audio_path: str, refined_output_path: str, final_output_path: str, logger=logging.Logger) -> bool:
        """为单个片段重新生成等待时间"""
        try:
            # 确保输出目录存在
            os.makedirs(final_output_path, exist_ok=True)
            
            # 获取语音时间文件
            speech_time_file_path = os.path.join(speech_audio_path, "speech.txt")
            if not os.path.exists(speech_time_file_path):
                print(f"❌ 语音时间文件不存在: {speech_time_file_path}")
                return False
            
            refined_code_dir = os.path.join(refined_output_path, "Code")
            refined_speech_dir = os.path.join(refined_output_path, "Speech")
            
            if self.manimAutoWaitGenerator:
                # 调用等待时间生成器处理单个片段
                self.manimAutoWaitGenerator.pipeline(speech_time_file_path, refined_speech_dir, refined_code_dir, final_output_path)
                print(f"✅ 等待时间生成完成: {segment_id}")
                return True
            else:
                print(f"❌ 等待时间生成器不可用")
                # 如果生成器不可用，直接复制refined文件
                refined_file = os.path.join(refined_code_dir, f"{segment_id}.py")
                final_file = os.path.join(final_output_path, f"{segment_id}.py")
                if os.path.exists(refined_file):
                    shutil.copy2(refined_file, final_file)
                    return True
                return False
                
        except Exception as e:
            print(f"❌ 重新生成等待时间失败: {e}")
            return False

    def _add_background_single(self, code_file_path: str, background_image: str, logger=logging.Logger):
        """为单个代码文件添加背景"""
        try:
            # 确保代码文件存在
            if not os.path.exists(code_file_path):
                print(f"❌ 代码文件不存在: {code_file_path}")
                return
                
            # 复制背景图片到代码文件目录（如果需要）
            code_dir = os.path.dirname(code_file_path)
            image_filename = None
            if not self.is_color(background_image):
                image_filename = self.copy_image_to_target_dir(background_image, code_dir)
            
            # 生成背景代码
            bg_code = self.build_background_code(background_image, image_filename)
            
            # 插入背景代码
            self.insert_background_code(code_file_path, bg_code)
            print(f"✅ 背景添加完成: {os.path.basename(code_file_path)}")
            
        except Exception as e:
            print(f"❌ 添加背景失败: {e}")

    def __render_single_video(self, segment_id: str, code_file_path: str, video_output_path: str, logger=logging.Logger) -> bool:
        """为单个代码文件渲染视频"""
        try:
            # 修复代码文件中的背景图片路径
            self._fix_background_image_paths_in_code_file(code_file_path)
            
            # 清理旧的media目录
            backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            media_dir = os.path.join(backend_dir, "media")
            if os.path.exists(media_dir):
                shutil.rmtree(media_dir)

            temp_code_file_path = Path(__file__).parent.parent.parent / code_file_path
         
            
            # 渲染命令
            render_command = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                "-m", "manim",
                "render",
                temp_code_file_path,
                "-q", "h",
                "--format", "mp4"
            ]
            
            # 执行渲染
            import subprocess
            try:
                result = subprocess.run(
                    render_command, 
                    cwd=backend_dir,
                    capture_output=True, 
                    text=True, 
                    check=False,
                    timeout=600  # 10分钟超时
                )
                
                if result.returncode != 0:
                    print(f"❌ 渲染失败: {result.stderr}")
                    return False
                
                # 查找生成的视频文件
                expected_media_dir = os.path.join(backend_dir, "media", "videos")
                rendered_video = None
                
                if os.path.exists(expected_media_dir):
                    latest_time = 0
                    for root, dirs, files in os.walk(expected_media_dir):
                        for file in files:
                            if file.endswith('.mp4'):
                                file_path = os.path.join(root, file)
                                file_time = os.path.getmtime(file_path)
                                if file_time > latest_time:
                                    latest_time = file_time
                                    rendered_video = file_path
                
                if not rendered_video:
                    print(f"❌ 找不到渲染后的视频文件")
                    return False
                
                # 复制到目标位置
                target_video_path = os.path.join(video_output_path, f"{segment_id}.mp4")
                
                # 备份原视频
                if os.path.exists(target_video_path):
                    backup_path = target_video_path + ".backup"
                    shutil.copy2(target_video_path, backup_path)
                
                shutil.copy2(rendered_video, target_video_path)
                print(f"✅ 视频渲染完成: {segment_id}")
                
                # 清理media目录
                if os.path.exists(media_dir):
                    shutil.rmtree(media_dir)
                
                return True
                
            except subprocess.TimeoutExpired:
                print(f"❌ 渲染超时")
                return False
                
        except Exception as e:
            print(f"❌ 渲染视频失败: {e}")
            return False

    def _merge_single_audio_video(self, segment_id: str, speech_audio_path: str, video_output_path: str, logger=logging.Logger) -> bool:
        """为单个片段合并音视频"""
        try:
            audio_file_path = os.path.join(speech_audio_path, f"{segment_id}.wav")
            video_file_path = os.path.join(video_output_path, f"{segment_id}.mp4")
            
            if not os.path.exists(audio_file_path):
                print(f"❌ 音频文件不存在: {audio_file_path}")
                return False
                
            if not os.path.exists(video_file_path):
                print(f"❌ 视频文件不存在: {video_file_path}")
                return False
            
            # 创建临时输出文件
            temp_output_path = video_file_path + ".temp.mp4"
            
            # 音视频合并命令
            backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            merge_script_path = os.path.join(backend_dir, "video_audio_merge_single.py")
            
            if not os.path.exists(merge_script_path):
                print(f"❌ 音频合并脚本不存在: {merge_script_path}")
                return False
            
            merge_command = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                merge_script_path,
                audio_file_path,        # 音频文件
                video_file_path,        # 视频文件  
                temp_output_path        # 输出文件
            ]
            
            import subprocess
            try:
                result = subprocess.run(
                    merge_command, 
                    cwd=backend_dir,
                    capture_output=True, 
                    text=True, 
                    check=False
                )
                
                if result.returncode == 0 and os.path.exists(temp_output_path):
                    # 替换原视频文件
                    shutil.move(temp_output_path, video_file_path)
                    print(f"✅ 音视频合并完成: {segment_id}")
                    return True
                else:
                    print(f"❌ 音视频合并失败: {result.stderr}")
                    return False
                    
            except Exception as e:
                print(f"❌ 音视频合并异常: {e}")
                return False
                
        except Exception as e:
            print(f"❌ 合并音视频失败: {e}")
            return False

    def get_preview_data(self, job_id: str, script_version: str = "refined") -> dict:
        """
        获取预览数据，包括所有视频片段、对应代码和讲稿
        
        Args:
            job_id: 任务ID
            script_version: 讲稿版本 ("original" 或 "refined")
        """
        job = self.jobs.get(job_id)
        if not job or job.status != "awaiting_preview_decision":
            return {"error": "任务不存在或不在预览阶段"}
            
        preview_data = job.preview_data
        video_wo_audio_path = preview_data["video_wo_audio_path"]
        manim_code_path = preview_data["manim_code_path"]
        
        # 根据版本选择讲稿路径
        if script_version == "original":
            speech_script_path = preview_data.get("speech_script_original_path")
            if not speech_script_path:
                return {"error": "原始讲稿路径不存在"}
        else:
            speech_script_path = preview_data["speech_script_path"]
        
        preview_items = []
        
        try:
            # 获取所有视频文件
            import glob
            video_files = glob.glob(os.path.join(video_wo_audio_path, "*.mp4"))
            def sort_key(filename):
                # 从文件名中提取所有数字
                numbers = re.findall(r'(\d+)', os.path.basename(filename))
                # 将提取到的字符串数字转换为整数元组，用于排序
                # 例如 "10_1.mp4" -> ('10', '1') -> (10, 1)
                return tuple(map(int, numbers))

            video_files.sort(key=sort_key)
            # video_files.sort()  # 按文件名排序
            
            for video_file in video_files:
                basename = os.path.splitext(os.path.basename(video_file))[0]
                
                # 找到对应的代码文件
                code_file = os.path.join(manim_code_path, f"{basename}.py")
                code_content = ""
                if os.path.exists(code_file):
                    with open(code_file, 'r', encoding='utf-8') as f:
                        code_content = f.read()
                
                # 找到对应的讲稿文件
                script_file = os.path.join(speech_script_path, f"{basename}.txt")
                script_content = ""
                script_exists = False
                if os.path.exists(script_file):
                    script_exists = True
                    with open(script_file, 'r', encoding='utf-8') as f:
                        script_content = f.read()
                
                # 获取视频文件大小
                video_size = os.path.getsize(video_file) if os.path.exists(video_file) else 0
                video_size_mb = video_size / (1024 * 1024)
                
                preview_items.append({
                    "id": basename,
                    "name": f"{basename}.mp4",
                    "video_path": f"http://teachmaster.cn:12300/api/v1/content/preview-video/{job_id}/{basename}",
                    "code_content": code_content,
                    "script_content": script_content,
                    "script_exists": script_exists,
                    "script_version": script_version,
                    "file_size": f"{video_size_mb:.1f} MB",
                    "duration": "计算中..."  # 可以后续添加视频时长计算
                })
            
            return {
                "job_id": job_id,
                "total_segments": len(preview_items),
                "segments": preview_items,
                "script_version": script_version,
                "script_paths": {
                    "original": preview_data.get("speech_script_original_path"),
                    "refined": preview_data["speech_script_path"]
                },
                "status": "ready_for_preview"
            }
            
        except Exception as e:
            return {"error": f"获取预览数据失败: {str(e)}"}

    def get_preview_data_original(self, job_id: str) -> dict:
        """获取原始版本的预览数据"""
        return self.get_preview_data(job_id, script_version="original")

    def get_job_status(self, job_id: str) -> Optional[JobStatus]:
        """获取任务状态"""
        return self.jobs.get(job_id)
    
    def get_all_jobs(self, limit: int = 10, offset: int = 0) -> List[JobStatus]:
        """获取所有任务列表"""
        all_jobs = list(self.jobs.values())
        return all_jobs[offset:offset + limit]
    
    def get_content_list(self, content_type: Optional[str] = None, limit: int = 10, offset: int = 0) -> List[ContentResponse]:
        """获取内容列表"""
        all_content = list(self.content.values())
        
        if content_type:
            all_content = [c for c in all_content if c.content_type == content_type]
        
        return all_content[offset:offset + limit]
    
    def get_content_by_id(self, content_id: int) -> Optional[ContentResponse]:
        """根据ID获取内容"""
        return self.content.get(content_id)
    
    def delete_content(self, content_id: int) -> bool:
        """删除内容"""
        if content_id in self.content:
            del self.content[content_id]
            return True
        return False
    
    def _format_file_size(self, size_bytes: int) -> str:
        """格式化文件大小"""
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.1f} KB"
        else:
            return f"{size_bytes / (1024 * 1024):.1f} MB"
        
    def generate_ppt(self, job_id: str) -> dict:
        """生成PPT"""
        try:
            job = self.jobs.get(job_id)
            output_root_path = "generated_content"
            request_output_dir = os.path.join(output_root_path, str(job.user_id), str(job_id))
            logger = self._setup_job_logger(job_id, request_output_dir)
            logger.info(json.dumps({
                "event": "Generating PPT...",
                "job_id": job_id,
                "message": "Generating PPT..."
            }))
            # 检查任务是否存在
            # if job_id not in self.jobs:
            #     raise ValueError(f"任务ID {job_id} 不存在")
            
            # # 检查任务状态是否为完成
            # if job.status != "completed":
            #     raise ValueError(f"任务ID {job_id} 状态不是 completed，当前状态为 {job.status}")
                
            
            # 生成PPT
            ppt_command = [
                '/home/EduAgent/miniconda3/envs/manim_env/bin/python',
                '/home/EduPal_v2/junhaoge/EduPal_v2/ML/PPTManager.py',
                'Video', 
                os.path.join(request_output_dir, "scripts"), 
                os.path.join(request_output_dir, "manim_codes_final"), 
                os.path.join(request_output_dir, "speech"), 
                os.path.join(request_output_dir, "PPT"), 
                "--subtitle",job.settings.get("course_title", "unknown"),
                "--teacher_name", job.settings.get("professor_name", "unknown"),
                "--teacher_avatar_path", job.settings.get("avatar_image", "csh.png"),
            ]
            # ppt_command = [
            #     '/home/EduAgent/miniconda3/envs/manim_env/bin/python',
            #     '/home/TeachMaster/ML/PPTManager.py',
            #     request_output_dir
            # ]
            self.run_subprocess_command(command=ppt_command, logger=logger)
            
            # ppt_path = "generated_content/SVM.pptx"
            ppt_path = os.path.join(request_output_dir, "PPT", "final.pptx")

            course_title = job.settings.get("course_title", "unknown")
            professor_name = job.settings.get("professor_name", "unknown")
            ppt_size = os.path.getsize(ppt_path) if os.path.exists(ppt_path) else 0
            # 保存PPT路径到任务结果
            job.result["files"].append(
                {"name": f"课程PPT-{course_title}-{professor_name}.pptx", "path": ppt_path, "size": ppt_size, "type": "ppt"}
            )
            print("===========")
            
            # 更新任务状态
            # self.jobs[job_id].result["ppt_path"] = ppt_path
            # self.jobs[job_id].status = "ppt_generated"
            self.jobs[job_id].message = "PPT生成完成"

        
        except Exception as e:
            raise ValueError(f"生成PPT失败: {str(e)}")

        
    def update_preview_segments(self, job_id: str, new_segments: List[Dict[str, Any]]) -> bool:
        """
        Synchronizes the backend file system and job state with frontend changes
        to video segments (delete, copy, reorder).
        """
        job = self.jobs.get(job_id)
        if not job or job.status != "awaiting_preview_decision":
            print(f"❌ Job {job_id} not found or not in awaiting_preview_decision state.")
            return False

        print(f"🔄 Updating preview segments for job {job_id}...")
        preview_data_paths = job.preview_data
        
        # Define all relevant directories where segment files are stored
        paths_to_manage = {
            'video': preview_data_paths.get("video_wo_audio_path"),
            'code_final': preview_data_paths.get("manim_code_path"),
            'script_refined': preview_data_paths.get("speech_script_path"),
            'script_original': preview_data_paths.get("speech_script_original_path"),
            'audio': preview_data_paths.get("speech_audio_path"),
            'code_original': preview_data_paths.get("manim_code_path", "").replace("_final", ""),
            'code_refined': os.path.join(os.path.dirname(preview_data_paths.get("manim_code_path", "")), "manim_codes_refined", "Code")
        }

        # Helper to get current segment IDs by scanning a directory
        def get_current_segment_ids(directory: str) -> set:
            if not directory or not os.path.exists(directory):
                return set()
            return {os.path.splitext(f)[0] for f in os.listdir(directory)}

        video_dir = paths_to_manage['video']
        if not video_dir:
            print("❌ Video directory path is missing in job's preview data.")
            return False

        current_ids = get_current_segment_ids(video_dir)
        new_ids = {seg['id'] for seg in new_segments}

        # --- 1. Handle Deletions ---
        deleted_ids = current_ids - new_ids
        if deleted_ids:
            print(f"🔥 Deleting segments: {deleted_ids}")
            for segment_id in deleted_ids:
                for key, dir_path in paths_to_manage.items():
                    if not dir_path or not os.path.exists(dir_path):
                        continue
                    
                    for file_to_delete in glob.glob(os.path.join(dir_path, f"{segment_id}.*")):
                        try:
                            os.remove(file_to_delete)
                            print(f"  🗑️ Deleted {file_to_delete}")
                        except OSError as e:
                            print(f"  ⚠️ Error deleting {file_to_delete}: {e}")

        # --- 2. Handle Copies ---
        added_ids = new_ids - current_ids
        if added_ids:
            print(f"✨ Copying segments for new IDs: {added_ids}")
            copy_map = {seg['id']: seg.get('source_id') for seg in new_segments if seg['id'] in added_ids and seg.get('source_id')}

            for new_id, source_id in copy_map.items():
                if not source_id:
                    print(f"  ⚠️ New segment {new_id} is missing 'source_id'. Cannot copy.")
                    continue

                print(f"  📋 Copying from {source_id} to {new_id}")
                for key, dir_path in paths_to_manage.items():
                    if not dir_path or not os.path.exists(dir_path):
                        continue

                    source_files = glob.glob(os.path.join(dir_path, f"{source_id}.*"))
                    if not source_files:
                        continue
                    
                    source_file = source_files[0]
                    ext = os.path.splitext(source_file)[1]
                    dest_file = os.path.join(dir_path, f"{new_id}{ext}")
                    try:
                        shutil.copy2(source_file, dest_file)
                        print(f"    - Copied {source_file} to {dest_file}")
                    except IOError as e:
                        print(f"    - ⚠️ Error copying file for {new_id}: {e}")

        # --- 3. Handle Reordering ---
        new_segment_order = [seg['id'] for seg in new_segments]
        print(f"📊 Saving new segment order: {new_segment_order}")
        job.preview_data["segment_order"] = new_segment_order
        
        return True


# 创建全局服务实例
full_content_service = MLFullContentService()


# 为了向后兼容，保留旧的类名
FullContentService = MLFullContentService