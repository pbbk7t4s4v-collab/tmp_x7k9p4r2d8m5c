# app/services/token_service.py

import json
import uuid
import os # --- ADDED ---
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
import threading
# --- ADDED: Import encryption tools ---
from cryptography.fernet import Fernet, InvalidToken

class TokenService:
    """
    A file-based service to generate, manage, and consume single-use, encrypted access tokens.
    Tokens contain encrypted metadata (creator, purpose) and are managed for their lifecycle (valid/used).
    This service is thread-safe.
    """
    def __init__(self, file_path: Path = Path("data/tokens.json")):
        self.TOKEN_FILE = file_path
        self._lock = threading.Lock()
        
        # --- ADDED: Load secret key and initialize encryption engine --- 
        secret_key = os.environ.get("TOKEN_SECRET_KEY", "dIrnc5S027-WLgfaqv_y41tlhbvq3VKs4XtCFPEHG5I=")
        if not secret_key:
            raise ValueError("TOKEN_SECRET_KEY environment variable not set. Please generate a key and configure it.")
        self.fernet = Fernet(secret_key.encode())
        
        self._tokens: Dict[str, Dict[str, Any]] = {}
        self._ensure_data_dir_exists()
        self._load_tokens()

    def _ensure_data_dir_exists(self):
        self.TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)

    def _load_tokens(self):
        with self._lock:
            try:
                with open(self.TOKEN_FILE, "r") as f:
                    self._tokens = json.load(f)

                print(self._tokens)
                print(f"🔑 Loaded {len(self._tokens)} token lifecycle records from {self.TOKEN_FILE}")
            except (FileNotFoundError, json.JSONDecodeError):
                self._tokens = {}
                print(f"⚠️ Token file not found or invalid. Initializing a new one.")
                self._save_tokens()

    def _save_tokens(self):
        with open(self.TOKEN_FILE, "w") as f:
            json.dump(self._tokens, f, indent=4)

    # --- NEW METHOD: Decrypts a token to reveal its contents ---
    def decrypt_token_info(self, token: str) -> Optional[Dict[str, Any]]:
        """
        Decrypts a token and returns the embedded information payload.
        Returns None if the token is invalid, tampered with, or expired.
        """
        try:
            # Set a TTL (Time To Live) for Fernet to automatically check expiration
            token_data = self._tokens.get(token)
            if not token_data:
                return None
            
            expires_at_str = token_data.get("expires_at")
            ttl = None
            if expires_at_str:
                expires_at = datetime.fromisoformat(expires_at_str)
                created_at = datetime.fromisoformat(token_data["created_at"])
                ttl = (expires_at - created_at).total_seconds()

            decrypted_payload_bytes = self.fernet.decrypt(token.encode(), ttl=ttl)
            return json.loads(decrypted_payload_bytes.decode())
        except InvalidToken:
            # This catches invalid format, signature, or expiration
            return None
        except (TypeError, json.JSONDecodeError):
            # Catches other potential errors
            return None
        
    def decrypt_token_info_with_ignore_expiration(self, token: str, ignore_expiration: bool = False) -> Optional[Dict[str, Any]]:
        """
        Decrypts a token and returns the embedded information payload.
        
        Args:
            token: The token string to decrypt.
            ignore_expiration: If True, the token's expiration time will not be checked.
                               This is useful for auditing expired tokens.

        Returns None if the token is invalid or tampered with.
        """
        try:
            ttl = None
            # Only enforce TTL if we are NOT ignoring expiration
            if not ignore_expiration:
                token_data = self._tokens.get(token)
                if token_data:
                    expires_at_str = token_data.get("expires_at")
                    if expires_at_str:
                        expires_at = datetime.fromisoformat(expires_at_str)
                        created_at = datetime.fromisoformat(token_data["created_at"])
                        # Calculate TTL only if the token has an expiration
                        ttl = (expires_at - created_at).total_seconds()

            decrypted_payload_bytes = self.fernet.decrypt(token.encode(), ttl=ttl)
            return json.loads(decrypted_payload_bytes.decode())
        except InvalidToken:
            # This catches invalid format, signature, or expiration (if ttl is set)
            return None
        except (TypeError, json.JSONDecodeError):
            return None

    # --- MODIFIED: Now accepts metadata to encrypt into the token ---
    def generate_tokens(
        self,
        count: int = 1,
        created_by: str = "system",
        page: int = 10,
        purpose: str = "general_use",
        expires_in_seconds: Optional[int] = None
    ) -> List[str]:
        """
        Generates encrypted tokens containing metadata about their creation.
        """
        new_token_strings = []
        with self._lock:
            for _ in range(count):
                created_at = datetime.utcnow()
                expires_at = None
                if expires_in_seconds:
                    expires_at = created_at + timedelta(seconds=expires_in_seconds)

                # 1. Create the data payload to be encrypted
                payload = {
                    "jti": uuid.uuid4().hex,  # Unique token identifier
                    "created_by": created_by,
                    "page": page,
                    "purpose": purpose,
                    "iat": created_at.isoformat(), # Issued At
                    "exp": expires_at.isoformat() if expires_at else None,
                }
                
                # 2. Encrypt the payload
                payload_bytes = json.dumps(payload).encode('utf-8')
                encrypted_token = self.fernet.encrypt(payload_bytes)
                token_str = encrypted_token.decode('utf-8')

                # 3. Store the token's lifecycle metadata (not the content)
                self._tokens[token_str] = {
                    "status": "valid",
                    "created_at": payload["iat"],
                    "expires_at": payload["exp"],
                    "used_at": None,
                    "used_by_user_id": None,
                    "used_by_job_id": None
                }
                new_token_strings.append(token_str)
            
            self._save_tokens()
        print(f"✅ Generated and saved {len(new_token_strings)} new encrypted token(s).")
        return new_token_strings

    def is_valid(self, token: str) -> bool:
        """
        Checks if a token's lifecycle status is 'valid' in our records and has not expired.
        """
        token = token.strip()
        token_data = self._tokens.get(token)
        print(token_data)
        if not token_data or token_data.get("status") != "valid":
            return False

        # Decrypt to check integrity and expiration
        decrypted_info = self.decrypt_token_info(token)
        return decrypted_info is not None

    def use_token(self, token: str, job_id: str, user_id: str) -> bool:
        """
        Marks a token as 'used' after validating its integrity and lifecycle status.
        """
        with self._lock:
            if self.is_valid(token):
                self._tokens[token]["status"] = "used"
                self._tokens[token]["used_at"] = datetime.utcnow().isoformat()
                self._tokens[token]["used_by_job_id"] = job_id
                self._tokens[token]["used_by_user_id"] = user_id
                self._save_tokens()
                print(f"Token has been consumed by job '{job_id}' by user '{user_id}'.")
                return True
        return False

# Create a singleton instance
token_service = TokenService()