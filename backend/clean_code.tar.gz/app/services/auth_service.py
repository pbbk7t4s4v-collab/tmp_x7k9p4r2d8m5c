"""
认证服务

包含了密码处理、数据库查询和 JWT 验证依赖项。
"""
import uuid
from typing import Optional
from passlib.context import CryptContext
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select
# 移除 fastapi_jwt_auth 导入
# from fastapi_jwt_auth import AuthJWT

# 导入 app/api/dependencies.py 中的 get_db
from app.db.database import get_db
from app.db.models import User
from app.core.security import decode_token  # 使用security.py中的函数

# --- 1 & 2. 密码哈希与验证 ---

# 1. 设置 passlib 上下文
# 我们只在创建/验证哈希时使用 "bcrypt"
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# 2. OAuth2 方案，告诉 FastAPI 哪里去寻找 token
# "tokenUrl" 必须指向你的登录路由
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")

def hash_password(password: str) -> str:
    """
    将明文密码哈希处理。
    """
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    验证明文密码是否与哈希值匹配。
    """
    return pwd_context.verify(plain_password, hashed_password)


# --- 3. 数据库用户查询 ---

async def get_user_by_email_or_username(
    db: AsyncSession, 
    email: Optional[str] = None, 
    username_or_email: Optional[str] = None
) -> Optional[User]:
    """
    通过邮箱或用户名从数据库中异步获取用户。
    用于注册时检查存在或登录时检查身份。
    """
    query = select(User)
    if username_or_email:
        # 允许用户使用邮箱或用户名登录
        query = query.where(
            (User.email == username_or_email) | (User.username == username_or_email)
        )
    elif email:
        query = query.where(User.email == email)
    else:
        return None # 必须提供一个查询条件
        
    result = await db.execute(query)
    return result.scalar_one_or_none()

async def get_user_by_id(db: AsyncSession, user_id: uuid.UUID) -> Optional[User]:
    """
    (辅助函数) 通过 ID 异步获取用户。
    """
        
    try:
        user = await db.get(User, user_id)
        return user
    except Exception as e:
        print(f"Error getting user by ID: {e}")
        return None


# --- 4. 认证依赖项 ---

async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
) -> User:
    """
    一个 FastAPI 依赖项，用于保护路由。
    
    1. 验证 JWT 是否存在且有效。
    2. 从 JWT 中提取 "subject" (即 user_id)。
    3. 从数据库中获取该用户。
    4. 返回 User 对象，或在失败时抛出 HTTP 401。
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        # 使用security.py中的decode_token函数
        payload = decode_token(token)
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
    except Exception:
        raise credentials_exception
        
    user = await get_user_by_id(db, uuid.UUID(user_id))
    if user is None:
        raise credentials_exception
        
    if not user.is_active:
         raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, 
            detail="用户已被禁用"
        )
        
    return user

async def get_admin_user(
    current_user: User = Depends(get_current_user)
) -> User:
    """
    一个 FastAPI 依赖项，用于保护 *仅限管理员* 的路由。

    1. 它自动调用 get_current_user，确保用户已认证且处于活动状态。
    2. 它额外检查 current_user 是否具有管理员权限。
    3. 如果不是管理员，抛出 HTTP 403 Forbidden。
    """
    
    # 2. 检查管理员权限
    if not current_user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="权限不足，需要管理员权限"
        )
        
    # 3. 如果是管理员，返回该用户对象
    return current_user

async def get_user_id_from_token(
    token: str = Depends(oauth2_scheme)
) -> uuid.UUID:
    """
    从JWT token中提取用户ID，不查询数据库。
    
    1. 验证JWT是否存在且有效。
    2. 从JWT中提取"subject"(即user_id)。
    3. 返回用户ID的UUID对象。
    
    这个函数适用于只需要用户ID而不需要完整用户信息的场景。
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        # 使用security.py中的decode_token函数
        payload = decode_token(token)
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
            
        # 将字符串转换为UUID对象
        current_user_id = uuid.UUID(user_id)
        return current_user_id

    except Exception:
        raise credentials_exception