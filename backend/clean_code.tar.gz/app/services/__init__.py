"""
Services package initialization
"""

from .full_content_service import full_content_service

__all__ = ["full_content_service"]