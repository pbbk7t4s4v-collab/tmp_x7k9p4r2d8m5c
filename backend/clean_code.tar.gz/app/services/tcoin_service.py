# app/services/tcoin_service.py
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from app.db.models import UserWallet, TcoinTransactionLog, TransactionType, User, GenerationJob
import uuid
from sqlalchemy.orm import Session 
from datetime import datetime

# --- 定义视频生成的成本 ---
# 建议从配置中读取
COST_PER_JOB = 100        # 每次完整生成消耗 100 T币
COST_PER_REGENERATE = 2  # 每次片段再生消耗 2 T币


class TcoinService:

    async def get_wallet(self, db: AsyncSession, user_id: uuid.UUID) -> UserWallet:
        """获取用户钱包，如果不存在则创建。"""
        wallet = await db.get(UserWallet, user_id)
        if not wallet:
            # 自动为用户创建钱包
            wallet = UserWallet(user_id=user_id, balance=0, version=0)
            db.add(wallet)
            try:
                await db.commit()
                await db.refresh(wallet)
            except Exception: # 处理并发创建时的唯一键冲突
                await db.rollback()
                wallet = await db.get(UserWallet, user_id)
        return wallet

    async def get_balance(self, db: AsyncSession, user_id: uuid.UUID) -> int:
        """快速获取用户余额。"""
        wallet = await self.get_wallet(db, user_id)
        return wallet.balance

    async def _change_balance(
        self,
        db: AsyncSession,
        user_id: uuid.UUID,
        amount: int, # 正数表示增加，负数表示减少
        tx_type: TransactionType,
        job_id: uuid.UUID = None,
        order_id: str = None,
        notes: str = None
    ) -> UserWallet:
        """
        核心函数：以原子方式更改余额并记录日志。
        (这是一个内部函数，外部应调用 debit 或 credit)
        """
        if amount == 0:
            return await self.get_wallet(db, user_id)

        # 1. 获取钱包并使用 "SELECT ... FOR UPDATE" 锁定该行，防止并发问题
        stmt = select(UserWallet).where(UserWallet.user_id == user_id).with_for_update()
        result = await db.execute(stmt)
        wallet = result.scalar_one_or_none()

        if not wallet:
            wallet = await self.get_wallet(db, user_id) # 重新调用以创建

        # 2. 检查余额 (如果是扣款)
        if amount < 0 and wallet.balance < abs(amount):
            raise ValueError("余额不足 (Insufficient T-Coins)") # 自定义异常更佳

        # 3. 计算新余额
        new_balance = wallet.balance + amount

        # 4. 更新钱包余额
        wallet.balance = new_balance
        wallet.version += 1 # 更新版本号
        db.add(wallet)
        await db.commit()
        
        # 5. 创建交易日志
        log_entry = TcoinTransactionLog(
            user_id=user_id,
            transaction_type=tx_type,
            amount=amount,
            balance_after=new_balance,
            related_job_id=job_id,
            related_order_id=order_id,
            notes=notes
        )
        db.add(log_entry)
        
        await db.commit()
        return wallet


    async def debit(
        self, db: AsyncSession, user_id: uuid.UUID, amount: int, job_id: uuid.UUID, notes: str = "视频生成"
    ):
        """
        (外部调用) 消耗T币。
        所有更改必须在数据库事务中进行！
        """
        if amount <= 0:
            raise ValueError("消耗金额必须为正数")
        return await self._change_balance(
            db, user_id, -abs(amount), TransactionType.CONSUMPTION, job_id=job_id, notes=notes
        )
    
       # ==================== 同步版本（用于同步worker） ====================
    
    def debit_sync(
        self, db: Session, user_id: uuid.UUID, amount: int, job_id: uuid.UUID, notes: str = "视频生成"
    ):
        """
        同步版本的T币扣除函数，用于同步worker中。
        所有更改必须在数据库事务中进行！
        """
        if amount <= 0:
            raise ValueError("消耗金额必须为正数")
        
        # 1. 获取钱包并使用 "SELECT ... FOR UPDATE" 锁定该行，防止并发问题
        wallet = db.query(UserWallet).filter(UserWallet.user_id == user_id).with_for_update().first()
        
        if not wallet:
            # 自动为用户创建钱包
            wallet = UserWallet(user_id=user_id, balance=0, version=0)
            db.add(wallet)
            try:
                db.commit()
                db.refresh(wallet)
            except Exception:  # 处理并发创建时的唯一键冲突
                db.rollback()
                wallet = db.query(UserWallet).filter(UserWallet.user_id == user_id).with_for_update().first()
        
        # 2. 检查余额
        if wallet.balance < amount:
            raise ValueError("余额不足 (Insufficient T-Coins)")
        
        # 3. 计算新余额
        new_balance = wallet.balance - amount
        
        # 4. 更新钱包余额
        wallet.balance = new_balance
        wallet.version += 1  # 更新版本号
        db.add(wallet)
        
        # 5. 创建交易日志
        log_entry = TcoinTransactionLog(
            user_id=user_id,
            transaction_type=TransactionType.CONSUMPTION,
            amount=-amount,  # 负数表示扣除
            balance_after=new_balance,
            related_job_id=job_id,
            notes=notes,
            created_at=datetime.utcnow()
        )
        db.add(log_entry)
        
        # 注意：不在这里commit，由调用者负责commit
        return wallet


    async def credit(
        self, db: AsyncSession, user_id: uuid.UUID, amount: int, tx_type: TransactionType, 
        order_id: str = None, job_id: uuid.UUID = None, notes: str = None
    ):
        """
        (外部调用) 增加T币 (充值, 退款, 奖励)。
        所有更改必须在数据库事务中进行！
        """
        if amount <= 0:
            raise ValueError("增加金额必须为正数")
        return await self._change_balance(
            db, user_id, abs(amount), tx_type, job_id=job_id, order_id=order_id, notes=notes
        )

# 创建一个单例
tcoin_service = TcoinService()