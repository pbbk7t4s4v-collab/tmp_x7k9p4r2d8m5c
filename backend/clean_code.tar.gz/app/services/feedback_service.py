
from pathlib import Path
import json
import os
import uuid
from datetime import datetime
from typing import Optional

from app.models.schemas import FinalFeedbackResponse, Comment, BaseResponse
from fastapi import BackgroundTasks
import smtplib
from email.mime.text import MIMEText
from app.db.models import GenerationJob
from app.helper.content_helper import ContentHelper

SMTP_SERVER = "smtp.qq.com"
SMTP_PORT = 587 # Or 465 for SSL
SMTP_USERNAME = "1687723655@qq.com"
SMTP_PASSWORD = "mtylcmvyfdpvbdcg"
FEEDBACK_RECIPIENT_EMAIL = "TeachMaster2025@outlook.com"
TOKEN_APPLICATION_RECIPIENT_EMAIL = "TeachMaster2025@outlook.com"

class FeedbackService:
    def __init__(self):
        pass

    def _get_job_base_path(self, job: GenerationJob) -> Path:
        """Helper to get the base directory path for a job."""
        if not job or not job.user_id:
            raise FileNotFoundError(f"Job status or user_id not found for {job.id}")
        return Path(f"generated_content/{job.user_id}/{job.id}")

    def _get_feedback_path(self, job: GenerationJob) -> Path:
        """Gets the path to the feedback.json file for a job."""
        return self._get_job_base_path(job) / "feedback.json"

    def _write_feedback_data(self, job: GenerationJob, data: dict):
        """Writes feedback data to feedback.json."""
        feedback_file = self._get_feedback_path(job)
        feedback_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(feedback_file, "w", encoding="utf-8") as f:
            # --- FIX STARTS HERE ---

            # 1. Define a helper function that converts datetime objects
            def datetime_serializer(o):
                if isinstance(o, datetime):
                    # Convert the datetime object to an ISO 8601 string format
                    return o.isoformat()
                # If it's not a datetime object, let the default encoder handle it
                raise TypeError(f"Object of type {o.__class__.__name__} is not JSON serializable")

            # 2. Pass this helper function to json.dump() using the 'default' parameter
            json.dump(data, f, indent=4, default=datetime_serializer)

    # --- LOGIC FOR THE NEW ENDPOINTS ---

    def set_user_vote(self, job: GenerationJob, segment_id: str, user_vote: Optional[str]) -> Optional[str]:
        """Sets the vote status for a segment and saves it."""
        feedback_data = self._read_feedback_data(job)
        
        if segment_id not in feedback_data:
            feedback_data[segment_id] = {"user_vote": None, "comments": []}
            
        feedback_data[segment_id]["user_vote"] = user_vote
        
        self._write_feedback_data(job, feedback_data)
        
        return user_vote

    def add_comment(self, job: GenerationJob, segment_id: str, comment_text: str) -> dict:
        """Adds a new comment for a segment and saves it."""
        feedback_data = self._read_feedback_data(job)
        status_data = job

        if segment_id not in feedback_data:
            feedback_data[segment_id] = {"user_vote": None, "comments": []}
            
        new_comment = {
            "id": str(uuid.uuid4()),
            "text": comment_text,
            "user_id": str(status_data.user_id), # In a real app, get this from the auth token
            "created_at": datetime.utcnow().isoformat()
        }
        
        feedback_data[segment_id]["comments"].append(new_comment)
        
        self._write_feedback_data(job, feedback_data)
        
        return new_comment

    def _read_feedback_data(self, job: GenerationJob) -> dict:
        """
        Safely reads feedback data from feedback.json for a given job.
        Returns an empty dictionary if the file doesn't exist.
        """
        feedback_file = self._get_feedback_path(job)
        if not os.path.exists(feedback_file):
            return {}
        try:
            with open(feedback_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            # In case the file is corrupted or unreadable, return empty
            return {}

    def get_final_video_feedback(self, job: GenerationJob) -> FinalFeedbackResponse:
        """Gets feedback for the FINAL VIDEO from feedback.json."""
        feedback_data = self._read_feedback_data(job)
        # Access the new nested structure
        video_data = feedback_data.get("final_outputs", {}).get("video", {
            "vote_status": None, "comments": []
        })
        return BaseResponse(data=video_data)

    def get_ppt_feedback(self, job: GenerationJob) -> FinalFeedbackResponse:
        """Gets feedback for the GENERATED PPT from feedback.json."""
        feedback_data = self._read_feedback_data(job)
        # Access the new nested structure
        ppt_data = feedback_data.get("final_outputs", {}).get("ppt", {
            "vote_status": None, "comments": []
        })
        return BaseResponse(data=ppt_data)

    def set_final_video_vote_status(self, job: GenerationJob, vote_status: Optional[str]):
        """Sets vote status for the FINAL VIDEO."""
        feedback_data = self._read_feedback_data(job)
        outputs = feedback_data.setdefault("final_outputs", {})
        video_entry = outputs.setdefault("video", {"vote_status": None, "comments": []})
        video_entry["vote_status"] = vote_status
        self._write_feedback_data(job, feedback_data)
        return BaseResponse(message="Video vote status updated.")

    def set_ppt_vote_status(self, job: GenerationJob, vote_status: Optional[str]):
        """Sets vote status for the GENERATED PPT."""
        feedback_data = self._read_feedback_data(job)
        outputs = feedback_data.setdefault("final_outputs", {})
        ppt_entry = outputs.setdefault("ppt", {"vote_status": None, "comments": []})
        ppt_entry["vote_status"] = vote_status
        self._write_feedback_data(job, feedback_data)
        return BaseResponse(message="PPT vote status updated.")

    def add_final_video_comment(self, job: GenerationJob, comment_text: str) -> Comment:
        """Adds a comment for the FINAL VIDEO."""
        feedback_data = self._read_feedback_data(job)
        outputs = feedback_data.setdefault("final_outputs", {})
        video_entry = outputs.setdefault("video", {"vote_status": None, "comments": []})
        new_comment = Comment(text=comment_text)
        video_entry["comments"].append(new_comment.model_dump())
        self._write_feedback_data(job, feedback_data)
        return BaseResponse(data=new_comment)

    def add_ppt_comment(self, job: GenerationJob, comment_text: str) -> Comment:
        """Adds a comment for the GENERATED PPT."""
        feedback_data = self._read_feedback_data(job)
        outputs = feedback_data.setdefault("final_outputs", {})
        ppt_entry = outputs.setdefault("ppt", {"vote_status": None, "comments": []})
        new_comment = Comment(text=comment_text)
        ppt_entry["comments"].append(new_comment.model_dump())
        self._write_feedback_data(job, feedback_data)
        return BaseResponse(data=new_comment)
    
    def submit_system_feedback(
        self,
        feedback_text: str,
        user_email: Optional[str],
        background_tasks: BackgroundTasks
    ):
        """Formats and sends system feedback email in the background."""
        subject = "System Feedback Received"
        body = f"Feedback received:\n\n"
        if user_email:
            body += f"From: {user_email}\n"
        body += f"Message:\n{feedback_text}"
        content_helper = ContentHelper()

        # Add the email sending task to the background
        background_tasks.add_task(
            content_helper._send_email_background,
            FEEDBACK_RECIPIENT_EMAIL,
            subject,
            body
        )
        return BaseResponse(message="Feedback submitted successfully. Thank you!")
    
    
