from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from contextlib import contextmanager
from sqlmodel import SQLModel
from contextlib import asynccontextmanager

# 导入你的全局配置
from app.core.config import settings

# ---------------------------------
# 1. 创建异步引擎
# ---------------------------------
# settings.DATABASE_URL 来自你的 .env 文件
# ("mysql+aiomysql://fastapi_user:supersecretpassword123@localhost:3306/content_gen_db")
async_engine = create_async_engine(
    settings.DATABASE_URL,
    echo=True,  # 在控制台打印 SQL 语句，方便调试
    future=True,
    pool_pre_ping=True, # 每次获取连接前自动检测连通性
    pool_recycle=3600,  # 1小时回收一次连接
    pool_size=20, # 连接池大小 (根据并发量调整)
    max_overflow=10 # 超出连接池大小时，允许额外创建的连接数
)

# ---------------------------------
# 2. 数据库初始化
# ---------------------------------
async def init_db():
    """
    在应用启动时初始化数据库，创建所有表。
    """
    async with async_engine.begin() as conn:
        # await conn.run_sync(SQLModel.metadata.drop_all) # 仅在开发初期重置时使用
        await conn.run_sync(SQLModel.metadata.create_all)

# ---------------------------------
# 3. 异步 Session 工厂
# ---------------------------------
# 这是创建新会话的工厂
AsyncSessionFactory = sessionmaker(
    bind=async_engine, 
    class_=AsyncSession, 
    expire_on_commit=False # 关键：防止在 commit 后对象被释放
)
async_session_maker = async_sessionmaker(async_engine, expire_on_commit=False)
# ---------------------------------
# 4. 依赖项 (用于 FastAPI 路由)
# ---------------------------------
async def get_db() -> AsyncSession:
    """
    一个 FastAPI 依赖项，为每个 API 请求提供一个数据库会话。
    """
    async with AsyncSessionFactory() as session:
        yield session

# ---------------------------------
# 5. 上下文管理器 (用于 ARQ Worker)
# ---------------------------------
@asynccontextmanager
async def get_db_session_context():
    """
    一个用于 ARQ Worker 或其他非 API 上下文的会话管理器。
    """
    async with AsyncSessionFactory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            print("数据库会话回滚")
            raise
SYNC_DATABASE_URL = settings.DATABASE_URL.replace("aiomysql", "pymysql")
if SYNC_DATABASE_URL == settings.DATABASE_URL:
    print("警告: 无法自动转换 DATABASE_URL 为同步 URL。请确保它使用的是 'pymysql' 驱动。")

# -----------------------------------------------------------
# 同步(Sync)设置 (给你 *同步* 的 ARQ Worker 用)
# -----------------------------------------------------------

# 创建一个 *完全独立* 的 *同步* 引擎
sync_engine = create_engine(
    SYNC_DATABASE_URL,
    echo=False,  # 同步 worker 中可以关掉日志
    future=True,
    pool_pre_ping=True, # 关键：同步 Worker 经常长时间空闲，必须加这个
    pool_recycle=3600,
    pool_size=20,
    max_overflow=10
)

# 创建一个 *完全独立* 的 *同步* Session 工厂
sync_session_maker = sessionmaker(
    bind=sync_engine,
    expire_on_commit=False
)

@contextmanager
def get_sync_db_session_context():
    """
    为同步 worker 提供一个 *真正* 的同步 session。
    """
    db = sync_session_maker() 
    print("创建了一个新的 *同步* session。")
    try:
        yield db
        print("同步操作完成，正在提交...")
        db.commit()
    except Exception as e:
        print(f"同步数据库操作失败: {e}，正在回滚...")
        db.rollback()
        raise
    finally:
        print("关闭同步数据库 session。")
        db.close()