import uuid
import enum
from datetime import datetime, timezone
import sqlalchemy as sa
from sqlmodel import SQLModel, Field, JSON, Column, Relationship
from typing import Optional, List, Dict, Any
from sqlalchemy.ext.mutable import MutableDict
from sqlalchemy import Column, Enum, String, BigInteger, DateTime, func


# ---------------------------------
# 1. 用户模型 (User Model)
# ---------------------------------
class User(SQLModel, table=True):
    """
    存储用户信息的基础模型
    """
    id: Any = Field(default_factory=uuid.uuid4, sa_column=Column(sa.CHAR(36), primary_key=True))
    
    email: str = Field(unique=True, index=True)
    username: str = Field(unique=True, index=True)
    hashed_password: str
    
    full_name: Optional[str] = None
    is_active: bool = Field(default=True)
    is_superuser: bool = Field(default=False)
    avatar_url: Optional[str] = None
    
    created_at: datetime = Field(default_factory=datetime.utcnow, nullable=False)

    reset_token: Optional[str] = Field(
        default=None, 
        index=True, 
        nullable=True, 
        max_length=100  # 对应 VARCHAR(100)
    )
    
    reset_token_expires: Optional[datetime] = Field(
        default=None, 
        nullable=True
    )

# ---------------------------------
# 2. 内容生成任务模型 (GenerationJob Model)
# ---------------------------------
class GenerationJob(SQLModel, table=True):
    """
    存储内容生成任务的状态和结果
    """
    id: Any = Field(
        default_factory=uuid.uuid4, 
        sa_column=Column(sa.CHAR(36), primary_key=True)
    )
    
    # 建立与 User 模型的外键关系
    # 6. 对 GenerationJob.user_id 应用相同的修复
    user_id: Any = Field(
        sa_column=Column(sa.CHAR(36))
    )
    
    status: str = Field(default="pending", index=True) # "pending", "running", "failed", "completed", "awaiting_preview"
    progress: int = Field(default=0)
    message: Optional[str] = None
    error_message: Optional[str] = None
    
    created_at: datetime = Field(default_factory=datetime.utcnow, nullable=False)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    current_step_start_time: Optional[str] = None
    current_step_estimated_time: Optional[float] = None

    # 用 JSONB/JSON 存储原始请求和结果，非常灵活
    request_payload: Dict[str, Any] = Field(default={}, sa_column=Column(JSON))
    preview_data: Dict[str, Any] = Field(default={}, sa_column=Column(MutableDict.as_mutable(JSON)))
    result_files: List[Dict[str, Any]] = Field(default=[], sa_column=Column(JSON))
    
    # 从 settings 中保存的配置
    settings: Dict[str, Any] = Field(default={}, sa_column=Column(JSON))
    
    # 访问令牌 (如果需要持久化)
    access_token: Optional[str] = Field(
        default=None, 
        sa_column=Column(sa.TEXT)
    )


# ---------------------------------
# 3. 上传文件模型 (UploadedFile Model)
# ---------------------------------
class UploadedFile(SQLModel, table=True):
    """
    存储用户上传的各种文件的元数据
    """
    id: Any = Field(
        default_factory=uuid.uuid4, 
        sa_column=Column(sa.CHAR(36), primary_key=True)
    )
    
    user_id: Any = Field(
        sa_column=Column(sa.CHAR(36))
    )
    
    file_type: str = Field(index=True) # e.g., 'background_image', 'reference_audio'
    
    original_filename: str
    storage_path: str # 存储在服务器上的绝对路径
    file_size: int
    created_at: datetime = Field(default_factory=datetime.utcnow, nullable=False)


class UserWallet(SQLModel, table=True):
    """
    用户钱包表：存储每个用户的当前T币余额。
    """
    id: Any = Field(
        default_factory=uuid.uuid4, 
        sa_column=Column(sa.CHAR(36))
    )
    
    # 关联的用户ID，同时也是主键，确保一个用户只有一个钱包
    user_id: Any = Field(
        sa_column=Column(sa.CHAR(36), primary_key=True)
    )
    
    # 当前余额
    # 建议使用 BigInteger，以防未来T币变得"不值钱"，余额数值巨大
    # 修复后的代码
    balance: int = Field(default=0, sa_column=Column(sa.BIGINT, index=True))
    
    # 乐观锁版本号，用于处理高并发下的余额更新
    version: int = Field(default=0, nullable=False)

    updated_at: datetime = Field(
        default=None, 
        sa_column=Column(
            sa.DateTime(timezone=True),
            server_default=sa.func.now(), # 数据库在 INSERT 时自动设置
            onupdate=sa.func.now(),       # 数据库在 UPDATE 时自动设置 (注意: SQLAlchemy 用 onupdate=func.now() 来表示 server_onupdate)
            nullable=False
        )
    )
    created_at: datetime = Field(default_factory=datetime.utcnow, nullable=False)


class TransactionType(str, enum.Enum):
    RECHARGE = "RECHARGE"     # 充值
    CONSUMPTION = "CONSUMPTION" # 消费 (例如：生成视频)
    REFUND = "REFUND"         # 退款 (例如：任务失败)
    REWARD = "REWARD"         # 奖励 (例如：签到、活动)
    ADMIN_ADJUST = "ADMIN_ADJUST" # 管理员手动调整
    REDEEM_CODE = "REDEEM_CODE" # 兑换码充值


class TcoinTransactionLog(SQLModel, table=True):
    """
    T币交易日志表：记录每一笔T币的流入和流出。
    (已转换为 SQLModel 风格)
    """
    __tablename__ = "tcoin_transaction_log"
    
    # ID 字段 (参考 GenerationJob.id 风格)
    id: Any = Field(
        default_factory=uuid.uuid4, 
        sa_column=Column(sa.CHAR(36), primary_key=True)
    )
    
    user_id: Any = Field(
        sa_column=Column(sa.CHAR(36))
    )
    
    # 交易类型 (使用 Enum)
    transaction_type: TransactionType = Field(
        sa_column=Column(Enum(TransactionType), index=True, nullable=False)
    )
    
    # 变动金额 (保留 BigInteger)
    amount: int = Field(
        sa_column=Column(BigInteger, nullable=False)
    )
    
    # 交易后余额 (保留 BigInteger)
    balance_after: int = Field(
        sa_column=Column(BigInteger, nullable=False)
    )
    
    # 关联 Job ID (参考 GenerationJob.id 风格)
    related_job_id: Optional[Any] = Field(
        sa_column=Column(sa.CHAR(36))
    )
    
    # 关联订单 ID
    related_order_id: Optional[str] = Field(
        sa_column=Column(sa.CHAR(36))
    )
    
    # 备注
    notes: Optional[str] = Field(
        default=None, 
        sa_column=Column(String(500))
    )
    
    # 创建时间 (参考 GenerationJob.created_at 风格)
    # 保留了源模型中的 index=True
    created_at: datetime = Field(
        default_factory=datetime.utcnow, 
        nullable=False,
        index=True
    )


class RechargePackage(SQLModel, table=True):
    """
    T币充值套餐表
    """
    __tablename__ = "recharge_package"

    id: Any = Field(
        default_factory=uuid.uuid4, 
        sa_column=Column(sa.CHAR(36), primary_key=True)
    )

    # 显示名称
    name: str = Field(max_length=100)
    
    # 价格 (必须存储为整数，单位：分)
    # 对应你后端逻辑的 "amount_cents"
    amount_cents: int = Field(sa_column=Column(sa.Integer, nullable=False))
    
    # 获得的T币数量
    tcoins: int = Field(sa_column=Column(sa.Integer, nullable=False))
    
    # 描述前端图标的 "Key"，例如 "coffee", "gift", "trophy"
    # 前端将用这个 Key 来映射到 React 组件
    icon_key: Optional[str] = Field(default=None, max_length=50)
    
    # 是否为 "最划算" 的套餐
    best_value: bool = Field(default=False)
    
    # "9折优惠" 这样的徽标文字
    ribbon_text: Optional[str] = Field(default=None, max_length=50)
    
    # 控制显示顺序
    display_order: int = Field(default=0, index=True)
    
    # 软删除/禁用
    is_active: bool = Field(default=True, index=True)
    
    # 创建时间
    created_at: datetime = Field(
        default_factory=datetime.utcnow, 
        nullable=False,
        index=True
    )
    
    # 更新时间
    updated_at: datetime = Field(
        default=None, 
        sa_column=Column(
            sa.DateTime(timezone=True),
            server_default=sa.func.now(), # 数据库在 INSERT 时自动设置
            onupdate=sa.func.now(),       # 数据库在 UPDATE 时自动设置 (注意: SQLAlchemy 用 onupdate=func.now() 来表示 server_onupdate)
            nullable=False
        )
    )



class RedeemCode(SQLModel, table=True):
    """
    兑换码表：用于T币充值
    """
    __tablename__ = "redeem_code"
    
    # 主键ID
    id: Any = Field(
        default_factory=uuid.uuid4, 
        sa_column=Column(sa.CHAR(36), primary_key=True)
    )
    
    # 兑换码（唯一，用于用户输入）
    # 注意：加密后的兑换码（以Timo开头）可能较长，所以设置为128字符
    code: str = Field(
        max_length=128,
        sa_column=Column(String(128), nullable=False, unique=True, index=True)
    )
    
    # T币数量
    tcoins: int = Field(
        sa_column=Column(sa.Integer, nullable=False)
    )
    
    # 是否已使用
    is_used: bool = Field(default=False, index=True)
    
    # 使用时间
    used_at: Optional[datetime] = Field(default=None)
    
    # 使用用户ID
    used_by_user_id: Optional[Any] = Field(
        default=None,
        sa_column=Column(sa.CHAR(36))
    )
    
    # 有效期开始时间
    valid_from: Optional[datetime] = Field(default=None)
    
    # 有效期结束时间
    valid_until: Optional[datetime] = Field(default=None, index=True)
    
    # 备注（管理员可以添加说明）
    notes: Optional[str] = Field(
        default=None,
        sa_column=Column(String(500))
    )
    
    # 创建者（管理员ID）
    created_by: Optional[Any] = Field(
        default=None,
        sa_column=Column(sa.CHAR(36))
    )
    
    # 创建时间
    created_at: datetime = Field(
        default_factory=datetime.utcnow, 
        nullable=False,
        index=True
    )
    
    # 更新时间
    updated_at: datetime = Field(
        default=None, 
        sa_column=Column(
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            onupdate=sa.func.now(),
            nullable=False
        )
    )