import asyncio
import uuid
from datetime import datetime
import traceback
from sqlalchemy.ext.asyncio import AsyncSession
from arq.connections import RedisSettings
from sqlalchemy.orm.attributes import flag_modified

# 导入你的数据库模型和会话管理器
from app.db.database import get_db_session_context
from app.db.models import GenerationJob 
# 导入你的 Pydantic/SQLModel 请求模型
from app.models.schemas import GenerationRequest 
# 导入你的配置文件
from app.core.config import settings 
# 导入你从 MLFullContentService 拆分出来的 *同步* 任务函数
from app.workers.generation_tasks import (
    generate_content_task_entry, 
    continue_generation_task_entry,
    regenerate_video_segment_entry,
    regenerate_audio_segment_entry,
    reprocess_segment_complete_entry,
    generate_ppt_entry,
    change_video_speed_entry,
    LLM_modify_manim_code_entry
)

# --- 数据库状态更新 (辅助函数) ---

async def db_update_job_status(
    db: AsyncSession, 
    job_id: str, 
    status: str, 
    progress: int, 
    message: str, 
    **kwargs
) -> GenerationJob | None:
    """
    一个统一的函数，用于在数据库中更新任务状态。
    这个函数在数据库会话 (db) 的上下文中被调用，它只修改会话，
    由调用者 (如 generate_content_task) 负责提交事务。
    """
    print(f"[DB Update] Job {job_id}: {status} ({progress}%) - {message}")
    try:
        job = await db.get(GenerationJob, job_id)
        if not job:
            print(f"[DB Update] 错误: 任务 {job_id} 未在数据库中找到。")
            return None

        # 更新核心字段
        job.status = status
        job.progress = progress
        job.message = message

        # 处理可选字段
        if "error" in kwargs:
            job.error_message = kwargs["error"]
        if "preview_data" in kwargs:
            job.preview_data = kwargs["preview_data"]
        if "result_files" in kwargs:
            job.result_files = kwargs["result_files"]
        if "settings" in kwargs:
            job.settings = kwargs["settings"]
        
        # 自动设置时间戳
        if status == "running" and not job.started_at:
            job.started_at = datetime.utcnow()
        if status in ("completed", "failed"):
            job.completed_at = datetime.utcnow()
            
        db.add(job) # 将更改添加到会话
        await db.flush() # 刷新以确保 job 对象在会话中更新
        return job

    except Exception as e:
        print(f"[DB Update] 严重错误: 更新任务 {job_id} 状态失败: {e}")
        # 异常将由上层 try/except 捕获
        raise

# --- 任务执行器 (通用模板) ---

async def run_task(job: GenerationJob, task_name: str, status: str, task_func, *args):
    """
    一个通用的 ARQ 任务执行器，处理状态更新和错误捕获。
    """
    job_id = job.id
    print(f"Worker: 收到 {task_name} 任务 for job {job_id}")
    
    # 1. 设置为正在运行
    try:
        async with get_db_session_context() as db:
            await db_update_job_status(db, job_id, status, 1, f"任务已启动: {task_name}...")
            await db.commit() # 提交 "running" 状态
    except Exception as e:
        print(f"Worker: 无法将任务 {job_id} 设为 {status}: {e}")
        return # 无法启动，放弃

    # 2. 在线程池中执行阻塞的同步任务
    try:
        await asyncio.to_thread(task_func, job, *args)
        
        # 3. 成功后
        print(f"Worker: {task_name} 任务 {job_id} 已完成。")
        # 注意: 任务函数 (如 `..._entry`) 负责设置最终状态
        # (例如 "awaiting_preview_decision" 或 "completed")

    except Exception as e:
        # 4. 捕获任务执行中的任何异常
        print(f"Worker: 任务 {job_id} ({task_name}) 严重失败: {e}")
        traceback.print_exc()
        try:
            async with get_db_session_context() as db:
                await db_update_job_status(
                    db, job_id, "failed", 0, 
                    f"任务 {task_name} 失败: {str(e)}", 
                    error=str(e)[:127] # 截断错误信息，避免超长
                )
                await db.commit() # 提交 "failed" 状态
        except Exception as db_e:
            print(f"Worker: 任务 {job_id} 失败，且更新数据库也失败: {db_e}")



async def run_segment_task(job: GenerationJob, task_name: str, segment_id: str, task_func):
    """
    专门用于片段任务的执行器，包含片段状态跟踪
    """
    job_id = job.id
    print(f"Worker: 收到 {task_name} 任务 for job {job_id}, segment {segment_id}")
    
    # 1. 更新片段状态为 "running"
    try:
        async with get_db_session_context() as db:
            if not job.preview_data:
                job.preview_data = {}
            if "segment_status" not in job.preview_data:
                job.preview_data["segment_status"] = {}
            
            job.preview_data["segment_status"][segment_id] = "running"
            db.add(job)
            flag_modified(job, "preview_data")
            await db.commit()
            print(f"Worker: 片段 {segment_id} 状态已更新为 running")
    except Exception as e:
        print(f"Worker: 无法更新片段 {segment_id} 状态为 running: {e}")
        return

    # 2. 在线程池中执行阻塞的同步任务
    try:
        await asyncio.to_thread(task_func, job, segment_id)
        
        # 3. 成功后更新片段状态为 "completed"
        async with get_db_session_context() as db:
            if job.preview_data and "segment_status" in job.preview_data:
                job.preview_data["segment_status"][segment_id] = "completed"
                db.add(job)
                flag_modified(job, "preview_data")
                await db.commit()
                print(f"Worker: 片段 {segment_id} 状态已更新为 completed")
        
    except Exception as e:
        # 4. 捕获任务执行中的任何异常，更新片段状态为 "failed"
        print(f"Worker: 片段 {segment_id} {task_name} 失败: {e}")
        traceback.print_exc()
        try:
            async with get_db_session_context() as db:
                if job.preview_data and "segment_status" in job.preview_data:
                    job.preview_data["segment_status"][segment_id] = "failed"
                    db.add(job)
                    flag_modified(job, "preview_data")
                    await db.commit()
                    print(f"Worker: 片段 {segment_id} 状态已更新为 failed")
        except Exception as db_e:
            print(f"Worker: 片段 {segment_id} 失败，且更新数据库也失败: {db_e}")

# --- 任务状态跟踪执行器 ---

async def run_task_with_status(job: GenerationJob, task_name: str, task_key: str, task_func, *args):
    """
    专门用于任务状态跟踪的执行器
    """
    job_id = str(job.id)
    print(f"Worker: 收到 {task_name} 任务 for job {job_id}")
    
    # 1. 更新任务状态为 "running"
    try:
        async with get_db_session_context() as db:
            job = await db.get(GenerationJob, job_id)
            if not job.preview_data:
                job.preview_data = {}
            if "task_status" not in job.preview_data:
                job.preview_data["task_status"] = {}
            
            job.preview_data["task_status"][task_key] = "running"
            db.add(job)
            flag_modified(job, "preview_data")
            await db.commit()
            print(f"Worker: 任务 {task_key} 状态已更新为 running")
    except Exception as e:
        print(f"Worker: 无法更新任务 {task_key} 状态为 running: {e}")
        return

    # 2. 在线程池中执行阻塞的同步任务
    try:
        await asyncio.to_thread(task_func, job, *args)
        
        # 3. 成功后更新任务状态为 "completed"
        async with get_db_session_context() as db:
            job = await db.get(GenerationJob, job_id)
            if job.preview_data and "task_status" in job.preview_data:
                job.preview_data["task_status"][task_key] = "completed"
                db.add(job)
                flag_modified(job, "preview_data")
                await db.commit()
                print(f"Worker: 任务 {task_key} 状态已更新为 completed")
        
    except Exception as e:
        # 4. 捕获任务执行中的任何异常，更新任务状态为 "failed"
        print(f"Worker: 任务 {task_key} {task_name} 失败: {e}")
        traceback.print_exc()
        try:
            async with get_db_session_context() as db:
                job = await db.get(GenerationJob, job_id)
                if job.preview_data and "task_status" in job.preview_data:
                    job.preview_data["task_status"][task_key] = "failed"
                    db.add(job)
                    flag_modified(job, "preview_data")
                    await db.commit()
                    print(f"Worker: 任务 {task_key} 状态已更新为 failed")
        except Exception as db_e:
            print(f"Worker: 任务 {task_key} 失败，且更新数据库也失败: {db_e}")

# --- ARQ 任务定义 ---

async def generate_content_task(ctx, job: GenerationJob, request_data: dict):
    """
    ARQ 任务 (第一部分): 执行从 "pending" 到 "awaiting_preview_decision"。
    """
    request = GenerationRequest(**request_data)
    await run_task(job, "generate_content", "running", generate_content_task_entry, request)

async def continue_generation_task(ctx, job: GenerationJob):
    """
    ARQ 任务 (第二部分): 执行从 "awaiting_preview_decision" 到 "completed"。
    """
    await run_task(job, "continue_generation", "continuing", continue_generation_task_entry)
async def regenerate_video_segment_task(ctx, job: GenerationJob, segment_id: str):
    """ ARQ 任务: 重新生成单个视频片段，包含状态跟踪 """
    await run_segment_task(job, "regenerate_video", segment_id, regenerate_video_segment_entry)

async def regenerate_audio_segment_task(ctx, job: GenerationJob, segment_id: str):
    """ ARQ 任务: 重新生成单个音频片段，包含状态跟踪 """
    await run_segment_task(job, "regenerate_audio", segment_id, regenerate_audio_segment_entry)

async def reprocess_segment_complete_task(ctx, job: GenerationJob, segment_id: str):
    """ ARQ 任务: 完整重新处理单个片段，包含状态跟踪 """
    await run_segment_task(job, "reprocess_segment", segment_id, reprocess_segment_complete_entry)

async def generate_ppt_task(ctx, job: GenerationJob):
    """ ARQ 任务: 生成 PPT，包含状态跟踪 """
    await run_task_with_status(job, "generate_ppt", "ppt", generate_ppt_entry)

async def change_video_speed_task(ctx, job: GenerationJob, speed: float):
    """ ARQ 任务: 调整视频速度，包含状态跟踪 """
    await run_task_with_status(job, "change_video_speed", "speed", change_video_speed_entry, speed)
async def LLM_modify_manim_code_task(ctx, job: GenerationJob, segment_id: str, origin_code: str, user_request: str): 
    await run_task_with_status(job, "llm_modify_manim_code", f"llm_modify-{segment_id}", LLM_modify_manim_code_entry, segment_id, origin_code, user_request)

# --- ARQ Worker 配置 ---

# 从你的全局配置 settings 中加载 Redis 设置
ARQ_REDIS_SETTINGS = RedisSettings(
    host=settings.REDIS_HOST, 
    port=settings.REDIS_PORT
)

# ARQ Worker 的主配置
class WorkerSettings:
    """
    定义 ARQ worker 查找和执行的任务。
    在你的终端中使用 `arq app.workers.arq_worker.WorkerSettings > arq.log 2>&1` 来启动 worker。
    """
    functions = [
        generate_content_task,    # 主生成
        continue_generation_task,  # 预览后继续
        regenerate_video_segment_task,
        regenerate_audio_segment_task,
        reprocess_segment_complete_task,
        generate_ppt_task,
        change_video_speed_task,
        LLM_modify_manim_code_task
    ]
    redis_settings = ARQ_REDIS_SETTINGS
    max_jobs = 20 # 根据你的服务器资源调整，允许同时执行的最大任务数
    job_timeout = 36000 # 任务超时时间（10小时），防止任务卡死
    keep_result = 36000 # 任务结果在 Redis 中的保留时间