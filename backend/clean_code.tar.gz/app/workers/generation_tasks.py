import asyncio
import os
import subprocess
import sys
import re
import uuid
import glob
import aiofiles
import json
import time
import shutil
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
from app.services.token_service import token_service
from app.helper.content_helper import ContentHelper
from sqlalchemy.orm.attributes import flag_modified

# 导入数据库模型和会话
from app.db.database import get_sync_db_session_context
from app.db.models import GenerationJob, TcoinTransactionLog, TransactionType
from app.models.schemas import (GenerationRequest, BaseResponse)
from llm_api import LLMAPIClient
from app.services.feedback_service import FeedbackService
from app.services.tcoin_service import tcoin_service, COST_PER_JOB

from fastapi import (HTTPException, status)

# 导入全局配置
from app.core.config import settings

# 添加脚本路径以便导入ML模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
# 添加backend根目录路径
backend_root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')
sys.path.append(backend_root)

JOB_LOCKS = {}
GLOBAL_LOCK = asyncio.Lock()


async def get_job_lock(job_id: str) -> asyncio.Lock:
    """获取或创建一个与特定 job_id 关联的锁"""
    async with GLOBAL_LOCK:
        if job_id not in JOB_LOCKS:
            JOB_LOCKS[job_id] = asyncio.Lock()
        return JOB_LOCKS[job_id]

# 导入 ML 模块
try:
    import whisper
    from script_generator import ScriptGenerator
    from generate_manim_codes import ManimCodeGenerator
    from generate_manim_codes_for_effi_test_cn_nano import ManimCodeGenerator_cn
    from script_splitter import ScriptSplitter
    from paginator import Paginator
    from manim_breakpoint_inserter import ManimBreakpointInserter
    from manim_auto_wait_generator import ManimAutoWaitGenerator
    from manim_auto_wait_generator_en import ManimAutoWaitGenerator_en
    from generate_speech_scripts import SpeechScriptGenerator
    from generate_speech_scripts_en import SpeechScriptGenerator_en
    from splitter import MarkdownSplitter
    from outline_content_generator_new import OutlineContentGenerator
    
    # 导入封面渲染模块
    from manim import config as manim_config
    from Demo import MergedLayoutScene2
    from EndingDemo import EndingScene
    from Demo_cn import MergedLayoutScene2_cn
    from EndingDemo_cn import EndingScene_cn
    
    ML_MODULES_LOADED = True
    print("所有ML和Manim模块导入成功。")

except ImportError as e:
    print(f"警告: 无法导入核心ML或Manim模块: {e}")
    print("！！！生成任务将无法执行！！！")
    ML_MODULES_LOADED = False
    # 定义占位符，防止代码在其他地方崩溃
    ScriptGenerator = None
    ManimCodeGenerator = None
    ScriptSplitter = None
    Paginator = None
    ManimBreakpointInserter = None
    ManimAutoWaitGenerator = None
    SpeechScriptGenerator = None
    MarkdownSplitter = None
    OutlineContentGenerator = None
    MergedLayoutScene2 = None
    EndingScene = None
    whisper = None
    manim_config = None


# ---------------------------------
# 全局 ML 模块初始化
# ---------------------------------
# 只有在模块成功加载时才初始化
if ML_MODULES_LOADED:
    try:
        # 配置文件路径（假设在项目根目录）
        CONFIG_PATH = str("config.json")
        
        script_generator = ScriptGenerator(config_path=CONFIG_PATH)
        manimcode_generator = ManimCodeGenerator(config_path=CONFIG_PATH)
        scriptSplitter = ScriptSplitter()
        paginator = Paginator(config_path=CONFIG_PATH)
        markdownSplitter = MarkdownSplitter()
        manimBreakpointInserter = ManimBreakpointInserter(config_path=CONFIG_PATH)
        manimAutoWaitGenerator = ManimAutoWaitGenerator()
        speechScriptGenerator = SpeechScriptGenerator(config_path=CONFIG_PATH)
        outlineContentGenerator = OutlineContentGenerator(config_path=CONFIG_PATH)
        
        print("ML Content Generators 初始化成功。")
    except Exception as e:
        print(f"警告: ML generator 初始化失败: {e}")
        ML_MODULES_LOADED = False
else:
    print("跳过 ML Generator 初始化，因为模块导入失败。")

# ---------------------------------
# 全局常量 (来自旧的 MLFullContentService)
# ---------------------------------
BASE_OVERHEAD_TIME = 5
TIME_PER_CHAR_PREPROCESS_KW = 0.5
TIME_PER_CHAR_PREPROCESS_MD = 0.02
TIME_PER_FILE_SPLIT = 7
TIME_PER_FILE_PAGINATE = 0.01
TIME_PER_FILE_MD_SPLIT = 0.01
TIME_PER_FILE_MANIM_CODE = 10
TIME_PER_FILE_SPEECH_SCRIPT = 20
TIME_PER_CHAR_AUDIO = 0.05
TIME_PER_FILE_BREAKPOINT = 15
TIME_PER_FILE_AUTOWAIT = 0.01
TIME_PER_FILE_ALIGN = 0.2
TIME_PER_FILE_ADD_BG = 0.01
TIME_PER_VIDEO_RENDER = 60
TIME_PER_VIDEO_MERGE_INDIVIDUAL = 0.05
TIME_PER_VIDEO_CONCAT = 5
TIME_FOR_COVER = 140
VOICE_MAP_PATH = Path("/home/TeachMasterAppV2/backend/minimax_voice_map.json")

def _load_voice_map() -> dict:
    """从 JSON 文件读取声线映射，不存在则返回空字典。"""
    if VOICE_MAP_PATH.exists():
        try:
            return json.loads(VOICE_MAP_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save_voice_map(mapping: dict) -> None:
    """将声线映射写回 JSON 文件。"""
    VOICE_MAP_PATH.write_text(
        json.dumps(mapping, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )


def get_or_create_voice_id_for_teacher(
    user_id: str,
    professor_name: str,
    is_default_audio: bool = False,
) -> tuple[str, bool]:
    """
    返回 (voice_id, existed)
    
    existed = True：表示 JSON 里已有记录，本次应复用声线。
    existed = False：表示第一次遇到，应执行 clone，并写入 JSON。

    is_default_audio = True 时：
        全系统共用同一条默认音频声线，key = "__GLOBAL_DEFAULT_VOICE__"
    """
    mapping = _load_voice_map()

    if is_default_audio:
        key = "__GLOBAL_DEFAULT_VOICE__"
    else:
        user_id = str(user_id or "").strip()
        professor_name = (professor_name or "").strip() or "UNKNOWN_TEACHER"
        key = f"{user_id}::{professor_name}"

    if key in mapping:
        return mapping[key], True, key

    voice_id = "v_" + uuid.uuid4().hex
    return voice_id, False, key

def persist_voice_id_for_teacher(key: str, voice_id: str) -> None:
    mapping = _load_voice_map()
    mapping[key] = voice_id
    _save_voice_map(mapping)


content_helper = ContentHelper()

# ---------------------------------
# 数据库通信辅助函数 (从同步线程调用)
# ---------------------------------

def update_status_sync(job_id: str, status: str, progress: int, message: str, **kwargs):
    """
    一个 "sync-over-async" 的 hack，允许从阻塞的同步函数 (如 generate_content_task_entry)
    中调用异步函数来更新数据库。
    """

    with get_sync_db_session_context() as db:
            print(f"[DB Update] Job {job_id}: {status} ({progress}%) - {message}")
            try:
                job = db.get(GenerationJob, job_id)
                if not job:
                    print(f"[DB Update] 错误: 任务 {job_id} 未在数据库中找到。")
                    return

                # 更新核心字段
                job.status = status
                job.progress = progress
                job.message = message

                # 处理可选字段
                if 'error' in kwargs:
                    job.error_message = kwargs["error"]
                if 'preview_data' in kwargs:
                    job.preview_data = kwargs["preview_data"]
                if 'result_files' in kwargs:
                    job.result_files = kwargs["result_files"]
                if 'settings' in kwargs:
                    job.settings = kwargs["settings"]
                if 'current_step_estimated_time' in kwargs:
                    job.current_step_estimated_time = kwargs["current_step_estimated_time"]
                    job.current_step_start_time = datetime.now().isoformat()
                
                # 自动设置时间戳
                if status == "running" and not job.started_at:
                    job.started_at = datetime.now().isoformat()
                if status in ("completed", "failed"):
                    job.completed_at = datetime.now().isoformat()
                                # 当任务到达预览阶段时，扣除T币
                if status == "awaiting_preview_decision":
                    # 检查是否已经扣除过T币（避免重复扣除）
                    job_uuid = uuid.UUID(job_id)
                    existing_transaction = db.query(TcoinTransactionLog).filter(
                        TcoinTransactionLog.related_job_id == job_uuid,
                        TcoinTransactionLog.transaction_type == TransactionType.CONSUMPTION,
                        TcoinTransactionLog.amount < 0  # 扣除操作
                    ).first()
                    
                    # 如果没有扣除记录，且不是使用token的任务，则扣除T币
                    if not existing_transaction and not job.access_token:
                        try:
                            user_id = uuid.UUID(job.user_id)
                            tcoin_service.debit_sync(
                                db=db,
                                user_id=user_id,
                                amount=COST_PER_JOB,
                                job_id=job_uuid,
                                notes=f"生成视频到达预览阶段：{job_id}"
                            )
                            print(f"[T币扣除] 任务 {job_id} 到达预览阶段，已扣除 {COST_PER_JOB} T币")
                        except ValueError as e:
                            # 余额不足或其他错误
                            print(f"[T币扣除] 警告: 任务 {job_id} 到达预览阶段，但扣除T币失败: {e}")
                            # 不阻止任务继续，但记录错误
                            job.error_message = f"T币扣除失败: {str(e)}"
                        except Exception as e:
                            print(f"[T币扣除] 错误: 任务 {job_id} 扣除T币时发生异常: {e}")
                            # 不阻止任务继续，但记录错误
                            job.error_message = f"T币扣除异常: {str(e)}"
                    
                db.add(job) # 将更改添加到会话
            
            except Exception as e:
                print(f"[DB Update] 严重错误: 更新任务 {job_id} 状态失败: {e}")
                # 回滚会在 get_db_session_context 的 except 块中自动调用
                raise # 重新抛出异常，让上层知道
# ---------------------------------
# 辅助函数
# ---------------------------------

def _setup_job_logger(job_id: str, log_dir: str) -> logging.Logger:
    """为指定的Job设置一个专用的日志记录器"""
    ensure_directory_exists(log_dir)
    log_file_path = os.path.join(log_dir, "generation_log.jsonl")
    
    logger = logging.getLogger(f"job_{job_id}")
    logger.setLevel(logging.INFO)
    
    # 防止重复添加handler
    if not logger.handlers:
        # 使用FileHandler将日志写入文件
        fh = logging.FileHandler(log_file_path, encoding='utf-8')
        fh.setLevel(logging.INFO)
        
        # 定义日志格式
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)
        
        # 为logger添加handler
        logger.addHandler(fh)
        
    return logger

def preprocess_keywords(keywords: str, request_output_dir: str, verbose: bool = False) -> str:
    """预处理关键词"""
    if not script_generator:
        raise RuntimeError("ScriptGenerator 未初始化。")
        
    output_dir = os.path.join(request_output_dir, "scripts", "full")
    os.makedirs(output_dir, exist_ok=True)
    script_file_path = script_generator.pipeline(keywords, output_dir=output_dir)
    return script_file_path

def ensure_directory_exists(directory: str) -> None:
    """确保目录存在，如果不存在则创建"""
    os.makedirs(directory, exist_ok=True)

def run_subprocess_command(command: list, logger: logging.Logger, description: str = "", verbose: bool = True) -> bool:
    """运行子进程命令，提供更好的错误处理和日志"""
    log_prefix = f"[{description}]" if description else "[Subprocess]"
    


    if verbose and description:
        print(f"正在执行: {description}")
    
    try:
        # 确保所有命令参数都是字符串
        command = [str(c) for c in command]
        logger.info(json.dumps({
            "event": "subprocess_start",
            "description": description,
            "command": ' '.join(command)
        }))
        # 部分外部命令可能输出非 UTF-8 字节，errors='replace' 避免解码异常
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=False,
            encoding='utf-8',
            errors='replace'
        )
        
        log_output = {
            "event": "subprocess_result",
            "description": description,
            "command": ' '.join(command),
            "return_code": result.returncode,
            "stdout": result.stdout.strip() if result.stdout is not None else None,
            "stderr": result.stderr.strip() if result.stderr is not None else None
        }

        if result.returncode != 0:
            if verbose:
                print(f"命令执行失败: {description}")
                print(f"返回码: {result.returncode}")
                if result.stdout: print(f"标准输出: {result.stdout}")
                if result.stderr: print(f"标准错误: {result.stderr}")
            
            logger.error(json.dumps(log_output, ensure_ascii=False))
            return False
        
        if verbose and result.stdout:
            print(f"命令输出: {result.stdout}")
            
        logger.info(json.dumps(log_output, ensure_ascii=False))
        return True
        
    except Exception as e:
        if verbose:
            print(f"执行命令时发生异常: {description}")
            print(f"错误信息: {str(e)}")
        
        logger.exception(json.dumps({
            "event": "subprocess_exception",
            "description": description,
            "command": ' '.join(command),
            "error": str(e)
        }))
        return False

def is_color(value: str) -> bool:
    return value.startswith("#") or value.isupper()

def remove_existing_background(file_path: str):
    """删除文件中已有的背景代码"""
    with open(file_path, "r", encoding='utf-8') as f:
        lines = f.readlines()
    
    new_lines = []
    in_bg_code = False
    
    for line in lines:
        if "###BACKGROUND###" in line and not in_bg_code:
            in_bg_code = True
            continue
        if in_bg_code:
            if "###BACKGROUND###" in line:
                in_bg_code = False
            continue
        new_lines.append(line)

    with open(file_path, "w", encoding='utf-8') as f:
        f.writelines(new_lines)

def insert_background_code(file_path: str, bg_code: str):
    remove_existing_background(file_path)
    with open(file_path, "r", encoding='utf-8') as f:
        lines = f.readlines()

    new_lines = []
    inserted = False
    for line in lines:
        new_lines.append(line)
        if not inserted and re.match(r"\s*def construct\(self\):", line):
            indent = re.match(r"(\s*)", line).group(1) + "    "  # 四空格缩进
            bg_code_indented = "".join(indent + line for line in bg_code.splitlines(True))
            new_lines.append(bg_code_indented)
            inserted = True

    if inserted:
        with open(file_path, "w", encoding='utf-8') as f:
            f.writelines(new_lines)
        print(f"插入成功: {file_path}")
    else:
        print(f"未找到 construct(self): 跳过: {file_path}")

def add_background(target_dir: str, bg_input: str, logger: logging.Logger):
    """为目标目录中的所有Manim代码文件添加背景"""
    if not os.path.exists(target_dir):
        error_msg = f"错误：目标目录不存在: {target_dir}"
        print(error_msg)
        logger.error(json.dumps({"event": "step_error", "step": "add_background", "error": error_msg}))
        return
        
    image_filename = None
    if not is_color(bg_input):
        image_filename = content_helper.copy_image_to_target_dir(bg_input, target_dir)
        
    bg_code = content_helper.build_background_code(bg_input, image_filename)
    
    python_files = [f for f in os.listdir(target_dir) if f.endswith(".py")]
    if not python_files:    
        warn_msg = f"警告：在目录 {target_dir} 中没有找到Python文件"
        print(warn_msg)
        logger.warning(json.dumps({"event": "step_warning", "step": "add_background", "message": warn_msg}))
        return
        
    print(f"找到 {len(python_files)} 个Python文件，开始处理...")
    logger.info(json.dumps({
        "event": "background_addition_details",
        "bg_input": bg_input,
        "target_dir": target_dir,
        "file_count": len(python_files)
    }))
    
    success_count = 0
    failed_files = []
    for filename in python_files:
        file_path = os.path.join(target_dir, filename)
        try:
            insert_background_code(file_path, bg_code)
            success_count += 1
        except Exception as e:
            error_msg = f"处理文件失败 {filename}: {str(e)}"
            print(error_msg)
            logger.warning(json.dumps({
                "event": "background_addition_file_error",
                "file": filename,
                "error": str(e)
            }))
            failed_files.append(filename)

    summary_log = {
        "event": "background_addition_summary",
        "success_count": success_count,
        "total_files": len(python_files)
    }
    if failed_files:
        summary_log["failed_files"] = failed_files
    logger.info(json.dumps(summary_log))
    print(f"\n处理完成！成功处理 {success_count}/{len(python_files)} 个文件")

def render_cover_and_ending(course_title: str, professor_name: str, 
                             avatar_image: str, background_image: str, 
                             output_dir: str, quality: str,
                             reference_audio: str, reference_text: str,language_now: str,  logger: logging.Logger) -> Dict[str, str]:
    """渲染课程封面和尾页视频"""
    if language_now == 'zh':
        # 如果是中文，则使用中文的渲染模块
        MergedLayoutScene = MergedLayoutScene2_cn
        EndingScene = EndingScene_cn
    else:
        # 默认使用英文的渲染模块
        MergedLayoutScene = MergedLayoutScene2
        EndingScene = EndingScene
        
    if not output_dir:
        output_dir = "./output"
    
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    quality_map = {
        "low": "low_quality",
        "medium": "medium_quality", 
        "high": "high_quality"
    }
    
    if quality not in quality_map:
        print(f"警告: 质量等级 '{quality}' 无效，使用默认高质量")
        quality = "high"
    
    print(f"开始渲染课程视频...")
    
    results = {}
    
    try:
        # 渲染封面视频
        print("🎬 渲染封面视频...")
        cover_output = output_path / "cover.mp4"
        max_try = 1
        for i in range(max_try):
            cover_file = _render_single_video(
                scene_class=MergedLayoutScene,
                title=course_title, avatar_image=avatar_image, professor_name=professor_name,
                background_image=background_image, output_path=str(cover_output), quality=quality,
                reference_audio=reference_audio, reference_text=reference_text,
                logger=logger,
                language_now=language_now
            )
            if cover_file:
                results['cover'] = str(cover_file)
                print(f"📹 封面视频: {cover_file}")
                break
        
        # 渲染尾页视频
        print("🎬 渲染尾页视频...")
        ending_output = output_path / "ending.mp4"
        for i in range(max_try):
            ending_file = _render_single_video(
                scene_class=EndingScene,
                title=course_title, avatar_image=avatar_image, professor_name=professor_name,
                background_image=background_image, output_path=str(ending_output), quality=quality,
                reference_audio=reference_audio, reference_text=reference_text,
                logger=logger,
                language_now=language_now
            )
            if ending_file:
                results['ending'] = str(ending_file)
                print(f"📹 尾页视频: {ending_file}")
                break
            
        print(f"✅ 封面和尾页渲染完成!")
        
    except Exception as e:
        print(f"❌ 封面/尾页渲染失败: {e}")
        logger.error(json.dumps({
            "event": "render_error",
            "error": str(e),
            "trace": traceback.format_exc(),
        }))
        import traceback
        traceback.print_exc()
    
    return results

def _render_single_video(scene_class, title: str, avatar_image: str, professor_name: str, 
                         background_image: str, output_path: str, quality: str, 
                         reference_audio: str = None, reference_text: str = None, logger: logging.Logger=None,language_now: str = 'zh' ) -> Optional[str]:
    """渲染单个视频文件"""
    try:
        quality_map = {
            "low": "low_quality",
            "medium": "medium_quality", 
            "high": "high_quality"
        }
        
        output_path_obj = Path(output_path).resolve()
        
        if output_path.endswith('.mp4') or '.' in output_path_obj.name:
            output_dir = output_path_obj.parent
            output_filename = output_path_obj.stem
        else:
            output_dir = output_path_obj
            output_filename = None
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        manim_config.media_dir = str(output_dir)
        
        manim_config.quality = quality_map[quality]
        
        if output_filename:
            manim_config.scene_names = [output_filename]
        
        scene = scene_class(class_title_text=title, avatar_image=avatar_image, 
                            professor_name=professor_name, background_image=background_image)
        try:
            scene.render()
        except Exception as e:
            logger.error(
                f"[COVER_RENDER_ERROR] Scene {scene_class.__name__} 渲染失败: {e}",
                exc_info=True
            )
            return None
        
        final_output_file = None
        if output_dir:
            video_dir = output_dir / "videos" / f"{manim_config.quality}"
            if not video_dir.exists():
                video_dirs = list(output_dir.glob("videos/*/"))
                if video_dirs:
                    for vdir in video_dirs:
                        if vdir.is_dir():
                            video_files = list(vdir.glob("*.mp4"))
                            if video_files:
                                video_dir = vdir
                                break
            
            if video_dir and video_dir.exists():
                video_files = list(video_dir.glob("*.mp4"))
                if video_files and output_filename:
                    original_file = video_files[0]
                    new_file = output_dir / f"{output_filename}.mp4"
                    if original_file != new_file:
                        original_file.rename(new_file)
                        final_output_file = new_file
                    else:
                        final_output_file = original_file
                elif video_files:
                    final_output_file = video_files[0]
                    
            if output_filename and final_output_file:
                txt_file = output_dir / f"{output_filename}.txt"
                scene_type = "封面" if scene_class == MergedLayoutScene2 else "尾页"
                if language_now == 'zh':
        # 中文文本内容
                    if scene_class == MergedLayoutScene2_cn:
                        txt_content = f"大家好！欢迎大家聆听本次课程，我是授课老师{professor_name}，今天让我们一起走进{title}吧。"
                    else:
                        txt_content = f"感谢大家聆听本次{title}课程，希望大家都有所收获！我是授课老师{professor_name}，期待与大家下次课程再见。"
                else:
        # 英文文本内容
                    if scene_class == MergedLayoutScene2:
                        txt_content = f"Hello everyone! Welcome to this semester's Machine Learning course. I am your instructor, {professor_name}, and today let's dive into {title} together."
                    else:
                        txt_content = f"Thank you for attending the {title} course. I hope you found it informative! I am {professor_name}, and I look forward to seeing you in the next class."
                
                with open(txt_file, 'w', encoding='utf-8') as f:
                    f.write(txt_content)
                print(f"📝 {scene_type}文本文件: {txt_file}")
                
                try:
                    audio_file = _generate_cover_audio(txt_content, output_dir, output_filename, reference_audio, reference_text, logger=logger)
                    if audio_file:
                        print(f"🎵 {scene_type}语音文件: {audio_file}")
                        
                        merged_file = _merge_cover_audio_video(
                            str(final_output_file), 
                            audio_file, 
                            output_dir, 
                            output_filename,
                            logger=logger
                        )
                        if merged_file:
                            print(f"🎬 {scene_type}合并文件: {merged_file}")
                            final_output_file = Path(merged_file)
                            try:
                                # 调用单视频字幕脚本烧录字幕
                                if txt_file.exists():
                                    if language_now == 'zh':
                                        subtitle_script = "/home/TeachMaster/ML/subtitle_single_cn.py"
                                    else:
                                        subtitle_script = "/home/TeachMaster/ML/subtitle_single.py"

                                    subtitle_cmd = [
                                        "/home/EduAgent/miniconda3/envs/aeneas_env/bin/python",
                                        subtitle_script,
                                        "--video", str(final_output_file),
                                        "--text", str(txt_file),
                                        "--output_dir", str(output_dir),
                                    ]

                                    run_subprocess_command(
                                        command=subtitle_cmd,
                                        description=f"为{scene_type}添加字幕",
                                        logger=logger
                                    )
                            except Exception as e:
                                print(f"⚠️ {scene_type}字幕生成失败: {e}")
                except Exception as e:
                    print(f"⚠️ {scene_type}语音生成失败: {e}")
        
        return str(final_output_file) if final_output_file else None
        
    except Exception as e:
        print(f"渲染单个视频失败: {e}")
        import traceback
        traceback.print_exc()
        return None

def _generate_cover_audio(text_content: str, output_dir: Path, filename: str, 
                          reference_audio: str = None, reference_text: str = None, logger: logging.Logger=None) -> Optional[str]:
    """为封面/尾页文本生成语音文件"""
    try:
        temp_input_dir = output_dir / f"{filename}_input"
        temp_input_dir.mkdir(exist_ok=True)
        
        temp_text_file = temp_input_dir / f"{filename}.txt"
        with open(temp_text_file, 'w', encoding='utf-8') as f:
            f.write(text_content)
        
        temp_output_dir = output_dir / f"{filename}_output"
        temp_output_dir.mkdir(exist_ok=True)
        
        wav_path = reference_audio or str(settings.DEFAULT_WAV_PATH)
        wav_prompt_path = reference_text or str(settings.DEFAULT_WAV_PROMPT_PATH)
        
        prompt_txt = ""
        if os.path.exists(wav_prompt_path):
            with open(wav_prompt_path, 'r', encoding='utf-8') as f:
                prompt_txt = f.read().strip()
        '''
        cosyvoice_command = [
            str(settings.PYTHON_PATH),
            str(settings.COSYVOICE_SCRIPT_PATH),
            str(temp_input_dir),
            str(temp_output_dir),
            "--prompt_wav", wav_path,
            "--prompt_text", prompt_txt,
        ]
        
        success = run_subprocess_command(command=cosyvoice_command, description=f"生成{filename}语音", logger=logger)
        '''
        user_voice_id = "v_" + uuid.uuid4().hex
        minimax_cmd = (
            f"source /home/EduAgent/miniconda3/etc/profile.d/conda.sh && "
            f"conda activate minimax_env && "
            f"python /home/TeachMasterAppV2/backend/batch_minimax_tts.py "
            f"--input_dir {temp_input_dir} "
            f"--output_dir {temp_output_dir} "
            f"--clone_audio {wav_path} "
            f"--voice_id {user_voice_id} "
            f"--model speech-02-hd "
            f"--prompt_text '{prompt_txt}'"
        )
        minimax_command = [
            "/bin/bash",
            "-c",
            minimax_cmd
        ]
        success = run_subprocess_command(command=minimax_command, description=f"生成{filename}语音", logger=logger)
        
        audio_file = None
        if success and temp_output_dir.exists():
            audio_files = list(temp_output_dir.glob("*.wav"))
            if audio_files:
                target_audio_file = output_dir / f"{filename}.wav"
                audio_files[0].rename(target_audio_file)
                audio_file = str(target_audio_file)
        
        if temp_input_dir.exists():
            shutil.rmtree(temp_input_dir)
        if temp_output_dir.exists():
            shutil.rmtree(temp_output_dir)
            
        return audio_file
            
    except Exception as e:
        print(f"生成封面语音失败: {e}")
        return None

def _merge_cover_audio_video(video_file: str, audio_file: str, output_dir: Path, filename: str, logger: logging.Logger=None) -> Optional[str]:
    """合并封面/尾页的音频和视频"""
    try:
        output_file = output_dir / f"{filename}-padded.mp4"
        
        # 假设 video_audio_merge_single.py 在项目根目录或已在 PATH 中
        merge_script_path = str("video_audio_merge_single.py")
        if not os.path.exists(merge_script_path):
            print(f"警告：合并脚本未找到 at {merge_script_path}，尝试使用全局命令")
            merge_script_path = "video_audio_merge_single.py" # 尝试全局

        merge_command = [
            str(settings.PYTHON_PATH),
            merge_script_path,
            audio_file,
            video_file,    
            str(output_file)
        ]
        
        success = run_subprocess_command(command=merge_command, description=f"合并{filename}音视频", logger=logger)
        
        if success and output_file.exists():
            return str(output_file)
        else:
            return None
            
    except Exception as e:
        print(f"合并封面音视频失败: {e}")
        return None

def concatenate_videos(video_files: List[str], output_path: str, logger: logging.Logger) -> Optional[str]:
    """使用ffmpeg的concat demuxer拼接多个视频文件"""
    try:
        existing_files = [f for f in video_files if f and os.path.exists(f)]
        
        if not existing_files:
            print("警告: 没有有效的视频文件可供拼接")
            return None
        
        if len(existing_files) == 1:
            shutil.copy2(existing_files[0], output_path)
            print(f"只有一个视频文件，直接复制: {existing_files[0]} -> {output_path}")
            return output_path
        
        temp_dir = os.path.dirname(output_path)
        file_list_path = os.path.join(temp_dir, "concat_list.txt")
        
        try:
            with open(file_list_path, 'w', encoding='utf-8') as f:
                for video_file in existing_files:
                    abs_path = os.path.abspath(video_file)
                    # 解决 ffmpeg 在 Windows 上的路径问题 (虽然服务器是 Linux)
                    abs_path_safe = abs_path.replace("\\", "/").replace("'", "'\\''")
                    f.write(f"file '{abs_path_safe}'\n")
            
            print(f"创建文件列表: {file_list_path}")
            print(f"拼接文件: {existing_files}")
            
            command = [
                "ffmpeg", "-y",
                "-f", "concat",
                "-safe", "0",
                "-i", file_list_path,
                "-c", "copy",
                output_path
            ]
            
            print(f"拼接视频命令: {' '.join(command)}")
            
            success = run_subprocess_command(command=command, description=f"拼接{len(existing_files)}个视频文件", logger=logger)
            
            if success and os.path.exists(output_path):
                print(f"视频拼接成功: {output_path}")
                return output_path
            else:
                print("视频拼接失败")
                return None
                
        finally:
            if os.path.exists(file_list_path):
                os.remove(file_list_path)
                
    except Exception as e:
        print(f"视频拼接过程中发生错误: {e}")
        if logger:
            logger.error(json.dumps({
                "event": "error",
                "message": f"视频拼接过程中发生错误: {e}"
            }, ensure_ascii=False))
        import traceback
        traceback.print_exc()
        return None

# def find_latest_file_with_keyword(query: str, directory: str, suffix: str = ".md") -> str:
#     """在指定目录中查找包含关键词的最新文件"""
#     if not os.path.exists(directory):
#         raise FileNotFoundError(f"目录不存在: {directory}")
    
#     files = [f for f in os.listdir(directory) if f.endswith(suffix)]
#     if not files:
#         raise FileNotFoundError(f"未找到 {suffix} 文件: {query} 在路径: {directory}")
    
#     candidate_files = [f for f in files if query in f]
#     if not candidate_files:
#         raise FileNotFoundError(f"未找到包含 {query} 的 {suffix} 文件在路径: {directory}")
    
#     try:
#         latest_file = max(candidate_files, key=lambda f: f.split('_')[-1].split('.')[0])
#         return latest_file
#     except (ValueError, IndexError):
#         latest_file = max(candidate_files, key=lambda f: os.path.getmtime(os.path.join(directory, f)))
#         return latest_file

def find_latest_file_with_keyword(query: str, directory: str, suffix: str = ".md") -> str:
    """
    在指定目录中查找包含关键词的最新文件。
    - 优先查找 suffix（默认 .md）文件；
    - 如果 suffix 为 ".md" 且未找到，则回退查找对应的 .txt，
      调用 txt2md.py 转为 .md 后再返回最新 .md 文件。
    """
    if not os.path.exists(directory):
        raise FileNotFoundError(f"目录不存在: {directory}")

    # ---------- 1. 先找指定后缀（默认 .md） ----------
    files = os.listdir(directory)
    candidate_files = [f for f in files if f.endswith(suffix) and query in f]

    if candidate_files:
        # 优先按文件名中的 "最后一个下划线后的字段" 排序
        try:
            latest_file = max(candidate_files, key=lambda f: f.split('_')[-1].split('.')[0])
        except (ValueError, IndexError):
            # 失败则按修改时间排序
            latest_file = max(
                candidate_files,
                key=lambda f: os.path.getmtime(os.path.join(directory, f))
            )
        return latest_file

    # ---------- 2. 如果找的是 .md 且没找到，尝试用 .txt 回退 ----------
    if suffix == ".md":
        txt_candidates = [f for f in files if f.endswith(".txt") and query in f]

        if not txt_candidates:
            raise FileNotFoundError(
                f"未找到包含 {query} 的 {suffix} 或 .txt 文件在路径: {directory}"
            )

        # 找最新的 txt
        try:
            latest_txt = max(txt_candidates, key=lambda f: f.split('_')[-1].split('.')[0])
        except (ValueError, IndexError):
            latest_txt = max(
                txt_candidates,
                key=lambda f: os.path.getmtime(os.path.join(directory, f))
            )

        txt_path = os.path.join(directory, latest_txt)

        # 调用 txt2md.py 转换
        subprocess.run(
            [sys.executable, "/home/TeachMasterAppV2/backend/txt2md.py", txt_path],
            check=True
        )

        # 转完再重新列一遍目录，找 .md
        files = os.listdir(directory)
        candidate_files = [f for f in files if f.endswith(".md") and query in f]
        if not candidate_files:
            raise FileNotFoundError(
                f"TXT 已转换，但仍未找到包含 {query} 的 .md 文件在路径: {directory}"
            )

        try:
            latest_md = max(candidate_files, key=lambda f: f.split('_')[-1].split('.')[0])
        except (ValueError, IndexError):
            latest_md = max(
                candidate_files,
                key=lambda f: os.path.getmtime(os.path.join(directory, f))
            )

        return latest_md

    # ---------- 3. 其它后缀且没找到，直接报错 ----------
    raise FileNotFoundError(f"未找到包含 {query} 的 {suffix} 文件在路径: {directory}")

# 将 paginated 章节按自然序号合并为单个文件，方便后续查看/调试
def merge_paginated_files(directory: str, output_filename: str = "full_paginated.md") -> str:
    """
    把目录下的 *_paginated.md 按数字序号 (1,2,3...) 合并，输出到同目录。
    如果找不到匹配文件则抛出 FileNotFoundError。
    返回合并文件的绝对路径。
    """
    if not os.path.exists(directory):
        raise FileNotFoundError(f"目录不存在: {directory}")

    paginated_files = [
        f for f in os.listdir(directory)
        if f.endswith("_paginated.md")
    ]
    if not paginated_files:
        raise FileNotFoundError(f"目录 {directory} 中未找到 *_paginated.md")

    def _numeric_key(name: str):
        # 取文件名前面的数字部分用于自然排序；失败则退回原名
        try:
            num = int(os.path.basename(name).split("_")[0])
            return (0, num, name)
        except Exception:
            return (1, name)

    paginated_files.sort(key=_numeric_key)

    output_path = os.path.join(directory, output_filename)
    main_h1: str | None = None
    h1_pattern = re.compile(r'^\s{0,3}#\s+(.+?)\s*#*\s*$')

    with open(output_path, "w", encoding="utf-8") as out_f:
        for idx, fname in enumerate(paginated_files):
            file_path = os.path.join(directory, fname)
            with open(file_path, "r", encoding="utf-8") as in_f:
                content = in_f.read()

            # 去除重复的全局 H1（如果各分页都带同一个 H1，则除首个外剔除）
            if main_h1 is None:
                for line in content.splitlines():
                    if line.strip():
                        m = h1_pattern.match(line)
                        if m:
                            main_h1 = m.group(1).strip()
                        break
            else:
                lines = content.splitlines()
                new_lines = []
                skipped = False
                i = 0
                while i < len(lines):
                    line = lines[i]
                    if not skipped and line.strip():
                        m = h1_pattern.match(line)
                        if m and m.group(1).strip() == main_h1:
                            skipped = True
                            i += 1
                            if i < len(lines) and lines[i].strip() == "":
                                i += 1
                            continue
                    new_lines.append(line)
                    i += 1
                content = "\n".join(new_lines)
            # 文件间用两个换行分隔，避免内容粘连
            if idx > 0:
                out_f.write("\n\n")
            out_f.write(content)
    return os.path.abspath(output_path)

# 将 full_paginated 按二级标题重新切分生成 *_paginated.md
def regenerate_paginated_from_full(full_path: str, target_dir: str) -> list[str]:
    h2_pattern = re.compile(r'^\s{0,3}##\s+.+$', re.MULTILINE)
    if not os.path.exists(full_path):
        raise FileNotFoundError(full_path)
    with open(full_path, "r", encoding="utf-8") as f:
        content = f.read()

    lines = content.splitlines()
    sections = []
    current = []
    for line in lines:
        if h2_pattern.match(line):
            if current:
                sections.append("\n".join(current).strip() + "\n")
            current = [line]
        else:
            current.append(line)
    if current:
        sections.append("\n".join(current).strip() + "\n")
    if not sections and content.strip():
        sections.append(content.strip() + "\n")
    if not sections:
        raise ValueError("full_paginated 内容为空或无法切分。")

    os.makedirs(target_dir, exist_ok=True)
    created = []
    for idx, sec in enumerate(sections, start=1):
        fname = f"{idx}_paginated.md"
        fpath = os.path.join(target_dir, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            f.write(sec)
        created.append(fname)
    # 拆分完成后删除 full_paginated，避免后续 MarkdownSplitter 再次把它切成 full_1.md 等
    try:
        os.remove(full_path)
    except Exception:
        pass
    return created

# 预审机制开始
def run_outline_check(outline_path: str, out_dir: str, logger: logging.Logger | None = None) -> tuple[str, str]:
    """
    调用 outline_check.py 对原始大纲做语义/逻辑审核。
    固定输出文件名为 suggestion.txt（存放在 out_dir 下）。
    返回 (建议文件路径, 建议文本)，失败则返回 ("", "")，不会中断主流程。
    """
    try:
        ensure_directory_exists(out_dir)
        cmd = [
            sys.executable,
            "/home/TeachMasterAppV2/backend/outline_check.py",
            "--outline_path",
            outline_path,
            "--out_suggestion",
            out_dir,
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if result.returncode != 0:
            if logger:
                logger.warning(
                    json.dumps(
                        {
                            "event": "outline_check_failed",
                            "outline": outline_path,
                            "return_code": result.returncode,
                            "stderr": result.stderr,
                        },
                        ensure_ascii=False,
                    )
                )
            return "", ""

        tmp_path = Path(out_dir) / f"{Path(outline_path).stem}_suggestion.txt"
        final_path = Path(out_dir) / "suggestion.txt"

        if not tmp_path.exists():
            return "", ""

        suggestion_text = tmp_path.read_text(encoding="utf-8")
        # 写入固定文件名，便于前端/后续流程定位
        final_path.write_text(suggestion_text, encoding="utf-8")
        try:
            tmp_path.unlink()  # 删除原始 <stem>_suggestion.txt，避免重复文件
        except Exception:
            pass
        return str(final_path), suggestion_text
    except Exception as e:
        if logger:
            logger.warning(
                json.dumps(
                    {
                        "event": "outline_check_exception",
                        "outline": outline_path,
                        "error": str(e),
                    },
                    ensure_ascii=False,
                )
            )
        return "", ""
# 预审机制结束

def preprocess_markdown(query: str, upload_file_path: str, request_output_dir: str, 
                        verbose: bool = False, logger: logging.Logger | None = None) -> str:
    """预处理 markdown 文件"""
    if not os.path.exists(upload_file_path):
        raise FileNotFoundError(f"用户请求目录不存在: {upload_file_path}")
    
    latest_file = find_latest_file_with_keyword(query, upload_file_path, suffix=".md")
    script_file_path = os.path.join(upload_file_path, latest_file)
    
    full_script_save_dir = os.path.join(request_output_dir, "scripts", "full")
    os.makedirs(full_script_save_dir, exist_ok=True)
    full_script_path = os.path.join(full_script_save_dir, "script_full.md")
    
    if not outlineContentGenerator:
        raise RuntimeError("OutlineContentGenerator 未初始化。")
        
    _ = outlineContentGenerator.pipeline(script_file_path, full_script_path, verbose=verbose)
    
    return full_script_path


def enhance_outline_short(raw_text: str, logger: logging.Logger | None = None) -> str:
    """
    轻量增强短大纲：调用 LLM 根据模板在原文基础上微调/补充。
    失败时返回原文以确保流程不中断。
    """
    try:
        client = LLMAPIClient()
        prompt = client.load_prompt_template("ShortEnhance")
        prompt = prompt.replace("{{outline}}", raw_text)
        enhanced = client.call_api_with_text(prompt)
        # 防御：若返回空/极短，则回退
        if not enhanced or len(enhanced.strip()) < 10:
            if logger:
                logger.warning("short_enhance returned empty, fallback to raw text")
            return raw_text
        return enhanced
    except Exception as e:
        if logger:
            logger.warning(f"short_enhance_failed: {e}")
        return raw_text

def preprocess_short(query: str, upload_file_path: str, request_output_dir: str, 
                     verbose: bool = False, logger: logging.Logger | None = None) -> str:
    """预处理 markdown 文件（简化版，不经过 outlineContentGenerator.pipeline）"""
    if not os.path.exists(upload_file_path):
        raise FileNotFoundError(f"用户请求目录不存在: {upload_file_path}")
    
    # 查找最新的 markdown 文件
    latest_file = find_latest_file_with_keyword(query, upload_file_path, suffix=".md")
    script_file_path = os.path.join(upload_file_path, latest_file)
    
    # 创建保存目录
    full_script_save_dir = os.path.join(request_output_dir, "scripts", "short")
    os.makedirs(full_script_save_dir, exist_ok=True)
    
    # 设置处理后的文件路径
    full_script_path = os.path.join(full_script_save_dir, "script_short.md")

    # 读取原文
    with open(script_file_path, "r", encoding="utf-8") as f:
        raw_text = f.read()

    # 轻量增强：调用短流程专用 prompt，失败时回退到原文
    enhanced_text = enhance_outline_short(raw_text, logger=logger)

    # 写出结果
    with open(full_script_path, "w", encoding="utf-8") as f:
        f.write(enhanced_text)
    
    return full_script_path

def generate_outline_with_attachments(query: str, upload_file_path: str, upload_attachment_dir: str, request_output_dir: str, verbose: bool = False) -> str:
        """
        生成带附件的大纲，并执行相应的命令行操作

        参数:
            query: 关键词或文件名
            upload_file_path: 上传文件路径
            upload_attachment_dir: 上传附件目录
            request_output_dir: 请求输出目录
            verbose: 是否输出详细信息
        
        返回:
            生成的大纲文件路径
        """
        # 检查附件文件夹是否非空
        if not os.path.exists(upload_attachment_dir):
            raise FileNotFoundError(f"附件文件夹不存在: {upload_attachment_dir}")

        if len(os.listdir(upload_attachment_dir)) == 0:
            raise FileNotFoundError(f"附件文件夹为空: {upload_attachment_dir}")

        # 查找对应的文件
        latest_file = find_latest_file_with_keyword(query, upload_file_path, suffix=".md")
        file_path = os.path.join(upload_file_path, latest_file)

        # 设置输出目录路径
        full_outline_save_dir = os.path.join(request_output_dir, "scripts", "full")
        os.makedirs(full_outline_save_dir, exist_ok=True)
        full_outline_path = os.path.join(full_outline_save_dir, "script_full.md")

        # 执行命令，生成大纲并处理附件
        command = [
            "/home/EduAgent/miniconda3/envs/edu_env/bin/python", 
            "/home/TeachMaster/ML/outline_content_generator_attachment_test.py",
            "--outline", file_path,  # 传入找到的文件路径
            "--attachments", str(upload_attachment_dir),  # 附件文件夹路径
            "--output", full_outline_save_dir  # 输出目录
        ]

        try:
            # 执行命令
            subprocess.run(command, check=True)
            if verbose:
                print(f"大纲和附件处理完成，输出路径: {full_outline_path}")
        except subprocess.CalledProcessError as e:
            print(f"运行 outline_content_generator_attachment_test.py 失败: {e}")
            raise e

        return full_outline_path

def _cleanup_media_folders_after_render(manim_code_final_output_path: str):
    """清理渲染过程中产生的media文件夹"""
    try:
        manim_media_dir = os.path.join(manim_code_final_output_path, "media")
        if os.path.exists(manim_media_dir):
            print(f"🧹 清理manim_codes_final中的media目录: {manim_media_dir}")
            shutil.rmtree(manim_media_dir)
            print(f"✅ 清理完成")
        
        backend_media_dir = "media"
        if os.path.exists(backend_media_dir):
            print(f"🧹 清理项目根目录中的media目录: {backend_media_dir}")
            shutil.rmtree(backend_media_dir)
            print(f"✅ 清理完成")
            
        if os.path.exists(manim_code_final_output_path):
            for item in os.listdir(manim_code_final_output_path):
                item_path = os.path.join(manim_code_final_output_path, item)
                if os.path.isdir(item_path) and item == "media":
                    print(f"🧹 清理发现的额外media目录: {item_path}")
                    shutil.rmtree(item_path)
                    
    except Exception as e:
        print(f"⚠️ 清理media文件夹时发生错误: {e}")
        import traceback
        traceback.print_exc()

def _fix_background_image_paths_in_code_file(self, code_file_path: str):
    """修复代码文件中的背景图片路径，确保使用绝对路径"""
    try:
        print(f"🔧 修复背景图片路径: {code_file_path}")
        
        with open(code_file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        pattern = r'ImageMobject\("([^"]+)"\)'
        matches = re.findall(pattern, content)
        
        modified = False
        
        for image_path in matches:
            if not os.path.isabs(image_path):
                print(f"    发现相对路径: {image_path}")
                
                possible_paths = [
                    image_path,
                    os.path.join(os.path.dirname(code_file_path), image_path),
                ]
                
                found_path = None
                for possible_path in possible_paths:
                    if os.path.exists(possible_path):
                        found_path = str(possible_path.resolve())
                        print(f"    ✅ 找到图片: {found_path}")
                        break
                
                if found_path:
                    old_pattern = f'ImageMobject("{image_path}")'
                    # 确保路径在 Python 字符串中是安全的
                    new_path_escaped = found_path.replace("\\", "\\\\")
                    new_pattern = f'ImageMobject(r"{new_path_escaped}")' # 使用 r-string
                    content = content.replace(old_pattern, new_pattern)
                    modified = True
                    print(f"    🔄 替换: {image_path} -> {new_path_escaped}")
                else:
                    print(f"    ⚠️ 找不到图片文件: {image_path}")
                    print(f"    尝试的路径: {possible_paths}")
        
        if modified:
            with open(code_file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✅ 背景图片路径修复完成")
        else:
            print(f"📁 无需修复背景图片路径")
            
    except Exception as e:
        print(f"⚠️ 修复背景图片路径时发生错误: {e}")
        import traceback
        traceback.print_exc()
def _regenerate_segment_subtitles(
    job: GenerationJob,
    segment_id: str,
    preview_data: Dict[str, Any],
    request_output_dir: str,
    logger: logging.Logger,
    merge_success: bool,
) -> None:
    """
    在单个片段的音视频合并完成后，按需要重新生成字幕。

    注意：这是一个“附加步骤”，失败不会中断主流程。
    """
    try:
        # 仅在合并成功且开启了字幕时才处理
        request_payload = getattr(job, "request_payload", {}) or {}
        enable_subtitles = request_payload.get("enable_subtitles", True)
        if not enable_subtitles or not merge_success:
            return

        speech_script_path = preview_data.get("speech_script_original_path")
        video_wo_audio_path = preview_data.get("video_wo_audio_path")
        video_w_audio_path = preview_data.get("video_w_audio_path")

        if not speech_script_path or not video_wo_audio_path:
            print("⚠️ 重新生成字幕时缺少必要路径（speech_script_original_path 或 video_wo_audio_path）")
            return

        print(f"📝 开始重新生成字幕: {segment_id}")

        temp_video_dir = os.path.join(request_output_dir, "temp_video_single")
        temp_text_dir = os.path.join(request_output_dir, "temp_text_single")
        temp_output_dir = os.path.join(request_output_dir, "temp_subtitle_single")

        ensure_directory_exists(temp_video_dir)
        ensure_directory_exists(temp_text_dir)
        ensure_directory_exists(temp_output_dir)

        # 使用“最新音频”的视频作为输入：来自 video_wo_audio_path
        source_video = os.path.join(video_wo_audio_path, f"{segment_id}.mp4")
        source_text = os.path.join(speech_script_path, f"{segment_id}.txt")

        if not (os.path.exists(source_video) and os.path.exists(source_text)):
            print(f"⚠️ 重新生成字幕所需文件不存在: video={source_video}, text={source_text}")
            return

        import shutil

        temp_video_file = os.path.join(temp_video_dir, f"{segment_id}.mp4")
        temp_text_file = os.path.join(temp_text_dir, f"{segment_id}.txt")

        shutil.copy2(source_video, temp_video_file)
        shutil.copy2(source_text, temp_text_file)


        # 语言判断
        language_now = job.settings.get("content_language", "zh") \
            if job.settings else "zh"

        if language_now == "zh":
            subtitle_script = "/home/TeachMaster/ML/subtitle_single_cn.py"
        else:
            subtitle_script = "/home/TeachMaster/ML/subtitle_single.py"

        subtitle_command = [
            "/home/EduAgent/miniconda3/envs/aeneas_env/bin/python",
            subtitle_script,
            "--video", temp_video_file,
            "--text", temp_text_file,
            "--output_dir", temp_output_dir,
        ]


        success_subtitle = run_subprocess_command(
            command=subtitle_command,
            description=f"重新生成{segment_id}字幕",
            logger=logger,
        )

        if success_subtitle:
            generated_subtitle_video = os.path.join(temp_output_dir, f"{segment_id}.mp4")
            if os.path.exists(generated_subtitle_video):
                # 最终预览优先写回 video_w_audio_path；若不存在则回写到 video_wo_audio_path
                target_dir = video_w_audio_path or video_wo_audio_path
                ensure_directory_exists(target_dir)
                target_video = os.path.join(target_dir, f"{segment_id}.mp4")
                shutil.copy2(generated_subtitle_video, target_video)
                print(f"✅ 字幕重新生成完成: {segment_id}")
            else:
                print(f"⚠️ 字幕视频文件未找到: {generated_subtitle_video}")
        else:
            print(f"⚠️ 字幕生成失败: {segment_id}")

    except Exception as e:
        print(f"⚠️ 字幕生成过程中发生错误: {e}")
        logger.warning(
            json.dumps(
                {
                    "event": "subtitle_generation_error",
                    "segment_id": segment_id,
                    "error": str(e),
                }
            )
        )
    finally:
        # 清理临时目录
        for d in (
            os.path.join(request_output_dir, "temp_video_single"),
            os.path.join(request_output_dir, "temp_text_single"),
            os.path.join(request_output_dir, "temp_subtitle_single"),
        ):
            if os.path.exists(d):
                shutil.rmtree(d)


def _wait_for_user_or_timeout(job_id: str):
        """
        通过轮询数据库来“暂停”
        """
        print(f"Job [{job_id}]: ⏳ 进入等待循环 (DB Polling)...")
        with get_sync_db_session_context() as db:
            while True:
                db.commit()
                # 1. 每次循环都从数据库获取最新状态
                job =  db.get(GenerationJob, job_id)
                
                if not job:
                    raise Exception("Task lost in database!")
                db.refresh(job)

                current_status = job.status
                deadline = job.settings.get("deadline", None)
                
                # A. 检测到用户已确认 (API 修改了数据库状态)
                # 我们约定：用户确认后，API 会把状态改为 'CONFIRMED'
                if current_status == "CONFIRMED":
                    print(f"Job [{job_id}]: ▶️ 发现状态变为 CONFIRMED")
                    # 返回数据库中最新的讲义内容 (可能是用户修改过的)
                    return

                # B. 检测超时 (心跳停止)
                if time.time() > deadline:
                    print(f"Job [{job_id}]: ⏰ 截止时间已过 ({deadline})")
                    # 返回当前的讲义内容
                    return

                # C. 继续等待
                # 这里的 sleep 是为了避免疯狂查询数据库，减轻 DB 压力
                time.sleep(5) 
                db.commit()

# ... (旧的 save/regenerate 函数，现在是 helper) ...
# 注意: 它们现在是顶级函数，不再有 `self`

# ---------------------------------
# 主要任务函数 1: 初始生成
# ---------------------------------

def generate_content_task_entry(job: GenerationJob, request: GenerationRequest):
    """
    同步执行的内容生成任务 (第 1 部分)。
    由 ARQ worker 在一个单独的线程中调用。
    """
    job_id = job.id
    if not ML_MODULES_LOADED:
        print("❌ ML 模块未加载，无法执行生成任务。")
        update_status_sync(job_id, "failed", 0, "服务器配置错误：ML模块加载失败", error="ML_MODULES_LOADED is False")
        return

    update_status_sync(
        job_id=job_id,
        status="initializing", 
        progress=0, 
        message="正在初始化生成环境...",
        current_step_estimated_time=30
    )
        
    mode = request.mode
    keywords = request.keyword
    isLongVideo = request.isLongVideo
    verbose = True
    
    user_id = str(request.user_id) # 确保是字符串

    output_root_path = str(settings.GENERATED_CONTENT_DIR)
    request_output_dir = os.path.join(output_root_path, user_id, str(job_id))

    logger = _setup_job_logger(job_id, request_output_dir)
    content_helper.setManimAutoWaitGenerator(request.content_language)

    enable_subtitles=request.enable_subtitles
    language_now = request.content_language

    try:
        # 定义默认文件路径
        background_image_path = str(settings.DEFAULT_BACKGROUND_IMAGE)
        wav_path = str(settings.DEFAULT_WAV_PATH)
        wav_prompt_path = str(settings.DEFAULT_WAV_PROMPT_PATH)
        
        # 检查是否提供了自定义文件
        uploads_dir = Path(settings.UPLOADS_DIR)
        
        if request.background_image_id:
            background_image_dir = uploads_dir / "backgrounds"
            for file in background_image_dir.iterdir():
                if file.name.startswith(request.background_image_id):
                    background_image_path = str(file)
                    break
        
        if request.reference_audio_id:
            audio_dir = uploads_dir / "audios"
            for file in audio_dir.iterdir():
                if file.name.startswith(request.reference_audio_id):
                    wav_path = str(file)
                    print("🚀 开始加载 Whisper 模型...")
                    model = whisper.load_model("medium")
                    print("✅ Whisper 模型加载完毕。")

                    print(f"🔊 正在识别音频文件: {wav_path}")
                    result = model.transcribe(wav_path, language="zh", fp16=False, initial_prompt="以下是普通话的句子。")
                    transcribed_text = result['text']
                    print(f"🔊 识别到的文本: {transcribed_text}")
                    
                    text_dir = uploads_dir / "texts"
                    text_dir.mkdir(parents=True, exist_ok=True)
                    text_file_path = text_dir / f"{str(uuid.uuid4())}.txt"
                    with open(text_file_path, "w", encoding="utf-8") as f:
                        f.write(transcribed_text)
                    wav_prompt_path = str(text_file_path)
                    print(f"🔊 保存识别的文本到文件: {wav_prompt_path}")
                     # 日志
                    break

        upload_md_dir = uploads_dir / 'md'
        start_time = time.time()
        time_dict = {}

        page = 0 # page = token_details['page'] # 你需要从 request 中获取 page（如果需要）

        logger.info(json.dumps({
                "event": "job_start", 
                "job_id": job_id, 
                "user_id": user_id,
                "page": page,
                "message": "Generation process started."
            }))
        
        # --- 步骤 0: 生成封面和尾页 ---
        cover_files = {}
        course_title = request.course_title or keywords
        professor_name = request.professor_name or "Prof. Siheng Chen"
        
        # 获取头像
        avatar_image = str("/home/TeachMasterAppV2/backend/csh.png") # 默认头像
        if request.avatar_image_id:
            avatar_dir = uploads_dir / "avatars"
            for file in avatar_dir.iterdir():
                if file.name.startswith(request.avatar_image_id):
                    avatar_image = str(file)
                    break

        # 以前封面和其他页逻辑是不一样的，所以封面背景是单独传，现在直接用来复用作校徽所以这里名字很奇怪，凑合过吧
        logo_image = str("/home/TeachMasterAppV3/backend/logo.png")
        if request.cover_background_image_id:
            logo_dir = uploads_dir / "cover_backgrounds"
            for file in logo_dir.iterdir():
                if file.name.startswith(request.cover_background_image_id):
                    logo_image = str(file)
                    break

        # 保存配置到数据库
        settings_data = {
            "background_image": str(background_image_path),
            "reference_audio": str(wav_path),
            "reference_text": str(wav_prompt_path),
            "course_title": str(course_title),
            "professor_name": str(professor_name),
            "avatar_image": str(avatar_image),
            "keyword": str(request.keyword),
            "content_language": str(language_now)
        }
        prompt_txt = ""
        with open(wav_prompt_path, 'r', encoding='utf-8') as f:
            prompt_txt = f.read().strip()

        update_status_sync(job_id, "initializing", 2, "配置已保存", settings=settings_data, current_step_estimated_time=TIME_FOR_COVER)
        uploads_ppt_dir = uploads_dir / "ppt"
        if mode == 'ppt':

            speech_audio_output_path = os.path.join(request_output_dir, "speech_audio")
            speech_output_path = os.path.join(request_output_dir, "speech")

            if enable_subtitles == True:
                video_w_audio_output_path = os.path.join(request_output_dir, "video_w_subtitles")
                ppt2video_command = [
                    "/home/EduAgent/miniconda3/envs/edu_env/bin/python",
                    "/home/TeachMaster/ML/ppt2video_stage1.py", # 使用并行版本
                    "--lang", "cn" if language_now == "zh" else "en", 
                    "--voice_id", "v" +keywords,
                    "--input_dir", uploads_ppt_dir,
                    "--output_dir", request_output_dir,
                    "--tts_mode", "1",
                    "--require_subtitle",
                    "--render_workers", "4",
                    "--quality", "h",
                    "--prompt_audio", wav_path,
                    "--prompt_text", wav_prompt_path
                ]
                run_subprocess_command(ppt2video_command, logger=logger)
            else:
                video_w_audio_output_path = os.path.join(request_output_dir, "video_w_audios")
                ppt2video_command = [
                    "/home/EduAgent/miniconda3/envs/edu_env/bin/python",
                    "/home/TeachMaster/ML/ppt2video_stage1.py", # 使用并行版本
                    "--lang", "cn" if language_now == "zh" else "en", 
                    "--voice_id", "v" +keywords,
                    "--input_dir", uploads_ppt_dir,
                    "--output_dir", request_output_dir,
                    "--tts_mode", "1",
                    "--render_workers", "4",
                    "--quality", "h",
                    "--prompt_audio", wav_path,
                    "--prompt_text", wav_prompt_path
                ]
                run_subprocess_command(ppt2video_command, logger=logger)

            manim_code_path = os.path.join(request_output_dir, "manim_codes")
            video_wo_audio_output_path = os.path.join(request_output_dir, "video_wo_audios")
            preview_data_payload = {
                "manim_code_path": str(manim_code_path),
                "video_w_audio_path": str(video_w_audio_output_path),
                "video_wo_audio_path": str(video_wo_audio_output_path),
                "speech_script_original_path": str(speech_output_path),
                "speech_script_path": str(speech_output_path),
                "speech_audio_path": str(speech_audio_output_path),
            }
        
            update_status_sync(
                job_id,
                status="awaiting_preview_decision", 
                progress=95, 
                message="视频渲染完成，等待预览选择...",
                preview_data=preview_data_payload
            )
        
            logger.info(json.dumps({
                "event": "process_pause",
                "status": "awaiting_preview_decision"
            }))
            return
        '''
        if request.generate_cover:
            update_status_sync(job_id, "cover_generation", 4, "生成封面和尾页...", current_step_estimated_time=TIME_FOR_COVER)
            logger.info(json.dumps({"event": "step_start", "step": "render_cover_and_ending"}))
            
            cover_output_dir = os.path.join(request_output_dir, "cover_ending")
            try:
                cover_files = render_cover_and_ending(
                    course_title=course_title,
                    professor_name=professor_name,
                    avatar_image=avatar_image,
                    background_image=cover_background,
                    output_dir=cover_output_dir,
                    quality="high",
                    reference_audio=wav_path,
                    reference_text=wav_prompt_path,
                    language_now=request.content_language,
                    logger=logger
                )
                logger.info(json.dumps({
                        "event": "step_result", 
                        "step": "render_cover_and_ending",
                        "output": cover_files
                    }))
            except Exception as e:
                logger.error(json.dumps({
                        "event": "step_error", 
                        "step": "render_cover_and_ending", 
                        "error": str(e)
                    }))
        '''
        # --- 步骤 1: 大纲预审，等待用户确认 ---
        original_outline_path = ""
        suggestion_path = ""
        suggestion_text = ""

        if mode == "outline":
            try:
                md_file_path = find_latest_file_with_keyword(keywords, upload_md_dir, suffix=".md")
                original_outline_path = os.path.join(upload_md_dir, md_file_path)

                # 运行大纲审核：输出 suggestion.txt，供前端查看
                precheck_dir = os.path.join(request_output_dir, "scripts", "precheck")
                suggestion_path, suggestion_text = run_outline_check(
                    outline_path=original_outline_path,
                    out_dir=precheck_dir,
                    logger=logger,
                )
                if suggestion_text:
                    settings_data["outline_suggestion"] = suggestion_text
                if suggestion_path:
                    settings_data["outline_suggestion_path"] = suggestion_path
            except Exception as e:
                logger.warning(json.dumps({
                    "event": "outline_precheck_failed",
                    "error": str(e)
                }, ensure_ascii=False))
                original_outline_path = ""

        initial_deadline = time.time() + 20
        settings_data["deadline"] = initial_deadline
        # notes_path 指向用户可编辑的原始大纲
        settings_data["notes_path"] = original_outline_path
        update_status_sync(job_id, "awaiting_check", 12, "等待用户输入...", settings=settings_data)
        # --- 等待用户 (check) ---
        _wait_for_user_or_timeout(job_id)

        # --- 步骤 1b: 预处理（在用户确认后执行） ---
        estimated_time = BASE_OVERHEAD_TIME
        if mode == "ppt": # PPT模式
            estimated_time += int(len(keywords) * TIME_PER_CHAR_PREPROCESS_KW)
            print(f"预估预处理时间 (关键词模式): {estimated_time}秒 ({len(keywords)}个字符)")
        elif mode == "outline": # outline模式
            try:
                if original_outline_path and os.path.exists(original_outline_path):
                    with open(original_outline_path, 'r', encoding='utf-8') as f:
                        content_len = len(f.read())
                    estimated_time += int(content_len * TIME_PER_CHAR_PREPROCESS_MD)
                    print(f"预估预处理时间 (MD模式): {estimated_time}秒 ({content_len}个字符)")
                else:
                    estimated_time += 60
            except Exception:
                estimated_time += 60

        update_status_sync(job_id, "pre_processing", 8, "预处理...", current_step_estimated_time=estimated_time)
         # 日志
        try:
            if mode == "ppt":
                script_file_path = preprocess_keywords(keywords, request_output_dir, verbose=verbose)
            elif mode == "outline":
                if isLongVideo:
                    if request.attachment_dir_id:
                        upload_attachment_dir = Path(settings.UPLOADS_DIR) / "attachments" / request.attachment_dir_id
                        if os.path.exists(upload_attachment_dir) and len(os.listdir(upload_attachment_dir)) > 0:
                            script_file_path = preprocess_markdown(
                                query=keywords, 
                                upload_file_path=str(upload_md_dir), 
                                request_output_dir=request_output_dir, 
                                verbose=verbose,
                                logger=logger,
                            )
                        else:
                            script_file_path = preprocess_markdown(
                                query=keywords, 
                                upload_file_path=str(upload_md_dir), 
                                request_output_dir=request_output_dir, 
                                verbose=verbose,
                                logger=logger,
                            )
                    else:
                        script_file_path = preprocess_markdown(
                            query=keywords, 
                            upload_file_path=str(upload_md_dir), 
                            request_output_dir=request_output_dir, 
                            verbose=verbose,
                            logger=logger,
                        )
                else:
                    script_file_path = preprocess_short(
                        query=keywords, 
                        upload_file_path=str(upload_md_dir), 
                        request_output_dir=request_output_dir, 
                        verbose=verbose,
                        logger=logger,
                    )
            else:
                raise ValueError(f"不支持的模式: {mode}")
            logger.info(json.dumps({ "output_path": script_file_path }))
        except Exception as e:
             # 日志
            raise e

        time_dict["preprocess_time"] = time.time() - start_time

        # --- 步骤 2: 脚本分割 ---
        estimated_time = BASE_OVERHEAD_TIME + TIME_PER_FILE_SPLIT
        update_status_sync(job_id, "script_splitting", 16, "脚本分割...", current_step_estimated_time=estimated_time)
        script_splited_output_folder = os.path.join(request_output_dir, "scripts", "splitted")
        ensure_directory_exists(script_splited_output_folder)
         # 日志
        try:
            scriptSplitter.pipeline(script_file_path, output_dir=script_splited_output_folder, page=page)
             # 日志
        except Exception as e:
             # 日志
            raise e
        time_dict["split_time"] = time.time() - start_time - time_dict["preprocess_time"]

        # --- 步骤 3: 分页处理 ---
        num_files = len(os.listdir(script_splited_output_folder))
        estimated_time = BASE_OVERHEAD_TIME + num_files * TIME_PER_FILE_PAGINATE
        update_status_sync(job_id, "pagination", 24, "分页处理...", current_step_estimated_time=estimated_time)
        try:
            script_paginated_output_folder = os.path.join(request_output_dir, "scripts", "paginated")
            ensure_directory_exists(script_paginated_output_folder)
             # 日志
            paginator.pipeline(script_splited_output_folder, output_dir=script_paginated_output_folder)
            # 在分页结果基础上生成整合文件，便于人工检查/调试
            try:
                merged_paginated_path = merge_paginated_files(script_paginated_output_folder)
                logger.info(json.dumps({
                    "event": "paginated_merge_success",
                    "merged_file": merged_paginated_path
                }))
                # 删除除 full_paginated.md 以外的其他 .md（为后续用户编辑留出单一入口）
                for fname in os.listdir(script_paginated_output_folder):
                    if fname.endswith(".md") and fname != "full_paginated.md":
                        try:
                            os.remove(os.path.join(script_paginated_output_folder, fname))
                        except Exception as e:
                            logger.warning(json.dumps({
                                "event": "paginated_cleanup_failed",
                                "file": fname,
                                "error": str(e)
                            }, ensure_ascii=False))
            except Exception as e:
                logger.warning(json.dumps({
                    "event": "paginated_merge_failed",
                    "error": str(e)
                }, ensure_ascii=False))
             # 日志
            time_dict["paginate_time"] = time.time() - start_time - sum(time_dict.values())
        except Exception as e:
             # 日志
            raise e
        
        # --- 新增：分页审阅等待 ---
        try:
            paginated_files = [
                f for f in os.listdir(script_paginated_output_folder)
                if f.endswith("_paginated.md")
            ]
            paginated_files.sort(key=lambda name: (0, int(name.split("_")[0])) if name.split("_")[0].isdigit() else (1, name))
        except Exception:
            paginated_files = []

        # 默认只等 10 秒；若前端在当前页面会通过心跳续命（见 /notes-heartbeat）
        pagination_deadline = time.time() + 10
        settings_data["deadline"] = pagination_deadline

        pagination_full_content = ""
        try:
            if 'merged_paginated_path' in locals() and merged_paginated_path and os.path.exists(merged_paginated_path):
                with open(merged_paginated_path, "r", encoding="utf-8") as f:
                    pagination_full_content = f.read()
        except Exception:
            pagination_full_content = ""

        pagination_preview_data = {
            "pagination_full_path": merged_paginated_path if 'merged_paginated_path' in locals() else "",
            "pagination_full_content": pagination_full_content,
            "pagination_files": paginated_files
        }

        update_status_sync(
            job_id,
            status="awaiting_pagination_review",
            progress=27,
            message="分页结果生成完成，等待用户确认...",
            settings=settings_data,
            preview_data=pagination_preview_data,
            current_step_estimated_time=int(pagination_deadline - time.time())
        )
        _wait_for_user_or_timeout(job_id)
            
        # --- 步骤 4: Markdown分割 ---
        # 若分页文件被清空（只剩 full_paginated.md），从 full 重新生成 *_paginated.md
        try:
            existing_paginated = [
                f for f in os.listdir(script_paginated_output_folder)
                if f.endswith("_paginated.md")
            ]
            full_paginated_path = os.path.join(script_paginated_output_folder, "full_paginated.md")
            if (not existing_paginated) and os.path.exists(full_paginated_path):
                regenerate_paginated_from_full(full_paginated_path, script_paginated_output_folder)
                existing_paginated = [
                    f for f in os.listdir(script_paginated_output_folder)
                    if f.endswith("_paginated.md")
                ]
        except Exception as e:
            logger.warning(json.dumps({
                "event": "paginated_regenerate_warning",
                "error": str(e)
            }, ensure_ascii=False))

        num_files = len([f for f in os.listdir(script_paginated_output_folder) if f.endswith("_paginated.md")])
        estimated_time = BASE_OVERHEAD_TIME + num_files * TIME_PER_FILE_MD_SPLIT
        update_status_sync(job_id, "markdown_splitting", 32, "Markdown分割...", current_step_estimated_time=estimated_time)
         # 日志
        try:
            markdownSplitter.pipeline(script_paginated_output_folder)
             # 日志
            time_dict["markdown_split_time"] = time.time() - start_time - sum(time_dict.values())
        except Exception as e:
             # 日志
            raise e

        # --- 步骤 5: 生成Manim代码 ---
        if language_now == 'zh':
            # cover和end的代码就放到manim_FINAL
            manimcode_generator = ManimCodeGenerator_cn(config_path=CONFIG_PATH)
        else:
            manimcode_generator = ManimCodeGenerator(config_path=CONFIG_PATH)
# 新增---------

        # 为首尾页生成真正用于渲染的 0_1.py / 999_1.py，放到 manim_codes_final 目录
        manim_code_final_output_path = os.path.join(request_output_dir, "manim_codes_final")
        ensure_directory_exists(manim_code_final_output_path)

        cover_code_path = os.path.join(manim_code_final_output_path, "0_1.py")
        ending_code_path = os.path.join(manim_code_final_output_path, "999_1.py")
        '''
        # 把参数先变成安全的 Python 字面量，避免引号出问题
        course_title_lit = repr(course_title)
        professor_name_lit = repr(professor_name)
        head_avatar_path = avatar_image
        if avatar_image.startswith("/uploads"):
            head_avatar_path = os.path.join(
                "/home/TeachMasterAppV2/backend",
                avatar_image.lstrip("/")
            )
        avatar_image_lit = repr(head_avatar_path)
        head_bg_path = background_image_path
        # 统一将 /uploads/... 变为绝对路径 /home/TeachMasterAppV2/backend/uploads/...
        if background_image_path.startswith("/uploads"):
            head_bg_path = os.path.join(
                "/home/TeachMasterAppV2/backend",
                background_image_path.lstrip("/")
            )
        else:
            head_bg_path = background_image_path

        background_image_lit = repr(head_bg_path)
        school_lit = request.school or ""
        university_lit = request.college or ""
        background_image_clean = background_image_lit.strip("'")  # 'SAI.png' → SAI.png
        background_image_final = f"{background_image_clean}"
        background_image_final_lit = repr(background_image_final)
        avatar_image_clean = avatar_image_lit.strip("'")
        avatar_image_final = f"{avatar_image_clean}"
        avatar_image_lit = repr(avatar_image_final)
        '''
        BASE_DIR = "/home/TeachMasterAppV2/backend"

        def normalize_path(path: str) -> str:
            """
            如果 path 是绝对路径（/home 开头），直接返回；
            否则认为是相对路径，拼成 BASE_DIR/path。
            """
            if not path:
                return path
            
            # 只要是绝对路径（你们项目全部绝对路径都在 /home 下）
            if path.startswith("/home"):
                return path
            
            # 统一去掉开头的 /，避免 //uploads 这种情况
            path_clean = path.lstrip("/")
            
            # 拼成绝对路径
            return BASE_DIR.rstrip("/") + "/" + path_clean.lstrip("/")
        logo_image_resolved = normalize_path(logo_image)
        avatar_image_resolved = normalize_path(avatar_image)
        background_image_resolved = normalize_path(background_image_path)

        logo_image_lit = repr(logo_image_resolved)
        avatar_image_lit = repr(avatar_image_resolved)
        background_image_lit = repr(background_image_resolved)

        school_lit = repr(request.school or "")
        university_lit = repr(request.college or "")


        course_title_lit = repr(course_title)
        professor_name_lit = repr(professor_name)


        if language_now == "zh":
            # 中文：封面用 Demo_cn.MergedLayoutScene2_cn，尾页用 EndingDemo_cn.EndingScene_cn
            cover_code = f'''# 自动生成的封面代码（中文）
import sys

# 确保可以找到 Demo_cn.py
backend_root = "/home/TeachMasterAppV2/backend"
if backend_root not in sys.path:
    sys.path.append(backend_root)

from Demo_cn import MergedLayoutScene2_cn


class Scene0_1(MergedLayoutScene2_cn):
    def __init__(self, **kwargs):
        super().__init__(
            class_title_text={course_title_lit},
            avatar_image={avatar_image_lit},
            professor_name={professor_name_lit},
            background_image={background_image_lit},
            school={school_lit},
            university={university_lit},
            left_logo={logo_image_lit},
            **kwargs
        )
'''

            ending_code = f'''# 自动生成的尾页代码（中文）
import sys

# 确保可以找到 EndingDemo_cn.py
backend_root = "/home/TeachMasterAppV2/backend"
if backend_root not in sys.path:
    sys.path.append(backend_root)

from EndingDemo_cn import EndingScene_cn


class Scene999_1(EndingScene_cn):
    def __init__(self, **kwargs):
        super().__init__(
            class_title_text={course_title_lit},
            avatar_image={avatar_image_lit},
            professor_name={professor_name_lit},
            background_image={background_image_lit},
            school={school_lit},
            university={university_lit},
            left_logo={logo_image_lit},
            **kwargs
        )
'''
        else:
            # 英文：封面用 Demo.py 里的类（你现在文件里类名也是 MergedLayoutScene2_cn，我就按你现有的来）
            cover_code = f'''# 自动生成的封面代码（英文）
import sys

# 确保可以找到 Demo.py
backend_root = "/home/TeachMasterAppV2/backend"
if backend_root not in sys.path:
    sys.path.append(backend_root)

from Demo import MergedLayoutScene2


class Scene0_1(MergedLayoutScene2):
    def __init__(self, **kwargs):
        super().__init__(
            class_title_text={course_title_lit},
            avatar_image={avatar_image_lit},
            professor_name={professor_name_lit},
            background_image={background_image_lit},
            school={school_lit},
            university={university_lit},
            left_logo={logo_image_lit},
            **kwargs
        )
'''

            # 英文尾页用 EndingDemo.EndingScene（它有 course_title 这个参数）
            ending_code = f'''# 自动生成的尾页代码（英文）
import sys

# 确保可以找到 EndingDemo.py
backend_root = "/home/TeachMasterAppV2/backend"
if backend_root not in sys.path:
    sys.path.append(backend_root)

from EndingDemo import EndingScene


class Scene999_1(EndingScene):
    def __init__(self, **kwargs):
        super().__init__(
            class_title_text={course_title_lit},
            avatar_image={avatar_image_lit},
            professor_name={professor_name_lit},
            background_image={background_image_lit},
            school={school_lit},
            university={university_lit},
            left_logo={logo_image_lit},
            **kwargs
        )
'''

        # 覆盖写入 0_1.py / 999_1.py
        with open(cover_code_path, "w", encoding="utf-8") as f:
            f.write(cover_code)
        with open(ending_code_path, "w", encoding="utf-8") as f:
            f.write(ending_code)
        print(f"✅ 首尾页代码已写入: {cover_code_path}, {ending_code_path}")
        num_files = len(os.listdir(script_paginated_output_folder))
        estimated_time = BASE_OVERHEAD_TIME + num_files * TIME_PER_FILE_MANIM_CODE
        update_status_sync(job_id, "manim_code_generation", 40, "生成Manim代码...", current_step_estimated_time=estimated_time)
        try:
            manim_code_output_path = os.path.join(request_output_dir, "manim_codes")
            ensure_directory_exists(manim_code_output_path)
             # 日志
            manimcode_generator.pipeline(script_paginated_output_folder, output_dir=manim_code_output_path)


                    # 使用batch_debug.py开始对生成的manim代码进行AI-debug
            print("-------------------------------------------开始debug-----------------------------")
            if language_now == 'en':
                debug_command = [
                    "python",
                    str("batch_debug.py"),
                    "--folder", manim_code_output_path
                ]
            else:
                debug_command = [
                    "python",
                    str("batch_debug_for_effi_test_cn.py"),
                    "--folder", manim_code_output_path
                ]
            success = run_subprocess_command(debug_command, logger=logger, description="AI-Debug Manim 代码", verbose=verbose)
            if not success:
                raise RuntimeError("AI-Debug Manim 代码失败")
        except Exception as e:
            raise e
        time_dict["manim_code_time"] = time.time() - start_time - sum(time_dict.values())

        # --- 步骤 6: 生成语音脚本 ---
        if language_now == 'en':
             speechScriptGenerator = SpeechScriptGenerator_en(config_path=CONFIG_PATH)
        else:
            speechScriptGenerator = SpeechScriptGenerator(config_path=CONFIG_PATH)
        num_files = len(os.listdir(script_paginated_output_folder))
        estimated_time = BASE_OVERHEAD_TIME + num_files * TIME_PER_FILE_SPEECH_SCRIPT
        update_status_sync(job_id, "speech_script_generation", 48, "生成语音脚本...", current_step_estimated_time=estimated_time)
        try:
            speech_output_path = os.path.join(request_output_dir, "speech")
            ensure_directory_exists(speech_output_path)
             # 日志
            speechScriptGenerator.pipeline(script_paginated_output_folder, manim_code_output_path, output_dir=speech_output_path)
        except Exception as e:
             # 日志
            raise e
        time_dict["speech_time"] = time.time() - start_time - sum(time_dict.values())
        
        # --- 步骤 7: 生成语音音频 ---

        # 先为首尾页写入讲稿到 speech 目录
        cover_script_path = os.path.join(speech_output_path, "0_1.txt")
        ending_script_path = os.path.join(speech_output_path, "999_1.txt")

        if language_now == "zh":
            cover_txt = f"大家好！欢迎大家聆听本次课程，我是授课老师{professor_name}，今天让我们一起走进{course_title}吧。"
            ending_txt = f"感谢大家聆听本次{course_title}课程，希望大家都有所收获！我是授课老师{professor_name}，期待与大家下次课程再见。"
        else:
            cover_txt = f"Hello everyone! Welcome to this course on {course_title}. I am your instructor, {professor_name}, and today let's dive into the topic together."
            ending_txt = f"Thank you for attending the {course_title} course. I hope you found it informative! I am {professor_name}, and I look forward to seeing you in the next class."

        # 覆盖写入首尾页讲稿
        with open(cover_script_path, "w", encoding="utf-8") as f:
            f.write(cover_txt)
        with open(ending_script_path, "w", encoding="utf-8") as f:
            f.write(ending_txt)
        print(f"✅ 首尾页讲稿已写入: {cover_script_path}, {ending_script_path}")

        total_chars = 0
        for filename in os.listdir(speech_output_path):
            if filename.endswith(".txt"):
                with open(os.path.join(speech_output_path, filename), 'r', encoding='utf-8') as f:
                    total_chars += len(f.read())
        estimated_time = BASE_OVERHEAD_TIME + int(total_chars * TIME_PER_CHAR_AUDIO)
        update_status_sync(job_id, "speech_audio_generation", 56, "生成语音音频...", current_step_estimated_time=estimated_time)
        speech_audio_output_path = os.path.join(request_output_dir, "speech_audio")
        ensure_directory_exists(speech_audio_output_path)
         # 日志
        # 判断当前是否在使用默认音频（即老师没有上传自己的音频）
        is_default_audio = (
            os.path.abspath(wav_path)
            == os.path.abspath(str(settings.DEFAULT_WAV_PATH))
        )

        # 从 JSON 里获取或创建 voice_id
        user_voice_id, existed, voice_key = get_or_create_voice_id_for_teacher(
            user_id=user_id,
            professor_name=professor_name,
            is_default_audio=is_default_audio,
        )

        # existed = True → 不需要 clone
        # existed = False → 第一次遇到此声线，需要 clone
        if is_default_audio and existed:
            # 默认音频且声线已存在 → 完全跳过 clone
            clone_audio_arg = ""
        else:
            # 第一次遇到（无论是不是默认音频）都要 clone 一次
            clone_audio_arg = "" if existed else f"--clone_audio {wav_path} "

        use_existing_flag = "--use_existing_voice" if existed else ""

        minimax_cmd = (
            f"source /home/EduAgent/miniconda3/etc/profile.d/conda.sh && "
            f"conda activate minimax_env && "
            f"python /home/TeachMasterAppV2/backend/batch_minimax_tts.py "
            f"--input_dir {speech_output_path} "
            f"--output_dir {speech_audio_output_path} "
            f"{clone_audio_arg}"
            f"--voice_id {user_voice_id} "
            f"--model speech-02-hd "
            f"--prompt_text '{prompt_txt}' "
            f"{use_existing_flag}"
        )
        minimax_command = [
            "/bin/bash",
            "-c",
            minimax_cmd
        ]
        success = run_subprocess_command(command=minimax_command, description="生成语音音频", verbose=verbose, logger=logger)
        '''
        cosyvoice_command = [
            str(settings.PYTHON_PATH),
            str(settings.COSYVOICE_SCRIPT_PATH).replace("dynamic", "par"), # 使用并行版本
            speech_output_path,
            speech_audio_output_path,
            "--prompt_wav", wav_path,
            "--prompt_text", prompt_txt,
        ]
        
        success = run_subprocess_command(command=cosyvoice_command, description="生成语音音频", verbose=verbose, logger=logger)
        '''
        if not success:
            raise RuntimeError("语音音频生成失败")
        if not existed:
           persist_voice_id_for_teacher(voice_key, user_voice_id)
        '''
        if not success:
            # 教师声线生成失败，降级为默认声线再试一次
            logger.warning(
                json.dumps(
                    {
                        "event": "speech_generation_fallback",
                        "message": "首次使用教师声线生成语音失败，降级为默认声线重试一次",
                        "user_id": user_id,
                        "professor_name": professor_name,
                        "voice_id": user_voice_id,
                    }
                )
            )
            # is_default_audio=True → 走全局默认声线
            fallback_voice_id, fallback_existed, fallback_key = get_or_create_voice_id_for_teacher(
                user_id=user_id,
                professor_name=professor_name,
                is_default_audio=True,
            )
            fallback_clone_arg = "" if fallback_existed else f"--clone_audio {settings.DEFAULT_WAV_PATH} "
            fallback_use_flag = "--use_existing_voice" if fallback_existed else ""

            fallback_cmd = (
                f"source /home/EduAgent/miniconda3/etc/profile.d/conda.sh && "
                f"conda activate minimax_env && "
                f"python /home/TeachMasterAppV2/backend/batch_minimax_tts.py "
                f"--input_dir {speech_output_path} "
                f"--output_dir {speech_audio_output_path} "
                f"{fallback_clone_arg}"
                f"--voice_id {fallback_voice_id} "
                f"--model speech-02-hd "
                f"--prompt_text '{prompt_txt}' "
                f"{fallback_use_flag}"
            )
            fallback_command = [
                "/bin/bash",
                "-c",
                fallback_cmd,
            ]
            success = run_subprocess_command(
                command=fallback_command,
                description="生成语音音频（默认声线降级）",
                verbose=verbose,
                logger=logger,
            )

            if not success:
                # 默认声线也失败，彻底报错
                raise RuntimeError("语音音频生成失败（默认声线降级也失败）")

            # 默认声线第一次克隆成功时，写入 JSON 映射
            if not fallback_existed:
                persist_voice_id_for_teacher(fallback_key, fallback_voice_id)

        else:
            # 教师声线分支成功时，如果是第一次，也写入 JSON 映射
            if not existed:
                persist_voice_id_for_teacher(voice_key, user_voice_id)
        '''
               
        time_dict["speech_audio_time"] = time.time() - start_time - sum(time_dict.values())

        # --- 步骤 8: 插入断点 ---
        num_files = len(os.listdir(manim_code_output_path))
        estimated_time = BASE_OVERHEAD_TIME + num_files * TIME_PER_FILE_BREAKPOINT
        update_status_sync(job_id, "breakpoint_insertion", 64, "插入断点...", current_step_estimated_time=estimated_time)
        speech_time_file_path = os.path.join(speech_audio_output_path, "speech.txt")
        refined_output_path = os.path.join(request_output_dir, "manim_codes_refined")
        ensure_directory_exists(refined_output_path)
        try:
             # 日志
            manimBreakpointInserter.pipeline(manim_code_output_path, speech_output_path, refined_output_path)
            if os.path.exists(refined_output_path):
                response_file_path = os.path.join(refined_output_path, "response.txt")
                with open(response_file_path, "w") as file:
                    file.write("Response file created successfully.\n")  
                    if hasattr(manimBreakpointInserter, "llm_records"):
                        for rec in manimBreakpointInserter.llm_records:
                            file.write(f"{rec}\n")
            manim_code_refined_output_path = os.path.join(refined_output_path, "Code")
            speech_refined_output_path = os.path.join(refined_output_path, "Speech")
             # 日志
        except Exception as e:
            # 先把错误写进 logger，方便后面查
            logger.error(json.dumps({
                "event": "step_error",
                "step": "breakpoint_insertion",
                "error": str(e),
            }, ensure_ascii=False))

            raise e

        time_dict["breakpoint_time"] = time.time() - start_time - sum(time_dict.values())

        # --- 步骤 9: 自动等待时间生成 ---
        num_files = len(os.listdir(manim_code_refined_output_path))
        estimated_time = BASE_OVERHEAD_TIME + num_files * TIME_PER_FILE_AUTOWAIT
        update_status_sync(job_id, "auto_wait_time_generation", 72, "自动等待时间生成...", current_step_estimated_time=estimated_time)
        try:
            manim_code_final_output_path = os.path.join(request_output_dir, "manim_codes_final")
             # 日志
            manimAutoWaitGenerator.pipeline(speech_time_file_path, speech_refined_output_path, 
                                            manim_code_refined_output_path, manim_code_final_output_path)
             # 日志
        except Exception as e:
             # 日志
            raise e
        time_dict["auto_wait_time"] = time.time() - start_time - sum(time_dict.values())

        # --- 在步骤 10、11 之前：临时移走首尾页代码 0_1.py / 999_1.py ---
        manim_final_dir = Path(manim_code_final_output_path)
        temp_cover_ending_dir = manim_final_dir / "_cover_ending_tmp"
        temp_cover_ending_dir.mkdir(exist_ok=True)

        moved_cover_ending_files: list[tuple[Path, Path]] = []
        for fname in ("0_1.py", "999_1.py"):
            src = manim_final_dir / fname
            if src.exists():
                dst = temp_cover_ending_dir / fname
                shutil.move(str(src), str(dst))
                moved_cover_ending_files.append((src, dst))
                if logger:
                    logger.info(f"临时移走首尾页代码: {src} -> {dst}")

        # --- 步骤 10: 音视频对齐处理 ---
        num_files = len(os.listdir(manim_code_final_output_path))
        estimated_time = BASE_OVERHEAD_TIME + num_files * TIME_PER_FILE_ALIGN
        update_status_sync(job_id, "video_audio_align", 80, "音视频对齐处理...", current_step_estimated_time=estimated_time)
         # 日志

        align_command = [
            str(settings.PYTHON_PATH), # 假设 .env 中有 MANIM_PYTHON_PATH
            str("video_audio_align.py"),
            speech_time_file_path,
            manim_code_final_output_path
        ]
        
        success = run_subprocess_command(command=align_command, description="音视频对齐处理", verbose=verbose, logger=logger)
        if not success:
            print("警告: 音视频对齐处理失败，继续后续流程")
             # 日志
        
        time_dict["align_time"] = time.time() - start_time - sum(time_dict.values())
        
        # --- 步骤 11: 添加背景 ---
        num_files = len(os.listdir(manim_code_final_output_path))
        estimated_time = BASE_OVERHEAD_TIME + num_files * TIME_PER_FILE_ADD_BG
        update_status_sync(job_id, "background_addition", 88, "添加背景...", current_step_estimated_time=estimated_time)
         # 日志
        
        add_background(manim_code_final_output_path, background_image_path, logger=logger)
        
        # 添加页码
        page_num_command = [
            str(settings.PYTHON_PATH),
            str("add_pagenum.py"),
            manim_code_final_output_path
        ]
        run_subprocess_command(command=page_num_command, description="添加页码", verbose=verbose, logger=logger)
        time_dict["add_background_time"] = time.time() - start_time - sum(time_dict.values())
        
        # --- 步骤 11 之后：恢复首尾页代码回 manim_codes_final ---
        for orig_path, temp_path in moved_cover_ending_files:
            if temp_path.exists():
                shutil.move(str(temp_path), str(orig_path))
                if logger:
                    logger.info(f"恢复首尾页代码: {temp_path} -> {orig_path}")

        # --- 步骤 12: 渲染视频 ---
        num_files = len(os.listdir(manim_code_final_output_path))
        estimated_time = BASE_OVERHEAD_TIME + num_files * TIME_PER_VIDEO_RENDER
        update_status_sync(job_id, "video_rendering", 92, "渲染视频...", current_step_estimated_time=estimated_time) # 调整进度

        # 复制占位图
        placeholder_src = Path(settings.UPLOADS_DIR) / "placeholder.png"
        if placeholder_src.exists():
            shutil.copyfile(placeholder_src, os.path.join(manim_code_final_output_path, "placeholder.png"))
        
        # 优化layout
        #layout_command = [
        #    str(settings.PYTHON_PATH),
        #    str("/home/TeachMaster/ML/batch_auto_fix_layout.py"),
        #    manim_code_final_output_path
        #]
        #run_subprocess_command(command=layout_command, logger=logger)
        
        video_wo_audio_output_path = os.path.join(request_output_dir, "video_wo_audio")
        quality = "h"
        ensure_directory_exists(video_wo_audio_output_path)
         # 日志
        
        render_command = [
            "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
            "batch_render_manim_for_effi_test.py",
            "--input_dir", manim_code_final_output_path,
            "--output_dir", video_wo_audio_output_path,
            "--quality", quality
        ]
        
        success = run_subprocess_command(command=render_command, description="渲染Manim视频", verbose=verbose, logger=logger)
        if not success:
            print("存在视频渲染失败")
             # 日志

        video_w_audio_output_path = os.path.join(request_output_dir, "video_w_audio")
        
        merge_individual_command = [
                str(settings.PYTHON_PATH),
                "video_audio_merge_individual.py",
                speech_audio_output_path,
                video_wo_audio_output_path,
                video_w_audio_output_path
            ]
            
        success = run_subprocess_command(command=merge_individual_command, description="合并音频与视频片段", verbose=True, logger=logger)
        if not success:
            raise RuntimeError("音频与视频片段合并失败")
        
        enable_subtitles = job.request_payload.get("enable_subtitles", True)
        video_w_audio_subtitle_output_path = video_w_audio_output_path
        if enable_subtitles == True:
                print("🎬 Generating subtitles...")
                video_dir = video_w_audio_output_path  # Path to the video with audio
                text_dir =  speech_output_path # Assuming text data is stored in a "text" folder
                # output_dir = video_w_audio_output_path  # Path to save the generated subtitles
                video_w_audio_subtitle_output_path =  Path(settings.GENERATED_CONTENT_DIR) / str(job.user_id) / str(job.id) / "video_w_audio_subtitle"
                output_dir = video_w_audio_subtitle_output_path

                # Ensure output directory exists
                ensure_directory_exists(output_dir)
                if language_now == 'zh':
                    subtitle_script = "/home/TeachMaster/ML/subtitle_generator_cn_effi.py"
                else:
                    subtitle_script = "/home/TeachMaster/ML/subtitle_generator_effi.py"  # 英文 fallback

                # Command for generating subtitles
                subtitle_command = [
                    "/home/EduAgent/miniconda3/envs/aeneas_env/bin/python", 
                    subtitle_script, 
                    video_dir, text_dir, output_dir
                ]

                # Run the subtitle generation process
                subtitle_generation_success = run_subprocess_command(command=subtitle_command, description="Generating subtitles", logger=logger)
                if not subtitle_generation_success:
                    raise RuntimeError("Failed to generate subtitles.")
                
                video_w_audio_output_path = video_w_audio_subtitle_output_path

        # --- 步骤 13: 暂停，等待预览 ---
        preview_data_payload = {
            "video_wo_audio_path": str(video_wo_audio_output_path),
            "video_w_audio_path": str(video_w_audio_output_path),
            "manim_code_path": str(manim_code_final_output_path),
            "speech_script_path": str(speech_refined_output_path),
            "speech_script_original_path": str(speech_output_path),
            "speech_audio_path": str(speech_audio_output_path),
            "manim_code_original_path": str(manim_code_output_path),
            "manim_code_refined_path": str(manim_code_refined_output_path)
        }
        
        update_status_sync(
            job_id,
            status="awaiting_preview_decision", 
            progress=95, 
            message="视频渲染完成，等待预览选择...",
            preview_data=preview_data_payload
        )
        
        logger.info(json.dumps({
            "event": "process_pause",
            "status": "awaiting_preview_decision",
            "preview_data_paths": preview_data_payload
        }))
        
        print("🔍 渲染完成，等待用户预览选择...")
        return # 任务的第一部分在此正常结束

    except KeyboardInterrupt:
        sys.exit(1) # 允许 Ctrl+C 终止
    except Exception as e:
        # 记录失败
        print(f"Content generation failed for job {job_id}: {e}")
        import traceback
        traceback.print_exc()
        logger.exception(json.dumps({
            "event": "job_failed",
            "job_id": job_id,
            "error": f"Content generation failed: {str(e)}"
        }))
        update_status_sync(job_id, status="failed", progress=0, message=f"生成失败: {str(e)}", error=str(e))
        # 让异常抛出，ARQ worker 会捕获它
        raise

# ---------------------------------
# 主要任务函数 2: 预览后继续
# ---------------------------------


def continue_generation_task_entry(job: GenerationJob):
    """
    同步执行的内容生成任务 (第 2 部分)。
    在用户预览并确认后，由 ARQ worker 在一个单独的线程中调用。
    """
    job_id = job.id
    print(f"🔄 用户选择继续，恢复生成流程... Job: {job_id}")
    
    if not job:
        print(f"❌ 无法继续：在数据库中找不到 Job {job_id}。")
        return
        
    if job.status not in ("awaiting_preview_decision", "continuation_queued"):
        print(f"❌ 无法继续：Job {job_id} 状态不正确 (当前: {job.status})。")
        # 可能任务已经被重新触发了，静默退出
        return
        
    # 从 job 数据中恢复路径
    try:
        preview_data = job.preview_data
        settings_data = job.settings
        enable_subtitles = job.request_payload.get("enable_subtitles", True)
        
        # video_wo_audio_output_path = preview_data["video_wo_audio_path"]
        video_w_audio_output_path = preview_data["video_w_audio_path"]
        speech_audio_output_path = preview_data["speech_audio_path"]
        speech_output_path = preview_data["speech_script_original_path"]
        
        request_output_dir = str(Path(settings.GENERATED_CONTENT_DIR) / str(job.user_id))
        keywords = settings_data.get("keyword", "unknown")
        _course_title = settings_data.get("course_title", "unknown")
        _professor_name = settings_data.get("professor_name", "unknown")

        logger = _setup_job_logger(job_id, os.path.join(request_output_dir, str(job_id)))
        logger.info(json.dumps({
            "event": "job_continue",
            "job_id": job_id,
            "message": "Resuming generation process after user preview."
        }))
        ensure_directory_exists(video_w_audio_output_path)
        
        # --- 步骤 13: 拼接最终完整视频 ---
        update_status_sync(job_id, "video_concatenation_internal", 96, "拼接完整视频...")
        final_video_path = ""
        videos_to_concat = []
        '''
        # 1. 封面
        if mode == 'outline':
            cover_output_dir = os.path.join(request_output_dir, str(job_id), "cover_ending")
            cover_file = os.path.join(cover_output_dir, "cover-padded.mp4")
            if os.path.exists(cover_file):
                videos_to_concat.append(cover_file)
                print(f"添加封面视频: {cover_file}")
        '''
        # 2. 教学内容 (按预览顺序)
        if "segment_order" in preview_data and preview_data["segment_order"]:
            print(f"使用自定义片段顺序: {preview_data['segment_order']}")
            for segment_id in preview_data["segment_order"]:
                segment_video_path = os.path.join(video_w_audio_output_path, f"{segment_id}.mp4")
                if os.path.exists(segment_video_path):
                    videos_to_concat.append(segment_video_path)
                else:
                    print(f"⚠️ 警告: 找不到片段视频: {segment_video_path}")
        else:
            # 按自然顺序回退
            print("未找到自定义顺序，按自然顺序合并。")
            all_padded_videos = sorted(
                glob.glob(os.path.join(video_w_audio_output_path, "*.mp4")),
                key=lambda f: [int(c) for c in re.findall(r'\d+', os.path.basename(f))]
            )
            videos_to_concat.extend(all_padded_videos)
        '''
        # 3. 尾页
        if mode == 'outline':
            ending_file = os.path.join(cover_output_dir, "ending-padded.mp4")
            if os.path.exists(ending_file):
                videos_to_concat.append(ending_file)
                print(f"添加尾页视频: {ending_file}")
        '''
        # --- 执行拼接 ---
        if not videos_to_concat:
            raise RuntimeError("没有找到可拼接的视频文件。")
        
        final_video_dir = os.path.join(request_output_dir, str(job_id), "final_video")
        ensure_directory_exists(final_video_dir)
        final_video_path = os.path.join(final_video_dir, f"完整课程-{_course_title}.mp4")

        if len(videos_to_concat) == 1:
            shutil.copy2(videos_to_concat[0], final_video_path)
            print(f"只有一个视频文件，直接复制: {final_video_path}")
        else:
            update_status_sync(job_id, "video_concatenation", 99, "拼接完整视频...")
            print("🎬 Step 15: 拼接完整视频...")
            logger.info(json.dumps({
                "event": "step_start",
                "step": "15_video_concatenation_final",
                "message": "Merging video segments for final concatenation...",
                "input_video_w_audio_dir": str(video_w_audio_output_path),
                "output_video_w_audio_path": str(os.path.join(video_w_audio_output_path, "Full.mp4"))
            }))
            
            concatenated_path = concatenate_videos(video_files=videos_to_concat, output_path=final_video_path, logger=logger)
            if not concatenated_path:
                raise RuntimeError("最终视频拼接失败")
                
        # --- 步骤 14: 合并讲稿 ---
        update_status_sync(job_id, "video_concatenation", 99, "合并讲稿...")
        readtxtPath = os.path.join(request_output_dir, str(job_id), "speech")
        readtxt_script_path = str("readtxt.py")
        if not os.path.exists(readtxt_script_path):
            readtxt_script_path = "readtxt.py" # fallback

        readtxt_command = [
            str(settings.PYTHON_PATH), 
            readtxt_script_path,
            readtxtPath,
            "--out",
            os.path.join(readtxtPath, "讲稿文件")
        ]
        run_subprocess_command(command=readtxt_command, description="合并讲稿", verbose=False, logger=logger)

        # --- 步骤 15: 完成 ---
        final_video_size = os.path.getsize(final_video_path) if os.path.exists(final_video_path) else 0
        txt_path = os.path.join(readtxtPath, "讲稿文件.txt")

        if (job.request_payload.get("isLongVideo", True)):
            md_path = os.path.join(os.path.join(request_output_dir, str(job_id), "scripts", "full"), "script_full.md")
        else:
            md_path = os.path.join(os.path.join(request_output_dir, str(job_id), "scripts", "short"), "script_short.md")
            
        txt_size = os.path.getsize(txt_path) if os.path.exists(txt_path) else 0
        md_size = os.path.getsize(md_path) if os.path.exists(md_path) else 0

        result_files = [
            {"name": f"完整课程视频-{_course_title}-{_professor_name}.mp4", "path": final_video_path, "size": final_video_size, "type": "video"},
            {"name": f"完整课程讲义文件-{_course_title}-{_professor_name}.md", "path": md_path, "size": md_size, "type": "markdown"},
            {"name": f"完整课程讲稿文件-{_course_title}-{_professor_name}.txt", "path": txt_path, "size": txt_size, "type": "txt"}
        ]
        
        # 检查并添加 PPT (如果存在)
        ppt_path = os.path.join(request_output_dir, str(job_id), "PPT", "final.pptx")
        if os.path.exists(ppt_path):
            ppt_size = os.path.getsize(ppt_path)
            result_files.append(
                {"name": f"课程PPT-{_course_title}-{_professor_name}.pptx", "path": ppt_path, "size": ppt_size, "type": "ppt"}
            )
        
        update_status_sync(
            job_id,
            status="completed", 
            progress=100, 
            message="内容生成完成！",
            result_files=result_files
        )
        
        logger.info(json.dumps({
            "event": "job_completed",
            "job_id": job_id
        }, ensure_ascii=False))

        token_service.use_token(job.access_token, job.id, str(job.user_id))
        
        print("✅ 生成流程完成！")

    except Exception as e:
        # 记录失败
        print(f"Continue generation failed for job {job_id}: {e}")
        import traceback
        traceback.print_exc()
        logger.exception(json.dumps({
            "event": "job_failed",
            "stage": "continuation",
            "job_id": job_id,
            "error": f"Continue generation failed: {str(e)}"
        }))
        update_status_sync(job_id, status="failed", progress=95, message=f"合并失败: {str(e)}", error=str(e))
        # 让异常抛出，ARQ worker 会捕获它
        raise

# ---------------------------------
# 预览期间的辅助函数 (从 MLFullContentService 移植)
# ---------------------------------
# (这些函数是同步的，由 API 路由直接调用，但它们很轻量)

def backup_video_files_for_rollback(job: GenerationJob, segment_id: str) -> bool:
    """
    备份 video_wo_audio 和 video_w_audio 目录下的视频文件，用于回退。
    备份文件名格式：{segment_id}.mp4.backup
    如果已存在备份则覆盖。
    
    Args:
        job: GenerationJob 对象
        segment_id: 片段ID
    
    Returns:
        bool: 是否成功（即使部分失败也返回 True，只记录警告）
    """
    if not job or job.status != "awaiting_preview_decision":
        return False
    
    try:
        preview_data = job.preview_data
        video_wo_audio_path = preview_data.get("video_wo_audio_path")
        video_w_audio_path = preview_data.get("video_w_audio_path")
        
        success = True
        
        # 备份 video_wo_audio 目录下的视频
        if video_wo_audio_path:
            source_video_wo = os.path.join(video_wo_audio_path, f"{segment_id}.mp4")
            backup_video_wo = os.path.join(video_wo_audio_path, f"{segment_id}.mp4.backup")
            
            if os.path.exists(source_video_wo):
                try:
                    shutil.copy2(source_video_wo, backup_video_wo)
                    print(f"📦 已备份 video_wo_audio: {backup_video_wo}")
                except Exception as e:
                    print(f"⚠️ 备份 video_wo_audio 失败: {e}")
                    success = False
            else:
                print(f"⚠️ video_wo_audio 文件不存在，跳过备份: {source_video_wo}")
        
        # 备份 video_w_audio 目录下的视频
        if video_w_audio_path:
            source_video_w = os.path.join(video_w_audio_path, f"{segment_id}.mp4")
            backup_video_w = os.path.join(video_w_audio_path, f"{segment_id}.mp4.backup")
            
            if os.path.exists(source_video_w):
                try:
                    shutil.copy2(source_video_w, backup_video_w)
                    print(f"📦 已备份 video_w_audio: {backup_video_w}")
                except Exception as e:
                    print(f"⚠️ 备份 video_w_audio 失败: {e}")
                    success = False
            else:
                print(f"⚠️ video_w_audio 文件不存在，跳过备份: {source_video_w}")
        
        return success
    except Exception as e:
        print(f"⚠️ 备份视频文件时发生错误: {e}")
        return False

def save_manim_code_entry(job: GenerationJob, segment_id: str, code_content: str) -> bool:
    """
    保存 Manim 代码，并在保存前备份 video_wo_audio 和 video_w_audio 目录下的视频。
    
    Args:
        job: GenerationJob 对象
        segment_id: 片段ID
        code_content: 要保存的代码内容
    
    Returns:
        bool: 是否成功
    """    
    if not job or job.status != "awaiting_preview_decision":
        return False
    try:
        # 在保存代码前，先备份 video_wo_audio 和 video_w_audio 目录下的视频
        # 这样在回退时可以使用这些备份
        backup_video_files_for_rollback(job, segment_id)
        
        preview_data = job.preview_data
        manim_code_path = preview_data["manim_code_path"]
        code_file_path = os.path.join(manim_code_path, f"{segment_id}.py")
        with open(code_file_path, 'w', encoding='utf-8') as f:
            f.write(code_content)
        print(f"✅ 代码保存成功: {code_file_path}")
        return True
    except Exception as e:
        print(f"❌ 保存代码失败: {e}")
        return False

def rollback_segment_entry(job: GenerationJob, segment_id: str, code_content: str, video_file_path: Optional[str] = None) -> bool:
    """
    回退片段到备份状态：替换代码文件和视频文件。
    
    回退策略：
    1. 前端传回的备份视频（video_file_path）覆写 video_w_audio_subtitle 目录下的视频
    2. 后端使用本地备份文件（.backup）覆写 video_wo_audio 和 video_w_audio 目录下的视频
    3. 删除本地备份文件
    
    Args:
        job: GenerationJob 对象
        segment_id: 片段ID
        code_content: 要回退的代码内容
        video_file_path: 前端传回的备份视频文件路径（临时文件路径，对应 video_w_audio_subtitle）
    
    Returns:
        bool: 是否成功
    """
    if not job or job.status != "awaiting_preview_decision":
        print(f"❌ 任务不存在或不在预览状态: {job.id}")
        return False
    
    try:
        preview_data = job.preview_data
        
        # 1. 回退代码文件
        manim_code_path = preview_data.get("manim_code_path")
        if not manim_code_path:
            print(f"❌ 缺少 manim_code_path")
            return False
        
        code_file_path = os.path.join(manim_code_path, f"{segment_id}.py")
        try:
            # 写入新的代码内容（不创建备份，因为前端已经有备份）
            with open(code_file_path, 'w', encoding='utf-8') as f:
                f.write(code_content)
            print(f"✅ 代码回退成功: {code_file_path}")
        except Exception as e:
            print(f"❌ 代码回退失败: {e}")
            return False
        
        # 2. 回退视频文件
        video_wo_audio_path = preview_data.get("video_wo_audio_path")
        video_w_audio_path = preview_data.get("video_w_audio_path")
        
        # 检查是否存在独立的 video_w_audio_subtitle 目录
        output_root_path = str(settings.GENERATED_CONTENT_DIR)
        request_output_dir = os.path.join(output_root_path, str(job.user_id), str(job.id))
        video_w_audio_subtitle_path = os.path.join(request_output_dir, "video_w_audio_subtitle")
        video_w_audio_subtitle_exists = os.path.exists(video_w_audio_subtitle_path)
        
        try:
            # 2.1 使用前端传回的备份视频覆写 video_w_audio_subtitle 目录下的视频
            if video_file_path and os.path.exists(video_file_path):
                if video_w_audio_subtitle_exists:
                    target_video_subtitle = os.path.join(video_w_audio_subtitle_path, f"{segment_id}.mp4")
                    shutil.copy2(video_file_path, target_video_subtitle)
                    print(f"✅ 视频回退成功（video_w_audio_subtitle）: {target_video_subtitle}")
                else:
                    print(f"⚠️ video_w_audio_subtitle 目录不存在，跳过覆写")
            elif video_file_path:
                print(f"⚠️ 前端传回的备份视频文件不存在: {video_file_path}")
            
            # 2.2 使用后端本地备份文件覆写 video_wo_audio 目录下的视频
            if video_wo_audio_path:
                backup_video_wo = os.path.join(video_wo_audio_path, f"{segment_id}.mp4.backup")
                target_video_wo = os.path.join(video_wo_audio_path, f"{segment_id}.mp4")
                
                if os.path.exists(backup_video_wo):
                    shutil.copy2(backup_video_wo, target_video_wo)
                    print(f"✅ 视频回退成功（video_wo_audio）: {target_video_wo}")
                    # 删除备份文件
                    try:
                        os.remove(backup_video_wo)
                        print(f"🗑️ 已删除备份文件: {backup_video_wo}")
                    except Exception as e:
                        print(f"⚠️ 删除备份文件失败: {backup_video_wo}, {e}")
                else:
                    print(f"⚠️ video_wo_audio 备份文件不存在，跳过回退: {backup_video_wo}")
            
            # 2.3 使用后端本地备份文件覆写 video_w_audio 目录下的视频
            if video_w_audio_path:
                backup_video_w = os.path.join(video_w_audio_path, f"{segment_id}.mp4.backup")
                target_video_w = os.path.join(video_w_audio_path, f"{segment_id}.mp4")
                
                if os.path.exists(backup_video_w):
                    shutil.copy2(backup_video_w, target_video_w)
                    print(f"✅ 视频回退成功（video_w_audio）: {target_video_w}")
                    # 删除备份文件
                    try:
                        os.remove(backup_video_w)
                        print(f"🗑️ 已删除备份文件: {backup_video_w}")
                    except Exception as e:
                        print(f"⚠️ 删除备份文件失败: {backup_video_w}, {e}")
                else:
                    print(f"⚠️ video_w_audio 备份文件不存在，跳过回退: {backup_video_w}")
        
        except Exception as e:
            print(f"❌ 视频回退失败: {e}")
            import traceback
            traceback.print_exc()
            # 视频回退失败不影响代码回退的成功
        
        return True
    except Exception as e:
        print(f"❌ 回退失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def save_original_script_content_entry(job: GenerationJob, segment_id: str, script_content: str) -> bool:

    if not job or job.status != "awaiting_preview_decision":
        return False
    try:
        preview_data = job.preview_data
        original_speech_script_path = preview_data.get("speech_script_original_path")
        if not original_speech_script_path:
            return False
        script_file_path = os.path.join(original_speech_script_path, f"{segment_id}.txt")
        with open(script_file_path, 'w', encoding='utf-8') as f:
            f.write(script_content)
        print(f"✅ 原始讲稿保存成功: {script_file_path}")
        return True
    except Exception as e:
        print(f"❌ 保存原始讲稿失败: {e}")
        return False

def save_script_content_entry(job: GenerationJob, segment_id: str, script_content: str) -> bool:

    if not job or job.status != "awaiting_preview_decision":
        return False
    try:
        preview_data = job.preview_data
        speech_script_path = preview_data["speech_script_path"]
        script_file_path = os.path.join(speech_script_path, f"{segment_id}.txt")
        with open(script_file_path, 'w', encoding='utf-8') as f:
            f.write(script_content)
        print(f"✅ 讲稿保存成功: {script_file_path}")
        return True
    except Exception as e:
        print(f"❌ 保存讲稿失败: {e}")
        return False

# 注意：下面的 regenerate 函数涉及 subprocess，非常耗时
# 它们 *不应该* 在 API 线程中运行
# 理想情况下，它们应该被重构为 *新的* ARQ 任务

def regenerate_audio_segment_entry(job: GenerationJob, segment_id: str) -> bool:
    job_id = job.id
    if not job or job.status != "awaiting_preview_decision":
        print(f"❌ 任务不存在或不在预览状态: {job_id}")
        return False
    
    output_root_path = str(settings.GENERATED_CONTENT_DIR)
    request_output_dir = os.path.join(output_root_path, str(job.user_id), str(job_id))
    logger = _setup_job_logger(job_id, request_output_dir)
    try:
        preview_data = job.preview_data
        speech_script_path = preview_data.get("speech_script_original_path")
        speech_audio_path = preview_data.get("speech_audio_path")
        video_wo_audio_path = preview_data.get("video_wo_audio_path")
        
        if not all([speech_script_path, speech_audio_path, video_wo_audio_path]):
            print(f"❌ 缺少必需的路径信息")
            return False
        
        print(f"🎵 开始重新生成音频片段: {segment_id}")
        script_file_path = os.path.join(speech_script_path, f"{segment_id}.txt")
        if not os.path.exists(script_file_path):
            print(f"❌ 讲稿文件不存在: {script_file_path}")
            return False
        # 为重生成语音补齐 user_id 信息，方便在 Helper 里复用声线映射
        settings_for_regen = dict(job.settings or {})
        settings_for_regen.setdefault("user_id", str(job.user_id))
        
        # 调用 _regenerate_single_speech (已移植的 helper)
        success = content_helper._regenerate_single_speech(
            segment_id,
            script_file_path,
            speech_audio_path,
            settings_for_regen,
            logger=logger,
        )

        if not success:
             print(f"❌ 音频生成失败")
             return False

        # 重新合并音频和视频
        print(f"🎬 开始重新合并音视频...")
        #success_merge = content_helper._merge_single_audio_video(segment_id, speech_audio_path, video_wo_audio_path, logger=logger)
        success_merge = content_helper._merge_single_audio_video_change(segment_id, speech_audio_path, video_wo_audio_path, logger=logger)
        if not success_merge:
            print(f"⚠️ 音视频合并失败")
            # 即使合并失败，音频也已生成，返回 True
        else:
            # 音频和无声视频合并成功后，按需更新字幕
            _regenerate_segment_subtitles(
                job=job,
                segment_id=segment_id,
                preview_data=preview_data,
                request_output_dir=request_output_dir,
                logger=logger,
                merge_success=success_merge,
            )       
         
        print(f"🎉 音频重新生成完成: {segment_id}")
        return True

    except Exception as e:
        print(f"❌ 重新生成音频失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def regenerate_video_segment_entry(job: GenerationJob, segment_id: str) -> bool:
    job_id = job.id
    if not job or job.status != "awaiting_preview_decision":
        print(f"❌ 任务不存在或不在预览状态: {job_id}")
        return False
        
    output_root_path = str(settings.GENERATED_CONTENT_DIR)
    request_output_dir = os.path.join(output_root_path, str(job.user_id), str(job_id))
    logger = _setup_job_logger(job_id, request_output_dir)
        
    try:
        preview_data = job.preview_data
        manim_code_path = preview_data.get("manim_code_path")
        video_wo_audio_path = preview_data.get("video_wo_audio_path")
        speech_audio_path = preview_data.get("speech_audio_path")
        
        if not all([manim_code_path, video_wo_audio_path, speech_audio_path]):
            print(f"❌ 缺少必需的路径信息")
            return False
        
        # 1. 重新渲染Manim视频（无音频）
        print(f"🎬 开始重新渲染视频片段: {segment_id}")
        code_file_path = os.path.join(manim_code_path, f"{segment_id}.py")
        if not os.path.exists(code_file_path):
            print(f"❌ 代码文件不存在: {code_file_path}")
            return False
            
        #success_render = content_helper.re_render_single_video(segment_id, code_file_path, video_wo_audio_path, logger)
        success_render = content_helper.re_render_single_video_change(segment_id, code_file_path, video_wo_audio_path, logger)
        
        if not success_render:
            print(f"❌ 视频渲染失败")
            return False
            
        # 2. 重新合并音频和新视频
        print(f"🎵 开始重新合并音频...")
        success_merge = content_helper._merge_single_audio_video(segment_id, speech_audio_path, video_wo_audio_path, logger)

        if not success_merge:
            print(f"⚠️ 音频合并失败，但视频已重新渲染")
            # 即使合并失败，视频也已生成，返回 True
        else:
            # 音频和无声视频合并成功后，按需更新字幕
            _regenerate_segment_subtitles(
                job=job,
                segment_id=segment_id,
                preview_data=preview_data,
                request_output_dir=request_output_dir,
                logger=logger,
                merge_success=success_merge,
            )   

        print(f"🎉 视频片段重新生成完成: {segment_id}")
        return True


    except Exception as e:
        print(f"❌ 重新生成视频片段失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def reprocess_segment_complete_entry(job: GenerationJob, segment_id: str) -> bool:
    job_id = job.id
    if not job or job.status != "awaiting_preview_decision":
        print(f"❌ 任务不存在或不在预览状态: {job_id}")
        return False
    
    output_root_path = str(settings.GENERATED_CONTENT_DIR)
    request_output_dir = os.path.join(output_root_path, str(job.user_id), str(job_id))
    logger = _setup_job_logger(job_id, request_output_dir)
            
    try:
        print(f"🔄 开始完整重新处理片段: {segment_id}")
        
        preview_data = job.preview_data
        original_speech_script_path = preview_data.get("speech_script_original_path")
        original_manim_code_path = preview_data.get("manim_code_original_path") # 使用新添加的key
        speech_audio_path = preview_data.get("speech_audio_path")
        video_wo_audio_path = preview_data.get("video_wo_audio_path")
        
        if not all([original_speech_script_path, original_manim_code_path, speech_audio_path, video_wo_audio_path]):
            print(f"❌ 缺少必需的路径信息 (可能 'manim_code_original_path' 未设置)")
            return False
        
        script_file_path = os.path.join(original_speech_script_path, f"{segment_id}.txt")
        original_code_file_path = os.path.join(original_manim_code_path, f"{segment_id}.py")
        
        if not os.path.exists(script_file_path):
            print(f"❌ 原始讲稿文件不存在: {script_file_path}")
            return False
            
        if not os.path.exists(original_code_file_path):
            print(f"❌ 原始代码文件不存在: {original_code_file_path}")
            return False
        
        # 第1步：为单个片段重新生成语音
        print(f"🎵 第1步: 重新生成语音...")
        success = content_helper._regenerate_single_speech(segment_id, script_file_path, speech_audio_path, job.settings, logger=logger)
        if not success:
            print(f"❌ 语音生成失败")
            return False
        
        # 第2步：重新插入断点
        print(f"🔧 第2步: 重新插入断点...")
        refined_output_path = os.path.join(request_output_dir, "manim_codes_refined")
        success = content_helper._reinsert_breakpoints_single(segment_id, original_code_file_path, script_file_path, refined_output_path, logger=logger)
        if not success:
            print(f"❌ 断点插入失败")
            return False
        
        # 第3步：重新生成等待时间
        print(f"⏱️ 第3步: 重新生成等待时间...")
        final_output_path = os.path.join(request_output_dir, "manim_codes_final")
        success = content_helper._regenerate_wait_time_single(segment_id, speech_audio_path, refined_output_path, final_output_path, logger=logger)
        if not success:
            print(f"❌ 等待时间生成失败")
            return False
        
        # 第4步：添加背景
        print(f"🖼️ 第4步: 重新添加背景...")
        final_code_file_path = os.path.join(final_output_path, f"{segment_id}.py")
        background_image = job.settings.get("background_image", str(settings.DEFAULT_BACKGROUND_IMAGE))
        content_helper._add_background_single(final_code_file_path, background_image, logger=logger)
        
        # 第5步：重新渲染视频
        print(f"🎬 第5步: 重新渲染视频...")
        success = content_helper.re_render_single_video(segment_id, final_code_file_path, video_wo_audio_path, logger)
        if not success:
            print(f"❌ 视频渲染失败")
            return False
        
        # 第6步：重新合并音视频
        print(f"🎞️ 第6步: 重新合并音视频...")
        success = content_helper._merge_single_audio_video(segment_id, speech_audio_path, video_wo_audio_path, logger=logger)
        if not success:
            print(f"⚠️ 音视频合并失败，但视频已重新渲染")
        
        print(f"✅ 片段完整重新处理完成: {segment_id}")
        return True
        
    except Exception as e:
        print(f"❌ 完整重新处理片段失败: {e}")
        import traceback
        traceback.print_exc()
        return False

# (注意: generate_ppt_entry, update_preview_segments_entry, upload_image_for_job_entry, change_video_speed_entry
#  也需要从 MLFullContentService 移植过来)
def update_preview_segments_entry(job: GenerationJob, new_segments: List[Dict[str, Any]]) -> bool:
    job_id = job.id
    if not job or job.status != "awaiting_preview_decision":
        print(f"❌ Job {job_id} not found or not in awaiting_preview_decision state.")
        return False
    
    print(f"🔄 Updating preview segments for job {job_id}...")
    preview_data_paths = job.preview_data
    enable_subtitles = job.request_payload.get("enable_subtitles", False)
    
    paths_to_manage = {
        'video': preview_data_paths.get("video_w_audio_path"),
        'code_final': preview_data_paths.get("manim_code_path"),
        'script_refined': preview_data_paths.get("speech_script_path"),
        'script_original': preview_data_paths.get("speech_script_original_path"),
        'audio': preview_data_paths.get("speech_audio_path"),
        'code_original': preview_data_paths.get("manim_code_original_path"),
        'code_refined': preview_data_paths.get("manim_code_refined_path")
    }
    
    def get_current_segment_ids(directory: str) -> set:
        if not directory or not os.path.exists(directory):
            return set()
        return {os.path.splitext(f)[0] for f in os.listdir(directory) if not f.startswith('.')}

    video_dir = paths_to_manage['video']
    if not video_dir:
        print("❌ Video directory path is missing.")
        return False

    current_ids = get_current_segment_ids(video_dir)
    new_ids = {seg.id for seg in new_segments}

    # --- 1. Handle Deletions ---
    deleted_ids = current_ids - new_ids
    if deleted_ids:
        print(f"🔥 Deleting segments: {deleted_ids}")
        for segment_id in deleted_ids:
            for key, dir_path in paths_to_manage.items():
                if not dir_path or not os.path.exists(dir_path):
                    continue
                
                for file_to_delete in glob.glob(os.path.join(dir_path, f"{segment_id}.*")):
                    try:
                        os.remove(file_to_delete)
                        print(f"  🗑️ Deleted {file_to_delete}")
                    except OSError as e:
                        print(f"  ⚠️ Error deleting {file_to_delete}: {e}")

    # --- 2. Handle Copies ---
    added_ids = new_ids - current_ids
    if added_ids:
        print(f"✨ Copying segments for new IDs: {added_ids}")
        copy_map = {seg.id: seg.source_id for seg in new_segments if seg.id in added_ids and seg.source_id}

        for new_id, source_id in copy_map.items():
            if not source_id:
                print(f"  ⚠️ New segment {new_id} is missing 'source_id'. Cannot copy.")
                continue

            print(f"  📋 Copying from {source_id} to {new_id}")
            for key, dir_path in paths_to_manage.items():
                if not dir_path or not os.path.exists(dir_path):
                    continue

                source_files = glob.glob(os.path.join(dir_path, f"{source_id}.*"))
                if not source_files:
                    print(f"    - No source file found for {key} in {dir_path}")
                    continue
                for source_file in source_files:
                    # source_file = source_files[0]
                    ext = os.path.splitext(source_file)[1]
                    dest_file = os.path.join(dir_path, f"{new_id}{ext}")
                    try:
                        shutil.copy2(source_file, dest_file)
                        print(f"    - Copied {source_file} to {dest_file}")
                    except IOError as e:
                        print(f"    - ⚠️ Error copying file for {new_id}: {e}")

    # --- 3. Handle Reordering (Save to DB) ---
    new_segment_order = [seg.id for seg in new_segments]
    print(f"📊 Saving new segment order: {new_segment_order}")
    
    # 我们需要在这里更新数据库。这需要一个新的 `update_job_preview_data_sync`
    # 为简单起见，我们只更新 preview_data 中的 segment_order 键
    job.preview_data["segment_order"] = new_segment_order
    update_status_sync(
        job_id, 
        job.status, # 保持状态不变
        job.progress, # 保持进度不变
        job.message, # 保持消息不变
        preview_data=job.preview_data # 仅更新 preview_data
    )
    
    return job


# generate_ppt_entry
def generate_ppt_entry(job: GenerationJob) -> GenerationJob:
    """生成PPT"""
    job_id = job.id
    try:
        # --- 1. 基础路径：全部转绝对路径 ---
        # 后端根目录（即当前文件所在目录的上级）
        backend_root = os.path.abspath(os.getcwd())

        output_root_path = os.path.join(backend_root, "generated_content")
        request_output_dir = os.path.join(output_root_path, str(job.user_id), str(job_id))

        # 保证输出目录存在
        os.makedirs(request_output_dir, exist_ok=True)

        logger = _setup_job_logger(job_id, request_output_dir)
        logger.info(json.dumps({
            "event": "Generating PPT...",
            "job_id": job_id,
            "message": "Generating PPT..."
        }))

        # --- 2. 各子目录绝对路径 ---
        scripts_dir = os.path.join(request_output_dir, "scripts")
        manim_final_dir = os.path.join(request_output_dir, "manim_codes_final")
        speech_dir = os.path.join(request_output_dir, "speech")
        ppt_dir = os.path.join(request_output_dir, "PPT")
        os.makedirs(ppt_dir, exist_ok=True)

        # --- 3. avatar 路径（前端可能传相对路径） ---
        avatar_path = job.settings.get("avatar_image", "csh.png")
        if not os.path.isabs(avatar_path):
            avatar_path = os.path.abspath(os.path.join(backend_root, avatar_path))

        # --- 3.5 background 路径 ---
        bg_path = job.settings.get("background_image", "")
        if bg_path:
            if bg_path.startswith("/uploads"):
                bg_path = os.path.join(backend_root, bg_path.lstrip("/"))
            elif not os.path.isabs(bg_path):
                bg_path = os.path.abspath(os.path.join(backend_root, bg_path))

        # --- 4. 构建绝对路径命令 ---
        ppt_script_path = os.path.join(backend_root, "PPTMerge_parallel.py")
        ppt_output_path = os.path.join(ppt_dir, "final.pptx")

        ppt_command = [
            "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
            ppt_script_path,
            manim_final_dir,
            ppt_output_path,
            "--title", job.settings.get("course_title", "unknown"),
            "--teacher", job.settings.get("professor_name", "unknown"),
            "--avatar", avatar_path,
            "--speech_dir", speech_dir,
            "--workers", "2"
        ]

        if bg_path:
            ppt_command.extend(["--bg", bg_path])

        run_subprocess_command(command=ppt_command, logger=logger)

        # --- 5. final.pptx 的绝对路径 ---
        ppt_path = ppt_output_path

        course_title = job.settings.get("course_title", "unknown")
        professor_name = job.settings.get("professor_name", "unknown")
        ppt_size = os.path.getsize(ppt_path) if os.path.exists(ppt_path) else 0

        # --- 6. 加入任务结果 ---
        job.result_files.append(
            {
                "name": f"课程PPT-{course_title}-{professor_name}.pptx",
                "path": ppt_path,
                "size": ppt_size,
                "type": "ppt",
            }
        )
        job.message = "PPT生成完成"
        with get_sync_db_session_context() as db:
            flag_modified(job, "result_files")
            db.add(job)
            db.commit()
            db.refresh(job)
        return job

    except Exception as e:
        raise ValueError(f"生成PPT失败: {str(e)}")

#     change_video_speed_entry


def change_video_speed_entry(job_status: GenerationJob, speed: float):
    job_id = job_status.id
    if not job_status:
        raise HTTPException(status_code=404, detail=f"任务 {job_id} 未找到")

    if job_status.status != "completed":
        raise HTTPException(status_code=400, detail=f"任务 {job_id} 状态不是 'completed'。")
    
    user_id = job_status.user_id
    video_dir = Path(f"generated_content/{user_id}/{job_id}")
    input_path = Path(job_status.result_files[0]["path"])
    temp_output_path = video_dir / "Full_temp_speed.mp4"

    if not input_path.exists():
        raise HTTPException(status_code=404, detail="原始视频文件未找到。")

    script_path = "/home/TeachMasterAppV2/backend/set_speed.sh" 
    command = [
        script_path,
        "-i", str(input_path),
        "-o", str(temp_output_path),
        "-s", str(speed)  # 将速度值转换为字符串
    ]
        
    print(f"🚀 准备执行脚本: {' '.join(command)}")

        # 3. 执行脚本命令
    result = subprocess.run(
        command,
        capture_output=True, # 捕获标准输出和标准错误
        text=True,           # 以文本形式捕获
        check=False          # 我们将手动检查返回码
    )

    # 4. 检查脚本是否成功执行
    if result.returncode != 0:
        # 如果脚本失败，记录错误并通知客户端
        print(f"❌ 脚本执行错误 job {job_id}:\n标准输出: {result.stdout}\n标准错误: {result.stderr}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"处理视频失败。脚本错误: {result.stderr or '无详细错误信息，请检查脚本日志。'}"
        )

    # 5. 成功后，用新生成的文件替换原始文件
    input_path.unlink() # 删除原始文件
    temp_output_path.rename(input_path) # 将临时文件重命名为原始文件名

    print(f"✅ 任务 {job_id} 的视频速度已成功调整为 {speed}x。")

    return BaseResponse(
        success=True,
        message=f"视频速度已成功调整为 {speed}x 并保存。",
        data={"speed": speed}
    )


def get_preview_data_entry(job: GenerationJob, script_version: str = "refined") -> dict:
        """
        获取预览数据，包括所有视频片段、对应代码和讲稿
        
        Args:
            job_id: 任务ID
            script_version: 讲稿版本 ("original" 或 "refined")
        """
        job_id = job.id

        print("job: ",job)
        if not job:
            return {"error": "任务不存在"}

        # --- 分页审阅阶段 ---
        if job.status == "awaiting_pagination_review":
            preview_data = job.preview_data or {}
            pagination_full_path = preview_data.get("pagination_full_path", "")
            pagination_files = preview_data.get("pagination_files", [])
            pagination_full_content = ""
            try:
                if pagination_full_path and os.path.exists(pagination_full_path):
                    # 读取完整分页内容，便于前端直接展示
                    with open(pagination_full_path, "r", encoding="utf-8") as f:
                        pagination_full_content = f.read()
            except Exception as e:
                pagination_full_content = f"[读取失败]: {e}"
            return {
                "job_id": job_id,
                "user_id": str(job.user_id),
                "status": "awaiting_pagination_review",
                "pagination_full_path": pagination_full_path,
                "pagination_full_content": pagination_full_content,
                "pagination_files": pagination_files,
                "message": "分页结果待审阅"
            }

        # --- 正常视频预览阶段 ---
        if job.status != "awaiting_preview_decision":
            return {"error": "任务不在预览阶段"}
            
        preview_data = job.preview_data
        # video_wo_audio_path = preview_data["video_wo_audio_path"]
        video_w_audio_path = preview_data["video_w_audio_path"]
        manim_code_path = preview_data["manim_code_path"]
        
        # 根据版本选择讲稿路径
        if script_version == "original":
            speech_script_path = preview_data.get("speech_script_original_path")
            if not speech_script_path:
                return {"error": "原始讲稿路径不存在"}
        else:
            speech_script_path = preview_data["speech_script_path"]
        
        preview_items = []
        
        try:
            feedback_data = FeedbackService()._read_feedback_data(job)
            # 获取所有视频文件
            import glob
            video_files = glob.glob(os.path.join(video_w_audio_path, "*.mp4"))
            def sort_key(filename):
                # 从文件名中提取所有数字
                numbers = re.findall(r'(\d+)', os.path.basename(filename))
                # 将提取到的字符串数字转换为整数元组，用于排序
                # 例如 "10_1.mp4" -> ('10', '1') -> (10, 1)
                return tuple(map(int, numbers))

            video_files.sort(key=sort_key)
            # video_files.sort()  # 按文件名排序
            
            for video_file in video_files:
                basename = os.path.splitext(os.path.basename(video_file))[0]
                
                # 找到对应的代码文件
                code_file = os.path.join(manim_code_path, f"{basename}.py")
                code_content = ""
                if os.path.exists(code_file):
                    with open(code_file, 'r', encoding='utf-8') as f:
                        code_content = f.read()
                
                # 找到对应的讲稿文件
                script_file = os.path.join(speech_script_path, f"{basename}.txt")
                script_content = ""
                script_exists = False
                if os.path.exists(script_file):
                    script_exists = True
                    with open(script_file, 'r', encoding='utf-8') as f:
                        script_content = f.read()
                
                # 获取视频文件大小
                video_size = os.path.getsize(video_file) if os.path.exists(video_file) else 0
                video_size_mb = video_size / (1024 * 1024)

                segment_feedback = feedback_data.get(basename, {})
                duration_seconds = content_helper.get_video_duration(f"{video_w_audio_path}/{basename}.mp4")
                duration_formatted = "计算中..."
                if duration_seconds is not None:
                    # 将时长转换为 'HH:MM:SS' 格式
                    hours = int(duration_seconds // 3600)
                    minutes = int((duration_seconds % 3600) // 60)
                    seconds = int(duration_seconds % 60)
                    
                    duration_formatted = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
                
                preview_items.append({
                    "id": basename,
                    "name": f"{basename}.mp4",
                    "video_path": f"https://www.teachmaster.cn/api/v1/content/preview-video/{job_id}/{basename}",
                    "code_content": code_content,
                    "script_content": script_content,
                    "script_exists": script_exists,
                    "script_version": script_version,
                    "file_size": f"{video_size_mb:.1f} MB",
                    "duration": duration_formatted,
                    "user_vote": segment_feedback.get("user_vote", None),
                    "comments": segment_feedback.get("comments", [])
                })
            
            return {
                "job_id": job_id,
                "user_id": str(job.user_id),  # 添加user_id，供前端构建图片路径使用
                "total_segments": len(preview_items),
                "segments": preview_items,
                "script_version": script_version,
                "script_paths": {
                    "original": preview_data.get("speech_script_original_path"),
                    "refined": preview_data["speech_script_path"]
                },
                "status": "ready_for_preview"
            }
            
        except Exception as e:
            return {"error": f"获取预览数据失败: {str(e)}"}

def LLM_modify_manim_code_entry(job: GenerationJob, segment_id: str, origin_code: str, user_request: str):
    """ 
    ARQ 任务: 调整 Manim 代码，并将结果*更新*到*单个* JSON 文件
    """
    
    print(f"开始处理 Job: {job.id}, Segment: {segment_id}")
    job_id_str = str(job.id)
    base_dir = Path(settings.GENERATED_CONTENT_DIR)
    file_path = base_dir / str(job.user_id) / str(job.id) / "modifications.json"
    file_path = str(file_path)

    try:
        # 读取现有数据
        all_data = {}
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                try:
                    content = f.read()
                    if content.strip():
                        all_data = json.loads(content)
                except json.JSONDecodeError:
                    print(f"警告：{file_path} 文件损坏，将覆盖。")
                    all_data = {}

        # 调用 LLM
        client = LLMAPIClient()
        user_prompt = client.load_prompt_template("ModifyManimCode")
        user_prompt = user_prompt.replace("{origin_code}", origin_code).replace("{user_request}", user_request)
        llm_result = client.call_api_with_text(user_prompt) 
            
        # 准备*这个片段*的数据
        segment_data = {
            "job_id": job_id_str,
            "segment_id": segment_id,
            "user_request": user_request,
            "modified_code": llm_result,
            "updated_at": datetime.now().isoformat(),
            "error": None
        }
            
        # 将此片段的数据更新到*总数据*中
        all_data[segment_id] = segment_data
            
        # 异步写回*整个*文件
        with open(file_path, 'w', encoding='utf-8') as f:
             f.write(json.dumps(all_data, indent=4, ensure_ascii=False))
                
        print(f"成功更新结果到: {file_path} (Segment: {segment_id})")

    except Exception as e:
        print(f"错误：处理 Job {job_id_str}, Segment {segment_id} 失败: {e}")
            
        error_data = {
            "job_id": job_id_str,
            "segment_id": segment_id,
            "user_request": user_request,
            "modified_code": None,
            "error": str(e),
            "updated_at": datetime.now().isoformat()
        }
        all_data.setdefault(segment_id, {}).update(error_data)
        with aiofiles.open(file_path, 'w', encoding='utf-8') as f:
            f.write(json.dumps(all_data, indent=4, ensure_ascii=False))
            
        raise # 重新抛出异常，以便 ARQ 知道任务失败
