"""
Pydantic models for API request/response schemas
"""

from datetime import datetime
import uuid
from typing import Generic, Optional, List, TypeVar, Any, Dict
from pydantic import BaseModel, EmailStr, Field
from app.db.models import TransactionType

T = TypeVar('T')

# Base models
class BaseResponse(BaseModel, Generic[T]):
    """Base response model"""
    success: bool = True
    code: int = 200
    message: str = "Success"
    data: Optional[T] = None


# User models
class UserBase(BaseModel):
    """Base user model"""
    email: EmailStr
    username: str
    password: str
    is_active: bool = True


class UserCreate(BaseModel):
    """User creation model"""
    email: EmailStr
    username: str
    password: str
    full_name: Optional[str] = None


class UserResponse(UserBase):
    """User response model"""
    id: int
    created_at: datetime
    
    class Config:
        from_attributes = True


class UserLogin(BaseModel):
    """User login model"""
    username: str
    password: str


class Token(BaseModel):
    """JWT token model"""
    access_token: str
    token_type: str = "bearer"
    expires_in: int


# Content models
class ContentBase(BaseModel):
    """Base content model"""
    title: str
    description: Optional[str] = None
    content_type: str  # "course", "chapter", "video", etc.


class ContentCreate(ContentBase):
    """Content creation model"""
    keywords: List[str] = []
    settings: Optional[dict] = {}


class ContentResponse(ContentBase):
    """Content response model"""
    id: int
    user_id: int
    status: str  # "pending", "processing", "completed", "failed"
    created_at: datetime
    updated_at: Optional[datetime] = None
    file_paths: List[str] = []
    
    class Config:
        from_attributes = True


class GenerationRequest(BaseModel):
    """Content generation request"""
    keyword: Optional[str] = None
    mode: Optional[str] = None

    enable_subtitles: Optional[bool] = True
    content_language: Optional[str] = "zh"
    attachment_dir_id: Optional[str] = None
    isLongVideo: Optional[bool] = False

    user_id: Optional[str] = None
    content_type: Optional[str] = "full_course"  # "outline", "chapter", "full_course", "video"
    max_results: Optional[int] = 2
    settings: Optional[dict] = {}
    school: Optional[str] = None
    college: Optional[str] = None
    # 添加新的可选字段
    background_image_id: Optional[str] = None
    reference_audio_id: Optional[str] = None
    # 封面生成相关参数
    professor_name: Optional[str] = None
    course_title: Optional[str] = None
    avatar_image_id: Optional[str] = None
    cover_background_image_id: Optional[str] = None
    generate_cover: Optional[bool] = True  # 是否生成封面和尾页

    # Add a field for the single-use access token
    access_token: Optional[str] = None

class GenerationResponse(BaseResponse):
    """Content generation response"""
    job_id: str
    status: str = "started"
    estimated_duration: Optional[int] = None  # in seconds


class JobStatus(BaseModel):
    """Job status model"""
    job_id: str
    user_id: int
    status: str  # "pending", "running", "completed", "failed"
    progress: int = 0  # 0-100
    message: Optional[str] = None  # 状态消息
    result: Optional[dict] = None
    settings: Optional[dict] = {}
    error: Optional[str] = None
    created_at: datetime
    completed_at: Optional[datetime] = None
    preview_data: Optional[dict] = None  # 预览数据

    current_step_start_time: str | None = None  # 步骤开始时间的ISO格式字符串
    current_step_estimated_time: int = 30       # 步骤预估总时长（秒）

    access_token: str = Field(..., description="A valid single-use token to authorize content generation.")

class JobStatusUpdate(BaseModel):
    status: str



class FileUploadResponse(BaseModel):
    """
    文件上传接口的响应模型
    包含上传状态、文件标识、原始信息等关键数据
    """
    
    # 文件唯一标识（用于后续内容生成接口引用，必选）
    file_id: str = Field(
        ..., 
        description="系统生成的唯一文件ID，格式为UUID+文件后缀（如：123e4567-e89b-12d3-a456-426614174000.md）"
    )
    dir_id: Optional[str] = Field(
        None, 
        description="目录ID，用于组织文件结构（如：123e4567-e89b-12d3-a456-426614174000）"
    )
    
    # 原始文件名（必选）
    # original_filename: str = Field(
    #     ..., 
    #     description="用户上传时的原始文件名（如：机器学习大纲.md）"
    # )
    # 文件名（必选）
    filename: str = Field(
        ..., 
        description="上传后的文件名（如：机器学习大纲.md）"
    )

    file_path: str = Field(
        ..., 
        description="文件保存路径（如：app/uploads/markdown/123e4567-e89b-12d3-a456-426614174000.md）"
    )
    
    # 文件保存路径（可选，后端内部追踪用，前端可忽略）
    # save_path: Optional[str] = Field(
    #     None, 
    #     description="文件在服务器的保存路径（如：app/uploads/markdown/123e4567-e89b-12d3-a456-426614174000.md）"
    # )
    
    # 文件大小（单位：字节，必选）
    # file_size: int = Field(
    #     ..., 
    #     description="文件大小，单位为字节（B）"
    # )
    
    # 文件MIME类型（可选）
    # file_type: Optional[str] = Field(
    #     None, 
    #     description="文件MIME类型（如：text/markdown），默认自动识别"
    # )
    
    # 上传时间（必选，默认自动填充当前UTC时间）
    created_at: datetime = Field(
        default_factory=datetime.utcnow, 
        description="文件上传时间，格式为UTC时间（如：2025-09-05T10:30:00.123456）"
    )

    # class Config:
    #     """
    #     配置类：支持从ORM对象解析，便于后续对接数据库
    #     """
    #     from_attributes = True
    



class SaveCodeRequest(BaseModel):
    """
    /save-code/{job_id} 的请求体
    """
    segment_id: str
    code_content: str

class SaveScriptRequest(BaseModel):
    """
    /save-script/{job_id} 和 /save-original-script/{job_id} 的请求体
    """
    segment_id: str
    script_content: str

class SegmentRequest(BaseModel):
    """
    所有 /regenerate-... 和 /reprocess-... 路由的请求体
    """
    segment_id: str

class SpeedRequest(BaseModel):
    """
    /video/speed/{job_id} 的请求体
    """
    speed: float = Field(..., gt=0, description="速度必须是正数") 

class SegmentUpdateItem(BaseModel):
    """
    /update-preview-segments/{job_id} 中 segments 列表的单个对象
    """
    id: str
    source_id: Optional[str] = Field(None, description="如果这是一个复制操作，则为源 segment_id")

class UpdateSegmentsRequest(BaseModel):
    """
    /update-preview-segments/{job_id} 的请求体
    """
    segments: List[SegmentUpdateItem]


class TokenResponse(BaseModel):
    """
    用于 /login 路由的响应模型。
    """
    access_token: str
    token_type: str = "bearer"

class UserPublic(BaseModel):
    """
    用于 API 响应的用户模型（不含密码）。
    """
    id: uuid.UUID
    email: EmailStr
    username: str
    full_name: Optional[str] = None
    is_active: bool
    is_superuser: bool
    created_at: datetime

    class Config:
        from_attributes = True


class ForgotPasswordRequest(BaseModel):
    """
    请求忘记密码时，前端发送的模型
    """
    email: EmailStr

class ResetPasswordRequest(BaseModel):
    """
    重置密码时，前端发送的模型
    """
    token: str
    new_password: str

    

    
class Comment(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    text: str
    user_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

class VoteRequest(BaseModel):
    segment_id: str
    user_vote: Optional[str] # Will be 'like', 'dislike', or null

class CommentRequest(BaseModel):
    segment_id: str
    comment_text: str

class VoteResponse(BaseModel):
    segment_id: str
    user_vote: Optional[str]


class FinalVoteRequest(BaseModel):
    vote_status: Optional[str]  # Can be 'like', 'dislike', or null

class FinalCommentRequest(BaseModel):
    comment_text: str

class Comment(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    text: str
    author: str = "User"
    created_at: datetime = Field(default_factory=datetime.utcnow)

class FinalFeedbackResponse(BaseModel):
    vote_status: Optional[str]
    comments: List[Comment]
    

class SystemFeedbackRequest(BaseModel):
    feedback_text: str = Field(..., min_length=10)

class ManimModifyRequest(BaseModel):
    job_id: str
    segment_id: str
    original_code: str
    user_request: str


class ManimModifyResponse(BaseModel):
    new_code: str
    explanation: str


class ModificationResultResponse(BaseModel):
    job_id: str
    segment_id: str
    user_request: str | None = None
    modified_code: str | None = None
    updated_at: str
    error: str | None = None

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    email: Optional[EmailStr] = None
    class Config:
        from_attributes = True

class TokenValidationRequest(BaseModel):
    token: str

# 通用分页响应结构
class PageResponse(BaseModel):
    total: int
    page: int
    size: int
    items: List[Any]

# --- User Schema ---
class UserUpdateAdmin(BaseModel):
    is_active: Optional[bool] = None
    is_superuser: Optional[bool] = None
    full_name: Optional[str] = None
    # 不允许管理员直接修改密码，通常只提供重置链接

# --- RechargePackage Schema ---
class PackageCreateUpdate(BaseModel):
    name: str
    amount_cents: int
    tcoins: int
    icon_key: Optional[str] = None
    best_value: bool = False
    ribbon_text: Optional[str] = None
    display_order: int = 0
    is_active: bool = True

class JobCreate(BaseModel):
    user_id: str  # 管理员必须指定归属用户
    status: str = "pending"
    progress: int = 0
    message: Optional[str] = None
    settings: Dict[str, Any] = {} # 允许手动传入配置
    
class JobUpdate(BaseModel):
    status: Optional[str] = None
    progress: Optional[int] = None
    message: Optional[str] = None
    error_message: Optional[str] = None
    # 允许管理员修补结果数据或配置用于调试
    result_files: Optional[List[Dict[str, Any]]] = None
    settings: Optional[Dict[str, Any]] = None

# --- Wallet 相关 ---
class WalletResponse(BaseModel):
    user_id: str
    balance: int
    version: int
    updated_at: datetime
    created_at: datetime

class WalletAdjust(BaseModel):
    user_id: str
    amount: int # 变动金额，正数加钱，负数扣钱
    notes: Optional[str] = "管理员手动调整"

# --- Transaction Log 相关 ---
class TransactionLogResponse(BaseModel):
    id: str
    user_id: str
    transaction_type: TransactionType
    amount: int
    balance_after: int
    related_job_id: Optional[str]
    notes: Optional[str]
    created_at: datetime

class ConfirmRequest(BaseModel):
    job_id: str
    new_notes: str