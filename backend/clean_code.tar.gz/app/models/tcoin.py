
from datetime import datetime
import uuid
from typing import Generic, Optional, List, TypeVar
from pydantic import BaseModel, EmailStr, Field
from app.db.models import TransactionType

class SettingsStub:
    STRIPE_SECRET_KEY: str = "sk_test_..." # 替换为您的 Stripe Secret Key
    STRIPE_WEBHOOK_SECRET: str = "whsec_..." # 替换为您的 Webhook Signing Secret
    FRONTEND_URL: str = "https://www.teachmaster.cn"


class RechargeRequest(BaseModel):
    # package_id 映射到预定义的充值包
    package_id: str

class TransactionLogResponse(BaseModel):
    id: str
    transaction_type: TransactionType
    amount: int
    balance_after: int
    notes: Optional[str]
    created_at: datetime
    related_job_id: Optional[str]
    related_order_id: Optional[str]

    class Config:
        from_attributes = True

class HistoryResponseData(BaseModel):
    items: List[TransactionLogResponse]
    page: int
    limit: int
    total: int

class RechargePackageCreate(BaseModel):
    id: str
    name: str
    amount_cents: int
    tcoins: int
    icon_key: Optional[str] = None
    best_value: bool = False
    ribbon_text: Optional[str] = None
    display_order: int = 0
    is_active: bool = True

class RechargePackageUpdate(BaseModel):
    name: Optional[str] = None
    amount_cents: Optional[int] = None
    tcoins: Optional[int] = None
    icon_key: Optional[str] = None
    best_value: Optional[bool] = None
    ribbon_text: Optional[str] = None
    display_order: Optional[int] = None
    is_active: Optional[bool] = None

class RedeemCodeCreate(BaseModel):
    """创建兑换码请求"""
    code: str = Field(..., min_length=4, max_length=20, description="兑换码（固定20字符：Timo + 16字符短码）")
    tcoins: int = Field(..., gt=0, description="T币数量")
    valid_from: Optional[datetime] = None
    valid_until: Optional[datetime] = None
    notes: Optional[str] = None


class RedeemCodeUseRequest(BaseModel):
    """使用兑换码请求"""
    code: str = Field(..., min_length=4, max_length=20, description="兑换码（固定20字符）")


class RedeemCodeResponse(BaseModel):
    """兑换码响应"""
    id: str
    code: str
    tcoins: int
    is_used: bool
    used_at: Optional[datetime] = None
    used_by_user_id: Optional[str] = None
    valid_from: Optional[datetime] = None
    valid_until: Optional[datetime] = None
    notes: Optional[str] = None
    created_by: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True



class RedeemCodeEncryptRequest(BaseModel):
    """加密兑换码请求"""
    tcoins: int = Field(..., gt=0, description="T币数量")
    valid_from: Optional[datetime] = None
    valid_until: Optional[datetime] = None
    notes: Optional[str] = None


class RedeemCodeEncryptResponse(BaseModel):
    """加密兑换码响应"""
    code: str = Field(..., description="加密后的兑换码（以Timo开头）")


class RedeemCodeDecryptRequest(BaseModel):
    """解密兑换码请求"""
    code: str = Field(..., min_length=4, max_length=128, description="兑换码")


class RedeemCodeDecryptResponse(BaseModel):
    """解密兑换码响应"""
    tcoins: int
    valid_from: Optional[datetime] = None
    valid_until: Optional[datetime] = None
    notes: Optional[str] = None