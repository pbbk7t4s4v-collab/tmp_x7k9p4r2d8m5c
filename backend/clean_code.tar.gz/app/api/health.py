"""
Health check endpoints
"""

from fastapi import APIRouter, Depends, HTTPException
from datetime import datetime
import time
import os
from app.models.schemas import BaseResponse, ConfirmRequest
from app.db.database import get_db
from app.db.models import User
from app.api.content import get_job_or_404
from app.services.auth_service import oauth2_scheme, get_current_user
from sqlalchemy.ext.asyncio import AsyncSession
router = APIRouter()


@router.get("/health", response_model=BaseResponse)
async def health_check():
    """Health check endpoint"""
    return BaseResponse(
        message="Service is healthy",
        timestamp=datetime.now()
    )


@router.get("/ping")
async def ping():
    """Simple ping endpoint"""
    return {"message": "pong", "timestamp": datetime.now().isoformat()}

@router.get("/notes-heartbeat")
async def check_heartbeat(
    job_id: str,
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db), # 注入数据库
    current_user: User = Depends(get_current_user)
):
    """
    前端心跳接口
    逻辑：只要请求此接口，就去数据库把 deadline 往后推
    """
    
    # 续 60 秒
    new_deadline = time.time() + 60
    job = await get_job_or_404(job_id, db)

    current_settings = dict(job.settings) if job.settings else {}
    current_settings['deadline'] = new_deadline
    job.settings = current_settings
    if job and job.status in ('awaiting_check', 'awaiting_pagination_review'):
        db.add(job)
        await db.commit()
        await db.refresh(job)
        return BaseResponse(data={"msg": "续命成功", "new_deadline": new_deadline})
    
    return BaseResponse(code=404, data={"msg": "忽略", "reason": "任务不存在或不在等待状态"})

@router.post("/notes-confirm")
async def api_confirm(
    request: ConfirmRequest,
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db), # 注入数据库
    current_user: User = Depends(get_current_user)
):
    """
    用户确认接口
    逻辑：更新讲义内容，并将状态改为 CONFIRMED
    """
    job_id = request.job_id
    new_notes = request.new_notes
    
    job = await get_job_or_404(job_id, db)
    if job and job.status == 'awaiting_check':
        # 修改对应讲义文件内容
        md_path = job.settings.get('notes_path')
        if md_path:
            try:
                # 确保目录存在
                os.makedirs(os.path.dirname(md_path), exist_ok=True)
                # 覆盖写入
                with open(md_path, 'w', encoding='utf-8') as f:
                    f.write(new_notes)
                print(f"[API] 成功更新本地文件: {md_path}")
            except OSError as e:
                # 记录错误但不一定阻断流程，或者返回 500
                print(f"[API] 更新文件失败: {e}")
                raise HTTPException(status_code=500, detail=f"文件写入失败: {str(e)}")
        else:
            print("[API] 警告: 任务中未找到 notes_path，跳过文件更新")
        job.status = "CONFIRMED" # 这是一个信号状态，告诉 Worker 可以继续了
        db.add(job)
        await db.commit()
        await db.refresh(job)
        return BaseResponse(data={"msg": "已确认，正在处理"})
    
    return BaseResponse(code=404, data={"msg": "忽略", "reason": "任务不存在或不在等待状态"})
