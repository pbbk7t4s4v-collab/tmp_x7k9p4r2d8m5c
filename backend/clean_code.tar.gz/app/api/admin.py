from typing import Any, List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from sqlmodel import select as sql_select # 为了避免冲突，或者直接用 sqlalchemy 的 select 也可以，但在 sqlmodel 模型上通常通用
from sqlmodel import desc, func
import datetime
import json
import base64
import zlib
import logging
import secrets
import string
logger = logging.getLogger(__name__)
from cryptography.fernet import Fernet, InvalidToken
from app.db.models import User, GenerationJob, RechargePackage, UserWallet, TcoinTransactionLog, TransactionType, RedeemCode
from app.db.database import get_db
from app.models.schemas import BaseResponse, PageResponse, UserUpdateAdmin, JobUpdate, WalletResponse, WalletAdjust, TransactionLogResponse
from app.models.tcoin import (
    RechargePackageCreate, RechargePackageUpdate, RedeemCodeCreate, RedeemCodeResponse,
    RedeemCodeEncryptRequest, RedeemCodeEncryptResponse,
    RedeemCodeDecryptRequest, RedeemCodeDecryptResponse
)
from app.services.auth_service import oauth2_scheme, get_admin_user
from app.core.config import settings

router = APIRouter()

# --- 通用分页帮助函数 (异步版) ---
async def get_pagination(
    db: AsyncSession, 
    model: Any, 
    page: int, 
    size: int, 
    filters: list = None
):
    # 1. 计算总数
    # 注意：func.count() 需要放在 select 中
    count_query = select(func.count()).select_from(model)
    if filters:
        for f in filters:
            count_query = count_query.where(f)
            
    # 执行异步查询
    total_result = await db.execute(count_query)
    total = total_result.scalar_one()

    # 2. 查询数据
    query = select(model)
    if filters:
        for f in filters:
            query = query.where(f)
    
    # 默认按创建时间倒序（如果模型有created_at）
    if hasattr(model, 'created_at'):
        query = query.order_by(model.created_at.desc())
        
    query = query.offset((page - 1) * size).limit(size)
    
    # 执行异步查询
    result = await db.execute(query)
    items = result.scalars().all()
    
    return PageResponse(total=total, page=page, size=size, items=items)

# ================= 用户管理 =================

@router.get("/users", response_model=BaseResponse)
async def get_all_users(
    page: int = 1, 
    size: int = 10, 
    email: str = None,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(get_admin_user)
):
    filters = []
    if email:
        filters.append(User.email.contains(email))
    
    # 调用异步分页函数
    pagination_data = await get_pagination(db, User, page, size, filters)
    return BaseResponse(data=pagination_data)

@router.put("/users/{user_id}", response_model=BaseResponse)
async def update_user_status(
    user_id: str,
    user_in: UserUpdateAdmin,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(get_admin_user)
):
    user = await db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user_data = user_in.dict(exclude_unset=True)
    for key, value in user_data.items():
        setattr(user, key, value)
    
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return BaseResponse(data=user)

@router.delete("/users/{user_id}")
async def delete_user(
    user_id: str,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(get_admin_user)
):
    user = await db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    await db.delete(user)
    await db.commit()
    return BaseResponse(data={"ok": True})

# ================= 套餐管理 =================
@router.get(
    "/package", 
    response_model=BaseResponse, 
    summary="获取所有可用的T币充值套餐"
)
async def get_recharge_packages(
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    stmt = (
        select(RechargePackage)
        .where(RechargePackage.is_active == True)
        .order_by(RechargePackage.display_order)
    )
    result = await db.execute(stmt)
    packages = result.scalars().all()
    return BaseResponse(data=packages)

@router.post(
    "/package", 
    response_model=BaseResponse, 
    summary="[Admin] 创建新套餐"
)
async def create_package(
    package_in: RechargePackageCreate,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    admin: User = Depends(get_admin_user)
):
    # 检查 ID 是否已存在 (如果 id 是前端传来的话，如果是自动生成则不需要这一步)
    if package_in.id:
        existing = await db.get(RechargePackage, package_in.id)
        if existing:
            raise HTTPException(status_code=400, detail="套餐 ID 已存在")
        
    db_package = RechargePackage.model_validate(package_in)
    db.add(db_package)
    await db.commit()
    await db.refresh(db_package)
    return BaseResponse(data=db_package)

@router.patch(
    "/package/{package_id}", 
    response_model=BaseResponse, 
    summary="[Admin] 修改套餐"
)
async def update_package(
    package_id: str,
    package_in: RechargePackageUpdate,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    admin: User = Depends(get_admin_user)
):
    db_package = await db.get(RechargePackage, package_id)
    if not db_package:
        raise HTTPException(status_code=404, detail="套餐未找到")
        
    package_data = package_in.model_dump(exclude_unset=True)
    for key, value in package_data.items():
        setattr(db_package, key, value)
        
    db.add(db_package)
    await db.commit()
    await db.refresh(db_package)
    return BaseResponse(data=db_package)

@router.delete(
    "/package/{package_id}",  # 修复路径缺少斜杠
    summary="[Admin] 删除套餐",
    # status_code=status.HTTP_204_NO_CONTENT # 如果返回 BaseResponse，通常不用 204
)
async def delete_package(
    package_id: str,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    admin: User = Depends(get_admin_user)
):
    db_package = await db.get(RechargePackage, package_id)
    if db_package:
        await db.delete(db_package)
        await db.commit()
    return BaseResponse(data={"ok": True})

@router.get(
    "/package/all", 
    response_model=BaseResponse, 
    summary="[Admin] 获取所有套餐（包括禁用的）"
)
async def get_all_packages(
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    admin: User = Depends(get_admin_user)
):
    stmt = select(RechargePackage).order_by(RechargePackage.display_order)
    result = await db.execute(stmt)
    return BaseResponse(data=result.scalars().all())

# ================= 任务管理 (CRUD) =================

@router.get("/jobs", response_model=BaseResponse)
async def get_jobs( # 记得加 async
    page: int = 1, 
    size: int = 10, 
    status: str = None,
    user_id: str = None,
    job_id: str = None,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(get_admin_user)
):
    filters = []
    if status:
        filters.append(GenerationJob.status == status)
    if user_id:
        filters.append(GenerationJob.user_id == user_id)
    if job_id:
        filters.append(GenerationJob.id == job_id)
        
    # 调用异步分页
    pagination_data = await get_pagination(db, GenerationJob, page, size, filters)
    return BaseResponse(data=pagination_data)

@router.put("/jobs/{job_id}", response_model=BaseResponse)
async def update_job( # 记得加 async
    job_id: str,
    job_in: JobUpdate,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(get_admin_user)
):
    job = await db.get(GenerationJob, job_id) # 使用 await db.get
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    job_data = job_in.dict(exclude_unset=True)
    for key, value in job_data.items():
        setattr(job, key, value)
        
    db.add(job)
    await db.commit()
    await db.refresh(job)
    return BaseResponse(data=job)

@router.delete("/jobs/{job_id}", response_model=BaseResponse)
async def delete_job( # 记得加 async
    job_id: str,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(get_admin_user)
):
    job = await db.get(GenerationJob, job_id) # 使用 await db.get
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    await db.delete(job)
    await db.commit()
    return BaseResponse(data={"ok": True})


# ================= 钱包管理 =================

@router.get("/wallets", response_model=BaseResponse)
async def get_wallets(
    page: int = 1, 
    size: int = 10, 
    user_id: str = None,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(get_admin_user)
):
    query = select(UserWallet)
    if user_id:
        query = query.where(UserWallet.user_id == user_id)
    
    # 计算总数
    count_query = select(func.count()).select_from(query.subquery())
    total = (await db.execute(count_query)).scalar_one()
    
    # 分页查询
    query = query.offset((page - 1) * size).limit(size).order_by(desc(UserWallet.updated_at))
    result = await db.execute(query)
    items = result.scalars().all()
    
    return BaseResponse(data={"items": items, "total": total, "page": page, "size": size})

@router.post("/wallets/adjust", response_model=BaseResponse)
async def adjust_wallet_balance(
    adjust_in: WalletAdjust,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(get_admin_user)
):
    """
    管理员调整余额接口。
    注意：这是金融逻辑，必须使用事务锁或乐观锁，并必须记录流水。
    """
    # 1. 获取钱包 (使用 with_for_update 加行锁，防止并发问题)
    # 注意：AsyncSession 的行锁语法可能依赖具体数据库，这里展示通用逻辑
    query = select(UserWallet).where(UserWallet.user_id == adjust_in.user_id).with_for_update()
    result = await db.execute(query)
    wallet = result.scalar_one_or_none()
    
    if not wallet:
        # 如果钱包不存在，可以选择报错或者自动创建（这里选择报错）
        raise HTTPException(status_code=404, detail="User Wallet not found")
        
    # 2. 计算新余额
    new_balance = wallet.balance + adjust_in.amount
    if new_balance < 0:
        raise HTTPException(status_code=400, detail="Balance cannot be negative after adjustment")

    # 3. 更新钱包
    wallet.balance = new_balance
    wallet.version += 1 # 乐观锁版本号 +1
    
    # 4. 创建交易流水 (关键步骤)
    log = TcoinTransactionLog(
        user_id=wallet.user_id,
        transaction_type=TransactionType.ADMIN_ADJUST,
        amount=adjust_in.amount,
        balance_after=new_balance,
        notes=adjust_in.notes,
        created_at=datetime.datetime.utcnow()
    )
    
    db.add(wallet)
    db.add(log)
    
    try:
        await db.commit()
        await db.refresh(wallet)
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Transaction failed: {str(e)}")
        
    return BaseResponse(data=wallet)

# ================= 交易流水查询 =================

@router.get("/transactions", response_model=BaseResponse)
async def get_transactions(
    page: int = 1, 
    size: int = 10, 
    user_id: str = None,
    type: TransactionType = None,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(get_admin_user)
):
    query = select(TcoinTransactionLog)
    
    if user_id:
        query = query.where(TcoinTransactionLog.user_id == user_id)
    if type:
        query = query.where(TcoinTransactionLog.transaction_type == type)
        
    # 排序：最新的在前
    query = query.order_by(desc(TcoinTransactionLog.created_at))
    
    # 计算总数
    count_query = select(func.count()).select_from(query.subquery())
    total = (await db.execute(count_query)).scalar_one()
    
    # 分页
    query = query.offset((page - 1) * size).limit(size)
    result = await db.execute(query)
    items = result.scalars().all()
    
    return BaseResponse(data={"items": items, "total": total})


# ================= 兑换码管理 =================

@router.post(
    "/redeem-codes",
    response_model=BaseResponse,
    summary="[Admin] 创建兑换码"
)
async def create_redeem_code(
    code_in: RedeemCodeCreate,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    admin: User = Depends(get_admin_user)
):
    """
    管理员创建兑换码。
    """
    # 检查兑换码是否已存在
    stmt = select(RedeemCode).where(RedeemCode.code == code_in.code.upper().strip())
    result = await db.execute(stmt)
    existing = result.scalar_one_or_none()
    
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="兑换码已存在"
        )
    
    # 创建兑换码
    redeem_code = RedeemCode(
        code=code_in.code.upper().strip(),
        tcoins=code_in.tcoins,
        valid_from=code_in.valid_from,
        valid_until=code_in.valid_until,
        notes=code_in.notes,
        created_by=admin.id
    )
    
    db.add(redeem_code)
    await db.commit()
    await db.refresh(redeem_code)
    
    return BaseResponse(data=RedeemCodeResponse.model_validate(redeem_code))


@router.get(
    "/redeem-codes",
    response_model=BaseResponse,
    summary="[Admin] 获取兑换码列表"
)
async def get_redeem_codes(
    page: int = 1,
    size: int = 10,
    code: str = None,
    is_used: bool = None,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    admin: User = Depends(get_admin_user)
):
    """
    管理员查询兑换码列表。
    """
    filters = []
    if code:
        filters.append(RedeemCode.code.contains(code.upper().strip()))
    if is_used is not None:
        filters.append(RedeemCode.is_used == is_used)
    
    pagination_data = await get_pagination(db, RedeemCode, page, size, filters)
    return BaseResponse(data=pagination_data)


@router.get(
    "/redeem-codes/{code_id}",
    response_model=BaseResponse,
    summary="[Admin] 获取单个兑换码详情"
)
async def get_redeem_code(
    code_id: str,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    admin: User = Depends(get_admin_user)
):
    """
    管理员获取单个兑换码详情。
    """
    redeem_code = await db.get(RedeemCode, code_id)
    if not redeem_code:
        raise HTTPException(status_code=404, detail="兑换码未找到")
    
    return BaseResponse(data=RedeemCodeResponse.model_validate(redeem_code))


@router.delete(
    "/redeem-codes/{code_id}",
    response_model=BaseResponse,
    summary="[Admin] 删除兑换码"
)
async def delete_redeem_code(
    code_id: str,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    admin: User = Depends(get_admin_user)
):
    """
    管理员删除兑换码（仅限未使用的）。
    """
    redeem_code = await db.get(RedeemCode, code_id)
    if not redeem_code:
        raise HTTPException(status_code=404, detail="兑换码未找到")
    
    if redeem_code.is_used:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="已使用的兑换码不能删除"
        )
    
    await db.delete(redeem_code)
    await db.commit()
    
    return BaseResponse(data={"ok": True})



def generate_short_code(length: int = 16) -> str:
    """
    生成固定长度的随机短码
    使用大写字母和数字，避免容易混淆的字符（0, O, I, 1）
    """
    # 使用大写字母和数字，排除容易混淆的字符
    alphabet = string.ascii_uppercase.replace('O', '').replace('I', '') + string.digits.replace('0', '').replace('1', '')
    # 确保包含足够的字符
    alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    return ''.join(secrets.choice(alphabet) for _ in range(length))


@router.post(
    "/redeem-codes/encrypt",
    response_model=BaseResponse,
    summary="[Admin] 生成兑换码（固定长度）"
)
async def encrypt_redeem_code(
    encrypt_request: RedeemCodeEncryptRequest,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    admin: User = Depends(get_admin_user)
):
    """
    根据配置信息生成固定长度的兑换码（Timo + 16字符短码 = 20字符）。
    配置数据存储在数据库中，通过短码关联。
    """
    try:
        # 生成固定长度的短码（16字符）
        short_code = generate_short_code(16)
        code = f"Timo{short_code}"  # 总共20字符，固定长度
        
        # 检查兑换码是否已存在（极小概率，但需要检查）
        max_retries = 10
        retry_count = 0
        while retry_count < max_retries:
            stmt = select(RedeemCode).where(RedeemCode.code == code)
            result = await db.execute(stmt)
            existing = result.scalar_one_or_none()
            
            if not existing:
                break  # 兑换码唯一，可以使用
                
            # 如果已存在，重新生成
            short_code = generate_short_code(16)
            code = f"Timo{short_code}"
            retry_count += 1
        
        if retry_count >= max_retries:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="生成唯一兑换码失败，请重试"
            )
        
        logger.info(f"成功生成固定长度兑换码: {code} (长度: {len(code)}字符)")
        return BaseResponse(data=RedeemCodeEncryptResponse(code=code))
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.exception(f"生成兑换码时发生未知错误: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"生成兑换码失败: {str(e)}"
        )


@router.post(
    "/redeem-codes/decrypt",
    response_model=BaseResponse,
    summary="[Admin] 解密兑换码（从数据库查询配置）"
)
async def decrypt_redeem_code(
    decrypt_request: RedeemCodeDecryptRequest,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    admin: User = Depends(get_admin_user)
):
    """
    从数据库查询兑换码配置信息（固定长度短码方案）。
    """
    try:
        code = decrypt_request.code.strip()
        
        # 检查是否以"Timo"开头
        if not code.startswith("Timo"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="兑换码格式不正确，必须以Timo开头"
            )
        
        # 检查长度（应该是20字符：Timo + 16字符短码）
        if len(code) != 20:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="兑换码长度不正确，应为20字符"
            )
        
        # 从数据库查询兑换码配置
        stmt = select(RedeemCode).where(RedeemCode.code == code)
        result = await db.execute(stmt)
        redeem_code = result.scalar_one_or_none()
        
        if not redeem_code:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="兑换码不存在或配置未找到"
            )
        
        return BaseResponse(data=RedeemCodeDecryptResponse(
            tcoins=redeem_code.tcoins,
            valid_from=redeem_code.valid_from,
            valid_until=redeem_code.valid_until,
            notes=redeem_code.notes
        ))
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"解密兑换码时发生未知错误: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"解密失败: {str(e)}"
        )