"""
API 路由：用于用户认证
"""
import secrets
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from pydantic import BaseModel
from app.services.tcoin_service import tcoin_service, TransactionType

from app.db.database import get_db
from app.core.security import create_access_token
from app.db.models import User
from app.models.schemas import (
    UserCreate, 
    UserPublic, 
    UserLogin, 
    TokenResponse, 
    BaseResponse,
    ForgotPasswordRequest,
    ResetPasswordRequest,
    UserUpdate,
    TokenValidationRequest
)
from app.services.auth_service import (
    hash_password, 
    verify_password, 
    get_user_by_email_or_username,
    get_current_user
)
from app.helper.content_helper import ContentHelper

router = APIRouter()

# --- 辅助模型 ---

class Settings(BaseModel):
    authjwt_secret_key: str
    authjwt_algorithm: str
    authjwt_access_token_expires: int # 确保这是整数（秒）


# --- 路由 ---
@router.post("/signup", response_model=BaseResponse, status_code=status.HTTP_201_CREATED)
async def register_user(
    user_in: UserCreate, 
    db: AsyncSession = Depends(get_db)
) -> BaseResponse:
    """
    创建新用户（注册）。
    """
    # 检查用户或邮箱是否已存在
    existing_user = await get_user_by_email_or_username(db, user_in.email, user_in.username)
    if existing_user:
        return BaseResponse(
            success=False,
            code=409,
            message="用户名或邮箱已被注册。",
        )
        
    # 创建新用户
    hashed_password = hash_password(user_in.password)
    new_user = User(
        email=user_in.email,
        username=user_in.username,
        hashed_password=hashed_password,
        full_name=user_in.full_name
    )
    
    db.add(new_user)
    try:
        await db.commit()
        await db.refresh(new_user)
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"创建用户失败: {e}"
        )
    user = await get_user_by_email_or_username(db, username_or_email=new_user.username)
    
    await tcoin_service.credit(
                    db=db,
                    user_id=user.id, # 假设 user_id 是 string/char(36)
                    amount=10,
                    tx_type=TransactionType.RECHARGE,
                    notes=f"新用户注册"
                )
                
    print(f"✅ Webhook: 用户 {user.id} 成功注册T币钱包。")
        
    return BaseResponse(
        success=True,
        code=status.HTTP_201_CREATED,
        message="用户注册成功。",
        data=UserPublic.model_validate(new_user) # 使用model_validate替代from_orm
    )

@router.post("/login", response_model=BaseResponse)
async def login_for_access_token(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db)
) -> BaseResponse:
    """
    用户登录以获取 JWT Access Token。
    
    注意：这是 OAuth2 标准，它使用 'username' 字段。
    我们允许用户使用他们的 `username` 或 `email` 登录。
    """
    user = await get_user_by_email_or_username(db, username_or_email=form_data.username)
    
    # 验证用户是否存在以及密码是否正确
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="用户名或密码不正确",
            headers={"WWW-Authenticate": "Bearer"},
        )
        
    # 验证用户是否激活
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="用户已被禁用"
        )
        
    # 创建 access token
    # 使用security.py中的create_access_token函数
    access_token = create_access_token(subject=str(user.id))
    
    return BaseResponse(
        message="登录成功",
        data=TokenResponse(
            access_token=access_token,
            token_type="bearer"
        )
    )

@router.get("/me", response_model=BaseResponse)
async def read_users_me(
    user: User = Depends(get_current_user) # 使用我们的依赖项
) -> BaseResponse:
    """
    获取当前登录用户的信息。
    
    `get_current_user` 依赖项会处理所有 JWT 验证。
    """
    return BaseResponse(
        message="用户信息获取成功",
        data=UserPublic.model_validate(user) # 使用model_validate替代from_orm
    )
async def get_user_by_reset_token(db: AsyncSession, token: str) -> User | None:
    """
    通过重置令牌查找用户
    """
    stmt = select(User).where(User.reset_token == token)
    result = await db.execute(stmt)
    return result.scalars().first()

@router.post("/forgot-password", response_model=BaseResponse)
async def forgot_password(
    request: ForgotPasswordRequest, 
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """
    处理“忘记密码”请求。
    """
    # 1. 允许使用邮箱或用户名查找（尽管表单是Email）
    user = await get_user_by_email_or_username(db, email=request.email)
    
    # [安全提示] 无论用户是否存在，我们都返回成功消息
    # 这可以防止攻击者通过此端点枚举您系统中的电子邮件地址。
    if not user:
        print(f"Password reset attempt for non-existent user: {request.email}")
        return BaseResponse(
            success=True,
            code=status.HTTP_200_OK,
            message="如果该邮箱已注册，您将收到一封密码重置邮件。"
        )

    # 2. 生成一个安全的重置令牌
    token = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    
    # 3. 设置令牌和过期时间（例如，1小时后）
    # [假设] 您的 User 模型有 'reset_token' 和 'reset_token_expires' 字段
    try:
        user.reset_token = token
        user.reset_token_expires = now + timedelta(hours=1)
        
        db.add(user)
        await db.commit()
    except AttributeError:
        # 如果您没有在 User 模型中添加字段，将在此处失败
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="后端 User 模型配置不正确，缺少 reset_token 字段。"
        )
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"数据库更新失败: {e}"
        )

    # 4. [模拟发送邮件]
    # 在真实应用中, 您会在这里使用 fastapi-mail 或 smtplib
    # 将包含令牌的链接发送给 user.email
    reset_link = f"https://www.teachmaster.cn/reset-password?token={token}"
    content_helper = ContentHelper()
    subject = "密码重置请求"
    body = f"您的密码重置链接为: {reset_link}\n\n请点击链接重置您的密码。\n\n如果您未请求重置密码，请忽略此邮件。"
    
    background_tasks.add_task(
        content_helper._send_email_background,
        recipient=user.email,
        subject=subject,
        body=body
    )
    
    return BaseResponse(
        success=True,
        code=status.HTTP_200_OK,
        message="如果该邮箱已注册，您将收到一封密码重置邮件。"
    )

@router.post("/validate-reset-token", response_model=BaseResponse)
async def validate_reset_token_post(
    payload: TokenValidationRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    验证 Token 是否有效 (POST 方法)
    """
    user = await get_user_by_reset_token(db, payload.token)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="无效的重置令牌。"
        )

    # --- 修复时间比较错误 ---
    expiry = user.reset_token_expires
    
    # 数据库取出的时间可能是 Naive 的 (不含时区)，默认为 UTC
    if expiry and expiry.tzinfo is None:
        expiry = expiry.replace(tzinfo=timezone.utc)

    if not expiry or expiry <= datetime.now(timezone.utc):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="重置令牌已过期。"
        )

    return BaseResponse(message="Token 有效")


@router.post("/reset-password", response_model=BaseResponse)
async def reset_password(
    request: ResetPasswordRequest, 
    db: AsyncSession = Depends(get_db)
):
    """
    处理实际的密码重置
    """
    # 1. 验证 token
    user = await get_user_by_reset_token(db, request.token)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="无效的重置令牌。"
        )

    # 2. 检查过期 --- 同样应用时间修复 ---
    expiry = user.reset_token_expires
    if expiry and expiry.tzinfo is None:
        expiry = expiry.replace(tzinfo=timezone.utc)

    if not expiry or expiry <= datetime.now(timezone.utc):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="重置令牌已过期。"
        )

    # 3. 更新密码
    try:
        user.hashed_password = hash_password(request.new_password)
        
        # 4. 销毁令牌
        user.reset_token = None
        user.reset_token_expires = None
        
        db.add(user)
        await db.commit()
        # await db.refresh(user)
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"密码更新失败: {str(e)}"
        )

    return BaseResponse(message="您的密码已成功重置，请使用新密码登录。")

@router.patch("/user/me", response_model=BaseResponse)
async def update_user_me(
    *,
    db: AsyncSession = Depends(get_db),
    user_in: UserUpdate,
    current_user: User = Depends(get_current_user), # 获取当前Token对应的用户
):
    """
    更新当前用户的个人信息
    """
    # 1. 检查邮箱是否已被其他用户占用 (如果用户修改了邮箱)
    if user_in.email and user_in.email != current_user.email:
        result = await db.execute(
            select(User).where(User.email == user_in.email)
        )
        existing_user = result.scalars().first()
        if existing_user:
            raise HTTPException(
                status_code=400,
                detail="该邮箱已被注册",
            )

    # 2. 获取 Pydantic 模型中的数据，排除未传的字段 (exclude_unset=True)
    # 这样前端只传 full_name 时，不会把 email 覆盖为 None
    update_data = user_in.dict(exclude_unset=True)

    # 3. 更新数据库对象属性
    for field, value in update_data.items():
        setattr(current_user, field, value)

    # 4. 提交事务
    db.add(current_user)
    await db.commit()
    await db.refresh(current_user) # 刷新对象以获取最新数据（如updated_at）

    return BaseResponse(data=current_user)