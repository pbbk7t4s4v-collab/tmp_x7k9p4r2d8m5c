# app/api/endpoints/tokens.py

from fastapi import APIRouter, Depends, status, Query, HTTPException
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from app.services.auth_service import oauth2_scheme
from app.services.token_service import token_service
from pydantic import ConfigDict
from app.models.schemas import BaseResponse

router = APIRouter()

# --- Response and Request Models ---

class TokenGenerationResponse(BaseModel):
    message: str
    generated_tokens: List[str]

class TokenValidationRequest(BaseModel):
    token: str = Field(..., description="The token string to validate.")

class TokenRequest(BaseModel):
    token: str = Field(..., description="The token string to process.")

class TokenDetails(BaseModel):
    model_config = ConfigDict(
        populate_by_name=True,
    )
    created_by: str
    page: int
    purpose: str
    jti: str
    iat: str = Field(..., alias="issued_at")
    exp: Optional[str] = Field(None, alias="expires_at")

class TokenValidationResponse(BaseModel):
    status: str
    message: str
    details: Optional[TokenDetails] = None


# --- API Endpoints ---

@router.post(
    "/generate",
    response_model=BaseResponse[TokenGenerationResponse],
    summary="Generate New Encrypted Access Tokens",
    status_code=status.HTTP_201_CREATED,
    tags=["Tokens"]
)
def generate_new_tokens(
    count: int = Query(1, ge=1, le=100, description="The number of tokens to generate."),
    purpose: str = Query("course_generation", description="The purpose for which these tokens are being generated."),
    page: int = Query(10, ge=1, description="The page number for pagination."),
    expires_in_seconds: Optional[int] = Query(
        None, 
        ge=60, 
        description="Token lifetime in seconds (e.g., 86400 for 1 day). If not provided, the token will not expire."
    ),
    admin_user: str = Query(..., description="The username of the user creating the tokens."),
    token: str = Depends(oauth2_scheme) 
):
    """
    Generates a specified number of single-use, encrypted access tokens. The creator's username is automatically embedded.
    
    - **count**: How many tokens to create.
    - **purpose**: A string describing the use case for these tokens (e.g., "final_exam_access").
    - **expires_in_seconds**: How long the token should be valid for. Must be at least 60 seconds.
    
    This endpoint requires admin authentication.
    """
    # MODIFIED: Pass the creator's username and purpose to the service
    new_tokens = token_service.generate_tokens(
        count=count,
        created_by=admin_user, # The authenticated username is used as the creator
        page=page,
        purpose=purpose,
        expires_in_seconds=expires_in_seconds
    )
    return BaseResponse(
        success=True,
        message=f"Successfully generated {len(new_tokens)} new token(s) for purpose '{purpose}'.",
        data=new_tokens
    )

# --- NEW ENDPOINT ---
@router.post(
    "/validate",
    response_model=BaseResponse,
    summary="Validate an Access Token",
    tags=["Tokens"]
)
def validate_token(
    request: TokenValidationRequest,
    token: str = Depends(oauth2_scheme) 
):
    """
    Verifies if a token is valid, unused, and not expired. If valid, it decrypts and returns the embedded information.
    
    This endpoint is useful for administrators to check the status and details of a token without consuming it.
    
    Requires admin authentication.
    """
    token_str = request.token
    
    # Check if the token is valid in the lifecycle management system
    is_currently_valid = token_service.is_valid(token_str)
    
    if not is_currently_valid:
        return BaseResponse(
            success=False,
            message="Token is not currently valid. It may have been used, expired, or tampered with.",
            data=None
        )
        
    # If valid, decrypt to get details
    token_details = token_service.decrypt_token_info(token_str)
    
    # This check is redundant if is_valid passed, but it's good practice
    if not token_details:
        return BaseResponse(
            success=False,
            message="Token is valid but failed decryption. This could indicate a problem.",
            data=None
        )

    return BaseResponse(
        success=True,
        message="Token is valid and ready for use.",
        data=token_details
    )


@router.post(
    "/decrypt",
    response_model=BaseResponse[TokenDetails],
    summary="Decrypt Token Information (Admin)",
    tags=["Tokens"]
)
def decrypt_token(
    request: TokenRequest,
    token: str = Depends(oauth2_scheme) 
):
    """
    Decrypts a token to reveal its embedded information, regardless of whether it has been used or has expired.
    
    This is an administrative endpoint for auditing and troubleshooting. It will fail only if the token is malformed or was signed with a different secret key (i.e., it's counterfeit).
    """
    # Call the service to decrypt the token, ignoring the expiration date
    token_details = token_service.decrypt_token_info_with_ignore_expiration(request.token, ignore_expiration=True)
    
    if not token_details:
        return BaseResponse(
            success=False,
            message="Unable to decrypt token. It may be malformed, counterfeit, or corrupted.",
            data=None
        )
        
    return BaseResponse(
        success=True,
        message="Token decrypted successfully.",
        data=token_details
    )
