from app.models.schemas import(
    Comment,
    VoteRequest,
    CommentRequest,
    VoteResponse,
    FinalVoteRequest,
    FinalCommentRequest,
    FinalFeedbackResponse,
    SystemFeedbackRequest,
    BaseResponse,

)

from fastapi import (
    APIRouter, HTTPException, status, Depends, BackgroundTasks
)
from app.services.auth_service import oauth2_scheme, get_current_user
from app.services.feedback_service import FeedbackService
from app.db.database import get_db
from app.db.models import GenerationJob, User
import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional, Any

router = APIRouter()
feedback_service = FeedbackService()

async def get_job_or_404(job_id: uuid.UUID, db: AsyncSession, check_status: Optional[str] = None) -> GenerationJob:
    """
    从数据库获取 Job，如果找不到则抛出 404。
    如果提供了 check_status，还会验证任务状态。
    """
    job = await db.get(GenerationJob, job_id)
    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Job {job_id} not found"
        )
    if check_status and job.status != check_status:
         raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Job {job_id} is not in '{check_status}' state (current: {job.status})"
        )
    return job

@router.post("/vote/{job_id}", response_model=BaseResponse)
async def set_vote_status(
    job_id: str,
    request: VoteRequest,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Sets the vote status for a specific video segment."""
    try:
        feedback_service.set_user_vote(
            await get_job_or_404(job_id, db), request.segment_id, request.user_vote
        )
        return BaseResponse(data={
            "segment_id": request.segment_id,
            "user_vote": request.user_vote
        })
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Job or segment not found for job_id: {job_id}"
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to set vote status: {str(e)}"
        )


# --- NEW ENDPOINT FOR COMMENTING ---
@router.post("/comment/{job_id}", response_model=BaseResponse, status_code=status.HTTP_201_CREATED)
async def add_comment(
    job_id: str,
    request: CommentRequest,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    """Adds a comment to a specific video segment."""
    try:
        # 根据job_id获取对应语言的服务
        new_comment = feedback_service.add_comment(
            await get_job_or_404(job_id, db), request.segment_id, request.comment_text
        )
        return BaseResponse(data=new_comment)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Job or segment not found for job_id: {job_id}"
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to add comment: {str(e)}"
        )
    
@router.get("/final-video/{job_id}", response_model=BaseResponse)
async def get_final_video_feedback(job_id: str, db: AsyncSession = Depends(get_db),token: str = Depends(oauth2_scheme)):
    # 根据job_id获取对应语言的服务
    return feedback_service.get_final_video_feedback(await get_job_or_404(job_id, db))

@router.post("/final-video-vote/{job_id}")
async def set_final_video_vote(job_id: str, request: FinalVoteRequest,db: AsyncSession = Depends(get_db), token: str = Depends(oauth2_scheme)):
    # 根据job_id获取对应语言的服务
    return feedback_service.set_final_video_vote_status(await get_job_or_404(job_id, db), request.vote_status)

@router.post("/final-video-comment/{job_id}", response_model=BaseResponse)
async def add_final_video_comment(job_id: str, request: FinalCommentRequest, db: AsyncSession = Depends(get_db),token: str = Depends(oauth2_scheme)):
    # 根据job_id获取对应语言的服务
    return feedback_service.add_final_video_comment(await get_job_or_404(job_id, db), request.comment_text)

# --- PPT Feedback Endpoints ---
@router.get("/ppt/{job_id}", response_model=BaseResponse)
async def get_ppt_feedback(job_id: str, db: AsyncSession = Depends(get_db),token: str = Depends(oauth2_scheme)):
    # 根据job_id获取对应语言的服务
    return feedback_service.get_ppt_feedback(await get_job_or_404(job_id, db))

@router.post("/ppt-vote/{job_id}")
async def set_ppt_vote(job_id: str, request: FinalVoteRequest, db: AsyncSession = Depends(get_db),token: str = Depends(oauth2_scheme)):
    # 根据job_id获取对应语言的服务
    return feedback_service.set_ppt_vote_status(await get_job_or_404(job_id, db), request.vote_status)

@router.post("/ppt-comment/{job_id}", response_model=BaseResponse)
async def add_ppt_comment(job_id: str, request: FinalCommentRequest, db: AsyncSession = Depends(get_db),token: str = Depends(oauth2_scheme)):
    # 根据job_id获取对应语言的服务
    return feedback_service.add_ppt_comment(await get_job_or_404(job_id, db), request.comment_text)

@router.post("/system", response_model=BaseResponse)
def submit_system_feedback_endpoint(
    request: SystemFeedbackRequest,
    background_tasks: BackgroundTasks, # Inject BackgroundTasks
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme) # Keep authentication if needed
):
    """Submits system feedback via email."""
    try:
        return feedback_service.submit_system_feedback(
            request.feedback_text, current_user.email, background_tasks
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to submit feedback: {str(e)}"
        )