import uuid
import stripe
from datetime import datetime
from typing import List, Optional, Any, Dict

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel
from app.db.models import User, TcoinTransactionLog, RedeemCode
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from sqlmodel import Field
from app.models.schemas import BaseResponse
from app.models.tcoin import SettingsStub, RechargeRequest, TransactionLogResponse, HistoryResponseData, RechargePackageCreate, RechargePackageUpdate, RedeemCodeUseRequest
from app.db.models import RechargePackage
from app.db.database import get_db
from app.services.auth_service import get_current_user, oauth2_scheme, get_admin_user
from app.services.tcoin_service import tcoin_service, TransactionType
settings = SettingsStub()

# --- Stripe API Key 配置 ---
stripe.api_key = settings.STRIPE_SECRET_KEY
# --- API 路由 ---
router = APIRouter()

@router.get(
    "/balance", 
    response_model=BaseResponse, 
    summary="获取当前用户T币余额"
)
async def get_user_balance(
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    current_user: User = Depends(get_current_user) # 使用真实的用户依赖
):
    """
    获取当前登录用户的T币余额。
    """

    print(current_user)
    try:
        balance = await tcoin_service.get_balance(db, user_id=current_user.id)
        return BaseResponse(data={"balance":balance})
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取余额失败: {str(e)}"
        )

@router.get(
    "/history", 
    response_model=BaseResponse,
    summary="获取T币交易历史"
)
async def get_user_transaction_history(
    page: int = 1,
    limit: int = 10,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    current_user: User = Depends(get_current_user)
):
    """
    获取当前登录用户的T币交易历史，按时间倒序分页。
    """
    if page < 1: page = 1
    if limit < 1 or limit > 100: limit = 10
    
    try:
        # 1. 查询总数
        count_stmt = select(func.count(TcoinTransactionLog.id)).where(
            TcoinTransactionLog.user_id == current_user.id
        )
        total_result = await db.execute(count_stmt)
        total = total_result.scalar_one()

        # 2. 查询分页数据
        stmt = (
            select(TcoinTransactionLog)
            .where(TcoinTransactionLog.user_id == current_user.id)
            .order_by(TcoinTransactionLog.created_at.desc())
            .offset((page - 1) * limit)
            .limit(limit)
        )
        result = await db.execute(stmt)
        items = result.scalars().all()
        
        return BaseResponse(
            data=HistoryResponseData(
                items=[TransactionLogResponse.from_orm(item) for item in items],
                page=page,
                limit=limit,
                total=total
            )
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取历史记录失败: {str(e)}"
        )


@router.post(
    "/create-recharge", 
    response_model=BaseResponse,
    summary="创建充值订单"
)
async def create_recharge_session(
    request: RechargeRequest,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    current_user: User = Depends(get_current_user)
):
    """
    为当前用户创建一个 Stripe 支付会话。
    用户选择一个预定义的充值包，后端返回一个支付 URL。
    """
    package = await db.get(RechargePackage, request.package_id)

    if not package or not package.is_active:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, 
            detail="充值包未找到或已下架"
        )
    # 预定义的充值包 (T币数量, 价格(分))
    # 价格ID (price_id) 是在 Stripe Dashboard 中预先创建的
    # 或者您可以使用 price_data 动态创建
    # PACKAGES = {
    #     "pkg_100": {"tcoins": 100, "amount_cents": 100, "name": "100 T币"}, # 1元
    #     "pkg_1000": {"tcoins": 1000, "amount_cents": 1000, "name": "1000 T币"}, # 10元
    #     "pkg_5000": {"tcoins": 5000, "amount_cents": 4500, "name": "5000 T币 (9折)"}, # 45元
    # }
    
    # package = PACKAGES.get(request.package_id)
    # if not package:
    #     raise HTTPException(
    #         status_code=status.HTTP_404_NOT_FOUND, 
    #         detail="充值包未找到"
    #     )

    try:
        # session = stripe.checkout.Session.create(
        #     payment_method_types=['card'], # 或 'alipay', 'wechat_pay' (需Stripe配置)
        #     line_items=[{
        #         'price_data': {
        #             'currency': 'cny', # 或 'usd'
        #             'product_data': {
        #                 'name': package["name"],
        #             },
        #             'unit_amount': package["amount_cents"], # 价格(分)
        #         },
        #         'quantity': 1,
        #     }],
        #     mode='payment',
        #     success_url=f"{settings.FRONTEND_URL}/payment/success?session_id={{CHECKOUT_SESSION_ID}}",
        #     cancel_url=f"{settings.FRONTEND_URL}/payment/cancel",
            
        #     # 关键：将我们的内部数据存入 metadata，以便 Webhook 使用
        #     metadata={
        #         "user_id": str(current_user.id),
        #         "tcoin_amount": package["tcoins"],
        #         "package_id": request.package_id
        #     }
        # )
        session = {"url": f"https://www.teachmaster.cn/payment/success?session_id={uuid.uuid4()}"}
        await tcoin_service.credit(
            db=db,
            user_id=current_user.id, # 假设 user_id 是 string/char(36)
            amount=package.tcoins,
            tx_type=TransactionType.RECHARGE,
            order_id=str(uuid.uuid4()),
            notes=f"模拟 Stripe 充值 {package.tcoins} T币"
        )
        print(f"✅ Webhook: 用户 {current_user.id} 成功充值 {package.tcoins} T币。")
        
        return BaseResponse(data={"checkout_url": session.get("url")})

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"创建支付会话失败: {str(e)}"
        )

@router.post("/webhook/payment-success", summary="Stripe支付成功Webhook")
async def stripe_webhook_payment_success(
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    """
    接收 Stripe 支付成功后的回调。
    此接口由 Stripe 服务器调用，不应被用户直接调用。
    """
    payload = await request.body()
    sig_header = request.headers.get('Stripe-Signature')
    
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, settings.STRIPE_WEBHOOK_SECRET
        )
    except ValueError as e:
        # 无效的 payload
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except stripe.error.SignatureVerificationError as e:
        # 无效的签名
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    # --- 处理 Webhook 事件 ---

    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']
        
        # 1. 检查支付状态
        if session.payment_status == "paid":
            metadata = session.metadata
            user_id = metadata.get('user_id')
            tcoin_amount_str = metadata.get('tcoin_amount')
            order_id = session.payment_intent # 使用 payment_intent 作为唯一订单ID
            
            if not all([user_id, tcoin_amount_str, order_id]):
                # Metadata 丢失，严重错误
                print(f"❌ Webhook 错误: 丢失 metadata. Session ID: {session.id}")
                raise HTTPException(status_code=400, detail="Webhook metadata 丢失")
                
            try:
                tcoin_amount = int(tcoin_amount_str)
                
                # 2. 幂等性检查：防止重复处理
                async with db.begin_nested(): # 使用子事务进行查询
                    stmt = select(TcoinTransactionLog).where(
                        TcoinTransactionLog.related_order_id == order_id
                    )
                    existing_log = await db.execute(stmt)
                    if existing_log.scalar_one_or_none():
                        print(f"ℹ️ Webhook: 订单 {order_id} 已处理，跳过。")
                        return {"status": "already_processed"}

                # 3. 事务性：为用户充值
                await tcoin_service.credit(
                    db=db,
                    user_id=user_id, # 假设 user_id 是 string/char(36)
                    amount=tcoin_amount,
                    tx_type=TransactionType.RECHARGE,
                    order_id=order_id,
                    notes=f"Stripe 充值 {tcoin_amount} T币"
                )
                
                print(f"✅ Webhook: 用户 {user_id} 成功充值 {tcoin_amount} T币。")

            except ValueError:
                raise HTTPException(status_code=400, detail="Webhook metadata tcoin_amount 无效")
            except Exception as e:
                # 充值失败，Stripe 将重试 Webhook
                print(f"❌ Webhook 充值失败: {e}")
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, 
                    detail="充值入账失败"
                )

    # 告诉 Stripe 已成功接收
    return {"status": "received"}

@router.post(
    "/redeem",
    response_model=BaseResponse,
    summary="使用兑换码充值T币"
)
async def redeem_code(
    request: RedeemCodeUseRequest,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    current_user: User = Depends(get_current_user)
):
    """
    用户使用兑换码进行T币充值。
    """
    # 1. 查找兑换码
    stmt = select(RedeemCode).where(RedeemCode.code == request.code.upper().strip())
    result = await db.execute(stmt)
    redeem_code = result.scalar_one_or_none()
    
    if not redeem_code:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="兑换码不存在"
        )
    
    # 2. 检查是否已使用
    if redeem_code.is_used:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="兑换码已被使用"
        )
    
    # 3. 检查有效期
    now = datetime.utcnow()
    if redeem_code.valid_from and now < redeem_code.valid_from:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="兑换码尚未生效"
        )
    
    if redeem_code.valid_until and now > redeem_code.valid_until:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="兑换码已过期"
        )
    
    # 4. 使用事务确保原子性
    try:
        # 标记兑换码为已使用
        redeem_code.is_used = True
        redeem_code.used_at = now
        redeem_code.used_by_user_id = current_user.id
        
        # 为用户充值T币
        await tcoin_service.credit(
            db=db,
            user_id=current_user.id,
            amount=redeem_code.tcoins,
            tx_type=TransactionType.REDEEM_CODE,
            order_id=str(redeem_code.id),
            notes=f"兑换码充值: {request.code}"
        )
        
        await db.commit()
        
        return BaseResponse(
            data={
                "message": f"成功充值 {redeem_code.tcoins} T币",
                "tcoins": redeem_code.tcoins
            }
        )
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"兑换失败: {str(e)}"
        )





