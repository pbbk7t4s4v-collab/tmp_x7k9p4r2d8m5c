import subprocess
import uuid
import os
import re
import mimetypes
import zipfile
import json
import base64
import io
import aiofiles
import asyncio
import urllib.parse
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, List

from fastapi import (
    APIRouter, HTTPException, status, Depends, 
    UploadFile, File, Form, Request, Header
)
from sqlalchemy.orm.attributes import flag_modified
from fastapi.responses import FileResponse, StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select, desc, func
from app.services.tcoin_service import tcoin_service, COST_PER_REGENERATE, COST_PER_JOB

# 内部依赖
from app.models.schemas import (
    GenerationRequest, 
    GenerationResponse, 
    BaseResponse,
    FileUploadResponse,
    SaveCodeRequest,
    SaveScriptRequest,
    SegmentRequest,
    SpeedRequest,
    UpdateSegmentsRequest,
    ManimModifyRequest,
    JobStatusUpdate
)

from app.services.auth_service import get_current_user, get_user_id_from_token, oauth2_scheme
from app.services.token_service import token_service # 
from app.db.database import get_db
from app.db.models import GenerationJob, UploadedFile, User
from app.core.config import settings
from app.core.dependencies import get_redis
from arq.connections import ArqRedis
from app.helper.content_helper import ContentHelper
from app.models.schemas import ModificationResultResponse
from pydantic import BaseModel

# Worker 函数 (我们将在这里运行轻量级的I/O)
from app.workers.generation_tasks import (
    get_preview_data_entry,
    save_manim_code_entry,
    save_script_content_entry,
    save_original_script_content_entry,
    update_preview_segments_entry,
    rollback_segment_entry
)


router = APIRouter()
content_helper = ContentHelper()

class PaginationConfirmRequest(BaseModel):
    job_id: str
    full_paginated: str

async def get_job_or_404(job_id: uuid.UUID, db: AsyncSession, check_status: Optional[str] = None) -> GenerationJob:
    """
    从数据库获取 Job，如果找不到则抛出 404。
    如果提供了 check_status，还会验证任务状态。
    """
    job = await db.get(GenerationJob, job_id)
    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Job {job_id} not found"
        )
    if check_status and job.status != check_status:
         raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Job {job_id} is not in '{check_status}' state (current: {job.status})"
        )
    return job


@router.post("/generate-image", response_model=BaseResponse[dict])
async def generate_image_api(
    prompt: str = Form(...),
    filename: Optional[str] = Form(None),
    token: str = Depends(oauth2_scheme),
    current_user: User = Depends(get_current_user),
):
    """
    调用本地 image_generator.py 生成 1:1 图片，返回保存路径。
    """
    output_dir = Path("backend/uploads/generated_images")
    output_dir.mkdir(parents=True, exist_ok=True)
    fname = filename or f"{uuid.uuid4()}.png"
    output_path = output_dir / fname

    cmd = [
        sys.executable,
        "/home/TeachMasterAppV2/backend/image_generator.py",
        prompt,
        str(output_path),
    ]

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await proc.communicate()

    if proc.returncode != 0:
        detail = stderr.decode() or "image_generator 执行失败"
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=detail
        )

    data_url = None
    try:
        img_bytes = output_path.read_bytes()
        b64 = base64.b64encode(img_bytes).decode()
        data_url = f"data:image/png;base64,{b64}"
    except Exception:
        data_url = None

    abs_path = str(output_path.resolve())

    return BaseResponse(
        success=True,
        data={
            "path": abs_path,
            "name": output_path.name,
            "stdout": stdout.decode() if stdout else "",
            "data_url": data_url,
            "absolute_dir": str(output_dir.resolve()),
        }
    )

@router.post("/generate", response_model=GenerationResponse | BaseResponse)
async def generate_content(
    request: GenerationRequest,
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db), # 注入数据库
    current_user: User = Depends(get_current_user),
    redis: ArqRedis = Depends(get_redis) # 注入 Redis
):
    use_token = False
    if request.access_token:
        if not token_service.is_valid(request.access_token):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Invalid or already used access token. Please provide a valid token."
            )
        else:
            use_token = True

    
    """Start content generation process"""
    # 生成唯一的 Job ID
    job_id_obj = uuid.uuid4()
    request.user_id = current_user.id

    # 检查余额
    wallet = await tcoin_service.get_wallet(db, uuid.UUID(current_user.id))
    if wallet.balance < COST_PER_JOB:
        return BaseResponse(
            success=False,
            code=403,
            message="用户T币余额不足。"
        )
    # 在数据库中创建 Job 记录
    new_job = GenerationJob(
        id=job_id_obj,
        user_id=uuid.UUID(request.user_id),
        status="pending", # 初始状态
        progress=0,
        message="任务已排队",
        request_payload=request.dict(), # 保存请求详情
        access_token=request.access_token
    )
    db.add(new_job)
    await db.commit()
    await db.refresh(new_job)

    # 将任务推送到 ARQ 队列
    await redis.enqueue_job(
        'generate_content_task', 
        new_job,
        request.dict()
    )
    
    return GenerationResponse(
        job_id=str(job_id_obj),
        message=f"任务已入队: {request.keyword}",
        estimated_duration=300 
    )


@router.get("/jobs/{job_id}", response_model=BaseResponse)
async def get_job_status(
    job_id: uuid.UUID, # 验证 UUID
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
) -> BaseResponse:
    """
    (异步) 从数据库获取单个 content generation job 的状态。
    """
    print(f"获取任务状态: {job_id}")
    job = await get_job_or_404(job_id, db)
    
    # # 使用 Pydantic 模型进行响应（自动从 ORM 转换）
    # job_status_response = JobStatus.from_orm(job)
    # return BaseResponse(data=job_status_response)
    return BaseResponse(data=job)

@router.get("/jobs", response_model=BaseResponse)
async def get_user_jobs(
    limit: int = 10,
    offset: int = 0,
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
) -> BaseResponse:
    """
    (异步) 从数据库获取当前用户的所有 content generation jobs 的列表（分页）。
    """
    # 从token中获取用户ID
    # 注意：这里需要实现从token获取用户ID的逻辑
    user_id = await get_user_id_from_token(token)  # 需要实现这个函数
    # 按用户ID过滤并分页查询
    query = select(GenerationJob).where(
        GenerationJob.user_id == str(user_id)
    ).offset(offset).limit(limit).order_by(desc(GenerationJob.created_at))
    
    result = await db.execute(query)
    print(result)
    jobs = result.scalars().all()
    
    # 获取总数用于分页
    count_query = select(func.count(GenerationJob.id)).where(
        GenerationJob.user_id == str(user_id)
    )
    count_result = await db.execute(count_query)
    total = count_result.scalar()
    
    return BaseResponse(data={
        "jobs": jobs,
        "total": total,
        "limit": limit,
        "offset": offset
    })


@router.get("/stats", response_model=BaseResponse)
async def get_job_statistics(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
    token: str = Depends(oauth2_scheme)
):
    """
    获取当前用户的任务统计数据：已完成、失败、排队中、进行中
    """
    
    stmt = (
        select(GenerationJob.status, func.count(GenerationJob.id))
        .where(GenerationJob.user_id == current_user.id)
        .group_by(GenerationJob.status)
    )
    
    result = await db.execute(stmt) 
    results = result.all()
    
    # 初始化计数器
    stats = {
        "total": 0,
        "completed": 0,
        "failed": 0,
        "pending": 0,
        "processing": 0
    }
    
    for status, count in results:
        stats["total"] += count
        
        if status == "completed":
            stats["completed"] += count
            
        elif status == "failed":
            stats["failed"] += count
            
        elif status in ["pending", "continuation_queued"]:
            stats["pending"] += count
            
        else:
            stats["processing"] += count

    return BaseResponse(data=stats)


@router.get("/jobs/{job_id}/files", response_model=BaseResponse)
async def get_job_files(
    job_id: uuid.UUID,
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
) -> BaseResponse:
    """
    (异步) 获取指定任务的所有生成文件和上传文件。
    """
    # 获取任务信息
    job = await get_job_or_404(job_id, db)
    
    # 从token中获取用户ID，验证权限
    user_id = get_user_id_from_token(token)  # 需要实现这个函数
    
    # 验证用户是否有权限访问此任务
    if str(job.user_id) != str(user_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="您没有权限访问此任务的文件"
        )
    
    # 获取任务相关的生成文件
    generated_files = job.result_files if job.result_files else []
    
    # 获取任务相关的上传文件
    uploaded_files = []
    if job.request_payload:
        # 检查请求中是否包含上传的文件ID
        for file_type in ["background_image_id", "reference_audio_id", "reference_text_id"]:
            file_id = job.request_payload.get(file_type)
            if file_id:
                # 从数据库查询上传文件信息
                file_query = select(UploadedFile).where(UploadedFile.id == file_id)
                file_result = await db.execute(file_query)
                uploaded_file = file_result.scalar_one_or_none()
                if uploaded_file:
                    uploaded_files.append({
                        "id": str(uploaded_file.id),
                        "type": file_type.replace("_id", ""),
                        "original_filename": uploaded_file.original_filename,
                        "file_size": uploaded_file.file_size,
                        "created_at": uploaded_file.created_at
                    })
    
    return BaseResponse(data={
        "job_id": str(job_id),
        "generated_files": generated_files,
        "uploaded_files": uploaded_files
    })


@router.delete("/jobs/{job_id}", response_model=BaseResponse)
async def delete_job(
    job_id: uuid.UUID,
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
):
    """
    (异步) 从数据库删除一个 Job 记录。
    TODO: 还应该删除关联的磁盘文件。
    """
    job = await get_job_or_404(job_id, db)
    
    # TODO: 在此添加逻辑以删除 job.preview_data 和 job.result_files 中的所有文件
    
    await db.delete(job)
    await db.commit()
    return BaseResponse(message=f"Job {job_id} deleted successfully")


@router.get("/download/{job_id}/{file_name}", response_class=FileResponse)
async def download_file(
    job_id: uuid.UUID,
    file_name: str,
    db: AsyncSession = Depends(get_db)
):
    """
    (异步) 下载单个生成的文件（从 job.result_files）。
    """
    job = await get_job_or_404(job_id, db, check_status="completed")
    
    file_to_download = None
    for file_info in job.result_files:
        if file_info.get("name") == file_name:
            file_to_download = file_info
            break
            
    if not file_to_download:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"File {file_name} not found in job {job_id}"
        )
        
    file_path = file_to_download.get("path")
    if not file_path or not Path(file_path).exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"File {file_name} no longer exists on server."
        )
        
    return FileResponse(
        path=file_path,
        filename=file_name,
        media_type="application/octet-stream"
    )

@router.get("/downloadAll/{job_id}", response_class=StreamingResponse)
async def download_all_files(
    job_id: uuid.UUID,
    db: AsyncSession = Depends(get_db)
):
    """
    (异步) 打包下载所有生成的（在 job.result_files 中的）文件。
    在 `to_thread` 中运行 `zip` 以防止阻塞。
    """
    job = await get_job_or_404(job_id, db, check_status="completed")
    # 创建内存中的zip文件
    zip_buffer = io.BytesIO()
    
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
        # 添加每个文件到zip
        for file in job.result_files:
            file_path = file["path"]
            if os.path.exists(file_path):
                zip_file.write(file_path, arcname=file["name"])
    
    # 确保zip文件指针在开始位置
    zip_buffer.seek(0)
    
    # 生成zip文件名
    keyword = job.request_payload.get("keyword", "content")
    zip_filename = f"{keyword}_generated_files.zip"
    
    # 返回zip文件流
    return StreamingResponse(
        io.BytesIO(zip_buffer.getvalue()),
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename={zip_filename}"}
    )

@router.post("/upload", response_model=BaseResponse[FileUploadResponse], status_code=status.HTTP_201_CREATED)
async def upload_markdown_file(
    file: UploadFile = File(...),
    file_type: str = Form(...),
    token: str = Depends(oauth2_scheme)  # 认证保护
) -> BaseResponse[FileUploadResponse]:
    try:
        # 生成唯一文件ID
        file_id = str(uuid.uuid4())
        
        # 根据文件类型确定存储目录
        if file_type == 'background_image':
            upload_dir = Path("uploads/backgrounds")
        elif file_type == 'reference_audio':
            upload_dir = Path("uploads/audios")
        elif file_type == 'reference_text':
            upload_dir = Path("uploads/texts")
        elif file_type == 'avatar_image':
            upload_dir = Path("uploads/avatars")
        elif file_type == 'cover_background_image':
            upload_dir = Path("uploads/cover_backgrounds")
        elif file_type == 'markdown':
            upload_dir = Path("uploads/md")
        elif file_type == 'ppt':
            upload_dir = Path("uploads/ppt")
        else:
            upload_dir = Path("uploads/others")

        upload_dir.mkdir(parents=True, exist_ok=True)
        
        # 保存文件
        file_path = upload_dir / f"{file_id}_{file.filename}"
        with open(file_path, "wb") as f:
            f.write(await file.read())
        
        return BaseResponse(
            success=True,
            data=FileUploadResponse(
                file_id=file_id,
                filename=file.filename,
                file_path=str(file_path),
                created_at=datetime.utcnow()
            )
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to upload file: {str(e)}"
        )

@router.post(
    "/upload-batch", 
    response_model=BaseResponse[List[FileUploadResponse]], 
    status_code=status.HTTP_201_CREATED
)
async def upload_batch_files(
    files: List[UploadFile] = File(...),
    file_type: str = Form(...),
    dir_id: str | None = Form(None),  #  允许用户传入可选的 dir_id
    token: str = Depends(oauth2_scheme)  # 认证保护
) -> BaseResponse[List[FileUploadResponse]]:
    """
    批量上传文件接口。
    
    - files: 多个文件。
    - file_type: 所有文件将被归类到这个类型。
    - dir_id: 用于需要目录访问的类型。如果提供, 则上传到该目录; 否则创建新目录。
    - token: 认证令牌。
    """
    print(">>> [START] upload_batch_files: Received file request.")
    # 仅在需要时才生成新的 dir_id
    current_dir_id = dir_id
    
    # 根据文件类型确定存储目录
    if file_type == 'attachment': 
        if not current_dir_id:
            # 如果用户没有提供 dir_id，则创建新的
            current_dir_id = str(uuid.uuid4())
        upload_dir = Path(f"uploads/attachments/{current_dir_id}")
    else:
        upload_dir = Path("uploads/others")

    # (目录已存在时 exist_ok=True 会忽略错误)
    upload_dir.mkdir(parents=True, exist_ok=True)
    
    uploaded_files_response: List[FileUploadResponse] = []
    
    try:
        for file in files:
            # 为每个文件生成唯一的 file_id
            file_id = str(uuid.uuid4())
            file_path = upload_dir / f"{file_id}_{file.filename}"
            
            # 异步读取文件内容并写入磁盘
            file_content = await file.read()
            with open(file_path, "wb") as f:
                f.write(file_content)
            
            # 准备响应
            response_data = FileUploadResponse(
                file_id=file_id,
                filename=file.filename,
                file_path=str(file_path),
                created_at=datetime.utcnow()
            )

            # 如果是 attachment, 附带上 dir_id
            if file_type == 'attachment':
                response_data.dir_id = current_dir_id
                
            uploaded_files_response.append(response_data)
            
        return BaseResponse(
            success=True,
            data=uploaded_files_response
        )
        
    except Exception as e:
        # 如果在处理任何一个文件时出错，则整个批次失败
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to upload batch files: {str(e)}"
        )

@router.get("/preview-video/{job_id}/{video_name}", response_class=FileResponse)
async def get_preview_video_segment(
    job_id: uuid.UUID,
    video_name: str,
    range: Optional[str] = Header(None),
    db: AsyncSession = Depends(get_db)
    # 移除了 token 认证，以便 <video> 标签可以直接访问
):
    """
    (异步) 获取预览视频文件（无音频）。
    """
    from urllib.parse import unquote
    
    job = await get_job_or_404(job_id, db)
    
    # 允许在这些状态下预览
    if job.status not in ("awaiting_preview_decision", "continuation_queued", "continuing", "running"):
         raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Job is not in a previewable state (current: {job.status})"
        )
        
    preview_data = job.preview_data
    if not preview_data:
        raise HTTPException(status_code=404, detail="Job has no preview data")
        
    # video_wo_audio_path = preview_data.get("video_wo_audio_path")
    video_w_audio_path = preview_data.get("video_w_audio_path")
    if not video_w_audio_path:
        raise HTTPException(status_code=404, detail="Preview data is missing video path")
        
    # 处理 URL 解码：FastAPI 会自动解码，但为了安全起见，我们再次解码
    # 同时处理可能的空格问题（将空格替换为下划线，因为视频文件名通常是 segment_id，格式为 "0_1"）
    decoded_video_name = unquote(video_name)
    # 如果视频名称包含空格，尝试替换为下划线（因为视频文件名格式通常是 "0_1"）
    normalized_video_name = decoded_video_name.replace(" ", "_")
    
    # 构建完整的视频文件路径
    video_file_path = Path(video_w_audio_path) / f"{normalized_video_name}.mp4"
    
    # 如果使用规范化名称找不到文件，尝试使用原始名称
    if not video_file_path.exists() and normalized_video_name != decoded_video_name:
        video_file_path = Path(video_w_audio_path) / f"{decoded_video_name}.mp4"
    
    if not video_file_path.exists():
        # (调试日志)
        if Path(video_w_audio_path).exists():
            files_in_dir = os.listdir(video_w_audio_path)
            print(f"📁 目录 {video_w_audio_path} 中的文件: {files_in_dir}")
            print(f"⚠️ 请求的视频名称: {video_name} (解码后: {decoded_video_name}, 规范化: {normalized_video_name})")
        else:
            print(f"📁 目录不存在: {video_w_audio_path}")
            
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Video file not found: {normalized_video_name}.mp4 (原始请求: {video_name})"
        )
    print(f"🔍 找到视频文件: {video_file_path}")
    return content_helper.stream_video_response(
            file_path=video_file_path,
            range_header=range,
            display_filename=f"{normalized_video_name}.mp4"
        )

@router.get("/preview-w-video/{job_id}", response_class=FileResponse)
async def get_completed_video(
    job_id: uuid.UUID,
    range: Optional[str] = Header(None),
    db: AsyncSession = Depends(get_db)
    # 移除了 token 认证
):
    """
    (异步) 获取已完成的、带音频的最终视频文件。
    """
    job = await get_job_or_404(job_id, db, check_status="completed")

    video_file_path = None
    video_filename = "Full.mp4" # 默认
    for file_info in job.result_files:
        if file_info.get("type") == "video":
            video_file_path = file_info.get("path")
            video_filename = file_info.get("name", video_filename)
            break

    if not video_file_path or not Path(video_file_path).exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Completed video file not found for job {job_id}"
        )
        
    return content_helper.stream_video_response(
            file_path=video_file_path,
            range_header=range,
            display_filename="Full.mp4"
        )

@router.post("/save-code/{job_id}", response_model=BaseResponse)
async def save_manim_code(
    job_id: uuid.UUID,
    request: SaveCodeRequest, # 使用 Pydantic 模型
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
):
    """
    (异步) 保存编辑后的 Manim 代码。这是一个同步文件 I/O，在 to_thread 中运行。
    """

    job = await get_job_or_404(job_id, db)
    try:
        # save_manim_code_entry 是在 generation_tasks.py 中的同步函数
        success = await asyncio.to_thread(
            save_manim_code_entry, 
            job,
            request.segment_id, 
            request.code_content
        )
        if not success:
            raise HTTPException(status_code=500, detail="Failed to save code (Job not found or not in preview state)")
        return BaseResponse(message="代码保存成功", data={"segment_id": request.segment_id})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"保存代码失败: {str(e)}")


@router.post("/save-script/{job_id}", response_model=BaseResponse)
async def save_script_content(
    job_id: uuid.UUID,
    request: SaveScriptRequest, # 使用 Pydantic 模型
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
):
    """
    (异步) 保存编辑后的“打断点”讲稿。
    """
    job = await get_job_or_404(job_id, db)
    try:
        success = await asyncio.to_thread(
            save_script_content_entry, 
            job,
            request.segment_id, 
            request.script_content
        )
        if not success:
            raise HTTPException(status_code=500, detail="Failed to save script (Job not found or not in preview state)")
        return BaseResponse(message="讲稿保存成功", data={"segment_id": request.segment_id})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"保存讲稿失败: {str(e)}")


@router.post("/continue-generation/{job_id}", response_model=BaseResponse)
async def continue_generation(
    job_id: uuid.UUID,
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
    redis: ArqRedis = Depends(get_redis)
):
    """
    在用户预览完成后，触发 ARQ 任务以继续生成流程。
    """
    job = await get_job_or_404(job_id, db)

    # 允许从 "awaiting_preview_decision" 或 "running" (如果重新生成过) 状态继续
    if job.status not in ("awaiting_preview_decision", "running"):
         raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Job {job_id} is not in a state to be continued (current: {job.status})"
        )

    # 更新状态并入队
    job.status = "continuation_queued"
    job.message = "任务已入队，准备合并最终视频"
    db.add(job)
    await db.commit()
    
    # 提交 "continue_generation_task" 任务到 ARQ
    await redis.enqueue_job("continue_generation_task", job)
    
    return BaseResponse(message="继续生成流程已入队", data={"job_id": job.id})


@router.post("/save-original-script/{job_id}", response_model=BaseResponse)
async def save_original_script_content(
    job_id: uuid.UUID,
    request: SaveScriptRequest, # 复用 Pydantic 模型
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
):
    """
    (异步) 保存编辑后的"原始"讲稿。
    """
    job = await get_job_or_404(job_id, db)
    try:
        success = await asyncio.to_thread(
            save_original_script_content_entry, 
            job,
            request.segment_id, 
            request.script_content
        )
        if not success:
            raise HTTPException(status_code=500, detail="Failed to save original script (Job not found or not in preview state)")
        return BaseResponse(message="原始讲稿保存成功", data={"segment_id": request.segment_id})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"保存原始讲稿失败: {str(e)}")

@router.post("/rollback-segment/{job_id}", response_model=BaseResponse)
async def rollback_segment(
    job_id: uuid.UUID,
    segment_id: str = Form(...),
    code_content: str = Form(...),
    video_file: Optional[UploadFile] = File(None),
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
):
    """
    (异步) 回退片段到备份状态：替换代码文件和视频文件。
    """
    job = await get_job_or_404(job_id, db)
    try:
        # 如果有视频文件，先保存到临时文件
        video_file_path = None
        if video_file:
            # 创建临时文件
            import tempfile
            temp_dir = tempfile.gettempdir()
            temp_file_path = os.path.join(temp_dir, f"{segment_id}_rollback_{uuid.uuid4()}.mp4")
            
            # 读取并保存视频文件
            video_content = await video_file.read()
            with open(temp_file_path, 'wb') as f:
                f.write(video_content)
            video_file_path = temp_file_path
        
        # 调用回退函数
        success = await asyncio.to_thread(
            rollback_segment_entry,
            job,
            segment_id,
            code_content,
            video_file_path
        )
        
        # 清理临时文件
        if video_file_path and os.path.exists(video_file_path):
            try:
                os.remove(video_file_path)
            except Exception as e:
                print(f"⚠️ 清理临时文件失败: {e}")
        
        if not success:
            raise HTTPException(status_code=500, detail="回退失败 (Job not found or not in preview state)")
        
        return BaseResponse(
            message="回退成功",
            data={
                "segment_id": segment_id,
                "has_video_rollback": video_file is not None
            }
        )
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"回退失败: {str(e)}")

@router.post("/update-preview-segments/{job_id}", response_model=BaseResponse)
async def update_preview_segments(
    job_id: uuid.UUID,
    request: UpdateSegmentsRequest, # 使用 Pydantic 模型
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
):
    """
    (异步) 处理片段的删除、复制和重排序。
    这是一个重度 I/O (文件复制/删除) 操作，在 to_thread 中运行。
    """
    job = await get_job_or_404(job_id, db) # 确认 job 存在
    try:
        job = await asyncio.to_thread(
            update_preview_segments_entry,
            job,
            request.segments # 传递 segment 字典列表
        )
        flag_modified(job, "preview_data")
        db.add(job)
        await db.commit()
        return BaseResponse(message="Preview segments updated successfully.")
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to update preview segments: {str(e)}")



# --- 重新生成的路由 (重量级 ARQ 任务) ---

@router.post("/regenerate-video-segment/{job_id}", response_model=BaseResponse)
async def regenerate_video_segment(
    job_id: uuid.UUID,
    request: SegmentRequest, # 使用 Pydantic 模型
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
    redis: ArqRedis = Depends(get_redis)
):
    """
    (ARQ 任务) 重新生成指定的视频片段。
    """
    job = await get_job_or_404(job_id, db) # 确认 job 存在
     # 检查余额
    wallet = await tcoin_service.get_wallet(db, uuid.UUID(job.user_id))
    if wallet.balance < COST_PER_REGENERATE:
        return BaseResponse(
            success=False,
            code=403,
            message="用户T币余额不足。"
        )
    # 扣除用户的 TCOIN 费用
    await tcoin_service.debit(
                db=db, 
                user_id=job.user_id, 
                amount=COST_PER_REGENERATE, 
                job_id=job.id,
                notes=f"再生片段 {request.segment_id}"
            )
    
    # 初始化片段状态
    if not job.preview_data:
        job.preview_data = {}
    if "segment_status" not in job.preview_data:
        job.preview_data["segment_status"] = {}
    # 设置片段状态为 "queued"
    job.preview_data["segment_status"][request.segment_id] = "queued"
    flag_modified(job, "preview_data")
    
    db.add(job)
    await db.commit()

    await redis.enqueue_job(
        "regenerate_video_segment_task", # 新 ARQ 任务
        job,
        request.segment_id
    )
    return BaseResponse(
        success=True,
        message=f"视频片段 {request.segment_id} 重新生成任务已入队",
        data={"segment_id": request.segment_id}
    )

@router.post("/regenerate-audio-segment/{job_id}", response_model=BaseResponse)
async def regenerate_audio_segment(
    job_id: uuid.UUID,
    request: SegmentRequest, # 使用 Pydantic 模型
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
    redis: ArqRedis = Depends(get_redis)
):
    """
    (ARQ 任务) 重新生成指定片段的音频。
    """
    job = await get_job_or_404(job_id, db) # 确认 job 存在
    
    # 初始化片段状态
    if not job.preview_data:
        job.preview_data = {}
    if "segment_status" not in job.preview_data:
        job.preview_data["segment_status"] = {}
    # 设置片段状态为 "queued"
    job.preview_data["segment_status"][request.segment_id] = "queued"
    flag_modified(job, "preview_data")
    db.add(job)
    await db.commit()
    
    await redis.enqueue_job(
        "regenerate_audio_segment_task", # 新 ARQ 任务
        job,
        request.segment_id
    )
    return BaseResponse(
        success=True,
        message=f"音频片段 {request.segment_id} 重新生成任务已入队",
        data={"segment_id": request.segment_id}
    )

@router.post("/reprocess-segment/{job_id}", response_model=BaseResponse)
async def reprocess_segment_complete(
    job_id: uuid.UUID,
    request: SegmentRequest, # 使用 Pydantic 模型
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
    redis: ArqRedis = Depends(get_redis)
):
    """
    (ARQ 任务) 完整重新处理指定的片段。
    """
    job = await get_job_or_404(job_id, db) # 确认 job 存在
    
    # 初始化片段状态
    if not job.preview_data:
        job.preview_data = {}
    if "segment_status" not in job.preview_data:
        job.preview_data["segment_status"] = {}
    # 设置片段状态为 "queued"
    job.preview_data["segment_status"][request.segment_id] = "queued"
    flag_modified(job, "preview_data")
    db.add(job)
    await db.commit()
    
    await redis.enqueue_job(
        "reprocess_segment_complete_task", # 新 ARQ 任务
        job,
        request.segment_id
    )
    return BaseResponse(
        success=True,
        message=f"片段 {request.segment_id} 完整重新处理任务已入队",
        data={"segment_id": request.segment_id}
    )

@router.get("/generate-ppt/{job_id}", response_model=BaseResponse)
async def generate_ppt(
    job_id: uuid.UUID,
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
    redis: ArqRedis = Depends(get_redis)
):
    """
    (ARQ 任务) 为已完成的任务生成 PPT。
    """
    job = await get_job_or_404(job_id, db, check_status="completed") # 必须是已完成的
    
    # 初始化任务状态
    if not job.preview_data:
        job.preview_data = {}
    if "task_status" not in job.preview_data:
        job.preview_data["task_status"] = {}
    # 设置任务状态为 "queued"
    job.preview_data["task_status"]["ppt"] = "queued"
    flag_modified(job, "preview_data")
    db.add(job)
    await db.commit()
    
    await redis.enqueue_job(
        "generate_ppt_task", # 新 ARQ 任务
        job
    )
    return BaseResponse(
        success=True,
        message="PPT 生成任务已入队",
        data={"job_id": job_id}
    )

@router.post("/video/speed/{job_id}", response_model=BaseResponse)
async def change_video_speed(
    job_id: uuid.UUID,
    request: SpeedRequest, # 使用 Pydantic 模型
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
    redis: ArqRedis = Depends(get_redis)
):
    """
    (ARQ 任务) 调整最终视频的速度。
    """
    job = await get_job_or_404(job_id, db, check_status="completed") # 必须是已完成的
    
    # 初始化任务状态
    if not job.preview_data:
        job.preview_data = {}
    if "task_status" not in job.preview_data:
        job.preview_data["task_status"] = {}
    # 设置任务状态为 "queued"
    job.preview_data["task_status"]["speed"] = "queued"
    flag_modified(job, "preview_data")
    db.add(job)
    await db.commit()
    
    await redis.enqueue_job(
        "change_video_speed_task", # 新 ARQ 任务
        job,
        request.speed
    )
    return BaseResponse(
        success=True,
        message=f"视频调速 {request.speed}x 任务已入队",
        data={"speed": request.speed}
    )

# --- 文件管理路由 ---

@router.post("/upload", response_model=BaseResponse, status_code=status.HTTP_201_CREATED)
async def upload_file(
    file: UploadFile = File(...),
    file_type: str = Form(...),
    # user_id: uuid.UUID = Form(...), # TODO: 应该从 token 中获取
    token: str = Depends(oauth2_scheme), 
    db: AsyncSession = Depends(get_db)
) -> BaseResponse:
    """
    (异步) 上传一个文件并将其元数据记录在 UploadedFile 表中。
    """
    # TODO: 从 token 中解码 user_id
    user_id_from_token = uuid.uuid4() # 临时的
    
    try:
        # 1. 确定存储目录
        upload_dir = settings.UPLOADS_DIR / file_type
        upload_dir.mkdir(parents=True, exist_ok=True)
        
        # 2. 生成唯一文件名
        file_id = uuid.uuid4()
        file_extension = Path(file.filename).suffix
        storage_filename = f"{file_id}{file_extension}"
        file_path = upload_dir / storage_filename

        # 3. 异步读取并异步写入文件 (在线程池中)
        file_content = await file.read()
        await asyncio.to_thread(file_path.write_bytes, file_content)
        file_size = file_path.stat().st_size

        # 4. 在数据库中创建记录
        new_file = UploadedFile(
            id=file_id,
            user_id=user_id_from_token, 
            file_type=file_type,
            original_filename=file.filename,
            storage_path=str(file_path.resolve()), # 存储绝对路径
            file_size=file_size
        )
        db.add(new_file)
        await db.commit()
        await db.refresh(new_file)
        
        return BaseResponse(
            success=True,
            data=FileUploadResponse.from_orm(new_file) # 从 ORM 模型创建 Pydantic 响应
        )
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to upload file: {str(e)}"
        )


@router.post("/upload-image/{job_id}", response_model=BaseResponse)
async def upload_image_for_job(
    job_id: uuid.UUID,
    image: UploadFile = File(...),
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
):
    """
    (异步) 为特定任务上传图片素材 (例如，在 Manim 中使用)。
    """
    job = await get_job_or_404(job_id, db)
    
    # 构建特定于任务的素材存储路径
    assets_dir = Path(settings.GENERATED_CONTENT_DIR) / str(job.user_id) / str(job.id) / "manim_assets"
    assets_dir.mkdir(parents=True, exist_ok=True)

    # 3. 生成唯一文件名
    file_extension = Path(image.filename).suffix
    unique_filename = f"{uuid.uuid4()}{file_extension}"
    file_path = assets_dir / unique_filename

    # 4. 异步保存文件
    try:
        file_content = await image.read()
        await asyncio.to_thread(file_path.write_bytes, file_content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save image: {str(e)}")

    print(f"🖼️ 图片已上传并保存至: {file_path}")

    return BaseResponse(
        success=True,
        message="图片上传成功",
        data={
            "image_path": str(file_path.resolve()), # 返回绝对路径
            "file_name": unique_filename  # 返回文件名，供 Manim 代码引用
        }
    )
@router.get("/preview-data/{job_id}", response_model=BaseResponse)
async def get_preview_data(
    job_id: uuid.UUID,
    script_version: str = "refined", # "original" 或 "refined"
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
):
    """
    (异步) 获取预览所需的所有片段数据（视频URL、代码、讲稿）。
    这是一个 I/O 密集型操作（读取多个文件），因此在 to_thread 中运行。
    """
    job = await get_job_or_404(job_id, db)
    
    # 允许在重新生成过程中查询状态
    if job.status not in ("awaiting_preview_decision", "continuation_queued", "continuing", "running"):
         raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Job is not in a previewable state (current: {job.status})"
        )

    try:
        # get_preview_data_entry 是一个同步函数，它会读取大量文件
        preview_data = await asyncio.to_thread(
            get_preview_data_entry, 
            job, # 传递完整的 job 对象
            script_version
        )
        
        # 添加片段状态信息到返回数据中
        if job.preview_data:
            if "segment_status" in job.preview_data:
                preview_data["segment_status"] = job.preview_data["segment_status"]
            else:
                # 如果没有片段状态信息，初始化一个空的状态字典
                preview_data["segment_status"] = {}
            
            # 添加任务状态信息到返回数据中
            if "task_status" in job.preview_data:
                preview_data["task_status"] = job.preview_data["task_status"]
            else:
                # 如果没有任务状态信息，初始化一个空的状态字典
                preview_data["task_status"] = {}
        else:
            preview_data["segment_status"] = {}
            preview_data["task_status"] = {}
        
        return BaseResponse(
            success=True,
            message="预览数据获取成功",
            data=preview_data
        )
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(
            status_code=500,
            detail=f"获取预览数据失败: {str(e)}"
        )
    
@router.get("/task-status/{job_id}", response_model=BaseResponse)
async def get_segment_status(
    job_id: uuid.UUID,
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
):
    job = await get_job_or_404(job_id, db)
    
    task_status = {}
    segment_status = {}

    if job.preview_data:
        task_status = job.preview_data.get("task_status", {})
        segment_status = job.preview_data.get("segment_status", {})
    
    return BaseResponse(
        success=True,
        message="Job 内部状态获取成功",
        data={
            "task_status": task_status,
            "segment_status": segment_status,
            "job_status": job.status # 也可以顺便返回主任务状态
        }
    )


@router.get("/course-hub/view/{job_id}")
def get_preview_video(
    request: Request,  # 1. 导入 Request 对象来获取请求头
    job_id: str,
    range: Optional[str] = Header(None)  # 2. 捕获 'Range' 请求头
):
    """
    获取预览视频文件 (已支持 HTTP Range Requests 来允许进度条拖拽).
    """
    try:
        video_file_path = f"course_hub/{job_id}.mp4"
        
        print(f"🎬 请求视频文件: {video_file_path}")

        if not os.path.exists(video_file_path):
            raise HTTPException(
                status_code=404,
                detail=f"视频文件不存在: {video_file_path}"
            )
        
        # 获取文件大小，并处理文件可能正在写入的情况
        # 如果文件正在写入，文件大小可能会变化，需要多次检查以确保稳定性
        file_size = os.path.getsize(video_file_path)
        # 等待文件稳定（如果文件大小在短时间内变化，说明可能正在写入）
        import time
        max_wait_time = 2.0  # 最多等待2秒
        wait_interval = 0.1  # 每次检查间隔0.1秒
        waited_time = 0.0
        while waited_time < max_wait_time:
            new_size = os.path.getsize(video_file_path)
            if new_size == file_size:
                # 文件大小稳定，可以继续
                break
            file_size = new_size
            time.sleep(wait_interval)
            waited_time += wait_interval
        
        media_type, _ = mimetypes.guess_type(video_file_path)
        if media_type is None:
            media_type = "video/mp4"

        # 准备基础响应头
        headers = {
            "Content-Type": media_type,
            "Accept-Ranges": "bytes", # 关键：告诉浏览器我支持范围请求
            "Content-Length": str(file_size),
            "Content-Disposition": f"inline; filename=\"intro.mp4\"",
        }

        # 3. 检查 'Range' 头是否存在
        if range is None:
            # --- 如果没有 Range 头：返回完整的视频流 (Status 200) ---
            def full_file_iter(file_path: str, chunk_size: int = 1024 * 64):
                with open(file_path, "rb") as file:
                    while True:
                        chunk = file.read(chunk_size)
                        if not chunk:
                            break
                        yield chunk
            
            print(f"✅ (200 OK) 返回完整视频文件 (Stream): {video_file_path}")
            return StreamingResponse(
                full_file_iter(video_file_path),
                headers=headers,
                status_code=200
            )

        # --- 4. 如果有 Range 头：处理范围请求 (Status 206) ---
        print(f"⚙️ 处理 Range header: {range}")
        
        # 解析 Range (e.g., "bytes=0-" or "bytes=1024-2048")
        try:
            range_str = range.strip().split("=")[1]
            start_str, end_str = range_str.split("-")
            
            start = int(start_str)
            # 如果 end 未指定，使用文件大小-1
            end = int(end_str) if end_str else file_size - 1
        except Exception:
            raise HTTPException(status_code=400, detail="无效的 Range header")

        # 处理 Range 请求超出文件大小的情况
        # 如果 start 超出文件大小，说明文件可能被重新生成了（新文件更小）
        # 此时返回从文件开头开始的内容，而不是 416 错误，避免浏览器需要重新请求
        if start >= file_size:
            print(f"⚠️ Range 请求超出文件大小，返回从文件开头开始: start={start}, file_size={file_size}")
            # 返回从文件开头到文件末尾的内容
            start = 0
            end = file_size - 1
        
        # 如果 end 超出文件大小，将其调整为文件末尾
        if end >= file_size:
            print(f"⚠️ Range 请求的 end 超出文件大小，调整为文件末尾: end={end} -> {file_size - 1}")
            end = file_size - 1
        
        # 确保 start <= end
        if start > end:
            print(f"⚠️ Range 请求无效，返回从文件开头开始: start={start} > end={end}")
            start = 0
            end = file_size - 1

        chunk_size = (end - start) + 1
        
        # 更新响应头以反映部分内容
        headers["Content-Length"] = str(chunk_size)
        headers["Content-Range"] = f"bytes {start}-{end}/{file_size}"
        
        print(f"✅ (206 Partial) 返回部分视频文件 (Bytes {start}-{end}): {video_file_path}")
        
        return StreamingResponse(
            content_helper.send_bytes_range_requests(video_file_path, start, end),
            headers=headers,
            status_code=206  # 关键：返回 206 Partial Content
        )

    except Exception as e:
        print(f"❌ 获取预览视频失败: {str(e)}")
        # 隐藏详细的 os 错误，只返回通用消息
        if isinstance(e, FileNotFoundError) or isinstance(e, HTTPException):
             raise e
        raise HTTPException(
            status_code=500,
            detail=f"获取预览视频失败"
        )

@router.post("/modify-manim-code", response_model=BaseResponse)
async def modify_manim_code(
    request: ManimModifyRequest,
    token: str = Depends(oauth2_scheme),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    redis: ArqRedis = Depends(get_redis)
):
    """
    接收Manim代码和用户指令，调用LLM返回修改后的代码
    """

    job = await get_job_or_404(request.job_id, db) # 必须是已完成的
    
    # 初始化片段状态
    if not job.preview_data:
        job.preview_data = {}
    if "task_status" not in job.preview_data:
        job.preview_data["task_status"] = {}
    # 设置片段状态为 "queued"
    job.preview_data["task_status"][f"llm_modify-{request.segment_id}"] = "queued"
    flag_modified(job, "preview_data")
    db.add(job)
    await db.commit()
    
    await redis.enqueue_job(
        "LLM_modify_manim_code_task",
        job,
        request.segment_id,
        request.original_code,
        request.user_request
    )
    return BaseResponse(
        success=True,
        message=f"片段 {request.segment_id} 完整重新处理任务已入队",
        data={"segment_id": request.segment_id}
    )

@router.get(
    "/{job_id}/modification/{segment_id}",
    response_model=BaseResponse,
    summary="获取单个片段的修改结果"
)
async def get_modification_result(
    job_id: str,
    segment_id: str,
    db: AsyncSession = Depends(get_db),
    token: str = Depends(oauth2_scheme),
    current_user: User = Depends(get_current_user)
):
    """
    根据 Job ID 和 Segment ID 检索由 ARQ 任务生成的修改结果 JSON 文件。
    
    - 验证用户是否拥有该 Job。
    - 检查结果文件是否存在。
    """
    job = await get_job_or_404(job_id, db)
    
    if str(job.user_id) != str(current_user.id) and not current_user.is_superuser:
         raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to access this job"
        )

    file_path = f"generated_content/{job.user_id}/{job_id}/modifications.json"
    
    if not os.path.exists(file_path):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Modification result not found. The task may still be pending or failed."
        )
        
    try:
        async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
            content = await f.read()
        
        all_data = json.loads(content)
        segment_data = all_data.get(segment_id)
        print(segment_data)
        
        if not segment_data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Modification result for this specific segment_id not found."
            )
        raw_code = segment_data["modified_code"]
        clean_code = re.sub(r'^```(?:json)?\s*|\s*```$', '', raw_code, flags=re.IGNORECASE | re.MULTILINE).strip()
        llm_response = json.loads(clean_code)
        
        # 验证返回的数据结构是否符合预期
        if "new_code" not in llm_response or "explanation" not in llm_response:
            raise HTTPException(status_code=500, detail="LLM response format error")

        return BaseResponse(
            success=True,
            message="Modification result retrieved successfully",
            data=llm_response
        )
        
    except json.JSONDecodeError:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to decode result file. File may be corrupt."
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while reading the result file: {e}"
        )
    

@router.get("/lecture_notes")
async def api_get_lecture_notes(
    job_id: str,
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db), # 注入数据库
    current_user: User = Depends(get_current_user),
    redis: ArqRedis = Depends(get_redis) # 注入 Redis
):
    """
    获取讲义内容接口 (GET)
    用于前端 Modal 显示讲义内容
    """
    
    job = await get_job_or_404(job_id, db)
    
    if not job:
        raise HTTPException(status_code=404, detail="任务不存在")
        
    # 优先尝试读取文件，因为文件内容可能是最新的（尽管 confirm 也会更新 DB）
    # 或者如果 confirm 还没调，文件里是初始内容
    md_path = job.settings.get('notes_path')
    content = ""
    
    if md_path and os.path.exists(md_path):
        try:
            with open(md_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            return BaseResponse(code=500, message=f"读取讲义文件失败：{e}")
        
        return BaseResponse(data={"job_id": job_id, "content": content})
    return BaseResponse(code=404, message="讲义文件不存在")

@router.put("/jobs/{job_id}", response_model=BaseResponse)
async def update_job_status(
    job_id: str,
    item: JobStatusUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    job = await db.get(GenerationJob, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    # 3. 从模型中获取数据
    job.status = item.status 
        
    db.add(job)
    await db.commit()
    await db.refresh(job)
    return BaseResponse(data=job)

@router.get("/image-preview")
async def image_preview(path: str):
    """
    图片预览接口：接收绝对路径，返回图片文件。
    已增强兼容性：处理 URL 编码问题，并放宽 MIME 类型检查。
    """
    if not path:
        raise HTTPException(status_code=400, detail="缺少图片路径")

    print(f"🖼️ [Image Preview Request] Raw Path: {path}")

    # FastAPI会自动解码query参数，但为了兼容性，我们尝试多种方式
    file_path = None
    
    # 1. 尝试直接使用路径（FastAPI已自动解码）
    test_path = Path(path)
    if test_path.exists() and test_path.is_file():
        file_path = test_path.resolve()
        print(f"✅ [Image Preview] Found with direct path: {file_path}")
    else:
        # 2. 如果不存在，尝试URL解码（防止某些情况下仍有编码）
        decoded_path = urllib.parse.unquote(path)
        test_path = Path(decoded_path)
        if test_path.exists() and test_path.is_file():
            file_path = test_path.resolve()
            print(f"✅ [Image Preview] Found with decoded path: {file_path}")
        else:
            # 3. 尝试多次解码（处理双重编码的情况）
            double_decoded = urllib.parse.unquote(decoded_path)
            test_path = Path(double_decoded)
            if test_path.exists() and test_path.is_file():
                file_path = test_path.resolve()
                print(f"✅ [Image Preview] Found with double-decoded path: {file_path}")

    # 4. 最终检查文件是否存在
    if not file_path or not file_path.exists() or not file_path.is_file():
        print(f"❌ [Image Preview Error] File Not Found. Tried paths:")
        print(f"   - Original: {path}")
        print(f"   - Decoded: {urllib.parse.unquote(path)}")
        print(f"   - Double-decoded: {urllib.parse.unquote(urllib.parse.unquote(path))}")
        raise HTTPException(status_code=404, detail=f"图片不存在: {path}")

    # 4. 猜测 MIME 类型，如果猜不到，则根据后缀名手动指定，或者使用通用流类型
    mime_type, _ = mimetypes.guess_type(str(file_path))
    
    if not mime_type:
        suffix = file_path.suffix.lower()
        if suffix in ['.jpg', '.jpeg']:
            mime_type = "image/jpeg"
        elif suffix == '.png':
            mime_type = "image/png"
        elif suffix == '.svg':
            mime_type = "image/svg+xml"
        elif suffix == '.gif':
            mime_type = "image/gif"
        else:
            # 如果实在识别不出，使用 octet-stream 保证文件能传过去，浏览器通常能自动识别内容
            mime_type = "application/octet-stream"
            print(f"⚠️ [Image Preview] MIME type unknown, using fallback: {mime_type}")

    return FileResponse(
        path=str(file_path),
        media_type=mime_type,
        filename=file_path.name,
    )


# ---------- Pagination confirm (awaiting_pagination_review) ----------

def _split_full_by_h2(full_text: str) -> List[str]:
    """
    按二级标题 (##) 切分合并后的 full_paginated 内容。
    返回每个章节文本列表，保留标题行。
    """
    h2_pattern = re.compile(r'^\s{0,3}##\s+.+$', re.MULTILINE)
    lines = full_text.splitlines()

    sections: List[str] = []
    current: List[str] = []

    for line in lines:
        if h2_pattern.match(line):
            if current:
                sections.append("\n".join(current).strip() + "\n")
            current = [line]
        else:
            current.append(line)

    if current:
        sections.append("\n".join(current).strip() + "\n")

    # 如果没有任何 H2，但有内容，则整篇作为一节
    if not sections and full_text.strip():
        sections.append(full_text.strip() + "\n")

    return sections


def _regenerate_paginated_files_from_full(full_text: str, target_dir: str) -> list[str]:
    """
    将 full_paginated 文本按 H2 重新切分，生成 1_paginated.md, 2_paginated.md...
    """
    os.makedirs(target_dir, exist_ok=True)
    sections = _split_full_by_h2(full_text)
    if not sections:
        raise ValueError("full_paginated 内容为空或未找到可切分的章节。")

    created_files = []
    for idx, section in enumerate(sections, start=1):
        fname = f"{idx}_paginated.md"
        fpath = os.path.join(target_dir, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            f.write(section)
        created_files.append(fname)
    # 拆分完成后删除 full_paginated，避免后续再被 MarkdownSplitter 误切出 full_1.md
    full_path = os.path.join(target_dir, "full_paginated.md")
    try:
        if os.path.exists(full_path):
            os.remove(full_path)
    except Exception:
        pass
    return created_files


@router.post("/pagination-confirm", response_model=BaseResponse)
async def pagination_confirm(
    payload: PaginationConfirmRequest,
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    分页审阅阶段确认：
      1) 覆写 full_paginated.md
      2) 按 H2 重新生成 *_paginated.md
      3) 更新 preview_data（full_content + 文件列表）
      4) 状态置为 CONFIRMED 继续流水
    """
    job = await get_job_or_404(uuid.UUID(payload.job_id), db, check_status="awaiting_pagination_review")

    preview_data = job.preview_data or {}
    full_path = preview_data.get("pagination_full_path")

    if not full_path:
        raise HTTPException(status_code=400, detail="pagination_full_path 未设置，无法保存。")

    target_dir = os.path.dirname(full_path)

    # 覆写 full_paginated.md
    try:
        os.makedirs(target_dir, exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(payload.full_paginated)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"写入 full_paginated 失败: {e}")

    # 重新生成 *_paginated.md
    try:
        new_files = _regenerate_paginated_files_from_full(payload.full_paginated, target_dir)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"重新生成分页文件失败: {e}")

    # 更新 preview_data
    preview_data["pagination_full_content"] = payload.full_paginated
    preview_data["pagination_files"] = new_files
    job.preview_data = preview_data
    flag_modified(job, "preview_data")

    # 状态置为 CONFIRMED，继续流水
    job.status = "CONFIRMED"

    db.add(job)
    await db.commit()
    await db.refresh(job)

    return BaseResponse(
        success=True,
        message="分页确认成功，已更新文件并继续生成",
        data={
            "pagination_files": new_files,
            "full_path": full_path
        }
    )


@router.post("/pagination-save", response_model=BaseResponse)
async def pagination_save(
    payload: PaginationConfirmRequest,
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    仅保存 full_paginated 及其重新切分的 *_paginated.md，不推进流程。
    状态保持 awaiting_pagination_review。
    """
    job = await get_job_or_404(uuid.UUID(payload.job_id), db, check_status="awaiting_pagination_review")

    preview_data = job.preview_data or {}
    full_path = preview_data.get("pagination_full_path")
    if not full_path:
        raise HTTPException(status_code=400, detail="pagination_full_path 未设置，无法保存。")

    target_dir = os.path.dirname(full_path)

    # 覆写 full_paginated.md
    try:
        os.makedirs(target_dir, exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(payload.full_paginated)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"写入 full_paginated 失败: {e}")

    # 重新生成 *_paginated.md
    try:
        new_files = _regenerate_paginated_files_from_full(payload.full_paginated, target_dir)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"重新生成分页文件失败: {e}")

    # 更新 preview_data
    preview_data["pagination_full_content"] = payload.full_paginated
    preview_data["pagination_files"] = new_files
    job.preview_data = preview_data
    flag_modified(job, "preview_data")

    db.add(job)
    await db.commit()
    await db.refresh(job)

    return BaseResponse(
        success=True,
        message="分页内容已保存（未继续流程）",
        data={
            "pagination_files": new_files,
            "full_path": full_path
        }
    )
