"""
Application configuration settings
"""

import os
from typing import List
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings"""
    
    # Basic settings
    APP_NAME: str = "ML Education Platform"
    DEBUG: bool = True
    TESTING: bool = False
    HOST: str = "0.0.0.0"
    PORT: int = 8888
    
    # Security settings
    SECRET_KEY: str = "your-secret-key-here-change-in-production"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days
    ALGORITHM: str = "HS256"
    
    # CORS settings
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",  # React development server
        "http://150.158.152.82",
        "http://teachmaster.cn",
        "http://106.63.100.86:12300",
        "http://www.teachmaster.cn",
        "http://localhost:8888",  # FastAPI server
        "http://localhost:8001",  # FastAPI server on alternate port
        "http://localhost:8611",
        "http://localhost:64588",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8888",
        "http://127.0.0.1:8001",
        "http://127.0.0.1:8611",
        "http://127.0.0.1:64588",
         "*",
    ]
    
    # Database settings
    DATABASE_URL: str = "mysql+aiomysql://tm_user:tm_user@localhost:3306/tm_db"
    
    # Redis settings (for caching and sessions)
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_PORT: int = 6379
    REDIS_HOST: str = "localhost"
    
    # File upload settings
    MAX_UPLOAD_SIZE: int = 10 * 1024 * 1024  # 10MB
    UPLOAD_DIRECTORY: str = "uploads"
    ALLOWED_EXTENSIONS: List[str] = [".txt", ".md", ".pdf", ".docx"]
    
    # ML API settings (for integrating with existing ML tools)
    ML_API_KEY: str = ""
    ML_API_BASE_URL: str = ""

    # Redeem code encryption key
    REDEEM_CODE_ENCRYPTION_KEY: str = os.environ.get(
        "REDEEM_CODE_ENCRYPTION_KEY",
        "dIrnc5S027-WLgfaqv_y41tlhbvq3VKs4XtCFPEHG5I="
    )
    
    class Config:
        env_file = ".env"

    DEFAULT_WAV_PATH: str = "/home/TeachMasterAppV2/backend/uploads/source/TeachMaster_cn.wav"
    DEFAULT_WAV_PROMPT_PATH: str = "/home/TeachMasterAppV2/backend/uploads/source/TeachMaster_cn.txt"

    PYTHON_PATH: str = "/home/EduAgent/miniconda3/envs/cosyvoice/bin/python"

    COSYVOICE_SCRIPT_PATH: str = "/home/EduAgent/services/cosyvoice/run_cosyvoice_dynamic.py"

    GENERATED_CONTENT_DIR: str = "generated_content"
    DEFAULT_BACKGROUND_IMAGE: str = "/home/TeachMasterAppV2/backend/SAI.png"
    DEFAULT_WAV_PATH: str = "/home/TeachMasterAppV2/backend/uploads/source/TeachMaster_cn.wav"
    DEFAULT_WAV_PROMPT_PATH: str = "/home/TeachMasterAppV2/backend/uploads/source/TeachMaster_cn.txt"
    UPLOADS_DIR: str = "uploads"


# Create settings instance
settings = Settings()