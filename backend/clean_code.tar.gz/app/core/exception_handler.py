# app/exception_handler.py

import logging
from fastapi import Request, status
from fastapi.responses import JSONResponse
from app.models.schemas import BaseResponse

# 配置一个 logger 用于记录错误
logger = logging.getLogger(__name__)

async def global_exception_handler(request: Request, exc: Exception):
    """
    一个全局异常处理器，用于捕获所有未处理的异常。
    """
    # 记录详细的错误信息，方便调试
    logger.error(
        f"Unhandled exception for request {request.method} {request.url}: {exc}", 
        exc_info=True  # 这会包括堆栈跟踪信息
    )
    
    # 返回一个标准化的 JSON 错误响应
    # 注意：我们假设你的 BaseResponse 模型可以接受这些参数
    error_content = BaseResponse(
        success=False,
        code=500,
        message="服务器发生了一个未知的内部错误，请联系管理员。",
        data={"error": str(exc)}
    ).model_dump()

    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=error_content
    )