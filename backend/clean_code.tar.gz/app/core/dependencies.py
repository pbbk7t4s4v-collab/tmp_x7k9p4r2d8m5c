from fastapi import Request, HTTPException, status
from arq.connections import ArqRedis
from typing import Optional

async def get_redis(request: Request) -> Optional[ArqRedis]:
    """
    Dependency function to get the ARQ Redis pool from the app state.
    """
    if not hasattr(request.app.state, 'redis') or not request.app.state.redis:
        # This should not happen if startup event is successful
        print("Error: Redis connection pool is not available.")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Redis connection pool is not available."
        )
    return request.app.state.redis
