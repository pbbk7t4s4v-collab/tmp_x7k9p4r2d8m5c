
import os
import shutil
import json
import mimetypes
import subprocess
import logging
from pathlib import Path
from moviepy import VideoFileClip
from typing import Optional, Generator
from fastapi.responses import StreamingResponse
from fastapi import HTTPException
import smtplib
from email.mime.text import MIMEText
import uuid
from app.core.config import settings

SMTP_SERVER = "smtp.qq.com"
SMTP_PORT = 587 # Or 465 for SSL
SMTP_USERNAME = "1687723655@qq.com"
SMTP_PASSWORD = "mtylcmvyfdpvbdcg"
FEEDBACK_RECIPIENT_EMAIL = "TeachMaster2025@outlook.com"
TOKEN_APPLICATION_RECIPIENT_EMAIL = "TeachMaster2025@outlook.com"
VOICE_MAP_PATH = Path("/home/TeachMasterAppV2/backend/minimax_voice_map.json")

def _load_voice_map() -> dict:
    """从 JSON 文件读取声线映射，不存在则返回空字典。"""
    if VOICE_MAP_PATH.exists():
        try:
            return json.loads(VOICE_MAP_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save_voice_map(mapping: dict) -> None:
    """将声线映射写回 JSON 文件。"""
    VOICE_MAP_PATH.write_text(
        json.dumps(mapping, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )


def get_or_create_voice_id_for_teacher(
    user_id: str,
    professor_name: str,
    is_default_audio: bool = False,
) -> tuple[str, bool]:
    """
    返回 (voice_id, existed)
    
    existed = True：表示 JSON 里已有记录，本次应复用声线。
    existed = False：表示第一次遇到，应执行 clone，并写入 JSON。

    is_default_audio = True 时：
        全系统共用同一条默认音频声线，key = "__GLOBAL_DEFAULT_VOICE__"
    """
    mapping = _load_voice_map()

    if is_default_audio:
        key = "__GLOBAL_DEFAULT_VOICE__"
    else:
        user_id = str(user_id or "").strip()
        professor_name = (professor_name or "").strip() or "UNKNOWN_TEACHER"
        key = f"{user_id}::{professor_name}"

    if key in mapping:
        return mapping[key], True

    voice_id = "v_" + uuid.uuid4().hex
    mapping[key] = voice_id
    _save_voice_map(mapping)
    return voice_id, False

class ContentHelper:
    def __init__(self):
        CONFIG_PATH = str("config.json")
        from manim_breakpoint_inserter import ManimBreakpointInserter

        from manim_auto_wait_generator import ManimAutoWaitGenerator
        self.manimAutoWaitGenerator = ManimAutoWaitGenerator()
        self.manimBreakpointInserter = ManimBreakpointInserter(config_path=CONFIG_PATH)

        pass

    def setManimAutoWaitGenerator(self, lang: str):
        from manim_auto_wait_generator import ManimAutoWaitGenerator
        from manim_auto_wait_generator_en import ManimAutoWaitGenerator_en
        if lang == 'zh':
            self.manimAutoWaitGenerator = ManimAutoWaitGenerator()
        elif lang == 'en':
            self.manimAutoWaitGenerator = ManimAutoWaitGenerator_en()
        else:
            self.manimAutoWaitGenerator = ManimAutoWaitGenerator()

    def run_subprocess_command(self, command: list, logger: logging.Logger, description: str = "", verbose: bool = True) -> bool:
        """
        运行子进程命令，提供更好的错误处理和日志
        
        参数:
            command: 命令列表
            logger: 用于记录日志的logger实例
            description: 命令描述
            verbose: 是否输出详细信息
        
        返回:
            是否成功执行
        """
        log_prefix = f"[{description}]" if description else "[Subprocess]"
        
        # 记录将要执行的命令
        logger.info(json.dumps({
            "event": "subprocess_start",
            "description": description,
            "command": ' '.join(command)
        }))

        if verbose and description:
            print(f"正在执行: {description}")
        
        try:
            result = subprocess.run(command, capture_output=True, text=True, check=False, encoding='utf-8')
            
            log_output = {
                "event": "subprocess_result",
                "description": description,
                "command": ' '.join(command),
                "return_code": result.returncode,
                "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip()
            }

            if result.returncode != 0:
                if verbose:
                    print(f"命令执行失败: {description}")
                    print(f"返回码: {result.returncode}")
                    if result.stdout: print(f"标准输出: {result.stdout}")
                    if result.stderr: print(f"标准错误: {result.stderr}")
                
                logger.error(json.dumps(log_output, ensure_ascii=False))
                return False
            
            if verbose and result.stdout:
                print(f"命令输出: {result.stdout}")
                
            logger.info(json.dumps(log_output, ensure_ascii=False))
            return True
            
        except Exception as e:
            if verbose:
                print(f"执行命令时发生异常: {description}")
                print(f"错误信息: {str(e)}")
            
            # 使用 logger.exception 记录异常信息（包含堆栈追踪）
            logger.exception(json.dumps({
                "event": "subprocess_exception",
                "description": description,
                "command": ' '.join(command),
                "error": str(e)
            }))
            return False

    def _regenerate_single_speech(self, segment_id: str, script_file_path: str, speech_audio_path: str, settings: dict, logger=logging.Logger) -> bool:
        """为单个片段重新生成语音"""
        try:
            # 创建临时目录用于单个音频生成
            temp_input_dir = os.path.join(os.path.dirname(speech_audio_path), f"temp_input_{segment_id}")
            temp_output_dir = os.path.join(os.path.dirname(speech_audio_path), f"temp_output_{segment_id}")
            
            try:
                # 创建临时目录
                os.makedirs(temp_input_dir, exist_ok=True)
                os.makedirs(temp_output_dir, exist_ok=True)
                
                # 复制讲稿文件到临时输入目录
                temp_script_file = os.path.join(temp_input_dir, f"{segment_id}.txt")
                shutil.copy2(script_file_path, temp_script_file)

                # 读取课程原来的 voice_id（整堂课首次生成语音时已经写入）
                voice_id_file = os.path.join(speech_audio_path, "voice_id.txt")
                if not os.path.exists(voice_id_file):
                    print(f"❌ 未找到 voice_id.txt，无法复用原有声线: {voice_id_file}")
                    return False

                with open(voice_id_file, "r", encoding="utf-8") as f:
                    user_voice_id = f.read().strip()

                if not user_voice_id:
                    print(f"❌ voice_id.txt 内容为空，无法复用原有声线: {voice_id_file}")
                    return False

                # 重生成时只复用已有声线，不再克隆，也不再依赖 reference_audio / reference_text
                use_existing_flag = "--use_existing_voice"

                minimax_cmd = (
                    f"source /home/EduAgent/miniconda3/etc/profile.d/conda.sh && "
                    f"conda activate minimax_env && "
                    f"python /home/TeachMasterAppV2/backend/batch_minimax_tts.py "
                    f"--input_dir {temp_input_dir} "
                    f"--output_dir {temp_output_dir} "
                    f"--voice_id {user_voice_id} "
                    f"--model speech-02-hd "
                    f"{use_existing_flag}"
                )
                minimax_command = [
                    "/bin/bash",
                    "-c",
                    minimax_cmd,
                ]
                success = self.run_subprocess_command(
                    command=minimax_command,
                    description=f"生成{segment_id}语音",
                    logger=logger,
                )

                if not success:
                    print(f"❌ 音频生成命令执行失败")
                    return False

                # 查找生成的音频文件
                generated_audio_files = [
                    f for f in os.listdir(temp_output_dir) if f.endswith(".wav")
                ]
                if not generated_audio_files:
                    print(f"❌ 未找到生成的音频文件")
                    return False

                # 移动新音频文件到目标位置
                target_audio_path = os.path.join(
                    speech_audio_path, f"{segment_id}.wav"
                )
                source_audio_path = os.path.join(
                    temp_output_dir, generated_audio_files[0]
                )

                # 备份原音频文件
                if os.path.exists(target_audio_path):
                    backup_path = target_audio_path + ".backup"
                    shutil.copy2(target_audio_path, backup_path)
                    print(f"💾 备份原音频: {backup_path}")

                # 复制新音频文件
                shutil.copy2(source_audio_path, target_audio_path)
                print(f"✅ 新音频已复制到目标位置: {target_audio_path}")

                return True

            finally:
                # 清理临时目录
                if os.path.exists(temp_input_dir):
                    shutil.rmtree(temp_input_dir)
                if os.path.exists(temp_output_dir):
                    shutil.rmtree(temp_output_dir)

        except Exception as e:
            print(f"❌ 重新生成单个语音失败: {e}")
            return False
    def _reinsert_breakpoints_single(self, segment_id: str, original_code_file_path: str, script_file_path: str, refined_output_path: str, logger=logging.Logger) -> bool:
        """为单个片段重新插入断点"""
        try:
            # 确保输出目录存在
            os.makedirs(refined_output_path, exist_ok=True)
            refined_code_dir = os.path.join(refined_output_path, "Code")
            refined_speech_dir = os.path.join(refined_output_path, "Speech")
            os.makedirs(refined_code_dir, exist_ok=True)
            os.makedirs(refined_speech_dir, exist_ok=True)
            
            # 创建临时目录结构用于断点插入器
            temp_code_dir = os.path.join(refined_output_path, f"temp_code_{segment_id}")
            temp_speech_dir = os.path.join(refined_output_path, f"temp_speech_{segment_id}")
            
            try:
                os.makedirs(temp_code_dir, exist_ok=True)
                os.makedirs(temp_speech_dir, exist_ok=True)
                
                # 复制单个文件到临时目录
                shutil.copy2(original_code_file_path, os.path.join(temp_code_dir, f"{segment_id}.py"))
                shutil.copy2(script_file_path, os.path.join(temp_speech_dir, f"{segment_id}.txt"))


                # 使用断点插入器处理单个片段
                if self.manimBreakpointInserter:
                    temp_output_dir = os.path.join(refined_output_path, f"temp_output_{segment_id}")
                    os.makedirs(temp_output_dir, exist_ok=True)
                    
                    self.manimBreakpointInserter.pipeline(temp_code_dir, temp_speech_dir, temp_output_dir)
                    
                    # 复制处理后的文件到最终位置
                    temp_refined_code_dir = os.path.join(temp_output_dir, "Code")
                    temp_refined_speech_dir = os.path.join(temp_output_dir, "Speech")
                    
                    if os.path.exists(os.path.join(temp_refined_code_dir, f"{segment_id}.py")):
                        shutil.copy2(os.path.join(temp_refined_code_dir, f"{segment_id}.py"), 
                                   os.path.join(refined_code_dir, f"{segment_id}.py"))
                    
                    if os.path.exists(os.path.join(temp_refined_speech_dir, f"{segment_id}.txt")):
                        shutil.copy2(os.path.join(temp_refined_speech_dir, f"{segment_id}.txt"), 
                                   os.path.join(refined_speech_dir, f"{segment_id}.txt"))
                    
                    # 清理临时输出
                    if os.path.exists(temp_output_dir):
                        shutil.rmtree(temp_output_dir)
                    
                    print(f"✅ 断点插入完成: {segment_id}")
                    return True
                else:
                    print(f"❌ 断点插入器不可用")
                    return False
                    
            finally:
                # 清理临时目录
                if os.path.exists(temp_code_dir):
                    shutil.rmtree(temp_code_dir)
                if os.path.exists(temp_speech_dir):
                    shutil.rmtree(temp_speech_dir)
                    
        except Exception as e:
            print(f"❌ 重新插入断点失败: {e}")
            return False

    def _regenerate_wait_time_single(self, segment_id: str, speech_audio_path: str, refined_output_path: str, final_output_path: str, logger=logging.Logger) -> bool:
        """为单个片段重新生成等待时间"""
        try:
            # 确保输出目录存在
            os.makedirs(final_output_path, exist_ok=True)
            
            # 获取语音时间文件
            speech_time_file_path = os.path.join(speech_audio_path, "speech.txt")
            if not os.path.exists(speech_time_file_path):
                print(f"❌ 语音时间文件不存在: {speech_time_file_path}")
                return False
            
            refined_code_dir = os.path.join(refined_output_path, "Code")
            refined_speech_dir = os.path.join(refined_output_path, "Speech")
            
            if self.manimAutoWaitGenerator:
                # 调用等待时间生成器处理单个片段
                self.manimAutoWaitGenerator.pipeline(speech_time_file_path, refined_speech_dir, refined_code_dir, final_output_path)
                print(f"✅ 等待时间生成完成: {segment_id}")
                return True
            else:
                print(f"❌ 等待时间生成器不可用")
                # 如果生成器不可用，直接复制refined文件
                refined_file = os.path.join(refined_code_dir, f"{segment_id}.py")
                final_file = os.path.join(final_output_path, f"{segment_id}.py")
                if os.path.exists(refined_file):
                    shutil.copy2(refined_file, final_file)
                    return True
                return False
                
        except Exception as e:
            print(f"❌ 重新生成等待时间失败: {e}")
            return False
        
    def is_color(self, value: str) -> bool:
        return value.startswith("#") or value.isupper()
    
    def build_background_code(self, bg_input: str, image_filename: str = None) -> str:
        if self.is_color(bg_input):
            if bg_input.startswith("#"):
                return f'self.camera.background_color = Color("{bg_input}")  # 自定义颜色\n'
            else:
                return f'self.camera.background_color = {bg_input}  # 内置颜色\n'
        else:
            img_name = image_filename if image_filename else bg_input
            
            if not os.path.isabs(img_name):
                # 尝试多个可能的位置
                backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                possible_img_paths = [
                    os.path.join(backend_dir, img_name),  # backend/目录
                    os.path.join(os.path.dirname(backend_dir), img_name),  # 项目根目录
                    img_name  # 如果都不存在，保持原名
                ]
                    
                for possible_path in possible_img_paths:
                    if os.path.exists(possible_path):
                        img_name = possible_path
                        break
                else:
                    print(f"⚠️ 找不到背景图片，尝试的路径: {possible_img_paths}")
                    print(f"⚠️ 使用原始路径: {img_name}")
            return (
                "###BACKGROUND###\n"
                f'bg = ImageMobject("{img_name}")\n'
                f'bg.set_z_index(-100)\n'
                f'bg.scale(max(config.frame_width  / bg.width, config.frame_height / bg.height))\n'
                f'bg.move_to(ORIGIN)\n'
                f'self.add(bg)\n'
                "###BACKGROUND###\n"
            )
    def copy_image_to_target_dir(self, image_path: str, target_dir: str) -> str:
        """将图片文件拷贝到目标目录中"""
        if not os.path.exists(image_path):
            print(f"警告：图片文件不存在: {image_path}")
            return os.path.basename(image_path)
        
        image_filename = os.path.basename(image_path)
        target_path = os.path.join(target_dir, image_filename)
        
        try:
            if os.path.exists(target_path):
                if os.path.getsize(image_path) == os.path.getsize(target_path):
                    print(f"图片已存在，跳过拷贝: {image_filename}")
                    return image_filename
            
            shutil.copy2(image_path, target_path)
            print(f"图片拷贝成功: {image_path} -> {target_path}")
            return image_filename
        
        except Exception as e:
            print(f"拷贝图片失败: {str(e)}")
            return os.path.basename(image_path)
        

    def _add_background_single(self, code_file_path: str, background_image: str, logger=logging.Logger):
        """为单个代码文件添加背景"""
        try:
            # 确保代码文件存在
            if not os.path.exists(code_file_path):
                print(f"❌ 代码文件不存在: {code_file_path}")
                return
                
            # 复制背景图片到代码文件目录（如果需要）
            code_dir = os.path.dirname(code_file_path)
            image_filename = None
            if not self.is_color(background_image):
                image_filename = self.copy_image_to_target_dir(background_image, code_dir)
            
            # 生成背景代码
            bg_code = self.build_background_code(background_image, image_filename)
            
            # 插入背景代码
            self.insert_background_code(code_file_path, bg_code)
            print(f"✅ 背景添加完成: {os.path.basename(code_file_path)}")
            
        except Exception as e:
            print(f"❌ 添加背景失败: {e}")
    def _fix_background_image_paths_in_code_file(self, code_file_path: str):
        """
        修复代码文件中的背景图片路径，确保使用绝对路径
        """
        try:
            print(f"🔧 修复背景图片路径: {code_file_path}")
            
            # 读取代码文件
            with open(code_file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 查找ImageMobject调用中的相对路径
            import re
            pattern = r'ImageMobject\("([^"]+)"\)'
            matches = re.findall(pattern, content)
            
            backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            modified = False
            
            for image_path in matches:
                # 如果是相对路径，尝试转换为绝对路径
                if not os.path.isabs(image_path):
                    print(f"   发现相对路径: {image_path}")
                    
                    # 尝试多个可能的位置
                    possible_paths = [
                        os.path.join(backend_dir, image_path),  # backend/目录
                        os.path.join(os.path.dirname(backend_dir), image_path),  # 项目根目录
                        os.path.join(os.path.dirname(code_file_path), image_path),  # 代码文件同目录
                    ]
                    
                    found_path = None
                    for possible_path in possible_paths:
                        if os.path.exists(possible_path):
                            found_path = possible_path
                            print(f"   ✅ 找到图片: {found_path}")
                            break
                    
                    if found_path:
                        # 替换路径
                        old_pattern = f'ImageMobject("{image_path}")'
                        new_pattern = f'ImageMobject("{found_path}")'
                        content = content.replace(old_pattern, new_pattern)
                        modified = True
                        print(f"   🔄 替换: {image_path} -> {found_path}")
                    else:
                        print(f"   ⚠️ 找不到图片文件: {image_path}")
                        print(f"   尝试的路径: {possible_paths}")
            
            # 如果有修改，写回文件
            if modified:
                with open(code_file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"✅ 背景图片路径修复完成")
            else:
                print(f"📁 无需修复背景图片路径")
                
        except Exception as e:
            print(f"⚠️ 修复背景图片路径时发生错误: {e}")
            # 不中断主流程
            import traceback
            traceback.print_exc()

    def re_render_single_video(self, segment_id: str, code_file_path: str, video_output_path: str, logger=logging.Logger) -> bool:
        """为单个代码文件渲染视频"""
        try:
            # 修复代码文件中的背景图片路径
            self._fix_background_image_paths_in_code_file(code_file_path)
        
            # 清理旧的media目录
            backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            media_dir = os.path.join(backend_dir, "media")
            if os.path.exists(media_dir):
                shutil.rmtree(media_dir)

            temp_code_file_path = Path(__file__).parent.parent.parent / code_file_path
         
            
            # 渲染命令
            render_command = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                "-m", "manim",
                "render",
                temp_code_file_path,
                "-q", "h",
                "--format", "mp4"
            ]
            
            # 执行渲染
            import subprocess
            try:
                result = subprocess.run(
                    render_command, 
                    cwd=backend_dir,
                    capture_output=True, 
                    text=True, 
                    check=False,
                    timeout=600  # 10分钟超时
                )
                
                if result.returncode != 0:
                    print(f"❌ 渲染失败: {result.stderr}")
                    return False
                
                # 查找生成的视频文件
                expected_media_dir = os.path.join(backend_dir, "media", "videos")
                rendered_video = None
                
                if os.path.exists(expected_media_dir):
                    latest_time = 0
                    for root, dirs, files in os.walk(expected_media_dir):
                        for file in files:
                            if file.endswith('.mp4'):
                                file_path = os.path.join(root, file)
                                file_time = os.path.getmtime(file_path)
                                if file_time > latest_time:
                                    latest_time = file_time
                                    rendered_video = file_path
                
                if not rendered_video:
                    print(f"❌ 找不到渲染后的视频文件")
                    return False
                
                # 复制到目标位置
                target_video_path = os.path.join(video_output_path, f"{segment_id}.mp4")
                
                # 备份原视频
                if os.path.exists(target_video_path):
                    backup_path = target_video_path + ".backup"
                    shutil.copy2(target_video_path, backup_path)
                
                shutil.copy2(rendered_video, target_video_path)
                print(f"✅ 视频渲染完成: {segment_id}")
                
                # 清理media目录
                if os.path.exists(media_dir):
                    shutil.rmtree(media_dir)
                
                return True
                
            except subprocess.TimeoutExpired:
                print(f"❌ 渲染超时")
                return False
                
        except Exception as e:
            print(f"❌ 渲染视频失败: {e}")
            return False

    

    def _merge_single_audio_video(self, segment_id: str, speech_audio_path: str, video_output_path: str, logger=logging.Logger) -> bool:
        """为单个片段合并音视频"""
        try:
            audio_file_path = os.path.join(speech_audio_path, f"{segment_id}.wav")
            video_file_path = os.path.join(video_output_path, f"{segment_id}.mp4")
            
            if not os.path.exists(audio_file_path):
                print(f"❌ 音频文件不存在: {audio_file_path}")
                return False
                
            if not os.path.exists(video_file_path):
                print(f"❌ 视频文件不存在: {video_file_path}")
                return False
            
            # 创建临时输出文件
            temp_output_path = video_file_path + ".temp.mp4"
            
            # 音视频合并命令
            backend_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            merge_script_path = os.path.join(backend_dir, "video_audio_merge_single.py")
            
            if not os.path.exists(merge_script_path):
                print(f"❌ 音频合并脚本不存在: {merge_script_path}")
                return False
            
            merge_command = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                merge_script_path,
                audio_file_path,        # 音频文件
                video_file_path,        # 视频文件  
                temp_output_path        # 输出文件
            ]
            
            import subprocess
            try:
                result = subprocess.run(
                    merge_command, 
                    cwd=backend_dir,
                    capture_output=True, 
                    text=True, 
                    check=False
                )
                
                if result.returncode == 0 and os.path.exists(temp_output_path):
                    # 替换原视频文件
                    shutil.move(temp_output_path, video_file_path)
                    print(f"✅ 音视频合并完成: {segment_id}")
                    return True
                else:
                    print(f"❌ 音视频合并失败: {result.stderr}")
                    return False
                    
            except Exception as e:
                print(f"❌ 音视频合并异常: {e}")
                return False
                
        except Exception as e:
            print(f"❌ 合并音视频失败: {e}")
            return False
        

    def _merge_single_audio_video_change(self, segment_id: str, speech_audio_path: str, video_output_path: str, logger=logging.Logger) -> bool:
        """
        为单个片段合并音视频（使用改进版脚本 video_audio_merge_change.py，可在音频更长时延长视频）
        """
        try:
            audio_file_path = os.path.join(speech_audio_path, f"{segment_id}.wav")
            video_file_path = os.path.join(video_output_path, f"{segment_id}.mp4")
            
            if not os.path.exists(audio_file_path):
                print(f"❌ 音频文件不存在: {audio_file_path}")
                return False
                
            if not os.path.exists(video_file_path):
                print(f"❌ 视频文件不存在: {video_file_path}")
                return False
            
            temp_output_path = video_file_path + ".temp.mp4"
            
            backend_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            merge_script_path = os.path.join(backend_dir, "video_audio_merge_change.py")
            
            if not os.path.exists(merge_script_path):
                print(f"❌ 音频合并脚本不存在: {merge_script_path}")
                return False
            
            merge_command = [
                "/home/EduAgent/miniconda3/envs/manim_env/bin/python",
                merge_script_path,
                audio_file_path,
                video_file_path,
                temp_output_path,
            ]
            
            import subprocess
            try:
                result = subprocess.run(
                    merge_command,
                    cwd=backend_dir,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                
                if result.returncode == 0 and os.path.exists(temp_output_path):
                    shutil.move(temp_output_path, video_file_path)
                    print(f"✅ 音视频合并完成(改进版): {segment_id}")
                    return True
                else:
                    print(f"❌ 音视频合并失败: {result.stderr}")
                    return False
                    
            except Exception as e:
                print(f"❌ 音视频合并异常: {e}")
                return False
                
        except Exception as e:
            print(f"❌ 合并音视频失败: {e}")
            return False
        
    def send_bytes_range_requests(
        self, file_path: str, start: int, end: int, chunk_size: int = 1024 * 64  # 64KB chunk size
    ) -> Generator[bytes, None, None]:
        """
        一个生成器函数，用于读取并返回文件的特定字节范围。
        
        Args:
            file_path (str): 要读取的文件路径.
            start (int): 开始读取的字节位置.
            end (int): 结束读取的字节位置.
            chunk_size (int): 每次读取的块大小.
        """
        with open(file_path, "rb") as file:
            file.seek(start)
            bytes_left_to_read = (end - start) + 1
            while bytes_left_to_read > 0:
                chunk = file.read(min(chunk_size, bytes_left_to_read))
                if not chunk:
                    break
                yield chunk
                bytes_left_to_read -= len(chunk)

    def stream_video_response(
        self,
        file_path: str, 
        range_header: Optional[str], 
        display_filename: str = "video.mp4"
    ) -> StreamingResponse:
        """
        (可复用的函数)
        为视频文件生成一个 StreamingResponse，自动支持 HTTP Range Requests。
        """
        
        # 1. 检查文件是否存在
        if not os.path.exists(file_path):
            print(f"❌ 文件未找到: {file_path}")
            raise HTTPException(
                status_code=404,
                detail=f"视频文件不存在: {file_path}"
            )

        # 获取文件大小，并处理文件可能正在写入的情况
        # 如果文件正在写入，文件大小可能会变化，需要多次检查以确保稳定性
        file_size = os.path.getsize(file_path)
        # 等待文件稳定（如果文件大小在短时间内变化，说明可能正在写入）
        import time
        max_wait_time = 2.0  # 最多等待2秒
        wait_interval = 0.1  # 每次检查间隔0.1秒
        waited_time = 0.0
        while waited_time < max_wait_time:
            new_size = os.path.getsize(file_path)
            if new_size == file_size:
                # 文件大小稳定，可以继续
                break
            file_size = new_size
            time.sleep(wait_interval)
            waited_time += wait_interval
        
        media_type, _ = mimetypes.guess_type(file_path)
        if media_type is None:
            media_type = "video/mp4"

        # 2. 准备基础响应头
        headers = {
            "Content-Type": media_type,
            "Accept-Ranges": "bytes", # 关键：告诉浏览器我支持范围请求
            "Content-Length": str(file_size),
            # "inline" 尝试在浏览器中播放, "attachment" 会强制下载
            "Content-Disposition": f"inline; filename=\"{display_filename}\"",
        }

        # 3. 如果没有 Range 头：返回完整的视频流 (Status 200)
        if range_header is None:
            def full_file_iter(file_path: str, chunk_size: int = 1024 * 64):
                with open(file_path, "rb") as file:
                    while True:
                        chunk = file.read(chunk_size)
                        if not chunk:
                            break
                        yield chunk
            
            print(f"✅ (200 OK) 返回完整视频流: {file_path}")
            return StreamingResponse(
                full_file_iter(file_path),
                headers=headers,
                status_code=200
            )

        # 4. 如果有 Range 头：处理范围请求 (Status 206)
        print(f"⚙️ 处理 Range header: {range_header}")
        
        try:
            range_str = range_header.strip().split("=")[1]
            start_str, end_str = range_str.split("-")
            
            start = int(start_str)
            # 如果 end 未指定，使用文件大小-1
            end = int(end_str) if end_str else file_size - 1
        except Exception:
            raise HTTPException(status_code=400, detail="无效的 Range header")

        # 处理 Range 请求超出文件大小的情况
        # 如果 start 超出文件大小，说明文件可能被重新生成了（新文件更小）
        # 此时返回从文件开头开始的内容，而不是 416 错误，避免浏览器需要重新请求
        if start >= file_size:
            print(f"⚠️ Range 请求超出文件大小，返回从文件开头开始: start={start}, file_size={file_size}")
            # 返回从文件开头到文件末尾的内容
            start = 0
            end = file_size - 1
        
        # 如果 end 超出文件大小，将其调整为文件末尾
        if end >= file_size:
            print(f"⚠️ Range 请求的 end 超出文件大小，调整为文件末尾: end={end} -> {file_size - 1}")
            end = file_size - 1
        
        # 确保 start <= end
        if start > end:
            print(f"⚠️ Range 请求无效，返回从文件开头开始: start={start} > end={end}")
            start = 0
            end = file_size - 1

        chunk_size = (end - start) + 1
        
        # 5. 更新响应头以反映部分内容
        headers["Content-Length"] = str(chunk_size)
        headers["Content-Range"] = f"bytes {start}-{end}/{file_size}"
        
        print(f"✅ (206 Partial) 返回部分视频 (Bytes {start}-{end}): {file_path}")
        
        return StreamingResponse(
            self.send_bytes_range_requests(file_path, start, end),
            headers=headers,
            status_code=206  # 关键：返回 206 Partial Content
        )
    
    def get_video_duration(self, video_path: str) -> Optional[float]:
        """
        计算给定视频文件的时长（秒）。

        Args:
            video_path: 视频文件的完整路径。

        Returns:
            视频时长（秒），如果文件不存在或读取失败，则返回 None。
        """
        if not os.path.exists(video_path):
            print(f"错误: 视频文件不存在于 {video_path}")
            return None
        
        try:
            # 使用 VideoFileClip 打开视频文件
            clip = VideoFileClip(video_path)
            # clip.duration 属性给出视频的秒数时长
            duration = clip.duration
            
            # 记得关闭 clip 释放资源
            clip.close()
            
            return duration
            
        except Exception as e:
            print(f"读取视频文件 {video_path} 时出错: {e}")
            return None
        

    def _send_email_background(
        self, recipient: str, subject: str, body: str
    ):
        """Sends an email using configured SMTP settings."""
        try:
            msg = MIMEText(body)
            msg['Subject'] = subject
            msg['From'] = SMTP_USERNAME
            msg['To'] = recipient

            # Connect to SMTP server and send
            # Use SMTP_SSL for port 465
            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
                server.starttls() # Use TLS
                server.login(SMTP_USERNAME, SMTP_PASSWORD)
                server.sendmail(SMTP_USERNAME, [recipient], msg.as_string())
            print(f"Email sent successfully to {recipient}")
        except Exception as e:
            print(f"Error sending email to {recipient}: {e}") # Log the error


