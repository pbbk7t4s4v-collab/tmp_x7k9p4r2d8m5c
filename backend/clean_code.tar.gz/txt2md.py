#!/usr/bin/env python3
import sys
import os
import re

def convert_line(line: str) -> str:
    """
    将行首的数字标题如 1 / 1.2 / 3.2.5 转换为 Markdown 标题
    1      -> # 
    1.2    -> ##
    3.2.5  -> ### 等
    """
    pattern = r"^(\d+(?:\.\d+)*)[.\s]+(.*)$"
    match = re.match(pattern, line.strip())
    if not match:
        return line

    number_part = match.group(1)
    title_text = match.group(2).strip()

    level = number_part.count('.') + 1
    markdown_prefix = "#" * level
    return f"{markdown_prefix} {title_text}\n"


def txt_to_md(txt_path: str):
    if not os.path.isfile(txt_path):
        print(f"文件不存在: {txt_path}")
        return

    folder = os.path.dirname(txt_path)
    file_name = os.path.splitext(os.path.basename(txt_path))[0]
    md_path = os.path.join(folder, file_name + ".md")

    converted_lines = []

    # 1. 读取并转换内容
    with open(txt_path, "r", encoding="utf-8") as f:
        for line in f:
            converted_lines.append(convert_line(line))

    # 2. 写入 .md 文件
    with open(md_path, "w", encoding="utf-8") as f:
        f.writelines(converted_lines)

    print(f"转换完成: {md_path}")

    # 3. 自动删除原 .txt 文件
    try:
        os.remove(txt_path)
        print(f"已删除原文件: {txt_path}")
    except Exception as e:
        print(f"删除原文件失败: {txt_path}，错误信息: {e}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("用法: python txt2md.py <txt绝对路径>")
        sys.exit(1)

    txt_path = sys.argv[1]
    txt_to_md(txt_path)
