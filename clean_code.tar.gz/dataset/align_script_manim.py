import os

def align_datasets(md_dir, py_dir):
    # 检查路径是否存在
    if not os.path.exists(md_dir) or not os.path.exists(py_dir):
        print("错误：指定的文件夹路径不存在，请检查配置。")
        return

    # 获取 Markdown 文件夹下的所有 .md 文件
    md_files = [f for f in os.listdir(md_dir) if f.endswith('.md')]
    total_initial_md = len(md_files)
    
    deleted_count = 0
    remaining_count = 0

    print(f"开始校验数据对齐情况...")
    print(f"当前 Markdown 数量: {total_initial_md}")
    print("-" * 30)

    for md_filename in md_files:
        # 获取不带后缀的文件名主干，例如: "sub1-sub2-1_1"
        file_stem = os.path.splitext(md_filename)[0]
        
        # 构建对应的 python 文件名
        expected_py_filename = file_stem + ".py"
        py_file_path = os.path.join(py_dir, expected_py_filename)

        # 检查 Python 文件是否存在
        if not os.path.exists(py_file_path):
            # 如果不存在，删除该 Markdown 文件
            md_file_path = os.path.join(md_dir, md_filename)
            try:
                os.remove(md_file_path)
                print(f"已删除 (无对应代码): {md_filename}")
                deleted_count += 1
            except Exception as e:
                print(f"删除失败 {md_filename}: {e}")
        else:
            remaining_count += 1

    print("-" * 30)
    print(f"校验完成！")
    print(f"🗑️  共删除（未对齐）: {deleted_count} 个文件")
    print(f"✅ 剩余（已对齐）: {remaining_count} 个文件")

# --- 配置区域 ---
# 请填入你之前汇总数据的文件夹路径
markdown_folder = '/home/TeachMasterAppV2/dataset/collect_markdowns'
manim_folder = '/home/TeachMasterAppV2/dataset/collect_manim_codes'

if __name__ == "__main__":
    # 运行前建议备份 Markdown 文件夹，以防万一
    align_datasets(markdown_folder, manim_folder)