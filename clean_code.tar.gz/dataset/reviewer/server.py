import json
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, Optional

import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field


HERE = Path(__file__).resolve().parent
DATASET_DIR = HERE.parent

STATIC_DIR = HERE / "static"
DATA_DIR = HERE / "data"
STATE_PATH = DATA_DIR / "state.json"
EVENTS_PATH = DATA_DIR / "events.jsonl"

STATE_LOCK = threading.Lock()
SCAN_LOCK = threading.Lock()


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _append_jsonl(path: Path, event: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def _load_state() -> dict[str, Any]:
    if not STATE_PATH.exists():
        return {"version": 1, "created_at": _iso_now(), "items": {}}
    try:
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"version": 1, "created_at": _iso_now(), "items": {}, "corrupted_state": True}


def _resolve_dirs(dataset_dir: Path) -> dict[str, Path]:
    videos_dir = dataset_dir / "rendered_videos"
    if not videos_dir.exists():
        raise RuntimeError(f"missing rendered_videos dir: {videos_dir}")

    codes_dir = dataset_dir / "collect_manim_codes"
    if not codes_dir.exists():
        # 兼容用户描述中的 collect_manim_code
        codes_dir = dataset_dir / "collect_manim_code"
    if not codes_dir.exists():
        raise RuntimeError(f"missing collect_manim_codes/collect_manim_code dir: {codes_dir}")

    markdown_dir = dataset_dir / "collect_markdowns"
    if not markdown_dir.exists():
        # 兼容潜在的 collect_markdown
        markdown_dir = dataset_dir / "collect_markdown"
    if not markdown_dir.exists():
        raise RuntimeError(f"missing collect_markdowns/collect_markdown dir: {markdown_dir}")

    return {"videos": videos_dir, "codes": codes_dir, "markdowns": markdown_dir}


DIRS = _resolve_dirs(DATASET_DIR)


def _safe_relpath(path: Path, root: Path) -> str:
    rel = path.relative_to(root)
    return rel.as_posix()


SCAN_CACHE: dict[str, Any] = {"stamp": None, "items": None}


def _scan_items() -> list[dict[str, Any]]:
    """
    Returns ordered items (newest first) from rendered_videos.
    Each item is keyed by id (video stem), and optionally has matching code/md files.
    """
    videos_dir = DIRS["videos"]
    codes_dir = DIRS["codes"]
    markdown_dir = DIRS["markdowns"]

    stamp = (
        videos_dir.stat().st_mtime_ns,
        codes_dir.stat().st_mtime_ns if codes_dir.exists() else None,
        markdown_dir.stat().st_mtime_ns if markdown_dir.exists() else None,
    )

    with SCAN_LOCK:
        if SCAN_CACHE["stamp"] == stamp and SCAN_CACHE["items"] is not None:
            return SCAN_CACHE["items"]

        videos = sorted(videos_dir.rglob("*.mp4"))
        items: list[dict[str, Any]] = []
        for vp in videos:
            try:
                st = vp.stat()
            except FileNotFoundError:
                continue
            item_id = vp.stem
            code_path = codes_dir / f"{item_id}.py"
            md_path = markdown_dir / f"{item_id}.md"
            items.append(
                {
                    "id": item_id,
                    "video_relpath": _safe_relpath(vp, videos_dir),
                    "video_mtime": st.st_mtime,
                    "video_size": st.st_size,
                    "has_code": code_path.exists(),
                    "has_markdown": md_path.exists(),
                }
            )

        items.sort(key=lambda x: (x["video_mtime"], x["id"]), reverse=True)
        SCAN_CACHE["stamp"] = stamp
        SCAN_CACHE["items"] = items
        return items


def _get_item_index(items: list[dict[str, Any]], item_id: str) -> Optional[int]:
    for i, it in enumerate(items):
        if it["id"] == item_id:
            return i
    return None


def _read_text_file(path: Path, *, max_bytes: int = 2_000_000) -> dict[str, Any]:
    if not path.exists():
        return {"exists": False, "text": None, "truncated": False}
    data = path.read_bytes()
    truncated = False
    if len(data) > max_bytes:
        data = data[:max_bytes]
        truncated = True
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        text = data.decode("utf-8", errors="replace")
    return {"exists": True, "text": text, "truncated": truncated}


def _item_payload(item: dict[str, Any], *, state: dict[str, Any]) -> dict[str, Any]:
    item_id = item["id"]
    videos_dir = DIRS["videos"]
    codes_dir = DIRS["codes"]
    markdown_dir = DIRS["markdowns"]

    code_path = codes_dir / f"{item_id}.py"
    md_path = markdown_dir / f"{item_id}.md"

    code = _read_text_file(code_path)
    md = _read_text_file(md_path)

    item_state = (state.get("items") or {}).get(item_id) or {}

    return {
        "item": {
            **item,
            "video_url": f"/videos/{item['video_relpath']}",
        },
        "code": code["text"],
        "code_missing": not code["exists"],
        "code_truncated": code["truncated"],
        "markdown": md["text"],
        "markdown_missing": not md["exists"],
        "markdown_truncated": md["truncated"],
        "state": item_state,
    }


def _pick_start_item(items: list[dict[str, Any]], state: dict[str, Any]) -> Optional[dict[str, Any]]:
    reviewed = state.get("items") or {}
    # 优先选择“有对应 code+markdown”的条目，避免一上来就卡在不完整数据上
    for it in items:
        if not (it.get("has_code") and it.get("has_markdown")):
            continue
        st = reviewed.get(it["id"]) or {}
        if not st.get("reviewed"):
            return it
    for it in items:
        st = reviewed.get(it["id"]) or {}
        if not st.get("reviewed"):
            return it
    return items[0] if items else None


def _next_unreviewed(items: list[dict[str, Any]], state: dict[str, Any], *, after_id: str) -> Optional[dict[str, Any]]:
    reviewed = state.get("items") or {}
    after_index = _get_item_index(items, after_id)
    start = (after_index + 1) if after_index is not None else 0
    for it in items[start:]:
        if not (it.get("has_code") and it.get("has_markdown")):
            continue
        st = reviewed.get(it["id"]) or {}
        if not st.get("reviewed"):
            return it
    for it in items[start:]:
        st = reviewed.get(it["id"]) or {}
        if not st.get("reviewed"):
            return it
    return None


class OpenRequest(BaseModel):
    item_id: str = Field(..., min_length=1)
    client_ts: Optional[float] = None


class SubmitRequest(BaseModel):
    item_id: str = Field(..., min_length=1)
    delete_mark: bool = False
    difficulty: Literal["easy", "medium", "hard"] = "medium"
    comment: str = ""
    video_duration: Optional[float] = None
    video_current_time: Optional[float] = None
    video_ended: Optional[bool] = None


app = FastAPI(title="TeachMaster Dataset Reviewer", version="0.1.0")

if not STATIC_DIR.exists():
    raise RuntimeError(f"missing frontend static dir: {STATIC_DIR}")

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


def _iter_file_range(path: Path, start: int, end: int, *, chunk_size: int = 1024 * 1024):
    with path.open("rb") as f:
        f.seek(start)
        remaining = end - start + 1
        while remaining > 0:
            chunk = f.read(min(chunk_size, remaining))
            if not chunk:
                break
            remaining -= len(chunk)
            yield chunk


@app.get("/videos/{video_path:path}")
def serve_video(video_path: str, request: Request):
    """
    Serve mp4 with HTTP Range support so the progress bar can seek/drag.
    """
    videos_root = DIRS["videos"].resolve()
    file_path = (videos_root / video_path).resolve()
    if videos_root != file_path and videos_root not in file_path.parents:
        raise HTTPException(status_code=403, detail="invalid path")
    if not file_path.exists() or not file_path.is_file():
        raise HTTPException(status_code=404, detail="video not found")

    size = file_path.stat().st_size
    range_header = request.headers.get("range")
    headers = {"Accept-Ranges": "bytes"}

    if not range_header:
        return FileResponse(file_path, media_type="video/mp4", headers=headers)

    # Example: "bytes=0-1023" / "bytes=0-" / "bytes=-500"
    if not range_header.startswith("bytes="):
        return FileResponse(file_path, media_type="video/mp4", headers=headers)
    raw = range_header[len("bytes=") :].strip()
    if "," in raw:
        raw = raw.split(",", 1)[0].strip()
    if "-" not in raw:
        return FileResponse(file_path, media_type="video/mp4", headers=headers)

    start_s, end_s = raw.split("-", 1)
    try:
        if start_s == "":
            # suffix range: last N bytes
            suffix = int(end_s)
            if suffix <= 0:
                raise ValueError
            start = max(0, size - suffix)
            end = size - 1
        else:
            start = int(start_s)
            end = int(end_s) if end_s != "" else (size - 1)
    except Exception:
        raise HTTPException(status_code=416, detail="invalid range")

    if start < 0 or start >= size:
        raise HTTPException(status_code=416, detail="range not satisfiable")
    if end < start:
        raise HTTPException(status_code=416, detail="range not satisfiable")
    end = min(end, size - 1)

    content_length = end - start + 1
    headers.update(
        {
            "Content-Range": f"bytes {start}-{end}/{size}",
            "Content-Length": str(content_length),
        }
    )
    return StreamingResponse(
        _iter_file_range(file_path, start, end),
        status_code=206,
        media_type="video/mp4",
        headers=headers,
    )


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {
        "ok": True,
        "now": _iso_now(),
        "dataset_dir": str(DATASET_DIR),
        "videos_dir": str(DIRS["videos"]),
        "codes_dir": str(DIRS["codes"]),
        "markdowns_dir": str(DIRS["markdowns"]),
    }


@app.get("/api/start")
def start() -> dict[str, Any]:
    items = _scan_items()
    with STATE_LOCK:
        state = _load_state()
    start_item = _pick_start_item(items, state)
    if not start_item:
        return {"empty": True, "total": 0}
    payload = _item_payload(start_item, state=state)
    payload["total"] = len(items)
    payload["index"] = _get_item_index(items, start_item["id"])
    payload["empty"] = False
    return payload


@app.get("/api/item/{item_id}")
def get_item(item_id: str) -> dict[str, Any]:
    items = _scan_items()
    idx = _get_item_index(items, item_id)
    if idx is None:
        raise HTTPException(status_code=404, detail="item not found")
    with STATE_LOCK:
        state = _load_state()
    payload = _item_payload(items[idx], state=state)
    payload["total"] = len(items)
    payload["index"] = idx
    payload["empty"] = False
    return payload


@app.get("/api/items")
def list_items(limit: int = 200) -> dict[str, Any]:
    items = _scan_items()
    with STATE_LOCK:
        state = _load_state()
    out = []
    for it in items[: max(1, min(limit, 5000))]:
        st = (state.get("items") or {}).get(it["id"]) or {}
        out.append({**it, "reviewed": bool(st.get("reviewed")), "marked_delete": bool(st.get("delete_mark"))})
    return {"total": len(items), "items": out}


@app.post("/api/open")
def open_item(req: OpenRequest) -> dict[str, Any]:
    items = _scan_items()
    if _get_item_index(items, req.item_id) is None:
        raise HTTPException(status_code=404, detail="item not found")

    server_ts = time.time()
    event = {
        "type": "open",
        "item_id": req.item_id,
        "server_ts": server_ts,
        "server_time": _iso_now(),
        "client_ts": req.client_ts,
    }

    with STATE_LOCK:
        state = _load_state()
        items_state = state.setdefault("items", {})
        st = items_state.setdefault(req.item_id, {})
        st["opened_at"] = _iso_now()
        st["opened_count"] = int(st.get("opened_count") or 0) + 1
        state["updated_at"] = _iso_now()
        _atomic_write_json(STATE_PATH, state)
        _append_jsonl(EVENTS_PATH, event)

    return {"ok": True}


@app.post("/api/submit")
def submit(req: SubmitRequest) -> dict[str, Any]:
    items = _scan_items()
    if _get_item_index(items, req.item_id) is None:
        raise HTTPException(status_code=404, detail="item not found")

    event = {
        "type": "submit",
        "item_id": req.item_id,
        "server_time": _iso_now(),
        "delete_mark": bool(req.delete_mark),
        "difficulty": req.difficulty,
        "comment": req.comment,
        "video_duration": req.video_duration,
        "video_current_time": req.video_current_time,
        "video_ended": req.video_ended,
    }

    with STATE_LOCK:
        state = _load_state()
        items_state = state.setdefault("items", {})
        st = items_state.setdefault(req.item_id, {})
        st["reviewed"] = True
        st["reviewed_at"] = _iso_now()
        st["delete_mark"] = bool(req.delete_mark)
        st["difficulty"] = req.difficulty
        st["comment"] = req.comment
        st["video_duration"] = req.video_duration
        st["video_current_time"] = req.video_current_time
        st["video_ended"] = req.video_ended
        state["updated_at"] = _iso_now()
        _atomic_write_json(STATE_PATH, state)
        _append_jsonl(EVENTS_PATH, event)

    with STATE_LOCK:
        state = _load_state()
    next_item = _next_unreviewed(items, state, after_id=req.item_id)
    if not next_item:
        return {"done": True, "total": len(items)}

    payload = _item_payload(next_item, state=state)
    payload["total"] = len(items)
    payload["index"] = _get_item_index(items, next_item["id"])
    payload["empty"] = False
    payload["done"] = False
    return payload


def main() -> None:
    port = int(os.environ.get("PORT", "8010"))
    host = os.environ.get("HOST", "127.0.0.1")
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    main()
