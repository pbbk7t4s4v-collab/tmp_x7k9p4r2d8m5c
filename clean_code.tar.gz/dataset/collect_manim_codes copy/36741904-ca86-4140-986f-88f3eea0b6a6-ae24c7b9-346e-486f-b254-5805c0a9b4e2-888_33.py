from manim import *

class LabFridgeSafety(Scene):
    def construct(self):

        # 1. Title Section
        title = Text("Laboratory Refrigerators",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("33", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Content Layout - Left Side Text
        # Using BulletedList for clear steps
        bullet_points = BulletedList(
            "Regular defrosting and cleaning.",
            "Do not store unrelated items (food/drink).",
            "No flammables in standard fridges\n(sparks can trigger explosions).",
            "Use safety locks for special samples\n(toxins, pathogens).",
            font_size=28,
            buff=0.4
        )
        bullet_points.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # 3. Image Integration - Right Side
        # Image 1: Professional Lab Fridge
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_33/1.png") # A professional laboratory refrigerator standing against a white background. It features a digital temperature display and shelves filled with chemical reagents, test tubes, and biological samples, distinct from a household fridge. Realistic photography style.
        img1.height = 2.5  # Set fixed height to maintain layout

        # Image 2: Safety Warnings
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_33/2.png") # A safety warning illustration depicting a refrigerator with a 'No Food or Drink' prohibition symbol and a 'Explosion Risk' warning sign stuck on the door. The style should be clean, instructional vector art suitable for a safety manual.
        img2.height = 2.5  # Set fixed height

        # Arrange images vertically on the right
        img_group = Group(img1, img2).arrange(DOWN, buff=0.5)
        img_group.to_edge(RIGHT, buff=1.0).shift(DOWN * 0.2)

        # 4. Animation Sequence
        # Show first image (the fridge object)
        self.play(FadeIn(img1, shift=LEFT))

        # Show maintenance points
        self.play(Write(bullet_points[0], run_time=1))

        # Show prohibition point
        self.play(Write(bullet_points[1], run_time=1))

        # Show warning image and related text
        self.play(FadeIn(img2, shift=UP))
        self.play(Write(bullet_points[2], run_time=1.5))

        # Highlight the explosion risk
        risk_rect = SurroundingRectangle(bullet_points[2], color=RED, buff=0.1)
        self.play(Create(risk_rect))

        # Show final point about locks
        self.play(Write(bullet_points[3], run_time=1.5))

        # Final wait
