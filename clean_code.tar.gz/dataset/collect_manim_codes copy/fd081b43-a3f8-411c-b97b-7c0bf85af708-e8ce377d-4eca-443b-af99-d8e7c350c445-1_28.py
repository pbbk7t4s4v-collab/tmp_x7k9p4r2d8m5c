from manim import *

class PracticeViewpointCore(Scene):
    def construct(self):

        # --- 标题部分 ---
        title = Text("实践观点在马克思主义哲学中的核心地位",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("28", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- 核心概念：实践观点 ---
        # 使用 VGroup 组合文字和边框
        core_text = Text("实践观点", font="AR PL UKai CN", font_size=36, color=YELLOW)
        core_desc = Text("马克思主义哲学的基石", font="AR PL UKai CN", font_size=20, color=WHITE)
        core_content = VGroup(core_text, core_desc).arrange(DOWN, buff=0.15)

        # 使用 SurroundingRectangle 强调核心
        core_box = SurroundingRectangle(core_content, color=YELLOW, buff=0.3)
        core_group = VGroup(core_content, core_box).move_to(UP * 0.5)

        # --- 分支概念 1：认识论 ---
        epis_title = Text("认识论", font="AR PL UKai CN", font_size=28, color=BLUE)
        epis_points = Text("认识的基础\n源泉与检验", font="AR PL UKai CN", font_size=20, color=BLUE_A)
        epis_content = VGroup(epis_title, epis_points).arrange(DOWN, buff=0.15)
        epis_box = SurroundingRectangle(epis_content, color=BLUE, buff=0.2)
        epis_group = VGroup(epis_content, epis_box).next_to(core_group, LEFT, buff=1.5).shift(DOWN * 0.5)

        # --- 分支概念 2：历史观 ---
        hist_title = Text("历史观", font="AR PL UKai CN", font_size=28, color=GREEN)
        hist_points = Text("社会存在基础\n唯物史观动力", font="AR PL UKai CN", font_size=20, color=GREEN_A)
        hist_content = VGroup(hist_title, hist_points).arrange(DOWN, buff=0.15)
        hist_box = SurroundingRectangle(hist_content, color=GREEN, buff=0.2)
        hist_group = VGroup(hist_content, hist_box).next_to(core_group, RIGHT, buff=1.5).shift(DOWN * 0.5)

        # --- 分支概念 3：价值论 ---
        axio_title = Text("价值论", font="AR PL UKai CN", font_size=28, color=RED)
        axio_points = Text("价值的源泉\n主体客体中介", font="AR PL UKai CN", font_size=20, color=RED_A)
        axio_content = VGroup(axio_title, axio_points).arrange(DOWN, buff=0.15)
        axio_box = SurroundingRectangle(axio_content, color=RED, buff=0.2)
        axio_group = VGroup(axio_content, axio_box).next_to(core_group, DOWN, buff=1.2)

        # --- 连接线条 (箭头) ---
        arrow_epis = Arrow(core_box.get_left(), epis_box.get_right(), color=GREY, buff=0.1)
        arrow_hist = Arrow(core_box.get_right(), hist_box.get_left(), color=GREY, buff=0.1)
        arrow_axio = Arrow(core_box.get_bottom(), axio_box.get_top(), color=GREY, buff=0.1)

        # --- 动画展示流程 ---
        # 1. 展示核心
        self.play(FadeIn(core_group, shift=UP), run_time=1.0)

        # 2. 同时展示三个维度的分支，体现"贯穿"的含义
        self.play(
            GrowArrow(arrow_epis), FadeIn(epis_group, shift=LEFT),
            GrowArrow(arrow_hist), FadeIn(hist_group, shift=RIGHT),
            GrowArrow(arrow_axio), FadeIn(axio_group, shift=DOWN),
            run_time=1.5
        )

        # 3. 简短停留，让观众阅读
