from manim import *

class DeepMDLimitations(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("深度势能分子动力学的局限与趋势",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 我们将三个要点设计为三个可视化的"卡片"，水平排列

        # --- 卡片 1: 长程相互作用 ---
        # 概念：原子间距离较远时的相互作用（如静电）
        c1_text = Text("长程相互作用处理", font="AR PL UKai CN", font_size=24, color=BLUE_A)

        # 图示：两个距离较远的粒子，中间有相互作用线
        atom1 = Dot(color=BLUE)
        atom2 = Dot(color=RED).shift(RIGHT * 1.5)
        interaction = DashedLine(atom1.get_center(), atom2.get_center(), color=YELLOW)
        formula_lr = MathTex(r"V \propto \frac{1}{r}", font_size=24).next_to(interaction, UP, buff=0.1)

        icon1 = VGroup(atom1, atom2, interaction, formula_lr).arrange(RIGHT, buff=0.1)
        icon1.next_to(c1_text, DOWN, buff=0.4)

        group1 = VGroup(c1_text, icon1)

        # --- 卡片 2: 不确定性与泛化 ---
        # 概念：模型在未见过的相空间中的表现
        c2_text = Text("不确定性与泛化", font="AR PL UKai CN", font_size=24, color=GREEN_A)

        # 图示：训练集区域和未知区域
        axes = Axes(x_range=[0, 4], y_range=[0, 4], x_length=1.5, y_length=1.2, tips=False)
        dots_train = VGroup(*[Dot(axes.c2p(x, x + 0.2), radius=0.05, color=GREEN) for x in [0.5, 1.0, 1.5]])
        dot_unknown = Dot(axes.c2p(3.0, 3.0), radius=0.08, color=RED)
        q_mark = Text("?", font_size=30, color=RED).next_to(dot_unknown, UP, buff=0.1)

        icon2 = VGroup(axes, dots_train, dot_unknown, q_mark)
        icon2.next_to(c2_text, DOWN, buff=0.4)

        group2 = VGroup(c2_text, icon2)

        # --- 卡片 3: 多尺度融合 ---
        # 概念：微观粒子到宏观连续介质的连接
        c3_text = Text("与多尺度模拟融合", font="AR PL UKai CN", font_size=24, color=PURPLE_A)

        # 图示：左边是粒子，箭头指向右边的网格
        micro_dots = VGroup(*[Dot(radius=0.04, color=WHITE).move_to([x*0.2, y*0.2, 0])
                              for x in range(3) for y in range(3)]).center()
        arrow = Arrow(LEFT, RIGHT, buff=0, max_tip_length_to_length_ratio=0.3, color=WHITE).scale(0.5)
        macro_grid = NumberPlane(x_range=[0, 1], y_range=[0, 1], x_length=0.8, y_length=0.8,
                                 background_line_style={"stroke_color": TEAL, "stroke_width": 2})

        icon3 = VGroup(micro_dots, arrow, macro_grid).arrange(RIGHT, buff=0.2)
        icon3.next_to(c3_text, DOWN, buff=0.4)

        group3 = VGroup(c3_text, icon3)

        # 3. 整体排列与边框
        # 将三组内容水平排列
        content_row = VGroup(group1, group2, group3).arrange(RIGHT, buff=1.0)
        group1.shift(RIGHT * 0.5)
        group2.shift(RIGHT * 0.5)

        # 为每个部分添加背景框（SurroundingRectangle）
        rect1 = SurroundingRectangle(group1, color=BLUE, buff=0.2, corner_radius=0.2)
        rect2 = SurroundingRectangle(group2, color=GREEN, buff=0.2, corner_radius=0.2)
        rect3 = SurroundingRectangle(group3, color=PURPLE, buff=0.2, corner_radius=0.2)

        # 4. 动画播放
        # 分步展示三个局限/趋势

        # 展示第一点
        self.play(FadeIn(group1, shift=UP), run_time=1.2)

        # 展示第二点
        self.play(FadeIn(group2, shift=UP), run_time=1.2)

        # 展示第三点
        self.play(FadeIn(group3, shift=UP), run_time=1.2)

        # 稍微停顿，让观众阅读
