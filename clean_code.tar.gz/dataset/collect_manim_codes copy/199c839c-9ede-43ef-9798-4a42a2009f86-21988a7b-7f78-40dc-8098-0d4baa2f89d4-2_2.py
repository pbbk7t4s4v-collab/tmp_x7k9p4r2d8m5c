from manim import *

class AIGuessingGame(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("互动环节：AI猜猜看",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 第一阶段：展示混合素材（动漫与风景）
        # 提示文本
        hint_text = Text("观察以下图片，判断是否为AI生成？", font_size=28, font="AR PL UKai CN", color=YELLOW)
        hint_text.next_to(title_line, DOWN, buff=0.5)

        # 载入图片1和3
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/199c839c-9ede-43ef-9798-4a42a2009f86/21988a7b-7f78-40dc-8098-0d4baa2f89d4/pictures/2_2/1.png") # 这里期望是一张精致的日系二次元动漫角色插画，画风细腻，色彩鲜艳，作为"AI猜猜看"环节的测试素材，写实风
        img3 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/199c839c-9ede-43ef-9798-4a42a2009f86/21988a7b-7f78-40dc-8098-0d4baa2f89d4/pictures/2_2/3.png") # 这里期望是一张唯美的现代中学校园风景插画，阳光明媚，包含教学楼和林荫道，新海诚风格，用于提升学生代入感，写实风

        # 设置图片大小和位置
        img1.height = 3.5
        img3.height = 3.5

        # 组合排列
        img_group = Group(img1, img3).arrange(RIGHT, buff=1.0)
        img_group.next_to(hint_text, DOWN, buff=0.5)

        # 标签
        label1 = Text("素材A：动漫角色", font_size=24, font="AR PL UKai CN").next_to(img1, DOWN, buff=0.2)
        label3 = Text("素材B：校园场景", font_size=24, font="AR PL UKai CN").next_to(img3, DOWN, buff=0.2)

        # 动画展示
        self.play(FadeIn(hint_text))
        self.play(FadeIn(img1), FadeIn(img3))
        self.play(Write(label1), Write(label3))

        # 3. 第二阶段：揭示翻车案例（清除上一阶段内容）
        self.play(
            FadeOut(img_group),
            FadeOut(label1),
            FadeOut(label3),
            FadeOut(hint_text)
        )

        # 重点提示文本
        focus_text = Text("识别秘籍：寻找反逻辑细节（如手指数量）", font_size=28, font="AR PL UKai CN", color=RED)
        focus_text.next_to(title_line, DOWN, buff=0.5)

        # 载入图片2（翻车案例）
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/199c839c-9ede-43ef-9798-4a42a2009f86/21988a7b-7f78-40dc-8098-0d4baa2f89d4/pictures/2_2/2.png") # 这里期望是一张存在明显逻辑错误的AI生成图片，特写展示一只拥有六根手指的人手，风格写实，用于展示AI生成的"翻车"案例，写实风
        img2.height = 4.0
        img2.next_to(focus_text, DOWN, buff=0.3)

        # 强调框
        rect = SurroundingRectangle(img2, color=RED, buff=0.1)

        # 错误说明
        error_label = Text("AI生成常见缺陷：多指/畸形", font_size=24, font="AR PL UKai CN", color=RED)
        error_label.next_to(rect, DOWN, buff=0.2)

        # 动画展示
        self.play(Write(focus_text))
        self.play(FadeIn(img2))
        self.play(Create(rect), Write(error_label))
