from manim import *

class OrganizationLevelPM(Scene):
    def construct(self):

        # 1. 标题设置 (根据模板要求)
        title = Text("组织级项目管理:项目集与项目组合",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("18", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 左侧:项目集 (Program)
        # 视觉元素:几个相互连接的圆,表示关联性
        p_circle1 = Circle(radius=0.25, color=BLUE_B, fill_opacity=0.5)
        p_circle2 = Circle(radius=0.25, color=BLUE_B, fill_opacity=0.5)
        p_circle3 = Circle(radius=0.25, color=BLUE_B, fill_opacity=0.5)

        # 排列成三角形
        p_group_circles = VGroup(p_circle1, p_circle2, p_circle3).arrange(RIGHT, buff=0.5)
        p_circle2.shift(UP * 0.4)

        # 连线表示关联
        p_line1 = Line(p_circle1.get_center(), p_circle2.get_center(), color=BLUE_A, stroke_width=2)
        p_line2 = Line(p_circle2.get_center(), p_circle3.get_center(), color=BLUE_A, stroke_width=2)
        p_line3 = Line(p_circle1.get_center(), p_circle3.get_center(), color=BLUE_A, stroke_width=2)

        prog_visual = VGroup(p_line1, p_line2, p_line3, p_group_circles)

        # 外部框
        prog_box = SurroundingRectangle(prog_visual, color=BLUE, buff=0.3)
        prog_title = Text("项目集 (Program)", font="AR PL UKai CN", font_size=28, color=BLUE).next_to(prog_box, UP, buff=0.2)

        # 文本描述
        prog_desc = VGroup(
            Text("• 互相关联的项目/活动", font="AR PL UKai CN", font_size=22),
            Text("• 协调管理以获益", font="AR PL UKai CN", font_size=22),
            MathTex(r"1 + 1 > 2", font_size=32, color=YELLOW) # 强调协同效应
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2).next_to(prog_box, DOWN, buff=0.3)

        left_content = VGroup(prog_title, prog_visual, prog_box, prog_desc)

        # 右侧:项目组合 (Portfolio)
        # 视觉元素:形状各异,不一定连接
        pf_shape1 = Square(side_length=0.5, color=GREEN, fill_opacity=0.5) # 项目
        pf_shape2 = Circle(radius=0.25, color=BLUE, fill_opacity=0.5)      # 项目集
        pf_shape3 = Triangle(color=RED, fill_opacity=0.5).scale(0.5)       # 运营

        pf_visual = VGroup(pf_shape1, pf_shape2, pf_shape3).arrange(RIGHT, buff=0.6)

        # 外部框
        pf_box = SurroundingRectangle(pf_visual, color=GREEN, buff=0.3)
        pf_title = Text("项目组合 (Portfolio)", font="AR PL UKai CN", font_size=28, color=GREEN).next_to(pf_box, UP, buff=0.2)

        # 文本描述
        pf_desc = VGroup(
            Text("• 为实现战略业务目标", font="AR PL UKai CN", font_size=22),
            Text("• 组合管理项目/运营", font="AR PL UKai CN", font_size=22),
            Text("• 不一定彼此依赖", font="AR PL UKai CN", font_size=22, color=ORANGE)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2).next_to(pf_box, DOWN, buff=0.3)

        right_content = VGroup(pf_title, pf_visual, pf_box, pf_desc)

        # 3. 整体布局调整
        # 将左右内容并排显示
        content_group = VGroup(left_content, right_content).arrange(RIGHT, buff=1.5)
        content_group.move_to(DOWN * 0.5) # 稍微下移,避开标题

        # 4. 动画展示
        # 展示左侧:项目集
        self.play(FadeIn(prog_title), Create(prog_visual))
        self.play(Create(prog_box))
        self.play(Write(prog_desc), run_time=2)

        # 展示右侧:项目组合
        self.play(FadeIn(pf_title), FadeIn(pf_visual))
        self.play(Create(pf_box))
        self.play(Write(pf_desc), run_time=2)

        # 5. 停留
