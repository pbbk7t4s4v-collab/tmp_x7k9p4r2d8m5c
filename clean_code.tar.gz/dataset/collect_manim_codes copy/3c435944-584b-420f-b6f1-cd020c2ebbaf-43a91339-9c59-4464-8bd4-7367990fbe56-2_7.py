from manim import *
import math

class OperationsPreservingConvexity(Scene):
    def construct(self):

        # 1. Title Setup (Standard Template)
        title = Text("Operations Preserving Convexity",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Left Column: Definitions
        # Concept 1: Pointwise Supremum
        sup_title = Text("1. Pointwise Supremum", font_size=28, color=BLUE_A, weight=BOLD)

        sup_def = MathTex(
            r"g(x) = \sup_{y \in \mathcal{Y}} f(x,y)",
            font_size=32
        )

        sup_expl = Paragraph(
            "If f(x,y) is convex in x for each y,",
            "then the supremum g(x) is convex.",
            font_size=20,
            line_spacing=0.5,
            slant=ITALIC,
            color=GRAY_A
        )

        # Concept 2: Perspective Function
        persp_title = Text("2. Perspective Function", font_size=28, color=BLUE_A, weight=BOLD)

        persp_def = MathTex(
            r"g(x,t) = t f(x/t)",
            font_size=32
        )

        persp_cond = MathTex(
            r"\text{dom}(g) = \{(x,t) \mid x/t \in \text{dom}(f), t > 0\}",
            font_size=24,
            color=GRAY_B
        )

        # Arrange Left Side elements
        left_group = VGroup(
            sup_title,
            sup_def,
            sup_expl,
            persp_title,
            persp_def,
            persp_cond
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.35)

        left_group.to_edge(LEFT, buff=1).shift(DOWN * 0.2)

        # 3. Right Column: Visualization of Pointwise Supremum
        # Create Axes
        ax = Axes(
            x_range=[-2.5, 2.5, 1],
            y_range=[0, 4.5, 1],
            x_length=5,
            y_length=4,
            axis_config={"include_tip": True, "font_size": 18, "color": GREY},
        )

        # Create curves representing f(x, y) for different y
        # We use parabolas shifted around
        c1 = ax.plot(lambda x: 0.4 * (x + 1.2)**2 + 0.8, color=BLUE_D, stroke_width=2, stroke_opacity=0.6)
        c2 = ax.plot(lambda x: 0.5 * (x - 0.5)**2 + 0.5, color=BLUE_D, stroke_width=2, stroke_opacity=0.6)
        c3 = ax.plot(lambda x: 0.6 * (x - 1.5)**2 + 1.2, color=BLUE_D, stroke_width=2, stroke_opacity=0.6)
        c4 = ax.plot(lambda x: 0.3 * x**2 + 1.5, color=BLUE_D, stroke_width=2, stroke_opacity=0.6)

        graph_group = VGroup(ax, c1, c2, c3, c4)
        graph_group.to_edge(RIGHT, buff=1)

        # Calculate the envelope (Supremum) for visualization
        # Note: This is a discrete approximation for the visual
        def sup_func(x):
            y1 = 0.4 * (x + 1.2)**2 + 0.8
            y2 = 0.5 * (x - 0.5)**2 + 0.5
            y3 = 0.6 * (x - 1.5)**2 + 1.2
            y4 = 0.3 * x**2 + 1.5
            return max(y1, y2, y3, y4)

        sup_curve = ax.plot(sup_func, color=YELLOW, stroke_width=5)

        # Labels
        graph_label = Text("Supremum Envelope", font_size=20, color=YELLOW).next_to(sup_curve, UP, buff=0.1)
        axes_labels = ax.get_axis_labels(x_label="x", y_label="f(x,y)")

        # 4. Animation Sequence
        # Fade in text definitions
        self.play(FadeIn(left_group, shift=RIGHT), run_time=1.5)

        # Draw axes and base functions
        self.play(
            Create(ax),
            Write(axes_labels),
            run_time=1.0
        )
        self.play(
            LaggedStart(
                Create(c1), Create(c2), Create(c3), Create(c4),
                lag_ratio=0.2
            ),
            run_time=2.0
        )

        # Highlight the Supremum
        highlight_box = SurroundingRectangle(sup_def, color=YELLOW, buff=0.1)

        self.play(
            Create(highlight_box),
            Create(sup_curve),
            Write(graph_label),
            run_time=2.0
        )
