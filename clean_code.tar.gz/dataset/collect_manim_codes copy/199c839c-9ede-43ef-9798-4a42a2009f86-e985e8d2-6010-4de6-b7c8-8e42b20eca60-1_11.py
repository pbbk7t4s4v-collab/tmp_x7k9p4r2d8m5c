from manim import *

class MaterialistDialecticsMethodology(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("唯物辩证法的方法论意义",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("11", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容辅助函数
        font_cn = "AR PL UKai CN"

        def create_card(title_text, content_texts, color, position_ref=None):
            # 标题部分
            t = Text(title_text, font=font_cn, font_size=26, color=color, weight=BOLD)

            # 内容部分 (列表)
            content_group = VGroup()
            for text in content_texts:
                line = Text(text, font=font_cn, font_size=18, color=WHITE)
                content_group.add(line)
            content_group.arrange(DOWN, buff=0.15, aligned_edge=LEFT)

            # 组合文本
            text_block = VGroup(t, content_group).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

            # 外框
            box = SurroundingRectangle(text_block, color=color, buff=0.3, corner_radius=0.2)

            # 整体组合
            card = VGroup(box, text_block)
            return card

        # 3. 创建四个板块内容

        # 板块1: 全面的观点
        card1 = create_card(
            "坚持全面的观点",
            ["• 多角度、多层次认识事物", "• 克服片面性和绝对化", "• 把握各种矛盾及其关系"],
            BLUE
        )

        # 板块2: 发展的观点
        card2 = create_card(
            "坚持发展的观点",
            ["• 克服静止僵化的思维", "• 承认新事物战胜旧事物", "• 理解变革与创新的必然"],
            GREEN
        )

        # 板块3: 矛盾分析方法
        card3 = create_card(
            "坚持矛盾分析方法",
            ["• 唯物辩证法的根本方法", "• 具体问题具体分析", "• 分清主要与次要矛盾"],
            RED
        )

        # 板块4: 理论联系实际
        card4 = create_card(
            "坚持理论联系实际",
            ["• 改造世界的武器", "• 在实践中检验发展理论", "• 用理论指导实践"],
            YELLOW
        )

        # 4. 布局排版 (2x2 网格)
        grid = VGroup(card1, card2, card3, card4).arrange_in_grid(rows=2, cols=2, buff=0.6)
        grid.next_to(title_group, DOWN, buff=0.6)

        # 5. 动画展示流程

        # 展示第一行：基本观点
        self.play(
            FadeIn(card1, shift=RIGHT, run_time=0.8),
            FadeIn(card2, shift=LEFT, run_time=0.8)
        )

        # 展示第二行：核心方法与目的
        self.play(
            GrowFromCenter(card3, run_time=0.8), # 强调根本方法
            FadeIn(card4, shift=UP, run_time=0.8)
        )

        # 简单的连接关系可视化 (示意图)
        # 在中心画一个十字连接线,表示四个方面的有机统一
        h_line = Line(grid.get_left(), grid.get_right(), color=GREY, stroke_opacity=0.3).move_to(grid.get_center())
        v_line = Line(grid.get_top(), grid.get_bottom(), color=GREY, stroke_opacity=0.3).move_to(grid.get_center())

        self.play(Create(h_line), Create(v_line), run_time=0.5)
