from manim import *

class BindingForces(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("药物与受体的结合力类型",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("72", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 图片展示 (左侧)
        # 严格遵守图片建议和注释格式
        img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/2d420861-da71-474e-b5d0-92a9e702d1ee/b28e272c-affb-4a4e-8370-e037b9e3294b/pictures/888_73/1.png") # 这里期望是一张3D生物医学可视化风格的图片，展示药物分子与受体蛋白结合的微观场景。画面主体是一个具有复杂表面结构的蛋白质（受体），其表面有一个明显的凹陷区域（结合口袋）。一个形状与其互补的小分子药物正紧密地嵌入这个口袋中。画面需要体现出“锁与钥匙”的契合感，背景为深色或虚化的细胞环境，风格严谨、科学，便于后续在画面上叠加动画线条来演示氢键、离子键等相互作用。

        # 调整图片大小和位置
        img.height = 4.5  # 限制高度
        img.width = 4.5   # 保持比例
        img.to_edge(LEFT, buff=1.0).shift(DOWN * 0.3)

        # 为图片添加边框，增加科技感
        img_rect = SurroundingRectangle(img, color=BLUE, buff=0.05, stroke_width=2)

        self.play(FadeIn(img), Create(img_rect))

        # 3. 核心概念文本 (右侧)
        # 使用 VGroup 组合每一条力，方便排版

        # 氢键
        t1_label = Text("1. 氢键", font="AR PL UKai CN", font_size=24, color=YELLOW)
        t1_desc = Text("具有方向性，确保精确定位", font="AR PL UKai CN", font_size=20, color=WHITE)
        g1 = VGroup(t1_label, t1_desc).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # 离子键
        t2_label = Text("2. 离子键 (静电)", font="AR PL UKai CN", font_size=24, color=RED)
        t2_desc = Text("长程吸引，引导药物进入口袋", font="AR PL UKai CN", font_size=20, color=WHITE)
        g2 = VGroup(t2_label, t2_desc).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # 范德华力
        t3_label = Text("3. 范德华力", font="AR PL UKai CN", font_size=24, color=GREEN)
        t3_desc = Text("短程引力，要求高度形状互补", font="AR PL UKai CN", font_size=20, color=WHITE)
        g3 = VGroup(t3_label, t3_desc).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # 疏水相互作用
        t4_label = Text("4. 疏水相互作用", font="AR PL UKai CN", font_size=24, color=BLUE)
        # 混合 MathTex 展示 Delta G
        t4_desc_text = Text("非极性结合，降低", font="AR PL UKai CN", font_size=20, color=WHITE)
        t4_math = MathTex(r"\Delta G", font_size=24, color=BLUE_A)
        t4_row = VGroup(t4_desc_text, t4_math).arrange(RIGHT, buff=0.1)
        g4 = VGroup(t4_label, t4_row).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # 整体排列右侧文本
        right_group = VGroup(g1, g2, g3, g4).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        right_group.next_to(img, RIGHT, buff=0.8)

        # 4. 动画展示文本与连线
        # 依次显示并画出指向图片的箭头，表示这些力作用于复合物

        arrows = VGroup()
        for item in [g1, g2, g3, g4]:
            # 计算箭头起始点和终点
            start = item.get_left()
            end = img.get_right() + LEFT * 0.5 + UP * (item.get_center()[1] - img.get_center()[1]) * 0.5
            # 简单的连线效果
            arrow = Line(start, end, color=item[0].get_color(), stroke_width=2).add_tip(tip_length=0.15)
            arrows.add(arrow)

        self.play(
            LaggedStart(
                AnimationGroup(Write(g1), Create(arrows[0])),
                AnimationGroup(Write(g2), Create(arrows[1])),
                AnimationGroup(Write(g3), Create(arrows[2])),
                AnimationGroup(Write(g4), Create(arrows[3])),
                lag_ratio=0.6
            ),
            run_time=4
        )

        # 5. 强调总结
        # 加上一个总括的矩形框在文字周围
        text_rect = SurroundingRectangle(right_group, color=WHITE, buff=0.2, stroke_width=1, stroke_opacity=0.5)
        self.play(Create(text_rect), run_time=1)
