from manim import *

class DiodeDirection(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("二极管方向识别(阴极标识)",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 引入文本
        intro_text = Text("二极管具有单向导电性,必须正确识别正负极",
                         font="AR PL UKai CN",
                         font_size=24,
                         color=BLUE_A)
        intro_text.next_to(title_line, DOWN, buff=0.5)
        self.play(FadeIn(intro_text))

        # 3. 核心可视化内容构建

        # --- 方法一:色环标识 ---
        # 绘制一个黑色圆柱体代表二极管
        d1_body = Rectangle(width=2.0, height=0.8, color=GRAY, fill_color=BLACK, fill_opacity=1)
        # 绘制白色色环(阴极)
        d1_band = Rectangle(width=0.3, height=0.8, color=WHITE, fill_color=WHITE, fill_opacity=1)
        d1_band.move_to(d1_body.get_right() - np.array([0.15, 0, 0]))
        # 引脚
        d1_wire_l = Line(d1_body.get_left(), d1_body.get_left() + LEFT * 0.5, color=GRAY)
        d1_wire_r = Line(d1_body.get_right(), d1_body.get_right() + RIGHT * 0.5, color=GRAY)

        d1_group = VGroup(d1_wire_l, d1_wire_r, d1_body, d1_band)

        label1 = Text("色环标识", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(d1_group, UP, buff=0.2)
        desc1 = Text("色环端 = 负极", font="AR PL UKai CN", font_size=18).next_to(d1_group, DOWN, buff=0.2)
        group1 = VGroup(d1_group, label1, desc1)

        # --- 方法二:引脚长度 ---
        # 绘制LED样式的示意图
        d2_head = Circle(radius=0.4, color=RED, fill_opacity=0.5)
        # 长脚(正)
        d2_leg_long = Line(d2_head.get_bottom() + LEFT*0.15, d2_head.get_bottom() + LEFT*0.15 + DOWN*1.2, color=GRAY, stroke_width=4)
        # 短脚(负)
        d2_leg_short = Line(d2_head.get_bottom() + RIGHT*0.15, d2_head.get_bottom() + RIGHT*0.15 + DOWN*0.6, color=GRAY, stroke_width=4)

        d2_group = VGroup(d2_head, d2_leg_long, d2_leg_short)

        label2 = Text("引脚长度", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(d2_head, UP, buff=0.2)
        desc2 = Text("短脚 = 负极", font="AR PL UKai CN", font_size=18).next_to(d2_leg_long, DOWN, buff=0.4) # 对齐到底部下方
        group2 = VGroup(d2_group, label2, desc2)

        # --- 方法三:管体符号 ---
        # 绘制电路符号
        start_point = LEFT * 0.8
        end_point = RIGHT * 0.8
        # 三角形
        tri_path = Polygon(start_point + UP*0.4, start_point + DOWN*0.4, end_point, color=WHITE, fill_opacity=0)
        # 竖线
        bar_line = Line(end_point + UP*0.4, end_point + DOWN*0.4, color=WHITE, stroke_width=4)
        # 导线
        wire_l = Line(start_point + LEFT*0.4, start_point, color=WHITE)
        wire_r = Line(end_point, end_point + RIGHT*0.4, color=WHITE)

        d3_group = VGroup(tri_path, bar_line, wire_l, wire_r)

        label3 = Text("管体符号", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(d3_group, UP, buff=0.2)
        desc3 = Text("箭头指 = 负极", font="AR PL UKai CN", font_size=18).next_to(d3_group, DOWN, buff=0.2)
        group3 = VGroup(d3_group, label3, desc3)

        # 4. 布局与动画
        # 将三组内容水平排列
        content_row = VGroup(group1, group2, group3).arrange(RIGHT, buff=1.0)
        content_row.next_to(intro_text, DOWN, buff=0.8)

        # 逐步显示
        self.play(FadeIn(group1, shift=UP), run_time=1)
        self.play(FadeIn(group2, shift=UP), run_time=1)
        self.play(FadeIn(group3, shift=UP), run_time=1)

        # 5. 强调负极特征
        # 在关键部位添加 MathTex("-") 标记
        sign1 = MathTex("-", color=RED).next_to(d1_band, RIGHT, buff=0.1).scale(0.8)
        sign2 = MathTex("-", color=RED).next_to(d2_leg_short, DOWN, buff=0.1).scale(0.8)
        sign3 = MathTex("-", color=RED).next_to(bar_line, RIGHT, buff=0.1).scale(0.8)

        self.play(
            Write(sign1),
            Write(sign2),
            Write(sign3)
        )

        # 使用矩形框强调这三个负极特征
        rects = VGroup(
            SurroundingRectangle(d1_band, color=ORANGE, buff=0.05),
            SurroundingRectangle(d2_leg_short, color=ORANGE, buff=0.05),
            SurroundingRectangle(bar_line, color=ORANGE, buff=0.1)
        )

        self.play(Create(rects), run_time=1.5)
