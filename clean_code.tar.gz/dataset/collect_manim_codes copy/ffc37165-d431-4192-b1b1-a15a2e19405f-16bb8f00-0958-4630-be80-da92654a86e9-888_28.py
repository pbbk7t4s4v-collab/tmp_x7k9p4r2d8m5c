from manim import *

class EulerCircuitOrigin(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("欧拉回路：问题来源与抽象",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("28", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧图片展示
        # 图片布局：左侧占据约40%宽度
        img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/ffc37165-d431-4192-b1b1-a15a2e19405f/16bb8f00-0958-4630-be80-da92654a86e9/pictures/888_28/1.png") # 这里期望是一张展示哥尼斯堡七桥问题的地图示意图，要求画面展示一条河流将陆地分隔成两岸和两个岛屿，总共有七座桥连接着这些陆地部分，写实风
        img.scale_to_fit_height(5.0) # 调整高度以适应屏幕
        img.to_edge(LEFT, buff=1.0)
        img.shift(DOWN * 0.5) # 稍微下移避开标题

        # 图片边框
        img_rect = SurroundingRectangle(img, color=BLUE, buff=0.05)
        img_label = Text("哥尼斯堡 (1736)", font="AR PL UKai CN", font_size=20, color=BLUE)
        img_label.next_to(img_rect, DOWN)

        self.play(FadeIn(img), Create(img_rect), Write(img_label))

        # 3. 右侧内容布局
        # 分为上半部分（文本）和下半部分（抽象图）

        # 3.1 文本讲解
        text_start_pos = UP * 1.5 + RIGHT * 1.0

        p1 = Text("经典问题：七桥问题（一笔画）", font="AR PL UKai CN", font_size=24, color=YELLOW)
        p2 = Text("抽象过程：", font="AR PL UKai CN", font_size=24, color=WHITE)
        p3 = Text("• 陆地/岛屿 → 顶点 (Node)", font="AR PL UKai CN", font_size=22, color=LIGHT_GREY)
        p4 = Text("• 桥梁 → 边 (Edge)", font="AR PL UKai CN", font_size=22, color=LIGHT_GREY)
        p5 = Text("意义：图论诞生", font="AR PL UKai CN", font_size=24, color=ORANGE)

        text_group = VGroup(p1, p2, p3, p4, p5)
        text_group.arrange(DOWN, aligned_edge=LEFT, buff=0.25)
        text_group.to_edge(RIGHT, buff=1.0).shift(UP * 0.5)

        self.play(Write(p1))
        self.play(FadeIn(p2), FadeIn(p3), FadeIn(p4))

        # 3.2 抽象图演示 (在右下角绘制简单的图模型)
        # 定义节点位置 (相对位置)
        graph_center = text_group.get_bottom() + DOWN * 2.0 + LEFT * 0.5

        # 模拟四个区域：北岸(N)，南岸(S)，大岛(A)，小岛(B)
        node_n = Dot(point=graph_center + UP * 1.2, color=RED, radius=0.12)
        node_s = Dot(point=graph_center + DOWN * 1.2, color=RED, radius=0.12)
        node_a = Dot(point=graph_center, color=RED, radius=0.12) # 中间的大岛
        node_b = Dot(point=graph_center + RIGHT * 1.8, color=RED, radius=0.12) # 右侧的小岛

        # 标签
        label_n = Text("北岸", font="AR PL UKai CN", font_size=16).next_to(node_n, UP, buff=0.1)
        label_s = Text("南岸", font="AR PL UKai CN", font_size=16).next_to(node_s, DOWN, buff=0.1)
        label_a = Text("岛A", font="AR PL UKai CN", font_size=16).next_to(node_a, LEFT, buff=0.1)
        label_b = Text("岛B", font="AR PL UKai CN", font_size=16).next_to(node_b, RIGHT, buff=0.1)

        nodes = VGroup(node_n, node_s, node_a, node_b, label_n, label_s, label_a, label_b)

        # 连线 (7条边)
        # N-A (2条)
        edge_na_1 = ArcBetweenPoints(node_n.get_center(), node_a.get_center(), angle=0.5, color=GREEN)
        edge_na_2 = ArcBetweenPoints(node_n.get_center(), node_a.get_center(), angle=-0.5, color=GREEN)

        # S-A (2条)
        edge_sa_1 = ArcBetweenPoints(node_s.get_center(), node_a.get_center(), angle=0.5, color=GREEN)
        edge_sa_2 = ArcBetweenPoints(node_s.get_center(), node_a.get_center(), angle=-0.5, color=GREEN)

        # N-B (1条)
        edge_nb = Line(node_n.get_center(), node_b.get_center(), color=GREEN)

        # S-B (1条)
        edge_sb = Line(node_s.get_center(), node_b.get_center(), color=GREEN)

        # A-B (1条)
        edge_ab = Line(node_a.get_center(), node_b.get_center(), color=GREEN)

        edges = VGroup(edge_na_1, edge_na_2, edge_sa_1, edge_sa_2, edge_nb, edge_sb, edge_ab)

        # 动画：从文本描述到图形生成
        self.play(Create(nodes), run_time=1)
        self.play(Create(edges), run_time=1.5)

        # 强调抽象结果
        abstract_box = SurroundingRectangle(VGroup(nodes, edges), color=WHITE, buff=0.2, stroke_width=1)
        abstract_label = Text("图模型", font="AR PL UKai CN", font_size=18).next_to(abstract_box, DOWN)

        self.play(Create(abstract_box), Write(abstract_label))

        # 最后显示意义
        self.play(Write(p5))
