from manim import *

class ElderlyBMIAnalysis(Scene):
    def construct(self):

        # 1. 标题部分 (按照模板要求)
        title = Text("老年人：BMI标准的特殊性",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心可视化内容：对比图
        # 定义参数
        bar_width = 1.5
        total_height = 3.5

        # 左侧：年轻人 (肌肉多，脂肪少)
        # 肌肉部分 (红色)
        young_muscle_h = total_height * 0.75
        young_fat_h = total_height * 0.25

        y_muscle_rect = Rectangle(width=bar_width, height=young_muscle_h, color=RED, fill_opacity=0.8, fill_color=RED)
        y_fat_rect = Rectangle(width=bar_width, height=young_fat_h, color=YELLOW, fill_opacity=0.8, fill_color=YELLOW)
        y_fat_rect.next_to(y_muscle_rect, UP, buff=0)

        young_group = VGroup(y_muscle_rect, y_fat_rect)
        young_group.move_to(LEFT * 3)

        young_label = Text("年轻人", font="AR PL UKai CN", font_size=24).next_to(young_group, UP, buff=0.2)
        young_desc = Text("肌肉紧实", font="AR PL UKai CN", font_size=20, color=RED_A).next_to(y_muscle_rect, LEFT, buff=0.2)

        # 右侧：老年人 (肌肉少，脂肪多 - 肌少症)
        # 肌肉部分 (红色)
        old_muscle_h = total_height * 0.4
        old_fat_h = total_height * 0.6

        o_muscle_rect = Rectangle(width=bar_width, height=old_muscle_h, color=RED, fill_opacity=0.8, fill_color=RED)
        o_fat_rect = Rectangle(width=bar_width, height=old_fat_h, color=YELLOW, fill_opacity=0.8, fill_color=YELLOW)
        o_fat_rect.next_to(o_muscle_rect, UP, buff=0)

        old_group = VGroup(o_muscle_rect, o_fat_rect)
        # 对齐底部
        old_group.move_to(RIGHT * 3)
        old_group.align_to(young_group, DOWN)

        old_label = Text("老年人", font="AR PL UKai CN", font_size=24).next_to(old_group, UP, buff=0.2)
        old_desc = Text("肌肉流失", font="AR PL UKai CN", font_size=20, color=YELLOW_A).next_to(o_fat_rect, RIGHT, buff=0.2)

        # 共同的BMI标签
        bmi_arrow_left = Arrow(start=DOWN, end=UP, color=WHITE).next_to(young_group, DOWN, buff=0.1)
        bmi_arrow_right = Arrow(start=DOWN, end=UP, color=WHITE).next_to(old_group, DOWN, buff=0.1)
        bmi_text = Text("BMI = 21 (相同)", font="AR PL UKai CN", font_size=28, color=BLUE).move_to((bmi_arrow_left.get_bottom() + bmi_arrow_right.get_bottom()) / 2 + DOWN * 0.4)

        # 图例
        legend_muscle = VGroup(Square(side_length=0.2, color=RED, fill_opacity=1, fill_color=RED), Text("肌肉", font="AR PL UKai CN", font_size=18)).arrange(RIGHT, buff=0.1)
        legend_fat = VGroup(Square(side_length=0.2, color=YELLOW, fill_opacity=1, fill_color=YELLOW), Text("脂肪", font="AR PL UKai CN", font_size=18)).arrange(RIGHT, buff=0.1)
        legend = VGroup(legend_muscle, legend_fat).arrange(RIGHT, buff=0.5).move_to(UP * 2)

        # 3. 动画展示核心对比
        self.play(FadeIn(young_label), FadeIn(old_label), FadeIn(legend))
        self.play(Create(young_group), Create(old_group), run_time=1.5)
        self.play(Write(young_desc), Write(old_desc))

        self.play(GrowFromPoint(bmi_arrow_left, bmi_arrow_left.get_start()),
                  GrowFromPoint(bmi_arrow_right, bmi_arrow_right.get_start()),
                  Write(bmi_text))

        # 4. 结论展示
        conclusion_text = Text("结论：老年人健康范围需适当放宽", font="AR PL UKai CN", font_size=28, color=YELLOW)
        conclusion_box = SurroundingRectangle(conclusion_text, color=YELLOW, buff=0.2)
        conclusion_group = VGroup(conclusion_box, conclusion_text)
        conclusion_group.to_edge(DOWN, buff=0.8)

        self.play(FadeIn(conclusion_group, shift=UP))
