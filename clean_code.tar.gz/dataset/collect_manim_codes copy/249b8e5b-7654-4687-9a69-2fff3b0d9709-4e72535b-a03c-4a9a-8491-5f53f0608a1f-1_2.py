from manim import *

class ListOperations(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("Python列表元素的增删改",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 初始化列表可视化
        # 创建列表框和元素
        box_size = 1.2
        squares = VGroup()
        texts = VGroup()

        # 初始数据: ["A", "B", "C"]
        data = ["A", "B", "C"]
        colors = [BLUE, BLUE, BLUE]

        for i, (char, col) in enumerate(zip(data, colors)):
            sq = Square(side_length=box_size, color=col, fill_opacity=0.5, fill_color=col)
            txt = Text(char, font_size=40, color=WHITE)
            sq_group = VGroup(sq, txt)
            squares.add(sq_group)

        # 排列方块
        squares.arrange(RIGHT, buff=0.2)
        squares.move_to(ORIGIN).shift(UP * 0.5)

        # 添加索引标记 (0, 1, 2)
        indices = VGroup()
        for i, sq in enumerate(squares):
            idx = Text(str(i), font_size=24, color=GRAY, font="AR PL UKai CN")
            idx.next_to(sq, UP, buff=0.1)
            indices.add(idx)

        list_group = VGroup(squares, indices)

        self.play(FadeIn(list_group, shift=UP))

        # 3. 操作展示区域 (下方文字说明)
        op_text = Text("初始列表: ['A', 'B', 'C']", font="AR PL UKai CN", font_size=28, color=YELLOW)
        op_text.next_to(list_group, DOWN, buff=1.0)
        self.play(Write(op_text))

        # --- 场景一:修改列表元素 ---
        # 目标:将索引1的 'B' 修改为 'X'
        new_op_text = Text("1. 修改: my_list[1] = 'X'", font="AR PL UKai CN", font_size=28, color=GREEN)
        new_op_text.move_to(op_text)

        # 高亮框
        target_sq = squares[1][0] # 索引1的方块
        rect = SurroundingRectangle(squares[1], color=YELLOW, buff=0.1)

        self.play(
            Transform(op_text, new_op_text),
            Create(rect)
        )

        # 变换文字
        old_txt = squares[1][1]
        new_txt = Text("X", font_size=40, color=RED).move_to(old_txt.get_center())

        self.play(
            Transform(old_txt, new_txt),
            target_sq.animate.set_color(RED).set_fill(RED, opacity=0.5),
            run_time=1.0
        )
        self.play(FadeOut(rect))

        # --- 场景二:在列表中添加元素 ---
        # 目标:在末尾添加 'D'
        add_op_text = Text("2. 添加: my_list.append('D')", font="AR PL UKai CN", font_size=28, color=GREEN)
        add_op_text.move_to(op_text)

        # 创建新元素
        new_sq = Square(side_length=box_size, color=BLUE, fill_opacity=0.5, fill_color=BLUE)
        new_char = Text("D", font_size=40, color=WHITE)
        new_item = VGroup(new_sq, new_char)
        # 初始位置在屏幕右侧外,或者就在C的右边淡入
        new_item.next_to(squares[2], RIGHT, buff=0.2)

        # 新索引
        new_idx = Text("3", font_size=24, color=GRAY, font="AR PL UKai CN")
        new_idx.next_to(new_item, UP, buff=0.1)

        self.play(Transform(op_text, add_op_text))

        self.play(
            FadeIn(new_item, shift=LEFT),
            FadeIn(new_idx, shift=DOWN),
            run_time=1.0
        )

        # 更新逻辑上的组,方便后续操作
        squares.add(new_item)
        indices.add(new_idx)

        # --- 场景三:从列表中删除元素 ---
        # 目标:删除索引0的 'A'
        del_op_text = Text("3. 删除: del my_list[0]", font="AR PL UKai CN", font_size=28, color=GREEN)
        del_op_text.move_to(op_text)

        self.play(Transform(op_text, del_op_text))

        # 选中第一个元素
        to_delete_item = squares[0]
        to_delete_idx = indices[0]

        rect_del = SurroundingRectangle(to_delete_item, color=RED)
        self.play(Create(rect_del), run_time=0.5)

        # 消失动画
        self.play(
            FadeOut(to_delete_item),
            FadeOut(to_delete_idx),
            FadeOut(rect_del),
            run_time=0.8
        )

        # 剩余元素左移
        remaining_squares = VGroup(*[squares[i] for i in range(1, 4)])
        remaining_indices = VGroup(*[indices[i] for i in range(1, 4)])

        # 整体向左移动填补空缺
        shift_amount = squares[0].get_center() - squares[1].get_center()
        # 注意:这里squares[0]虽然FadeOut了,但对象位置还在,我们计算相对位移
        # 更简单的做法是重新arrange,但为了平滑移动,我们手动计算

        target_point = squares[0].get_center()
        current_first = squares[1].get_center()
        move_vec = target_point - current_first

        # 更新索引数字 (删除0后,原来的1变成0,2变成1...)
        # 这里为了演示简单,我们只移动物理位置,不更新索引显示的数字(因为列表本身索引会变,但通常演示物理删除时,数字重排会比较乱,这里只移动位置)
        # 如果要严谨,应该把原来的索引1变成0。

        new_indices_text = ["0", "1", "2"]
        anims = []

        # 移动方块
        anims.append(remaining_squares.animate.shift(move_vec))
        anims.append(remaining_indices.animate.shift(move_vec))

        # 同时也改变索引显示的数字
        for i, idx_mobj in enumerate(remaining_indices):
            new_idx_char = Text(new_indices_text[i], font_size=24, color=GRAY, font="AR PL UKai CN")
            new_idx_char.move_to(idx_mobj.get_center() + move_vec) # 预判移动后的位置
            anims.append(Transform(idx_mobj, new_idx_char))

        self.play(*anims, run_time=1.0)
