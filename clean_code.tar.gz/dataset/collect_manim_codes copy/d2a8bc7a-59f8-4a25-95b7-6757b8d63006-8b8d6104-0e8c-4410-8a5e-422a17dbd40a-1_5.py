from manim import *

class GraphicsAndAnimationOverview(Scene):
    def construct(self):

        # ---------------------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------------------
        title = Text("图形与动画:定义、生成与开发",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------------------
        # 2. 内容布局设计
        # 将内容分为三个模块:概念与特点、生成与格式、开发注意事项
        # ---------------------------------------------------------------------

        # 定义通用字体配置
        text_props = {"font": "AR PL UKai CN", "font_size": 22, "color": LIGHT_GRAY}
        header_props = {"font": "AR PL UKai CN", "font_size": 26, "color": BLUE_B, "weight": BOLD}

        # --- 模块 1: 概念与特点 ---
        header_1 = Text("1. 定义与特点", **header_props)
        content_1 = VGroup(
            Text("• 图形:静态视觉符号", **text_props),
            Text("• 动画:连续运动图像", **text_props),
            Text("• 特点:直观、信息量大", **text_props),
            Text("• 优势:跨越语言障碍", **text_props)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        group_1 = VGroup(header_1, content_1).arrange(DOWN, aligned_edge=LEFT, buff=0.4)

        # --- 模块 2: 生成与格式 ---
        header_2 = Text("2. 生成与格式", **header_props)
        content_2 = VGroup(
            Text("• 生成:扫描/绘制/计算", **text_props),
            Text("• 关键帧:运动规律设定", **text_props),
            Text("• 格式:BMP/JPG/GIF", **text_props),
            Text("• 矢量 vs 位图", **text_props)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        group_2 = VGroup(header_2, content_2).arrange(DOWN, aligned_edge=LEFT, buff=0.4)

        # --- 模块 3: 开发注意事项 ---
        header_3 = Text("3. 开发要点", **header_props)
        content_3 = VGroup(
            Text("• 视觉心理匹配", **text_props),
            Text("• 色彩与分辨率", **text_props),
            Text("• 数据量与存储", **text_props),
            Text("• 交互性设计", **text_props)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        group_3 = VGroup(header_3, content_3).arrange(DOWN, aligned_edge=LEFT, buff=0.4)

        # ---------------------------------------------------------------------
        # 3. 位置排列与边框
        # ---------------------------------------------------------------------

        # 水平排列三个组
        all_groups = VGroup(group_1, group_2, group_3).arrange(RIGHT, buff=1.0)
        all_groups.move_to(ORIGIN).shift(DOWN * 0.5) # 整体下移,避开标题

        # 为每个组添加边框 (SurroundingRectangle)
        rect_1 = SurroundingRectangle(group_1, color=TEAL, buff=0.3, corner_radius=0.2)
        rect_2 = SurroundingRectangle(group_2, color=TEAL, buff=0.3, corner_radius=0.2)
        rect_3 = SurroundingRectangle(group_3, color=TEAL, buff=0.3, corner_radius=0.2)

        # ---------------------------------------------------------------------
        # 4. 图片占位符 (Rule 12)
        # 用于展示图形文件的图标示例,增强视觉效果
        # ---------------------------------------------------------------------
        try:
            # 这里放置一张示意图,代表图形文件的图标
            img = ImageMobject("placeholder.png")
            img.height = 0.8
            # 将图片放在"生成与格式"模块的右下角,作为装饰
            img.next_to(rect_2, DOWN, buff=0.1)
            img_caption = Text("文件示例", font="AR PL UKai CN", font_size=16, color=GRAY).next_to(img, RIGHT)
            img_group = VGroup(img, img_caption)
        except:
            # 如果没有图片,创建一个替代的几何图形
            img_shape = Square(side_length=0.5, color=BLUE, fill_opacity=0.5)
            img_text = Text("IMG", font_size=12).move_to(img_shape)
            img_group = VGroup(img_shape, img_text)
            img_group.next_to(rect_2, DOWN, buff=0.1)

        # ---------------------------------------------------------------------
        # 5. 动画播放
        # ---------------------------------------------------------------------

        # 依次显示三个模块
        self.play(
            Create(rect_1),
            FadeIn(group_1, shift=UP),
            run_time=1.5
        )

        self.play(
            Create(rect_2),
            FadeIn(group_2, shift=UP),
            FadeIn(img_group),
            run_time=1.5
        )

        self.play(
            Create(rect_3),
            FadeIn(group_3, shift=UP),
            run_time=1.5
        )

        # 简单的强调动画:高亮中间的"格式"部分
        self.play(
            Indicate(content_2[2], color=YELLOW, scale_factor=1.1),
            run_time=1.0
        )
