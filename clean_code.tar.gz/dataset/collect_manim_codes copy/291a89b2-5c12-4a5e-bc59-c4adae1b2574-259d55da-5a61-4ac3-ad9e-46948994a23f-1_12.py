from manim import *

class SubstantiveReasoning(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("实质理由的隐蔽运作机制",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心流程图布局 (形式三段论的外观)
        # ---------------------------------------------------------
        # 定义三个主要环节的标题
        # 使用函数简化创建过程
        def create_stage_header(text, position):
            t = Text(text, font="AR PL UKai CN", font_size=28, color=WHITE)
            box = SurroundingRectangle(t, color=BLUE, buff=0.2, fill_opacity=0.2, fill_color=BLUE_E)
            group = VGroup(box, t)
            group.move_to(position)
            return group

        # 计算位置:屏幕宽度分为三部分
        pos_left = LEFT * 4.5
        pos_center = ORIGIN
        pos_right = RIGHT * 4.5

        # 创建顶部Header (事实认定 -> 规范选择 -> 涵摄)
        # 实际上为了布局平衡,稍微往上提一点
        base_y = UP * 1.5

        stage1 = create_stage_header("事实认定", pos_left + base_y)
        stage2 = create_stage_header("规范选择", pos_center + base_y)
        stage3 = create_stage_header("涵摄 (Subsumption)", pos_right + base_y)

        # 调整水平间距,确保不重叠
        stages = VGroup(stage1, stage2, stage3).arrange(RIGHT, buff=1.2).move_to(UP * 1.5)

        # 箭头连接
        arrow1 = Arrow(stage1.get_right(), stage2.get_left(), color=GREY, buff=0.1)
        arrow2 = Arrow(stage2.get_right(), stage3.get_left(), color=GREY, buff=0.1)

        # 动画展示形式层面
        self.play(FadeIn(stages, shift=DOWN), Create(arrow1), Create(arrow2))

        # ---------------------------------------------------------
        # 3. 揭示"隐蔽运作" (实质理由的内容)
        # ---------------------------------------------------------

        # 辅助函数:创建详情列表
        def create_detail_list(items, parent_mobject):
            lines = VGroup()
            for item in items:
                # 使用小点作为 bullet
                dot = Dot(radius=0.06, color=YELLOW)
                txt = Text(item, font="AR PL UKai CN", font_size=20, color=LIGHT_GREY)
                line = VGroup(dot, txt).arrange(RIGHT, buff=0.15)
                lines.add(line)

            lines.arrange(DOWN, buff=0.2, aligned_edge=LEFT)
            # 放在对应方框的正下方
            lines.next_to(parent_mobject, DOWN, buff=0.5)
            return lines

        # 事实认定的隐蔽内容
        details1_content = [
            "证据取舍 (价值判断)",
            "叙事建构 (描述框架)",
            "经验法则 (社会通念)"
        ]
        details1 = create_detail_list(details1_content, stages[0])

        # 规范选择的隐蔽内容
        details2_content = [
            "后果妥当性考量",
            "政策导向 (类型化)",
            "体系融贯性判断"
        ]
        details2 = create_detail_list(details2_content, stages[1])

        # 涵摄的隐蔽内容
        details3_content = [
            "概念边界 (如:公共场所)",
            "社会认知与技术理解",
            "价值评价的融合"
        ]
        details3 = create_detail_list(details3_content, stages[2])

        # ---------------------------------------------------------
        # 4. 动画展示实质层面
        # ---------------------------------------------------------

        # 依次展示,强调"隐蔽"被揭示的感觉
        self.play(
            Write(details1),
            run_time=1.5
        )

        self.play(
            Write(details2),
            run_time=1.5
        )

        self.play(
            Write(details3),
            run_time=1.5
        )

        # ---------------------------------------------------------
        # 5. 添加总结性标注
        # ---------------------------------------------------------
        # 在上方标注"形式逻辑",下方标注"实质推理"

        formal_label = Text("表象:形式逻辑", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        formal_label.next_to(stages, UP, buff=0.3)

        substantive_label = Text("内核:实质推理", font="AR PL UKai CN", font_size=24, color=YELLOW)
        # 放在所有详情的最下方居中
        all_details = VGroup(details1, details2, details3)
        substantive_label.next_to(all_details, DOWN, buff=0.5)

        # 使用虚线框把下半部分框起来,表示这是"隐蔽机制"
        substantive_rect = DashedVMobject(
            SurroundingRectangle(
                VGroup(details1, details2, details3, substantive_label),
                color=YELLOW,
                buff=0.2,
                stroke_width=2
            )
        )

        self.play(
            FadeIn(formal_label),
            FadeIn(substantive_label),
            Create(substantive_rect)
        )
