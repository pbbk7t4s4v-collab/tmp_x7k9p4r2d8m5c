from manim import *

class DeepBSDEMethod(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("5.4 Deep BSDE方法：高维PDE求解",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("22", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念文本 (左侧)
        # 使用VGroup手动管理列表，避免BulletedList的潜在问题
        p1 = Text("• 核心定位：专为高维偏微分方程设计", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        p2 = Text("• 关键结合：反向随机微分方程 + 深度学习", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        p3 = Text("• 优势：有效缓解高维灾难问题", font="AR PL UKai CN", font_size=24, color=BLUE_C)

        text_group = VGroup(p1, p2, p3).arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        text_group.to_edge(LEFT, buff=1.0).shift(UP * 0.5)

        self.play(FadeIn(text_group, shift=RIGHT), run_time=1.0)

        # 3. 网络结构可视化 (下方)
        # 创建时间步上的串联子网络示意图

        # 定义子网络块生成函数
        def create_subnet_block(label_tex, sub_label):
            rect = RoundedRectangle(corner_radius=0.2, height=1.5, width=2.0, color=TEAL, fill_opacity=0.2)
            label = MathTex(label_tex, font_size=28).move_to(rect.get_center() + UP*0.3)
            sub = Text(sub_label, font="AR PL UKai CN", font_size=20, color=GREY_A).next_to(label, DOWN, buff=0.1)
            return VGroup(rect, label, sub)

        # 创建三个主要块：t_0, t_1, ..., t_N
        block_t0 = create_subnet_block("t_0", "子网络 1")
        block_t1 = create_subnet_block("t_1", "子网络 2")
        # 省略号
        dots = MathTex(r"\cdots", font_size=40).set_color(WHITE)
        block_tn = create_subnet_block("t_N", "子网络 N")

        # 排列位置
        diagram_group = VGroup(block_t0, block_t1, dots, block_tn).arrange(RIGHT, buff=0.8)
        diagram_group.to_edge(DOWN, buff=0.8)

        # 连接箭头 (时间递推)
        arrow1 = Arrow(block_t0.get_right(), block_t1.get_left(), buff=0.1, color=YELLOW)
        arrow2 = Arrow(block_t1.get_right(), dots.get_left(), buff=0.1, color=YELLOW)
        arrow3 = Arrow(dots.get_right(), block_tn.get_left(), buff=0.1, color=YELLOW)

        arrows = VGroup(arrow1, arrow2, arrow3)

        # 输出标注 (梯度输出)
        def create_output_arrow(block):
            ar = Arrow(start=block.get_top(), end=block.get_top() + UP*0.8, buff=0.05, color=GREEN)
            lab = MathTex(r"\nabla u", font_size=24, color=GREEN).next_to(ar, UP, buff=0.05)
            return VGroup(ar, lab)

        out0 = create_output_arrow(block_t0)
        out1 = create_output_arrow(block_t1)
        outN = create_output_arrow(block_tn)
        outputs = VGroup(out0, out1, outN)

        # 整体展示
        self.play(Create(diagram_group), run_time=1.5)
        self.play(GrowArrow(arrow1), GrowArrow(arrow2), GrowArrow(arrow3), run_time=1.0)
        self.play(FadeIn(outputs, shift=UP), run_time=1.0)

        # 4. 强调框
        # 强调这是基于BSDE的递推
        frame = SurroundingRectangle(diagram_group, color=ORANGE, buff=0.2)
        frame_label = Text("BSDE 递推关系优化", font="AR PL UKai CN", font_size=22, color=ORANGE)
        frame_label.next_to(frame, DOWN, buff=0.1)

        self.play(
            Create(frame),
            Write(frame_label),
            run_time=1.5
        )
