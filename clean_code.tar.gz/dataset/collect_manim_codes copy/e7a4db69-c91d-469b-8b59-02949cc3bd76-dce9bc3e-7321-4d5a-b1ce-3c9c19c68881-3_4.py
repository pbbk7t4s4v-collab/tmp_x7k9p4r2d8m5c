from manim import *

class TransistorCurrentMeasurement(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("晶体管工作点(集电极电流)测量方法",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("37", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：简化的晶体管电路图示意
        # 电源 VCC
        vcc_label = MathTex("V_{CC}", color=RED).move_to(UP * 2 + LEFT * 4.5)
        top_line = Line(UP * 2 + LEFT * 4.5, UP * 1.5 + LEFT * 4.5)

        # 集电极电阻 Rc
        rc_rect = Rectangle(height=1, width=0.4, color=BLUE).next_to(top_line, DOWN, buff=0)
        rc_label = MathTex("R_C", color=BLUE).next_to(rc_rect, LEFT)

        # 三极管示意 (圆圈 + 内部线条)
        q_circle = Circle(radius=0.4, color=WHITE).next_to(rc_rect, DOWN, buff=0.2)
        q_base = Line(q_circle.get_left(), q_circle.get_center() + LEFT*0.1)
        q_col = Line(q_circle.get_top(), q_circle.get_center() + UP*0.1)
        q_emit = Line(q_circle.get_bottom(), q_circle.get_center() + DOWN*0.1)
        q_label = Text("Q", font="AR PL UKai CN", font_size=20).next_to(q_circle, RIGHT)

        # 发射极电阻 Re
        re_line_top = Line(q_circle.get_bottom(), q_circle.get_bottom() + DOWN*0.2)
        re_rect = Rectangle(height=1, width=0.4, color=GREEN).next_to(re_line_top, DOWN, buff=0)
        re_label = MathTex("R_E", color=GREEN).next_to(re_rect, LEFT)

        # 接地
        gnd_line = Line(re_rect.get_bottom(), re_rect.get_bottom() + DOWN*0.2)
        gnd_symbol = VGroup(
            Line(LEFT*0.2, RIGHT*0.2),
            Line(LEFT*0.1, RIGHT*0.1).shift(DOWN*0.1),
            Line(LEFT*0.05, RIGHT*0.05).shift(DOWN*0.2)
        ).next_to(gnd_line, DOWN, buff=0)

        circuit_group = VGroup(vcc_label, top_line, rc_rect, rc_label,
                               q_circle, q_base, q_col, q_emit, q_label,
                               re_line_top, re_rect, re_label, gnd_line, gnd_symbol)

        self.play(Create(circuit_group), run_time=2)

        # 3. 右侧：核心概念与公式
        # 3.1 间接测量法原理
        method_title = Text("核心思想：间接测量法", font="AR PL UKai CN", font_size=28, color=YELLOW)
        method_title.move_to(UP * 1.5 + RIGHT * 1.5)

        self.play(FadeIn(method_title))

        # 3.2 集电极电流公式演示
        # 测量电压动画 - 在Rc旁边加上大括号
        brace_rc = Brace(rc_rect, RIGHT, buff=0.1)
        urc_text = MathTex("U_{RC}", color=BLUE).next_to(brace_rc, RIGHT)

        formula_ic = MathTex(r"I_C = \frac{U_{RC}}{R_C}", font_size=36)
        formula_ic.next_to(method_title, DOWN, buff=0.5).align_to(method_title, LEFT)

        self.play(
            GrowFromCenter(brace_rc),
            Write(urc_text),
            Write(formula_ic)
        )

        # 3.3 举例计算
        example_box = VGroup()
        ex_text = Text("举例：", font="AR PL UKai CN", font_size=24, color=GRAY_A)
        ex_calc = MathTex(r"R_C=1\,\mathrm{k}\Omega,\ U_{RC}=2\,\mathrm{V}", font_size=26)
        ex_res = MathTex(r"\Rightarrow I_C = 2mA", font_size=26, color=YELLOW)

        # 排版举例
        ex_group = VGroup(ex_text, ex_calc, ex_res).arrange(RIGHT, buff=0.2)
        ex_group.next_to(formula_ic, DOWN, buff=0.4).align_to(formula_ic, LEFT)

        # 强调框
        ex_rect = SurroundingRectangle(ex_group, color=GRAY, buff=0.1, stroke_width=1)

        self.play(
            FadeIn(ex_group),
            Create(ex_rect)
        )

        # 3.4 发射极电流近似法
        # 在Re旁边加括号
        brace_re = Brace(re_rect, RIGHT, buff=0.1)
        ure_text = MathTex("U_{RE}", color=GREEN).next_to(brace_re, RIGHT)

        formula_ie = MathTex(r"I_C \approx I_E = \frac{U_{RE}}{R_E}", font_size=36)
        formula_ie.next_to(ex_group, DOWN, buff=0.6).align_to(ex_group, LEFT)

        self.play(
            GrowFromCenter(brace_re),
            Write(ure_text),
            Write(formula_ie)
        )

        # 3.5 典型数值范围
        values_title = Text("典型工作电流范围：", font="AR PL UKai CN", font_size=24, color=ORANGE)
        values_list = VGroup(
            Text("• 中频放大管: 1 ~ 3 mA", font="AR PL UKai CN", font_size=24),
            Text("• 功率放大管: 数十 mA", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        values_group = VGroup(values_title, values_list).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        values_group.next_to(formula_ie, DOWN, buff=0.5).align_to(formula_ie, LEFT)

        self.play(Write(values_group))
