from manim import *
import numpy as np

class KMeansOptimizationObjective(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (标准模板)
        # ---------------------------------------------------------
        title = Text("K-means 的优化目标",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 左侧：数学公式展示 (SSE)
        # ---------------------------------------------------------
        # SSE 公式
        sse_formula = MathTex(
            r"J = \sum_{i=1}^{k} \sum_{x \in C_i} ||x - \mu_i||^2",
            font_size=40
        )

        formula_label = Text("损失函数 (SSE)", font="AR PL UKai CN", font_size=28, color=YELLOW)
        formula_label.next_to(sse_formula, UP, buff=0.3)

        # 符号解释
        explanation_group = VGroup(
            MathTex(r"C_i", color=BLUE, font_size=30),
            Text(": 第 i 个簇", font="AR PL UKai CN", font_size=24),
            MathTex(r"\mu_i", color=RED, font_size=30),
            Text(": 簇中心", font="AR PL UKai CN", font_size=24),
            MathTex(r"x", color=WHITE, font_size=30),
            Text(": 样本点", font="AR PL UKai CN", font_size=24)
        ).arrange_in_grid(rows=3, cols=2, buff=(0.2, 0.2), cell_alignment=LEFT)

        left_content = VGroup(formula_label, sse_formula, explanation_group).arrange(DOWN, buff=0.5)
        left_content.to_edge(LEFT, buff=1.0).shift(UP*0.5)

        # ---------------------------------------------------------
        # 3. 右侧：可视化示意图
        # ---------------------------------------------------------
        # 定义两个簇的中心和点
        center1_pos = np.array([2.5, 1.5, 0])
        points1_pos = [
            center1_pos + np.array([0.4, 0.3, 0]),
            center1_pos + np.array([-0.3, 0.5, 0]),
            center1_pos + np.array([-0.5, -0.2, 0]),
            center1_pos + np.array([0.2, -0.6, 0]),
        ]

        center2_pos = np.array([4.5, -0.5, 0])
        points2_pos = [
            center2_pos + np.array([0.3, 0.4, 0]),
            center2_pos + np.array([-0.4, 0.2, 0]),
            center2_pos + np.array([0.1, -0.5, 0]),
        ]

        # 创建对象
        c1_dot = Dot(center1_pos, color=RED, radius=0.15)
        c1_label = MathTex(r"\mu_1", color=RED, font_size=24).next_to(c1_dot, UP, buff=0.1)
        c1_points = VGroup(*[Dot(p, color=BLUE_A, radius=0.08) for p in points1_pos])

        c2_dot = Dot(center2_pos, color=RED, radius=0.15)
        c2_label = MathTex(r"\mu_2", color=RED, font_size=24).next_to(c2_dot, UP, buff=0.1)
        c2_points = VGroup(*[Dot(p, color=BLUE_A, radius=0.08) for p in points2_pos])

        # 连接线（表示距离/误差）
        lines = VGroup()
        for p in c1_points:
            line = Line(p.get_center(), c1_dot.get_center(), color=YELLOW, stroke_width=2, stroke_opacity=0.6)
            lines.add(line)
        for p in c2_points:
            line = Line(p.get_center(), c2_dot.get_center(), color=YELLOW, stroke_width=2, stroke_opacity=0.6)
            lines.add(line)

        visual_group = VGroup(c1_dot, c1_label, c1_points, c2_dot, c2_label, c2_points, lines)

        # ---------------------------------------------------------
        # 4. 底部：核心结论
        # ---------------------------------------------------------
        conclusion_text = Text("目标：最小化距离平方和 -> 提高簇内紧凑度",
                             font="AR PL UKai CN", font_size=30, color=GREEN)
        conclusion_text.to_edge(DOWN, buff=1.0)

        conclusion_rect = SurroundingRectangle(conclusion_text, color=GREEN, buff=0.2)

        # ---------------------------------------------------------
        # 5. 动画播放序列
        # ---------------------------------------------------------
        # 展示左侧公式
        self.play(FadeIn(left_content, shift=RIGHT))

        # 展示右侧点和中心
        self.play(
            FadeIn(c1_dot), FadeIn(c1_points), Write(c1_label),
            FadeIn(c2_dot), FadeIn(c2_points), Write(c2_label)
        )

        # 动态画出误差线
        self.play(Create(lines, run_time=1.5))

        # 强调结论
        self.play(Write(conclusion_text))
        self.play(Create(conclusion_rect))
