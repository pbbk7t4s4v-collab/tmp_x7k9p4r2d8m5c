from manim import *

class FluidMechanicsInNature(Scene):
    def construct(self):

        # 1. 设置标题
        title = Text("流体力学与自然现象",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 展示流体力学在自然现象中的应用领域
        examples_header = Text("应用领域：", font_size=28, weight=BOLD)
        examples_list = BulletedList(
            "海洋洋流与大气环流",
            "天气系统形成",
            "河流及地下水运动",
            font_size=28,
            buff=0.3
        )

        content_group = VGroup(examples_header, examples_list).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        content_group.next_to(title_group, DOWN, buff=0.5)

        self.play(Write(examples_header))
        self.play(FadeIn(examples_list, shift=RIGHT, lag_ratio=0.3))

        # 3. 聚焦于气象预报的具体例子
        focus_text = Text("例如：气象预报", font_size=30, color=YELLOW)
        focus_text.next_to(content_group, DOWN, buff=0.6)

        self.play(FadeIn(focus_text, scale=1.2))

        # 4. 创建一个简单的气象示意图
        diagram_group = VGroup()

        # 创建一个表示台风的漩涡
        typhoon_swirl = VGroup(*[
            Arc(radius=0.1 + i * 0.15, start_angle=i * PI / 2, angle=TAU * 0.75, color=WHITE)
            for i in range(3)
        ]).rotate(-PI/2)
        typhoon_swirl.move_to(LEFT * 3)

        # 创建台风的预测路径
        path_arrow = Arrow(
            start=typhoon_swirl.get_center(),
            end=RIGHT * 1.5,
            stroke_width=5,
            color=YELLOW
        ).set_stroke(opacity=0.8)

        # 创建降水区域
        precipitation_area = VGroup(*[Dot(radius=0.04, color=BLUE_A) for _ in range(40)])
        precipitation_area.arrange_in_grid(rows=5, cols=8, buff=0.15).move_to(RIGHT * 3.5)

        # 标签
        typhoon_label = Text("预测台风路径", font_size=24).next_to(path_arrow, UP, buff=0.2)
        precip_label = Text("预测降水分布", font_size=24).next_to(precipitation_area, UP, buff=0.2)

        diagram_group.add(typhoon_swirl, path_arrow, precipitation_area, typhoon_label, precip_label)
        diagram_group.move_to(DOWN * 1.5)

        # 播放动画
        self.play(
            FadeOut(content_group, shift=UP),
            FadeOut(focus_text, shift=UP)
        )

        self.play(
            Create(typhoon_swirl),
            run_time=1.0
        )
        self.play(
            GrowArrow(path_arrow),
            Write(typhoon_label),
            run_time=1.5
        )
        self.play(
            LaggedStart(*[FadeIn(dot, scale=0.5) for dot in precipitation_area], lag_ratio=0.05),
            Write(precip_label),
            run_time=2.0
        )

        # 使用SurroundingRectangle进行强调
        highlight_box = SurroundingRectangle(diagram_group, color=GREEN, buff=0.3)
        self.play(Create(highlight_box))
