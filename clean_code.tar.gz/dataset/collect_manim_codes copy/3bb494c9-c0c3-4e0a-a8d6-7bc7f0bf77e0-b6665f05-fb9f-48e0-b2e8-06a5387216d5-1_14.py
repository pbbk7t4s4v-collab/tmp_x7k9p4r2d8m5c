from manim import *

class WaveEquationLinearization(Scene):
    def construct(self):

        # 1. Title Setup (Standardized Template)
        title = Text("Wave Equations: Linearization in 3D",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # Bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Group and Animate
        title_group = VGroup(title, title_line)
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("14", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Content: Small Perturbation Definition
        # Explaining the variables rho and u based on the lecture notes
        perturb_label = Text("Small Perturbation (Density & Velocity):", font_size=28, color=BLUE_B)

        # State vector: (density, velocity)
        # rho = rho_0(1+s), where s is condensation
        perturb_math = MathTex(
            r"(\rho, u) = (\rho_0(1 + s), u)",
            font_size=36
        )

        perturb_group = VGroup(perturb_label, perturb_math).arrange(DOWN, buff=0.3)
        perturb_group.next_to(title_group, DOWN, buff=1.0)

        # 3. Content: Linearized System of Equations
        # Mass conservation and Momentum conservation
        equation_system = MathTex(
            r"\begin{cases}"
            r"\partial_t s + \mathrm{div} u = 0 \\"
            r"\partial_t u + p'(\rho_0)\nabla s \approx 0"
            r"\end{cases}",
            tex_template=TexTemplate(), # Standard template usually sufficient
            font_size=42
        )

        # Tag (1.1.19)
        eq_tag = MathTex(r"(1.1.19)", font_size=32, color=GRAY)
        eq_tag.next_to(equation_system, RIGHT, buff=0.8)

        # Grouping equation and tag
        eq_main_group = VGroup(equation_system, eq_tag)
        eq_main_group.next_to(perturb_group, DOWN, buff=0.8)

        # Emphasis Box
        rect = SurroundingRectangle(equation_system, color=YELLOW, buff=0.2)
        rect_label = Text("Linearized Isentropic Gas Dynamics", font_size=24, color=YELLOW)
        rect_label.next_to(rect, UP, buff=0.1)

        # 4. Animation Sequence
        # Fade in perturbation concept
        self.play(FadeIn(perturb_group, shift=DOWN), run_time=1.0)

        # Write the system of equations
        self.play(Write(equation_system), run_time=2.0)

        # Show tag and emphasis box
        self.play(
            FadeIn(eq_tag, shift=LEFT),
            Create(rect),
            FadeIn(rect_label),
            run_time=1.5
        )

        # Final wait to keep within 15s limit
