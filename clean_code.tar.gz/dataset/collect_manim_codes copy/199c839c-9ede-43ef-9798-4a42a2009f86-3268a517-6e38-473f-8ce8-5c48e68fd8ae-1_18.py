from manim import *
import numpy as np

class NegationOfNegationScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格遵守模板)
        # ---------------------------------------------------------
        title = Text("否定之否定与螺旋式上升",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("18", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 第一部分：发展周期流程图 (肯定 -> 否定 -> 否定之否定)
        # ---------------------------------------------------------

        # 定义文本内容
        font_style = {"font": "AR PL UKai CN", "font_size": 28}

        item1 = Text("肯定", color=BLUE_C, **font_style)
        item2 = Text("否定", color=RED_C, **font_style)
        item3 = Text("否定之否定", color=GREEN_C, **font_style)

        # 排版：水平排列
        process_group = VGroup(item1, item2, item3).arrange(RIGHT, buff=2.0)
        process_group.shift(UP * 1.0) # 整体上移

        # 箭头
        arrow1 = Arrow(item1.get_right(), item2.get_left(), buff=0.1, color=GREY)
        arrow2 = Arrow(item2.get_right(), item3.get_left(), buff=0.1, color=GREY)

        # 补充说明文本（更高层次）
        note_text = Text("更高层次的回复", font="AR PL UKai CN", font_size=20, color=YELLOW)
        note_text.next_to(item3, DOWN, buff=0.2)

        # 强调框
        rect = SurroundingRectangle(VGroup(item3, note_text), color=YELLOW, buff=0.15)

        # 动画展示流程
        self.play(FadeIn(item1, shift=UP))
        self.play(GrowArrow(arrow1), FadeIn(item2, shift=UP))
        self.play(GrowArrow(arrow2), FadeIn(item3, shift=UP))
        self.play(Write(note_text), Create(rect))

        # ---------------------------------------------------------
        # 3. 第二部分：螺旋式上升可视化 (几何演示)
        # ---------------------------------------------------------

        # 定义坐标系原点位置 (屏幕下方)
        origin_point = DOWN * 2.5

        # 绘制中心轴 (表示总趋势：前进上升)
        axis_line = Arrow(start=origin_point, end=origin_point + UP * 3.5, color=WHITE, buff=0)
        axis_label = Text("总趋势：前进上升", font="AR PL UKai CN", font_size=22, color=WHITE)
        axis_label.next_to(axis_line, RIGHT, buff=0.2).shift(UP * 1)

        # 绘制螺旋线/波浪线 (表示道路：曲折)
        # 使用参数方程绘制垂直方向的正弦波，模拟螺旋上升的侧视图
        spiral_curve = ParametricFunction(
            lambda t: np.array([
                0.6 * np.sin(3 * t),  # x坐标震荡
                t,                    # y坐标上升
                0
            ]),
            t_range=[0, 3.2],
            color=ORANGE
        ).move_to(axis_line.get_center()) # 移动到轴的中心

        spiral_label = Text("道路：曲折迂回", font="AR PL UKai CN", font_size=22, color=ORANGE)
        spiral_label.next_to(spiral_curve, LEFT, buff=0.5).shift(DOWN * 0.5)

        # 动画展示螺旋上升
        self.play(
            GrowArrow(axis_line),
            Write(axis_label)
        )
        self.play(
            Create(spiral_curve, run_time=2),
            FadeIn(spiral_label, shift=RIGHT)
        )
