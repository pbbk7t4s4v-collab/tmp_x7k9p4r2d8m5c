from manim import *

class NetworkFlowScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("网络流与流量分布图",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("65", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 构建图结构 (节点与边)
        # ---------------------------------------------------------
        # 定义节点位置
        pos_s = LEFT * 4 + DOWN * 0.5
        pos_t = RIGHT * 4 + DOWN * 0.5
        pos_a = LEFT * 1 + UP * 1.5
        pos_b = RIGHT * 1 + DOWN * 2.0

        # 创建节点圆圈
        def create_node(pos, label_text, color=BLUE):
            circle = Circle(radius=0.4, color=color, fill_opacity=0.2)
            circle.move_to(pos)
            label = Text(label_text, font="AR PL UKai CN", font_size=24).move_to(pos)
            return VGroup(circle, label)

        node_s = create_node(pos_s, "S", GREEN) # 源点
        node_t = create_node(pos_t, "T", RED)   # 汇点
        node_a = create_node(pos_a, "A", BLUE)
        node_b = create_node(pos_b, "B", BLUE)

        nodes = VGroup(node_s, node_t, node_a, node_b)

        # 创建边 (箭头)
        arrow_sa = Arrow(node_s.get_right(), node_a.get_left(), buff=0.1, color=GREY)
        arrow_sb = Arrow(node_s.get_right(), node_b.get_left(), buff=0.1, color=GREY)
        arrow_at = Arrow(node_a.get_right(), node_t.get_left(), buff=0.1, color=GREY)
        arrow_bt = Arrow(node_b.get_right(), node_t.get_left(), buff=0.1, color=GREY)
        arrow_ab = Arrow(node_a.get_bottom(), node_b.get_top(), buff=0.1, color=GREY)

        edges = VGroup(arrow_sa, arrow_sb, arrow_at, arrow_bt, arrow_ab)

        # ---------------------------------------------------------
        # 3. 流量标签 (Flow/Capacity)
        # ---------------------------------------------------------
        # 辅助函数：创建标签
        def create_label(arrow, flow, cap, direction=UP):
            tex = MathTex(f"{flow}/{cap}", font_size=24, color=YELLOW)
            tex.next_to(arrow.get_center(), direction, buff=0.1)
            return tex

        # 初始状态：流量为0
        lbl_sa = create_label(arrow_sa, 0, 10, UP)
        lbl_sb = create_label(arrow_sb, 0, 5, DOWN)
        lbl_at = create_label(arrow_at, 0, 6, UP)
        lbl_bt = create_label(arrow_bt, 0, 8, DOWN)
        lbl_ab = create_label(arrow_ab, 0, 4, RIGHT)

        labels = VGroup(lbl_sa, lbl_sb, lbl_at, lbl_bt, lbl_ab)

        # ---------------------------------------------------------
        # 4. 概念解释文本
        # ---------------------------------------------------------
        # 位于左上角或右上角的空白处
        concept_text = MathTex(r"0 \le f(u,v) \le c(u,v)", font_size=30, color=WHITE)
        concept_desc = Text("流量不超过容量", font="AR PL UKai CN", font_size=24, color=WHITE)
        concept_group = VGroup(concept_text, concept_desc).arrange(DOWN, buff=0.1)
        concept_group.to_corner(UR, buff=1.0)

        box = SurroundingRectangle(concept_group, color=BLUE, buff=0.2)

        # ---------------------------------------------------------
        # 5. 动画流程
        # ---------------------------------------------------------

        # 展示图结构
        self.play(FadeIn(nodes), Create(edges), run_time=1.5)
        self.play(Write(labels), run_time=1.0)

        # 展示概念约束
        self.play(FadeIn(concept_group), Create(box), run_time=1.0)

        # 模拟流量分配 (Flow Update)
        # S->A->T (Flow 6)
        # S->B->T (Flow 4)
        # A->B (Flow 0)

        new_lbl_sa = create_label(arrow_sa, 6, 10, UP)
        new_lbl_at = create_label(arrow_at, 6, 6, UP) # 满流
        new_lbl_sb = create_label(arrow_sb, 4, 5, DOWN)
        new_lbl_bt = create_label(arrow_bt, 4, 8, DOWN)

        # 强调满流边
        arrow_at_highlight = arrow_at.copy().set_color(ORANGE).set_stroke(width=6)

        self.play(
            Transform(lbl_sa, new_lbl_sa),
            Transform(lbl_at, new_lbl_at),
            Transform(lbl_sb, new_lbl_sb),
            Transform(lbl_bt, new_lbl_bt),
            run_time=2.0
        )

        # 高亮满流边
        full_flow_text = Text("瓶颈边 (满流)", font="AR PL UKai CN", font_size=20, color=ORANGE)
        full_flow_text.next_to(new_lbl_at, UP, buff=0.1)

        self.play(
            Create(arrow_at_highlight),
            FadeIn(full_flow_text),
            run_time=1.0
        )
