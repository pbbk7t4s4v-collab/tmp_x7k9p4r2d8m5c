from manim import *

class ExplainabilityScene(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("可解释性：透视AI决策逻辑",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧文本内容构建
        # 定义文本样式
        text_style = {"font": "AR PL UKai CN", "font_size": 26, "color": WHITE}

        # 核心定义
        p1_text = Text("让人类理解AI的决策依据和推理过程", **text_style)

        # 作用列表
        bullet_1 = Text("• 建立信任的基础", **text_style)
        bullet_2 = Text("• 责任认定与系统调试", **text_style)

        # 重点场景
        p3_text = Text("关键应用：高后果决策场景", font="AR PL UKai CN", font_size=28, color=YELLOW)

        # 组合左侧文本
        left_group = VGroup(
            p1_text,
            VGroup(bullet_1, bullet_2).arrange(DOWN, buff=0.3, aligned_edge=LEFT),
            p3_text
        ).arrange(DOWN, buff=0.8, aligned_edge=LEFT)

        left_group.to_edge(LEFT, buff=0.8).shift(UP * 0.5)

        # 3. 右侧图片内容构建
        # 图片1：展示信任建立与透明度
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/835d5475-a08d-4cd1-935c-338eea91cae9/pictures/3_4/1.png") # 这里期望是一张概念插图，展示一个人正在与一个半透明的AI虚拟形象互动。AI形象内部显示出清晰的逻辑线路或发光的节点，象征着其决策过程是透明和可见的。背景简洁，带有科技感，体现'建立信任'的主题。写实风
        img1.height = 2.2 # 调整大小以适应屏幕
        img1_label = Text("建立信任", font="AR PL UKai CN", font_size=20, color=BLUE_B).next_to(img1, DOWN, buff=0.1)
        group_img1 = Group(img1, img1_label)

        # 图片2：展示高后果决策
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/835d5475-a08d-4cd1-935c-338eea91cae9/pictures/3_4/2.png") # 这里期望是一张高风险决策场景的写实图片，例如医生正在严肃地查看电脑屏幕上的AI辅助诊断结果（如带有AI标注的CT扫描图）。这代表了'高后果决策'场景，强调可解释性在关键领域的重要性。写实风
        img2.height = 2.2 # 调整大小以适应屏幕
        img2_label = Text("高后果决策", font="AR PL UKai CN", font_size=20, color=RED_B).next_to(img2, DOWN, buff=0.1)
        group_img2 = Group(img2, img2_label)

        # 组合右侧图片，垂直排列
        right_group = Group(group_img1, group_img2).arrange(DOWN, buff=0.5)
        right_group.to_edge(RIGHT, buff=1.0).match_y(left_group)

        # 4. 动画展示流程

        # 第一阶段：展示定义与第一张图（建立信任）
        self.play(FadeIn(p1_text, shift=RIGHT))
        self.play(
            Write(bullet_1),
            Write(bullet_2),
            FadeIn(group_img1, shift=LEFT)
        )

        # 第二阶段：展示高后果场景与第二张图
        # 添加强调框
        rect = SurroundingRectangle(p3_text, color=YELLOW, buff=0.1)

        self.play(
            Write(p3_text),
            FadeIn(group_img2, shift=LEFT)
        )
        self.play(Create(rect))
