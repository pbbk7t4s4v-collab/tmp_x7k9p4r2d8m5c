from manim import *

class MultimodalInteraction(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("第三阶段:多模态交互",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("34", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念展示 (中心节点)
        # ---------------------------------------------------------
        # 定义通用字体配置
        my_font = "AR PL UKai CN"

        # 中心文字
        center_text = Text("多模态交互", font=my_font, font_size=36, color=BLUE_A)
        center_sub = Text("自然 · 直观 · 整合", font=my_font, font_size=20, color=GRAY_B)

        # 组合中心内容并排列
        center_content = VGroup(center_text, center_sub).arrange(DOWN, buff=0.15)
        center_content.move_to(DOWN * 0.2) # 稍微下移,避开标题

        # 中心边框
        center_box = SurroundingRectangle(center_content, color=BLUE, buff=0.3, corner_radius=0.2)

        self.play(
            FadeIn(center_content, shift=UP),
            Create(center_box)
        )

        # ---------------------------------------------------------
        # 3. 四大交互方式 (分支节点)
        # ---------------------------------------------------------
        # 定义节点生成函数以保持代码整洁和一致性
        def create_node(title_str, desc_str, position, color_theme):
            t = Text(title_str, font=my_font, font_size=24, color=color_theme)
            d = Text(desc_str, font=my_font, font_size=18, color=WHITE)
            group = VGroup(t, d).arrange(DOWN, buff=0.1)
            group.move_to(position)

            box = SurroundingRectangle(group, color=color_theme, buff=0.15)

            # 箭头连接
            arrow = Arrow(
                start=center_box.get_edge_center(position - center_box.get_center()),
                end=box.get_edge_center((position - center_box.get_center()) * -1),
                buff=0.1,
                color=color_theme,
                stroke_width=2
            )
            return VGroup(group, box, arrow)

        # 定义四个节点的位置和内容
        # 左上:触控
        node_touch = create_node(
            "触控交互", "智能手机/平板",
            LEFT * 4 + UP * 1.2,
            TEAL
        )

        # 右上:语音
        node_voice = create_node(
            "语音交互", "智能音箱/助手",
            RIGHT * 4 + UP * 1.2,
            GREEN
        )

        # 左下:体感
        node_body = create_node(
            "体感交互", "动作捕捉/VR",
            LEFT * 4 + DOWN * 1.8,
            YELLOW
        )

        # 右下:脑机
        node_bci = create_node(
            "脑机接口", "解读大脑信号",
            RIGHT * 4 + DOWN * 1.8,
            RED
        )

        # ---------------------------------------------------------
        # 4. 动画播放序列
        # ---------------------------------------------------------
        # 分组播放,逻辑清晰
        # 先展示左边两个(主流与体感)
        self.play(
            FadeIn(node_touch[0], shift=RIGHT),
            Create(node_touch[1]),
            GrowArrow(node_touch[2]),
            run_time=1
        )

        self.play(
            FadeIn(node_voice[0], shift=LEFT),
            Create(node_voice[1]),
            GrowArrow(node_voice[2]),
            run_time=1
        )

        # 再展示下面两个(进阶技术)
        self.play(
            FadeIn(node_body[0], shift=RIGHT),
            Create(node_body[1]),
            GrowArrow(node_body[2]),
            FadeIn(node_bci[0], shift=LEFT),
            Create(node_bci[1]),
            GrowArrow(node_bci[2]),
            run_time=1.5
        )

        # 最后的停顿
