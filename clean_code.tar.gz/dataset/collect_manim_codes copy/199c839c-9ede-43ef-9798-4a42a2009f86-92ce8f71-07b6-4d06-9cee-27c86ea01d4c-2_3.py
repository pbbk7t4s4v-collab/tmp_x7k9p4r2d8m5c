from manim import *

class WhyStudyOS(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("为什么学习操作系统？",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心架构图 (左侧)
        # 上层应用
        app_text = Text("上层应用", font="AR PL UKai CN", font_size=28)
        app_rect = SurroundingRectangle(app_text, color=BLUE_C, fill_opacity=0.2, fill_color=BLUE_C, buff=0.2)
        app_group = VGroup(app_rect, app_text)

        # 操作系统 (核心)
        os_text = Text("操作系统", font="AR PL UKai CN", font_size=32, weight=BOLD, color=YELLOW)
        os_rect = SurroundingRectangle(os_text, color=YELLOW, fill_opacity=0.2, fill_color=YELLOW, buff=0.3)
        os_group = VGroup(os_rect, os_text)

        # 底层硬件
        hw_text = Text("底层硬件", font="AR PL UKai CN", font_size=28)
        hw_rect = SurroundingRectangle(hw_text, color=GREY, fill_opacity=0.2, fill_color=GREY, buff=0.2)
        hw_group = VGroup(hw_rect, hw_text)

        # 垂直排列
        stack_group = VGroup(app_group, os_group, hw_group).arrange(DOWN, buff=0.8)
        stack_group.move_to(LEFT * 3 + DOWN * 0.5)

        # 连接箭头
        arrow_1 = DoubleArrow(os_rect.get_top(), app_rect.get_bottom(), buff=0.05, color=WHITE)
        arrow_2 = DoubleArrow(os_rect.get_bottom(), hw_rect.get_top(), buff=0.05, color=WHITE)

        # 3. 右侧说明文字
        # 内功概念
        concept_text = Text("计算机专业的内功", font="AR PL UKai CN", font_size=36, color=YELLOW)
        concept_text.move_to(RIGHT * 2 + UP * 1)

        # 指向内功的箭头
        concept_arrow = Arrow(os_rect.get_right(), concept_text.get_left(), color=YELLOW, buff=0.2)

        # 好处列表
        benefit_1 = Text("编写高性能代码", font="AR PL UKai CN", font_size=28, color=GREEN)
        benefit_2 = Text("编写高可靠代码", font="AR PL UKai CN", font_size=28, color=GREEN)

        benefits_group = VGroup(benefit_1, benefit_2).arrange(DOWN, buff=0.4, aligned_edge=LEFT)
        benefits_group.next_to(concept_text, DOWN, buff=0.8)

        # 装饰性括号
        brace = Brace(benefits_group, direction=LEFT, color=WHITE)

        # 4. 动画流程
        # 4.1 显示三层架构
        self.play(FadeIn(app_group), FadeIn(hw_group))
        self.play(
            GrowFromCenter(os_group),
            Create(arrow_1),
            Create(arrow_2)
        )

        # 4.2 强调核心地位
        self.play(
            Indicate(os_text, color=YELLOW),
            Create(concept_arrow),
            Write(concept_text)
        )

        # 4.3 展示学习收益
        self.play(
            GrowFromCenter(brace),
            FadeIn(benefits_group, shift=RIGHT)
        )
