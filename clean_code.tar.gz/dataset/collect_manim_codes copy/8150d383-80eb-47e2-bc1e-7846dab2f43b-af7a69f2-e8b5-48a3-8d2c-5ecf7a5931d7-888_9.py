from manim import *

class EulerAngleScene(Scene):
    def construct(self):

        # 1. Title Setup (Standard Template)
        title = Text("Rigid Body Motion: Euler Angles",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Content Layout - Left Side (Explanation)
        # Definition
        def_text = Paragraph(
            "Euler Angle describes orientation via",
            "three sequential rotations.",
            font_size=24,
            line_spacing=1.0,
            color=LIGHT_GREY
        )

        # Steps (Z-Y-X Sequence)
        # Using separate Tex objects instead of BulletedList to avoid LaTeX errors and have better control
        step1 = Tex(r"1. Rotate around Z: \textbf{Yaw} ($\alpha$)", font_size=28, color=RED_B)
        step2 = Tex(r"2. Rotate around Y: \textbf{Pitch} ($\beta$)", font_size=28, color=GREEN_B)
        step3 = Tex(r"3. Rotate around X: \textbf{Roll} ($\gamma$)", font_size=28, color=BLUE_B)

        text_group = VGroup(def_text, step1, step2, step3).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        text_group.to_edge(LEFT, buff=1.0)
        text_group.shift(UP * 0.2) # Slight adjustment

        # Decoration box
        box = SurroundingRectangle(text_group, color=WHITE, buff=0.3, corner_radius=0.2)

        # 3. Content Layout - Right Side (3D Visualization)
        # Create a 3D axis system
        axes = ThreeDAxes(
            x_range=[-2, 2], y_range=[-2, 2], z_range=[-2, 2],
            x_length=4, y_length=4, z_length=4,
            axis_config={"include_tip": True}
        )

        # Labels for axes
        x_label = axes.get_x_axis_label("X")
        y_label = axes.get_y_axis_label("Y")
        z_label = axes.get_z_axis_label("Z")
        labels = VGroup(x_label, y_label, z_label)

        # Rotation indicators (Arcs)
        # Yaw (Z-axis rotation)
        arc_z = Arc(radius=0.8, start_angle=0, angle=PI/1.5, color=RED_B, arc_center=axes.c2p(0,0,0))
        arc_z.shift(axes.c2p(0,0,1.5) - axes.c2p(0,0,0)) # Move up Z axis
        yaw_label = MathTex(r"\alpha", color=RED_B, font_size=24).next_to(arc_z, RIGHT, buff=0.1)

        # Pitch (Y-axis rotation) - Visualized as an arc around Y
        # We construct the arc in XY plane then rotate it to be around Y
        arc_y = Arc(radius=0.8, start_angle=0, angle=PI/1.5, color=GREEN_B, arc_center=ORIGIN)
        arc_y.rotate(PI/2, axis=RIGHT) # Rotate to be around Y axis
        arc_y.shift(axes.c2p(0,1.5,0)) # Move along Y axis
        pitch_label = MathTex(r"\beta", color=GREEN_B, font_size=24).next_to(arc_y, UP, buff=0.1)

        # Roll (X-axis rotation)
        arc_x = Arc(radius=0.8, start_angle=0, angle=PI/1.5, color=BLUE_B, arc_center=ORIGIN)
        arc_x.rotate(PI/2, axis=UP) # Rotate to be around X axis
        arc_x.shift(axes.c2p(1.5,0,0)) # Move along X axis
        roll_label = MathTex(r"\gamma", color=BLUE_B, font_size=24).next_to(arc_x, UP, buff=0.1)

        # Grouping the visual elements
        visual_group = VGroup(axes, labels, arc_z, yaw_label, arc_y, pitch_label, arc_x, roll_label)

        # Orientation of the 3D model for better viewing
        visual_group.rotate(30*DEGREES, axis=RIGHT).rotate(-45*DEGREES, axis=UP)
        visual_group.to_edge(RIGHT, buff=1.5)
        visual_group.shift(DOWN * 0.5)

        # 4. Animation Sequence
        # Intro Text
        self.play(FadeIn(def_text, shift=UP))
        self.play(Create(box))

        # Intro Axes
        self.play(Create(axes), Write(labels), run_time=1.5)

        # Step 1: Yaw
        self.play(
            Write(step1),
            Create(arc_z),
            Write(yaw_label),
            run_time=1.5
        )

        # Step 2: Pitch
        self.play(
            Write(step2),
            Create(arc_y),
            Write(pitch_label),
            run_time=1.5
        )

        # Step 3: Roll
        self.play(
            Write(step3),
            Create(arc_x),
            Write(roll_label),
            run_time=1.5
        )
