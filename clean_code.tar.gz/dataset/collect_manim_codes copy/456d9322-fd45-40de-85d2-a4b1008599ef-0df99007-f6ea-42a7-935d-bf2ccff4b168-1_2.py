from manim import *

class HeapOrderProperty(Scene):
    def construct(self):

        # 1. 标题部分
        title = Text("堆序性质 (Heap-Order Property)",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心规则文本
        core_rule_text = Text(
            "核心规则：任意节点的值与其子节点存在特定大小关系",
            font_size=24,
            font="AR PL UKai CN",
            color=BLUE_A
        ).next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(core_rule_text, shift=DOWN))

        # 3. 可视化演示：大顶堆 vs 小顶堆
        # 辅助函数：创建简单的节点和连线
        def create_node(val, pos, color=WHITE, radius=0.4):
            circle = Circle(radius=radius, color=color, fill_opacity=0.2, fill_color=color).move_to(pos)
            num = Text(str(val), font_size=30).move_to(pos)
            return VGroup(circle, num)

        # 左侧：大顶堆示例
        # 位置定义
        left_center = LEFT * 3.5 + DOWN * 0.5

        # 节点
        max_root = create_node("9", left_center + UP * 1.0, color=RED)
        max_l = create_node("7", left_center + LEFT * 1.2 + DOWN * 0.5)
        max_r = create_node("6", left_center + RIGHT * 1.2 + DOWN * 0.5)

        # 连线
        line_max_l = Line(max_root.get_bottom(), max_l.get_top())
        line_max_r = Line(max_root.get_bottom(), max_r.get_top())

        max_heap_group = VGroup(line_max_l, line_max_r, max_root, max_l, max_r)

        # 标签
        max_label = Text("大顶堆 (Max Heap)", font="AR PL UKai CN", font_size=20, color=RED).next_to(max_root, UP)
        max_math = Text("Val(parent) ≥ Val(child)", font_size=24, font="AR PL UKai CN", color=RED_B).next_to(max_heap_group, DOWN, buff=0.2)

        # 右侧：小顶堆示例
        right_center = RIGHT * 3.5 + DOWN * 0.5

        min_root = create_node("2", right_center + UP * 1.0, color=GREEN)
        min_l = create_node("5", right_center + LEFT * 1.2 + DOWN * 0.5)
        min_r = create_node("8", right_center + RIGHT * 1.2 + DOWN * 0.5)

        line_min_l = Line(min_root.get_bottom(), min_l.get_top())
        line_min_r = Line(min_root.get_bottom(), min_r.get_top())

        min_heap_group = VGroup(line_min_l, line_min_r, min_root, min_l, min_r)

        min_label = Text("小顶堆 (Min Heap)", font="AR PL UKai CN", font_size=20, color=GREEN).next_to(min_root, UP)
        min_math = Text("Val(parent) ≤ Val(child)", font_size=24, font="AR PL UKai CN", color=GREEN_B).next_to(min_heap_group, DOWN, buff=0.2)

        # 播放树的生成
        self.play(
            Create(max_heap_group),
            FadeIn(max_label),
            Create(min_heap_group),
            FadeIn(min_label),
            run_time=1.5
        )
        self.play(Write(max_math), Write(min_math))

        # 4. 与BST的区别 (重点强调)
        # 放在中间下方
        note_bg = Rectangle(height=1.5, width=6, color=YELLOW, fill_opacity=0.1)
        note_bg.to_edge(DOWN, buff=0.5)

        note_title = Text("区别于二叉搜索树 (BST)", font="AR PL UKai CN", font_size=22, color=YELLOW).move_to(note_bg.get_top() + DOWN * 0.3)
        note_content = Text("堆不限制左右孩子的大小关系", font="AR PL UKai CN", font_size=26).next_to(note_title, DOWN, buff=0.2)

        note_group = VGroup(note_bg, note_title, note_content)

        self.play(GrowFromCenter(note_group))

        # 强调：在图中展示左右孩子无序性
        # 例如大顶堆中 7 和 6 (左大右小)，小顶堆中 5 和 8 (左小右大) -> 说明没有顺序
        arrow_l = Arrow(start=max_l.get_bottom()+DOWN*0.1, end=max_r.get_bottom()+DOWN*0.1, buff=0.1, color=YELLOW, path_arc=0.5)
        arrow_r = Arrow(start=min_l.get_bottom()+DOWN*0.1, end=min_r.get_bottom()+DOWN*0.1, buff=0.1, color=YELLOW, path_arc=0.5)

        unordered_text = Text("左右无序", font="AR PL UKai CN", font_size=18, color=YELLOW)
        unordered_text.move_to(ORIGIN).shift(DOWN * 0.5) # 放在中间

        self.play(
            Create(arrow_l),
            Create(arrow_r),
            FadeIn(unordered_text),
            run_time=1.0
        )
