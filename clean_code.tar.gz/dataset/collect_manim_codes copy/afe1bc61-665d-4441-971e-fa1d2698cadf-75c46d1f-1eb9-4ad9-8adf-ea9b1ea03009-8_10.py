from manim import *

class RequirementPrioritization(Scene):
    def construct(self):

        # ---------------------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------------------
        title = Text("需求优先级确定",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("54", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------------------
        # 2. 左侧:常用方法列表
        # ---------------------------------------------------------------------
        method_label = Text("常用优先级方法:", font="AR PL UKai CN", font_size=26, color=BLUE_B)
        method_label.to_edge(LEFT, buff=1).shift(UP * 1.5)

        # 手动创建列表以精确控制
        m_item1 = Text("1. MoSCoW方法", font="AR PL UKai CN", font_size=24, color=WHITE)
        m_item2 = Text("2. Kano模型", font="AR PL UKai CN", font_size=24, color=YELLOW) # 高亮Kano

        # 排版
        list_group = VGroup(m_item1, m_item2).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        list_group.next_to(method_label, DOWN, aligned_edge=LEFT, buff=0.3)

        left_group = VGroup(method_label, list_group)

        self.play(FadeIn(left_group, shift=RIGHT))

        # 强调框选 Kano
        rect = SurroundingRectangle(m_item2, color=YELLOW, buff=0.1)
        self.play(Create(rect, run_time=0.5))

        # ---------------------------------------------------------------------
        # 3. 右侧:Kano模型五类需求可视化
        # ---------------------------------------------------------------------
        # 定义数据:(类型名称, 描述, 颜色)
        kano_data = [
            ("基本型需求", "必须有,没有很不满意", RED),
            ("期望型需求", "越多越满意", BLUE),
            ("兴奋型需求", "意想不到的惊喜", GOLD),
            ("无差异需求", "有没有都无所谓", GREY),
            ("反向需求", "有了反而不满意", MAROON),
        ]

        kano_items = VGroup()

        for name, desc, col in kano_data:
            # 每一行的组
            row = VGroup()
            # 类型名
            t_name = Text(name, font="AR PL UKai CN", font_size=22, color=col, weight=BOLD)
            # 冒号
            t_colon = Text(" : ", font="AR PL UKai CN", font_size=22, color=WHITE)
            # 描述
            t_desc = Text(desc, font="AR PL UKai CN", font_size=20, color=WHITE)

            # 组合一行
            row.add(t_name, t_colon, t_desc)
            row.arrange(RIGHT, buff=0.1, aligned_edge=DOWN)
            kano_items.add(row)

        # 整体纵向排列
        kano_items.arrange(DOWN, buff=0.4, aligned_edge=LEFT)

        # 放置在屏幕右侧
        kano_items.next_to(left_group, RIGHT, buff=1.5).shift(DOWN * 0.2)

        # ---------------------------------------------------------------------
        # 4. 动画展示 Kano 详情
        # ---------------------------------------------------------------------
        # 简单的箭头指向
        arrow = Arrow(start=rect.get_right(), end=kano_items.get_left(), color=YELLOW, buff=0.2)
        self.play(GrowArrow(arrow, run_time=0.5))

        # 依次显示五类需求
        for item in kano_items:
            self.play(
                FadeIn(item, shift=LEFT * 0.5),
                run_time=0.4  # 保持快速,控制总时长
            )
