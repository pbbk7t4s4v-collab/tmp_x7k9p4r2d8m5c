from manim import *

class ConsumptionFunctionScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (标准模板)
        # ---------------------------------------------------------
        title = Text("消费函数理论详解",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心公式展示
        # ---------------------------------------------------------
        # 公式：C = C_0 + c(Y - T)
        formula = MathTex(
            r"C", r"=", r"C_0", r"+", r"c", r"(Y - T)",
            font_size=48
        )
        # 为关键变量着色以便与下方对应
        formula[2].set_color(RED)    # C_0
        formula[4].set_color(YELLOW) # c

        formula.next_to(title_line, DOWN, buff=0.5)

        # 强调框
        box = SurroundingRectangle(formula, color=BLUE, buff=0.2)

        self.play(
            Write(formula),
            Create(box)
        )

        # ---------------------------------------------------------
        # 3. 可视化布局：左侧图表，右侧解释
        # ---------------------------------------------------------

        # --- 左侧：坐标系图示 ---
        # 创建坐标轴
        axes = Axes(
            x_range=[0, 6, 1],
            y_range=[0, 5, 1],
            x_length=5,
            y_length=3.5,
            axis_config={"include_tip": True, "tip_width": 0.2, "tip_height": 0.2},
        ).add_coordinates([0])

        # 轴标签
        x_label = axes.get_x_axis_label(MathTex("Y-T"), edge=DOWN, direction=DOWN, buff=0.2)
        y_label = axes.get_y_axis_label(MathTex("C"), edge=LEFT, direction=LEFT, buff=0.2)
        labels = VGroup(x_label, y_label)

        # 绘制消费曲线 (线性函数 C = 1 + 0.5x)
        c0_val = 1
        slope = 0.5
        graph_line = axes.plot(lambda x: c0_val + slope * x, color=BLUE_A, x_range=[0, 5.5])

        # 截距点 (C_0)
        intercept_dot = Dot(axes.c2p(0, c0_val), color=RED)
        intercept_label = MathTex("C_0", color=RED, font_size=24).next_to(intercept_dot, LEFT, buff=0.1)

        # 组合图表元素
        plot_group = VGroup(axes, labels, graph_line, intercept_dot, intercept_label)
        plot_group.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # --- 右侧：变量文字解释 ---
        def create_explanation(tex, text_cn, color=WHITE):
            # 使用 VGroup 组合数学符号和中文解释
            symbol = MathTex(tex, color=color)
            desc = Text(text_cn, font="AR PL UKai CN", font_size=22, color=WHITE)
            return VGroup(symbol, desc).arrange(RIGHT, buff=0.3)

        # 创建解释行
        line1 = create_explanation("C_0", "自发性消费 (截距)", RED)
        line2 = create_explanation("c", "边际消费倾向 (斜率)", YELLOW)
        line2_sub = MathTex(r"0 < c < 1", font_size=20, color=YELLOW).next_to(line2, DOWN, buff=0.1, aligned_edge=LEFT)
        line3 = create_explanation("Y", "国民收入")
        line4 = create_explanation("T", "税收")

        # 组合文本块
        text_block = VGroup(line1, line2, line2_sub, line3, line4).arrange(DOWN, buff=0.35, aligned_edge=LEFT)
        text_block.next_to(plot_group, RIGHT, buff=1.0)

        # ---------------------------------------------------------
        # 4. 动画流程
        # ---------------------------------------------------------

        # 第一步：显示坐标轴和基本变量解释
        self.play(
            FadeIn(axes),
            Write(labels),
            FadeIn(line3),
            FadeIn(line4),
            run_time=1.0
        )

        # 第二步：显示截距 C_0 和对应的解释
        self.play(
            FadeIn(intercept_dot),
            Write(intercept_label),
            FadeIn(line1),
            run_time=1.0
        )

        # 第三步：画出函数线并显示斜率 c 的解释
        self.play(
            Create(graph_line),
            FadeIn(line2),
            Write(line2_sub),
            run_time=1.5
        )
