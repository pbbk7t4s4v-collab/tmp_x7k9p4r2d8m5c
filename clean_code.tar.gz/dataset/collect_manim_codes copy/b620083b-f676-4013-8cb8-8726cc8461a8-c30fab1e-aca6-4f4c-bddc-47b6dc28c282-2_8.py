from manim import *

class TDistributionConfidence(Scene):
    def construct(self):

        # 1. 标题设置 (符合模板要求)
        title = Text("t分布置信区间与测量次数",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("16", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心公式部分
        # 说明文字
        intro_text = Text("置信度一般取 0.95，对应的置信区间公式：",
                         font="AR PL UKai CN", font_size=26, color=LIGHT_GRAY)
        intro_text.next_to(title_line, DOWN, buff=0.6)

        # 数学公式
        formula = MathTex(
            r"x = \bar{x} \pm t_{0.95}\sigma_{\bar{x}} = \bar{x} \pm \frac{t_{0.95}}{\sqrt{n}}\sigma_x",
            font_size=36,
            color=WHITE
        )
        formula.next_to(intro_text, DOWN, buff=0.4)

        self.play(
            FadeIn(intro_text),
            Write(formula)
        )

        # 3. 数据可视化 (不同n对应的t值)
        # 标签
        data_label = Text("不同测量次数 n 对应的 t 因子值：",
                         font="AR PL UKai CN", font_size=26, color=BLUE_B)
        data_label.next_to(formula, DOWN, buff=0.8)
        data_label.to_edge(LEFT, buff=1.5)

        # 数据列构建
        data_pairs = [
            ("3", "2.48"),
            ("4", "1.59"),
            ("5", "1.24"),
            ("6", "1.05"),
            ("7", "0.926")
        ]

        columns = VGroup()
        for n_val, t_val in data_pairs:
            # 每一列包含 n值 和 t值
            col = VGroup(
                MathTex(f"n={n_val}", font_size=30, color=WHITE),
                MathTex(f"{t_val}", font_size=30, color=YELLOW)
            ).arrange(DOWN, buff=0.25)
            columns.add(col)

        # 横向排列所有列
        columns.arrange(RIGHT, buff=0.8)
        columns.next_to(data_label, DOWN, buff=0.4)
        columns.set_x(0) # 居中显示

        self.play(
            FadeIn(data_label),
            FadeIn(columns, lag_ratio=0.1)
        )

        # 4. 强调 n=6 (一般推荐值)
        # 获取 n=6 对应的那一列 (列表索引为3)
        target_col = columns[3]

        # 创建强调框
        highlight_rect = SurroundingRectangle(target_col, color=RED, buff=0.15)

        # 强调文字
        highlight_text = Text("一般取测量次数为 6",
                            font="AR PL UKai CN", font_size=22, color=RED)
        highlight_text.next_to(highlight_rect, DOWN, buff=0.2)

        self.play(
            Create(highlight_rect),
            Write(highlight_text)
        )
