from manim import *

class IntegralAreaAccumulation(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("定积分的几何意义：面积累积",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：公式与概念定义
        # 数学公式
        formula = MathTex(r"\int_a^b f(x)\,dx", font_size=48)

        # 概念说明文字
        text_lines = VGroup(
            Text("定积分表示函数曲线与", font="AR PL UKai CN", font_size=26),
            Text("x轴之间区域的带符号面积", font="AR PL UKai CN", font_size=26, color=YELLOW),
            Text("面积随积分上限增加而累积", font="AR PL UKai CN", font_size=22, color=GRAY_A)
        ).arrange(DOWN, buff=0.3, aligned_edge=LEFT)

        # 组合左侧内容
        left_content = VGroup(formula, text_lines).arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        left_content.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 强调框
        rect = SurroundingRectangle(formula, color=BLUE, buff=0.2)

        # 3. 右侧：几何图像可视化
        # 创建坐标系
        ax = Axes(
            x_range=[0, 6, 1],
            y_range=[0, 5, 1],
            x_length=6,
            y_length=4,
            axis_config={"include_tip": True, "tip_shape": StealthTip},
        ).to_edge(RIGHT, buff=0.8).shift(DOWN * 0.5)

        labels = ax.get_axis_labels(x_label="x", y_label="f(x)")

        # 定义函数 f(x) = 0.2(x-3)^2 + 1.5 (开口向上的抛物线片段)
        def func(x):
            return 0.2 * (x - 3)**2 + 1.5

        # 绘制曲线
        curve = ax.plot(func, x_range=[0.5, 5.5], color=BLUE_C, stroke_width=3)

        # 标记积分区间 [a, b]
        a_val, b_val = 1.0, 5.0
        label_a = MathTex("a", font_size=24).next_to(ax.c2p(a_val, 0), DOWN, buff=0.2)
        label_b = MathTex("b", font_size=24).next_to(ax.c2p(b_val, 0), DOWN, buff=0.2)

        # 4. 动画展示流程
        # 第一步:展示文字和公式
        self.play(
            Write(left_content),
            Create(rect),
            run_time=1.5
        )

        # 第二步:展示坐标系和曲线
        self.play(
            Create(ax),
            Write(labels),
            Create(curve),
            FadeIn(label_a),
            FadeIn(label_b),
            run_time=1.5
        )

        # 第三步:动态演示面积累积过程
        # 使用 ValueTracker 控制积分上限的移动
        x_tracker = ValueTracker(a_val)

        # 动态绘制面积 (always_redraw 确保每一帧都重新计算)
        area = always_redraw(lambda: ax.get_area(
            curve,
            x_range=[a_val, x_tracker.get_value()],
            color=BLUE,
            opacity=0.5
        ))

        # 动态扫描线 (表示当前的积分上限位置)
        scanner_line = always_redraw(lambda: Line(
            start=ax.c2p(x_tracker.get_value(), 0),
            end=ax.c2p(x_tracker.get_value(), func(x_tracker.get_value())),
            color=YELLOW,
            stroke_width=4
        ))

        # 添加动态元素到场景
        self.add(area, scanner_line)

        # 播放数值变化动画,从 a 到 b
        self.play(
            x_tracker.animate.set_value(b_val),
            run_time=4,
            rate_func=linear
        )

        # 结束停顿
