from manim import *

class UNCLOSQuestionSummary(Scene):
    def construct(self):

        # 1. 标题设置（严格遵守模板）
        title = Text("问题引导总结：UNCLOS的作用与局限",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心问题展示
        # 使用一个思考气泡或框图来展示核心问题
        question_text = Text("《联合国海洋法公约》\n是否能够解决未来海洋治理中的\n所有问题？",
                            font="AR PL UKai CN",
                            font_size=36,
                            color=BLUE_A,
                            line_spacing=1.2)

        question_box = SurroundingRectangle(question_text, color=BLUE, buff=0.3, corner_radius=0.2)
        question_group = VGroup(question_box, question_text).move_to(UP * 1.0)

        self.play(FadeIn(question_group, shift=DOWN))

        # 3. 概念可视化：天平/对比图
        # 左侧：公约的基石作用
        left_content = VGroup(
            Text("基石作用", font="AR PL UKai CN", font_size=28, color=GREEN),
            Text("确立基本法律框架", font="AR PL UKai CN", font_size=24, color=WHITE),
            Text("划定管辖海域", font="AR PL UKai CN", font_size=24, color=WHITE)
        ).arrange(DOWN, buff=0.2)

        left_box = SurroundingRectangle(left_content, color=GREEN, buff=0.2)
        left_group = VGroup(left_box, left_content).move_to(LEFT * 3.5 + DOWN * 1.5)

        # 右侧：未来的挑战
        right_content = VGroup(
            Text("未来挑战", font="AR PL UKai CN", font_size=28, color=RED),
            Text("新兴技术(深海采矿)", font="AR PL UKai CN", font_size=24, color=WHITE),
            Text("气候变化影响", font="AR PL UKai CN", font_size=24, color=WHITE),
            Text("生物多样性保护", font="AR PL UKai CN", font_size=24, color=WHITE)
        ).arrange(DOWN, buff=0.2)

        right_box = SurroundingRectangle(right_content, color=RED, buff=0.2)
        right_group = VGroup(right_box, right_content).move_to(RIGHT * 3.5 + DOWN * 1.5)

        # 4. 动画展示对比
        self.play(Create(left_box), Write(left_content))
        self.play(Create(right_box), Write(right_content))

        # 5. 结论箭头与文字
        # 从中间画一个箭头指向下方,表示结论
        arrow = Arrow(start=UP * 0.5, end=DOWN * 2.5, color=YELLOW).move_to(DOWN * 1.5)

        conclusion_text = Text("结论：它是基础，但非万能",
                             font="AR PL UKai CN",
                             font_size=32,
                             color=YELLOW)
        conclusion_text.next_to(arrow, DOWN, buff=0.2)
        # 确保结论文字不超出屏幕底部
        if conclusion_text.get_bottom()[1] < -3.8:
            conclusion_text.shift(UP * 0.5)
            arrow.scale(0.8)
            arrow.next_to(question_group, DOWN, buff=0.2)
            conclusion_text.next_to(arrow, DOWN, buff=0.2)

        self.play(GrowArrow(arrow))
        self.play(Write(conclusion_text))

        # 6. 最后的强调
        self.play(Indicate(conclusion_text, color=ORANGE))
