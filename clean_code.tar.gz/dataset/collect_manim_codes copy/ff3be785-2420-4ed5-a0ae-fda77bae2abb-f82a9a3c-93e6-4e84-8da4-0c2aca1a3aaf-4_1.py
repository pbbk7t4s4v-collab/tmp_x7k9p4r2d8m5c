from manim import *

class BMILimitations(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (符合模板要求)
        # ---------------------------------------------------------
        title = Text("BMI 的局限性",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 左侧文本内容 (核心盲区讲解)
        # ---------------------------------------------------------
        # 使用 VGroup 手动排列文本,避免 BulletedList 的兼容性和中文字体问题
        t1 = Text("• 核心盲区:", font="AR PL UKai CN", font_size=26, color=YELLOW)
        t1_sub = Text("  无法区分"肌肉"与"脂肪"", font="AR PL UKai CN", font_size=24, color=WHITE)

        t2 = Text("• 案例对比:", font="AR PL UKai CN", font_size=26, color=YELLOW)
        t2_sub1 = Text("  - 健美运动员 (肌肉发达)", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        t2_sub2 = Text("  - 普通肥胖者 (脂肪堆积)", font="AR PL UKai CN", font_size=24, color=RED_B)

        # 组合文本
        text_group = VGroup(t1, t1_sub, t2, t2_sub1, t2_sub2).arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        text_group.to_edge(LEFT, buff=1).shift(UP * 0.5)

        self.play(FadeIn(text_group, shift=RIGHT))

        # ---------------------------------------------------------
        # 3. 右侧可视化 (几何图形对比)
        # ---------------------------------------------------------
        # 定义两个矩形代表两人,高度相同代表身高相同

        # 健美运动员 (密度大,体积相对紧凑,用蓝色表示肌肉)
        muscle_rect = Rectangle(height=3.0, width=1.0, color=BLUE, fill_opacity=0.6)
        muscle_label = Text("健美\n运动员", font="AR PL UKai CN", font_size=20).next_to(muscle_rect, UP)
        muscle_text = Text("肌肉", font="AR PL UKai CN", font_size=20, color=WHITE).move_to(muscle_rect)

        muscle_group = VGroup(muscle_rect, muscle_label, muscle_text)

        # 肥胖者 (密度小,体积相对大,用红色表示脂肪,但为了演示BMI盲区,此处强调身高体重数据一致)
        # 视觉上让肥胖者稍微宽一点点暗示体积不同,但标注相同的BMI
        fat_rect = Rectangle(height=3.0, width=1.4, color=RED, fill_opacity=0.6)
        fat_label = Text("普通\n肥胖者", font="AR PL UKai CN", font_size=20).next_to(fat_rect, UP)
        fat_text = Text("脂肪", font="AR PL UKai CN", font_size=20, color=WHITE).move_to(fat_rect)

        fat_group = VGroup(fat_rect, fat_label, fat_text)

        # 排列图形
        visual_group = VGroup(muscle_group, fat_group).arrange(RIGHT, buff=1.5)
        visual_group.to_edge(RIGHT, buff=1.5).shift(UP * 0.2)

        # 动画展示图形
        self.play(
            DrawBorderThenFill(muscle_rect),
            DrawBorderThenFill(fat_rect),
            Write(muscle_label),
            Write(fat_label),
            Write(muscle_text),
            Write(fat_text)
        )

        # ---------------------------------------------------------
        # 4. 结论展示 (BMI 计算结果相同)
        # ---------------------------------------------------------
        # 添加连线和公式
        brace = Brace(visual_group, DOWN)
        bmi_eq = MathTex(r"BMI_{A} = BMI_{B}").next_to(brace, DOWN, buff=0.1)

        result_text = Text("身体成分截然不同!", font="AR PL UKai CN", font_size=24, color=ORANGE)
        result_text.next_to(bmi_eq, DOWN, buff=0.2)

        # 强调框
        surround_rect = SurroundingRectangle(result_text, color=YELLOW, buff=0.15)

        self.play(GrowFromCenter(brace))
        self.play(Write(bmi_eq))
        self.play(FadeIn(result_text, shift=UP))
        self.play(Create(surround_rect))
