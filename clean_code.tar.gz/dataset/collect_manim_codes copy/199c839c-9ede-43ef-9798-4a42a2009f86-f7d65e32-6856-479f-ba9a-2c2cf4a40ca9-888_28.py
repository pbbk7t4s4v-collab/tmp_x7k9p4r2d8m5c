from manim import *

class HardSphereModel(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("硬球模型：最简化的排斥势",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("28", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧内容：公式与文字描述
        # 数学定义
        formula = MathTex(
            r"u(r) = \begin{cases} \infty & r < \sigma \\ 0 & r \ge \sigma \end{cases}",
            font_size=40
        )

        # 文字说明
        desc_group = VGroup(
            Text("• 物理假设：不可重叠的刚性球体", font="AR PL UKai CN", font_size=24, color=BLUE_A),
            Text("• 特点：仅含短程排斥，无吸引", font="AR PL UKai CN", font_size=24, color=RED_A),
            Text("• 适用：理想气体的几何碰撞", font="AR PL UKai CN", font_size=24, color=WHITE)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.3)

        left_content = VGroup(formula, desc_group).arrange(DOWN, aligned_edge=LEFT, buff=0.6)
        left_content.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 3. 右侧内容：势能曲线图与球体示意
        # 坐标系
        ax = Axes(
            x_range=[0, 3.5, 1],
            y_range=[0, 4, 1],
            x_length=5,
            y_length=3.5,
            axis_config={"include_tip": True, "color": GREY},
        )
        labels = ax.get_axis_labels(x_label="r", y_label="u(r)")

        # 标记 Sigma
        sigma_val = 1.2
        sigma_tick = Line(ax.c2p(sigma_val, -0.1), ax.c2p(sigma_val, 0.1), color=WHITE)
        sigma_label = MathTex(r"\sigma", font_size=28).next_to(sigma_tick, DOWN)

        # 绘制势能线
        # 垂直的"硬墙" (r = sigma)
        wall_line = Line(ax.c2p(sigma_val, 0), ax.c2p(sigma_val, 3.5), color=RED, stroke_width=5)
        # 水平的零势能 (r > sigma)
        zero_line = Line(ax.c2p(sigma_val, 0), ax.c2p(3.5, 0), color=BLUE, stroke_width=5)

        graph_elements = VGroup(ax, labels, sigma_tick, sigma_label, wall_line, zero_line)
        graph_elements.to_edge(RIGHT, buff=1).shift(DOWN * 0.5)

        # 球体碰撞示意图 (放在图表上方)
        sphere_r = 0.3
        s1 = Circle(radius=sphere_r, color=WHITE, fill_opacity=0.6, fill_color=GREY)
        s2 = Circle(radius=sphere_r, color=WHITE, fill_opacity=0.6, fill_color=GREY)
        s2.next_to(s1, RIGHT, buff=0) # 紧挨着，距离为直径

        # 标注间距
        collision_group = VGroup(s1, s2)
        brace = Brace(collision_group, UP, buff=0.1)
        brace_text = MathTex(r"r = \sigma", font_size=24).next_to(brace, UP)

        visual_model = VGroup(collision_group, brace, brace_text)
        visual_model.next_to(graph_elements, UP, buff=0.3)

        # 4. 动画流程
        # 步骤 1: 显示公式
        self.play(Write(formula), run_time=1)

        # 步骤 2: 建立坐标系
        self.play(Create(ax), Write(labels), run_time=1)

        # 步骤 3: 绘制硬球势能曲线 (强调排斥壁)
        self.play(
            Create(sigma_tick), Write(sigma_label),
            Create(wall_line), Create(zero_line),
            run_time=1.5
        )

        # 步骤 4: 显示球体模型示意
        self.play(FadeIn(visual_model, shift=DOWN), run_time=1)

        # 步骤 5: 显示文字描述
        self.play(
            Write(desc_group),
            run_time=2
        )

        # 步骤 6: 强调无穷大势能部分
        rect = SurroundingRectangle(wall_line, color=YELLOW, buff=0.1)
        warning_text = Text("势能无穷大", font="AR PL UKai CN", font_size=20, color=YELLOW)
        warning_text.next_to(rect, RIGHT)

        self.play(Create(rect), FadeIn(warning_text))
