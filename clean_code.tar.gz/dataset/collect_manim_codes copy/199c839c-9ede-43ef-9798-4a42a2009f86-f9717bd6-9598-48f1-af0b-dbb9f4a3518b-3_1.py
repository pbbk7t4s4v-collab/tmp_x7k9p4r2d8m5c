from manim import *

class BinaryTreeLimitScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("二叉树的限制:从性质到存储",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念展示:数学性质
        # ---------------------------------------------------------
        # 文本描述
        prop_text = Text("1. 数学性质:严格的度数限制", font="AR PL UKai CN", font_size=28, color=BLUE_B)
        prop_text.to_edge(LEFT, buff=1).shift(UP*1.5)

        # 可视化:一个根节点和两条边
        root_node = Circle(radius=0.25, color=WHITE, fill_opacity=1, fill_color=BLUE)
        left_line = Line(root_node.get_center(), root_node.get_center() + DL * 1.2, color=GRAY)
        right_line = Line(root_node.get_center(), root_node.get_center() + DR * 1.2, color=GRAY)

        # 节点上的文字
        node_label = MathTex("v", color=BLACK).scale(0.8).move_to(root_node)

        # 限制公式
        limit_formula = MathTex(r"Degree(v) \le 2", color=YELLOW)
        limit_formula.next_to(root_node, RIGHT, buff=1.5)

        # 组合上半部分图形
        tree_demo = VGroup(left_line, right_line, root_node, node_label, limit_formula)
        tree_demo.next_to(prop_text, DOWN, buff=0.5).shift(RIGHT * 1)

        # 强调框
        box = SurroundingRectangle(limit_formula, color=YELLOW, buff=0.2)

        # ---------------------------------------------------------
        # 3. 核心概念展示:存储映射
        # ---------------------------------------------------------
        # 文本描述
        store_text = Text("2. 决定存储方式:", font="AR PL UKai CN", font_size=28, color=BLUE_B)
        store_text.align_to(prop_text, LEFT).shift(DOWN * 0.5)

        # 左侧:数组示意图 (顺序存储)
        array_rects = VGroup(*[Square(side_length=0.6, color=WHITE) for _ in range(4)]).arrange(RIGHT, buff=0)
        array_label = Text("顺序存储(数组)", font="AR PL UKai CN", font_size=24, color=GRAY_B).next_to(array_rects, DOWN, buff=0.2)
        array_group = VGroup(array_rects, array_label)

        # 右侧:链表节点示意图 (链式存储)
        # 绘制 [Left|Data|Right] 结构
        link_body = Rectangle(width=2.4, height=0.8, color=GREEN)
        sep1 = Line(link_body.get_top() + LEFT*0.8, link_body.get_bottom() + LEFT*0.8, color=GREEN)
        sep2 = Line(link_body.get_top() + RIGHT*0.8, link_body.get_bottom() + RIGHT*0.8, color=GREEN)

        l_ptr = Text("L", font_size=20).move_to(link_body.get_left() + RIGHT*0.4)
        data_val = Text("Data", font_size=20).move_to(link_body.get_center())
        r_ptr = Text("R", font_size=20).move_to(link_body.get_right() + LEFT*0.4)

        link_visual = VGroup(link_body, sep1, sep2, l_ptr, data_val, r_ptr)
        link_label = Text("链式存储(指针)", font="AR PL UKai CN", font_size=24, color=GRAY_B).next_to(link_visual, DOWN, buff=0.2)
        link_group = VGroup(link_visual, link_label)

        # 排版底部存储组
        storage_group = VGroup(array_group, link_group).arrange(RIGHT, buff=2)
        storage_group.next_to(store_text, DOWN, buff=0.5).shift(RIGHT * 1)

        # ---------------------------------------------------------
        # 4. 动画播放序列
        # ---------------------------------------------------------
        # 播放第一部分:性质
        self.play(FadeIn(prop_text))
        self.play(
            Create(left_line),
            Create(right_line),
            DrawBorderThenFill(root_node),
            Write(node_label),
            run_time=1
        )
        self.play(Write(limit_formula))
        self.play(Create(box)) # 强调重点

        # 播放第二部分:存储
        self.play(FadeIn(store_text))
        self.play(
            FadeIn(array_group, shift=UP),
            FadeIn(link_group, shift=UP),
            run_time=1.5
        )
