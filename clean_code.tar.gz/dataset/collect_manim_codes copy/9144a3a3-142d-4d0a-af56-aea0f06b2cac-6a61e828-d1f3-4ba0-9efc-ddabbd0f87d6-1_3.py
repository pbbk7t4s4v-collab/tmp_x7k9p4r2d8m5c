from manim import *
import numpy as np

class HighDimImageChallenge(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("高维图像数据的挑战：参数爆炸",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧:图像可视化
        # 注意:此处使用 placeholder.png 代表课程中提到的猫狗分类 224x224 RGB 图像
        image_array = np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
        image_obj = ImageMobject(image_array)
        image_obj.set_height(4) # 设置合适高度
        image_obj.to_edge(LEFT, buff=1.5).shift(DOWN * 0.5)

        # 图像标签
        image_label_top = Text("RGB彩色图像", font="AR PL UKai CN", font_size=24, color=BLUE)
        image_label_dim = MathTex(r"224 \times 224 \times 3", color=BLUE)

        label_group = VGroup(image_label_top, image_label_dim).arrange(DOWN, buff=0.1)
        label_group.next_to(image_obj, DOWN, buff=0.2)

        # 3. 右侧:参数计算流程
        # 步骤1:输入维度计算
        t1 = Text("1. 输入层维度 (Input):", font="AR PL UKai CN", font_size=24, color=GRAY_B)
        m1 = MathTex(r"224 \times 224 \times 3 = 150,528", font_size=30)
        g1 = VGroup(t1, m1).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # 步骤2:隐藏层假设
        t2 = Text("2. 假设隐藏层神经元:", font="AR PL UKai CN", font_size=24, color=GRAY_B)
        m2 = MathTex(r"N_{hidden} = 1000", font_size=30)
        g2 = VGroup(t2, m2).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # 步骤3:权重计算
        t3 = Text("3. 仅第一层权重参数:", font="AR PL UKai CN", font_size=24, color=GRAY_B)
        m3 = MathTex(r"150,528 \times 1000", font_size=30)
        g3 = VGroup(t3, m3).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # 步骤4:结果展示
        t4 = Text("参数总量约:", font="AR PL UKai CN", font_size=30)
        result_text = Text("1.5 亿 !", font="AR PL UKai CN", font_size=48, color=RED, weight=BOLD)
        g4 = VGroup(t4, result_text).arrange(RIGHT, buff=0.2)

        # 组合右侧所有步骤
        right_content = VGroup(g1, g2, g3, g4).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        right_content.next_to(image_obj, RIGHT, buff=1.5).align_to(image_obj, UP)

        # 结果强调框
        result_box = SurroundingRectangle(g4, color=RED, buff=0.15)

        # 4. 动画流程
        # 展示图像和标签
        self.play(FadeIn(image_obj, shift=RIGHT), Write(label_group))

        # 逐步展示计算逻辑
        self.play(FadeIn(g1, shift=LEFT))
        self.play(FadeIn(g2, shift=LEFT))
        self.play(FadeIn(g3, shift=LEFT))

        # 强调最终结果
        self.play(Write(g4))
        self.play(Create(result_box))
