from manim import *

class MECEdgeComputing(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("边缘计算(MEC)：数据本地化与远程操控",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧核心概念 (文本与简单几何示意)
        # 概念文本
        concept_t1 = Text("• 计算能力下沉至网络边缘", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        concept_t2 = Text("• 数据不出场站：满足安全要求", font="AR PL UKai CN", font_size=24, color=WHITE)
        concept_t3 = Text("• 本地分流：低时延，减轻骨干网压力", font="AR PL UKai CN", font_size=24, color=WHITE)

        concept_group = VGroup(concept_t1, concept_t2, concept_t3).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        concept_group.to_edge(LEFT, buff=0.8).shift(UP * 0.5)

        # 简单示意图：本地闭环
        factory_box = Square(side_length=1.2, color=WHITE).set_opacity(0.1)
        factory_label = Text("场站本地", font="AR PL UKai CN", font_size=16).next_to(factory_box, UP, buff=0.1)

        data_dot = Dot(color=YELLOW)
        path = Circle(radius=0.4, color=BLUE).move_to(factory_box)

        diagram_group = VGroup(factory_box, factory_label, path, data_dot)
        diagram_group.next_to(concept_group, DOWN, buff=0.5).align_to(concept_group, LEFT)

        # 3. 右侧案例展示 (图片与说明)
        # 图片加载与布局
        img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/a86b50f2-b325-4e1f-891c-db39334dc69f/e9ded471-3c18-450e-8ea1-cb0cc9fc16ce/pictures/3_2/1.png") # 这里期望是一张写实风格的工业场景图，展示位于电厂煤场的斗轮堆取料机（Bucket Wheel Stacker Reclaimer）。这是一种巨大的重型机械，拥有长长的悬臂和前端巨大的旋转轮斗，正在煤堆旁作业。画面视角宏大，体现无人值守的自动化作业状态，背景可以是堆积的煤山和蓝天，画面中可以隐约看到5G基站或信号塔，暗示远程连接。写实风

        # 调整图片大小以适应版面 (保持1:1视觉比例)
        img.height = 3.2
        img.width = 3.2
        img.to_edge(RIGHT, buff=1.0).shift(UP * 0.2)

        # 图片边框
        img_border = SurroundingRectangle(img, color=ORANGE, buff=0.05)

        # 案例说明文本
        case_title = Text("案例：宁波大唐乌沙山电厂", font="AR PL UKai CN", font_size=22, color=ORANGE)
        case_tech = Text("技术：MEC + 硬切片", font="AR PL UKai CN", font_size=20, color=BLUE_A)
        case_result = Text("成效：斗轮机5G远程操控 / 无人值守", font="AR PL UKai CN", font_size=20, color=WHITE)

        case_text_group = VGroup(case_title, case_tech, case_result).arrange(DOWN, buff=0.15)
        case_text_group.next_to(img, DOWN, buff=0.3)

        # 4. 动画流程
        # 展示左侧概念
        self.play(Write(concept_group), run_time=2)

        # 展示左侧示意图（强调数据本地化）
        self.play(
            FadeIn(factory_box),
            Write(factory_label),
            Create(path),
            run_time=1.5
        )
        self.play(MoveAlongPath(data_dot, path), run_time=1.5) # 数据在本地循环

        # 展示右侧图片案例
        self.play(
            FadeIn(img),
            Create(img_border),
            run_time=1.5
        )

        # 展示案例文字
        self.play(Write(case_text_group), run_time=2)

        # 停留
