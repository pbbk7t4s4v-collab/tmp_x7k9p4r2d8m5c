from manim import *

class AgilePMORole(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (根据模板)
        # ---------------------------------------------------------
        title = Text("敏捷PMO：从控制者到赋能者",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("23", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念对比 (控制者 vs 赋能者)
        # ---------------------------------------------------------
        # 左侧：传统PMO
        t_pmo_text = Text("传统 PMO", font="AR PL UKai CN", font_size=28, color=GRAY_B)
        t_role_text = Text("控制者 (Controller)", font="AR PL UKai CN", font_size=24, color=RED_C)
        t_group = VGroup(t_pmo_text, t_role_text).arrange(DOWN, buff=0.2)

        # 右侧：敏捷PMO
        a_pmo_text = Text("敏捷 PMO", font="AR PL UKai CN", font_size=28, color=BLUE_B)
        a_role_text = Text("赋能者 (Enabler)", font="AR PL UKai CN", font_size=24, color=GREEN_C)
        a_group = VGroup(a_pmo_text, a_role_text).arrange(DOWN, buff=0.2)

        # 中间箭头
        arrow = Arrow(start=LEFT, end=RIGHT, color=WHITE, buff=0.5)

        # 布局排列
        top_content = VGroup(t_group, arrow, a_group).arrange(RIGHT, buff=1.5)
        top_content.next_to(title_line, DOWN, buff=0.8)

        # 动画展示对比
        self.play(FadeIn(t_group, shift=RIGHT))
        self.play(GrowArrow(arrow))
        self.play(FadeIn(a_group, shift=LEFT))

        # 强调右侧
        focus_rect = SurroundingRectangle(a_group, color=YELLOW, buff=0.2)
        self.play(Create(focus_rect))

        # ---------------------------------------------------------
        # 3. 六大职责列表 (两列布局)
        # ---------------------------------------------------------
        # 数据准备
        responsibilities = [
            ("建立标准", "制定敏捷实践指南"),
            ("提供培训", "辅导团队学习方法"),
            ("度量报告", "可视化的数据体系"),
            ("工具支持", "提供管理平台工具"),
            ("跨队协调", "促进大规模协作"),
            ("持续改进", "推动成熟度提升"),
        ]

        list_group = VGroup()

        for title_str, desc_str in responsibilities:
            # 图标点
            dot = Dot(color=ORANGE).scale(0.8)
            # 标题
            item_title = Text(title_str, font="AR PL UKai CN", font_size=22, color=BLUE_A, weight=BOLD)
            # 描述
            item_desc = Text(f": {desc_str}", font="AR PL UKai CN", font_size=22, color=WHITE)

            # 单行组合
            line = VGroup(dot, item_title, item_desc).arrange(RIGHT, buff=0.15, aligned_edge=DOWN)
            list_group.add(line)

        # 分两列
        col1 = VGroup(*list_group[:3]).arrange(DOWN, buff=0.4, aligned_edge=LEFT)
        col2 = VGroup(*list_group[3:]).arrange(DOWN, buff=0.4, aligned_edge=LEFT)

        columns = VGroup(col1, col2).arrange(RIGHT, buff=1.0)
        columns.next_to(top_content, DOWN, buff=0.8)

        # 动画展示列表
        self.play(LaggedStart(
            FadeIn(col1, shift=UP),
            FadeIn(col2, shift=UP),
            lag_ratio=0.3,
            run_time=2
        ))
