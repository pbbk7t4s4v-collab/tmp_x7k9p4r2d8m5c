from manim import *
import numpy as np

class QualitativeTheoryStudy(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格遵守模板要求)
        # ---------------------------------------------------------
        title = Text("定性理论阶段：研究解的性态",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("14", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局 - 左侧文字描述
        # ---------------------------------------------------------
        # 使用 VGroup 手动排列文本,避免 BulletedList 的潜在问题
        p1 = Text("• 不再寻求通解的具体表达式", font="AR PL UKai CN", font_size=26, color=BLUE_B)
        p2 = Text("• 利用几何与拓扑方法", font="AR PL UKai CN", font_size=26, color=BLUE_B)
        p3 = Text("• 核心关注解的宏观性质：", font="AR PL UKai CN", font_size=26, color=WHITE)

        # 强调关键词
        keywords = Text("  稳定性、周期性、极限环", font="AR PL UKai CN", font_size=24, color=YELLOW)

        text_group = VGroup(p1, p2, p3, keywords).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        text_group.to_edge(LEFT, buff=1.0).shift(UP * 0.2)

        # ---------------------------------------------------------
        # 3. 内容布局 - 右侧可视化 (相图示意)
        # ---------------------------------------------------------
        # 创建一个简单的坐标系表示相平面
        axes = Axes(
            x_range=[-2, 2, 1],
            y_range=[-2, 2, 1],
            x_length=4,
            y_length=4,
            axis_config={"color": GREY, "include_tip": True},
            tips=False
        ).to_edge(RIGHT, buff=1.0).shift(UP * 0.2)

        axis_labels = axes.get_axis_labels(x_label=MathTex("x"), y_label=MathTex("y"))

        # 绘制一个简单的稳定焦点示意图 (箭头指向原点)
        arrows = VGroup()
        for angle in np.linspace(0, 2*PI, 8, endpoint=False):
            # 起点在圆周
            start_point = axes.c2p(1.5 * np.cos(angle), 1.5 * np.sin(angle))
            # 终点靠近原点
            end_point = axes.c2p(0.4 * np.cos(angle + PI/4), 0.4 * np.sin(angle + PI/4))
            arrow = Arrow(start_point, end_point, buff=0, color=GREEN, max_tip_length_to_length_ratio=0.2)
            arrows.add(arrow)

        # 中心红点表示平衡点
        center_dot = Dot(axes.c2p(0, 0), color=RED)

        # 图注
        graph_label = Text("相图：解趋向于稳定平衡点", font="AR PL UKai CN", font_size=20, color=GREY_B)
        graph_label.next_to(axes, DOWN, buff=0.2)

        vis_group = VGroup(axes, axis_labels, arrows, center_dot, graph_label)

        # ---------------------------------------------------------
        # 4. 动画流程
        # ---------------------------------------------------------

        # 展示左侧文字
        self.play(
            FadeIn(p1, shift=RIGHT),
            FadeIn(p2, shift=RIGHT),
            run_time=1.5
        )

        self.play(Write(p3))
        self.play(Write(keywords))

        # 强调框
        rect = SurroundingRectangle(keywords, color=YELLOW, buff=0.1)
        self.play(Create(rect), run_time=0.5)

        # 展示右侧图形
        self.play(Create(axes), Write(axis_labels), run_time=1)
        self.play(
            FadeIn(center_dot, scale=0.5),
            LaggedStart(*[GrowArrow(a) for a in arrows], lag_ratio=0.1),
            run_time=1.5
        )
        self.play(Write(graph_label))
