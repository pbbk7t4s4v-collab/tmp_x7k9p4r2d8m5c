from manim import *

class DeterminantAndMatrixRelation(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("行列式与矩阵的关系",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局
        # 左侧:矩阵展示
        matrix_tex = MathTex(r"A = \begin{bmatrix} a & b \\ c & d \end{bmatrix}")
        matrix_desc = Text("矩阵 (Matrix)", font="AR PL UKai CN", font_size=24, color=BLUE)
        matrix_sub = Text("数据的排列形式", font="AR PL UKai CN", font_size=20, color=GRAY)

        left_group = VGroup(matrix_tex, matrix_desc, matrix_sub).arrange(DOWN, buff=0.3)

        # 右侧:行列式展示
        det_tex = MathTex(r"|A| = ad - bc")
        det_desc = Text("行列式 (Determinant)", font="AR PL UKai CN", font_size=24, color=YELLOW)
        det_sub = Text("计算出的一个数值", font="AR PL UKai CN", font_size=20, color=GRAY)

        right_group = VGroup(det_tex, det_desc, det_sub).arrange(DOWN, buff=0.3)

        # 整体布局
        content_group = VGroup(left_group, right_group).arrange(RIGHT, buff=2.5)
        content_group.move_to(ORIGIN)

        # 中间箭头
        arrow = Arrow(left_group.get_right(), right_group.get_left(), color=WHITE, buff=0.2)
        op_text = Text("运算/映射", font="AR PL UKai CN", font_size=18).next_to(arrow, UP, buff=0.1)

        # 3. 动画流程
        # 步骤1: 显示矩阵
        self.play(FadeIn(left_group, shift=RIGHT))

        # 步骤2: 箭头过渡
        self.play(GrowArrow(arrow), FadeIn(op_text))

        # 步骤3: 显示行列式
        self.play(FadeIn(right_group, shift=LEFT))

        # 步骤4: 核心区别强调
        # 强调矩阵是方括号,行列式是竖线,结果是数值
        rect_matrix = SurroundingRectangle(matrix_tex, color=BLUE, buff=0.1)
        rect_det = SurroundingRectangle(det_tex, color=YELLOW, buff=0.1)

        key_point = Text("矩阵是表,行列式是数", font="AR PL UKai CN", font_size=28, color=RED)
        key_point.next_to(content_group, DOWN, buff=0.8)

        self.play(
            Create(rect_matrix),
            Create(rect_det)
        )
        self.play(Write(key_point))
