from manim import *

class DFSExplanation(Scene):
    def construct(self):

        # 1. 标题部分
        title = Text("图的遍历：深度优先搜索(DFS)",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("21", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧文字讲解区
        # 使用 Text 和 Dot 组合模拟列表，避免 BulletedList 的潜在 LaTeX 问题
        text_config = {"font": "AR PL UKai CN", "font_size": 24, "color": WHITE}

        item1 = Text("核心思想：沿一条路走到底，不通则回退", **text_config)
        item2 = Text("不连通图：需从未访问顶点重新启动", **text_config)
        item3 = Text("结果特点：序列不唯一 (受遍历顺序影响)", **text_config)

        text_group = VGroup(item1, item2, item3).arrange(DOWN, aligned_edge=LEFT, buff=0.6)

        # 添加列表点
        dots = VGroup()
        for item in text_group:
            dot = Dot(color=ORANGE, radius=0.06).next_to(item, LEFT, buff=0.2)
            dots.add(dot)

        content_group = VGroup(dots, text_group)
        content_group.to_edge(LEFT, buff=1).shift(UP*0.5)

        # 添加强调框
        box = SurroundingRectangle(content_group, color=BLUE, buff=0.3, stroke_width=2)

        self.play(
            FadeIn(content_group, shift=RIGHT),
            Create(box)
        )

        # 3. 右侧图示可视化区
        # 手动绘制简单的树状图结构来演示 DFS
        # 节点位置
        start_pos = RIGHT * 3 + UP * 1.5
        left_pos = RIGHT * 1.5 + DOWN * 0.5
        right_pos = RIGHT * 4.5 + DOWN * 0.5
        leaf_pos = RIGHT * 1.5 + DOWN * 2.5

        # 节点样式
        node_radius = 0.35
        node_color = WHITE
        text_color = BLACK

        # 创建节点
        n1 = Circle(radius=node_radius, color=node_color, fill_color=BLACK, fill_opacity=1).move_to(start_pos)
        t1 = Text("1", font="AR PL UKai CN", font_size=20).move_to(start_pos)

        n2 = Circle(radius=node_radius, color=node_color, fill_color=BLACK, fill_opacity=1).move_to(left_pos)
        t2 = Text("2", font="AR PL UKai CN", font_size=20).move_to(left_pos)

        n3 = Circle(radius=node_radius, color=node_color, fill_color=BLACK, fill_opacity=1).move_to(right_pos)
        t3 = Text("3", font="AR PL UKai CN", font_size=20).move_to(right_pos)

        n4 = Circle(radius=node_radius, color=node_color, fill_color=BLACK, fill_opacity=1).move_to(leaf_pos)
        t4 = Text("4", font="AR PL UKai CN", font_size=20).move_to(leaf_pos)

        nodes = VGroup(n1, n2, n3, n4)
        labels = VGroup(t1, t2, t3, t4)

        # 创建边
        e1 = Line(start_pos, left_pos, color=GREY)
        e2 = Line(left_pos, leaf_pos, color=GREY)
        e3 = Line(start_pos, right_pos, color=GREY)

        edges = VGroup(e1, e2, e3)
        edges.set_z_index(-1) # 确保线条在圆圈下方

        graph_group = VGroup(edges, nodes, labels)

        self.play(FadeIn(graph_group))

        # 4. 演示 DFS 过程
        highlight_color = YELLOW

        # 步骤1: 访问起点 1
        self.play(n1.animate.set_fill(highlight_color, opacity=0.8), run_time=0.5)

        # 步骤2: 深入到 2
        self.play(
            ShowPassingFlash(e1.copy().set_color(highlight_color), time_width=0.5),
            n2.animate.set_fill(highlight_color, opacity=0.8),
            run_time=0.6
        )

        # 步骤3: 深入到 4
        self.play(
            ShowPassingFlash(e2.copy().set_color(highlight_color), time_width=0.5),
            n4.animate.set_fill(highlight_color, opacity=0.8),
            run_time=0.6
        )

        # 步骤4: 回退提示
        backtrack_label = Text("无路可走，回退", font="AR PL UKai CN", font_size=18, color=RED)
        backtrack_label.next_to(n4, RIGHT)
        self.play(Write(backtrack_label), run_time=0.5)
        self.play(FadeOut(backtrack_label), run_time=0.5)

        # 步骤5: 回退到 1 再去 3
        # 视觉上直接显示跳到 3 的路径，暗示回退过程
        self.play(
            ShowPassingFlash(e3.copy().set_color(highlight_color), time_width=0.5),
            n3.animate.set_fill(highlight_color, opacity=0.8),
            run_time=0.6
        )
