from manim import *

class DecisionTaskClassification(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("决策智能的任务分类",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 上半部分：分类维度
        # 定义文本内容
        basis_label = Text("分类核心维度：", font_size=28, font="AR PL UKai CN", color=GREY_B)

        # 两个主要维度
        dim1 = Text("环境动态性", font_size=30, font="AR PL UKai CN", color=BLUE_C)
        dim2 = Text("环境透明度", font_size=30, font="AR PL UKai CN", color=BLUE_C)

        # 布局
        dims_group = VGroup(dim1, dim2).arrange(RIGHT, buff=1.5)
        top_section = VGroup(basis_label, dims_group).arrange(RIGHT, buff=0.5)
        top_section.next_to(title_line, DOWN, buff=1.2)

        # 给维度添加框
        box1 = SurroundingRectangle(dim1, color=BLUE, buff=0.15, stroke_width=2)
        box2 = SurroundingRectangle(dim2, color=BLUE, buff=0.15, stroke_width=2)

        # 动画展示上半部分
        self.play(FadeIn(basis_label))
        self.play(
            Write(dim1), Create(box1),
            Write(dim2), Create(box2)
        )

        # 3. 下半部分：强化学习的定位
        # 箭头连接
        arrow = Arrow(start=top_section.get_bottom(), end=top_section.get_bottom() + DOWN * 1.2, color=WHITE, buff=0.1)

        # RL 标题
        rl_title = Text("强化学习 (RL)", font_size=36, font="AR PL UKai CN", color=YELLOW)
        rl_title.next_to(arrow, DOWN, buff=0.2)

        # RL 的三个关键特征
        feat1 = Text("动态环境", font_size=26, font="AR PL UKai CN", color=WHITE)
        feat2 = Text("序贯决策", font_size=26, font="AR PL UKai CN", color=WHITE)
        feat3 = Text("非完全透明", font_size=26, font="AR PL UKai CN", color=WHITE)

        # 特征布局
        features = VGroup(feat1, feat2, feat3).arrange(RIGHT, buff=0.8)
        features.next_to(rl_title, DOWN, buff=0.6)

        # 整体包裹框
        rl_group = VGroup(rl_title, features)
        rl_box = SurroundingRectangle(rl_group, color=YELLOW, buff=0.3, corner_radius=0.2)

        # 动画展示下半部分
        self.play(GrowArrow(arrow))
        self.play(Write(rl_title), Create(rl_box))

        # 依次展示特征，强调RL的适用场景
        self.play(
            FadeIn(feat1, shift=UP),
            run_time=0.5
        )
        self.play(
            FadeIn(feat2, shift=UP),
            run_time=0.5
        )
        self.play(
            FadeIn(feat3, shift=UP),
            run_time=0.5
        )

        # 4. 停留展示
