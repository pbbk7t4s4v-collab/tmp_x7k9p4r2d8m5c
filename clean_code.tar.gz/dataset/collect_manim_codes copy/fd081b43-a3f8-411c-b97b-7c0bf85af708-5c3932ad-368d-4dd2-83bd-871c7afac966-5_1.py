from manim import *

class PragmaticsImplicature(Scene):
    def construct(self):

        # 1. Title Setup (Standard Template)
        title = Text("Pragmatics: Implicature & Intention",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Definition of Pragmatics
        def_text = Text("Pragmatics: The study of meaning in context",
                       font_size=24, color=GREY_A)
        def_text.next_to(title_line, DOWN, buff=0.3)
        self.play(FadeIn(def_text))

        # 3. The Example Scenario (Central Visual)
        # Speaker's utterance
        speaker_text = Text('Speaker says: "It\'s cold in here"', font_size=32, weight=BOLD)
        speaker_text.move_to(UP * 0.5)

        self.play(Write(speaker_text))

        # 4. Splitting Meaning: Literal vs. Intention

        # Left Side: Literal Meaning
        literal_title = Text("Literal Meaning", font_size=26, color=BLUE)
        literal_desc = Text("Fact about temperature", font_size=22, slant=ITALIC)
        literal_group = VGroup(literal_title, literal_desc).arrange(DOWN, buff=0.2)
        literal_group.move_to(DL * 2 + RIGHT * 1.5) # Position bottom left

        arrow_literal = Arrow(start=speaker_text.get_bottom(), end=literal_group.get_top(), color=BLUE)

        # Right Side: Implicature/Intention
        implicature_title = Text("Implicature / Intention", font_size=26, color=YELLOW)
        implicature_desc = Text("Request: Close the window!", font_size=22, slant=ITALIC)
        implicature_group = VGroup(implicature_title, implicature_desc).arrange(DOWN, buff=0.2)
        implicature_group.move_to(DR * 2 + LEFT * 1.5) # Position bottom right

        arrow_implicature = Arrow(start=speaker_text.get_bottom(), end=implicature_group.get_top(), color=YELLOW)

        # Animation of the split
        self.play(
            GrowArrow(arrow_literal),
            FadeIn(literal_group, shift=DOWN),
        )

        self.play(
            GrowArrow(arrow_implicature),
            FadeIn(implicature_group, shift=DOWN)
        )

        # 5. Highlight the Core Concept (Implicature)
        # Using SurroundingRectangle as requested
        highlight_box = SurroundingRectangle(implicature_group, color=YELLOW, buff=0.2)
        highlight_label = Text("Contextual Meaning", font_size=20, color=YELLOW)
        highlight_label.next_to(highlight_box, DOWN)

        self.play(
            Create(highlight_box),
            Write(highlight_label)
        )
