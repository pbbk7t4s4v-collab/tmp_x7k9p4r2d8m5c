from manim import *

class CaseExternality(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("个案裁判的制度外部性理论",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("38", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念:个案的双重效应
        # 中心节点
        case_node = Text("个案裁判", font="AR PL UKai CN", font_size=28, color=BLUE_B)
        case_node.move_to(UP * 1.5)
        case_box = SurroundingRectangle(case_node, color=BLUE, buff=0.2)

        self.play(FadeIn(case_node), Create(case_box))

        # 左侧:内部效应
        internal_text = Text("解决具体纠纷\n(当事人之间)", font="AR PL UKai CN", font_size=24, color=GREY_B)
        internal_text.next_to(case_box, DL, buff=1.5)

        arrow_left = Arrow(case_box.get_bottom(), internal_text.get_top(), color=GREY, buff=0.1)

        # 右侧:外部效应 (重点)
        external_text = Text("制度外部性\n(超出个案)", font="AR PL UKai CN", font_size=24, color=YELLOW)
        external_text.next_to(case_box, DR, buff=1.5)
        external_box = SurroundingRectangle(external_text, color=YELLOW, buff=0.15)

        arrow_right = Arrow(case_box.get_bottom(), external_text.get_top(), color=YELLOW, buff=0.1)

        self.play(
            GrowArrow(arrow_left), FadeIn(internal_text),
            GrowArrow(arrow_right), FadeIn(external_text), Create(external_box)
        )

        # 3. 机制解释:如何产生外部性
        # 在外部性下方展示流程
        mechanism_group = VGroup()
        step1 = Text("司法解释/指导案例", font="AR PL UKai CN", font_size=22)
        arrow_m1 = Arrow(LEFT, RIGHT, buff=0.1, max_stroke_width_to_length_ratio=5).scale(0.5)
        step2 = Text("提炼裁判规则", font="AR PL UKai CN", font_size=22)
        arrow_m2 = Arrow(LEFT, RIGHT, buff=0.1, max_stroke_width_to_length_ratio=5).scale(0.5)
        step3 = Text("类似案件先例", font="AR PL UKai CN", font_size=22, color=ORANGE)

        mechanism_group.add(step1, arrow_m1, step2, arrow_m2, step3)
        mechanism_group.arrange(RIGHT, buff=0.2)
        mechanism_group.next_to(external_box, DOWN, buff=0.8).shift(LEFT * 1.5)

        # 连接线
        connect_arrow = DashedLine(external_box.get_bottom(), mechanism_group.get_top(), color=YELLOW_D)

        self.play(
            Create(connect_arrow),
            Write(mechanism_group)
        )

        # 4. 制度对比 (底部)
        comparison_title = Text("不同法系的体现", font="AR PL UKai CN", font_size=26, color=BLUE_A)
        comparison_title.next_to(mechanism_group, DOWN, buff=0.6)

        # 左:判例法系
        sys_common = Text("判例法系: 遵循先例", font="AR PL UKai CN", font_size=24)

        # 右:中国
        sys_china = Text("中国: 案例指导制度", font="AR PL UKai CN", font_size=24, color=GREEN)

        systems = VGroup(sys_common, sys_china).arrange(RIGHT, buff=1.5)
        systems.next_to(comparison_title, DOWN, buff=0.3)

        self.play(
            FadeIn(comparison_title),
            FadeIn(systems, shift=UP)
        )

        # 最后的强调
        final_rect = SurroundingRectangle(sys_china, color=GREEN, buff=0.1)
        self.play(Create(final_rect))
