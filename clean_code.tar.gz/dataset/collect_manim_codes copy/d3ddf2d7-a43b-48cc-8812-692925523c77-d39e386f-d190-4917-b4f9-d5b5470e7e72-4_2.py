from manim import *

class PhoneticsAndForms(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("重点字音字形辨析",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容创建
        # 使用 Text 对象并利用 t2c 参数进行局部着色，突出重点字和拼音
        # 左侧数据
        item1 = Text("红缯 (zēng)", font="AR PL UKai CN", font_size=32, t2c={"缯": YELLOW, "zēng": YELLOW})
        item2 = Text("紫绡 (xiāo)", font="AR PL UKai CN", font_size=32, t2c={"绡": YELLOW, "xiāo": YELLOW})
        item3 = Text("醴酪 (lǐ lào)", font="AR PL UKai CN", font_size=32, t2c={"醴酪": YELLOW, "lǐ lào": YELLOW})
        item4 = Text("龟裂 (jūn)", font="AR PL UKai CN", font_size=32, t2c={"龟": YELLOW, "jūn": YELLOW})

        # 右侧数据
        item5 = Text("贮藏 (zhù)", font="AR PL UKai CN", font_size=32, t2c={"贮": YELLOW, "zhù": YELLOW})
        item6 = Text("渣滓 (zǐ)", font="AR PL UKai CN", font_size=32, t2c={"滓": YELLOW, "zǐ": YELLOW})
        item7 = Text("萌蘖 (niè)", font="AR PL UKai CN", font_size=32, t2c={"蘖": YELLOW, "niè": YELLOW})
        item8 = Text("啖 (dàn)", font="AR PL UKai CN", font_size=32, t2c={"啖": YELLOW, "dàn": YELLOW})

        # 3. 排版布局
        # 左列组合
        col_left = VGroup(item1, item2, item3, item4).arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        # 右列组合
        col_right = VGroup(item5, item6, item7, item8).arrange(DOWN, buff=0.6, aligned_edge=LEFT)

        # 整体组合并居中
        content_group = VGroup(col_left, col_right).arrange(RIGHT, buff=3.0)
        content_group.move_to(ORIGIN).shift(DOWN * 0.2)

        # 4. 辅助图形
        # 使用 SurroundingRectangle 对两列内容进行框选，增强视觉聚焦
        rect_left = SurroundingRectangle(col_left, color=BLUE_C, buff=0.25, corner_radius=0.1)
        rect_right = SurroundingRectangle(col_right, color=BLUE_C, buff=0.25, corner_radius=0.1)

        # 5. 动画展示
        # 分左右两列依次淡入,同时画出边框
        self.play(
            FadeIn(col_left, shift=RIGHT * 0.5),
            Create(rect_left),
            run_time=1.2
        )
        self.play(
            FadeIn(col_right, shift=LEFT * 0.5),
            Create(rect_right),
            run_time=1.2
        )
