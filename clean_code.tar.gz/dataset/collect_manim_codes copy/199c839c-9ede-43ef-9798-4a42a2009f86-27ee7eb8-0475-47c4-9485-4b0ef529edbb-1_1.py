from manim import *

class TeacherIntroduction(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("授课教师介绍",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容构建
        # 姓名部分 - 突出显示
        name_label = Text("姓名:", font="AR PL UKai CN", font_size=36, color=BLUE_A)
        name_val = Text("高云", font="AR PL UKai CN", font_size=48, color=YELLOW)
        name_group = VGroup(name_label, name_val).arrange(RIGHT, buff=0.2)

        # 详细信息部分
        # 使用 Text 对象逐行构建,确保对齐和字体
        info_font_size = 28
        line_buff = 0.4

        # 职称
        title_text = Text("职称:上海交通大学数学科学学院 副教授", font="AR PL UKai CN", font_size=info_font_size)

        # 办公室
        office_text = Text("办公室:理科群楼6号719室", font="AR PL UKai CN", font_size=info_font_size)

        # 研究兴趣
        research_text = Text("研究兴趣:代数几何,复几何", font="AR PL UKai CN", font_size=info_font_size)

        # 邮箱
        email_text = Text("邮箱:gaoyunmath@sjtu.edu.cn", font="AR PL UKai CN", font_size=info_font_size)

        # 组合详细信息
        details_group = VGroup(title_text, office_text, research_text, email_text)
        details_group.arrange(DOWN, aligned_edge=LEFT, buff=line_buff)

        # 整体布局
        content_group = VGroup(name_group, details_group)
        content_group.arrange(DOWN, aligned_edge=LEFT, buff=0.6)
        content_group.move_to(ORIGIN)

        # 添加外框装饰
        box = SurroundingRectangle(content_group, color=BLUE, buff=0.5, stroke_width=2)

        # 3. 动画演示
        # 先显示姓名
        self.play(FadeIn(name_group, shift=UP), run_time=1)

        # 绘制外框
        self.play(Create(box), run_time=1)

        # 依次展示详细信息
        for item in details_group:
            self.play(Write(item), run_time=0.8)
