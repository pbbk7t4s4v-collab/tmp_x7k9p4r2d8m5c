from manim import *

class OvercastStandard(Scene):
    def construct(self):

        # 1. 标题部分 (标准模板)
        title = Text("云量标准：阴 (Overcast)",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧文字定义
        # 第一行：定义描述
        text_def_1 = Text("如果云量占了", font="AR PL UKai CN", font_size=28)
        text_def_2 = Text("三份 (3/4)", font="AR PL UKai CN", font_size=28, color=BLUE)
        text_def_3 = Text("及以上", font="AR PL UKai CN", font_size=28)

        # 组合第一行文字
        line1_group = VGroup(text_def_1, text_def_2, text_def_3).arrange(RIGHT, buff=0.1)

        # 第二行：结论
        text_result = Text("天气就是：阴", font="AR PL UKai CN", font_size=36, color=GRAY_A)

        # 装饰用的小云朵图标 (由圆形组合而成)
        c1 = Circle(radius=0.15, fill_opacity=1, color=GRAY).shift(LEFT*0.2 + DOWN*0.1)
        c2 = Circle(radius=0.2, fill_opacity=1, color=GRAY).shift(UP*0.1)
        c3 = Circle(radius=0.15, fill_opacity=1, color=GRAY).shift(RIGHT*0.2 + DOWN*0.1)
        cloud_icon = VGroup(c1, c2, c3).next_to(text_result, RIGHT, buff=0.3)

        # 整体文字组
        text_group = VGroup(line1_group, VGroup(text_result, cloud_icon)).arrange(DOWN, buff=0.8, aligned_edge=LEFT)
        text_group.to_edge(LEFT, buff=1.0).shift(UP*0.5)

        # 3. 右侧可视化 - 饼图展示 3/4
        # 天空背景圆 (代表整个天空)
        radius = 1.6
        sky_circle = Circle(radius=radius, color=WHITE, stroke_width=2)

        # 辅助网格线 (将圆分为4份)
        v_line = Line(UP*radius, DOWN*radius)
        h_line = Line(LEFT*radius, RIGHT*radius)
        grid = VGroup(v_line, h_line).set_color(WHITE).set_opacity(0.3)

        # 阴天区域 (填充 3/4 的区域，灰色代表云)
        # 从90度(顶部)开始，逆时针旋转270度(3/4圆)
        cloud_sector = Sector(
            radius=radius,
            angle=270 * DEGREES,
            start_angle=90 * DEGREES,
            color=GRAY,
            fill_opacity=0.8
        )

        # 数学符号标注
        math_label = MathTex(r"\ge \frac{3}{4}", font_size=48, color=WHITE)
        math_label.next_to(sky_circle, DOWN, buff=0.3)

        # 组合图表
        chart_group = VGroup(sky_circle, grid, cloud_sector, math_label)
        chart_group.to_edge(RIGHT, buff=2.0)

        # 4. 动画流程
        # 4.1 显示第一行定义
        self.play(FadeIn(line1_group, shift=RIGHT))

        # 4.2 绘制空圆和网格 (展示"四份"的概念)
        self.play(Create(sky_circle), Create(grid))

        # 4.3 填充云层 (展示"3/4")
        self.play(DrawBorderThenFill(cloud_sector), run_time=1.5)

        # 4.4 显示分数标注
        self.play(Write(math_label))

        # 4.5 得出结论并强调
        self.play(Write(text_result), FadeIn(cloud_icon, scale=0.5))

        # 4.6 框选强调核心概念
        emphasis_box = SurroundingRectangle(VGroup(text_result, cloud_icon), color=YELLOW, buff=0.2)
        self.play(Create(emphasis_box))
