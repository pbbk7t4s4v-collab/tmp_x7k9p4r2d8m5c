from manim import *

class BSTPracticalSignificance(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("BST平衡调整的实践意义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("32", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧:失衡情况
        # 创建一个退化的链表状BST
        left_center = LEFT * 3.5 + UP * 0.5

        node_style = {"radius": 0.2, "color": BLUE, "fill_opacity": 1, "stroke_width": 2}
        line_style = {"stroke_width": 3, "color": GRAY}

        # 失衡树节点位置
        n1 = Circle(**node_style).move_to(left_center + UP * 1 + LEFT * 0.5)
        n2 = Circle(**node_style).move_to(left_center + LEFT * 0)
        n3 = Circle(**node_style).move_to(left_center + DOWN * 1 + RIGHT * 0.5)

        # 连线
        l1 = Line(n1.get_center(), n2.get_center(), **line_style)
        l2 = Line(n2.get_center(), n3.get_center(), **line_style)

        bad_tree = VGroup(l1, l2, n1, n2, n3)

        bad_label = Text("失衡状态", font="AR PL UKai CN", font_size=24, color=RED).next_to(bad_tree, UP)
        bad_complexity = MathTex("O(n)", color=RED).next_to(bad_tree, DOWN)

        left_group = VGroup(bad_label, bad_tree, bad_complexity)

        # 3. 内容布局 - 右侧:平衡情况 (AVL/红黑树)
        right_center = RIGHT * 3.5 + UP * 0.5

        # 平衡树节点位置
        r_root = Circle(**node_style).move_to(right_center + UP * 0.5)
        r_left = Circle(**node_style).move_to(right_center + DOWN * 0.5 + LEFT * 1)
        r_right = Circle(**node_style).move_to(right_center + DOWN * 0.5 + RIGHT * 1)

        # 连线
        rl1 = Line(r_root.get_center(), r_left.get_center(), **line_style)
        rl2 = Line(r_root.get_center(), r_right.get_center(), **line_style)

        good_tree = VGroup(rl1, rl2, r_root, r_left, r_right)

        good_label = Text("平衡调整 (AVL/红黑树)", font="AR PL UKai CN", font_size=24, color=GREEN).next_to(good_tree, UP)
        good_complexity = MathTex("O(\\log n)", color=GREEN).next_to(good_tree, DOWN)

        right_group = VGroup(good_label, good_tree, good_complexity)

        # 4. 动画展示对比
        self.play(FadeIn(left_group, shift=RIGHT), run_time=1)

        # 添加箭头指向右侧
        arrow = Arrow(left_group.get_right(), right_group.get_left(), buff=0.5, color=YELLOW)
        arrow_text = Text("优化", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(arrow, UP, buff=0.1)

        self.play(GrowArrow(arrow), FadeIn(arrow_text))
        self.play(FadeIn(right_group, shift=LEFT), run_time=1)

        # 5. 底部应用场景
        # 使用方框展示应用
        app_text_1 = Text("数据库索引", font="AR PL UKai CN", font_size=24)
        app_text_2 = Text("文件系统", font="AR PL UKai CN", font_size=24)

        app_group = VGroup(app_text_1, app_text_2).arrange(RIGHT, buff=2)
        app_group.move_to(DOWN * 2.5)

        # 为应用添加边框
        rect1 = SurroundingRectangle(app_text_1, color=BLUE, buff=0.2)
        rect2 = SurroundingRectangle(app_text_2, color=BLUE, buff=0.2)

        final_app_group = VGroup(rect1, app_text_1, rect2, app_text_2)

        # 连接线从平衡树指向应用
        conn_line = Line(good_complexity.get_bottom(), final_app_group.get_top(), color=GREY, stroke_width=2)

        self.play(
            Create(conn_line),
            Create(rect1), Write(app_text_1),
            Create(rect2), Write(app_text_2),
            run_time=1.5
        )
