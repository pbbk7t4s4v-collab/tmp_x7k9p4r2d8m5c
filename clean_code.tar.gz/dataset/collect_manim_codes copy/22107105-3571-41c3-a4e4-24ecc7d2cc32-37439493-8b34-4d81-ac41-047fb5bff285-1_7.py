from manim import *

class MarxistEpistemology(Scene):
    def construct(self):

        # 1. 标题设置 (标准模板)
        title = Text("马克思主义认识论",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念展示
        # 核心论点
        core_concept = Text("实践是认识的基础", font="AR PL UKai CN", font_size=28, color=YELLOW)
        core_concept.next_to(title_line, DOWN, buff=0.6)

        self.play(FadeIn(core_concept, shift=DOWN))

        # 3. 循环过程可视化 (实践 <-> 认识)
        # 定义节点
        practice_text = Text("实践", font="AR PL UKai CN", font_size=32)
        knowledge_text = Text("认识", font="AR PL UKai CN", font_size=32)

        # 定位节点
        practice_text.move_to(LEFT * 2.5 + DOWN * 0.2)
        knowledge_text.move_to(RIGHT * 2.5 + DOWN * 0.2)

        # 使用 SurroundingRectangle 框选
        box_practice = SurroundingRectangle(practice_text, color=BLUE, buff=0.3)
        box_knowledge = SurroundingRectangle(knowledge_text, color=GREEN, buff=0.3)

        group_practice = VGroup(box_practice, practice_text)
        group_knowledge = VGroup(box_knowledge, knowledge_text)

        # 绘制箭头形成闭环
        # 上方箭头：实践 -> 认识
        arrow_top = Arrow(
            start=box_practice.get_top(),
            end=box_knowledge.get_top(),
            path_arc=-1.2,
            color=WHITE,
            buff=0.1
        )
        # 下方箭头：认识 -> 实践
        arrow_bottom = Arrow(
            start=box_knowledge.get_bottom(),
            end=box_practice.get_bottom(),
            path_arc=-1.2,
            color=WHITE,
            buff=0.1
        )

        # 箭头标签
        label_top = Text("能动反映", font="AR PL UKai CN", font_size=20, color=LIGHT_GREY)
        label_top.next_to(arrow_top, UP, buff=0.1)

        label_bottom = Text("指导/检验", font="AR PL UKai CN", font_size=20, color=LIGHT_GREY)
        label_bottom.next_to(arrow_bottom, DOWN, buff=0.1)

        # 动画展示循环图
        self.play(
            Create(group_practice),
            Create(group_knowledge),
            run_time=1.0
        )
        self.play(
            GrowArrow(arrow_top),
            FadeIn(label_top),
            run_time=1.0
        )
        self.play(
            GrowArrow(arrow_bottom),
            FadeIn(label_bottom),
            run_time=1.0
        )

        # 4. 底部总结：循环上升规律
        cycle_law = Text("规律：实践 — 认识 — 再实践 — 再认识 (循环上升)",
                        font="AR PL UKai CN",
                        font_size=24,
                        color=ORANGE)
        cycle_law.move_to(DOWN * 2.8)

        self.play(Write(cycle_law))
