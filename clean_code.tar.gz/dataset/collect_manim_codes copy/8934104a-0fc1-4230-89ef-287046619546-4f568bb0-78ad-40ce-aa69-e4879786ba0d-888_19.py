from manim import *

class PoissonBoltzmannComparison(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("多尺度DNN求解Poisson-Boltzmann方程效果对比",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("18", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 图片加载与布局
        # 加载三张图片，严格按照Planner建议的顺序和注释
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/4f568bb0-78ad-40ce-aa69-e4879786ba0d/pictures/888_19/1.png") # 这里期望是一张科学可视化热力图，代表Poisson-Boltzmann方程的精确解（Exact Solution）。图像展示了平滑且复杂的二维数值分布，色彩过渡自然，作为对比的基准真值。
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/4f568bb0-78ad-40ce-aa69-e4879786ba0d/pictures/888_19/2.png") # 这里期望是一张科学可视化热力图，代表普通DNN的预测结果。与精确解相比，该图像在细节上显得模糊，颜色梯度存在可见的偏差和噪声，体现出预测精度的不足。
        img3 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/4f568bb0-78ad-40ce-aa69-e4879786ba0d/manim_assets/d91a414b-0692-4d6e-95f8-19fa0b860377.jpg") # 这里期望是一张科学可视化热力图，代表Multi-Scale DNN的预测结果。该图像清晰锐利，其色彩分布和纹理细节与精确解高度重合，几乎看不出差异，体现了高精度的预测能力。

        # 设置统一大小（保持1:1比例），高度设为3.2以适应屏幕
        img_size = 3.2
        img1.height = img_size
        img2.height = img_size
        img3.height = img_size

        # 组合并排列图片
        images = Group(img1, img2, img3).arrange(RIGHT, buff=1.0)
        images.next_to(title_line, DOWN, buff=0.5)

        # 3. 创建标签
        label_font_size = 24
        label1 = Text("精确解 (Exact)", font="AR PL UKai CN", font_size=label_font_size, color=BLUE_B).next_to(img1, DOWN, buff=0.2)
        label2 = Text("普通 DNN", font="AR PL UKai CN", font_size=label_font_size, color=RED_B).next_to(img2, DOWN, buff=0.2)
        label3 = Text("Multi-Scale DNN", font="AR PL UKai CN", font_size=label_font_size, color=GREEN_B).next_to(img3, DOWN, buff=0.2)

        # 4. 结论文本
        conclusion = Text("结论：Multi-Scale DNN 能够捕捉高频细节，预测结果与精确解高度吻合。",
                         font="AR PL UKai CN", font_size=26, color=YELLOW)
        conclusion.to_edge(DOWN, buff=0.5)

        # 5. 动画展示流程
        # 展示第一张图（基准）
        self.play(FadeIn(img1), Write(label1))

        # 展示第二张图（普通DNN效果较差）
        self.play(FadeIn(img2), Write(label2))

        # 展示第三张图（多尺度DNN效果好）
        self.play(FadeIn(img3), Write(label3))

        # 强调对比
        rect_bad = SurroundingRectangle(img2, color=RED, buff=0.05)
        rect_good = SurroundingRectangle(img3, color=GREEN, buff=0.05)

        self.play(Create(rect_bad), run_time=0.5)
        self.play(Create(rect_good), run_time=0.5)

        # 展示结论
        self.play(Write(conclusion))
