from manim import *

class PolarizabilityVolume(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("极化率体积的概念",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容部分：极化率 alpha 的单位问题
        # ---------------------------------------------------------
        # 左侧展示 alpha 及其单位
        alpha_label = MathTex(r"\alpha", color=BLUE, font_size=60)

        # 使用 MathTex 展示复杂单位
        unit_label = MathTex(
            r"\text{Unit: } \mathrm{C}^2 \cdot \mathrm{m}^2 \cdot \mathrm{J}^{-1}",
            font_size=32
        )

        # 组合上半部分
        alpha_group = VGroup(alpha_label, unit_label).arrange(DOWN, buff=0.3)
        alpha_group.shift(UP * 1.2)

        # 描述文本
        desc_text = Text("单位复杂，不直观", font="AR PL UKai CN", font_size=24, color=GRAY)
        desc_text.next_to(alpha_group, RIGHT, buff=1.0)

        self.play(FadeIn(alpha_group))
        self.play(Write(desc_text))

        # ---------------------------------------------------------
        # 3. 核心公式：极化率体积 alpha'
        # ---------------------------------------------------------
        # 转换箭头
        arrow = Arrow(start=alpha_group.get_bottom(), end=DOWN*0.5, color=WHITE, buff=0.5)

        # 核心公式
        formula = MathTex(
            r"\alpha'", r"=", r"\frac{\alpha}{4\pi\epsilon_0}",
            font_size=48
        )
        formula.set_color_by_tex(r"\alpha'", YELLOW)
        formula.next_to(arrow, DOWN, buff=0.2)

        # 强调框
        box = SurroundingRectangle(formula, color=YELLOW, buff=0.2)

        self.play(GrowArrow(arrow))
        self.play(Write(formula))
        self.play(Create(box))

        # ---------------------------------------------------------
        # 4. 物理意义可视化：体积
        # ---------------------------------------------------------
        # 底部说明文字
        meaning_text = Text("引入极化率体积，量纲为体积", font="AR PL UKai CN", font_size=28, color=YELLOW)
        meaning_text.next_to(box, DOWN, buff=0.8)
        meaning_text.shift(LEFT * 1.5)

        # 简单的立方体几何图形表示"体积"
        cube_side = 0.8
        square_front = Square(side_length=cube_side, color=BLUE_C, fill_opacity=0.2, fill_color=BLUE_C)
        square_back = Square(side_length=cube_side, color=BLUE_E).shift(UP*0.3 + RIGHT*0.3)

        # 连接前后面的线
        corners_front = [square_front.get_corner(x) for x in [UL, UR, DL, DR]]
        corners_back = [square_back.get_corner(x) for x in [UL, UR, DL, DR]]
        lines = VGroup(*[Line(c1, c2, color=BLUE_E) for c1, c2 in zip(corners_front, corners_back)])

        cube_viz = VGroup(square_back, lines, square_front)
        cube_viz.next_to(meaning_text, RIGHT, buff=0.5)

        self.play(FadeIn(meaning_text))
        self.play(Create(cube_viz))
