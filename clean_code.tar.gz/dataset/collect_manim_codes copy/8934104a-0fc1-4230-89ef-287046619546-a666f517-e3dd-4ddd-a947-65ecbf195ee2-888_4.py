from manim import *

class UnsupervisedLearningRoleAndClustering(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("无监督学习角色与聚类定义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 第一部分：无监督学习的角色
        # 中心节点
        center_node = Text("无监督学习", font="AR PL UKai CN", font_size=28, color=BLUE)
        center_node.move_to(UP * 1.5)

        # 左侧应用：EDA
        left_text = Text("探索性分析 (EDA)\n挖掘数据内在模式", font="AR PL UKai CN", font_size=22, line_spacing=0.8)
        left_text.next_to(center_node, DOWN, buff=1.0).shift(LEFT * 3)

        # 右侧应用：特征提取
        right_text = Text("特征提取\n监督学习前置步骤", font="AR PL UKai CN", font_size=22, line_spacing=0.8)
        right_text.next_to(center_node, DOWN, buff=1.0).shift(RIGHT * 3)

        # 连接箭头
        arrow_l = Arrow(center_node.get_bottom(), left_text.get_top(), color=GREY, buff=0.1)
        arrow_r = Arrow(center_node.get_bottom(), right_text.get_top(), color=GREY, buff=0.1)

        # 框选强调
        role_group = VGroup(center_node, left_text, right_text, arrow_l, arrow_r)

        self.play(FadeIn(center_node))
        self.play(
            GrowArrow(arrow_l), GrowArrow(arrow_r),
            FadeIn(left_text), FadeIn(right_text),
            run_time=1.5
        )

        # 3. 第二部分：聚类问题的形式化描述
        # 分隔线
        sep_line = Line(LEFT*6, RIGHT*6, color=GREY_C).move_to(ORIGIN)
        self.play(Create(sep_line, run_time=0.8))

        # 聚类定义文本
        cluster_def_text = Text("聚类目标：将集合 D 划分为 k 个互不相交的簇",
                               font="AR PL UKai CN", font_size=26, color=YELLOW)
        cluster_def_text.next_to(sep_line, DOWN, buff=0.4)

        # 数学公式
        # D = U Ci, Ci n Cj = empty
        math_formula = MathTex(
            r"D = \bigcup_{i=1}^k C_i",
            r",\quad",
            r"C_i \cap C_j = \emptyset",
            r"\;(i \neq j)",
            font_size=32
        )
        math_formula.next_to(cluster_def_text, DOWN, buff=0.3)

        # 可视化图示：集合划分
        # 大集合 D
        set_rect = Rectangle(width=5, height=1.8, color=WHITE, fill_opacity=0.1)
        set_rect.next_to(math_formula, DOWN, buff=0.3)
        set_label = MathTex("D", font_size=24).move_to(set_rect.get_corner(UL) + DR * 0.3)

        # 内部簇 C1, C2, C3
        c1 = Circle(radius=0.5, color=GREEN, fill_opacity=0.3).move_to(set_rect.get_left() + RIGHT * 1.2)
        c2 = Circle(radius=0.5, color=RED, fill_opacity=0.3).move_to(set_rect.get_center())
        c3 = Circle(radius=0.5, color=BLUE, fill_opacity=0.3).move_to(set_rect.get_right() + LEFT * 1.2)

        c1_lab = MathTex("C_1", font_size=20).move_to(c1)
        c2_lab = MathTex("C_2", font_size=20).move_to(c2)
        c3_lab = MathTex("C_3", font_size=20).move_to(c3)

        vis_group = VGroup(set_rect, set_label, c1, c2, c3, c1_lab, c2_lab, c3_lab)

        # 动画展示下半部分
        self.play(Write(cluster_def_text, run_time=1.0))
        self.play(Write(math_formula, run_time=1.0))
        self.play(
            Create(set_rect),
            Write(set_label),
            FadeIn(VGroup(c1, c2, c3), scale=0.5),
            Write(VGroup(c1_lab, c2_lab, c3_lab)),
            run_time=1.5
        )

        # 强调互不相交
        surr_rect = SurroundingRectangle(math_formula[2], color=RED, buff=0.1)
        self.play(Create(surr_rect), run_time=0.5)
