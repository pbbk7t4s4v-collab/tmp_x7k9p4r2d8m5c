from manim import *

class NeuralNetworkIntro(Scene):
    def construct(self):

        # 1. 标题部分
        title = Text("神经网络的基础",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧:分类问题实例可视化
        # 创建坐标系
        axes = Axes(
            x_range=[-2, 2], y_range=[-2, 2],
            x_length=3.5, y_length=3.5,
            axis_config={"include_tip": True, "tip_length": 0.15}
        )

        # 模拟两类数据点
        class_a_points = VGroup(*[
            Dot(point=axes.c2p(x, y), color=BLUE, radius=0.06)
            for x, y in [(-1, 1), (-0.5, 0.8), (-1.2, 0.2), (-0.2, 1.5)]
        ])
        class_b_points = VGroup(*[
            Dot(point=axes.c2p(x, y), color=RED, radius=0.06)
            for x, y in [(1, -1), (0.5, -0.5), (1.2, -0.2), (0.8, -1.2)]
        ])

        # 分类边界线
        boundary = Line(
            start=axes.c2p(-1.5, -1.5),
            end=axes.c2p(1.5, 1.5),
            color=YELLOW,
            stroke_width=2
        )

        class_label = Text("分类问题实例", font="AR PL UKai CN", font_size=20).next_to(axes, DOWN)

        left_group = VGroup(axes, class_a_points, class_b_points, boundary, class_label)
        left_group.to_edge(LEFT, buff=1.0).shift(UP*0.5)

        # 3. 右侧:神经网络示意图与公式
        # 构建简单的 MLP 结构
        layers = [3, 4, 2] # 输入层3,隐藏层4,输出层2
        neuron_radius = 0.12
        neurons = VGroup()

        # 创建神经元节点
        for i, layer_size in enumerate(layers):
            layer_neurons = VGroup(*[
                Circle(radius=neuron_radius, color=WHITE, fill_opacity=0.5, stroke_width=2)
                for _ in range(layer_size)
            ])
            layer_neurons.arrange(DOWN, buff=0.25)
            neurons.add(layer_neurons)

        neurons.arrange(RIGHT, buff=1.5)

        # 创建连接线
        edges = VGroup()
        for i in range(len(layers) - 1):
            for n1 in neurons[i]:
                for n2 in neurons[i+1]:
                    edge = Line(n1.get_center(), n2.get_center(), color=GREY, stroke_width=1, stroke_opacity=0.5)
                    edges.add(edge)

        nn_viz = VGroup(edges, neurons)

        # 核心公式
        formula = Text("y = σ(Wx + b)", font_size=28, color=YELLOW)
        formula.next_to(nn_viz, DOWN, buff=0.3)

        # 结构标注
        struct_label = Text("结构示意与公式", font="AR PL UKai CN", font_size=20).next_to(formula, DOWN, buff=0.2)

        right_group = VGroup(nn_viz, formula, struct_label)
        right_group.to_edge(RIGHT, buff=1.0).shift(UP*0.5)

        # 确保左右高度一致
        right_group.match_y(left_group)

        # 4. 底部:应用领域
        # 水平排列 bullet points 比较困难,改用 VGroup 手动排列以节省空间
        app_texts = VGroup(
            Text("• 图像识别", font="AR PL UKai CN", font_size=22),
            Text("• 自然语言处理", font="AR PL UKai CN", font_size=22),
            Text("• 预测分析", font="AR PL UKai CN", font_size=22)
        ).arrange(RIGHT, buff=0.8)

        app_title = Text("主要应用:", font="AR PL UKai CN", font_size=24, color=BLUE)
        app_group = VGroup(app_title, app_texts).arrange(RIGHT, buff=0.3)
        app_group.to_edge(DOWN, buff=0.8)

        # 5. 动画流程
        # 展示左侧分类实例
        self.play(
            Create(axes, run_time=1),
            FadeIn(class_a_points, shift=UP*0.2),
            FadeIn(class_b_points, shift=DOWN*0.2),
        )
        self.play(Create(boundary), Write(class_label))

        # 展示右侧网络结构
        self.play(
            Create(neurons, lag_ratio=0.1),
            Create(edges, lag_ratio=0.01, run_time=1.5),
        )

        # 展示公式
        self.play(
            Write(formula),
            FadeIn(struct_label)
        )

        # 强调公式框
        rect = SurroundingRectangle(formula, color=BLUE, buff=0.1)
        self.play(Create(rect, run_time=0.5))

        # 展示底部应用
        self.play(FadeIn(app_group, shift=UP*0.3))
