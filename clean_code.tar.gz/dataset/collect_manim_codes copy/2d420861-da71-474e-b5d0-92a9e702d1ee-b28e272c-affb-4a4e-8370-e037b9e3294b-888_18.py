from manim import *

class KeesomInteractionScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("Keesom 相互作用与温度效应",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("18", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 公式展示
        # ---------------------------------------------------------
        # 使用 MathTex 展示 Keesom 近似公式
        formula = MathTex(
            r"V_{\text{Keesom}}(r) = -\frac{2\mu_1^2 \mu_2^2}{3(4\pi\epsilon_0)^2 k_B T r^6}",
            font_size=42
        )
        formula.next_to(title_group, DOWN, buff=0.8)

        # 强调其中的 T (温度) 和 V (势能)
        # 注意：MathTex自动拆分，这里我们将 T 标红，V 标蓝
        formula.set_color_by_tex("T", RED)
        formula.set_color_by_tex("V", BLUE)

        self.play(Write(formula), run_time=2)

        # 这里的 T 很关键，做一个强调动画
        # 找到 T 的位置（通过颜色筛选或者 tex 匹配）
        t_part = formula.get_parts_by_tex("T")
        self.play(Indicate(t_part, color=RED, scale_factor=1.5))

        # ---------------------------------------------------------
        # 3. 逻辑推导流程图 (可视化文字讲解)
        # ---------------------------------------------------------
        # 分步骤展示：温度升高 -> 热扰动 -> 取向随机 -> 吸引力减弱

        # 定义文本样式
        txt_style = {"font": "AR PL UKai CN", "font_size": 26, "color": WHITE}

        step1 = Text("温度 T 升高", **txt_style)
        step1.set_color(RED) # 强调温度

        step2 = Text("热扰动剧烈", **txt_style)

        step3 = Text("分子取向趋于随机", **txt_style)

        step4 = Text("平均吸引力减弱", **txt_style)
        step4.set_color(BLUE) # 强调结果

        # 使用箭头连接
        arrow1 = Arrow(LEFT, RIGHT, buff=0.1, color=GRAY)
        arrow2 = Arrow(LEFT, RIGHT, buff=0.1, color=GRAY)
        arrow3 = Arrow(LEFT, RIGHT, buff=0.1, color=GRAY)

        # 组合成一行 (或者两行，视宽度而定，这里分两行展示更清晰)
        # 第一行：温度 -> 热扰动
        row1 = VGroup(step1, arrow1, step2).arrange(RIGHT, buff=0.3)

        # 第二行：取向随机 -> 吸引力减弱
        row2 = VGroup(step3, arrow3, step4).arrange(RIGHT, buff=0.3)

        # 整体布局
        content_group = VGroup(row1, row2).arrange(DOWN, buff=0.8)
        content_group.next_to(formula, DOWN, buff=1.0)

        # 添加中间的连接箭头（从第一行到第二行）
        arrow_down = Arrow(step2.get_bottom(), step3.get_top(), buff=0.1, color=GRAY)

        # ---------------------------------------------------------
        # 4. 动画播放序列
        # ---------------------------------------------------------

        # 第一行
        self.play(FadeIn(step1, shift=UP))
        self.play(GrowArrow(arrow1), FadeIn(step2, shift=LEFT))

        # 向下连接
        self.play(GrowArrow(arrow_down))

        # 第二行
        self.play(FadeIn(step3, shift=UP))
        self.play(GrowArrow(arrow3), FadeIn(step4, shift=LEFT))

        # 最后给结论加一个框
        result_box = SurroundingRectangle(step4, color=YELLOW, buff=0.15)
        self.play(Create(result_box))
