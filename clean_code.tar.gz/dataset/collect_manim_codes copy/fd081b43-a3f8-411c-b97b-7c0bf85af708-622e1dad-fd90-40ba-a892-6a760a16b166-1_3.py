from manim import *

class FluidFlowConcepts(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (标准模板)
        # ---------------------------------------------------------
        title = Text("流线、迹线与路径线的概念辨析",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局 (左右分栏展示流线与迹线)
        # ---------------------------------------------------------

        # 左侧:流线 (Streamline) - 欧拉观点 (空间场)
        # ---------------------------------------------------------
        s_title = Text("流线 (Streamline)", font="AR PL UKai CN", font_size=24, color=BLUE)
        s_desc = Text("某时刻速度场切线的集合\n(欧拉观点:快照)", font="AR PL UKai CN", font_size=18, color=GRAY_B, line_spacing=1)

        # 可视化:一条曲线和切向箭头
        s_curve = FunctionGraph(lambda x: 0.5 * np.sin(x), x_range=[-2, 2], color=BLUE_A)
        # 添加切向箭头
        arrows = VGroup()
        for x_val in [-1.5, 0, 1.5]:
            p = s_curve.point_from_proportion((x_val + 2) / 4) # 简单的比例映射
            # 近似切线方向
            angle = np.arctan(0.5 * np.cos(x_val))
            arrow = Arrow(start=ORIGIN, end=RIGHT*0.6, buff=0, color=BLUE, max_tip_length_to_length_ratio=0.4)
            arrow.rotate(angle).move_to(p)
            arrows.add(arrow)

        s_group = VGroup(s_title, s_desc, s_curve, arrows).arrange(DOWN, buff=0.4)
        s_group.to_edge(LEFT, buff=1.5).shift(DOWN*0.5)

        # 右侧:迹线 (Pathline) - 拉格朗日观点 (质点历史)
        # ---------------------------------------------------------
        p_title = Text("迹线 (Pathline)", font="AR PL UKai CN", font_size=24, color=RED)
        p_desc = Text("同一质点在一段时间的轨迹\n(拉格朗日观点:历史)", font="AR PL UKai CN", font_size=18, color=GRAY_B, line_spacing=1)

        # 可视化:一个移动的点和留下的轨迹
        p_path = ParametricFunction(lambda t: np.array([t, 0.5 * np.cos(2*t), 0]), t_range=[-1.5, 1.5], color=RED_A)
        dot = Dot(color=RED).move_to(p_path.get_start())

        p_group_layout = VGroup(p_title, p_desc, p_path).arrange(DOWN, buff=0.4)
        p_group_layout.to_edge(RIGHT, buff=1.5).shift(DOWN*0.5)

        # 调整位置以对齐
        p_path.next_to(p_desc, DOWN, buff=0.4)
        dot.move_to(p_path.get_start())

        # ---------------------------------------------------------
        # 3. 动画演示
        # ---------------------------------------------------------

        # 显示定义文本
        self.play(
            FadeIn(s_title, shift=UP),
            FadeIn(s_desc),
            FadeIn(p_title, shift=UP),
            FadeIn(p_desc),
            run_time=1.5
        )

        # 演示流线 (静态场显示)
        self.play(
            Create(s_curve),
            GrowArrow(arrows[0]),
            GrowArrow(arrows[1]),
            GrowArrow(arrows[2]),
            run_time=2
        )

        # 演示迹线 (动态点移动)
        self.play(
            MoveAlongPath(dot, p_path, rate_func=linear),
            Create(p_path),
            run_time=3
        )

        # ---------------------------------------------------------
        # 4. 强调框
        # ---------------------------------------------------------
        rect_left = SurroundingRectangle(s_group, color=BLUE, buff=0.2, corner_radius=0.1)
        rect_right = SurroundingRectangle(p_group_layout, color=RED, buff=0.2, corner_radius=0.1)

        self.play(
            Create(rect_left),
            Create(rect_right),
            run_time=1
        )
