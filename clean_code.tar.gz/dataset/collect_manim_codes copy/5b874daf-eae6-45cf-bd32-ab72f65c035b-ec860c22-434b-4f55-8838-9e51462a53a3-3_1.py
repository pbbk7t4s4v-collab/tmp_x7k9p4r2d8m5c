from manim import *

class ImageLayoutScene(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("多图场景展示：图片与排版",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容创建
        # 注意：严格遵守一页只使用一张图片的限制,后续图片位置使用几何图形占位示意

        # 图片1：使用实际的 placeholder.png
        # 注释：这里展示第一张测试图片，用于说明主要视觉内容
        img1 = Rectangle(height=2.5, width=4.0, color=GRAY, fill_opacity=0.3)
        img1.set_height(2.5) # 设置高度，保持纵横比
        label1 = Text("测试图片1", font="AR PL UKai CN", font_size=24).next_to(img1, DOWN)
        group1 = Group(img1, label1)

        # 图片2：使用几何图形占位 (模拟多图布局)
        rect2 = Rectangle(height=2.5, width=img1.width, color=BLUE, fill_opacity=0.3)
        placeholder_text2 = Text("占位图2", font="AR PL UKai CN", font_size=20).move_to(rect2)
        label2 = Text("测试图片2", font="AR PL UKai CN", font_size=24).next_to(rect2, DOWN)
        group2 = Group(rect2, placeholder_text2, label2)

        # 图片3：使用几何图形占位 (模拟多图布局)
        rect3 = Rectangle(height=2.5, width=img1.width, color=GREEN, fill_opacity=0.3)
        placeholder_text3 = Text("占位图3", font="AR PL UKai CN", font_size=20).move_to(rect3)
        label3 = Text("测试图片3", font="AR PL UKai CN", font_size=24).next_to(rect3, DOWN)
        group3 = Group(rect3, placeholder_text3, label3)

        # 3. 布局排列
        # 将三个组横向排列，间距适中
        main_group = Group(group1, group2, group3).arrange(RIGHT, buff=0.8)
        main_group.move_to(ORIGIN).shift(DOWN * 0.3)

        # 4. 强调框
        # 强调整个图片展示区域
        outline = SurroundingRectangle(main_group, color=YELLOW, buff=0.2)
        outline_label = Text("多媒体资源列表", font="AR PL UKai CN", font_size=20, color=YELLOW)
        outline_label.next_to(outline, UP)

        # 5. 动画播放序列
        # 依次展示图片和占位符
        self.play(FadeIn(img1), Write(label1))

        self.play(FadeIn(group2))

        self.play(FadeIn(group3))

        # 展示整体强调框
        self.play(
            Create(outline),
            Write(outline_label)
        )
