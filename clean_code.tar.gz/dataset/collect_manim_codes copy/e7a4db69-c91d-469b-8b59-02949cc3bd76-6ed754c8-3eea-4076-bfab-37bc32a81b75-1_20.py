from manim import *

class Transistor9013Example(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("9013三极管示例解析",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("20", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：绘制三极管示意图 (使用几何图形)
        # 管身 (TO-92 封装示意，黑色半圆柱/切角矩形)
        body = RoundedRectangle(
            corner_radius=0.4,
            height=3.0,
            width=2.2,
            fill_color="#333333",
            fill_opacity=1,
            stroke_color=WHITE,
            stroke_width=2
        )

        # 型号标注
        label_9013 = Text("9013", font_size=24, color=WHITE).move_to(body.get_center() + UP*0.5)

        # 管脚 (Lines)
        leg_config = {"stroke_width": 6, "color": LIGHT_GREY}
        leg_center = Line(body.get_bottom(), body.get_bottom() + DOWN*1.2, **leg_config)
        leg_left = Line(body.get_bottom() + LEFT*0.6, body.get_bottom() + LEFT*0.8 + DOWN*1.2, **leg_config)
        leg_right = Line(body.get_bottom() + RIGHT*0.6, body.get_bottom() + RIGHT*0.8 + DOWN*1.2, **leg_config)

        legs = VGroup(leg_left, leg_center, leg_right)

        # 管脚标识 (E-B-C)
        # 注意：讲义中提到从左至右为 E-B-C
        label_e = Text("E", font_size=24, color=YELLOW, font="AR PL UKai CN").next_to(leg_left, DOWN, buff=0.1)
        label_b = Text("B", font_size=24, color=YELLOW, font="AR PL UKai CN").next_to(leg_center, DOWN, buff=0.1)
        label_c = Text("C", font_size=24, color=YELLOW, font="AR PL UKai CN").next_to(leg_right, DOWN, buff=0.1)

        pin_labels = VGroup(label_e, label_b, label_c)

        # 组合左侧图形
        transistor_group = VGroup(legs, body, label_9013, pin_labels)
        transistor_group.to_edge(LEFT, buff=1.5).shift(DOWN*0.5)

        # 3. 右侧：参数与应用说明 (Text + MathTex)
        # 辅助函数：创建一行文本
        def create_info_line(label_text, value_tex, color=WHITE):
            t = Text(label_text, font="AR PL UKai CN", font_size=24, color=color)
            if value_tex:
                v = MathTex(value_tex, font_size=28, color=BLUE)
                v.next_to(t, RIGHT, buff=0.2)
                return VGroup(t, v)
            return t

        # 封装形式
        line1 = create_info_line("封装形式：", "\\text{TO-92}")
        # 放大倍数
        line2 = create_info_line("放大倍数 (\\beta)：", "100 \\sim 300")
        # 最大集电极电流
        line3 = create_info_line("最大集电极电流：", "I_C = 500\\text{mA}")
        # 应用场景
        line4 = Text("应用：LED驱动、继电器控制", font="AR PL UKai CN", font_size=24, color=GREEN)
        # 小功率开关
        line5 = Text("(小功率开关场合)", font="AR PL UKai CN", font_size=20, color=GREY)

        # 组合文本
        info_group = VGroup(line1, line2, line3, line4, line5)
        info_group.arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        info_group.next_to(transistor_group, RIGHT, buff=1.5)

        # 装饰框
        info_box = SurroundingRectangle(info_group, color=BLUE, buff=0.2, stroke_width=1)

        # 4. 动画播放流程
        # 绘制三极管主体
        self.play(
            FadeIn(body),
            Create(legs),
            Write(label_9013),
            run_time=1.5
        )

        # 强调管脚定义
        self.play(Write(pin_labels), run_time=1)

        # 依次显示右侧信息
        self.play(Create(info_box), FadeIn(info_group, shift=LEFT), run_time=1.5)

        # 简单强调应用场景
        self.play(Indicate(line4, color=GREEN_A), run_time=1)
