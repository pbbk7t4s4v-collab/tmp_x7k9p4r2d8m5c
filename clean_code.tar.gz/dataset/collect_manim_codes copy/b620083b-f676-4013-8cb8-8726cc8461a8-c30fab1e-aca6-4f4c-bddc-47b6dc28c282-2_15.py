from manim import *

class UncertaintyCalculationProcess(Scene):
    def construct(self):

        # ---------------------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------------------
        title = Text("测量不确定度计算实例",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("23", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------------------
        # 2. 内容布局设计
        #    将屏幕分为左右两部分:左侧为数据处理基础,右侧为A/B类分量计算
        # ---------------------------------------------------------------------

        # --- 左侧:基础数据处理 ---

        # 步骤1:修正零位误差
        step1_label = Text("1. 修正零位误差", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        step1_math = MathTex(r"d_i = d_i' - d_0", font_size=28)
        step1_group = VGroup(step1_label, step1_math).arrange(DOWN, buff=0.15).align_to(LEFT, LEFT)

        # 步骤2:计算平均值
        step2_label = Text("2. 计算平均值", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        step2_math = MathTex(r"\bar{x} = 0.246 \text{ mm}", font_size=28)
        step2_group = VGroup(step2_label, step2_math).arrange(DOWN, buff=0.15).align_to(LEFT, LEFT)

        # 步骤3:标准偏差
        step3_label = Text("3. 计算标准偏差", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        step3_math = MathTex(r"\sigma_x = \sqrt{\frac{\sum(x_i-\bar{x})^2}{n-1}}", font_size=28)
        step3_group = VGroup(step3_label, step3_math).arrange(DOWN, buff=0.15).align_to(LEFT, LEFT)

        # 左侧整体组合
        left_panel = VGroup(step1_group, step2_group, step3_group).arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        left_panel.to_edge(LEFT, buff=1.0).shift(UP*0.5)

        # --- 右侧:不确定度分量 ---

        # 步骤4:A类分量
        step4_label = Text("4. 求A类分量 (n=6)", font="AR PL UKai CN", font_size=24, color=YELLOW)
        # t_{0.95} 在 n=6 时为 1.05 (根据讲义逻辑,虽然通常t因子查表不同,此处遵循讲义数值)
        step4_math = MathTex(r"\Delta_a = \frac{t_{0.95}}{\sqrt{n}}\sigma_x \approx 0.002 \text{ mm}", font_size=28)
        step4_note = Text("(t因子取1.05)", font="AR PL UKai CN", font_size=20, color=GRAY)
        step4_group = VGroup(step4_label, step4_math, step4_note).arrange(DOWN, buff=0.15).align_to(LEFT, LEFT)

        # 步骤5:B类分量
        step5_label = Text("5. 求B类分量 (c=1.05)", font="AR PL UKai CN", font_size=24, color=YELLOW)
        # 使用 \Delta_{inst} 代替中文下标避免Latex问题
        step5_math = MathTex(r"\Delta_b = \frac{\Delta_{inst}}{c} \approx 0.004 \text{ mm}", font_size=28)
        step5_group = VGroup(step5_label, step5_math).arrange(DOWN, buff=0.15).align_to(LEFT, LEFT)

        # 右侧整体组合
        right_panel = VGroup(step4_group, step5_group).arrange(DOWN, buff=0.8, aligned_edge=LEFT)
        right_panel.next_to(left_panel, RIGHT, buff=1.5).align_to(left_panel, UP)

        # 分隔线
        separator = Line(UP*2, DOWN*2, color=GRAY, stroke_opacity=0.5)
        separator.move_to((left_panel.get_right() + right_panel.get_left()) / 2)

        # ---------------------------------------------------------------------
        # 3. 动画演示流程
        # ---------------------------------------------------------------------

        # 显示分隔线
        self.play(Create(separator), run_time=0.5)

        # 左侧动画:逐步显示数据处理步骤
        self.play(FadeIn(step1_group, shift=RIGHT*0.2), run_time=0.6)

        self.play(FadeIn(step2_group, shift=RIGHT*0.2), run_time=0.6)

        self.play(FadeIn(step3_group, shift=RIGHT*0.2), run_time=0.6)

        # 右侧动画:显示不确定度计算
        # A类
        self.play(Write(step4_group), run_time=1.0)

        # 强调A类结果
        rect_a = SurroundingRectangle(step4_math, color=YELLOW, buff=0.1)
        self.play(Create(rect_a), run_time=0.5)

        # B类
        self.play(Write(step5_group), run_time=1.0)

        # 强调B类结果
        rect_b = SurroundingRectangle(step5_math, color=YELLOW, buff=0.1)
        self.play(Create(rect_b), run_time=0.5)
