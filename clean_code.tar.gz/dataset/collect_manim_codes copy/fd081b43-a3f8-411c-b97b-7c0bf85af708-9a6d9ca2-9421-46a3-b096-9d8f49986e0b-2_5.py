from manim import *

class DifferentialApproximation(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("微分近似的应用",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局规划：左侧公式与说明，右侧图形演示
        # 左侧内容
        formula = MathTex(
            r"f(x + \Delta x) \approx f(x) + f'(x)\Delta x",
            font_size=38
        )
        formula.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 说明文字
        desc_text1 = Text("利用切线代替曲线", font="AR PL UKai CN", font_size=24, color=YELLOW)
        desc_text2 = Text("在局部范围内进行快速估算", font="AR PL UKai CN", font_size=24)

        desc_group = VGroup(desc_text1, desc_text2).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        desc_group.next_to(formula, DOWN, buff=0.5).align_to(formula, LEFT)

        # 强调框
        rect = SurroundingRectangle(formula, color=BLUE, buff=0.2)

        # 右侧图形内容
        # 创建坐标系
        axes = Axes(
            x_range=[0, 4.5, 1],
            y_range=[0, 5, 1],
            x_length=5,
            y_length=4,
            axis_config={"include_tip": True, "tip_shape": StealthTip}
        )
        axes.to_edge(RIGHT, buff=0.5).shift(DOWN * 0.5)

        axes_labels = axes.get_axis_labels(x_label="x", y_label="y")

        # 定义函数 f(x) = 0.2*x^2 + 1 (平滑曲线)
        func = lambda x: 0.2 * (x ** 2) + 1
        graph = axes.plot(func, color=BLUE, x_range=[0, 4.2])
        graph_label = MathTex("f(x)", color=BLUE, font_size=24).next_to(graph, UP, buff=0.1)

        # 设定点 x 和 x + dx
        x_val = 2.0
        dx_val = 1.5
        x_new_val = x_val + dx_val

        # 计算点坐标
        p1_coords = axes.c2p(x_val, func(x_val))
        p2_actual_coords = axes.c2p(x_new_val, func(x_new_val)) # 真实值点

        # 切线计算: f'(x) = 0.4x -> f'(2) = 0.8
        slope = 0.4 * x_val
        # 切线方程: y - f(x) = slope * (x - x_val)
        tangent_func = lambda x: slope * (x - x_val) + func(x_val)
        tangent_line = axes.plot(tangent_func, color=GREEN, x_range=[0.5, 4.2])

        # 近似值点坐标 (在切线上)
        p2_approx_coords = axes.c2p(x_new_val, tangent_func(x_new_val))

        # 辅助元素
        dot_x = Dot(p1_coords, color=WHITE)
        dot_actual = Dot(p2_actual_coords, color=BLUE) # 真实值
        dot_approx = Dot(p2_approx_coords, color=GREEN) # 近似值

        # 垂直虚线表示 dx
        v_line = DashedLine(
            start=axes.c2p(x_new_val, 0),
            end=p2_actual_coords,
            color=GRAY,
            stroke_opacity=0.5
        )

        # 标注 dx
        brace_dx = BraceBetweenPoints(
            axes.c2p(x_val, 0),
            axes.c2p(x_new_val, 0),
            direction=DOWN,
            buff=0.1
        )
        label_dx = MathTex(r"\Delta x", font_size=24).next_to(brace_dx, DOWN, buff=0.1)

        # 标注 f(x) 和 近似点
        label_fx = MathTex("f(x)", font_size=24).next_to(dot_x, UP+LEFT, buff=0.1)
        label_approx = Text("近似值", font="AR PL UKai CN", font_size=20, color=GREEN).next_to(dot_approx, RIGHT, buff=0.1)

        # 3. 动画演示流程

        # 第一阶段：显示公式
        self.play(Write(formula))
        self.play(Create(rect))

        # 第二阶段：绘制图形基础
        self.play(
            Create(axes),
            Write(axes_labels),
            Create(graph),
            Write(graph_label),
            run_time=1.5
        )

        # 第三阶段：展示切线近似原理
        self.play(
            FadeIn(dot_x),
            Write(label_fx),
            Create(tangent_line),
            run_time=1
        )

        # 移动 dx 并显示差异
        self.play(
            GrowFromCenter(brace_dx),
            Write(label_dx),
            Create(v_line),
            run_time=1
        )

        self.play(
            FadeIn(dot_approx),
            Write(label_approx),
            FadeIn(dot_actual),
            run_time=1
        )

        # 第四阶段：显示结论文字
        self.play(Write(desc_group))

        # 稍微停顿，展示整体
