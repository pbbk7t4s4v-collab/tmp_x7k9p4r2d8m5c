from manim import *

class JudicialTension(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格遵守模板)
        # ---------------------------------------------------------
        title = Text("技术赋能与司法民主化张力",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("52", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 左侧：ODR平台的双面性 (概念可视化)
        # ---------------------------------------------------------
        # 左侧容器
        left_group = VGroup()

        # ODR 标题
        odr_label = Text("在线争议解决 (ODR)", font="AR PL UKai CN", font_size=28, color=BLUE)

        # 优势部分
        pros_title = Text("技术赋能 (优势)", font="AR PL UKai CN", font_size=24, color=GREEN)
        pros_desc = Text("• 降低司法门槛\n• 低成本解决纠纷", font="AR PL UKai CN", font_size=20, line_spacing=0.8).next_to(pros_title, DOWN, buff=0.2, aligned_edge=LEFT)

        # 风险部分
        cons_title = Text("算法风险 (张力)", font="AR PL UKai CN", font_size=24, color=RED)
        cons_desc = Text("• "批量正义"忽视个案\n• 主体异化为数据点", font="AR PL UKai CN", font_size=20, line_spacing=0.8).next_to(cons_title, DOWN, buff=0.2, aligned_edge=LEFT)

        # 组合左侧内容
        left_content = VGroup(odr_label, pros_title, pros_desc, cons_title, cons_desc)
        left_content.arrange(DOWN, buff=0.4, aligned_edge=LEFT)
        left_content.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # ---------------------------------------------------------
        # 3. 右侧:威斯康星州诉卢米斯案 (流程图可视化)
        # ---------------------------------------------------------
        # 案例标题
        case_title = Text("示例:威斯康星州诉卢米斯案", font="AR PL UKai CN", font_size=26, color=YELLOW)
        case_title.to_edge(RIGHT, buff=1.0).align_to(title_line, DOWN).shift(DOWN * 1.0)

        # 流程图元素
        # 输入:被告
        input_node = Text("被告\n数据", font="AR PL UKai CN", font_size=20)
        input_box = SurroundingRectangle(input_node, color=WHITE, buff=0.1)
        input_group = VGroup(input_box, input_node)

        # 处理:COMPAS算法 (黑箱)
        process_text = Text("COMPAS\n系统", font="AR PL UKai CN", font_size=20)
        process_box = Rectangle(height=1.2, width=2.0, color=GRAY, fill_opacity=0.5, fill_color=DARK_GRAY)
        process_label = Text("算法黑箱", font="AR PL UKai CN", font_size=16, color=LIGHT_GRAY).next_to(process_box, UP, buff=0.1)
        process_group = VGroup(process_box, process_text, process_label)

        # 输出:判决
        output_text = Text("高风险\n重刑", font="AR PL UKai CN", font_size=20, color=RED)
        output_box = SurroundingRectangle(output_text, color=RED, buff=0.1)
        output_group = VGroup(output_box, output_text)

        # 定位流程图
        process_group.next_to(case_title, DOWN, buff=0.8)
        input_group.next_to(process_group, LEFT, buff=0.5)
        output_group.next_to(process_group, RIGHT, buff=0.5)

        # 箭头
        arrow1 = Arrow(input_box.get_right(), process_box.get_left(), buff=0.1)
        arrow2 = Arrow(process_box.get_right(), output_box.get_left(), buff=0.1)

        # 结论文本
        conclusion_text = Text("最高院判决:\n不可仅依赖算法,需综合判断",
                             font="AR PL UKai CN", font_size=22, color=ORANGE, line_spacing=1.0)
        conclusion_text.next_to(process_group, DOWN, buff=0.6)
        conclusion_rect = SurroundingRectangle(conclusion_text, color=YELLOW, buff=0.15)

        # ---------------------------------------------------------
        # 4. 动画播放序列
        # ---------------------------------------------------------

        # 展示左侧概念
        self.play(FadeIn(odr_label))
        self.play(
            FadeIn(pros_title, shift=RIGHT),
            FadeIn(pros_desc, shift=RIGHT)
        )
        self.play(
            FadeIn(cons_title, shift=RIGHT),
            FadeIn(cons_desc, shift=RIGHT)
        )

        # 展示右侧案例流程
        self.play(Write(case_title))
        self.play(
            Create(input_group),
            Create(process_group),
            Create(output_group),
            GrowArrow(arrow1),
            GrowArrow(arrow2)
        )

        # 强调判决核心
        self.play(
            Write(conclusion_text),
            Create(conclusion_rect)
        )
