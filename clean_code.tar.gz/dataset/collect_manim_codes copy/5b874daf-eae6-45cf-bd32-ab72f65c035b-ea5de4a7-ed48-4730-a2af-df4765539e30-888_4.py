from manim import *

class CNNArchitectureAndApps(Scene):
    def construct(self):
        # ==========================================
        # 0. 视觉风格配置 (Visual Config)
        # ==========================================
        # 字体
        FONT_MAIN = "AR PL UKai CN"

        # 配色 (更轻盈的玻璃质感)
        COLOR_ACCENT = "#FFD700"     # 金色
        COLOR_CARD_BG = "#2E2E2E"    # 略微提亮的深灰背景
        COLOR_CARD_BORDER = WHITE    # 细白边框
        COLOR_TEXT_MAIN = WHITE

        # 透明度设置
        OPACITY_BG_OVERLAY = 0.8     # 背景压暗程度
        OPACITY_CARD_FILL = 0.6      # 卡片透明度
        OPACITY_CARD_STROKE = 0.3    # 边框透明度

        # ==========================================
        # 1. 背景与氛围 (Background)
        # ==========================================
        # 尝试加载背景图
        try:
            bg = ImageMobject("/home/TeachMasterAppV2/backend/SAI.png")
            bg.set_z_index(-100)
            bg.scale(max(config.frame_width/bg.width, config.frame_height/bg.height))
            bg.move_to(ORIGIN)
            self.add(bg)
        except:
            self.camera.background_color = "#111111"

        # [关键修复]: 全局遮罩 (去掉了白边)
        bg_overlay = Rectangle(
            # 让遮罩比屏幕稍微大一点点 (0.1)，防止边缘有缝隙
            width=config.frame_width + 0.1,
            height=config.frame_height + 0.1,
            fill_color=BLACK,
            fill_opacity=OPACITY_BG_OVERLAY,
            stroke_width=0  # <--- [修复点] 这一行去掉了白边
        ).set_z_index(-99)
        self.add(bg_overlay)

        # ==========================================
        # 2. 布局容器：大尺寸英雄卡片
        # ==========================================
        # 卡片主体 (12x7)
        hero_card = RoundedRectangle(
            corner_radius=0.5, width=12.0, height=7.0,
            fill_color=COLOR_CARD_BG, fill_opacity=OPACITY_CARD_FILL,
            stroke_color=COLOR_CARD_BORDER, stroke_width=2, stroke_opacity=OPACITY_CARD_STROKE
        ).move_to(ORIGIN)

        # 顶部装饰线 (位于标题下方)
        # 计算线条宽度：比卡片略窄 (左右各留 1.0 的边距)
        line_width = 12.0 - 2.0
        header_line = Line(LEFT * (line_width/2), RIGHT * (line_width/2), color=COLOR_ACCENT)
        # 将线条放在卡片顶部向下一点的位置
        header_line.next_to(hero_card.get_top(), DOWN, buff=1.2)

        # 标题 (位于线条上方)
        title_text = "CNN: Architecture & Applications"

        title = Text(title_text, font=FONT_MAIN, font_size=42, color=COLOR_TEXT_MAIN, weight=BOLD)
        title.next_to(header_line, UP, buff=0.25)

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)

        # 入场动画
        self.play(
            FadeIn(hero_card, scale=0.95),
            Create(header_line),
            Write(title),
            FadeIn(page_number),
            run_time=1.5
        )

        # ==========================================
        # 3. 内容填充区 (Content Area)
        # ==========================================
        # Architecture Diagram Section
        layer_props = [
            ("Input", BLUE, 1.0),
            ("Conv", GREEN, 0.9),
            ("Pool", YELLOW, 0.8),
            ("FC", RED, 0.7)
        ]

        layers = VGroup()
        for text, color, size in layer_props:
            box = Rectangle(height=size, width=0.7, color=color, fill_opacity=0.5)
            label = Text(text, font_size=16).move_to(box)
            layer_group = VGroup(box, label)
            layers.add(layer_group)

        layers.arrange(RIGHT, buff=0.8)

        # Arrows connecting layers - positioned between boxes at center or slightly downward
        arrows = VGroup()
        for i in range(len(layers) - 1):
            # Calculate arrow positions from right edge of current box to left edge of next box
            # Position at center height or slightly lower (DOWN * 0.1 for slight downward tilt)
            start_pos = layers[i].get_right() + DOWN * 0.1
            end_pos = layers[i+1].get_left() + DOWN * 0.1
            arrow = Arrow(
                start=start_pos,
                end=end_pos,
                buff=0.05,  # Small buffer to keep arrow from touching box edges
                color=GREY,
                max_tip_length_to_length_ratio=0.2,
                stroke_width=3
            )
            arrows.add(arrow)

        # Label for Architecture
        arch_label = Text("Architecture Breakdown", font_size=22, color=BLUE_B)

        # Combine layers and arrows into one group
        layers_with_arrows = VGroup(layers, arrows)

        arch_section = VGroup(arch_label, layers_with_arrows)
        arch_section.arrange(DOWN, buff=0.3)
        arch_section.next_to(header_line, DOWN, buff=0.5)

        # Frame for Architecture - now includes arrows
        arch_frame = SurroundingRectangle(arch_section, color=BLUE_C, buff=0.15, stroke_width=1)

        # Applications & Training Strategy Section
        # Left: Applications
        app_title = Text("Common Applications", font_size=20, weight=BOLD, color=GOLD)
        app_list = VGroup(
            Text("• Medical: CT/MRI Analysis", font_size=18),
            Text("• Auto: Road/Pedestrian Perception", font_size=18)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.12)

        app_group = VGroup(app_title, app_list).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # Right: Early Stopping Concept
        stop_title = Text("Training Strategy", font_size=20, weight=BOLD, color=GOLD)
        stop_desc = Text("Early Stopping:\nMonitor val_loss to\nprevent overfitting.", font_size=18, line_spacing=1.1)

        stop_group = VGroup(stop_title, stop_desc).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # Arrange app and stop side by side
        bottom_section = VGroup(app_group, stop_group).arrange(RIGHT, buff=1.2)
        bottom_section.next_to(arch_section, DOWN, buff=0.5)

        # ==========================================
        # 4. 动画流 (Animation)
        # ==========================================
        # Show Architecture
        self.play(FadeIn(arch_label, shift=DOWN))
        self.play(
            LaggedStart(
                *[Create(layer) for layer in layers],
                *[GrowArrow(arrow) for arrow in arrows],
                lag_ratio=0.2
            ),
            Create(arch_frame),
            run_time=2.5
        )

        # Show Applications and Strategy
        self.play(
            FadeIn(app_group, shift=RIGHT),
            FadeIn(stop_group, shift=LEFT),
            run_time=1.5
        )

        to_fade = [m for m in self.mobjects if m != bg and m != bg_overlay]
        self.play(FadeOut(*to_fade))
