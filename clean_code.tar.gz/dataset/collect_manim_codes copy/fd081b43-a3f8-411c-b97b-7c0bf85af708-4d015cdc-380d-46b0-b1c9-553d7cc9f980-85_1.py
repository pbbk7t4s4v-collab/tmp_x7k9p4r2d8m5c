from manim import *
import numpy as np

class LaminarVsTurbulent(Scene):
    def construct(self):

        # 1. 标题部分 (使用指定模板)
        title = Text("层流与湍流的对比",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("85", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局规划
        # 左侧区域中心
        left_center = LEFT * 3.5 + UP * 0.5
        # 右侧区域中心
        right_center = RIGHT * 3.5 + UP * 0.5

        # 3. 左侧：层流 (Laminar Flow)
        laminar_label = Text("层流 (Laminar)", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        laminar_label.move_to(left_center + UP * 1.5)

        # 绘制层流线条：平行的直线
        laminar_lines = VGroup()
        for i in range(5):
            # 在Y轴方向上均匀分布
            y_pos = -1.0 + i * 0.5
            line = Line(start=LEFT*2, end=RIGHT*2, color=BLUE)
            line.move_to(left_center + UP * (y_pos * 0.6)) # 调整垂直间距
            # 添加箭头表示方向
            arrow = Arrow(line.get_right(), line.get_right() + RIGHT*0.1, color=BLUE, buff=0, max_tip_length_to_length_ratio=0.5)
            laminar_lines.add(VGroup(line, arrow))

        # 层流描述文字
        laminar_desc = VGroup(
            Text("• 流体分层流动", font="AR PL UKai CN", font_size=22),
            Text("• 互不混合", font="AR PL UKai CN", font_size=22),
            Text("• 低雷诺数 (Re)", font="AR PL UKai CN", font_size=22, color=YELLOW)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        laminar_desc.next_to(laminar_lines, DOWN, buff=0.5)

        # 4. 右侧：湍流 (Turbulent Flow)
        turbulent_label = Text("湍流 (Turbulent)", font="AR PL UKai CN", font_size=28, color=RED_A)
        turbulent_label.move_to(right_center + UP * 1.5)

        # 绘制湍流线条：混乱的曲线
        turbulent_lines = VGroup()
        for i in range(5):
            y_base = -1.0 + i * 0.5
            # 使用参数方程模拟混乱的波形
            # y = base + A*sin(Bx + phase) + noise
            graph = FunctionGraph(
                lambda x: 0.15 * np.sin(3 * x + i * 20) + 0.08 * np.sin(10 * x + i),
                x_range=[-2, 2],
                color=RED_C
            )
            graph.move_to(right_center + UP * (y_base * 0.6))
            turbulent_lines.add(graph)

        # 湍流描述文字
        turbulent_desc = VGroup(
            Text("• 流动剧烈混合", font="AR PL UKai CN", font_size=22),
            Text("• 产生大小涡旋", font="AR PL UKai CN", font_size=22),
            Text("• 高雷诺数 (Re)", font="AR PL UKai CN", font_size=22, color=YELLOW)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        turbulent_desc.next_to(turbulent_lines, DOWN, buff=0.5)

        # 5. 边框强调
        # 为两个区域添加边框
        left_box = SurroundingRectangle(VGroup(laminar_label, laminar_desc), color=BLUE, buff=0.3, corner_radius=0.2)
        right_box = SurroundingRectangle(VGroup(turbulent_label, turbulent_desc), color=RED, buff=0.3, corner_radius=0.2)

        # 6. 动画展示
        # 显示标签
        self.play(
            FadeIn(laminar_label, shift=UP),
            FadeIn(turbulent_label, shift=UP),
            run_time=1
        )

        # 绘制流线 (层流平滑，湍流稍快且混乱)
        self.play(
            Create(laminar_lines, lag_ratio=0.1),
            Create(turbulent_lines, lag_ratio=0.2),
            run_time=2
        )

        # 显示描述文字和边框
        self.play(
            Write(laminar_desc),
            Write(turbulent_desc),
            Create(left_box),
            Create(right_box),
            run_time=2
        )
