from manim import *

class TeacherIntroduction(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("主讲教师简介与背景",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 图像内容
        # 按照Planner建议插入图片
        profile_img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/199c839c-9ede-43ef-9798-4a42a2009f86/92ce8f71-07b6-4d06-9cee-27c86ea01d4c/pictures/1_1/1.png") # 这里期望是一张展示一位大学教授的形象插画，男性，戴着眼镜，穿着得体的衬衫或西装，气质儒雅专业，面带微笑，手势仿佛在进行自我介绍。风格为扁平化矢量风或简约的2.5D风格，背景干净，适合作为计算机专业课程的主讲人虚拟形象。

        # 调整图像大小和位置（假设图片为1:1比例）
        profile_img.set_height(4.5)
        profile_img.next_to(title_group, DOWN, buff=0.5).to_edge(LEFT, buff=1.5)

        # 3. 文本介绍内容
        # 使用VGroup和Text进行排版
        intro_text_group = VGroup(
            Text("清华大学计算机系博士", font="AR PL UKai CN", font_size=28, color=TEAL),
            Text("长聘副教授", font="AR PL UKai CN", font_size=28, weight=BOLD),
            Text("师从孙家广院士", font="AR PL UKai CN", font_size=26),
            Line(LEFT, RIGHT, stroke_width=1, color=GRAY).set_width(4), # 分割线
            Text("访问研究经历：", font="AR PL UKai CN", font_size=24, color=YELLOW),
            Text("• 香港理工大学", font="AR PL UKai CN", font_size=24),
            Text("• 荷兰埃因霍温科技大学", font="AR PL UKai CN", font_size=24)
        )

        # 设置文本对齐和间距
        intro_text_group.arrange(DOWN, aligned_edge=LEFT, buff=0.35)

        # 将文本放置在图片右侧
        intro_text_group.next_to(profile_img, RIGHT, buff=1.0)

        # 添加装饰性边框
        border = SurroundingRectangle(intro_text_group, color=BLUE, buff=0.4, corner_radius=0.2)

        # 4. 动画展示
        # 图片淡入
        self.play(FadeIn(profile_img, shift=RIGHT), run_time=1)

        # 边框生成
        self.play(Create(border), run_time=0.8)

        # 文本内容逐行书写
        self.play(Write(intro_text_group), run_time=3)

        # 5. 停留
