from manim import *

class DRLChallenges(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("深度强化学习面临的挑战",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("27", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局设计 (2x2 网格展示挑战)
        # ---------------------------------------------------------

        # 定义通用样式
        text_font = "AR PL UKai CN"
        item_scale = 0.8

        # --- 模块 1: 参数空间与稳定性 ---
        # 图示：简单的点阵代表参数空间
        dots = VGroup(*[Dot(radius=0.05, color=BLUE_A) for _ in range(9)]).arrange_in_grid(3, 3, buff=0.15)
        text_1_title = Text("参数空间巨大", font=text_font, font_size=24, color=BLUE)
        text_1_sub = Text("训练不稳定", font=text_font, font_size=20, color=GRAY_B)
        group_1 = VGroup(dots, text_1_title, text_1_sub).arrange(DOWN, buff=0.2)

        # --- 模块 2: 过拟合 ---
        # 图示：锯齿状线条代表过拟合
        zigzag = VGroup(
            Line(ORIGIN, UP*0.3+RIGHT*0.2),
            Line(UP*0.3+RIGHT*0.2, DOWN*0.2+RIGHT*0.4),
            Line(DOWN*0.2+RIGHT*0.4, UP*0.4+RIGHT*0.6)
        ).set_color(RED).move_to(ORIGIN)
        text_2_title = Text("容易过拟合", font=text_font, font_size=24, color=RED)
        group_2 = VGroup(zigzag, text_2_title).arrange(DOWN, buff=0.2)

        # --- 模块 3: 样本需求 ---
        # 图示：堆叠的小方块代表大量样本
        squares = VGroup(*[Square(side_length=0.15, color=GREEN, fill_opacity=0.5) for _ in range(4)]).arrange(RIGHT, buff=0.1)
        text_3_title = Text("需要大量样本", font=text_font, font_size=24, color=GREEN)
        group_3 = VGroup(squares, text_3_title).arrange(DOWN, buff=0.2)

        # --- 模块 4: 硬件效率 ---
        # 图示：两个方块加双向箭头
        box_cpu = Rectangle(height=0.3, width=0.5, color=GOLD)
        box_gpu = Rectangle(height=0.3, width=0.5, color=GOLD)
        arrow = DoubleArrow(LEFT*0.3, RIGHT*0.3, buff=0, color=GOLD, stroke_width=2)
        hardware_icon = VGroup(box_cpu, arrow, box_gpu).arrange(RIGHT, buff=0.1)
        text_4_title = Text("硬件协同效率", font=text_font, font_size=24, color=GOLD)
        text_4_sub = Text("CPU 与 GPU", font=text_font, font_size=20, color=GRAY_B)
        group_4 = VGroup(hardware_icon, text_4_title, text_4_sub).arrange(DOWN, buff=0.2)

        # --- 组合所有模块 ---
        # 将四个组放入一个大的 VGroup 并排列成 2x2 网格
        all_challenges = VGroup(group_1, group_2, group_3, group_4).arrange_in_grid(rows=2, cols=2, buff=(2.0, 1.0))
        all_challenges.move_to(ORIGIN).shift(DOWN * 0.5) # 下移一点避开标题

        # --- 添加边框 ---
        rects = VGroup()
        for item in all_challenges:
            rect = SurroundingRectangle(item, color=WHITE, buff=0.3, corner_radius=0.2)
            rect.set_stroke(width=2, opacity=0.5)
            rects.add(rect)

        # ---------------------------------------------------------
        # 3. 动画呈现
        # ---------------------------------------------------------

        # 依次展示四个挑战
        # 左上
        self.play(
            Create(rects[0]),
            FadeIn(group_1, shift=UP),
            run_time=1
        )

        # 右上
        self.play(
            Create(rects[1]),
            FadeIn(group_2, shift=UP),
            run_time=1
        )

        # 左下
        self.play(
            Create(rects[2]),
            FadeIn(group_3, shift=UP),
            run_time=1
        )

        # 右下
        self.play(
            Create(rects[3]),
            FadeIn(group_4, shift=UP),
            run_time=1
        )

        # 简单的强调动画：让整个组稍微放大一点点表示重点
        self.play(
            all_challenges.animate.scale(1.05),
            rects.animate.scale(1.05),
            run_time=1.5
        )
