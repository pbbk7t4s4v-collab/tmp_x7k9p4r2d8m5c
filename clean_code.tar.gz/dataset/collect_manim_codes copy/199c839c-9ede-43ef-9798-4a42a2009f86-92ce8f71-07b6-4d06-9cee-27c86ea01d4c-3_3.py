from manim import *

class OSChallengesAndStrategy(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("移动计算挑战与操作系统战略价值",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧：移动与泛在计算
        # 定义左侧子标题
        left_header = Text("移动与泛在计算新需求", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        left_header.move_to(LEFT * 3.5 + UP * 1.5)

        # 插入图片1
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/199c839c-9ede-43ef-9798-4a42a2009f86/92ce8f71-07b6-4d06-9cee-27c86ea01d4c/pictures/3_3/1.png") # 这里期望是一张展示移动计算与泛在计算的场景，画面中心是一部现代智能手机，周围环绕着连接的物联网（IoT）设备，如智能手表、智能家电、传感器等，通过光线或线条连接，背景为深蓝色科技风，要求画面科技感十足，写实风
        img1.height = 2.0  # 调整高度以适应屏幕
        img1.next_to(left_header, DOWN, buff=0.3)

        # 左侧文字要点
        left_points = VGroup(
            Text("• 更强的功耗管理能力", font="AR PL UKai CN", font_size=20),
            Text("• 实时响应能力", font="AR PL UKai CN", font_size=20),
            Text("• 异构硬件支持能力", font="AR PL UKai CN", font_size=20)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        left_points.next_to(img1, DOWN, buff=0.4)

        # 3. 内容布局 - 右侧：国家战略价值
        # 定义右侧子标题
        right_header = Text("OS的国家战略与国产化", font="AR PL UKai CN", font_size=24, color=RED_A)
        right_header.move_to(RIGHT * 3.5 + UP * 1.5)

        # 插入图片2
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/199c839c-9ede-43ef-9798-4a42a2009f86/92ce8f71-07b6-4d06-9cee-27c86ea01d4c/pictures/3_3/2.png") # 这里期望是一张象征操作系统作为国家战略基础设施的插图，画面包含底层的服务器机柜或芯片电路板，上方有一个发光的盾牌或锁形图标，象征数据的底层控制权与安全性，风格为严肃、大气的科技写实风
        img2.height = 2.0
        img2.next_to(right_header, DOWN, buff=0.3)

        # 右侧文字要点
        right_points = VGroup(
            Text("• 掌握数据底层控制权", font="AR PL UKai CN", font_size=20),
            Text("• 关键基础设施安全前提", font="AR PL UKai CN", font_size=20),
            Text("• 自主可控的必要性", font="AR PL UKai CN", font_size=20)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        right_points.next_to(img2, DOWN, buff=0.4)

        # 4. 动画展示过程
        # 展示左侧内容
        self.play(FadeIn(left_header, shift=DOWN), FadeIn(img1, scale=0.9))
        self.play(Write(left_points), run_time=2)

        # 分隔线
        separator = Line(UP*2, DOWN*2, color=GRAY, stroke_opacity=0.5)
        self.play(Create(separator), run_time=0.5)

        # 展示右侧内容
        self.play(FadeIn(right_header, shift=DOWN), FadeIn(img2, scale=0.9))
        self.play(Write(right_points), run_time=2)

        # 5. 强调框
        # 强调右侧的重要性
        highlight_rect = SurroundingRectangle(Group(right_header, img2, right_points), color=YELLOW, buff=0.2)
        self.play(Create(highlight_rect), run_time=1)
