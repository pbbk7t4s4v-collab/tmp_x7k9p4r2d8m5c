from manim import *

class LinkedListDeleteError(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("链表删除：错误示范与内存泄漏",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 绘制链表初始状态
        # 定义节点样式
        def create_node(label_text):
            box = Square(side_length=1.2, color=BLUE, fill_opacity=0.2, fill_color=BLUE)
            label = Text(label_text, font="AR PL UKai CN", font_size=24).move_to(box.get_center())
            return VGroup(box, label)

        node_curr = create_node("Current")
        node_del = create_node("Target")
        node_next = create_node("Next")

        # 排列节点
        node_group = VGroup(node_curr, node_del, node_next).arrange(RIGHT, buff=1.5)
        node_group.move_to(ORIGIN).shift(DOWN * 0.5)

        # 绘制初始指针
        arrow_1 = Arrow(start=node_curr.get_right(), end=node_del.get_left(), buff=0.1, color=WHITE)
        arrow_2 = Arrow(start=node_del.get_right(), end=node_next.get_left(), buff=0.1, color=WHITE)

        # 指针标签
        pointer_label = Text("next", font_size=16, font="AR PL UKai CN").next_to(arrow_1, UP, buff=0.05)

        # 组合初始链表
        list_group = VGroup(node_group, arrow_1, arrow_2, pointer_label)

        self.play(FadeIn(list_group))

        # 3. 展示错误代码
        code_bg = Rectangle(width=10, height=1, color=GRAY, fill_opacity=0.1)
        code_text = Text("错误写法: current->next = current->next->next",
                        font="Monospace", font_size=24, color=YELLOW)
        code_group = VGroup(code_bg, code_text).next_to(title_group, DOWN, buff=0.5)

        self.play(FadeIn(code_group, shift=DOWN))

        # 4. 执行错误操作动画
        # 创建新的直接连接指针
        new_arrow = Arrow(start=node_curr.get_right(), end=node_next.get_left(), buff=0.1, color=RED)
        # 为了避免穿过中间节点，让箭头稍微弯曲
        new_arrow = CurvedArrow(start_point=node_curr.get_right(), end_point=node_next.get_left(), angle=-TAU/4, color=RED)

        self.play(
            Transform(arrow_1, new_arrow),
            run_time=1.5
        )

        # 5. 分析后果：内存泄漏
        # 目标节点变灰，表示失去引用
        self.play(
            node_del.animate.set_color(GRAY),
            arrow_2.animate.set_color(GRAY),
            run_time=1.0
        )

        # 强调框
        surround_rect = SurroundingRectangle(node_del, color=RED, buff=0.1)
        leak_text = Text("悬挂节点：无法访问，无法释放！", font="AR PL UKai CN", font_size=24, color=RED)
        leak_text.next_to(node_del, UP, buff=0.3)

        result_text = Text("后果：导致内存泄漏 (Memory Leak)", font="AR PL UKai CN", font_size=28, color=RED)
        result_text.next_to(node_group, DOWN, buff=0.8)

        self.play(
            Create(surround_rect),
            Write(leak_text),
            run_time=1.0
        )

        self.play(Write(result_text))
