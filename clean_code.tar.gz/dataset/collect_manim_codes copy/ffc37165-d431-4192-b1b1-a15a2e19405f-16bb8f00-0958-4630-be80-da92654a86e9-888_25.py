from manim import *

class BFSIntroduction(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("广度优先遍历 (BFS)",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("25", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：图的分层结构可视化
        # 定义节点位置
        start_pos = LEFT * 4 + UP * 1.5
        layer1_pos_l = start_pos + DOWN * 1.5 + LEFT * 1.5
        layer1_pos_r = start_pos + DOWN * 1.5 + RIGHT * 1.5
        layer2_pos_1 = layer1_pos_l + DOWN * 1.5 + LEFT * 0.8
        layer2_pos_2 = layer1_pos_l + DOWN * 1.5 + RIGHT * 0.8
        layer2_pos_3 = layer1_pos_r + DOWN * 1.5 + RIGHT * 0.5

        # 创建节点样式函数
        def create_node(pos, label, color):
            circle = Circle(radius=0.35, color=color, fill_opacity=0.8, fill_color=BLACK)
            text = Text(label, font="AR PL UKai CN", font_size=20).move_to(circle)
            return VGroup(circle, text).move_to(pos)

        # 第0层
        node_start = create_node(start_pos, "起点", RED)
        label_l0 = Text("第0层", font="AR PL UKai CN", font_size=18, color=RED).next_to(node_start, RIGHT)

        # 第1层
        node_l1_a = create_node(layer1_pos_l, "A", BLUE)
        node_l1_b = create_node(layer1_pos_r, "B", BLUE)
        line_s_a = Line(node_start.get_bottom(), node_l1_a.get_top())
        line_s_b = Line(node_start.get_bottom(), node_l1_b.get_top())
        label_l1 = Text("第1层", font="AR PL UKai CN", font_size=18, color=BLUE).next_to(node_l1_b, RIGHT)

        # 第2层
        node_l2_1 = create_node(layer2_pos_1, "C", GREEN)
        node_l2_2 = create_node(layer2_pos_2, "D", GREEN)
        node_l2_3 = create_node(layer2_pos_3, "E", GREEN)
        line_a_1 = Line(node_l1_a.get_bottom(), node_l2_1.get_top())
        line_a_2 = Line(node_l1_a.get_bottom(), node_l2_2.get_top())
        line_b_3 = Line(node_l1_b.get_bottom(), node_l2_3.get_top())
        label_l2 = Text("第2层", font="AR PL UKai CN", font_size=18, color=GREEN).next_to(node_l2_3, RIGHT)

        graph_group = VGroup(
            node_start, label_l0,
            node_l1_a, node_l1_b, line_s_a, line_s_b, label_l1,
            node_l2_1, node_l2_2, node_l2_3, line_a_1, line_a_2, line_b_3, label_l2
        )

        # 3. 右侧：核心概念文本
        text_start_x = 0  # 屏幕中心偏右

        # 文本内容
        p1_title = Text("1. 核心思想：按层扩展", font="AR PL UKai CN", font_size=26, color=YELLOW)
        p1_desc = Text("类似树的层次遍历，由近及远", font="AR PL UKai CN", font_size=22, color=WHITE)

        p2_title = Text("2. 核心工具：队列 (Queue)", font="AR PL UKai CN", font_size=26, color=YELLOW)

        # 简单的队列图示
        queue_box = Rectangle(height=0.6, width=2.5, color=BLUE)
        queue_text = Text("先进先出 FIFO", font="AR PL UKai CN", font_size=20).move_to(queue_box)
        queue_group = VGroup(queue_box, queue_text)

        p3_title = Text("3. 典型用途", font="AR PL UKai CN", font_size=26, color=YELLOW)
        p3_desc = VGroup(
            Text("• 无权图最短路", font="AR PL UKai CN", font_size=22),
            Text("• 社交网络六度空间", font="AR PL UKai CN", font_size=22)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # 布局
        right_content = VGroup(
            p1_title, p1_desc,
            p2_title, queue_group,
            p3_title, p3_desc
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.35)

        right_content.to_edge(RIGHT, buff=1.0).shift(UP*0.5)

        # 4. 动画流程

        # 步骤1：显示第0层和核心思想
        self.play(
            FadeIn(node_start, scale=0.5),
            Write(label_l0),
            Write(p1_title),
            run_time=1
        )
        self.play(FadeIn(p1_desc), run_time=0.8)

        # 步骤2：扩展到第1层并显示队列工具
        self.play(
            Create(line_s_a), Create(line_s_b),
            FadeIn(node_l1_a, shift=DOWN), FadeIn(node_l1_b, shift=DOWN),
            Write(label_l1),
            Write(p2_title),
            run_time=1
        )

        # 强调队列
        queue_group.next_to(p2_title, DOWN, aligned_edge=LEFT)
        self.play(Create(queue_box), Write(queue_text), run_time=0.8)

        # 步骤3：扩展到第2层并显示用途
        self.play(
            Create(line_a_1), Create(line_a_2), Create(line_b_3),
            FadeIn(node_l2_1, shift=DOWN), FadeIn(node_l2_2, shift=DOWN), FadeIn(node_l2_3, shift=DOWN),
            Write(label_l2),
            Write(p3_title),
            run_time=1
        )

        self.play(Write(p3_desc), run_time=1)

        # 最后的强调框
        highlight_rect = SurroundingRectangle(right_content, color=BLUE, buff=0.2)
        self.play(Create(highlight_rect), run_time=0.5)
