from manim import *

class ConsistencyCheck(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("数据标注的一致性检验",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容部分：展示两个标注员的对比流程
        # ---------------------------------------------------------

        # 定义两个标注人员的节点
        # 使用 VGroup 组合文本和简单的背景框

        # 标注员 A
        text_a = Text("标注人员 A", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        label_a = Text("标注结果: [1, 0, 1]", font="AR PL UKai CN", font_size=20, color=WHITE).next_to(text_a, DOWN, buff=0.2)
        group_a = VGroup(text_a, label_a)
        box_a = SurroundingRectangle(group_a, color=BLUE, buff=0.2)
        full_group_a = VGroup(box_a, group_a).move_to(LEFT * 3.5 + UP * 0.5)

        # 标注员 B
        text_b = Text("标注人员 B", font="AR PL UKai CN", font_size=24, color=TEAL_A)
        label_b = Text("标注结果: [1, 0, 0]", font="AR PL UKai CN", font_size=20, color=WHITE).next_to(text_b, DOWN, buff=0.2)
        group_b = VGroup(text_b, label_b)
        box_b = SurroundingRectangle(group_b, color=TEAL, buff=0.2)
        full_group_b = VGroup(box_b, group_b).move_to(RIGHT * 3.5 + UP * 0.5)

        # 核心概念：对比与计算
        process_text = Text("对比标注结果", font="AR PL UKai CN", font_size=22, color=GREY_B)
        process_text.move_to(UP * 0.5)

        # 箭头连接
        arrow_a = Arrow(box_a.get_right(), process_text.get_left(), buff=0.1, color=BLUE)
        arrow_b = Arrow(box_b.get_left(), process_text.get_right(), buff=0.1, color=TEAL)

        # 结果指标：Kappa 系数
        # 使用 MathTex 展示公式符号，Text 展示中文说明
        kappa_box_pos = DOWN * 1.5
        kappa_title = Text("计算一致性指标", font="AR PL UKai CN", font_size=26, color=YELLOW).move_to(kappa_box_pos + UP * 0.5)

        kappa_formula = MathTex(r"\text{Kappa} = \frac{P_o - P_e}{1 - P_e}", font_size=36)
        kappa_formula.next_to(kappa_title, DOWN, buff=0.3)

        kappa_desc = Text("衡量多人标注的一致程度", font="AR PL UKai CN", font_size=20, color=GREY_C)
        kappa_desc.next_to(kappa_formula, DOWN, buff=0.3)

        result_group = VGroup(kappa_title, kappa_formula, kappa_desc)
        result_rect = SurroundingRectangle(result_group, color=YELLOW, buff=0.2)

        # 下拉箭头指向结果
        down_arrow = Arrow(process_text.get_bottom(), result_rect.get_top(), buff=0.1, color=WHITE)

        # ---------------------------------------------------------
        # 3. 动画序列
        # ---------------------------------------------------------

        # 1. 出现两个标注员及其结果
        self.play(
            FadeIn(full_group_a, shift=RIGHT),
            FadeIn(full_group_b, shift=LEFT),
            run_time=1.5
        )

        # 2. 出现中间的对比过程
        self.play(
            GrowArrow(arrow_a),
            GrowArrow(arrow_b),
            Write(process_text),
            run_time=1.0
        )

        # 3. 指向并生成最终指标
        self.play(
            GrowArrow(down_arrow),
            Create(result_rect),
            FadeIn(kappa_title, shift=UP),
        )

        # 4. 展示公式和解释
        self.play(
            Write(kappa_formula),
            FadeIn(kappa_desc),
            run_time=1.5
        )
