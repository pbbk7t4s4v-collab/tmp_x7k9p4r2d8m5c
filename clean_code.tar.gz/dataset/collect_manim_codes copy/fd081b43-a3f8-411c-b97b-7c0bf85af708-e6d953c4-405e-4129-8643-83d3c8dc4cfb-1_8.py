from manim import *

class FluidBoundaryLayer(Scene):
    def construct(self):

        # ===================== 标题设置 =====================
        title = Text("流体边界层与阻力产生机制",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ===================== 核心可视化:边界层示意图 =====================
        # 1. 平板
        plate_start = LEFT * 5 + DOWN * 1.5
        plate_end = LEFT * 1 + DOWN * 1.5
        plate = Line(plate_start, plate_end, color=GRAY, stroke_width=6)
        plate_label = Text("固体壁面", font="AR PL UKai CN", font_size=20, color=GRAY).next_to(plate, DOWN, buff=0.1)

        # 2. 边界层曲线 (近似抛物线增长)
        curve_points = [
            plate_start,
            plate_start + RIGHT * 2 + UP * 1.2,
            plate_end + UP * 2.0
        ]
        boundary_curve = VMobject(color=BLUE_B, stroke_width=4)
        boundary_curve.set_points_smoothly(curve_points)
        boundary_label = Text("边界层外缘", font="AR PL UKai CN", font_size=18, color=BLUE_B).move_to(plate_end + UP * 2.3)

        # 3. 速度剖面 (Velocity Profile)
        # 在平板中间位置绘制
        x_pos = plate_start + RIGHT * 2.5
        vectors = VGroup()
        num_arrows = 6
        max_height = 1.5 # 对应x处的边界层高度

        for i in range(num_arrows):
            y = (i / (num_arrows - 1)) * max_height
            # 简单的速度分布 u/U = (y/delta)^(1/2)
            if y == 0:
                u_len = 0
            else:
                u_len = (y / max_height) ** 0.5 * 1.5 # 缩放长度

            # 只有长度大于0才画箭头
            if u_len > 0.1:
                arrow = Arrow(
                    start=x_pos + UP * y,
                    end=x_pos + UP * y + RIGHT * u_len,
                    buff=0,
                    color=YELLOW,
                    stroke_width=3,
                    max_tip_length_to_length_ratio=0.4
                )
                vectors.add(arrow)

        # 连接箭头的包络线
        profile_line = VMobject(color=YELLOW, stroke_opacity=0.5)
        profile_points = [x_pos + UP * ((i / (num_arrows - 1)) * max_height) + RIGHT * (( (i / (num_arrows - 1)) * max_height / max_height ) ** 0.5 * 1.5) for i in range(num_arrows)]
        # 修正第一个点为原点
        profile_points[0] = x_pos
        profile_line.set_points_smoothly(profile_points)

        profile_group = VGroup(vectors, profile_line)
        u_label = MathTex("u(y)", font_size=24, color=YELLOW).next_to(profile_group, RIGHT, buff=0.1)

        # ===================== 右侧:概念与公式 =====================

        # 关键概念列表
        list_start = RIGHT * 0.5 + UP * 1.5

        # 概念1:粘性作用
        concept1 = Text("1. 粘性作用 (Viscosity)", font="AR PL UKai CN", font_size=26, color=WHITE)
        concept1_sub = Text("   流体在壁面处速度为0 (无滑移)", font="AR PL UKai CN", font_size=22, color=GRAY_B)

        # 概念2:摩擦阻力 (Skin Friction)
        concept2 = Text("2. 摩擦阻力 (Skin Friction)", font="AR PL UKai CN", font_size=26, color=WHITE)
        # 公式
        formula = MathTex(
            r"\tau_w = \mu \left( \frac{\partial u}{\partial y} \right)_{y=0}",
            font_size=32,
            color=RED_A
        )
        formula_box = SurroundingRectangle(formula, color=RED, buff=0.15, stroke_width=2)

        # 概念3:压差阻力
        concept3 = Text("3. 压差阻力 (Pressure Drag)", font="AR PL UKai CN", font_size=26, color=WHITE)
        concept3_sub = Text("   由边界层分离引起", font="AR PL UKai CN", font_size=22, color=GRAY_B)

        # 布局右侧内容
        right_content = VGroup(
            concept1,
            concept1_sub,
            concept2,
            VGroup(formula, formula_box), # 将公式和框组合
            concept3,
            concept3_sub
        ).arrange(DOWN, buff=0.35, aligned_edge=LEFT)

        right_content.move_to(RIGHT * 3.5) # 整体移到右侧

        # ===================== 动画播放顺序 =====================

        # 1. 画出物理模型
        self.play(Create(plate), Write(plate_label), run_time=1)

        # 2. 形成边界层和速度剖面
        self.play(
            Create(boundary_curve),
            FadeIn(boundary_label),
            run_time=1.5
        )
        self.play(
            AnimationGroup(*[GrowArrow(arrow) for arrow in vectors]),
            Create(profile_line),
            Write(u_label),
            run_time=1
        )

        # 3. 展示右侧文字概念
        self.play(
            FadeIn(concept1, shift=LEFT),
            FadeIn(concept1_sub, shift=LEFT),
            run_time=1
        )

        # 4. 展示摩擦阻力与公式
        self.play(
            FadeIn(concept2, shift=LEFT),
            Write(formula),
            Create(formula_box),
            run_time=1.5
        )

        # 5. 展示压差阻力
        self.play(
            FadeIn(concept3, shift=LEFT),
            FadeIn(concept3_sub, shift=LEFT),
            run_time=1
        )
