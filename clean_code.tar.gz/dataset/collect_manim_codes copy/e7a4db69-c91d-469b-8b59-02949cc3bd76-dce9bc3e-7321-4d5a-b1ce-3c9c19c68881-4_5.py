from manim import *

class TuningSystemMatching(Scene):
    def construct(self):

        # 1. 标题设置 (标准模板)
        title = Text("调谐系统：电容与线圈的耦合",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("57", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心公式展示
        # 谐振频率公式
        formula = MathTex(r"f = \frac{1}{2\pi\sqrt{LC}}", font_size=48, color=YELLOW)
        formula.next_to(title_line, DOWN, buff=0.6)

        # 公式标注
        label_l = Text("L: 磁棒线圈", font="AR PL UKai CN", font_size=24, color=BLUE).next_to(formula, LEFT, buff=1)
        label_c = Text("C: 可变电容", font="AR PL UKai CN", font_size=24, color=GREEN).next_to(formula, RIGHT, buff=1)

        self.play(Write(formula))
        self.play(FadeIn(label_l, shift=RIGHT), FadeIn(label_c, shift=LEFT))

        # 3. 内容分栏布局：左侧机制,右侧参数

        # 左侧：耦合机制
        mech_title = Text("耦合机制", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        mech_list = VGroup(
            Text("• 线圈(L)：感应天线信号", font="AR PL UKai CN", font_size=24),
            Text("• 电容(C)：改变频率选台", font="AR PL UKai CN", font_size=24),
            Text("• 共同决定接收范围", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.25)

        mech_group = VGroup(mech_title, mech_list).arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        mech_group.to_edge(LEFT, buff=1).shift(DOWN * 0.5)

        # 右侧：匹配参数 (使用框图强调)
        param_title = Text("匹配要求 (中波标准)", font="AR PL UKai CN", font_size=28, color=GOLD)

        # 使用 LaTeX 展示数值，更清晰
        param_items = VGroup(
            MathTex(r"L: 300 \sim 500 \mu H", font_size=28),
            MathTex(r"C: 10 \sim 270 pF", font_size=28),
            MathTex(r"Freq: 535 \sim 1605 kHz", font_size=28)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        param_group_inner = VGroup(param_title, param_items).arrange(DOWN, aligned_edge=ORIGIN, buff=0.3)

        # 添加外框
        param_box = SurroundingRectangle(param_group_inner, color=GOLD, buff=0.2)
        param_full = VGroup(param_box, param_group_inner)
        param_full.to_edge(RIGHT, buff=1).shift(DOWN * 0.5)

        # 4. 进场动画
        self.play(
            FadeIn(mech_group, shift=RIGHT),
            Create(param_box),
            Write(param_group_inner)
        )

        # 5. 强调关联 (简单的箭头指示)
        # 从左侧机制指向公式，从右侧参数指向公式，表示共同作用
        arrow_1 = Arrow(start=mech_group.get_top(), end=formula.get_bottom() + LEFT*0.5, color=BLUE_C, stroke_width=3)
        arrow_2 = Arrow(start=param_full.get_top(), end=formula.get_bottom() + RIGHT*0.5, color=GOLD_C, stroke_width=3)

        self.play(GrowArrow(arrow_1), GrowArrow(arrow_2))
