from manim import *

class AutoDrivingChipCompanies(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("自动驾驶芯片企业",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("26", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 三列布局
        # --- NVIDIA ---
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/f087c8e7-bdee-4e6a-9515-bef77bdb5bd3/pictures/4_4/1.png") # 这里期望是一张极具未来感的黑色芯片，芯片表面有绿色的霓虹光路流转，代表NVIDIA的Orin芯片，背景是深邃的科技蓝黑色，高科技写实风格
        img1.height = 2.0

        t1_head = Text("NVIDIA", font="AR PL UKai CN", font_size=24, color=GREEN)
        t1_sub = Text("算力之王", font="AR PL UKai CN", font_size=18, color=GRAY_B)
        t1_list = VGroup(
            Text("• Orin/Thor芯片", font="AR PL UKai CN", font_size=16),
            Text("• 极高TOPS算力", font="AR PL UKai CN", font_size=16),
            Text("• 完善CUDA生态", font="AR PL UKai CN", font_size=16),
            Text("• 高端首选", font="AR PL UKai CN", font_size=16)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        group1 = Group(img1, t1_head, t1_sub, t1_list).arrange(DOWN, buff=0.15)
        box1 = SurroundingRectangle(group1, color=GREEN, buff=0.15, stroke_width=2)

        # --- Mobileye ---
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/f087c8e7-bdee-4e6a-9515-bef77bdb5bd3/pictures/4_4/2.png") # 这里期望是一张带有Intel Mobileye标志的芯片，周围环绕着类似汽车摄像头视野的蓝色线框图，象征视觉感知与ADAS技术，科技风
        img2.height = 2.0

        t2_head = Text("Mobileye", font="AR PL UKai CN", font_size=24, color=BLUE)
        t2_sub = Text("视觉先驱", font="AR PL UKai CN", font_size=18, color=GRAY_B)
        t2_list = VGroup(
            Text("• 早期ADAS垄断", font="AR PL UKai CN", font_size=16),
            Text("• 软硬一体黑盒", font="AR PL UKai CN", font_size=16),
            Text("• 转型开放生态", font="AR PL UKai CN", font_size=16)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        group2 = Group(img2, t2_head, t2_sub, t2_list).arrange(DOWN, buff=0.15)
        box2 = SurroundingRectangle(group2, color=BLUE, buff=0.15, stroke_width=2)

        # --- 地平线 ---
        img3 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/f087c8e7-bdee-4e6a-9515-bef77bdb5bd3/pictures/4_4/3.png") # 这里期望是一张具有金属质感的方形芯片，代表地平线（Horizon Robotics），背景融合了抽象的城市道路网格和电路板纹理，体现国产化与开放生态，科技插画风格
        img3.height = 2.0

        t3_head = Text("地平线", font="AR PL UKai CN", font_size=24, color=ORANGE)
        t3_sub = Text("国产替代", font="AR PL UKai CN", font_size=18, color=GRAY_B)
        t3_list = VGroup(
            Text("• 高性价比BPU", font="AR PL UKai CN", font_size=16),
            Text("• 本土化服务好", font="AR PL UKai CN", font_size=16),
            Text("• 市场份额重要", font="AR PL UKai CN", font_size=16)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        group3 = Group(img3, t3_head, t3_sub, t3_list).arrange(DOWN, buff=0.15)
        box3 = SurroundingRectangle(group3, color=ORANGE, buff=0.15, stroke_width=2)

        # 3. 整体排列与对齐
        # 确保列表顶部对齐以保持美观
        # 先将三个组水平排列
        final_group = Group(group1, group2, group3).arrange(RIGHT, buff=0.8)

        # 调整位置到屏幕中央偏下
        final_group.move_to(DOWN * 0.5)

        # 调整边框位置
        box1.move_to(group1)
        box2.move_to(group2)
        box3.move_to(group3)

        # 4. 动画播放
        # 分组淡入，强调不同厂商的定位

        # NVIDIA
        self.play(FadeIn(img1, shift=UP), FadeIn(t1_head, shift=UP), run_time=0.8)
        self.play(Write(t1_sub), Create(box1), FadeIn(t1_list), run_time=0.8)

        # Mobileye
        self.play(FadeIn(img2, shift=UP), FadeIn(t2_head, shift=UP), run_time=0.8)
        self.play(Write(t2_sub), Create(box2), FadeIn(t2_list), run_time=0.8)

        # Horizon
        self.play(FadeIn(img3, shift=UP), FadeIn(t3_head, shift=UP), run_time=0.8)
        self.play(Write(t3_sub), Create(box3), FadeIn(t3_list), run_time=0.8)
