from manim import *

class WarmUpScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格遵守模板)
        # ---------------------------------------------------------
        title = Text("Warm-up：社团招新",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局与图片加载
        # ---------------------------------------------------------
        # 图片加载与注释 (严格按照Planner建议)
        img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/101035d0-c172-4b79-88f0-28d7399887d1/a3ae9e0b-ce34-437b-baa2-c120be51c066/pictures/2_1/1.png") # 这里期望是一张展示几个穿着校服的学生围在一张桌子旁，正在专注于组装一个小型的机械机器人的图片，要求画面桌上散落着各种零件、螺丝刀和图纸，背景是明亮的教室环境，清新活泼的校园插画风格

        # 调整图片大小和位置 (1:1比例，放置在左侧)
        img.height = 4.5
        img.width = 4.5
        img.to_edge(LEFT, buff=1.5)
        img.shift(DOWN * 0.3)

        # 右侧文本内容构建
        content_group = VGroup()

        # 引导性问题/指令
        instruction_text = Text("观察图片细节", font="AR PL UKai CN", font_size=28, color=BLUE_B)

        # 核心概念列表
        concept_list = VGroup()
        c1 = Text("• 课外活动 (Activities)", font="AR PL UKai CN", font_size=26)
        c2 = Text("• 兴趣爱好 (Hobbies)", font="AR PL UKai CN", font_size=26)
        c3 = Text("• 团队合作 (Teamwork)", font="AR PL UKai CN", font_size=26)

        concept_list.add(c1, c2, c3)
        concept_list.arrange(DOWN, aligned_edge=LEFT, buff=0.4)

        # 总结性目标
        goal_text = Text("激活背景知识", font="AR PL UKai CN", font_size=30, color=YELLOW)

        # 组合右侧内容
        content_group.add(instruction_text, concept_list, goal_text)
        content_group.arrange(DOWN, aligned_edge=LEFT, buff=0.6)
        content_group.next_to(img, RIGHT, buff=1.0)

        # ---------------------------------------------------------
        # 3. 动画演示流程
        # ---------------------------------------------------------

        # 步骤 1: 图片淡入
        self.play(FadeIn(img, shift=RIGHT), run_time=1.0)

        # 步骤 2: 显示引导文字
        self.play(Write(instruction_text), run_time=0.8)

        # 步骤 3: 逐条显示概念，配合简单的箭头指示
        arrow = Arrow(start=img.get_right(), end=concept_list.get_left(), color=WHITE, buff=0.2)
        self.play(GrowArrow(arrow), run_time=0.6)

        for item in concept_list:
            self.play(FadeIn(item, shift=UP * 0.2), run_time=0.4)

        # 步骤 4: 强调最终目标
        box = SurroundingRectangle(goal_text, color=ORANGE, buff=0.15)
        self.play(
            Write(goal_text),
            Create(box),
            run_time=1.0
        )

        # 停留片刻
