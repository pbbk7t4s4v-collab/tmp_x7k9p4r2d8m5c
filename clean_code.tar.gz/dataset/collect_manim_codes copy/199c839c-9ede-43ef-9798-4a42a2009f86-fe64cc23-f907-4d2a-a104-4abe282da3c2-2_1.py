from manim import *

class NeuralNetworkBasics(Scene):
    def construct(self):

        # --- 标题设置 (严格遵守模板) ---
        title = Text("神经网络的基础",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- 左侧:神经网络示意图 ---
        # 创建节点
        # 输入层 (3个节点)
        input_nodes = VGroup(*[Dot(radius=0.12, color=BLUE) for _ in range(3)]).arrange(DOWN, buff=0.8)
        # 隐藏层 (4个节点)
        hidden_nodes = VGroup(*[Dot(radius=0.12, color=GREEN) for _ in range(4)]).arrange(DOWN, buff=0.8)
        # 输出层 (2个节点 - 代表分类)
        output_nodes = VGroup(*[Dot(radius=0.12, color=RED) for _ in range(2)]).arrange(DOWN, buff=1.0)

        # 设置位置
        input_nodes.move_to(LEFT * 5 + DOWN * 0.5)
        hidden_nodes.move_to(LEFT * 3 + DOWN * 0.5)
        output_nodes.move_to(LEFT * 1 + DOWN * 0.5)

        # 创建连线
        edges = VGroup()
        for i in input_nodes:
            for h in hidden_nodes:
                line = Line(i.get_center(), h.get_center(), stroke_width=1, color=GRAY_C)
                edges.add(line)

        for h in hidden_nodes:
            for o in output_nodes:
                line = Line(h.get_center(), o.get_center(), stroke_width=1, color=GRAY_C)
                edges.add(line)

        # 标签
        input_label = Text("输入层", font="AR PL UKai CN", font_size=20).next_to(input_nodes, UP, buff=0.3)
        hidden_label = Text("隐藏层", font="AR PL UKai CN", font_size=20).next_to(hidden_nodes, UP, buff=0.3)
        output_label = Text("输出层", font="AR PL UKai CN", font_size=20).next_to(output_nodes, UP, buff=0.3)

        # 组合左侧图形
        diagram_group = VGroup(input_nodes, hidden_nodes, output_nodes, edges, input_label, hidden_label, output_label)

        # 播放左侧动画
        self.play(
            FadeIn(input_nodes), FadeIn(hidden_nodes), FadeIn(output_nodes),
            Write(input_label), Write(hidden_label), Write(output_label)
        )
        self.play(Create(edges), run_time=2)

        # --- 右侧:公式与应用 ---

        # 1. 核心公式部分
        formula_title = Text("核心数学模型", font="AR PL UKai CN", font_size=24, color=YELLOW)
        formula_title.move_to(RIGHT * 3.5 + UP * 1.5)

        # 使用 MathTex 展示公式
        formula = MathTex(r"y = \sigma(W \cdot x + b)", font_size=38)
        formula.next_to(formula_title, DOWN, buff=0.3)

        # 公式解释
        formula_desc = Text("权重W × 输入x + 偏置b", font="AR PL UKai CN", font_size=18, color=GRAY_B)
        formula_desc.next_to(formula, DOWN, buff=0.2)

        # 框选公式
        formula_box = SurroundingRectangle(VGroup(formula_title, formula, formula_desc), color=BLUE, buff=0.2)

        self.play(Write(formula_title))
        self.play(Write(formula), FadeIn(formula_desc))
        self.play(Create(formula_box))

        # 2. 应用部分
        app_title = Text("分类问题实例", font="AR PL UKai CN", font_size=24, color=YELLOW)
        app_title.align_to(formula_title, LEFT).shift(DOWN * 2.5) # 手动调整位置避免重叠

        # 使用 VGroup 手动创建列表,避免 BulletedList 问题
        item1 = Text("• 图像识别 (猫/狗分类)", font="AR PL UKai CN", font_size=20)
        item2 = Text("• 垃圾邮件过滤 (是/否)", font="AR PL UKai CN", font_size=20)
        item3 = Text("• 手写数字识别 (0-9)", font="AR PL UKai CN", font_size=20)

        app_list = VGroup(item1, item2, item3).arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        app_list.next_to(app_title, DOWN, buff=0.3)

        self.play(Write(app_title))
        self.play(
            FadeIn(app_list, shift=RIGHT * 0.5),
            run_time=1.5
        )
