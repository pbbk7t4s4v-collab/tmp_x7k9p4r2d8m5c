from manim import *
import numpy as np

class CLTEvolution(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (模板要求)
        # ---------------------------------------------------------
        title = Text("中心极限定理的分布演化",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("38", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 坐标系建立
        # ---------------------------------------------------------
        axes = Axes(
            x_range=[-4, 4, 1],
            y_range=[0, 0.5, 0.1],
            x_length=7,
            y_length=3.5,
            axis_config={"include_tip": True, "color": GREY},
            tips=False
        ).next_to(title_line, DOWN, buff=0.3)

        # 坐标轴标签
        labels = axes.get_axis_labels(x_label="x", y_label="P(x)")

        self.play(Create(axes), FadeIn(labels), run_time=1.0)

        # ---------------------------------------------------------
        # 3. 分布演化动画
        # ---------------------------------------------------------

        # 阶段一:原始分布 (n=1),使用均匀分布作为示例 (看起来像矩形)
        # 为了动画平滑,使用 sigmoid 近似矩形或直接绘制分段线条
        # 这里使用简单的 continuous function 模拟平顶分布
        def uniform_approx(x):
            return 0.3 * (1 / (1 + np.exp(10*(x-1.5)))) * (1 / (1 + np.exp(-10*(x+1.5))))

        graph_original = axes.plot(uniform_approx, color=YELLOW)

        text_original = Text("n=1: 原始分布 (非正态)",
                             font="AR PL UKai CN", font_size=24, color=YELLOW)
        text_original.next_to(axes, UP, buff=0).to_edge(RIGHT, buff=1.5)

        self.play(Create(graph_original), Write(text_original), run_time=1.0)

        # 阶段二:正态分布 (n -> inf)
        def normal_dist(x):
            sigma = 1.0
            mu = 0
            return (1.0 / (sigma * np.sqrt(2 * np.pi))) * np.exp(-0.5 * ((x - mu) / sigma) ** 2)

        graph_normal = axes.plot(normal_dist, color=BLUE)

        text_normal = Text("n→∞: 样本均值趋近正态分布",
                           font="AR PL UKai CN", font_size=24, color=BLUE)
        text_normal.move_to(text_original.get_center())

        # 执行变换动画
        self.play(
            Transform(graph_original, graph_normal),
            Transform(text_original, text_normal),
            run_time=1.5
        )

        # ---------------------------------------------------------
        # 4. 核心公式与结论
        # ---------------------------------------------------------

        # 数学公式
        formula = MathTex(r"\bar{X}_n \sim N\left(\mu, \frac{\sigma^2}{n}\right)", color=WHITE, font_size=36)
        formula.next_to(axes, DOWN, buff=0.4)

        # 强调框
        rect = SurroundingRectangle(formula, color=BLUE, buff=0.15)

        # 文字解释
        explanation = Text("无论总体分布如何,样本量足够大时,\n均值抽样分布近似服从正态分布。",
                          font="AR PL UKai CN", font_size=24, color=GREY_A, line_spacing=0.8)
        explanation.next_to(formula, DOWN, buff=0.3)

        self.play(
            Write(formula),
            Create(rect),
            FadeIn(explanation)
        )
