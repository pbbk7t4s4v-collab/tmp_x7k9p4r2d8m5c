from manim import *

class NSEquationMeaning(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("纳维–斯托克斯方程的物理意义",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念文本：牛顿第二定律
        concept_text = Text("本质：流体微团的牛顿第二定律 (F = ma)",
                           font="AR PL UKai CN",
                           font_size=26,
                           color=YELLOW)
        concept_text.next_to(title_line, DOWN, buff=0.5)
        self.play(FadeIn(concept_text))

        # 3. 展示 N-S 方程 (分块展示以方便着色和标注)
        # 左边：密度 * 加速度 (惯性力)
        # 右边：压力梯度 + 黏性力 + 外力
        # 使用 Text 代替 MathTex 以避免 LaTeX 编译错误
        tokens = [
            Text("ρ (∂u/∂t + u · ∇u)"),
            Text("="),
            Text("-∇p"),
            Text("+"),
            Text("μ ∇² u"),
            Text("+"),
            Text("f")
        ]
        ns_eq = VGroup(*tokens).arrange(RIGHT, buff=0.2).scale(1.1)

        ns_eq.move_to(ORIGIN).shift(DOWN * 0.2) # 稍微下移

        # 设置颜色区分物理意义
        ns_eq[0].set_color(BLUE_C)   # 惯性力
        ns_eq[2].set_color(RED_C)    # 压力
        ns_eq[4].set_color(GREEN_C)  # 黏性
        ns_eq[6].set_color(GOLD_C)   # 外力

        self.play(Write(ns_eq))

        # 4. 添加标注 (Braces and Text)

        # 惯性力项标注 (上方)
        brace_inertia = Brace(ns_eq[0], UP, buff=0.1)
        text_inertia = Text("惯性力项 (ma)", font="AR PL UKai CN").scale(0.6).set_color(BLUE_C)
        text_inertia.next_to(brace_inertia, UP, buff=0.1)

        # 压力项标注 (下方)
        brace_pressure = Brace(ns_eq[2], DOWN, buff=0.1)
        text_pressure = Text("压力梯度力", font="AR PL UKai CN").scale(0.5).set_color(RED_C)

        # 黏性项标注 (下方)
        brace_viscosity = Brace(ns_eq[4], DOWN, buff=0.1)
        text_viscosity = Text("黏性力 (扩散)", font="AR PL UKai CN").scale(0.5).set_color(GREEN_C)

        # 外力项标注 (下方)
        brace_force = Brace(ns_eq[6], DOWN, buff=0.1)
        text_force = Text("外力", font="AR PL UKai CN").scale(0.5).set_color(GOLD_C)

        # 调整下方文字位置，防止重叠
        # 将文字稍微错开或者确保足够小
        text_pressure.next_to(brace_pressure, DOWN, buff=0.1)
        text_viscosity.next_to(brace_viscosity, DOWN, buff=0.1)
        text_force.next_to(brace_force, DOWN, buff=0.1)

        # 动画展示标注
        self.play(
            FadeIn(brace_inertia), Write(text_inertia),
            run_time=1
        )
        self.play(
            FadeIn(brace_pressure), Write(text_pressure),
            FadeIn(brace_viscosity), Write(text_viscosity),
            FadeIn(brace_force), Write(text_force),
            run_time=1.5
        )

        # 5. 使用 SurroundingRectangle 强调整个方程
        rect = SurroundingRectangle(ns_eq, color=WHITE, buff=0.2, stroke_width=2)
        self.play(Create(rect))
