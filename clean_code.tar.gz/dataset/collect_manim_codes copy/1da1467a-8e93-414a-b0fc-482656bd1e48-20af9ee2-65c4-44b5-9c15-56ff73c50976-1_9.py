from manim import *

class TsFileCoreDemands(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板要求)
        title = Text("文件格式的系统层核心诉求",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心可视化内容构建
        # 中心核心概念
        center_text = Text("TsFile 核心目标", font="AR PL UKai CN", font_size=32, color=BLUE_A)
        center_box = SurroundingRectangle(center_text, color=BLUE, buff=0.3, fill_opacity=0.2, fill_color=BLUE_E)
        center_group = VGroup(center_box, center_text).move_to(ORIGIN)

        # 左侧：写入需求
        write_label = Text("高效写入", font="AR PL UKai CN", font_size=28, color=GREEN)
        write_detail = Text("高并发 / 物联网洪流", font="AR PL UKai CN", font_size=20, color=WHITE)
        write_group = VGroup(write_label, write_detail).arrange(DOWN, buff=0.15)
        write_group.next_to(center_group, LEFT, buff=2)

        write_arrow = Arrow(start=write_group.get_right(), end=center_group.get_left(), color=GREEN)

        # 右侧：读取需求
        read_label = Text("高效读取", font="AR PL UKai CN", font_size=28, color=RED)
        read_detail = Text("谓词下推 / 范围过滤", font="AR PL UKai CN", font_size=20, color=WHITE)
        read_group = VGroup(read_label, read_detail).arrange(DOWN, buff=0.15)
        read_group.next_to(center_group, RIGHT, buff=2)

        read_arrow = Arrow(start=center_group.get_right(), end=read_group.get_left(), color=RED)

        # 上方：访问模式
        mode_label = Text("多种访问模式支持", font="AR PL UKai CN", font_size=24, color=YELLOW)
        mode_detail = Text("顺序访问  随机访问  窗口访问", font="AR PL UKai CN", font_size=20, color=YELLOW_B)
        mode_group = VGroup(mode_label, mode_detail).arrange(DOWN, buff=0.15)
        mode_group.next_to(center_group, UP, buff=1.0)

        # 连接线（虚线表示属性关联）
        mode_line = DashedLine(center_group.get_top(), mode_group.get_bottom(), color=YELLOW)

        # 下方：演进特性
        evolve_label = Text("生态演进能力", font="AR PL UKai CN", font_size=24, color=PURPLE)
        evolve_detail = Text("可扩展 · 可维护 · 开源", font="AR PL UKai CN", font_size=20, color=PURPLE_B)
        evolve_group = VGroup(evolve_label, evolve_detail).arrange(DOWN, buff=0.15)
        evolve_group.next_to(center_group, DOWN, buff=1.0)

        evolve_line = DashedLine(center_group.get_bottom(), evolve_group.get_top(), color=PURPLE)

        # 3. 动画播放流程
        # 显示中心
        self.play(FadeIn(center_group, scale=0.8), run_time=1)

        # 显示读写流（左右两侧）
        self.play(
            FadeIn(write_group, shift=RIGHT),
            GrowArrow(write_arrow),
            FadeIn(read_group, shift=LEFT),
            GrowArrow(read_arrow),
            run_time=1.5
        )

        # 显示上下特性
        self.play(
            FadeIn(mode_group, shift=DOWN),
            Create(mode_line),
            FadeIn(evolve_group, shift=UP),
            Create(evolve_line),
            run_time=1.5
        )

        # 4. 总结强调框
        # 用一个大的边框把所有要素框起来，表示这是一个完整的系统要求
        full_system_group = VGroup(write_group, read_group, mode_group, evolve_group, center_group)
        system_rect = SurroundingRectangle(full_system_group, color=GRAY, buff=0.2, stroke_width=2)

        self.play(Create(system_rect), run_time=1.5)
