from manim import *

class ResistorAppearance(Scene):
    def construct(self):

        # 1. 标题设置 (标准模板)
        title = Text("普通电阻器外观特征与分类",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 顶部通用描述
        intro_text = Text("普通电阻器通常为圆柱形封装,两端引出金属引脚",
                         font="AR PL UKai CN", font_size=24, color=LIGHT_GREY)
        intro_text.next_to(title_line, DOWN, buff=0.5)
        self.play(Write(intro_text))

        # 3. 定义绘制电阻的辅助函数
        def create_resistor_visual(body_color, name, features, scale_val=1.0):
            # 电阻主体 (矩形模拟圆柱体)
            body = Rectangle(width=2.0, height=0.6,
                             fill_color=body_color, fill_opacity=1, stroke_color=WHITE, stroke_width=1)
            # 引脚
            lead_left = Line(LEFT, RIGHT, color=LIGHT_GREY, stroke_width=4).set_length(0.8)
            lead_right = Line(LEFT, RIGHT, color=LIGHT_GREY, stroke_width=4).set_length(0.8)
            lead_left.next_to(body, LEFT, buff=0)
            lead_right.next_to(body, RIGHT, buff=0)

            # 色环 (示意)
            bands = VGroup()
            band_colors = [BLACK, RED, GOLD] if name != "功率电阻" else [] # 功率电阻通常印字,这里简化不画色环
            for i, col in enumerate(band_colors):
                band = Line(UP, DOWN, color=col, stroke_width=5).set_length(0.6)
                # 简单的位置分布
                x_pos = body.get_left()[0] + 0.5 + i * 0.3
                band.move_to([x_pos, body.get_center()[1], 0])
                bands.add(band)

            resistor_icon = VGroup(lead_left, body, lead_right, bands).scale(scale_val)

            # 文字说明
            name_text = Text(name, font="AR PL UKai CN", font_size=24, color=YELLOW)
            feature_list = VGroup(*[
                Text(feat, font="AR PL UKai CN", font_size=18, color=WHITE)
                for feat in features
            ]).arrange(DOWN, buff=0.15)

            text_group = VGroup(name_text, feature_list).arrange(DOWN, buff=0.2)
            text_group.next_to(resistor_icon, DOWN, buff=0.3)

            # 组合整体
            full_obj = VGroup(resistor_icon, text_group)
            return full_obj

        # 4. 创建三种电阻的实例
        # 碳膜电阻:浅棕色/米黄色
        resistor_carbon = create_resistor_visual(
            body_color="#D2B48C",  # Tan color
            name="碳膜电阻",
            features=["表面浅棕/米黄色", "成本低廉", "应用最广"]
        )

        # 金属膜电阻:蓝色/绿色
        resistor_metal = create_resistor_visual(
            body_color="#5F9EA0",  # CadetBlue
            name="金属膜电阻",
            features=["表面蓝色/绿色", "精度更高", "温度系数小"]
        )

        # 功率电阻:体积大,通常白色或水泥色
        resistor_power = create_resistor_visual(
            body_color="#F5F5F5",  # WhiteSmoke
            name="功率电阻",
            features=["体积较大", "耐大电流", "散热性好"],
            scale_val=1.3 # 放大以体现体积大
        )

        # 5. 布局排列
        items_group = VGroup(resistor_carbon, resistor_metal, resistor_power)
        items_group.arrange(RIGHT, buff=0.5)
        items_group.next_to(intro_text, DOWN, buff=0.8)

        # 6. 动画展示
        # 分别展示三个分类
        self.play(FadeIn(resistor_carbon, shift=UP), run_time=1)
        self.play(FadeIn(resistor_metal, shift=UP), run_time=1)
        self.play(FadeIn(resistor_power, shift=UP), run_time=1)

        # 7. 添加强调框
        # 对中间的金属膜电阻(高精度)进行强调
        highlight_rect = SurroundingRectangle(resistor_metal, color=BLUE, buff=0.15)
        highlight_text = Text("高精度首选", font="AR PL UKai CN", font_size=16, color=BLUE)
        highlight_text.next_to(highlight_rect, UP)

        self.play(
            Create(highlight_rect),
            Write(highlight_text)
        )
