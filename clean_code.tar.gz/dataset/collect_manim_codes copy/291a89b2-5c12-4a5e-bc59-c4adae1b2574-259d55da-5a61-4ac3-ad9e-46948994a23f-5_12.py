from manim import *

class InterviewDataAnalysis(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("访谈资料分析：方法与视角",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("68", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 分析方法展示 (左上区域)
        method_label = Text("分析方法", font="AR PL UKai CN", font_size=28, color=BLUE)
        method_label.to_edge(LEFT, buff=1).shift(UP * 1.5)

        m1 = Text("主题编码", font="AR PL UKai CN", font_size=24)
        m2 = Text("叙事分析", font="AR PL UKai CN", font_size=24)

        methods_group = VGroup(m1, m2).arrange(DOWN, buff=0.4).next_to(method_label, DOWN, buff=0.5)

        # 为方法添加边框
        m_box = SurroundingRectangle(methods_group, color=BLUE_B, buff=0.2)

        self.play(
            FadeIn(method_label),
            Create(m_box),
            Write(methods_group)
        )

        # 3. 关注重点 (左下区域)
        focus_label = Text("关注重点", font="AR PL UKai CN", font_size=28, color=TEAL)
        focus_label.align_to(method_label, LEFT).shift(DOWN * 2.0)

        f1 = Text("共同模式", font="AR PL UKai CN", font_size=24, color=YELLOW)
        f2 = Text("个体叙事", font="AR PL UKai CN", font_size=24, color=YELLOW)

        focus_group = VGroup(f1, f2).arrange(DOWN, buff=0.4).next_to(focus_label, DOWN, buff=0.5)

        # 连接箭头：方法 -> 重点
        arrow_down = Arrow(m_box.get_bottom(), focus_label.get_top(), buff=0.2, color=GRAY)

        self.play(
            FadeIn(focus_label),
            GrowArrow(arrow_down),
            Write(focus_group)
        )

        # 4. 比较视角与权力结构 (右侧区域)
        # 构建三角形布局的角色
        role_center = RIGHT * 3 + DOWN * 0.5

        judge = Text("法官", font="AR PL UKai CN", font_size=26, color=RED)
        lawyer = Text("律师", font="AR PL UKai CN", font_size=26, color=GREEN)
        litigant = Text("当事人", font="AR PL UKai CN", font_size=26, color=WHITE)

        judge.move_to(role_center + UP * 1.2)
        lawyer.move_to(role_center + DOWN * 0.8 + LEFT * 1.5)
        litigant.move_to(role_center + DOWN * 0.8 + RIGHT * 1.5)

        roles = VGroup(judge, lawyer, litigant)

        # 连接角色的线条(表示比较)
        lines = VGroup(
            Line(judge.get_bottom(), lawyer.get_top(), color=GRAY, stroke_opacity=0.5),
            Line(judge.get_bottom(), litigant.get_top(), color=GRAY, stroke_opacity=0.5),
            Line(lawyer.get_right(), litigant.get_left(), color=GRAY, stroke_opacity=0.5)
        )

        comp_title = Text("比较不同社会位置", font="AR PL UKai CN", font_size=24, color=BLUE).next_to(judge, UP, buff=0.5)

        self.play(
            FadeIn(comp_title),
            FadeIn(roles),
            Create(lines, run_time=1.5)
        )

        # 5. 揭示权力结构 (最终结论)
        power_box = SurroundingRectangle(roles, color=ORANGE, buff=0.3)
        power_text = Text("揭示法律场域的权力结构", font="AR PL UKai CN", font_size=26, color=ORANGE, weight=BOLD)
        power_text.next_to(power_box, DOWN, buff=0.2)

        self.play(
            Create(power_box),
            Write(power_text)
        )
