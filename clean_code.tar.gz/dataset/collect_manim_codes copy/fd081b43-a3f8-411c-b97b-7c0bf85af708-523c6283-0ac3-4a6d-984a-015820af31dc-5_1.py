from manim import *
import numpy as np

class ContourAndGradient(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("多元函数的等高线与梯度方向",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局规划：左侧概念文本，右侧几何可视化

        # --- 左侧：概念定义 ---
        t1 = Text("1. 等高线 (Contour Line)", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        m1 = MathTex(r"\{(x,y) \mid f(x,y) = C\}", font_size=26, color=BLUE_B)

        t2 = Text("2. 梯度 (Gradient)", font="AR PL UKai CN", font_size=24, color=RED_A)
        m2 = MathTex(r"\nabla f = \left( \frac{\partial f}{\partial x}, \frac{\partial f}{\partial y} \right)", font_size=26, color=RED_B)

        t3 = Text("3. 核心性质", font="AR PL UKai CN", font_size=24, color=YELLOW_A)
        p1 = Text("• 梯度垂直于等高线切线", font="AR PL UKai CN", font_size=20)
        p2 = Text("• 指向函数增长最快的方向", font="AR PL UKai CN", font_size=20)

        # 组合并排版左侧文本
        left_group = VGroup(t1, m1, t2, m2, t3, p1, p2).arrange(DOWN, aligned_edge=LEFT, buff=0.25)
        left_group.to_edge(LEFT, buff=1).shift(DOWN * 0.3)

        # --- 右侧：几何可视化 ---
        # 坐标系
        axes = Axes(
            x_range=[-3, 3], y_range=[-3, 3],
            x_length=4.5, y_length=4.5,
            axis_config={"include_tip": True, "tip_shape": StealthTip}
        ).scale(0.9)
        axes.to_edge(RIGHT, buff=1).shift(DOWN * 0.3)
        axes_labels = axes.get_axis_labels(x_label="x", y_label="y")

        # 等高线 (同心圆模拟 f(x,y) = x^2 + y^2)
        contours = VGroup()
        for r in [0.8, 1.4, 2.0]:
            circle = Circle(radius=r, color=BLUE_C, stroke_opacity=0.7, stroke_width=2)
            circle.move_to(axes.c2p(0,0))
            contours.add(circle)

        contour_text = MathTex(r"f(x,y)=C", font_size=20, color=BLUE).next_to(contours[2], UR, buff=0.1)

        # 关键点 P (在半径为1.4的圆上，45度角)
        angle_deg = 45
        angle_rad = angle_deg * DEGREES
        r_val = 1.4

        # 计算P点位置
        p_coords = axes.c2p(r_val * np.cos(angle_rad), r_val * np.sin(angle_rad))
        dot_p = Dot(p_coords, color=WHITE, radius=0.08)
        label_p = MathTex("P", font_size=20).next_to(dot_p, DOWN, buff=0.1)

        # 切线 (垂直于半径)
        tangent_vec = np.array([-np.sin(angle_rad), np.cos(angle_rad), 0])
        tangent_start = p_coords - tangent_vec * 1.2
        tangent_end = p_coords + tangent_vec * 1.2
        tangent_line = Line(tangent_start, tangent_end, color=GREEN, stroke_width=2)
        tangent_label = Text("切线", font="AR PL UKai CN", font_size=16, color=GREEN).next_to(tangent_line, UL, buff=0.05)

        # 梯度向量 (垂直于切线，指向外侧)
        grad_vec = np.array([np.cos(angle_rad), np.sin(angle_rad), 0])
        arrow_grad = Arrow(
            start=p_coords,
            end=p_coords + grad_vec * 1.0,
            buff=0, color=RED, stroke_width=3, max_tip_length_to_length_ratio=0.3
        )
        label_grad = MathTex(r"\nabla f", font_size=24, color=RED).next_to(arrow_grad.get_end(), RIGHT, buff=0.1)

        # 直角标记
        right_angle = RightAngle(tangent_line, arrow_grad, length=0.2, quadrant=(-1, -1), color=YELLOW)

        # 强调框
        prop_rect = SurroundingRectangle(VGroup(p1, p2), color=YELLOW, buff=0.1)

        # 3. 动画序列
        # Step 1: 展示定义
        self.play(FadeIn(left_group[0:4], shift=RIGHT), run_time=1.5)

        # Step 2: 绘制坐标系与等高线
        self.play(Create(axes), Write(axes_labels), run_time=1.0)
        self.play(Create(contours), FadeIn(contour_text), run_time=1.5)

        # Step 3: 定位点与切线
        self.play(
            FadeIn(dot_p),
            Write(label_p),
            Create(tangent_line),
            FadeIn(tangent_label),
            run_time=1.2
        )

        # Step 4: 绘制梯度并展示直角关系
        self.play(GrowArrow(arrow_grad), Write(label_grad), run_time=1.0)
        self.play(Create(right_angle), run_time=0.5)

        # Step 5: 总结性质
        self.play(
            FadeIn(left_group[4:], shift=UP),
            Create(prop_rect),
            run_time=1.5
        )
