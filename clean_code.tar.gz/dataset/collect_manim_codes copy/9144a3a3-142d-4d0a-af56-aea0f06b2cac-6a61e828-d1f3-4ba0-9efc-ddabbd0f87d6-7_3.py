from manim import *

class ReceptiveFieldAnalysis(Scene):
    def construct(self):

        # --- 标题设置 ---
        title = Text("感受野分析：3层卷积网络",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("30", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- 布局规划 ---
        # 左侧：可视化金字塔 (1D 切面示意)
        # 右侧：计算步骤

        # 辅助函数：创建一行像素块
        def create_pixel_row(count, color, label_text):
            squares = VGroup(*[
                Square(side_length=0.5, fill_opacity=0.6, fill_color=color, color=WHITE, stroke_width=2)
                for _ in range(count)
            ]).arrange(RIGHT, buff=0)

            label = Text(label_text, font="AR PL UKai CN", font_size=20, color=WHITE)
            label.next_to(squares, LEFT, buff=0.3)
            return VGroup(label, squares), squares

        # 创建各层 (自顶向下展示)
        # 第3层 (输出)
        l3_row, l3_sq = create_pixel_row(1, RED, "第3层")
        # 第2层 (感受野 3)
        l2_row, l2_sq = create_pixel_row(3, BLUE, "第2层")
        # 第1层 (感受野 5)
        l1_row, l1_sq = create_pixel_row(5, GREEN, "第1层")
        # 输入层 (感受野 7)
        in_row, in_sq = create_pixel_row(7, GREY, "输入层")

        # 组合并排列成金字塔形状
        visual_group = VGroup(l3_row, l2_row, l1_row, in_row).arrange(DOWN, buff=0.6)
        visual_group.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # --- 右侧：计算逻辑 ---
        # 公式
        formula_text = Text("公式: ", font="AR PL UKai CN", font_size=24).set_color(YELLOW)
        formula_math = MathTex(r"RF_{in} = RF_{out} + (k - 1)", font_size=30)
        formula_group = VGroup(formula_text, formula_math).arrange(RIGHT)
        formula_group.to_edge(RIGHT, buff=1.5).shift(UP * 1.5)

        # 计算步骤
        # 初始
        step1 = MathTex(r"\text{Layer 3: } 1 \times 1", font_size=28)
        # 倒推 Layer 2
        step2 = MathTex(r"\text{Layer 2: } 1 + (3-1) = 3", font_size=28)
        # 倒推 Layer 1
        step3 = MathTex(r"\text{Layer 1: } 3 + (3-1) = 5", font_size=28)
        # 倒推 Input
        step4 = MathTex(r"\text{Input: } 5 + (3-1) = 7", font_size=28)

        steps_group = VGroup(step1, step2, step3, step4).arrange(DOWN, buff=0.5, aligned_edge=LEFT)
        steps_group.next_to(formula_group, DOWN, buff=0.8).align_to(formula_group, LEFT)

        # 结论
        result_text = Text("单个像素有效感受野: 7x7", font="AR PL UKai CN", font_size=32, color=ORANGE)
        result_text.next_to(steps_group, DOWN, buff=0.8)

        result_box = SurroundingRectangle(result_text, color=YELLOW, buff=0.2)

        # --- 动画执行 ---

        # 1. 显示公式
        self.play(FadeIn(formula_group))

        # 2. 逐步显示每一层的推导
        # L3
        self.play(FadeIn(l3_row), Write(step1), run_time=0.8)

        # L2
        # 添加连接线示意 (简单的梯形效果)
        lines_l3_l2 = VGroup(
            Line(l3_sq.get_corner(DL), l2_sq.get_corner(UL), color=WHITE, stroke_opacity=0.3),
            Line(l3_sq.get_corner(DR), l2_sq.get_corner(UR), color=WHITE, stroke_opacity=0.3)
        )
        self.play(FadeIn(l2_row), Create(lines_l3_l2), Write(step2), run_time=0.8)

        # L1
        lines_l2_l1 = VGroup(
            Line(l2_sq.get_corner(DL), l1_sq.get_corner(UL), color=WHITE, stroke_opacity=0.3),
            Line(l2_sq.get_corner(DR), l1_sq.get_corner(UR), color=WHITE, stroke_opacity=0.3)
        )
        self.play(FadeIn(l1_row), Create(lines_l2_l1), Write(step3), run_time=0.8)

        # Input
        lines_l1_in = VGroup(
            Line(l1_sq.get_corner(DL), in_sq.get_corner(UL), color=WHITE, stroke_opacity=0.3),
            Line(l1_sq.get_corner(DR), in_sq.get_corner(UR), color=WHITE, stroke_opacity=0.3)
        )
        self.play(FadeIn(in_row), Create(lines_l1_in), Write(step4), run_time=0.8)

        # 3. 强调结论
        self.play(Write(result_text), Create(result_box))
