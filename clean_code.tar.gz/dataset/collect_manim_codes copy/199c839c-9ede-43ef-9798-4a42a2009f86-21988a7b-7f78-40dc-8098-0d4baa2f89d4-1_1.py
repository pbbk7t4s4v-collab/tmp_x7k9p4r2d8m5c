from manim import *

class CourseIntro(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("神奇的AI画家：从想象到图像的魔法",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心视觉元素：AI画家图片
        # 严格按照Planner建议加载图片
        img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/199c839c-9ede-43ef-9798-4a42a2009f86/21988a7b-7f78-40dc-8098-0d4baa2f89d4/pictures/1_1/1.png") # 这里期望是一张展示一个充满未来感的AI机器人画家,手持画笔,正在画布上创作绚丽多彩的画作。画风梦幻,色彩鲜艳,背景带有魔法光效,体现"从想象到图像的魔法"的主题的图片,要求画面梦幻,写实风

        # 设置图片大小与位置（保持1:1比例，适中大小）
        img.height = 4.0
        img.next_to(title_group, DOWN, buff=0.3)

        # 图片入场动画
        self.play(FadeIn(img, scale=0.5), run_time=1.0)

        # 3. 课程核心概念展示
        # 使用简单的文本框展示课程核心逻辑：想象 -> 图像
        concept_font_size = 26

        label_left = Text("你的想象 (Prompt)", font="AR PL UKai CN", font_size=concept_font_size, color=BLUE_B)
        arrow = Arrow(LEFT, RIGHT, color=WHITE).scale(0.8)
        label_right = Text("视觉奇迹 (Image)", font="AR PL UKai CN", font_size=concept_font_size, color=YELLOW_B)

        # 组合底部概念说明
        bottom_group = VGroup(label_left, arrow, label_right).arrange(RIGHT, buff=0.5)
        bottom_group.next_to(img, DOWN, buff=0.4)

        # 为底部概念添加外框
        surround_rect = SurroundingRectangle(bottom_group, color=BLUE, buff=0.2, stroke_width=2)

        # 播放底部概念动画
        self.play(
            FadeIn(bottom_group, shift=UP),
            Create(surround_rect, run_time=1.0)
        )

        # 4. 装饰性粒子效果（模拟魔法感，使用简单的圆点）
        dots = VGroup(*[Dot(color=random_color(), radius=0.05) for _ in range(10)])
        for dot in dots:
            dot.move_to(img.get_center() + np.array([
                np.random.uniform(-2, 2),
                np.random.uniform(-2, 2),
                0
            ]))

        self.play(LaggedStart(*[FadeIn(dot, scale=0.5) for dot in dots], lag_ratio=0.1), run_time=1.0)
        self.play(FadeOut(dots), run_time=0.5)
