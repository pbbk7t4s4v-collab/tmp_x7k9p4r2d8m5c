from manim import *

class MultipoleExpansionScene(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("多极展开与粒子类型",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("18", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 辅助函数：创建电荷球
        def create_charge(sign, color, radius=0.3):
            circle = Circle(radius=radius, color=color, fill_opacity=0.5, stroke_width=2)
            symbol = MathTex(sign, color=WHITE).scale(0.8).move_to(circle.get_center())
            return VGroup(circle, symbol)

        # 2. 内容展示 - 分为四个象限展示四种类型

        # --- 单极 (Monopole) ---
        # 概念：净电荷
        mono_charge = create_charge("+", RED)
        mono_label = Text("单极 (Monopole)", font="AR PL UKai CN", font_size=20, color=YELLOW)
        mono_desc = Text("净电荷", font="AR PL UKai CN", font_size=18, color=WHITE)

        monopole_group = VGroup(mono_charge, mono_label, mono_desc).arrange(DOWN, buff=0.2)
        monopole_group.to_corner(UL, buff=1.5).shift(DOWN*0.5)

        # --- 偶极 (Dipole) ---
        # 概念：电荷分离 (+ -)
        d_pos = create_charge("+", RED, radius=0.25)
        d_neg = create_charge("-", BLUE, radius=0.25)
        d_group_charges = VGroup(d_pos, d_neg).arrange(RIGHT, buff=0.1)
        dipole_label = Text("偶极 (Dipole)", font="AR PL UKai CN", font_size=20, color=YELLOW)
        dipole_desc = Text("电荷分离", font="AR PL UKai CN", font_size=18, color=WHITE)

        dipole_group = VGroup(d_group_charges, dipole_label, dipole_desc).arrange(DOWN, buff=0.2)
        dipole_group.to_corner(UR, buff=1.5).shift(DOWN*0.5)

        # --- 四极 (Quadrupole) ---
        # 概念：非球形复杂分布 (+ - / - +)
        q_p1 = create_charge("+", RED, radius=0.2)
        q_n1 = create_charge("-", BLUE, radius=0.2)
        q_n2 = create_charge("-", BLUE, radius=0.2)
        q_p2 = create_charge("+", RED, radius=0.2)

        # 排列成 2x2 矩阵
        row1 = VGroup(q_p1, q_n1).arrange(RIGHT, buff=0.1)
        row2 = VGroup(q_n2, q_p2).arrange(RIGHT, buff=0.1)
        quad_charges = VGroup(row1, row2).arrange(DOWN, buff=0.1)

        quad_label = Text("四极 (Quadrupole)", font="AR PL UKai CN", font_size=20, color=YELLOW)
        quad_desc = Text("非球形分布", font="AR PL UKai CN", font_size=18, color=WHITE)

        quad_group = VGroup(quad_charges, quad_label, quad_desc).arrange(DOWN, buff=0.2)
        quad_group.to_corner(DL, buff=1.5).shift(UP*0.5)

        # --- 感应偶极 (Induced Dipole) ---
        # 概念：电子云变形
        nucleus = Dot(color=RED, radius=0.1)
        # 椭圆表示变形的电子云，中心稍微偏移
        electron_cloud = Ellipse(width=1.0, height=0.6, color=BLUE, fill_opacity=0.3, stroke_width=2)
        electron_cloud.move_to(nucleus.get_center() + RIGHT * 0.2) # 偏移表示极化

        ind_visual = VGroup(electron_cloud, nucleus)
        ind_label = Text("感应偶极 (Induced)", font="AR PL UKai CN", font_size=20, color=YELLOW)
        ind_desc = Text("电子云响应", font="AR PL UKai CN", font_size=18, color=WHITE)

        induced_group = VGroup(ind_visual, ind_label, ind_desc).arrange(DOWN, buff=0.2)
        induced_group.to_corner(DR, buff=1.5).shift(UP*0.5)

        # 3. 动画播放
        # 分组依次出现
        self.play(FadeIn(monopole_group, shift=UP), run_time=1)
        self.play(FadeIn(dipole_group, shift=UP), run_time=1)
        self.play(FadeIn(quad_group, shift=UP), run_time=1)
        self.play(FadeIn(induced_group, shift=UP), run_time=1)

        # 4. 强调框
        # 用一个框强调"多极展开"是一个系统性近似
        frame = SurroundingRectangle(VGroup(monopole_group, dipole_group, quad_group, induced_group), color=BLUE_B, buff=0.3)
        summary_text = Text("多极展开：远场近似体系", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        summary_text.next_to(frame, DOWN, buff=0.2)

        self.play(Create(frame), Write(summary_text))
