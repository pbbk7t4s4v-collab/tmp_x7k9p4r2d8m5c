from manim import *

class LiteraryFeatures(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("语言特点：文学性与趣味性",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("26", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 主要内容 - 体现形式
        # 使用 Text 而非 MathTex 以确保中文字体支持
        concept_text = Text("体现形式：引用古诗文、史料、故事", font="AR PL UKai CN", font_size=28)
        concept_box = SurroundingRectangle(concept_text, color=BLUE, buff=0.2)
        concept_group = VGroup(concept_box, concept_text)
        concept_group.next_to(title_line, DOWN, buff=0.8)

        self.play(FadeIn(concept_group, shift=DOWN))

        # 3. 举例 - 诗人展示
        # 创建诗人名单
        poet_intro = Text("如：", font="AR PL UKai CN", font_size=24, color=GREY_A)
        poet_1 = Text("陈辉", font="AR PL UKai CN", font_size=26, color=YELLOW)
        poet_2 = Text("苏轼", font="AR PL UKai CN", font_size=26, color=YELLOW)
        poet_3 = Text("杜牧", font="AR PL UKai CN", font_size=26, color=YELLOW)

        # 排列诗人
        poets = VGroup(poet_intro, poet_1, poet_2, poet_3).arrange(RIGHT, buff=0.6)
        poets.next_to(concept_group, DOWN, buff=0.8)

        # 连接线
        arrow_1 = Arrow(start=concept_group.get_bottom(), end=poets.get_top(), buff=0.1, color=GREY)

        self.play(GrowArrow(arrow_1))
        self.play(Write(poets))

        # 4. 作用/效果展示
        # 左侧效果
        effect_1_text = Text("增强文学色彩", font="AR PL UKai CN", font_size=26)
        effect_1_box = SurroundingRectangle(effect_1_text, color=GREEN, buff=0.15)
        effect_1_group = VGroup(effect_1_box, effect_1_text)

        # 右侧效果
        effect_2_text = Text("充实文章内容", font="AR PL UKai CN", font_size=26)
        effect_2_box = SurroundingRectangle(effect_2_text, color=GREEN, buff=0.15)
        effect_2_group = VGroup(effect_2_box, effect_2_text)

        # 组合效果组并定位
        effects_group = VGroup(effect_1_group, effect_2_group).arrange(RIGHT, buff=1.5)
        effects_group.next_to(poets, DOWN, buff=1.0)

        # 分叉连接线
        line_start = poets.get_bottom()
        line_left = Line(line_start, effect_1_group.get_top(), color=GREEN_B)
        line_right = Line(line_start, effect_2_group.get_top(), color=GREEN_B)

        self.play(
            Create(line_left),
            Create(line_right),
            FadeIn(effects_group, shift=UP)
        )

        # 5. 停留片刻
