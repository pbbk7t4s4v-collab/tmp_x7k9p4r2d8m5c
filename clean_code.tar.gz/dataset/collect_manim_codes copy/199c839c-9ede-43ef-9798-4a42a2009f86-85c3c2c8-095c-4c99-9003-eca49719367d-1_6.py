from manim import *

class UrbanVentilationCFDScene(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Case Study: Urban Ventilation Design",
                     font_size=34,
                     color=WHITE,
                     weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Left Side: Problem and Solution Concepts
        concepts_list = BulletedList(
            "Problem: Dense cities trap heat and pollution.",
            "Method: Use CFD (Computational Fluid Dynamics).",
            "Action: Simulate airflow around building layouts.",
            "Goal: Optimize design for better air quality.",
            font_size=28,
            buff=0.4
        ).to_edge(LEFT, buff=0.8).shift(DOWN * 0.5)

        self.play(FadeIn(concepts_list, lag_ratio=0.5, shift=UP))

        # 3. Right Side: Visual Comparison
        # Vertical divider line
        divider = DashedLine(
            start=title_group.get_bottom() + DOWN * 0.3,
            end=concepts_list.get_bottom() + DOWN * 0.3,
            color=GRAY
        ).next_to(concepts_list, RIGHT, buff=0.6)

        # Visualization "Before"
        before_label = Text("Before: Poor Ventilation", font_size=24, color=RED_C)
        buildings_before = VGroup(
            *[Rectangle(width=0.7, height=h, fill_color=DARK_GRAY, fill_opacity=1)
              for h in [1.8, 2.2, 1.5]]
        ).arrange(RIGHT, buff=0.2)

        airflow_before = VGroup(
            Arrow(start=LEFT, end=ORIGIN, color=BLUE_D, stroke_width=3, max_tip_length_to_length_ratio=0.2).next_to(buildings_before, LEFT, buff=0.1).shift(UP*0.3),
            Arrow(start=LEFT, end=ORIGIN, color=BLUE_D, stroke_width=3, max_tip_length_to_length_ratio=0.2).next_to(buildings_before, LEFT, buff=0.1).shift(DOWN*0.3)
        )

        before_group = VGroup(before_label, buildings_before, airflow_before).arrange(DOWN, buff=0.4)

        # Visualization "After"
        after_label = Text("After: Optimized Ventilation", font_size=24, color=GREEN_C)
        buildings_after = buildings_before.copy().arrange(RIGHT, buff=0.8)

        airflow_after = VGroup(
            Arrow(start=LEFT*2, end=RIGHT*2, color=BLUE_C, stroke_width=5, max_tip_length_to_length_ratio=0.15).move_to(buildings_after).shift(UP*0.3),
            Arrow(start=LEFT*2, end=RIGHT*2, color=BLUE_C, stroke_width=5, max_tip_length_to_length_ratio=0.15).move_to(buildings_after).shift(DOWN*0.3)
        )

        after_group = VGroup(after_label, buildings_after, airflow_after).arrange(DOWN, buff=0.4)

        # Position and animate the visual elements
        visual_comparison = VGroup(before_group, after_group).arrange(DOWN, buff=1.0).next_to(divider, RIGHT, buff=0.6)

        self.play(
            Create(divider),
            FadeIn(visual_comparison, shift=LEFT)
        )

        # 4. Highlight the optimized outcome
        highlight_box = SurroundingRectangle(after_group, color=YELLOW, buff=0.25, stroke_width=3)
        result_text = Text("Healthier City", font_size=28, color=YELLOW).next_to(highlight_box, DOWN, buff=0.2)

        self.play(Create(highlight_box))
        self.play(Write(result_text))
