from manim import *

class FileSystemHierarchy(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("文件系统的层级结构",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 构建树形结构可视化 (左侧)
        # 定义节点样式
        def create_node(label_text, color=BLUE):
            box = RoundedRectangle(corner_radius=0.2, height=0.6, width=1.0, color=color, fill_opacity=0.2)
            text = Text(label_text, font="AR PL UKai CN", font_size=20)
            return VGroup(box, text)

        # 根节点
        root = create_node("根目录", color=RED)
        root.move_to(UP * 1.5 + LEFT * 3)

        # 第一层子节点
        dir_a = create_node("目录A", color=BLUE)
        dir_b = create_node("目录B", color=BLUE)

        # 布局第一层
        dir_a.next_to(root, DOWN, buff=1.5).shift(LEFT * 1.5)
        dir_b.next_to(root, DOWN, buff=1.5).shift(RIGHT * 1.5)

        # 第二层子节点 (文件)
        file_1 = create_node("文件1", color=GREEN)
        file_2 = create_node("文件2", color=GREEN)

        # 布局第二层 (在目录A下)
        file_1.next_to(dir_a, DOWN, buff=1.0).shift(LEFT * 0.8)
        file_2.next_to(dir_a, DOWN, buff=1.0).shift(RIGHT * 0.8)

        # 连线
        line_root_a = Line(root.get_bottom(), dir_a.get_top(), buff=0.1)
        line_root_b = Line(root.get_bottom(), dir_b.get_top(), buff=0.1)
        line_a_f1 = Line(dir_a.get_bottom(), file_1.get_top(), buff=0.1)
        line_a_f2 = Line(dir_a.get_bottom(), file_2.get_top(), buff=0.1)

        tree_group = VGroup(root, dir_a, dir_b, file_1, file_2, line_root_a, line_root_b, line_a_f1, line_a_f2)

        # 3. 文本说明 (右侧)
        text_start_pos = UP * 1 + RIGHT * 1

        info_title = Text("层级关系特点:", font="AR PL UKai CN", font_size=28, color=YELLOW)
        info_title.move_to(text_start_pos, aligned_edge=LEFT)

        # 说明点 1
        bullet_1 = Text("• 一对多", font="AR PL UKai CN", font_size=24, color=WHITE)
        bullet_1.next_to(info_title, DOWN, buff=0.5, aligned_edge=LEFT)
        desc_1 = Text("目录包含多个子项", font="AR PL UKai CN", font_size=20, color=GRAY_B)
        desc_1.next_to(bullet_1, DOWN, buff=0.1, aligned_edge=LEFT).shift(RIGHT * 0.2)

        # 说明点 2
        bullet_2 = Text("• 多对一", font="AR PL UKai CN", font_size=24, color=WHITE)
        bullet_2.next_to(desc_1, DOWN, buff=0.5, aligned_edge=LEFT).shift(LEFT * 0.2)
        desc_2 = Text("子项属于唯一父目录", font="AR PL UKai CN", font_size=20, color=GRAY_B)
        desc_2.next_to(bullet_2, DOWN, buff=0.1, aligned_edge=LEFT).shift(RIGHT * 0.2)

        # 4. 动画展示流程

        # 展示树结构
        self.play(FadeIn(root), run_time=0.5)
        self.play(
            Create(line_root_a), Create(line_root_b),
            FadeIn(dir_a), FadeIn(dir_b),
            run_time=0.8
        )
        self.play(
            Create(line_a_f1), Create(line_a_f2),
            FadeIn(file_1), FadeIn(file_2),
            run_time=0.8
        )

        # 展示文字标题
        self.play(Write(info_title), run_time=0.5)

        # 强调"一对多"
        rect_one_to_many = SurroundingRectangle(VGroup(dir_a, file_1, file_2), color=YELLOW, buff=0.15)
        self.play(
            Write(bullet_1),
            Write(desc_1),
            Create(rect_one_to_many),
            run_time=1.0
        )

        # 强调"多对一" (淡出之前的框,建立新框)
        rect_many_to_one = SurroundingRectangle(VGroup(root, dir_b), color=ORANGE, buff=0.15)
        self.play(
            ReplacementTransform(rect_one_to_many, rect_many_to_one),
            Write(bullet_2),
            Write(desc_2),
            run_time=1.0
        )

        self.play(FadeOut(rect_many_to_one), run_time=0.5)
