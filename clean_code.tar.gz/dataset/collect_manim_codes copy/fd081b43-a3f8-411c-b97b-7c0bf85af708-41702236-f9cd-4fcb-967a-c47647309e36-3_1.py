from manim import *

class MarketEquilibriumInterpretation(Scene):
    def construct(self):

        # 1. Title Setup (Standard Template)
        title = Text("Market Equilibrium: Intersection Interpretation",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Graph Setup (Left Side)
        # Create Axes
        ax = Axes(
            x_range=[0, 6],
            y_range=[0, 6],
            x_length=5,
            y_length=5,
            axis_config={"include_tip": True, "color": GREY},
        ).to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        labels = ax.get_axis_labels(x_label="Quantity (Q)", y_label="Price (P)")

        # Curves
        # Demand: Downward sloping
        demand_line = Line(
            start=ax.coords_to_point(1, 5),
            end=ax.coords_to_point(5, 1),
            color=BLUE,
            stroke_width=4
        )
        d_label = MathTex("D").next_to(demand_line.get_end(), RIGHT, buff=0.1).set_color(BLUE)

        # Supply: Upward sloping
        supply_line = Line(
            start=ax.coords_to_point(1, 1),
            end=ax.coords_to_point(5, 5),
            color=RED,
            stroke_width=4
        )
        s_label = MathTex("S").next_to(supply_line.get_end(), RIGHT, buff=0.1).set_color(RED)

        # Intersection Point (3, 3)
        intersect_point = ax.coords_to_point(3, 3)
        dot = Dot(intersect_point, color=YELLOW, radius=0.12)

        # Dashed lines to axes
        h_line = DashedLine(intersect_point, ax.coords_to_point(0, 3), color=YELLOW)
        v_line = DashedLine(intersect_point, ax.coords_to_point(3, 0), color=YELLOW)

        p_star = MathTex("P^*", color=YELLOW).next_to(h_line, LEFT, buff=0.1)
        q_star = MathTex("Q^*", color=YELLOW).next_to(v_line, DOWN, buff=0.1)

        # 3. Explanatory Text (Right Side)
        explanation_group = VGroup()

        # Key Concept Equation
        eq_text = MathTex(r"Q_{demand} = Q_{supply}")
        eq_text.scale(1.2)

        # Surrounding Rectangle for emphasis
        rect = SurroundingRectangle(eq_text, color=YELLOW, buff=0.2)

        # Bullet points
        bullet_1 = Text("Market Clears", font_size=24, color=WHITE)
        bullet_2 = Text("No Surplus", font_size=24, color=GREEN_B)
        bullet_3 = Text("No Shortage", font_size=24, color=GREEN_B)

        text_block = VGroup(eq_text, rect, bullet_1, bullet_2, bullet_3)
        text_block.arrange(DOWN, center=False, aligned_edge=LEFT, buff=0.4)
        text_block.next_to(ax, RIGHT, buff=1.5).align_to(ax, UP).shift(DOWN * 0.5)

        # 4. Animation Sequence
        # Draw Graph
        self.play(Create(ax), Write(labels), run_time=1.5)
        self.play(
            Create(demand_line), Write(d_label),
            Create(supply_line), Write(s_label),
            run_time=1.5
        )

        # Show Intersection
        self.play(FadeIn(dot, scale=0.5))
        self.play(
            Create(h_line), Write(p_star),
            Create(v_line), Write(q_star),
            run_time=1.0
        )

        # Show Explanation
        self.play(Write(eq_text))
        self.play(Create(rect))

        # Reveal bullets sequentially
        self.play(
            FadeIn(bullet_1, shift=RIGHT),
            FadeIn(bullet_2, shift=RIGHT),
            FadeIn(bullet_3, shift=RIGHT),
            run_time=1.5
        )
