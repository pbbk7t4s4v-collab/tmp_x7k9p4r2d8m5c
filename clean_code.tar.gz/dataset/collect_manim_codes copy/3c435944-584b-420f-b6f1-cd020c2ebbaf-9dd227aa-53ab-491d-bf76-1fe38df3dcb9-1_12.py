from manim import *

class ConvexCombinationTheorem(Scene):
    def construct(self):

        # 1. Title Setup (Standard Template)
        title = Text("Convex Combinations Theorem",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Theorem Statement
        theorem_text = Text(
            "Theorem: A set C is convex iff it contains\nall convex combinations of its points.",
            font_size=26,
            line_spacing=0.8,
            t2c={"convex": YELLOW, "iff": ORANGE}
        )
        theorem_text.next_to(title_line, DOWN, buff=0.4)

        # 3. Mathematical Formulation
        # Displaying the convex combination formula
        formula = MathTex(
            r"x = \sum_{i=1}^k \theta_i x_i \in C",
            r", \quad \sum_{i=1}^k \theta_i = 1",
            r", \quad \theta_i \geq 0",
            font_size=30
        )
        formula.next_to(theorem_text, DOWN, buff=0.3)

        # Group text elements
        text_group = VGroup(theorem_text, formula)

        # 4. Visual Representation (Geometric Interpretation)
        # Create an arbitrary convex set (ellipse)
        convex_set = Ellipse(width=5, height=3, color=BLUE_C, fill_opacity=0.2, stroke_width=2)
        convex_set.move_to(DOWN * 1.5)
        set_label = MathTex("C", color=BLUE_C, font_size=30).next_to(convex_set, RIGHT)

        # Define points inside
        p1 = convex_set.c2p(-1.5, -0.5, 0)
        p2 = convex_set.c2p(1.5, -0.2, 0)
        p3 = convex_set.c2p(0, 1.0, 0)

        points = VGroup(
            Dot(p1, color=WHITE),
            Dot(p2, color=WHITE),
            Dot(p3, color=WHITE)
        )

        point_labels = VGroup(
            MathTex("x_1", font_size=20).next_to(p1, DL, buff=0.1),
            MathTex("x_2", font_size=20).next_to(p2, DR, buff=0.1),
            MathTex("x_3", font_size=20).next_to(p3, UP, buff=0.1)
        )

        # Convex Hull of these points (representing all convex combinations)
        hull = Polygon(p1, p2, p3, color=YELLOW, fill_opacity=0.4, stroke_width=2)
        hull_label = Text("Convex Combinations", font_size=18, color=YELLOW).move_to(hull.get_center())

        # 5. Proof Note (Induction & Non-negative constraint)
        proof_note = Text(
            "Proof Note: Uses induction. Key constraint: coefficients non-negative.",
            font_size=20,
            color=GRAY_A,
            slant=ITALIC
        )
        proof_note.to_edge(BOTTOM, buff=0.2)

        # 6. Animations Sequence
        self.play(Write(theorem_text))
        self.play(FadeIn(formula, shift=UP))

        # Show the set
        self.play(Create(convex_set), Write(set_label))

        # Show points
        self.play(
            FadeIn(points),
            Write(point_labels)
        )

        # Show the convex combinations (the hull)
        self.play(
            DrawBorderThenFill(hull),
            FadeIn(hull_label)
        )

        # Highlight the non-negative condition which is key for proof
        highlight_rect = SurroundingRectangle(formula[2], color=RED, buff=0.1)
        self.play(
            Create(highlight_rect),
            FadeIn(proof_note)
        )
