from manim import *

class GraphicsAndAnimationDef(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("图形与动画的定义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("22", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 分左右两部分
        # 左侧：图形 (Graphics)

        # 左侧标题
        gfx_title = Text("图形 (Graphics)", font="AR PL UKai CN", font_size=28, color=BLUE)

        # 左侧可视化：几何形状
        triangle = Triangle(color=BLUE, fill_opacity=0.5).scale(0.8)
        square = Square(color=TEAL, fill_opacity=0.5).scale(0.8)
        # 数学公式示意
        math_tex = MathTex(r"y = mx + b", font_size=24, color=WHITE)

        # 组合形状
        gfx_shapes = VGroup(triangle, square, math_tex).arrange(RIGHT, buff=0.3)

        # 左侧描述文本
        gfx_desc_1 = Text("由数学/几何模型描述", font="AR PL UKai CN", font_size=20)
        gfx_desc_2 = Text("矢量形式：无损缩放", font="AR PL UKai CN", font_size=20, color=YELLOW)

        # 组合左侧所有元素
        left_group = VGroup(gfx_title, gfx_shapes, gfx_desc_1, gfx_desc_2).arrange(DOWN, buff=0.4)
        left_group.to_edge(LEFT, buff=1.5).shift(DOWN*0.5)

        # 右侧：动画 (Animation)

        # 右侧标题
        anim_title = Text("动画 (Animation)", font="AR PL UKai CN", font_size=28, color=GREEN)

        # 右侧可视化：帧序列示意
        frame1 = Rectangle(height=0.8, width=1.0, color=WHITE)
        frame2 = Rectangle(height=0.8, width=1.0, color=WHITE)
        frame3 = Rectangle(height=0.8, width=1.0, color=WHITE)
        frames = VGroup(frame1, frame2, frame3).arrange(RIGHT, buff=0.2)

        # 这里的箭头表示时间轴
        time_arrow = Arrow(start=LEFT, end=RIGHT, color=GRAY).scale(0.8).next_to(frames, DOWN, buff=0.2)
        time_label = Text("时间轴", font="AR PL UKai CN", font_size=16).next_to(time_arrow, DOWN, buff=0.1)

        # 右侧描述文本
        anim_desc_1 = Text("图形按时间连续播放", font="AR PL UKai CN", font_size=20)
        anim_desc_2 = Text("关键帧 / 程序控制", font="AR PL UKai CN", font_size=20, color=YELLOW)

        # 组合右侧所有元素
        right_group = VGroup(anim_title, frames, VGroup(time_arrow, time_label), anim_desc_1, anim_desc_2).arrange(DOWN, buff=0.3)
        right_group.to_edge(RIGHT, buff=1.5).shift(DOWN*0.5)

        # 对齐调整
        right_group.align_to(left_group, UP)

        # 3. 动画展示流程

        # 展示左侧：图形定义
        self.play(FadeIn(left_group, shift=RIGHT))

        # 强调左侧：无损缩放演示 (放大再缩小)
        self.play(
            gfx_shapes.animate.scale(1.2),
            Indicate(gfx_desc_2, color=YELLOW),
            run_time=1.5
        )
        self.play(gfx_shapes.animate.scale(1/1.2), run_time=0.5)

        # 框选左侧
        rect_left = SurroundingRectangle(left_group, color=BLUE, buff=0.2)
        self.play(Create(rect_left))

        # 展示右侧：动画定义
        self.play(FadeIn(right_group, shift=LEFT))

        # 强调右侧：动态演示 (一个小球穿过帧)
        moving_dot = Dot(color=RED).move_to(frame1.get_center())
        self.add(moving_dot)

        self.play(
            moving_dot.animate.move_to(frame3.get_center()),
            Indicate(anim_desc_1, color=YELLOW),
            run_time=2,
            rate_func=linear
        )

        # 框选右侧
        rect_right = SurroundingRectangle(right_group, color=GREEN, buff=0.2)
        self.play(Create(rect_right))

        # 4. 停留片刻
