from manim import *

class MoltenSaltThermalProperties(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("熔盐的热物性与流动",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 分左右两部分
        # 左侧：高温低压
        left_anchor = Point().shift(LEFT * 3.5 + UP * 1.0)

        header_left = Text("高温低压运行", font="AR PL UKai CN", font_size=28, color=YELLOW)
        header_left.move_to(left_anchor)

        # 左侧文本点
        l_text1 = Text("熔盐沸点 > 1400°C", font="AR PL UKai CN", font_size=22)
        l_text2 = Text("工作温度约 700°C", font="AR PL UKai CN", font_size=22)
        l_text3 = Text("无需高压容器", font="AR PL UKai CN", font_size=22, color=RED_B)

        l_group = VGroup(l_text1, l_text2, l_text3).arrange(DOWN, buff=0.15, aligned_edge=LEFT)
        l_group.next_to(header_left, DOWN, buff=0.3)

        # 左侧可视化：压力对比柱状图
        # 压水堆柱子
        bar_pwr = Rectangle(width=0.6, height=2.0, color=BLUE_C, fill_opacity=0.6)
        label_pwr = Text("压水堆", font="AR PL UKai CN", font_size=16).next_to(bar_pwr, DOWN, buff=0.1)

        # 熔盐堆柱子
        bar_msr = Rectangle(width=0.6, height=0.1, color=ORANGE, fill_opacity=0.6) # 极低的高度代表低压
        bar_msr.align_to(bar_pwr, DOWN) # 底部对齐
        label_msr = Text("熔盐堆", font="AR PL UKai CN", font_size=16).next_to(bar_msr, DOWN, buff=0.1)

        chart_group = VGroup(bar_pwr, label_pwr, bar_msr, label_msr)
        # 手动排列防止Group嵌套问题
        bar_pwr.move_to(LEFT * 4.5 + DOWN * 1.5)
        label_pwr.next_to(bar_pwr, DOWN, buff=0.1)
        bar_msr.next_to(bar_pwr, RIGHT, buff=1.0, aligned_edge=DOWN)
        label_msr.next_to(bar_msr, DOWN, buff=0.1)

        chart_label = Text("运行压力对比", font="AR PL UKai CN", font_size=18, color=GRAY)
        chart_label.next_to(VGroup(bar_pwr, bar_msr), UP, buff=0.2)

        full_left_visual = VGroup(bar_pwr, label_pwr, bar_msr, label_msr, chart_label)

        # 左侧外框
        rect_left = SurroundingRectangle(VGroup(header_left, l_group, full_left_visual), color=YELLOW, buff=0.2)

        # 右侧：优异传热
        right_anchor = Point().shift(RIGHT * 3.5 + UP * 1.0)

        header_right = Text("优异传热工质", font="AR PL UKai CN", font_size=28, color=BLUE)
        header_right.move_to(right_anchor)

        # 右侧文本点
        r_text1 = Text("大体积热容", font="AR PL UKai CN", font_size=22)
        r_text2 = Text("高导热系数", font="AR PL UKai CN", font_size=22)

        r_group = VGroup(r_text1, r_text2).arrange(DOWN, buff=0.15, aligned_edge=LEFT)
        r_group.next_to(header_right, DOWN, buff=0.3)

        # 右侧可视化：热流示意
        # 管道
        pipe_outline = Rectangle(width=3.5, height=1.2, color=WHITE, fill_opacity=0.0)
        pipe_outline.move_to(RIGHT * 3.5 + DOWN * 1.2)

        # 流体块（表示高密度热量）
        heat_chunk = Rectangle(width=0.8, height=0.8, color=RED, fill_opacity=0.4)
        heat_chunk.move_to(pipe_outline.get_left() + RIGHT * 0.6)

        # 箭头
        flow_arrow = Arrow(start=LEFT, end=RIGHT, color=RED).next_to(heat_chunk, RIGHT)

        # 说明文字
        flow_desc = Text("低流速带走高热量", font="AR PL UKai CN", font_size=18, color=RED_A)
        flow_desc.next_to(pipe_outline, DOWN, buff=0.1)

        full_right_visual = VGroup(pipe_outline, heat_chunk, flow_arrow, flow_desc)

        # 右侧外框
        rect_right = SurroundingRectangle(VGroup(header_right, r_group, full_right_visual), color=BLUE, buff=0.2)

        # 3. 动画序列

        # 展示左侧
        self.play(FadeIn(header_left), Create(rect_left))
        self.play(Write(l_group), run_time=1.5)
        self.play(
            FadeIn(chart_label),
            GrowFromEdge(bar_pwr, DOWN),
            GrowFromEdge(bar_msr, DOWN),
            FadeIn(label_pwr),
            FadeIn(label_msr),
            run_time=2
        )

        # 展示右侧
        self.play(FadeIn(header_right), Create(rect_right))
        self.play(Write(r_group), run_time=1.5)
        self.play(
            Create(pipe_outline),
            FadeIn(heat_chunk),
            GrowArrow(flow_arrow),
            Write(flow_desc),
            run_time=2
        )

        # 简单的循环移动动画暗示流动
        self.play(
            heat_chunk.animate.shift(RIGHT * 1.5),
            flow_arrow.animate.shift(RIGHT * 1.5),
            run_time=1.5,
            rate_func=smooth
        )
