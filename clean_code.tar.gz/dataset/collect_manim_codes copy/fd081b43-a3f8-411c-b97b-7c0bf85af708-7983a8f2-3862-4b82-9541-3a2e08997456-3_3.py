from manim import *

class RibosomeAssembly(Scene):
    def construct(self):

        # ---- Title Setup (Standard Template) ----
        title = Text("4.2 Ribosomes as Molecular Assembly Machines",
                    font_size=34,  # Increased font size
                    color=WHITE,   # White text for contrast
                    weight=BOLD)   # Bold
        title.to_edge(UP, buff=0.5)  # Position at top

        # Add bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Group title elements
        title_group = VGroup(title, title_line)

        # Title Animation
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---- Visual Elements: The Ribosome Model ----
        # Using simple geometry to represent the molecular machine

        # 1. Small Subunit (Oval shape at the bottom)
        small_subunit = Ellipse(width=2.8, height=1.4, color=BLUE_C, fill_opacity=0.6)
        small_subunit.set_stroke(color=BLUE_A, width=3)

        # 2. Large Subunit (Larger oval shape on top)
        large_subunit = Ellipse(width=3.8, height=2.2, color=PURPLE_C, fill_opacity=0.6)
        large_subunit.set_stroke(color=PURPLE_A, width=3)

        # 3. mRNA Strand (Line passing through)
        mrna_strand = Line(start=LEFT*2.5, end=RIGHT*2.5, color=RED, stroke_width=6)

        # Labels
        lbl_small = Text("Small Subunit", font_size=20, color=BLUE_B)
        lbl_large = Text("Large Subunit", font_size=20, color=PURPLE_B)
        lbl_mrna = Text("mRNA", font_size=20, color=RED)

        # Positioning Logic
        # Place diagram on the LEFT side of the screen
        diagram_center = LEFT * 3.5 + DOWN * 0.5

        small_subunit.move_to(diagram_center + DOWN * 0.5)
        lbl_small.next_to(small_subunit, DOWN, buff=0.1)

        mrna_strand.move_to(small_subunit.get_top() + UP * 0.1)
        lbl_mrna.next_to(mrna_strand, LEFT, buff=0.2)

        large_subunit.next_to(mrna_strand, UP, buff=0.05)
        lbl_large.next_to(large_subunit, UP, buff=0.1)

        diagram_group = VGroup(small_subunit, large_subunit, mrna_strand, lbl_small, lbl_large, lbl_mrna)

        # ---- Text Content: Key Concepts ----
        # Place text on the RIGHT side
        bullet_points = VGroup(
            Text("• Complex of rRNA and proteins", font_size=26),
            Text("• The 'Workbench' for translation", font_size=26),
            Text("• Two subunits assemble on mRNA:", font_size=26),
            Text("   - Small: Decodes genetic message", font_size=24, color=BLUE_B),
            Text("   - Large: Catalyzes peptide bonds", font_size=24, color=PURPLE_B),
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.4)

        bullet_points.to_edge(RIGHT, buff=1.0)
        bullet_points.shift(UP * 0.5)

        # ---- Animation Sequence ----

        # 1. Introduce Small Subunit
        self.play(
            FadeIn(small_subunit, shift=UP),
            Write(lbl_small),
            run_time=1.0
        )

        # 2. mRNA Binding (The template arrives)
        self.play(
            Create(mrna_strand),
            Write(lbl_mrna),
            run_time=1.0
        )

        # 3. Large Subunit Assembly (Completing the machine)
        self.play(
            FadeIn(large_subunit, shift=DOWN),
            Write(lbl_large),
            run_time=1.0
        )

        # 4. Display Bullet Points
        self.play(
            LaggedStart(
                *[FadeIn(line, shift=LEFT) for line in bullet_points],
                lag_ratio=0.3
            ),
            run_time=2.5
        )

        # 5. Highlight the Functional Assembly
        # Using SurroundingRectangle to emphasize the active complex
        highlight_rect = SurroundingRectangle(diagram_group, color=YELLOW, buff=0.2)
        self.play(Create(highlight_rect), run_time=1.0)
