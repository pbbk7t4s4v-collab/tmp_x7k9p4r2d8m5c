from manim import *
import numpy as np

def Curve(*points, color=WHITE, stroke_width=3):
    """Create a smooth VMobject through the given points.

    Usage: Curve([x1,y1,z1], [x2,y2,z2], ...)
    Returns a VMobject with points set smoothly and stroke applied.
    """
    c = VMobject()
    c.set_points_smoothly([np.array(p) for p in points])
    c.set_color(color)
    c.set_stroke(width=stroke_width)
    return c

class Page17(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("非诗意生活中的诗意栖居",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # 讲稿片段1：引入
        # "通过苏轼的例子我们可以看到，在非诗意的生活中追寻诗意栖居，其实有迹可循。"
        intro_text = Text("追寻诗意栖居：有迹可循", font="AR PL UKai CN", font_size=28, color=YELLOW)
        intro_text.move_to(UP * 2)
        self.play(FadeIn(intro_text))

        # 讲稿片段2：凝视日常
        # "首先是凝视日常，像苏轼那样，即便身处贬谪的困境，依然能从寻常的月色、江水、山石中发现美与哲理，将平凡的事物转化为心灵的慰藉。"

        # 1. 凝视日常
        icon_1 = Circle(radius=0.7, color=BLUE, fill_opacity=0.2)
        # 简单的眼睛示意
        eye_inner = Circle(radius=0.3, color=WHITE, fill_opacity=1).move_to(icon_1)
        eye_pupil = Circle(radius=0.1, color=BLACK, fill_opacity=1).move_to(icon_1)

        label_1 = Text("凝视日常", font="AR PL UKai CN", font_size=24).next_to(icon_1, DOWN)
        desc_1 = Text("发现美与哲理", font="AR PL UKai CN", font_size=16, color=GRAY_B).next_to(label_1, DOWN)
        group_1 = VGroup(icon_1, eye_inner, eye_pupil, label_1, desc_1)

        # 讲稿片段3：沟通历史
        # "其次是沟通历史，苏轼在石钟山不迷信古人的记载，而是亲自考察验证，这种与历史对话、求真务实的态度，让他在时空的交汇中获得了更深层的智慧。"

        # 2. 沟通历史
        icon_2 = Square(side_length=1.4, color=GREEN, fill_opacity=0.2)
        # 简单的书卷/对话示意
        lines = VGroup(
            Line(LEFT*0.4, RIGHT*0.4, color=WHITE),
            Line(LEFT*0.4, RIGHT*0.4, color=WHITE),
            Line(LEFT*0.4, RIGHT*0.4, color=WHITE)
        ).arrange(DOWN, buff=0.2).move_to(icon_2)

        label_2 = Text("沟通历史", font="AR PL UKai CN", font_size=24).next_to(icon_2, DOWN)
        desc_2 = Text("求真务实对话", font="AR PL UKai CN", font_size=16, color=GRAY_B).next_to(label_2, DOWN)
        group_2 = VGroup(icon_2, lines, label_2, desc_2)

        # 讲稿片段4：行走天下
        # "最后是行走天下，他用脚步丈量山水，用心灵感悟自然，在漫游中完成了精神的疗愈与升华。"

        # 3. 行走天下
        icon_3 = RegularPolygon(n=3, color=RED, fill_opacity=0.2).scale(0.8) # Triangle as mountain/path marker
        # 简单的路径示意
        path = Curve(
            [-0.3, -0.3, 0], [0, 0.3, 0], [0.3, -0.3, 0], color=WHITE
        ).move_to(icon_3)

        label_3 = Text("行走天下", font="AR PL UKai CN", font_size=24).next_to(icon_3, DOWN)
        desc_3 = Text("精神疗愈升华", font="AR PL UKai CN", font_size=16, color=GRAY_B).next_to(label_3, DOWN)
        group_3 = VGroup(icon_3, path, label_3, desc_3)

        # 布局
        main_group = VGroup(group_1, group_2, group_3).arrange(RIGHT, buff=1.5).move_to(DOWN * 0.5)

        # 动画序列
        self.play(FadeIn(group_1, shift=UP))

        self.play(FadeIn(group_2, shift=UP))

        self.play(FadeIn(group_3, shift=UP))

        # 讲稿片段5：总结
        # "这三个维度——对日常的敏锐观察、对历史的真诚追问、对天地的切身体验，构成了我们在当下生活中实践诗意栖居的核心路径，它们提醒我们，无论身处何种境遇，都可以通过这样的方式，在看似非诗意的生活中，开辟出属于自己的诗意空间。"

        rect = SurroundingRectangle(main_group, color=ORANGE, buff=0.2)
        conclusion_text = Text("核心路径：开辟属于自己的诗意空间", font="AR PL UKai CN", font_size=26, color=ORANGE)
        conclusion_text.next_to(rect, DOWN, buff=0.3)

        self.play(Create(rect))
        self.play(Write(conclusion_text))
