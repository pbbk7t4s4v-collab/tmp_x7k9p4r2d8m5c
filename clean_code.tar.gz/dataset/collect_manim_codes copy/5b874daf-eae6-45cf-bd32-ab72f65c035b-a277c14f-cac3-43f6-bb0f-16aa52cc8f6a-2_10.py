from manim import *

class EigenvectorStep(Scene):
    def construct(self):

        # 1. 标题部分 (遵循模板要求)
        title = Text("第三步：求解特征向量",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("20", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 分为三个步骤块

        # 步骤 1: 代入特征值
        step1_label = Text("1. 代入特征值", font="AR PL UKai CN", font_size=24, color=TEAL).to_edge(LEFT, buff=1).shift(UP*1.5)
        step1_eq = MathTex(r"(A - \lambda_i I)\mathbf{x} = \mathbf{0}", font_size=36)
        step1_eq.next_to(step1_label, DOWN, buff=0.3).align_to(step1_label, LEFT)

        step1_group = VGroup(step1_label, step1_eq)

        # 步骤 2: 求解方程组
        step2_label = Text("2. 求解齐次方程组", font="AR PL UKai CN", font_size=24, color=TEAL)
        step2_label.next_to(step1_group, DOWN, buff=0.6).align_to(step1_label, LEFT)

        step2_desc = Text("使用高斯消元法求解解空间", font="AR PL UKai CN", font_size=20, color=GRAY_B)
        step2_desc.next_to(step2_label, DOWN, buff=0.2).align_to(step2_label, LEFT)

        step2_group = VGroup(step2_label, step2_desc)

        # 步骤 3: 确定特征空间与基
        step3_label = Text("3. 确定特征空间与基向量", font="AR PL UKai CN", font_size=24, color=TEAL)
        step3_label.next_to(step2_group, DOWN, buff=0.6).align_to(step1_label, LEFT)

        # 示例解向量
        step3_eq = MathTex(
            r"\mathbf{x} = k \begin{pmatrix} v_1 \\ v_2 \end{pmatrix}, \quad k \neq 0",
            font_size=36
        )
        step3_eq.next_to(step3_label, DOWN, buff=0.3).align_to(step3_label, LEFT)

        step3_group = VGroup(step3_label, step3_eq)

        # 右侧可视化示意图 (简单的向量空间示意)
        # 坐标轴
        axes = Axes(
            x_range=[-2, 2], y_range=[-2, 2],
            x_length=3, y_length=3,
            axis_config={"include_tip": True, "tip_length": 0.1}
        ).to_edge(RIGHT, buff=1.5).shift(DOWN*0.5)

        # 特征向量直线
        line_vector = Line(
            start=axes.c2p(-1.5, -1.5),
            end=axes.c2p(1.5, 1.5),
            color=YELLOW,
            stroke_width=3
        )

        # 标签
        label_space = MathTex("E_{\lambda_i}", color=YELLOW, font_size=30).next_to(line_vector, UP)

        visual_group = VGroup(axes, line_vector, label_space)

        # 3. 动画流程

        # 展示步骤 1
        self.play(FadeIn(step1_label, shift=RIGHT), Write(step1_eq))

        # 展示步骤 2
        self.play(FadeIn(step2_label, shift=RIGHT), FadeIn(step2_desc))

        # 展示步骤 3
        self.play(FadeIn(step3_label, shift=RIGHT), Write(step3_eq))

        # 强调结果
        box = SurroundingRectangle(step3_eq, color=YELLOW, buff=0.1)
        self.play(Create(box))

        # 展示右侧可视化
        self.play(Create(axes), run_time=1)
        self.play(Create(line_vector), Write(label_space))
