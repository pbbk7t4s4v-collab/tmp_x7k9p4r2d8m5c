from manim import *
import numpy as np

class PlanarRobotArm(Scene):
    def construct(self):

        # 1. Title Configuration (Strictly following template)
        title = Text("Planar 2R Robot Arm Example",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("23", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Geometry Setup (The Robot)
        # Parameters
        L1 = 2.2
        L2 = 1.8
        theta1 = 40 * DEGREES
        theta2 = 35 * DEGREES

        # Origin for the robot (shifted left)
        origin = LEFT * 3 + DOWN * 2

        # Calculate joint positions
        p0 = origin
        p1 = p0 + np.array([L1 * np.cos(theta1), L1 * np.sin(theta1), 0])
        p2 = p1 + np.array([L2 * np.cos(theta1 + theta2), L2 * np.sin(theta1 + theta2), 0])

        # Visual Elements
        # Base
        base_line = Line(LEFT*0.5, RIGHT*0.5).move_to(p0 + DOWN*0.05)
        base_feature = VGroup(base_line, Line(p0, p0+DOWN*0.2))

        # Links
        link1 = Line(p0, p1, color=BLUE, stroke_width=6)
        link2 = Line(p1, p2, color=GREEN, stroke_width=6)

        # Joints
        joint0 = Dot(p0, color=WHITE)
        joint1 = Dot(p1, color=WHITE)
        ee = Dot(p2, color=RED) # End Effector

        # Labels for Links
        label_L1 = MathTex("L_1", font_size=24).next_to(link1, UP, buff=0.1).rotate(theta1)
        label_L2 = MathTex("L_2", font_size=24).next_to(link2, UP, buff=0.1).rotate(theta1+theta2)

        # Reference Lines for Angles
        ref_line_x = DashedLine(p0, p0 + RIGHT * 1.5, color=GRAY)
        ref_line_link1 = DashedLine(p1, p1 + (p1-p0).normalize() * 1.5, color=GRAY)

        # Angles
        arc1 = Angle(ref_line_x, link1, radius=0.6, color=YELLOW)
        tex_theta1 = MathTex(r"\theta_1", font_size=24, color=YELLOW).next_to(arc1, RIGHT, buff=0.1).shift(UP*0.1)

        arc2 = Angle(ref_line_link1, link2, radius=0.6, color=YELLOW)
        tex_theta2 = MathTex(r"\theta_2", font_size=24, color=YELLOW).next_to(arc2, RIGHT, buff=0.1).shift(UP*0.1)

        # End Effector Label
        ee_label = MathTex("(x, y)", font_size=24, color=RED).next_to(ee, RIGHT, buff=0.1)

        robot_group = VGroup(
            base_feature, ref_line_x, ref_line_link1,
            link1, link2, joint0, joint1, ee,
            arc1, arc2, label_L1, label_L2,
            tex_theta1, tex_theta2, ee_label
        )

        # 3. Mathematical Derivation (Right Side)
        eq_intro = Text("Forward Kinematics:", font_size=28, color=BLUE_A).to_edge(RIGHT, buff=2).shift(UP*1.5)

        eq_x = MathTex(
            r"x = L_1 \cos(\theta_1) + L_2 \cos(\theta_1 + \theta_2)",
            font_size=30
        )
        eq_y = MathTex(
            r"y = L_1 \sin(\theta_1) + L_2 \sin(\theta_1 + \theta_2)",
            font_size=30
        )
        eq_phi = MathTex(
            r"\phi = \theta_1 + \theta_2",
            font_size=30
        )

        equations = VGroup(eq_x, eq_y, eq_phi).arrange(DOWN, buff=0.4, aligned_edge=LEFT)
        equations.next_to(eq_intro, DOWN, buff=0.5, aligned_edge=LEFT)

        # Highlight Box
        box = SurroundingRectangle(equations, color=BLUE, buff=0.2)
        box_label = Text("Workspace Mapping", font_size=20, color=BLUE).next_to(box, DOWN)

        # 4. Animation Sequence
        # Show Robot Construction
        self.play(FadeIn(base_feature), Create(joint0))
        self.play(Create(ref_line_x))

        self.play(Create(link1), Write(label_L1))
        self.play(Create(arc1), Write(tex_theta1))
        self.play(Create(joint1))

        self.play(Create(ref_line_link1))
        self.play(Create(link2), Write(label_L2))
        self.play(Create(arc2), Write(tex_theta2))
        self.play(Create(ee), Write(ee_label))

        # Show Equations
        self.play(Write(eq_intro))
        self.play(
            AnimationGroup(
                Write(eq_x),
                Write(eq_y),
                Write(eq_phi),
                lag_ratio=0.5
            )
        )

        # Final Highlight
        self.play(Create(box), FadeIn(box_label))
