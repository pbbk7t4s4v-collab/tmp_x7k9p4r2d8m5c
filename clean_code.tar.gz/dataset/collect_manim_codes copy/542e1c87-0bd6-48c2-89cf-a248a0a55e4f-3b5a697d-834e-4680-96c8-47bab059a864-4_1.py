from manim import *

class ConsolidationAndApplication(Scene):
    def construct(self):

        # 1. 标题配置 (严格按照模板要求)
        title = Text("知识巩固与实践应用",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局
        # 定义三个主要阶段:理论复习 -> 编程实践 -> 拓展应用
        font_style = {"font": "AR PL UKai CN", "color": WHITE}

        # 步骤标题
        step1_txt = Text("理论回顾", font_size=28, **font_style)
        step2_txt = Text("编程实战", font_size=28, **font_style)
        step3_txt = Text("项目应用", font_size=28, **font_style)

        # 将步骤水平排列
        steps_group = VGroup(step1_txt, step2_txt, step3_txt)
        steps_group.arrange(RIGHT, buff=2.5)
        steps_group.move_to(ORIGIN).shift(UP * 0.5)

        # 使用 SurroundingRectangle 创建边框
        box1 = SurroundingRectangle(step1_txt, color=BLUE, buff=0.3, stroke_width=2)
        box2 = SurroundingRectangle(step2_txt, color=GREEN, buff=0.3, stroke_width=2)
        box3 = SurroundingRectangle(step3_txt, color=RED, buff=0.3, stroke_width=2)

        # 创建连接箭头
        arrow1 = Arrow(box1.get_right(), box2.get_left(), color=GREY, buff=0.1, max_tip_length_to_length_ratio=0.15)
        arrow2 = Arrow(box2.get_right(), box3.get_left(), color=GREY, buff=0.1, max_tip_length_to_length_ratio=0.15)

        # 详细描述文本 (放在下方)
        desc1 = Text("核心概念\n公式推导", font_size=20, line_spacing=0.8, **font_style)
        desc1.next_to(box1, DOWN, buff=0.3)

        desc2 = Text("代码复现\n参数调整", font_size=20, line_spacing=0.8, **font_style)
        desc2.next_to(box2, DOWN, buff=0.3)

        desc3 = Text("真实数据\n模型评估", font_size=20, line_spacing=0.8, **font_style)
        desc3.next_to(box3, DOWN, buff=0.3)

        # 3. 动画流程
        # 显示第一步:理论
        self.play(
            Create(box1),
            FadeIn(step1_txt, shift=UP * 0.2),
            run_time=1
        )
        self.play(Write(desc1), run_time=0.6)

        # 显示第二步:编程 (通过箭头连接)
        self.play(GrowArrow(arrow1), run_time=0.5)
        self.play(
            Create(box2),
            FadeIn(step2_txt, shift=UP * 0.2),
            run_time=1
        )
        self.play(Write(desc2), run_time=0.6)

        # 显示第三步:应用
        self.play(GrowArrow(arrow2), run_time=0.5)
        self.play(
            Create(box3),
            FadeIn(step3_txt, shift=UP * 0.2),
            run_time=1
        )
        self.play(Write(desc3), run_time=0.6)

        # 4. 整体强调
        full_group = VGroup(steps_group, box1, box2, box3, arrow1, arrow2, desc1, desc2, desc3)
        self.play(
            full_group.animate.scale(1.05),
            run_time=0.5
        )
        self.play(
            full_group.animate.scale(1/1.05),
            run_time=0.5
        )
