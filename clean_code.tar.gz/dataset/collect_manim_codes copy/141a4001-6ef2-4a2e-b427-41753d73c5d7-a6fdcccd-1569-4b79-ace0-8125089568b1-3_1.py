from manim import *

class CoqFunctionsAndPredicates(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("Coq中的函数与谓词",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 左侧：算术性质 (旧知识)
        arith_title = Text("算术性质", font_size=28, font="AR PL UKai CN", color=BLUE_A)
        arith_eq1 = MathTex("1 + 1 = 2", font_size=30)
        arith_eq2 = MathTex("\\forall n, n + 0 = n", font_size=30)

        left_content = VGroup(arith_title, arith_eq1, arith_eq2).arrange(DOWN, buff=0.4)
        left_box = SurroundingRectangle(left_content, color=BLUE, buff=0.3)
        left_group = VGroup(left_box, left_content)

        # 右侧：系统行为 (新知识 - 函数与谓词)
        sys_title = Text("系统行为", font_size=28, font="AR PL UKai CN", color=GREEN_A)

        # 函数节点
        func_node = Text("函数 (Functions)", font_size=26, font="AR PL UKai CN", color=WHITE)
        func_desc = Text("计算数值或转换数据", font_size=20, font="AR PL UKai CN", color=GRAY_B)
        func_group = VGroup(func_node, func_desc).arrange(DOWN, buff=0.1)

        # 谓词节点
        pred_node = Text("谓词 (Predicates)", font_size=26, font="AR PL UKai CN", color=WHITE)
        pred_desc = Text("描述逻辑属性或关系", font_size=20, font="AR PL UKai CN", color=GRAY_B)
        pred_group = VGroup(pred_node, pred_desc).arrange(DOWN, buff=0.1)

        right_inner = VGroup(sys_title, func_group, pred_group).arrange(DOWN, buff=0.5)
        right_box = SurroundingRectangle(right_inner, color=GREEN, buff=0.3)
        right_group = VGroup(right_box, right_inner)

        # 整体布局位置
        main_group = VGroup(left_group, right_group).arrange(RIGHT, buff=1.5)
        main_group.move_to(ORIGIN).shift(DOWN * 0.3)

        # 转换箭头
        arrow = Arrow(left_box.get_right(), right_box.get_left(), color=YELLOW, buff=0.1)
        arrow_text = Text("扩展定义", font_size=22, font="AR PL UKai CN", color=YELLOW).next_to(arrow, UP, buff=0.1)

        # 3. 动画流程
        # 步骤1: 展示左侧算术性质
        self.play(
            Create(left_box),
            FadeIn(left_content, shift=UP),
            run_time=1.5
        )

        # 步骤2: 箭头过渡
        self.play(
            GrowArrow(arrow),
            Write(arrow_text),
            run_time=1.0
        )

        # 步骤3: 展示右侧系统行为
        self.play(
            Create(right_box),
            FadeIn(sys_title, shift=UP),
            run_time=1.0
        )

        # 步骤4: 强调函数与谓词
        self.play(
            Write(func_group),
            run_time=1.0
        )
        self.play(
            Write(pred_group),
            run_time=1.0
        )

        # 停顿以供阅读
