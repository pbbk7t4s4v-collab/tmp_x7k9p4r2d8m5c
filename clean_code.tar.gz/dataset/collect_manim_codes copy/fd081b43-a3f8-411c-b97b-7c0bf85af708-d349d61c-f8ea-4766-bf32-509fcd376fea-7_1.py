from manim import *

class DeepLearningInVision(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (按照模板要求)
        # ---------------------------------------------------------
        title = Text("深度学习在视觉中的应用",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念可视化:CNN 流程示意图
        # ---------------------------------------------------------

        # 左侧:输入层
        input_box = Square(side_length=1.2, color=BLUE, fill_opacity=0.3)
        input_grid = VGroup(*[
            Line(input_box.get_corner(UL) + RIGHT * i * 0.4, input_box.get_corner(DL) + RIGHT * i * 0.4, stroke_width=1, color=BLUE_E)
            for i in range(1, 3)
        ], *[
            Line(input_box.get_corner(UL) + DOWN * i * 0.4, input_box.get_corner(UR) + DOWN * i * 0.4, stroke_width=1, color=BLUE_E)
            for i in range(1, 3)
        ])
        input_group = VGroup(input_box, input_grid)
        input_group.to_edge(LEFT, buff=1.5).shift(UP*0.5)

        input_label = Text("输入图像", font="AR PL UKai CN", font_size=18).next_to(input_box, DOWN)

        # 中间:卷积层/特征提取 (用不同大小的矩形表示层级缩减)
        conv1 = Rectangle(width=0.8, height=1.0, color=GREEN, fill_opacity=0.4)
        conv2 = Rectangle(width=0.6, height=0.8, color=GREEN, fill_opacity=0.6)
        conv3 = Rectangle(width=0.4, height=0.6, color=GREEN, fill_opacity=0.8)

        conv_layers = VGroup(conv1, conv2, conv3).arrange(RIGHT, buff=0.5)
        conv_layers.move_to(ORIGIN).shift(UP*0.5)

        # 连接箭头
        arrow1 = Arrow(input_box.get_right(), conv1.get_left(), buff=0.1, color=GREY)
        arrow2 = Arrow(conv1.get_right(), conv2.get_left(), buff=0.1, color=GREY)
        arrow3 = Arrow(conv2.get_right(), conv3.get_left(), buff=0.1, color=GREY)

        feature_label = Text("卷积神经网络 (CNN)", font="AR PL UKai CN", font_size=18, color=GREEN).next_to(conv_layers, UP)

        # 框选特征提取部分
        surround_rect = SurroundingRectangle(VGroup(conv_layers, feature_label), color=YELLOW, buff=0.2, stroke_width=2)
        feature_desc = Text("特征自动提取", font="AR PL UKai CN", font_size=16, color=YELLOW).next_to(surround_rect, DOWN)

        # 右侧:全连接与输出
        fc_nodes = VGroup(*[Dot(radius=0.08, color=RED) for _ in range(3)]).arrange(DOWN, buff=0.2)
        fc_nodes.next_to(conv3, RIGHT, buff=1.0)

        arrow_fc = Arrow(conv3.get_right(), fc_nodes.get_left(), buff=0.1, color=GREY)

        output_text = Text("分类/检测结果", font="AR PL UKai CN", font_size=18).next_to(fc_nodes, RIGHT, buff=0.3)

        # ---------------------------------------------------------
        # 3. 底部应用列表
        # ---------------------------------------------------------
        app_title = Text("典型视觉任务:", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        app_list = VGroup(
            Text("1. 图像分类 (ResNet)", font="AR PL UKai CN", font_size=20),
            Text("2. 目标检测 (YOLO)", font="AR PL UKai CN", font_size=20),
            Text("3. 语义分割 (U-Net)", font="AR PL UKai CN", font_size=20)
        ).arrange(RIGHT, buff=0.8)

        bottom_group = VGroup(app_title, app_list).arrange(DOWN, buff=0.3)
        bottom_group.to_edge(DOWN, buff=0.8)

        # ---------------------------------------------------------
        # 4. 动画流程
        # ---------------------------------------------------------

        # 第一步:显示输入和结构概览
        self.play(
            FadeIn(input_group, shift=RIGHT),
            Write(input_label),
            run_time=1
        )

        # 第二步:构建网络结构
        self.play(
            GrowArrow(arrow1),
            FadeIn(conv_layers, shift=LEFT),
            Write(feature_label),
            run_time=1.5
        )

        self.play(
            Create(surround_rect),
            Write(feature_desc),
            run_time=1
        )

        # 第三步:连接到输出
        self.play(
            GrowArrow(arrow2),
            GrowArrow(arrow3),
            GrowArrow(arrow_fc),
            FadeIn(fc_nodes),
            Write(output_text),
            run_time=1.5
        )

        # 第四步:展示具体应用
        self.play(
            FadeIn(app_title, shift=UP),
            LaggedStart(
                *[FadeIn(item, shift=UP) for item in app_list],
                lag_ratio=0.2
            ),
            run_time=2
        )
