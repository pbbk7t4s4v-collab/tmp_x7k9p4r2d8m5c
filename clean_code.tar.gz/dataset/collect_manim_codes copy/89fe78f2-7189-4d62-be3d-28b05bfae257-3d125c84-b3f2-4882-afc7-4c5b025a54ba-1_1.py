from manim import *

class TotalReflectionConditions(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("全反射的产生条件",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 文本内容展示 (条件列表)
        # ---------------------------------------------------------
        # 使用 VGroup 手动构建列表,避免 BulletedList 的兼容性问题

        # 条件一
        dot1 = Dot(color=BLUE).scale(0.8)
        text1 = Text("光从光密介质射入光疏介质", font="AR PL UKai CN", font_size=24)
        math1 = MathTex(r"(n_1 > n_2)", font_size=28, color=BLUE)
        item1 = VGroup(dot1, text1, math1).arrange(RIGHT, buff=0.2)

        # 条件二
        dot2 = Dot(color=BLUE).scale(0.8)
        text2 = Text("入射角大于或等于临界角", font="AR PL UKai CN", font_size=24)
        math2 = MathTex(r"(i \ge C)", font_size=28, color=RED)
        item2 = VGroup(dot2, text2, math2).arrange(RIGHT, buff=0.2)

        # 组合文本
        content_group = VGroup(item1, item2).arrange(DOWN, buff=0.5, aligned_edge=LEFT)
        content_group.next_to(title_group, DOWN, buff=0.8)

        # 文本进场动画
        self.play(FadeIn(content_group, shift=UP), run_time=1.0)

        # 强调框
        box = SurroundingRectangle(content_group, color=YELLOW, buff=0.2, stroke_width=2)
        self.play(Create(box), run_time=0.8)

        # ---------------------------------------------------------
        # 3. 几何可视化 (光路示意图)
        # ---------------------------------------------------------
        # 定义坐标
        origin = DOWN * 1.5
        left_point = origin + LEFT * 3
        right_point = origin + RIGHT * 3
        up_point = origin + UP * 1.5

        # 介质分界线
        interface = Line(left_point, right_point, color=WHITE)

        # 介质标记
        medium_dense = Text("光密介质 (水/玻璃)", font="AR PL UKai CN", font_size=20, color=BLUE_D)
        medium_dense.next_to(interface, DOWN, buff=0.2).to_edge(RIGHT, buff=1)

        medium_rare = Text("光疏介质 (空气)", font="AR PL UKai CN", font_size=20, color=GREY)
        medium_rare.next_to(interface, UP, buff=0.2).to_edge(RIGHT, buff=1)

        # 法线 (虚线)
        normal_line = DashedLine(origin + DOWN, origin + UP, color=GREY)

        # 光线路径
        # 入射光线 (从下往上,角度较大)
        incident_ray = Arrow(start=origin + DL * 1.5, end=origin, buff=0, color=YELLOW, stroke_width=3)

        # 反射光线 (全反射)
        reflected_ray = Arrow(start=origin, end=origin + DR * 1.5, buff=0, color=YELLOW, stroke_width=3)

        # 角度标记
        angle_arc = Angle(Line(origin, origin + DOWN), Line(origin, origin + DL * 1.5), radius=0.4, other_angle=True)
        angle_label = MathTex("i", font_size=24).next_to(angle_arc, DOWN, buff=0.1)

        diagram_group = VGroup(interface, normal_line, medium_dense, medium_rare, incident_ray, reflected_ray, angle_arc, angle_label)

        # ---------------------------------------------------------
        # 4. 演示动画
        # ---------------------------------------------------------

        # 绘制介质环境
        self.play(
            Create(interface),
            Create(normal_line),
            Write(medium_dense),
            Write(medium_rare),
            run_time=1.5
        )

        # 演示光路
        self.play(GrowArrow(incident_ray), run_time=0.8)
        self.play(
            Create(angle_arc),
            Write(angle_label),
            run_time=0.5
        )

        # 发生全反射
        self.play(
            GrowArrow(reflected_ray),
            Indicate(math2, color=RED), # 强调条件二
            run_time=1.0
        )
