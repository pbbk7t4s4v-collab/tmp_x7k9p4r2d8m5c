from manim import *

class ElectrostaticInteractionScene(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("静电相互作用：电荷与偶极子",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("47", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 分为左右两部分
        # 左侧：电荷-电荷相互作用 (n=1)
        left_title = Text("电荷-电荷相互作用 (n=1)", font="AR PL UKai CN", font_size=24, color=BLUE)

        # 库仑定律公式
        coulomb_eq = Text("V(r) = q1 q2 / (4π ε0 r)", font_size=28)

        # 可视化：同性相斥/异性相吸
        # 创建一个简单的电荷模型
        charge_plus = VGroup(Circle(radius=0.2, color=RED, fill_opacity=0.5), Text("+", color=WHITE, font_size=24)).center()
        charge_minus = VGroup(Circle(radius=0.2, color=BLUE, fill_opacity=0.5), Text("-", color=WHITE, font_size=24)).center()

        charge_visual = VGroup(charge_plus.copy(), charge_minus.copy()).arrange(RIGHT, buff=1.5)
        force_arrow = DoubleArrow(charge_visual[0].get_right(), charge_visual[1].get_left(), buff=0.1, color=YELLOW)
        force_label = Text("F", color=YELLOW, font_size=24).next_to(force_arrow, UP, buff=0.05)

        visual_group_1 = VGroup(charge_visual, force_arrow, force_label)

        # 文字描述列表（使用普通文本替代 LaTeX BulletedList）
        list_items = [
            "最强长程作用，服从库仑定律",
            "异性相吸，同性相斥",
            "衰减极慢，需Ewald求和处理",
        ]
        bullet_lines = VGroup(
            *[
                VGroup(Dot(radius=0.04, color=WHITE), Text(item, font="AR PL UKai CN", font_size=20)).arrange(RIGHT, buff=0.2)
                for item in list_items
            ]
        ).arrange(DOWN, buff=0.15, aligned_edge=LEFT)
        list_1 = bullet_lines

        left_group = VGroup(left_title, coulomb_eq, visual_group_1, list_1).arrange(DOWN, buff=0.4)

        # 右侧：涉及偶极子的相互作用 (n=2, 3)
        right_title = Text("涉及偶极子的相互作用", font="AR PL UKai CN", font_size=24, color=GREEN)

        # 子部分1: 电荷-偶极子
        sub_title_2 = Text("1. 电荷-偶极子 (n=2)", font="AR PL UKai CN", font_size=20, color=TEAL).align_to(right_title, LEFT)
        eq_2 = Text("V(r) ∝ r^-2", font_size=24)

        # 可视化：电荷与偶极子
        dipole_shape = RoundedRectangle(corner_radius=0.1, height=0.3, width=0.6, color=PURPLE, fill_opacity=0.5)
        dipole_text = Text("+ -", font_size=20).move_to(dipole_shape)
        dipole_obj = VGroup(dipole_shape, dipole_text)

        visual_2 = VGroup(charge_plus.copy().scale(0.8), dipole_obj.copy()).arrange(RIGHT, buff=1)
        visual_2_label = Text("取向调整", font="AR PL UKai CN", font_size=16, color=GRAY).next_to(visual_2, DOWN, buff=0.1)

        # 子部分2: 偶极子-偶极子
        sub_title_3 = Text("2. 偶极子-偶极子 (n=3)", font="AR PL UKai CN", font_size=20, color=TEAL).align_to(right_title, LEFT)
        eq_3 = Text("V(r) ∝ r^-3", font_size=24)

        visual_3 = VGroup(dipole_obj.copy(), dipole_obj.copy()).arrange(RIGHT, buff=1)

        right_sub_group = VGroup(
            sub_title_2,
            VGroup(eq_2, visual_2, visual_2_label).arrange(RIGHT, buff=0.3),
            sub_title_3,
            VGroup(eq_3, visual_3).arrange(RIGHT, buff=0.3)
        ).arrange(DOWN, buff=0.4, aligned_edge=LEFT)

        right_group = VGroup(right_title, right_sub_group).arrange(DOWN, buff=0.4)

        # 3. 整体布局调整
        main_content = VGroup(left_group, right_group).arrange(RIGHT, buff=1.0).next_to(title_group, DOWN, buff=0.5)

        # 添加边框强调
        box_left = SurroundingRectangle(left_group, color=BLUE_C, buff=0.2)
        box_right = SurroundingRectangle(right_group, color=GREEN_C, buff=0.2)

        # 4. 动画播放
        # 左侧入场
        self.play(FadeIn(box_left), FadeIn(left_title))
        self.play(Write(coulomb_eq))
        self.play(FadeIn(visual_group_1))
        self.play(Write(list_1))

        # 右侧入场
        self.play(FadeIn(box_right), FadeIn(right_title))
        self.play(
            FadeIn(sub_title_2),
            Write(eq_2),
            FadeIn(visual_2),
            FadeIn(visual_2_label)
        )
        self.play(
            FadeIn(sub_title_3),
            Write(eq_3),
            FadeIn(visual_3)
        )
