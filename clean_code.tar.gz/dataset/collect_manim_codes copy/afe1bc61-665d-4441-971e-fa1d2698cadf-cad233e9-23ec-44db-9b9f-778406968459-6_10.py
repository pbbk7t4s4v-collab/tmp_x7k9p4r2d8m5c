from manim import *

class SoftwareCrisisScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("软件危机的背景与定义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("21", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 历史背景 (文本列表展示)
        # ---------------------------------------------------------
        # 使用 VGroup 手动构建列表,避免 BulletedList 的潜在兼容性问题
        bullet1 = Text("• 20世纪60年代中期:硬件向高速度发展,软件规模急剧膨胀",
                      font="AR PL UKai CN", font_size=24, color=LIGHT_GRAY)
        bullet2 = Text("• 1968年:北大西洋公约组织 (NATO) 首次提出"软件危机"",
                      font="AR PL UKai CN", font_size=24, color=LIGHT_GRAY)

        text_group = VGroup(bullet1, bullet2).arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        text_group.next_to(title_line, DOWN, buff=0.8)

        self.play(FadeIn(text_group, shift=UP))

        # ---------------------------------------------------------
        # 3. 核心矛盾可视化 (对比图)
        # ---------------------------------------------------------
        # 左侧:生产能力
        cap_title = Text("软件生产能力", font="AR PL UKai CN", font_size=28, color=BLUE_C)
        cap_desc = Text("弱 / 手工", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        cap_group = VGroup(cap_title, cap_desc).arrange(DOWN, buff=0.2)

        cap_box = SurroundingRectangle(cap_group, color=BLUE, buff=0.2)
        cap_full = VGroup(cap_box, cap_group)

        # 右侧:业务需求
        dem_title = Text("业务发展需求", font="AR PL UKai CN", font_size=28, color=RED_C)
        dem_desc = Text("强 / 爆发", font="AR PL UKai CN", font_size=32, color=RED_A) # 字体稍大表示强
        dem_group = VGroup(dem_title, dem_desc).arrange(DOWN, buff=0.2)

        # 使用更大的框表示需求大
        dem_box = SurroundingRectangle(dem_group, color=RED, buff=0.4)
        dem_full = VGroup(dem_box, dem_group)

        # 布局:左右排列
        visual_group = VGroup(cap_full, dem_full).arrange(RIGHT, buff=2.0)
        visual_group.next_to(text_group, DOWN, buff=1.0)

        # 中间的不等号和矛盾标识
        inequality = MathTex(r"\ll", color=YELLOW).scale(1.5).move_to(visual_group.get_center())
        conflict_label = Text("不相适应", font="AR PL UKai CN", font_size=22, color=YELLOW)
        conflict_label.next_to(inequality, UP, buff=0.1)

        # ---------------------------------------------------------
        # 4. 动画展示
        # ---------------------------------------------------------
        # 显示两边的方框和文字
        self.play(
            Create(cap_box), Write(cap_group),
            run_time=1
        )
        self.play(
            Create(dem_box), Write(dem_group),
            run_time=1
        )

        # 强调矛盾
        self.play(
            Write(inequality),
            FadeIn(conflict_label),
            dem_full.animate.scale(1.1), # 放大需求端,强调不平衡
            cap_full.animate.scale(0.9)
        )

        # 底部总结定义
        summary = Text("定义:软件生产能力与业务发展需求之间的矛盾",
                      font="AR PL UKai CN", font_size=26, color=YELLOW)
        summary.next_to(visual_group, DOWN, buff=0.6)

        self.play(Write(summary))
