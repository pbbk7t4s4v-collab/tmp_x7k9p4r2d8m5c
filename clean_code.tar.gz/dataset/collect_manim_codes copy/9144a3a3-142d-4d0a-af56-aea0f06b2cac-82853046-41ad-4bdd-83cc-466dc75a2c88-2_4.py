from manim import *

class TaxonomyScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (根据模板要求)
        # ---------------------------------------------------------
        title = Text("开放式任务的分类体系",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 左侧:分类层级结构
        # ---------------------------------------------------------
        # 定义文本内容
        root_text = Text("首个真实用户体系", font="AR PL UKai CN", font_size=26, color=YELLOW)

        # 分类数量节点
        cat_major = Text("6 大类", font="AR PL UKai CN", font_size=30, color=BLUE_A)
        cat_minor = Text("17 小类", font="AR PL UKai CN", font_size=30, color=BLUE_B)

        # 排版:垂直排列
        hierarchy_group = VGroup(root_text, cat_major, cat_minor).arrange(DOWN, buff=1.0)
        hierarchy_group.to_edge(LEFT, buff=2.0).shift(DOWN * 0.5)

        # 连接箭头
        arrow1 = Arrow(root_text.get_bottom(), cat_major.get_top(), buff=0.1, color=GRAY)
        arrow2 = Arrow(cat_major.get_bottom(), cat_minor.get_top(), buff=0.1, color=GRAY)

        # 外框 (强调整体结构)
        structure_rect = SurroundingRectangle(
            VGroup(root_text, cat_minor),
            color=WHITE,
            buff=0.4,
            corner_radius=0.2
        )
        structure_label = Text("结构层级", font="AR PL UKai CN", font_size=20, color=GRAY)
        structure_label.next_to(structure_rect, UP, buff=0.1)

        # ---------------------------------------------------------
        # 3. 右侧:典型类别示例
        # ---------------------------------------------------------
        example_title = Text("典型类别示例", font="AR PL UKai CN", font_size=24, color=GREEN)

        # 示例内容列表
        examples = ["创意生成", "头脑风暴", "假设性推理", "概念解释"]

        # 创建示例卡片
        example_mobjects = VGroup()
        for ex_text in examples:
            t = Text(ex_text, font="AR PL UKai CN", font_size=24, color=WHITE)
            box = SurroundingRectangle(t, color=GREEN, fill_opacity=0.2, fill_color=GREEN_E, corner_radius=0.1)
            group = VGroup(box, t)
            example_mobjects.add(group)

        # 网格排列 (2x2)
        example_mobjects.arrange_in_grid(rows=2, cols=2, buff=0.4)

        # 整体布局:放在左侧结构的右边
        right_group = VGroup(example_title, example_mobjects).arrange(DOWN, buff=0.5)
        right_group.next_to(structure_rect, RIGHT, buff=1.5)

        # ---------------------------------------------------------
        # 4. 动画展示流程
        # ---------------------------------------------------------

        # 展示左侧层级结构
        self.play(Create(structure_rect), FadeIn(structure_label))
        self.play(FadeIn(root_text, shift=DOWN))
        self.play(GrowArrow(arrow1), Write(cat_major))
        self.play(GrowArrow(arrow2), Write(cat_minor))

        # 展示右侧示例
        self.play(FadeIn(example_title))
        self.play(
            LaggedStart(
                *[FadeIn(obj, shift=LEFT) for obj in example_mobjects],
                lag_ratio=0.3
            ),
            run_time=2
        )

        # 停留
