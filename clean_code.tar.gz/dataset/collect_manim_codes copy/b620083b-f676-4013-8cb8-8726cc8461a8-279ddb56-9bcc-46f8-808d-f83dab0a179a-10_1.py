from manim import *

class CourseFormatFeatures(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("课程形式特色：人机协作教学",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心图像展示
        # 根据Planner建议引入图片
        timo_img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/b620083b-f676-4013-8cb8-8726cc8461a8/279ddb56-9bcc-46f8-808d-f83dab0a179a/manim_assets/5c8bf5ef-ecb7-47e8-ad03-513b481359a8.png") # 这里期望是一张展示Timo的智能教学机器人或虚拟形象，外观可爱、具有未来科技感，表情友好且自信，姿态像是在进行讲解，背景为纯白色或简洁的渐变色的图片，要求画面清晰，写实风

        # 调整图片大小和位置 (保持1:1比例)
        timo_img.height = 4.5
        timo_img.to_edge(LEFT, buff=1.5)
        timo_img.shift(DOWN * 0.3)

        # 3. 文本内容构建
        # 使用 VGroup 排版右侧文字
        content_group = VGroup(
            Text("核心角色：TeachMaster", font="AR PL UKai CN", font_size=28, color=BLUE),
            Text("昵称：Timo (自主智能体)", font="AR PL UKai CN", font_size=26, color=WHITE),
            Text("形式：人机结合讲解", font="AR PL UKai CN", font_size=26, color=WHITE),
            Text("目标：探索新型教学模式", font="AR PL UKai CN", font_size=26, color=WHITE)
        ).arrange(DOWN, buff=0.6, aligned_edge=LEFT)

        content_group.next_to(timo_img, RIGHT, buff=1.0)

        # 为文字添加装饰框
        rect = SurroundingRectangle(content_group, color=TEAL, buff=0.3)
        label = Text("特色概览", font="AR PL UKai CN", font_size=20, color=TEAL)
        label.next_to(rect, UP, aligned_edge=LEFT)

        # 4. 动画展示流程
        # 图片淡入
        self.play(FadeIn(timo_img, shift=RIGHT), run_time=1.0)

        # 文字逐行显示
        for line in content_group:
            self.play(Write(line), run_time=0.8)

        # 显示框和标签
        self.play(Create(rect), FadeIn(label), run_time=1.0)

        # 5. 停留
