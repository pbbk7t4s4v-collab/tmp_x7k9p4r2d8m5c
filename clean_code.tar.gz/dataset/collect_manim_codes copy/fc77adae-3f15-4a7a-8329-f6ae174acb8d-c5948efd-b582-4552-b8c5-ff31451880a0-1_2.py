from manim import *

class EngineeringOptimizationScene(Scene):
    def construct(self):

        # 1. Title
        title = Text("Engineering Design & Optimization",
                     font_size=34,
                     color=WHITE,
                     weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Introduce the role of fluid dynamics and applications
        intro_text = Text("Fluid dynamics optimizes structures in fields like:", font_size=28).next_to(title_group, DOWN, buff=0.5)

        applications = BulletedList(
            "Aerospace Engineering",
            "Naval Architecture",
            "Automotive Manufacturing",
            font_size=28
        ).next_to(intro_text, DOWN, buff=0.3)
        applications.shift(LEFT*0.5)

        self.play(FadeIn(intro_text, shift=DOWN*0.5))
        self.play(Write(applications))

        # 3. Fade out introductory text to make space for examples
        self.play(FadeOut(intro_text), FadeOut(applications))

        # 4. Aircraft Design Example (Left Side)
        plane_group = VGroup()
        plane_title = Text("Aircraft Design", font_size=24, weight=BOLD).to_edge(LEFT, buff=1).shift(UP*1.5)

        airfoil = CubicBezier(
            start=np.array([-2, 0, 0]),
            handle1_start=np.array([-1, 0.5, 0]),
            handle2_end=np.array([1, 0.2, 0]),
            end=np.array([2, 0, 0])
        ).append_points(
            CubicBezier(
                start=np.array([2, 0, 0]),
                handle1_start=np.array([1, -0.2, 0]),
                handle2_end=np.array([-1, -0.3, 0]),
                end=np.array([-2, 0, 0])
            ).get_points()
        ).set_color(BLUE).scale(0.8)

        airfoil.next_to(plane_title, DOWN, buff=0.5)

        lift_arrow = Arrow(airfoil.get_center(), airfoil.get_center() + UP * 1.2, buff=0, color=GREEN)
        lift_label = Text("Lift", font_size=22, color=GREEN).next_to(lift_arrow, UP, buff=0.1)

        drag_arrow = Arrow(airfoil.get_center(), airfoil.get_center() + RIGHT * 1.5, buff=0, color=RED)
        drag_label = Text("Drag", font_size=22, color=RED).next_to(drag_arrow, RIGHT, buff=0.1)

        plane_desc = Text("Optimize wing shape", font_size=22).next_to(airfoil, DOWN, buff=0.7)

        plane_group.add(plane_title, airfoil, lift_arrow, lift_label, drag_arrow, drag_label, plane_desc)
        plane_group.shift(LEFT * 3)

        self.play(Write(plane_title))
        self.play(Create(airfoil), run_time=1.0)
        self.play(GrowArrow(lift_arrow), Write(lift_label), GrowArrow(drag_arrow), Write(drag_label))
        self.play(FadeIn(plane_desc, shift=UP*0.2))

        # 5. High-Speed Train Example (Right Side)
        train_group = VGroup()
        train_title = Text("High-Speed Train Design", font_size=24, weight=BOLD).to_edge(RIGHT, buff=1).shift(UP*1.5)

        train_body = VMobject().set_color(ORANGE)
        train_body.set_points_as_corners([
            np.array([-2, -0.5, 0]),
            np.array([-0.5, -0.5, 0]),
            np.array([0.5, 0, 0]),
            np.array([0.5, 0.8, 0]),
            np.array([-0.5, 0.8, 0]),
            np.array([-2, 0.3, 0]),
            np.array([-2, -0.5, 0]),
        ])
        train_body.next_to(train_title, DOWN, buff=0.5)

        air_flow_arrows = VGroup(*[
            Arrow(start=LEFT*0.8, end=RIGHT*0.8, color=LIGHT_GREY, max_tip_length_to_length_ratio=0.15)
            .scale(0.8).next_to(train_body, LEFT, buff=0.2).shift(UP*dy)
            for dy in [-0.3, 0, 0.3, 0.6]
        ])

        train_desc = Text("Reduce air resistance", font_size=22).next_to(train_body, DOWN, buff=0.7)

        train_group.add(train_title, train_body, air_flow_arrows, train_desc)
        train_group.shift(RIGHT * 3.5)

        self.play(Write(train_title))
        self.play(Create(train_body), run_time=1.0)
        self.play(Create(air_flow_arrows))
        self.play(FadeIn(train_desc, shift=UP*0.2))
