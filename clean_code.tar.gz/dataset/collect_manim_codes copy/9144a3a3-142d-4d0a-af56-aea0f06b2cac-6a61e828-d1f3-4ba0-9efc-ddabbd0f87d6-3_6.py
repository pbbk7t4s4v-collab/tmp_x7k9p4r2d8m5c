from manim import *

class ReceptiveFieldAndFeatures(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("感受野扩展与特征层次",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("15", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 布局设计
        # ---------------------------------------------------------
        # 左侧放文字和公式,右侧放图示

        # --- 右侧可视化:模拟图像网格 ---
        # 创建一个 7x7 的网格代表图像
        grid_size = 7
        squares = VGroup(*[
            Square(side_length=0.5, stroke_width=1, stroke_opacity=0.5, color=GREY)
            for _ in range(grid_size * grid_size)
        ])
        squares.arrange_in_grid(grid_size, grid_size, buff=0)
        squares.to_edge(RIGHT, buff=1.5).shift(DOWN * 0.5)

        # 定义中心点和感受野区域
        center_index = (grid_size * grid_size) // 2
        # 3x3 区域 (局部感受野)
        indices_3x3 = [
            center_index - grid_size - 1, center_index - grid_size, center_index - grid_size + 1,
            center_index - 1, center_index, center_index + 1,
            center_index + grid_size - 1, center_index + grid_size, center_index + grid_size + 1
        ]
        group_3x3 = VGroup(*[squares[i] for i in indices_3x3])

        # 感受野框 (初始为小)
        rf_rect = SurroundingRectangle(group_3x3, color=YELLOW, buff=0.05, stroke_width=4)
        rf_label = Text("局部感受野", font="AR PL UKai CN", font_size=20, color=YELLOW)
        rf_label.next_to(rf_rect, UP, buff=0.1)

        # 全局框 (最终覆盖全图)
        full_rect = SurroundingRectangle(squares, color=RED, buff=0.05, stroke_width=4)

        # --- 左侧内容:公式与解释 ---
        # 公式
        formula_tex = MathTex(
            r"\text{RF}_{size} = (2\Delta+1) \times (2\Delta+1)",
            color=BLUE_B
        ).scale(0.9)

        # 文本解释项
        explanation_group = VGroup(
            Text("1. 单层:捕获局部特征", font="AR PL UKai CN", font_size=24, color=WHITE),
            Text("   (如:边缘、纹理)", font="AR PL UKai CN", font_size=20, color=GREY_B),
            Text("2. 堆叠:感受野逐层扩大", font="AR PL UKai CN", font_size=24, color=WHITE),
            Text("3. 深层:覆盖全图,捕获语义", font="AR PL UKai CN", font_size=24, color=RED_B)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.3)

        # 组合左侧内容
        left_content = VGroup(formula_tex, explanation_group).arrange(DOWN, aligned_edge=LEFT, buff=0.8)
        left_content.to_edge(LEFT, buff=1.0).shift(UP * 0.5)

        # ---------------------------------------------------------
        # 3. 动画演示
        # ---------------------------------------------------------

        # 第一步:显示网格和公式
        self.play(
            FadeIn(squares),
            Write(formula_tex),
            run_time=1
        )

        # 第二步:显示局部感受野和第一条文本
        self.play(
            Create(rf_rect),
            FadeIn(rf_label),
            Write(explanation_group[0]), # 单层文本
            Write(explanation_group[1]), # 边缘纹理说明
            run_time=1.5
        )

        # 第三步:演示堆叠导致扩大
        self.play(
            Write(explanation_group[2]), # 堆叠文本
            run_time=1
        )

        # 变换感受野框:从局部(Yellow) -> 全局(Red)
        self.play(
            Transform(rf_rect, full_rect),
            rf_label.animate.become(
                Text("全局感受野", font="AR PL UKai CN", font_size=20, color=RED).next_to(full_rect, UP, buff=0.1)
            ),
            run_time=1.5
        )

        # 第四步:显示深层语义结论
        self.play(
            Write(explanation_group[3]),
            squares.animate.set_color(RED_E), # 网格稍微变红暗示被激活
            run_time=1.5
        )
