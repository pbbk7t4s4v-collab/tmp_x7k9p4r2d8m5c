from manim import *

class RolePlayDialogue(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("社团面试对话练习流程",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("14", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 图片设置 (严格按照Planner建议)
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/101035d0-c172-4b79-88f0-28d7399887d1/a3ae9e0b-ce34-437b-baa2-c120be51c066/pictures/6_2/1.png") # 这里期望是一张展示一个穿着校服的卡通学生形象，表情自信且充满期待，手里拿着一张申请表，正准备递交的图片，要求画面为清新教育类扁平插画，背景为纯白，写实风
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/101035d0-c172-4b79-88f0-28d7399887d1/a3ae9e0b-ce34-437b-baa2-c120be51c066/pictures/6_2/2.png") # 这里期望是一张展示一个坐在桌子后面的社团负责人形象，桌上放着一个写有CLUB字样的招牌，表情友好，正在进行面试或倾听的图片，要求画面为清新教育类扁平插画，背景为纯白，写实风

        # 图片位置调整 (保持1:1比例，适度缩放，左右分布)
        img1.set_height(3.2).to_edge(LEFT, buff=0.8).shift(DOWN * 0.5)
        img2.set_height(3.2).to_edge(RIGHT, buff=0.8).shift(DOWN * 0.5)

        # 3. 对话文本设置
        # 使用AR PL UKai CN字体，不同角色使用不同颜色
        t1 = Text("Student: Hello! I want to join the club.", font="AR PL UKai CN", font_size=20, color=BLUE_B)
        t2 = Text("Leader: Can you...?", font="AR PL UKai CN", font_size=20, color=GREEN_B)
        t3 = Text("Student: Yes, I can. / No, I can't.", font="AR PL UKai CN", font_size=20, color=BLUE_B)
        t4 = Text("Leader: Sure! (Time/Place) / Sorry.", font="AR PL UKai CN", font_size=20, color=GREEN_B)

        # 组合文本并垂直排列
        dialogue_group = VGroup(t1, t2, t3, t4).arrange(DOWN, buff=0.4)
        dialogue_group.move_to(ORIGIN).shift(DOWN * 0.5) # 居中放置在两张图片之间

        # 添加文本框
        box = SurroundingRectangle(dialogue_group, color=YELLOW, buff=0.3, stroke_width=2)

        # 4. 动画展示流程
        # 图片淡入
        self.play(
            FadeIn(img1, shift=RIGHT),
            FadeIn(img2, shift=LEFT),
            run_time=1
        )

        # 显示对话框和第一句
        self.play(Create(box), Write(t1), run_time=1)

        # 依次显示后续对话
        self.play(FadeIn(t2, shift=DOWN * 0.2), run_time=0.8)
        self.play(FadeIn(t3, shift=DOWN * 0.2), run_time=0.8)
        self.play(FadeIn(t4, shift=DOWN * 0.2), run_time=0.8)
