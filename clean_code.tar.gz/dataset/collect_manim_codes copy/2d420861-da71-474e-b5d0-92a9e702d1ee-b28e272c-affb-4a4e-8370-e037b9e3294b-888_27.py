from manim import *

class HydrophobicInteractionAndEmpiricalPotential(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("疏水相互作用与经验势构建",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("27", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧：疏水效应原理
        # 图片1：疏水效应熵驱动机制
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/2d420861-da71-474e-b5d0-92a9e702d1ee/b28e272c-affb-4a4e-8370-e037b9e3294b/pictures/888_27/1.png") # 这里期望是一张展示疏水效应的熵驱动机制的图片，要求画面左侧显示几个分散的非极性分子周围被排列整齐的水分子包围，右侧显示聚集后的分子及无序水分子，风格为清晰的教学演示图
        img1.height = 2.8
        img1.to_edge(LEFT, buff=0.8).shift(UP * 0.2)

        label1_title = Text("物理本质：熵驱动", font="AR PL UKai CN", font_size=24, color=YELLOW).next_to(img1, UP, buff=0.2)

        # 熵的公式
        math_entropy = MathTex(r"\Delta S_{system} > 0", color=WHITE, font_size=32).next_to(img1, DOWN, buff=0.2)
        desc1 = Text("水分子去有序化 (笼状解体)", font="AR PL UKai CN", font_size=20, color=LIGHT_GREY).next_to(math_entropy, DOWN, buff=0.1)

        # 3. 内容布局 - 右侧：蛋白质折叠示例
        # 图片2：蛋白质折叠
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/2d420861-da71-474e-b5d0-92a9e702d1ee/b28e272c-affb-4a4e-8370-e037b9e3294b/pictures/888_27/2.png") # 这里期望是一张展示蛋白质折叠剖面的图片，要求画面展示球状蛋白质内部充满黄色疏水侧链，外部为亲水表面，背景为淡蓝色的水溶液环境，风格为写实的生物医学插画
        img2.height = 2.8
        img2.to_edge(RIGHT, buff=0.8).shift(UP * 0.2)

        label2_title = Text("典型示例：蛋白质折叠", font="AR PL UKai CN", font_size=24, color=BLUE).next_to(img2, UP, buff=0.2)
        desc2_1 = Text("疏水侧链埋藏于核心", font="AR PL UKai CN", font_size=20).next_to(img2, DOWN, buff=0.2)
        desc2_2 = Text("稳定三维结构的关键", font="AR PL UKai CN", font_size=20).next_to(desc2_1, DOWN, buff=0.1)

        # 4. 底部 - 经验势模型简介
        # 使用框图展示
        concept_text = Text("经验势模型：在 计算成本 与 物理准确性 之间寻求平衡",
                          font="AR PL UKai CN", font_size=24, t2c={"计算成本": RED, "物理准确性": GREEN})
        concept_box = SurroundingRectangle(concept_text, color=TEAL, buff=0.2)
        bottom_group = VGroup(concept_box, concept_text).to_edge(DOWN, buff=0.5)

        # 5. 动画序列
        # 展示左侧疏水效应
        self.play(FadeIn(img1), Write(label1_title))
        self.play(Write(math_entropy), FadeIn(desc1))

        # 展示右侧蛋白质折叠
        self.play(FadeIn(img2), Write(label2_title))
        self.play(Write(desc2_1), Write(desc2_2))

        # 展示底部经验势概念
        self.play(Create(concept_box), Write(concept_text))
