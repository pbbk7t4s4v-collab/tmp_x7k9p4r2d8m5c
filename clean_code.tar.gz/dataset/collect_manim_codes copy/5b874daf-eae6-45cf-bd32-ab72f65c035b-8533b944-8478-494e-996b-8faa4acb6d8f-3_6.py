from manim import *

class CrossModalLearningBiology(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("计算生物学中的跨模态学习",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("25", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Content Sections
        # Foundational Period
        foundational_title = Text("图像与序列的融合", font="AR PL UKai CN",weight=BOLD, font_size=28)
        foundational_desc = Text("融合显微图像与基因表达数据，预测细胞状态。", font="AR PL UKai CN", font_size=24).next_to(foundational_title, DOWN, aligned_edge=LEFT, buff=0.15)
        foundational_group = VGroup(foundational_title, foundational_desc)

        # Viscosity and Vorticity
        viscosity_title = Text("蛋白质与文本关联",font="AR PL UKai CN", weight=BOLD, font_size=28)
        viscosity_desc = Text("处理蛋白质序列与生物医学文献，发现功能关联。", font="AR PL UKai CN", font_size=24).next_to(viscosity_title, DOWN, aligned_edge=LEFT, buff=0.15)
        viscosity_group = VGroup(viscosity_title, viscosity_desc)

        # Boundary Layer Revolution
        boundary_title = Text("多模态模型结构",font="AR PL UKai CN", weight=BOLD, font_size=28)
        boundary_desc = Text("可处理图像、序列与文本等多种数据模式", font="AR PL UKai CN", font_size=24).next_to(boundary_title, DOWN, aligned_edge=LEFT, buff=0.15)
        boundary_group = VGroup(boundary_title, boundary_desc)

        # Turbulence Theory
        turbulence_title = Text("生物学应用前景", weight=BOLD, font_size=28)
        turbulence_desc = Text("助力疾病研究、药物开发与个性化医疗", font="AR PL UKai CN", font_size=24).next_to(turbulence_title, DOWN, aligned_edge=LEFT, buff=0.15)
        turbulence_group = VGroup(turbulence_title, turbulence_desc)

        # 3. Layout and Animation
        content_group = VGroup(
            foundational_group,
            viscosity_group,
            boundary_group,
            turbulence_group
        ).arrange(DOWN, buff=0.5, aligned_edge=LEFT)

        content_group.next_to(title_group, DOWN, buff=0.5).to_edge(LEFT, buff=1.0)

        self.play(FadeIn(foundational_group, shift=UP*0.5), run_time=1)

        self.play(FadeIn(viscosity_group, shift=UP*0.5), run_time=1)
        self.play(FadeIn(boundary_group, shift=UP*0.5), run_time=1)
        self.play(FadeIn(turbulence_group, shift=UP*0.5), run_time=1)
