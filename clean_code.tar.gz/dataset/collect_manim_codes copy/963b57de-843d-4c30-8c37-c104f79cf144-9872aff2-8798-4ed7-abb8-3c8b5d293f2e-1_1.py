from manim import *

class FluidMechanicsIntro(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("流体力学绪论：探索流动的科学",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局
        # 左侧：核心概念文本
        # 定义文本内容
        text_lines = VGroup(
            Text("研究对象：液体与气体", font="AR PL UKai CN", font_size=28),
            Text("核心任务：研究平衡与运动规律", font="AR PL UKai CN", font_size=28),
            Text("应用领域：航空、水利、气象等", font="AR PL UKai CN", font_size=28)
        ).arrange(DOWN, buff=0.6, aligned_edge=LEFT)

        # 右侧：可视化插图 (根据Planner建议)
        img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/963b57de-843d-4c30-8c37-c104f79cf144/9872aff2-8798-4ed7-abb8-3c8b5d293f2e/pictures/1_1/1.png") # 这里期望是一张展示极具美感的流体力学主题插图，用于课程封面。画面展示了流体（如空气或水）流过物体时形成的彩色流线或涡旋（如卡门涡街），风格为现代科学可视化，背景简洁干净，体现物理学的严谨与美感。，写实风

        # 设置图片大小和位置 (保持1:1比例，适度缩放)
        img.height = 4.5
        img.width = 4.5

        # 整体布局：图片在右，文字在左
        img.to_edge(RIGHT, buff=1.5)
        text_lines.next_to(img, LEFT, buff=1.0)

        # 为文本添加强调框
        box = SurroundingRectangle(text_lines, color=BLUE, buff=0.4)
        label = Text("基础定义", font="AR PL UKai CN", font_size=20, color=BLUE)
        label.next_to(box, UP, aligned_edge=LEFT)

        # 3. 动画展示流程
        # 先展示图片，建立直观感受
        self.play(FadeIn(img, shift=LEFT), run_time=1.2)

        # 再展示文本框和标签
        self.play(
            Create(box),
            Write(label),
            run_time=1.0
        )

        # 逐行展示文本内容
        for line in text_lines:
            self.play(Write(line), run_time=0.8)

        # 简单的装饰元素：流线示意
        # 在文本左侧画几条简单的曲线代表流线，增加动感
        lines = VGroup()
        for i in range(3):
            curve = FunctionGraph(
                lambda x: 0.1 * np.sin(2 * x + i),
                x_range=[-2, 2],
                color=BLUE_C
            )
            curve.next_to(text_lines, DOWN, buff=0.5 + i*0.2)
            # 仅作为装饰，不需要太显眼
            lines.add(curve)

        # 稍微展示一下装饰线条
        self.play(Create(lines, lag_ratio=0.3), run_time=1.5)

        # 4. 停留
