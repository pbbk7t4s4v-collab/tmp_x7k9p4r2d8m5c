from manim import *

class CycloneStructure(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("气旋与反气旋结构对比",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("110", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心内容构建
        # ---------------------------------------------------------

        # 定义字体配置
        font_conf = {"font": "AR PL UKai CN"}

        # --- 左侧：气旋 (Cyclone) ---
        cyclone_center = Text("L", font_size=48, color=BLUE, weight=BOLD).shift(LEFT * 3.5 + UP * 0.5)
        cyclone_label = Text("气旋 (低压中心)", font_size=28, color=BLUE_A, **font_conf)
        cyclone_desc = Text("气流辐合上升\n多阴雨天气", font_size=24, color=WHITE, line_spacing=1.2, **font_conf)

        # 排版左侧文字
        cyclone_label.next_to(cyclone_center, DOWN, buff=1.5)
        cyclone_desc.next_to(cyclone_label, DOWN, buff=0.3)

        # 制作气旋箭头 (逆时针辐合) - 北半球
        c_arrows = VGroup()
        for i in range(4):
            # 简单的几何逻辑：从外向内指
            start_angle = i * PI / 2
            start_point = cyclone_center.get_center() + np.array([np.cos(start_angle)*1.5, np.sin(start_angle)*1.5, 0])
            end_point = cyclone_center.get_center() + np.array([np.cos(start_angle + PI/2)*0.6, np.sin(start_angle + PI/2)*0.6, 0])
            # 使用CurvedArrow模拟旋转气流
            arrow = CurvedArrow(start_point, end_point, angle=-TAU/5, color=BLUE_C)
            c_arrows.add(arrow)

        left_group = VGroup(cyclone_center, c_arrows, cyclone_label, cyclone_desc)

        # --- 右侧：反气旋 (Anticyclone) ---
        anticyclone_center = Text("H", font_size=48, color=RED, weight=BOLD).shift(RIGHT * 3.5 + UP * 0.5)
        anticyclone_label = Text("反气旋 (高压中心)", font_size=28, color=RED_A, **font_conf)
        anticyclone_desc = Text("气流辐散下沉\n多晴朗天气", font_size=24, color=WHITE, line_spacing=1.2, **font_conf)

        # 排版右侧文字
        anticyclone_label.next_to(anticyclone_center, DOWN, buff=1.5)
        anticyclone_desc.next_to(anticyclone_label, DOWN, buff=0.3)

        # 制作反气旋箭头 (顺时针辐散) - 北半球
        ac_arrows = VGroup()
        for i in range(4):
            # 从内向外指
            start_angle = i * PI / 2
            # 起点靠近中心
            start_point = anticyclone_center.get_center() + np.array([np.cos(start_angle)*0.6, np.sin(start_angle)*0.6, 0])
            # 终点远离中心，顺时针偏转
            end_point = anticyclone_center.get_center() + np.array([np.cos(start_angle - PI/2)*1.5, np.sin(start_angle - PI/2)*1.5, 0])

            arrow = CurvedArrow(start_point, end_point, angle=TAU/5, color=RED_C)
            ac_arrows.add(arrow)

        right_group = VGroup(anticyclone_center, ac_arrows, anticyclone_label, anticyclone_desc)

        # --- 装饰框 ---
        # 为描述文字添加边框，强调对比
        desc_box_left = SurroundingRectangle(cyclone_desc, color=BLUE, buff=0.15, stroke_width=2)
        desc_box_right = SurroundingRectangle(anticyclone_desc, color=RED, buff=0.15, stroke_width=2)

        # ---------------------------------------------------------
        # 3. 动画演示 (控制在15秒以内)
        # ---------------------------------------------------------

        # 1. 显示中心气压标识 (L 和 H)
        self.play(
            FadeIn(cyclone_center, shift=DOWN),
            FadeIn(anticyclone_center, shift=DOWN),
            run_time=1
        )

        # 2. 绘制气流箭头 (核心概念可视化)
        self.play(
            Create(c_arrows),
            Create(ac_arrows),
            run_time=1.5
        )

        # 3. 显示名称标签
        self.play(
            Write(cyclone_label),
            Write(anticyclone_label),
            run_time=1
        )

        # 4. 显示天气特征和边框
        self.play(
            FadeIn(cyclone_desc),
            Create(desc_box_left),
            FadeIn(anticyclone_desc),
            Create(desc_box_right),
            run_time=1.5
        )

        # 5. 简单的循环强调动画 (让箭头动一下表示气流)
        self.play(
            c_arrows.animate.scale(1.1).set_color(BLUE),
            ac_arrows.animate.scale(1.1).set_color(RED),
            rate_func=there_and_back,
            run_time=1
        )
