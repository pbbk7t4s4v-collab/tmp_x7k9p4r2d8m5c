from manim import *

class ImageRecognitionRise(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("图片识别的兴起",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧内容:趋势图表 (展示错误率下降/准确率上升)
        # 创建坐标轴
        axes = Axes(
            x_range=[2010, 2018, 2],
            y_range=[0, 30, 10],
            x_length=5,
            y_length=4,
            axis_config={"include_tip": True, "color": GREY},
            tips=False
        ).to_edge(LEFT, buff=1).shift(DOWN * 0.5)

        # 手动添加中文坐标标签,避免LaTeX字体问题
        x_label = Text("年份", font="AR PL UKai CN", font_size=20).next_to(axes.x_axis.get_end(), DOWN)
        y_label = Text("错误率 (%)", font="AR PL UKai CN", font_size=20).next_to(axes.y_axis.get_end(), UP).shift(LEFT*0.5)

        # 绘制曲线:模拟 ImageNet 错误率下降
        # 2010-2012 (传统方法瓶颈) -> 2012 (AlexNet转折) -> 2017 (超越人类)
        curve = axes.plot(lambda x: 28 if x < 2012 else 28 * (0.6 ** (x - 2012)),
                          x_range=[2010, 2017], color=BLUE_C)

        # 关键节点标注
        dot_2012 = Dot(axes.c2p(2012, 28), color=RED)
        label_2012 = Text("2012: AlexNet爆发", font="AR PL UKai CN", font_size=18, color=RED).next_to(dot_2012, UP+RIGHT, buff=0.1)

        graph_group = VGroup(axes, x_label, y_label, curve, dot_2012, label_2012)

        # 3. 右侧内容:核心驱动因素
        # 使用 VGroup 排版文字
        factor_title = Text("核心驱动因素", font="AR PL UKai CN", font_size=28, color=YELLOW)

        # 列表项
        factors = VGroup(
            Text("1. 大数据 (ImageNet)", font="AR PL UKai CN", font_size=24),
            Text("2. 算力提升 (GPU)", font="AR PL UKai CN", font_size=24),
            Text("3. 深度卷积网络 (CNN)", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.4)

        right_content = VGroup(factor_title, factors).arrange(DOWN, aligned_edge=LEFT, buff=0.5)
        right_content.next_to(axes, RIGHT, buff=1.5).shift(UP * 0.5)

        # 外框强调
        box = SurroundingRectangle(right_content, color=BLUE, buff=0.3)

        # 4. 动画流程 (总时长控制在15秒内)

        # 显示坐标系
        self.play(Create(axes), Write(x_label), Write(y_label), run_time=1.5)

        # 绘制曲线和关键点
        self.play(Create(curve, run_time=2), FadeIn(dot_2012, scale=0.5), Write(label_2012))

        # 显示右侧文字和框
        self.play(
            FadeIn(factor_title, shift=UP),
            Create(box),
            run_time=1
        )

        # 逐条显示原因
        for item in factors:
            self.play(Write(item), run_time=0.8)
