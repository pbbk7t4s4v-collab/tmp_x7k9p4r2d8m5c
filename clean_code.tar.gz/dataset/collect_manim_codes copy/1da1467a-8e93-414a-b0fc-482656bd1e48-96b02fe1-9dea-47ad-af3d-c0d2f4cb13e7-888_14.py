from manim import *

class IOAndStorageStructure(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("输入输出流向与存储网络",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("14", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 数据流向部分 (5.4)
        # 概念：物理信号 -> 数字信号 -> 内存
        flow_label = Text("数据转化路径", font_size=24, font="AR PL UKai CN", color=BLUE).next_to(title_line, DOWN, buff=0.3)

        step1 = Text("物理信号", font_size=20, font="AR PL UKai CN", color=GREY_A)
        arrow1 = MathTex(r"\rightarrow", color=WHITE)
        step2 = Text("数字信号", font_size=20, font="AR PL UKai CN", color=YELLOW)
        arrow2 = MathTex(r"\rightarrow", color=WHITE)
        step3 = Text("内存(RAM)", font_size=20, font="AR PL UKai CN", color=GREEN)

        flow_group = VGroup(step1, arrow1, step2, arrow2, step3).arrange(RIGHT, buff=0.2)
        flow_group.next_to(flow_label, DOWN, buff=0.2)

        flow_box = SurroundingRectangle(flow_group, color=BLUE, buff=0.15, stroke_width=2)

        self.play(FadeIn(flow_label), Create(flow_box))
        self.play(Write(flow_group), run_time=2)

        # 3. 存储设备持久化 (5.5)
        # 左侧展示存储对比

        # 图片1：存储硬件对比
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/1da1467a-8e93-414a-b0fc-482656bd1e48/96b02fe1-9dea-47ad-af3d-c0d2f4cb13e7/pictures/888_14/1.png") # 这里期望是一张展示计算机存储硬件的对比图。画面左侧是一条绿色的计算机内存条（RAM），画面右侧是一个金属外壳的机械硬盘或固态硬盘。风格为写实科技插画风，背景为纯白或淡灰色，用于直观区分易失性与非易失性存储设备。
        img1.height = 2.5 # 控制图片高度，避免过大
        img1.to_edge(LEFT, buff=1).shift(DOWN * 1)

        storage_title = Text("存储特性对比", font_size=24, font="AR PL UKai CN", color=ORANGE)
        storage_title.next_to(img1, UP, buff=0.2)

        # 文本描述
        ram_text = Text("RAM: 易失性 (掉电丢失)", font_size=18, font="AR PL UKai CN", color=RED_B)
        disk_text = Text("Disk: 持久化 (文件载体)", font_size=18, font="AR PL UKai CN", color=GREEN_B)
        storage_desc = VGroup(ram_text, disk_text).arrange(DOWN, buff=0.15, aligned_edge=LEFT)
        storage_desc.next_to(img1, RIGHT, buff=0.3)

        self.play(FadeIn(img1), Write(storage_title))
        self.play(Write(storage_desc))

        # 4. 网络通信设备 (5.6)
        # 右侧展示网络与云端

        # 图片2：云计算与集群
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/1da1467a-8e93-414a-b0fc-482656bd1e48/96b02fe1-9dea-47ad-af3d-c0d2f4cb13e7/pictures/888_14/2.png") # 这里期望是一张表现云计算与服务器集群的图片。画面展示排列整齐的服务器机柜，或者抽象的云端数据中心，无数光线代表数据在节点间流动。风格为蓝色调的科幻风，体现分布式系统和网络通信的宏大感。
        img2.height = 2.5 # 保持比例一致
        img2.to_edge(RIGHT, buff=1).align_to(img1, UP) # 与左侧图片对齐

        net_title = Text("网络与分布式", font_size=24, font="AR PL UKai CN", color=ORANGE)
        net_title.next_to(img2, UP, buff=0.2)

        # 文本描述
        nic_text = Text("网卡: 特殊I/O设备", font_size=18, font="AR PL UKai CN", color=BLUE_B)
        cloud_text = Text("连接云端与集群", font_size=18, font="AR PL UKai CN", color=BLUE_B)
        net_desc = VGroup(nic_text, cloud_text).arrange(DOWN, buff=0.15, aligned_edge=RIGHT)
        net_desc.next_to(img2, LEFT, buff=0.3) # 放在图片左侧以免出画

        self.play(FadeIn(img2), Write(net_title))
        self.play(Write(net_desc))

        # 5. 总结停留
