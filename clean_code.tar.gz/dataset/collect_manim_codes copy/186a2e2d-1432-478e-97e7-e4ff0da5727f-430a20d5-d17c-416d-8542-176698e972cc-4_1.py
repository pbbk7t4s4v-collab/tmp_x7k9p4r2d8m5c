from manim import *

class AIKnowledgeTreeStructure(Scene):
    def construct(self):

        # 1. Title setup (using the provided template)
        title = Text("The Core Knowledge Tree of AI",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # Bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Combine title elements
        title_group = VGroup(title, title_line)

        # Title animation
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Image setup (The Knowledge Tree)
        # Placing the tree on the right side to allow text on the left
        tree_img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/186a2e2d-1432-478e-97e7-e4ff0da5727f/430a20d5-d17c-416d-8542-176698e972cc/pictures/4_1/1.png") # An image showing a conceptual illustration of a large 'Knowledge Tree' with deep, prominent roots and a flourishing canopy is expected, with the roots symbolizing foundational disciplines like Mathematics and Psychology, in a modern flat vector art style.

        # Resize and position the image to ensure it fits well and doesn't overlap
        tree_img.height = 5.0  # Set a reasonable height
        tree_img.to_edge(RIGHT, buff=1.0)
        tree_img.shift(DOWN * 0.3) # Shift slightly down to clear title area

        # 3. Text content (The Roots/Foundations)
        # Header for the list
        list_header = Text("Foundations (Roots)", font_size=28, color=YELLOW, weight=BOLD)

        # Bulleted list for disciplines
        # Note: Avoid using LaTeX '&' or complex alignment inside BulletedList to prevent errors
        disciplines = BulletedList(
            "Mathematics",
            "Cybernetics",
            "Computer Engineering",
            "Psychology",
            "Neurophysiology",
            font_size=24,
            buff=0.25
        )

        # Group header and list
        text_group = VGroup(list_header, disciplines)
        text_group.arrange(DOWN, aligned_edge=LEFT, buff=0.3)

        # Position text group to the left of the image
        text_group.next_to(tree_img, LEFT, buff=0.8)
        # Ensure it doesn't go off screen left
        if text_group.get_left()[0] < -7:
            text_group.to_edge(LEFT, buff=0.5)

        # 4. Visual connectors
        # A rectangle to highlight the foundational disciplines
        rect = SurroundingRectangle(disciplines, color=BLUE, buff=0.15)

        # An arrow pointing from the text to the roots of the tree
        # Assuming roots are at the bottom of the image
        arrow = Arrow(
            start=rect.get_right(),
            end=tree_img.get_bottom() + UP * 0.5,
            color=BLUE,
            buff=0.1
        )

        # 5. Animation Sequence
        # Fade in the tree image
        self.play(FadeIn(tree_img, shift=LEFT), run_time=1.0)

        # Write the text content
        self.play(
            FadeIn(list_header, shift=UP),
            Write(disciplines),
            run_time=1.5
        )

        # Show the highlight box and arrow connecting to the tree roots
        self.play(
            Create(rect),
            GrowArrow(arrow),
            run_time=1.0
        )

        # Hold the final scene
