from manim import *

class TheoryExperienceDialogue(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (标准模板)
        # ---------------------------------------------------------
        title = Text("理论与经验的对话机制",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("62", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念：理论与经验的循环 (左右布局)
        # ---------------------------------------------------------
        # 定义核心节点
        theory_text = Text("理论", font="AR PL UKai CN", font_size=40, color=BLUE_A)
        theory_rect = SurroundingRectangle(theory_text, color=BLUE, buff=0.4, corner_radius=0.2)
        theory_group = VGroup(theory_rect, theory_text).move_to(LEFT * 3 + UP * 0.5)

        exp_text = Text("经验", font="AR PL UKai CN", font_size=40, color=GREEN_A)
        exp_rect = SurroundingRectangle(exp_text, color=GREEN, buff=0.4, corner_radius=0.2)
        exp_group = VGroup(exp_rect, exp_text).move_to(RIGHT * 3 + UP * 0.5)

        # 进场动画
        self.play(
            FadeIn(theory_group, shift=RIGHT),
            FadeIn(exp_group, shift=LEFT),
            run_time=1.0
        )

        # ---------------------------------------------------------
        # 3. 对话机制 (弯曲箭头与解释文字)
        # ---------------------------------------------------------
        # 上方箭头：理论 -> 经验
        arrow_top = CurvedArrow(
            start_point=theory_rect.get_top(),
            end_point=exp_rect.get_top(),
            angle=-TAU/4,
            color=YELLOW
        )
        label_top = Text("指引观察 / 识别变量 / 提出假设", font="AR PL UKai CN", font_size=24, color=YELLOW_A)
        label_top.next_to(arrow_top, UP, buff=0.1)

        # 下方箭头：经验 -> 理论
        arrow_bottom = CurvedArrow(
            start_point=exp_rect.get_bottom(),
            end_point=theory_rect.get_bottom(),
            angle=-TAU/4,
            color=YELLOW
        )
        label_bottom = Text("证实证伪 / 修正拓展 / 复杂化", font="AR PL UKai CN", font_size=24, color=YELLOW_A)
        label_bottom.next_to(arrow_bottom, DOWN, buff=0.1)

        # 绘制循环过程
        self.play(
            Create(arrow_top),
            Write(label_top),
            run_time=1.5
        )
        self.play(
            Create(arrow_bottom),
            Write(label_bottom),
            run_time=1.5
        )

        # ---------------------------------------------------------
        # 4. 底部流程：研究阶段展示
        # ---------------------------------------------------------
        # 简单的方块流程图展示三个阶段
        step1 = Text("1.研究设计", font="AR PL UKai CN", font_size=22, color=GRAY_A)
        step2 = Text("2.数据收集", font="AR PL UKai CN", font_size=22, color=GRAY_A)
        step3 = Text("3.结论阐释", font="AR PL UKai CN", font_size=22, color=GRAY_A)

        steps = VGroup(step1, step2, step3).arrange(RIGHT, buff=2.0)
        steps.to_edge(DOWN, buff=1.0)

        # 连接箭头的辅助函数
        arrow1 = Arrow(start=step1.get_right(), end=step2.get_left(), buff=0.2, color=GRAY, max_tip_length_to_length_ratio=0.15)
        arrow2 = Arrow(start=step2.get_right(), end=step3.get_left(), buff=0.2, color=GRAY, max_tip_length_to_length_ratio=0.15)

        # 底部标题
        process_label = Text("知识生产的基本机制：", font="AR PL UKai CN", font_size=24, color=WHITE)
        process_label.next_to(steps, UP, buff=0.4).align_to(steps, LEFT)

        self.play(
            FadeIn(process_label),
            FadeIn(steps, shift=UP),
            Create(arrow1),
            Create(arrow2),
            run_time=1.5
        )

        # ---------------------------------------------------------
        # 5. 结尾停顿
        # ---------------------------------------------------------
