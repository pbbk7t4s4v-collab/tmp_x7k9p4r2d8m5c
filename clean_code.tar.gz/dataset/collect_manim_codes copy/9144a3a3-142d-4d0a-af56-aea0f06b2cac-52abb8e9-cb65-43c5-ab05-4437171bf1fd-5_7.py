from manim import *

class MaterialMicrostructureConvolution(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (符合模板要求)
        # ---------------------------------------------------------
        title = Text("材料微观结构分析中的多通道卷积",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("24", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容可视化设计
        # ---------------------------------------------------------

        # 定义通用字体配置
        text_font = "AR PL UKai CN"

        # --- 左侧:输入通道 (3个通道) ---
        # 使用三个正方形叠加模拟"通道"
        input_sq1 = Square(side_length=1.8, color=BLUE, fill_opacity=0.3).set_fill(BLUE)
        input_sq2 = Square(side_length=1.8, color=GREEN, fill_opacity=0.3).set_fill(GREEN).shift(UP*0.2 + RIGHT*0.2)
        input_sq3 = Square(side_length=1.8, color=RED, fill_opacity=0.3).set_fill(RED).shift(UP*0.4 + RIGHT*0.4)

        input_stack = VGroup(input_sq1, input_sq2, input_sq3)
        input_stack.move_to(LEFT * 4)

        # 输入通道标签
        input_label_title = Text("输入 (3通道)", font=text_font, font_size=24, color=YELLOW).next_to(input_stack, UP, buff=0.3)

        # 详细列出三个通道名称
        input_texts = VGroup(
            Text("1. 原子序数对比度", font=text_font, font_size=18, color=BLUE_A),
            Text("2. 形貌高度", font=text_font, font_size=18, color=GREEN_A),
            Text("3. 晶粒取向", font=text_font, font_size=18, color=RED_A)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        input_texts.next_to(input_stack, DOWN, buff=0.4)

        # --- 中间:卷积操作 ---
        arrow = Arrow(start=LEFT, end=RIGHT, buff=0.5, color=WHITE).next_to(input_stack, RIGHT, buff=1.0)
        # 调整箭头长度
        arrow.scale(1.2)

        kernel_text = Text("卷积核学习特征", font=text_font, font_size=20, color=ORANGE)
        kernel_text.next_to(arrow, UP, buff=0.1)

        # --- 右侧:输出特征图 ---
        # 输出特征图堆叠
        output_sq1 = Square(side_length=1.5, color=GOLD, fill_opacity=0.4).set_fill(GOLD)
        output_sq2 = Square(side_length=1.5, color=PURPLE, fill_opacity=0.4).set_fill(PURPLE).shift(UP*0.2 + RIGHT*0.2)

        output_stack = VGroup(output_sq1, output_sq2)
        output_stack.next_to(arrow, RIGHT, buff=1.0)

        output_label_title = Text("输出特征图", font=text_font, font_size=24, color=YELLOW).next_to(output_stack, UP, buff=0.5)

        # 详细列出学习到的特征
        output_texts = VGroup(
            Text("• 检测晶界", font=text_font, font_size=18, color=GOLD_A),
            Text("• 检测位错", font=text_font, font_size=18, color=PURPLE_A)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        output_texts.next_to(output_stack, DOWN, buff=0.4)

        # ---------------------------------------------------------
        # 3. 动画演示流程
        # ---------------------------------------------------------

        # 第一步:展示输入数据
        self.play(
            FadeIn(input_stack, shift=UP),
            Write(input_label_title)
        )
        self.play(Write(input_texts), run_time=1.5)

        # 第二步:展示卷积过程
        self.play(
            GrowArrow(arrow),
            FadeIn(kernel_text, shift=DOWN)
        )

        # 第三步:展示输出结果
        self.play(
            FadeIn(output_stack, shift=LEFT),
            Write(output_label_title)
        )
        self.play(Write(output_texts), run_time=1.5)

        # 第四步:添加强调框
        # 将整个流程框起来,表示这是一个完整的分析单元
        full_group = VGroup(input_stack, input_texts, arrow, output_stack, output_texts, kernel_text, input_label_title, output_label_title)
        surround_rect = SurroundingRectangle(full_group, color=TEAL, buff=0.3)

        self.play(Create(surround_rect))

        # 停留片刻
