from manim import *

class RealLifeToExpression(Scene):
    def construct(self):

        # --- 1. 标题设置 (严格按照模板) ---
        title = Text("生活问题转化为数学表达式",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- 2. 内容布局设计 ---

        # 左侧：生活情境（以出租车计费为例,简单直观）
        scenario_title = Text("生活情境：出租车计费", font_size=24, font="AR PL UKai CN", color=BLUE)
        item1 = Text("• 起步价：10 元", font_size=20, font="AR PL UKai CN")
        item2 = Text("• 单价：3 元/公里", font_size=20, font="AR PL UKai CN")

        left_group = VGroup(scenario_title, item1, item2).arrange(DOWN, aligned_edge=LEFT, buff=0.3)

        # 中间：转化箭头
        arrow = Arrow(LEFT, RIGHT, color=YELLOW, buff=0.2)
        trans_text = Text("抽象化", font_size=16, font="AR PL UKai CN", color=YELLOW).next_to(arrow, UP, buff=0.05)
        arrow_group = VGroup(arrow, trans_text)

        # 右侧：数学表达式
        math_title = Text("数学模型 (表达式)", font_size=24, font="AR PL UKai CN", color=GREEN)
        expression = MathTex("y = 10 + 3x", font_size=36)
        # 变量说明
        var_expl = Text("y: 总费用,  x: 里程", font_size=18, font="AR PL UKai CN", color=GRAY)

        right_group = VGroup(math_title, expression, var_expl).arrange(DOWN, aligned_edge=ORIGIN, buff=0.3)

        # 组合主要内容区域
        main_content = VGroup(left_group, arrow_group, right_group).arrange(RIGHT, buff=0.8)
        main_content.move_to(ORIGIN).shift(UP * 0.5)

        # --- 3. 动画展示第一部分：建模 ---
        self.play(FadeIn(left_group, shift=RIGHT))
        self.play(
            GrowArrow(arrow),
            FadeIn(trans_text),
            FadeIn(right_group, shift=LEFT)
        )

        # --- 4. 底部：求解应用 ---
        solve_label = Text("应用求解：若行驶 5 公里？", font_size=22, font="AR PL UKai CN", color=ORANGE)

        # 分步展示代入过程
        # 这里的 & 是 LaTeX 对齐符号，MathTex 支持
        solve_step = MathTex("y = 10 + 3 \\times 5 = 25", font_size=32)

        solve_group = VGroup(solve_label, solve_step).arrange(DOWN, buff=0.2)
        solve_group.next_to(main_content, DOWN, buff=0.8)

        # 添加强调框
        box = SurroundingRectangle(solve_group, color=WHITE, buff=0.2, corner_radius=0.1)

        # --- 5. 动画展示第二部分：求解 ---
        self.play(Write(solve_label))
        self.play(Write(solve_step))
        self.play(Create(box))
