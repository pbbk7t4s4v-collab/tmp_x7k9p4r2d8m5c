from manim import *

class GrainBoundaryDetection(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("材料应用设计:晶粒边界识别",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("31", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心内容展示:图像与卷积核
        # 创建模拟的金属微观图像数据(左侧高亮,右侧低亮,模拟边缘)
        image_data = [
            [10, 10, 2],
            [10, 10, 2],
            [10, 10, 2]
        ]

        # 创建垂直边缘检测核数据
        kernel_data = [
            [1, 0, -1],
            [1, 0, -1],
            [1, 0, -1]
        ]

        # 实例化矩阵对象
        matrix_img = IntegerMatrix(image_data, include_background_rectangle=True)
        matrix_kernel = IntegerMatrix(kernel_data, include_background_rectangle=True)

        # 设置矩阵样式
        matrix_img.scale(0.7)
        matrix_kernel.scale(0.7)

        # 添加标签
        label_img = Text("金属微观图像片段", font="AR PL UKai CN", font_size=24, color=BLUE).next_to(matrix_img, UP)
        label_kernel = Text("3x3 边缘检测核", font="AR PL UKai CN", font_size=24, color=YELLOW).next_to(matrix_kernel, UP)

        # 组合并布局
        group_img = VGroup(label_img, matrix_img)
        group_kernel = VGroup(label_kernel, matrix_kernel)

        # 运算符号
        conv_symbol = MathTex(r"\ast", font_size=60).set_color(WHITE)

        # 整体水平排列
        main_group = VGroup(group_img, conv_symbol, group_kernel).arrange(RIGHT, buff=1.0)
        main_group.move_to(ORIGIN).shift(UP * 0.5)

        # 播放入场动画
        self.play(FadeIn(main_group))

        # 3. 解释权重设计
        # 获取卷积核的列来展示正负权重
        # 注意:IntegerMatrix.get_columns() 返回的是 VGroup 列表
        k_cols = matrix_kernel.get_columns()

        rect_pos = SurroundingRectangle(k_cols[0], color=GREEN, buff=0.1) # 正权重
        rect_neg = SurroundingRectangle(k_cols[2], color=RED, buff=0.1)   # 负权重

        # 解释文本
        explanation_1 = Text("正权重(+1) 感知左侧", font="AR PL UKai CN", font_size=20, color=GREEN)
        explanation_2 = Text("负权重(-1) 感知右侧", font="AR PL UKai CN", font_size=20, color=RED)

        explanation_1.next_to(rect_pos, DOWN, buff=0.2)
        explanation_2.next_to(rect_neg, DOWN, buff=0.2)

        self.play(
            Create(rect_pos),
            Create(rect_neg),
            FadeIn(explanation_1),
            FadeIn(explanation_2)
        )

        # 4. 总结原理
        # 底部结论框
        conclusion_text = Text(
            "原理:利用差分计算,当左右像素值差异大时输出高响应(检测到晶界)",
            font="AR PL UKai CN",
            font_size=26,
            color=ORANGE
        )
        conclusion_text.to_edge(DOWN, buff=1.0)

        # 简单的箭头指引
        arrow = Arrow(start=matrix_kernel.get_bottom(), end=conclusion_text.get_top(), buff=0.1, color=WHITE)

        self.play(
            GrowArrow(arrow),
            Write(conclusion_text)
        )
