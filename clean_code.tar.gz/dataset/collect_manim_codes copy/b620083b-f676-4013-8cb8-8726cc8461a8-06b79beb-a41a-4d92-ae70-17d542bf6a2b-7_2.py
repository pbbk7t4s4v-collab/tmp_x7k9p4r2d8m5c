from manim import *

class TreeRecursionConcept(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("树的递归性质与算法设计",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("35", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 左侧:树形结构可视化
        # ---------------------------------------------------------
        # 定义节点位置
        root_pos = LEFT * 3.5 + UP * 1.5
        l_pos    = root_pos + LEFT * 1.5 + DOWN * 1.5
        r_pos    = root_pos + RIGHT * 1.5 + DOWN * 1.5
        ll_pos   = l_pos + LEFT * 0.8 + DOWN * 1.2
        lr_pos   = l_pos + RIGHT * 0.8 + DOWN * 1.2

        # 创建节点辅助函数
        def create_node(pos, text=""):
            circle = Circle(radius=0.35, color=BLUE_B, fill_opacity=0.8, fill_color=BLUE_E)
            label = Text(text, font_size=20, font="AR PL UKai CN", color=WHITE).move_to(circle)
            return VGroup(circle, label)

        # 构建节点
        node_root = create_node(root_pos, "根")
        node_l    = create_node(l_pos, "子")
        node_r    = create_node(r_pos, "子")
        node_ll   = create_node(ll_pos)
        node_lr   = create_node(lr_pos)

        # 构建连线
        line_l  = Line(node_root.get_center(), node_l.get_center(), color=GREY)
        line_r  = Line(node_root.get_center(), node_r.get_center(), color=GREY)
        line_ll = Line(node_l.get_center(), node_ll.get_center(), color=GREY)
        line_lr = Line(node_l.get_center(), node_lr.get_center(), color=GREY)

        # 组合树结构
        # 注意绘制顺序:先画线,再画点,避免线遮挡点中的文字
        tree_edges = VGroup(line_l, line_r, line_ll, line_lr)
        tree_nodes = VGroup(node_root, node_l, node_r, node_ll, node_lr)
        full_tree = VGroup(tree_edges, tree_nodes)

        # ---------------------------------------------------------
        # 3. 右侧:概念解释文本
        # ---------------------------------------------------------
        text_origin = UP * 1.5 + RIGHT * 0.5

        # 概念点 1
        p1_title = Text("1. 结构自相似性", font_size=28, color=YELLOW, font="AR PL UKai CN")
        p1_title.move_to(text_origin, aligned_edge=LEFT)

        p1_desc = Text("子树也是树,具备完全相同的结构定义",
                       font_size=22, color=WHITE, font="AR PL UKai CN")
        p1_desc.next_to(p1_title, DOWN, aligned_edge=LEFT, buff=0.15)

        # 概念点 2
        p2_title = Text("2. 递归算法的基础", font_size=28, color=YELLOW, font="AR PL UKai CN")
        p2_title.next_to(p1_desc, DOWN, aligned_edge=LEFT, buff=0.6)

        p2_desc = Text("用相同的逻辑处理更小规模的问题",
                       font_size=22, color=WHITE, font="AR PL UKai CN")
        p2_desc.next_to(p2_title, DOWN, aligned_edge=LEFT, buff=0.15)

        # 逻辑公式
        logic_tex = MathTex(r"\text{Solve}(Tree) \rightarrow \text{Solve}(SubTree)", font_size=32)
        logic_tex.next_to(p2_desc, DOWN, buff=0.5, aligned_edge=LEFT)

        # ---------------------------------------------------------
        # 4. 动画流程
        # ---------------------------------------------------------

        # 步骤 1: 展示树和第一个概念
        self.play(FadeIn(full_tree, shift=UP), run_time=1)
        self.play(Write(p1_title), FadeIn(p1_desc), run_time=1)

        # 步骤 2: 强调全树 (原问题)
        rect_whole = SurroundingRectangle(full_tree, color=GREEN, buff=0.2)
        label_whole = Text("原问题 (Tree)", font_size=24, color=GREEN, font="AR PL UKai CN")
        label_whole.next_to(rect_whole, UP)

        self.play(Create(rect_whole), Write(label_whole), run_time=0.8)

        # 步骤 3: 聚焦子树 (子问题) - 视觉上的递归体现
        # 定义左子树组
        subtree_group = VGroup(node_l, node_ll, node_lr, line_ll, line_lr)

        rect_sub = SurroundingRectangle(subtree_group, color=RED, buff=0.15)
        label_sub = Text("子问题 (SubTree)", font_size=24, color=RED, font="AR PL UKai CN")
        label_sub.next_to(rect_sub, LEFT)

        self.play(
            ReplacementTransform(rect_whole, rect_sub),
            ReplacementTransform(label_whole, label_sub),
            run_time=1
        )

        # 步骤 4: 展示结论与逻辑映射
        self.play(Write(p2_title), FadeIn(p2_desc), run_time=1)
        self.play(Write(logic_tex), run_time=1)
