from manim import *

class CNNBasicConcepts(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("卷积神经网络:基本概念",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 主要定义文本
        # 介绍CNN是处理网格数据的模型
        definition = Text(
            "专门处理具有类似网格结构数据(如图像)的神经网络",
            font="AR PL UKai CN",
            font_size=24,
            color=BLUE_B
        ).next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(definition, shift=DOWN))

        # 3. 可视化部分:展示图像网格和卷积核
        # 左侧:模拟像素网格
        grid_size = 0.6
        input_grid = VGroup()
        for i in range(5):
            for j in range(5):
                sq = Square(side_length=grid_size, stroke_color=WHITE, stroke_width=1.5, fill_opacity=0.1)
                sq.move_to(np.array([j * grid_size, -i * grid_size, 0]))
                input_grid.add(sq)

        input_grid.move_to(LEFT * 3.5 + DOWN * 0.5)

        input_label = Text("输入图像 (Pixel Grid)", font="AR PL UKai CN", font_size=20, color=GRAY)
        input_label.next_to(input_grid, DOWN, buff=0.2)

        # 模拟卷积核 (3x3 红色框)
        kernel_size = grid_size * 3
        kernel_rect = Square(side_length=kernel_size, color=YELLOW, stroke_width=4)
        # 将卷积核对齐到左上角
        kernel_rect.move_to(input_grid[0].get_center() + np.array([grid_size, -grid_size, 0]))

        kernel_label = Text("卷积核 / 过滤器", font="AR PL UKai CN", font_size=20, color=YELLOW)
        kernel_label.next_to(kernel_rect, UP, buff=0.2)

        visual_group = VGroup(input_grid, input_label, kernel_rect, kernel_label)

        # 4. 右侧:核心特性列表
        # 使用 Text 自行构造带圆点的列表,避免 LaTeX 依赖
        bullet_texts = [
            "核心层级:卷积层、池化层、全连接层",
            "局部感知 (Local Connectivity)",
            "权值共享 (Parameter Sharing)",
            "自动提取图像特征",
        ]
        bullet_points = VGroup(
            *[Text(f"• {t}", font="AR PL UKai CN", font_size=24) for t in bullet_texts]
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        bullet_points.set_color(WHITE)
        bullet_points.next_to(visual_group, RIGHT, buff=1.5)
        bullet_points.align_to(title_line, UP).shift(DOWN * 1.5)

        # 5. 动画展示流程

        # 展示左侧网格
        self.play(Create(input_grid), FadeIn(input_label))

        # 展示卷积核概念
        self.play(Create(kernel_rect), FadeIn(kernel_label))

        # 简单的滑动动画模拟卷积操作
        self.play(
            kernel_rect.animate.shift(RIGHT * grid_size),
            run_time=1.0
        )

        # 展示右侧核心概念列表
        for item in bullet_points:
            self.play(FadeIn(item, shift=LEFT), run_time=0.6)

        # 6. 强调核心 (使用SurroundingRectangle)
        highlight_rect = SurroundingRectangle(bullet_points[2], color=ORANGE, buff=0.1)
        highlight_text = Text("减少参数数量的关键", font="AR PL UKai CN", font_size=18, color=ORANGE)
        highlight_text.next_to(highlight_rect, RIGHT, buff=0.2)

        self.play(
            Create(highlight_rect),
            Write(highlight_text)
        )
