from manim import *
import numpy as np

class SoftwareProjectFeatures(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板要求)
        title = Text("软件项目的五大特征",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("20", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念:软件项目 (中心节点)
        center_text = Text("软件项目", font="AR PL UKai CN", font_size=36, color=WHITE)
        center_rect = SurroundingRectangle(center_text, color=BLUE, buff=0.3, stroke_width=4)
        center_group = VGroup(center_text, center_rect)
        center_group.move_to(ORIGIN).shift(DOWN * 0.3) # 稍微下移,避开标题

        self.play(FadeIn(center_group, scale=0.5), run_time=1)

        # 3. 周围特征节点配置
        features = [
            "逻辑实体",       # Top
            "独特性",         # Top Right
            "高度复杂性",     # Bottom Right
            "人的特点",       # Bottom Left
            "不确定性"        # Top Left
        ]

        # 使用不同的颜色区分
        colors = [TEAL, GREEN, GOLD, RED_C, PURPLE]

        # 布局参数
        radius_x = 4.5
        radius_y = 2.2
        feature_groups = VGroup()
        lines = VGroup()

        # 计算位置并生成对象
        # 既然有5个点,我们按照椭圆分布,起始角度90度(上方)
        start_angle = 90 * DEGREES

        for i, (feature_text, color) in enumerate(zip(features, colors)):
            # 计算角度 (均匀分布)
            angle = start_angle - i * (360 / len(features)) * DEGREES

            # 椭圆坐标计算
            x_pos = radius_x * np.cos(angle)
            y_pos = radius_y * np.sin(angle)
            target_pos = center_group.get_center() + np.array([x_pos, y_pos, 0])

            # 创建文本
            txt = Text(feature_text, font="AR PL UKai CN", font_size=28, color=color)
            txt.move_to(target_pos)

            # 创建边框
            rect = SurroundingRectangle(txt, color=color, buff=0.15, stroke_width=2)

            # 组合节点
            node = VGroup(txt, rect)
            feature_groups.add(node)

            # 创建连线 (从中心框边缘到节点框边缘)
            # 简单的Line从中心到目标,然后用z_index控制遮挡,或者计算边缘
            line = Line(center_rect.get_center(), rect.get_center(), color=color, stroke_opacity=0.6)
            # 将线截断在矩形边缘(视觉优化)
            line.set_z_index(-1)
            lines.add(line)

        # 4. 动画展示
        # 依次展示每个特征,从上方开始顺时针
        for i in range(len(features)):
            self.play(
                Create(lines[i]),
                FadeIn(feature_groups[i], shift=lines[i].get_vector() * 0.2),
                run_time=0.8
            )
            if i == 0:
                pass
            elif i == 1:
                pass
            elif i == 2:
                pass
            elif i == 3:
                pass
            elif i == 4:
                pass

        # 5. 强调动画 (可选,保持在15秒内)
