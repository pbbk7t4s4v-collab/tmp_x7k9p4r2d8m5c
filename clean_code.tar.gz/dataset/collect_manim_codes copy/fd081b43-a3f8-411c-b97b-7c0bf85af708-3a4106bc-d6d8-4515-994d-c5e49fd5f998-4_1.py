from manim import *
import numpy as np

class IntegralAreaAccumulation(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("积分的面积累积图像：正弦函数示例",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 创建坐标系
        # 调整坐标系位置,避免与标题重叠
        axes = Axes(
            x_range=[-0.5, 7, 1],        # 0 到 2pi 约为 6.28
            y_range=[-1.5, 1.5, 0.5],
            x_length=9,
            y_length=4,
            axis_config={"include_tip": True, "tip_width": 0.2, "tip_height": 0.2},
            x_axis_config={"numbers_to_include": []}, # 自定义标签
            y_axis_config={"numbers_to_include": [1, -1]}
        ).shift(DOWN * 0.5)

        # 坐标轴标签
        x_label = axes.get_x_axis_label("x")
        y_label = axes.get_y_axis_label("f(x)")

        # 自定义 x 轴刻度标签 (pi 和 2pi)
        pi_pos = axes.coords_to_point(np.pi, 0)
        two_pi_pos = axes.coords_to_point(2 * np.pi, 0)

        pi_label = MathTex(r"\pi").next_to(pi_pos, DOWN, buff=0.2)
        two_pi_label = MathTex(r"2\pi").next_to(two_pi_pos, DOWN, buff=0.2)
        origin_label = MathTex("0").next_to(axes.coords_to_point(0, 0), DL, buff=0.1)

        # 3. 绘制正弦函数曲线
        graph = axes.plot(lambda x: np.sin(x), x_range=[0, 2 * np.pi], color=BLUE, stroke_width=4)

        # 函数公式展示
        formula = MathTex(r"f(x) = \sin x", color=BLUE)
        formula.to_corner(UR).shift(DOWN * 1.2 + LEFT * 1) # 放置在右上角

        # 文本说明
        desc_text = Text("区间: [0, 2π]", font="AR PL UKai CN", font_size=24).next_to(formula, DOWN, buff=0.2)

        # 强调框
        box = SurroundingRectangle(VGroup(formula, desc_text), color=YELLOW, buff=0.15)

        # 4. 面积区域 (积分累积效果)
        # 正半轴面积 (0 到 pi)
        area_pos = axes.get_area(
            graph,
            x_range=[0, np.pi],
            color=GREEN,
            opacity=0.5
        )

        # 负半轴面积 (pi 到 2pi)
        area_neg = axes.get_area(
            graph,
            x_range=[np.pi, 2 * np.pi],
            color=RED,
            opacity=0.5
        )

        # 5. 动画序列
        # 绘制坐标系和标签
        self.play(
            Create(axes),
            Write(x_label),
            Write(y_label),
            Write(origin_label),
            Write(pi_label),
            Write(two_pi_label),
            run_time=1.5
        )

        # 绘制函数曲线
        self.play(Create(graph), run_time=1.5)

        # 显示公式和强调框
        self.play(
            FadeIn(formula),
            Write(desc_text),
            Create(box),
            run_time=1
        )

        # 演示面积累积
        # 先累积正面积
        pos_label = Text("正累积", font="AR PL UKai CN", font_size=20, color=GREEN)
        pos_label.move_to(axes.c2p(np.pi/2, 0.5))

        self.play(
            Write(area_pos),
            FadeIn(pos_label),
            run_time=1.5
        )

        # 后累积负面积
        neg_label = Text("负累积", font="AR PL UKai CN", font_size=20, color=RED)
        neg_label.move_to(axes.c2p(3*np.pi/2, -0.5))

        self.play(
            Write(area_neg),
            FadeIn(neg_label),
            run_time=1.5
        )
