from manim import *

class ExplanationMethods(Scene):
    def construct(self):

        # 1. 标题设置 (严格遵循模板)
        title = Text("说明方法解析：列数字与举例子",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("20", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 定义通用样式
        header_font_size = 30
        body_font_size = 24

        # --- 第一部分：列数字 ---
        # 标题
        num_header = Text("1. 列数字", font="AR PL UKai CN", font_size=header_font_size, color=YELLOW)
        # 例子内容
        num_ex = Text("例子："直径三四厘米,重十余克到二十余克。"",
                     font="AR PL UKai CN", font_size=body_font_size)
        # 作用分析
        num_func = Text("作用：准确无误,体现语言的准确性,令人信服。",
                       font="AR PL UKai CN", font_size=body_font_size, color=LIGHT_GREY)

        # 组合第一部分
        group_num = VGroup(num_header, num_ex, num_func)
        group_num.arrange(DOWN, aligned_edge=LEFT, buff=0.25)

        # 添加边框
        rect_num = SurroundingRectangle(group_num, color=YELLOW, buff=0.2, corner_radius=0.1)

        # --- 第二部分：举例子 ---
        # 标题
        ex_header = Text("2. 举例子", font="AR PL UKai CN", font_size=header_font_size, color=BLUE)
        # 例子内容
        ex_content = Text("例子："南越王进贡"、"海南野生荔枝林"",
                         font="AR PL UKai CN", font_size=body_font_size)
        # 作用分析
        ex_func = Text("作用：提高文章可信度,增强说服力。",
                      font="AR PL UKai CN", font_size=body_font_size, color=LIGHT_GREY)

        # 组合第二部分
        group_ex = VGroup(ex_header, ex_content, ex_func)
        group_ex.arrange(DOWN, aligned_edge=LEFT, buff=0.25)

        # 添加边框
        rect_ex = SurroundingRectangle(group_ex, color=BLUE, buff=0.2, corner_radius=0.1)

        # 3. 整体位置调整
        # 将两个块组合以便居中
        content_group = VGroup(VGroup(rect_num, group_num), VGroup(rect_ex, group_ex))
        content_group.arrange(DOWN, buff=0.8)
        content_group.next_to(title_line, DOWN, buff=0.5)

        # 4. 动画展示
        # 展示列数字部分
        self.play(Create(rect_num), FadeIn(group_num, shift=UP), run_time=1.5)

        # 展示举例子部分
        self.play(Create(rect_ex), FadeIn(group_ex, shift=UP), run_time=1.5)

        # 强调关键词（简单的视觉引导）
        highlight_num = Underline(num_func, color=YELLOW)
        highlight_ex = Underline(ex_func, color=BLUE)

        self.play(Create(highlight_num), Create(highlight_ex))
