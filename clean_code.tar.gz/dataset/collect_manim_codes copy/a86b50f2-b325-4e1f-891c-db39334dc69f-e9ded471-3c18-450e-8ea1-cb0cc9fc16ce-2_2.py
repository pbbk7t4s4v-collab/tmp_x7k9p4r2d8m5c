from manim import *

class SmartGridDevelopmentNeeds(Scene):
    def construct(self):

        # 1. 标题部分
        title = Text("智能电网发展挑战与5G机遇",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧内容：智能电网全景与四大需求
        # 图片 1
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/a86b50f2-b325-4e1f-891c-db39334dc69f/e9ded471-3c18-450e-8ea1-cb0cc9fc16ce/pictures/2_2/1.png") # 一张扁平化科技风格的智能电网全景示意图。画面左侧展示风力发电机和太阳能光伏板（代表清洁发电），中间通过高压输电铁塔连接（代表输变电），右侧延伸至城市高楼和居民住宅（代表配电与用电）。整体色调采用科技蓝和绿色，背景简洁明亮，写实风

        # 调整图片大小和位置 (保持1:1比例的视觉占用，虽然原图可能不是)
        img1.height = 3.0
        img1.to_edge(LEFT, buff=1.0).shift(UP * 0.5)

        # 四大需求文本
        needs_text_1 = Text("清洁友好发电", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        needs_text_2 = Text("安全高效输变电", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        needs_text_3 = Text("灵活可靠配电", font="AR PL UKai CN", font_size=24, color=YELLOW) # 重点标黄
        needs_text_4 = Text("多样互动用电", font="AR PL UKai CN", font_size=24, color=BLUE_B)

        needs_group = VGroup(needs_text_1, needs_text_2, needs_text_3, needs_text_4)
        needs_group.arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        needs_group.next_to(img1, DOWN, buff=0.5)

        # 3. 右侧内容：配电侧挑战与5G解决方案
        # 挑战描述
        challenge_title = Text("配电侧挑战：", font="AR PL UKai CN", font_size=28, color=RED)
        challenge_desc = Text("末端通信难，光纤覆盖不足", font="AR PL UKai CN", font_size=24, color=WHITE)

        challenge_group = VGroup(challenge_title, challenge_desc)
        challenge_group.arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        challenge_group.to_edge(RIGHT, buff=1.5).shift(UP * 1.5)

        # 图片 2
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/a86b50f2-b325-4e1f-891c-db39334dc69f/e9ded471-3c18-450e-8ea1-cb0cc9fc16ce/pictures/2_2/2.png") # 一张展示5G基站解决配电网通信难题的插画。画面中心是一座现代化的5G信号塔，正在向周围发射信号波。画面下方是分布式的电力设施，如带有屋顶光伏的房屋和路边的智能配电箱，暗示无线信号正在覆盖光纤难以到达的末端区域，写实风

        img2.height = 3.0
        img2.next_to(challenge_group, DOWN, buff=0.5)

        # 解决方案描述
        solution_text = Text("5G优势：高带宽、低时延、广覆盖", font="AR PL UKai CN", font_size=24, color=GREEN)
        solution_text.next_to(img2, DOWN, buff=0.3)

        # 4. 动画流程展示

        # 展示左侧：全景图与需求
        self.play(FadeIn(img1, shift=RIGHT))
        self.play(Write(needs_group, run_time=2))

        # 强调"灵活可靠配电"
        rect = SurroundingRectangle(needs_text_3, color=YELLOW, buff=0.1)
        self.play(Create(rect))

        # 箭头过渡到右侧
        arrow = Arrow(start=rect.get_right(), end=challenge_group.get_left(), color=YELLOW)
        self.play(GrowArrow(arrow))

        # 展示右侧：挑战与5G方案
        self.play(Write(challenge_group))
        self.play(FadeIn(img2, shift=UP))
        self.play(Write(solution_text))
