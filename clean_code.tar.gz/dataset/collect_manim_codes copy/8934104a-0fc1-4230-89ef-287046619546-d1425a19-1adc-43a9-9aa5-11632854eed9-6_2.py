from manim import *

class PolicyBasedMethodScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (符合模板要求)
        # ---------------------------------------------------------
        title = Text("强化学习：基于策略的方法",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("23", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念展示 (左侧文本)
        # ---------------------------------------------------------
        # 文本描述
        desc_text = Text("直接对策略函数进行建模", font="AR PL UKai CN", font_size=28)
        desc_text.to_edge(LEFT, buff=1.0).shift(UP * 1.0)

        # 核心公式
        # 使用 MathTex 展示 pi(a|s)
        formula = MathTex(r"\pi(a|s) = P(a_t=a | s_t=s)", font_size=36, color=BLUE_A)
        formula.next_to(desc_text, DOWN, buff=0.5).align_to(desc_text, LEFT)

        # 公式解释
        formula_explain = Text("输入状态 s，直接输出动作概率分布",
                             font="AR PL UKai CN",
                             font_size=22,
                             color=GRAY)
        formula_explain.next_to(formula, DOWN, buff=0.3).align_to(desc_text, LEFT)

        left_content = VGroup(desc_text, formula, formula_explain)

        # ---------------------------------------------------------
        # 3. 算法可视化流程图 (右侧图示)
        # ---------------------------------------------------------
        # 状态节点 (圆形)
        state_circle = Circle(radius=0.4, color=WHITE, fill_opacity=0.1)
        state_label = MathTex("s").move_to(state_circle)
        state_group = VGroup(state_circle, state_label)

        # 策略网络/函数 (方框)
        policy_box = Square(side_length=1.2, color=BLUE, fill_opacity=0.2)
        policy_label = MathTex(r"\pi_\theta").move_to(policy_box)
        policy_group = VGroup(policy_box, policy_label)

        # 动作概率分布 (简单的柱状示意)
        bar_heights = [0.3, 0.8, 0.2, 0.5]
        bars = VGroup(*[
            Rectangle(width=0.15, height=h, fill_color=GREEN, fill_opacity=0.8, stroke_width=0)
            for h in bar_heights
        ]).arrange(RIGHT, buff=0.1, aligned_edge=DOWN)

        probs_label = Text("概率分布", font="AR PL UKai CN", font_size=18).next_to(bars, DOWN, buff=0.1)
        output_group = VGroup(bars, probs_label)

        # 组合并排列流程图
        diagram = VGroup(state_group, policy_group, output_group).arrange(RIGHT, buff=1.2)
        diagram.move_to(RIGHT * 3.5 + UP * 0.5) # 放置在屏幕右侧

        # 连接箭头
        arrow_1 = Arrow(state_group.get_right(), policy_group.get_left(), color=GRAY, buff=0.1)
        arrow_2 = Arrow(policy_group.get_right(), output_group.get_left(), color=GRAY, buff=0.1)

        # ---------------------------------------------------------
        # 4. 底部典型算法
        # ---------------------------------------------------------
        example_label = Text("典型算法：", font="AR PL UKai CN", font_size=30)
        algo_name = Text("REINFORCE", font="AR PL UKai CN", font_size=36, color=YELLOW, weight=BOLD)

        footer_group = VGroup(example_label, algo_name).arrange(RIGHT, buff=0.2)
        footer_group.to_edge(DOWN, buff=1.5)

        # 强调框
        algo_rect = SurroundingRectangle(algo_name, color=YELLOW, buff=0.15)

        # ---------------------------------------------------------
        # 5. 动画序列
        # ---------------------------------------------------------
        # 显示左侧概念
        self.play(FadeIn(desc_text, shift=RIGHT), run_time=1.0)
        self.play(Write(formula), run_time=1.0)
        self.play(FadeIn(formula_explain), run_time=0.8)

        # 绘制右侧流程图
        self.play(Create(state_group), Create(policy_group), run_time=1.0)
        self.play(GrowArrow(arrow_1), run_time=0.5)
        self.play(
            GrowArrow(arrow_2),
            FadeIn(output_group, shift=UP),
            run_time=1.0
        )

        # 显示底部算法
        self.play(Write(footer_group), run_time=1.0)
        self.play(Create(algo_rect), run_time=0.5)
