from manim import *

class FluidMechanicsImportance(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("流体力学的重要性",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心双重角色展示 (基础科学 vs 工程技术)
        # 左侧：基础科学
        science_text = Text("基础科学研究", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        science_desc = Text("前沿阵地", font="AR PL UKai CN", font_size=24, color=WHITE)
        science_group = VGroup(science_text, science_desc).arrange(DOWN, buff=0.2)
        science_box = SurroundingRectangle(science_group, color=BLUE, buff=0.2)
        science_full = VGroup(science_group, science_box)

        # 右侧：工程技术
        eng_text = Text("工程技术应用", font="AR PL UKai CN", font_size=28, color=GREEN_A)
        eng_desc = Text("核心支撑", font="AR PL UKai CN", font_size=24, color=WHITE)
        eng_group = VGroup(eng_text, eng_desc).arrange(DOWN, buff=0.2)
        eng_box = SurroundingRectangle(eng_group, color=GREEN, buff=0.2)
        eng_full = VGroup(eng_group, eng_box)

        # 布局
        roles_group = VGroup(science_full, eng_full).arrange(RIGHT, buff=1.5)
        roles_group.next_to(title_line, DOWN, buff=0.8)

        self.play(FadeIn(science_full, shift=RIGHT), FadeIn(eng_full, shift=LEFT))

        # 3. 连接与应用领域
        # 下方：应用价值
        arrow_down = Arrow(start=roles_group.get_bottom(), end=roles_group.get_bottom() + DOWN * 1.2, color=WHITE)

        value_text = Text("解决重大挑战", font="AR PL UKai CN", font_size=30, color=YELLOW)
        value_text.next_to(arrow_down, DOWN, buff=0.1)

        # 三大领域图标/文字
        energy = Text("能源", font="AR PL UKai CN", font_size=24, color=RED_B)
        env = Text("环境", font="AR PL UKai CN", font_size=24, color=TEAL_B)
        health = Text("健康", font="AR PL UKai CN", font_size=24, color=PURPLE_B)

        domains = VGroup(energy, env, health).arrange(RIGHT, buff=1.0)
        domains.next_to(value_text, DOWN, buff=0.5)

        # 为每个领域添加小圆圈背景
        domain_circles = VGroup()
        for item, col in zip(domains, [RED_B, TEAL_B, PURPLE_B]):
            circle = Circle(radius=0.5, color=col, fill_opacity=0.2)
            circle.move_to(item.get_center())
            domain_circles.add(circle)

        self.play(GrowArrow(arrow_down), Write(value_text))
        self.play(
            Create(domain_circles),
            Write(domains),
            run_time=1.5
        )

        # 4. 总结性文字 (自然规律)
        summary_text = Text("理解自然界的运动规律", font="AR PL UKai CN", font_size=24, color=GRAY_B)
        summary_text.to_edge(DOWN, buff=0.5)

        self.play(FadeIn(summary_text, shift=UP))
