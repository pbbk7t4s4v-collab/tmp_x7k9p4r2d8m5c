from manim import *

class FluidMechanicsIntro(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("流体力学的定义与核心概念",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧内容：研究对象（图片1）
        # 定义左侧标题
        left_label = Text("研究对象：流体", font="AR PL UKai CN", font_size=28, color=BLUE_A)

        # 插入图片1
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/963b57de-843d-4c30-8c37-c104f79cf144/daca49c1-a52c-459f-855d-b49a55cba8b9/pictures/888_1/1.png") # 这里期望是一张能够代表流体力学基础概念的图片。画面构图分为两部分，一部分展示清澈流动的水（代表液体），另一部分展示可视化的风洞气流线条（代表气体），风格简洁现代，背景中可以隐约包含一些物理公式符号，用于直观展示研究对象，写实风
        img1.height = 3.5  # 调整高度以适应屏幕，保持1:1比例

        # 图片下方的说明文字
        left_desc_1 = Text("液体 (Liquid) & 气体 (Gas)", font="AR PL UKai CN", font_size=24)
        left_desc_2 = Text("状态：静止 & 运动", font="AR PL UKai CN", font_size=24)

        # 组合左侧元素
        left_group = Group(left_label, img1, left_desc_1, left_desc_2).arrange(DOWN, buff=0.3)
        left_group.to_edge(LEFT, buff=1.5).shift(DOWN * 0.5)

        # 3. 右侧内容：工程应用（图片2）
        # 定义右侧标题
        right_label = Text("工程应用与方法", font="AR PL UKai CN", font_size=28, color=GREEN_A)

        # 插入图片2
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/963b57de-843d-4c30-8c37-c104f79cf144/daca49c1-a52c-459f-855d-b49a55cba8b9/pictures/888_1/2.png") # 这里期望是一张展示流体力学工程应用的图片。画面是一架飞机正在进行空气动力学测试，机翼周围有明显的彩色流线显示空气流动的轨迹，体现流体力学在解决实际工程问题中的作用，风格具有科技感，写实风
        img2.height = 3.5 # 保持与左侧一致

        # 图片下方的说明文字
        right_desc_1 = Text("建立数学模型 -> 物理方程", font="AR PL UKai CN", font_size=24)

        # 物理量公式展示
        math_vars = MathTex(r"P(\mathrm{pressure}),\ V(\mathrm{velocity}),\ \rho(\mathrm{density})", font_size=28)

        # 组合右侧元素
        right_group = Group(right_label, img2, right_desc_1, math_vars).arrange(DOWN, buff=0.3)
        right_group.to_edge(RIGHT, buff=1.5).align_to(left_group, UP)

        # 4. 装饰框
        rect_left = SurroundingRectangle(left_group, color=BLUE, buff=0.2)
        rect_right = SurroundingRectangle(right_group, color=GREEN, buff=0.2)

        # 5. 动画展示
        self.play(
            FadeIn(left_group, shift=RIGHT),
            Create(rect_left),
            run_time=1.5
        )

        self.play(
            FadeIn(right_group, shift=LEFT),
            Create(rect_right),
            run_time=1.5
        )
