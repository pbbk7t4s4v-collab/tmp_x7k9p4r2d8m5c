from manim import *

class AICourseIntro(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("神奇的AI画家：从想象到图像的魔法",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容可视化：展示 "文本 -> AI -> 图像" 的核心流程

        # 左侧：输入部分
        input_label = Text("输入提示词\n(Prompt)", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        input_desc = Text(""一只在太空\n漫步的猫"", font="AR PL UKai CN", font_size=20, color=WHITE)
        input_desc.next_to(input_label, DOWN, buff=0.2)
        input_group_content = VGroup(input_label, input_desc)
        # 使用 SurroundingRectangle 作为边框
        input_box = SurroundingRectangle(input_group_content, color=BLUE, buff=0.3)
        input_group = VGroup(input_group_content, input_box)

        # 中间：处理部分
        ai_label = Text("AI 魔法引擎\n(Diffusion Model)", font="AR PL UKai CN", font_size=24, color=GREEN_B)
        ai_box = SurroundingRectangle(ai_label, color=GREEN, buff=0.3)
        ai_group = VGroup(ai_label, ai_box)

        # 右侧：输出部分 (使用图片占位符)
        # 这里的图片占位符代表AI生成后的艺术作品
        output_img = Rectangle(color=GREY)
        output_img.height = 2.0  # 设置合适的高度
        output_label = Text("生成画作", font="AR PL UKai CN", font_size=24, color=YELLOW_B).next_to(output_img, UP, buff=0.2)
        output_group = VGroup(output_img, output_label)

        # 3. 布局排列
        # 将三个主要元素水平排列
        main_content = VGroup(input_group, ai_group, output_group).arrange(RIGHT, buff=1.5)
        main_content.move_to(ORIGIN) # 居中显示

        # 创建连接箭头
        arrow1 = Arrow(start=input_box.get_right(), end=ai_box.get_left(), color=GREY)
        arrow2 = Arrow(start=ai_box.get_right(), end=output_img.get_left(), color=GREY)

        # 4. 动画展示流程

        # 第一步：出现输入
        self.play(FadeIn(input_group, shift=UP), run_time=1)

        # 第二步：数据流向AI
        self.play(GrowArrow(arrow1), run_time=0.8)
        self.play(SpinInFromNothing(ai_group), run_time=1)

        # 第三步：AI生成结果
        self.play(GrowArrow(arrow2), run_time=0.8)
        self.play(FadeIn(output_group, shift=LEFT), run_time=1)

        # 5. 总结强调
        final_rect = SurroundingRectangle(main_content, color=YELLOW, buff=0.2)
        self.play(Create(final_rect), run_time=1)
