from manim import *

class FluidMechanicsFoundations(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Theoretical Foundations of Fluid Mechanics",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Core Theory Column (Left)
        theory_title = Text("Core Theoretical Framework", font_size=28, color=CYAN)
        theory_title.move_to(LEFT * 3.5 + UP * 1.5)

        # Main theoretical points
        main_points = BulletedList(
            "Continuum Hypothesis",
            "Conservation Laws (Mass, Momentum, Energy)",
            "Descriptive Methods (Viscosity, Turbulence, etc.)",
            font_size=24,
            line_spacing=0.8
        ).next_to(theory_title, DOWN, aligned_edge=LEFT, buff=0.4)

        theory_group = VGroup(theory_title, main_points)
        theory_box = SurroundingRectangle(theory_group, color=BLUE, buff=0.3)

        self.play(FadeIn(theory_title, shift=DOWN))
        self.play(Write(main_points, run_time=3))
        self.play(Create(theory_box))

        # 3. Application Column (Right)
        app_title = Text("Application: CFD", font_size=28, color=GREEN)
        app_title.move_to(RIGHT * 3.5 + UP * 1.5)

        # Benefits of CFD
        app_benefits = BulletedList(
            "Numerical Simulation of Flow",
            "Fast Design Evaluation",
            "Reduces Cost and Time",
            font_size=24,
            line_spacing=0.8
        ).next_to(app_title, DOWN, aligned_edge=LEFT, buff=0.4)

        app_group = VGroup(app_title, app_benefits)
        app_box = SurroundingRectangle(app_group, color=GREEN, buff=0.3)

        # 4. Connecting Arrow
        arrow = Arrow(
            start=theory_box.get_right(),
            end=app_box.get_left(),
            buff=0.2,
            color=WHITE
        )
        arrow_label = Text("Enables", font_size=20).next_to(arrow, UP, buff=0.1)

        self.play(
            GrowArrow(arrow),
            Write(arrow_label)
        )

        # Animate the application part
        self.play(
            FadeIn(app_title, shift=DOWN),
            run_time=0.5
        )
        self.play(
            Write(app_benefits, run_time=2.0)
        )
        self.play(Create(app_box))
