from manim import *

class WaveEquationDerivation(Scene):
    def construct(self):

        # 1. Title Configuration (Strictly following template)
        title = Text("Wave Equation: Derivation & General Solutions",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Assumption Text
        assumption = Text("Assumption: Small vibration implies stress T(x) = const.",
                         font_size=26, color=GRAY_B)
        assumption.next_to(title_line, DOWN, buff=0.5)

        # 3. Main Wave Equation
        # Using MathTex for clear mathematical representation
        wave_eq = MathTex(
            r"u_{tt} - a^2 u_{xx} = F(t, x)",
            font_size=42
        )
        wave_eq.next_to(assumption, DOWN, buff=0.5)

        # Highlight the equation
        box = SurroundingRectangle(wave_eq, color=BLUE, buff=0.2)
        label_eq = Text("Wave Equation (1.1.16)", font_size=20, color=BLUE).next_to(box, RIGHT)

        # Parameter definitions
        params = MathTex(
            r"\text{where } a = \sqrt{T/\rho}, \quad F(t,x) = f(t,x)/\rho",
            font_size=30,
            color=TEAL
        )
        params.next_to(box, DOWN, buff=0.3)

        # 4. Homogeneous Solutions
        divider = Line(LEFT, RIGHT, color=GRAY).scale(0.5).next_to(params, DOWN, buff=0.5)

        sol_title = Text("Homogeneous Solutions (F ≡ 0):", font_size=28, color=YELLOW)
        sol_title.next_to(divider, DOWN, buff=0.3)

        # Solution forms: Traveling waves
        # Left traveling wave
        sol_left = MathTex(r"u = \psi(x + at)", color=RED_B, font_size=36)
        label_left = Text("Left Traveling Wave", font_size=20, color=RED_B).next_to(sol_left, UP, buff=0.1)
        group_left = VGroup(label_left, sol_left)

        # Right traveling wave
        sol_right = MathTex(r"u = \phi(x - at)", color=GREEN_B, font_size=36)
        label_right = Text("Right Traveling Wave", font_size=20, color=GREEN_B).next_to(sol_right, UP, buff=0.1)
        group_right = VGroup(label_right, sol_right)

        # Arrange solutions horizontally
        solutions_group = VGroup(group_left, group_right).arrange(RIGHT, buff=2.0)
        solutions_group.next_to(sol_title, DOWN, buff=0.4)

        # 5. Animation Sequence
        self.play(FadeIn(assumption, shift=DOWN))

        self.play(Write(wave_eq))
        self.play(Create(box), FadeIn(label_eq))
        self.play(FadeIn(params, shift=UP))

        self.play(Create(divider))
        self.play(Write(sol_title))

        # Animate solutions appearing with a slight directional shift to represent movement
        self.play(
            FadeIn(group_left, shift=LEFT),
            FadeIn(group_right, shift=RIGHT)
        )
