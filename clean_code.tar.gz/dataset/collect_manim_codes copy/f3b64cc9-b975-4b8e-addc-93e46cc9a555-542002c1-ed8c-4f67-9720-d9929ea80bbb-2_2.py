from manim import *
import numpy as np

class QuantumLeapIntro(Scene):
    def construct(self):

        # 1. 标题设置 (符合模板要求)
        title = Text("量子跃迁与能级概念",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 绘制原子模型 (左侧)
        # 原子核
        nucleus = Dot(radius=0.15, color=RED)
        nucleus.move_to(LEFT * 3)
        nucleus_label = Text("原子核", font="AR PL UKai CN", font_size=16, color=RED).next_to(nucleus, DOWN, buff=0.1)

        # 轨道 (能级)
        orbit_1 = Circle(radius=1.2, color=GRAY, stroke_opacity=0.5).move_to(nucleus)
        orbit_2 = Circle(radius=2.2, color=GRAY, stroke_opacity=0.5).move_to(nucleus)

        # 能级标签
        label_e1 = MathTex("E_1", color=GRAY).next_to(orbit_1, LEFT, buff=0.1).scale(0.7)
        label_e2 = MathTex("E_2", color=GRAY).next_to(orbit_2, LEFT, buff=0.1).scale(0.7)

        atom_group = VGroup(nucleus, nucleus_label, orbit_1, orbit_2, label_e1, label_e2)

        # 3. 右侧说明文字
        info_text = VGroup(
            Text("1. 能量是离散的 (能级)", font="AR PL UKai CN", font_size=24, color=YELLOW),
            Text("2. 电子在不同轨道间跃迁", font="AR PL UKai CN", font_size=24),
            Text("3. 伴随光子的吸收或释放", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.5)

        info_text.to_edge(RIGHT, buff=1.0).shift(UP * 0.5)

        # 4. 动画流程

        # 展示原子结构和第一条文本
        self.play(
            FadeIn(atom_group),
            Write(info_text[0])
        )

        # 创建电子 (初始在 E2 - 高能级)
        electron = Dot(radius=0.1, color=BLUE)
        start_angle = PI / 4
        electron.move_to(orbit_2.point_at_angle(start_angle))

        electron_label = Text("电子", font="AR PL UKai CN", font_size=16, color=BLUE).next_to(electron, RIGHT, buff=0.1)

        self.play(
            FadeIn(electron),
            FadeIn(electron_label),
            Write(info_text[1])
        )

        # 跃迁动画 (E2 -> E1)
        target_pos = orbit_1.point_at_angle(start_angle)

        # 移除电子标签以便移动
        self.remove(electron_label)

        self.play(
            electron.animate.move_to(target_pos),
            run_time=1.0,
            rate_func=rush_into
        )

        # 光子发射效果 (正弦波曲线向外飞出)
        photon_start = target_pos
        photon_end = target_pos + np.array([2, 2, 0]) # 向右上方飞出

        # 定义光子路径函数
        def photon_path(t):
            start = photon_start
            end = photon_end
            linear_pos = start + t * (end - start)
            # 添加垂直于运动方向的波动
            direction = end - start
            normal = np.array([-direction[1], direction[0], 0])
            normal = normal / np.linalg.norm(normal)
            return linear_pos + 0.15 * np.sin(10 * PI * t) * normal

        photon = ParametricFunction(photon_path, t_range=[0, 1], color=YELLOW)
        photon_text = MathTex(r"h\nu", color=YELLOW).next_to(photon_end, UP, buff=0.1)

        self.play(
            Create(photon),
            FadeIn(photon_text),
            Write(info_text[2])
        )

        # 5. 底部公式总结
        formula = MathTex(r"\Delta E = E_2 - E_1 = h\nu", color=WHITE)
        formula.next_to(info_text, DOWN, buff=0.8)

        # 强调框
        box = SurroundingRectangle(formula, color=BLUE, buff=0.2)

        self.play(
            Write(formula),
            Create(box)
        )
