from manim import *

class ElectrolyticCapacitorFault(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("元器件故障:电解电容老化与交流输入不稳",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("46", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧可视化:原理与波形
        # 定义字体
        font_cn = "AR PL UKai CN"

        # 逻辑流程
        cap_text = Text("电解电容", font=font_cn, font_size=24, color=BLUE)
        aging_text = Text("容量 < 50%", font=font_cn, font_size=24, color=RED)
        ripple_text = Text("纹波系数增大", font=font_cn, font_size=24, color=ORANGE)

        flow_group = VGroup(cap_text, aging_text, ripple_text).arrange(DOWN, buff=0.5)
        flow_group.to_edge(LEFT, buff=1.0).shift(UP*1.5)

        arrow1 = Arrow(cap_text.get_bottom(), aging_text.get_top(), buff=0.1, color=WHITE)
        arrow2 = Arrow(aging_text.get_bottom(), ripple_text.get_top(), buff=0.1, color=WHITE)

        # 波形示意图 (平滑直流 -> 纹波直流)
        axes = Axes(
            x_range=[0, 4, 1],
            y_range=[0, 5, 1],
            x_length=4,
            y_length=2,
            axis_config={"include_tip": False, "include_numbers": False}
        ).next_to(flow_group, DOWN, buff=0.8)

        axes_label = Text("输出电压波形", font=font_cn, font_size=20).next_to(axes, DOWN)

        # 正常波形 (直线)
        dc_line = axes.plot(lambda x: 3.5, color=GREEN)
        dc_label = Text("正常", font=font_cn, font_size=16, color=GREEN).next_to(dc_line, UP, buff=0.1)

        # 故障波形 (100Hz纹波模拟)
        ripple_wave = axes.plot(lambda x: 3.5 + 0.5 * np.sin(10 * x), color=RED)
        ripple_label = Text("100Hz纹波", font=font_cn, font_size=16, color=RED).next_to(ripple_wave, UP, buff=0.1)

        left_group = VGroup(flow_group, arrow1, arrow2, axes, axes_label)

        # 3. 右侧文字:表现与检测
        # 故障表现列表
        symptom_title = Text("故障表现:", font=font_cn, font_size=26, color=YELLOW).align_to(LEFT, LEFT)
        symptom_list = VGroup(
            Text("1. 音量随电网波动出现'呼呼'声", font=font_cn, font_size=22),
            Text("2. 示波器现100Hz纹波(整流后)", font=font_cn, font_size=22),
            Text("3. 负载加重时电压明显跌落", font=font_cn, font_size=22)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        symptom_group = VGroup(symptom_title, symptom_list).arrange(DOWN, aligned_edge=LEFT, buff=0.3)

        # 检测方法列表
        detect_title = Text("检测方法:", font=font_cn, font_size=26, color=GREEN_B).align_to(LEFT, LEFT)
        detect_list = VGroup(
            Text("• 电容表测量实际容量", font=font_cn, font_size=22),
            Text("• 测交流分量 (正常应 < 0.1V)", font=font_cn, font_size=22, t2c={"< 0.1V": RED})
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        detect_group = VGroup(detect_title, detect_list).arrange(DOWN, aligned_edge=LEFT, buff=0.3)

        # 组合右侧内容
        right_content = VGroup(symptom_group, detect_group).arrange(DOWN, aligned_edge=LEFT, buff=0.8)
        right_content.to_edge(RIGHT, buff=1.0).shift(UP*0.5)

        # 4. 动画播放序列

        # 展示左侧原理流程
        self.play(
            FadeIn(cap_text),
            GrowArrow(arrow1),
            FadeIn(aging_text),
            run_time=1.5
        )

        self.play(
            GrowArrow(arrow2),
            Write(ripple_text),
            run_time=1.0
        )

        # 展示波形变化
        self.play(Create(axes), Write(axes_label), run_time=1.0)
        self.play(Create(dc_line), FadeIn(dc_label), run_time=0.8)
        self.play(
            Transform(dc_line, ripple_wave),
            Transform(dc_label, ripple_label),
            run_time=1.5
        )

        # 展示右侧故障表现和检测方法
        box_symptoms = SurroundingRectangle(symptom_group, color=YELLOW, buff=0.15, stroke_width=2)
        box_detect = SurroundingRectangle(detect_group, color=GREEN, buff=0.15, stroke_width=2)

        self.play(
            Write(symptom_group),
            Create(box_symptoms),
            run_time=2.0
        )

        self.play(
            FadeIn(detect_group, shift=UP*0.5),
            Create(box_detect),
            run_time=2.0
        )
