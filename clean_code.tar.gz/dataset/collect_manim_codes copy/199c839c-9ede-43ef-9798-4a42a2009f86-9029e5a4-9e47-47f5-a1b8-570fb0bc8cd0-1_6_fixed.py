from manim import *

class ScientificIntegrationScene(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Scientific Research & Interdisciplinary Integration",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Central Concept
        center_concept = Text("Fluid Mechanics", font_size=36, color=BLUE, weight=BOLD)
        center_pos = UP * 1.5
        center_concept.move_to(center_pos)
        center_concept.shift(DOWN * 0.3)  # 修复：下移0.3避免与箭头重叠
        self.play(Write(center_concept))

        # 3. Interdisciplinary Fields and Connections
        disciplines = {
            "Thermodynamics": LEFT * 5 + UP * 2.8,  # 修复：上移0.3减少与箭头重叠
            "Numerical Analysis": RIGHT * 5 + UP * 2.8,  # 修复：上移0.3减少与箭头重叠
            "Material Science": LEFT * 5 + UP * 0.8,  # 修复：上移0.3减少与箭头重叠
            "Economics": RIGHT * 5 + UP * 0.8,  # 修复：上移0.3减少与箭头重叠
        }

        discipline_mobjects = VGroup()
        connecting_arrows = VGroup()

        for name, position in disciplines.items():
            text = Text(name, font_size=28, color=TEAL)  # 修复：字体从30降为28减少边缘碰撞
            text.move_to(position)
            discipline_mobjects.add(text)

            arrow = Arrow(center_pos + DOWN * 0.3, text.get_center(), buff=0.4, stroke_width=3, color=GRAY)  # 修复：起点下移0.3，buff增至0.4避免遮挡
            connecting_arrows.add(arrow)

        self.play(
            LaggedStart(
                *[GrowArrow(arrow) for arrow in connecting_arrows],
                *[Write(mob) for mob in discipline_mobjects],
                lag_ratio=0.5,
                run_time=4
            )
        )

        # 4. Specific Examples
        example_list = BulletedList(
            "Ocean Economics: Predict fishery distribution using fluid models.",
            "Geophysics: Analyze magma flow and its link to earthquakes.",
            font_size=28  # 修复：字体从30降为28以优化底部布局
        ).to_edge(DOWN, buff=1.0)

        self.play(FadeIn(example_list, shift=UP * 0.5), run_time=2.5)
