from manim import *

class IsolationGowns(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Isolation Gowns",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("14", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Image Loading and Positioning
        # Image 1: General appearance of the gown
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_14/1.png") # A medical professional wearing a yellow or blue protective isolation gown, gloves, and a face mask. The gown is long-sleeved and covers the body fully, distinct from a standard white lab coat. The style is a clean, semi-realistic educational illustration on a white background.
        img1.height = 2.8
        img1.to_edge(RIGHT, buff=1.0).shift(UP * 1.5)

        # Image 2: Back-closing design detail
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_14/2.png") # A diagram or illustration showing the back-closing design of an isolation gown to highlight the protection aspect. The style is a clear technical illustration.
        img2.height = 2.8
        img2.next_to(img1, DOWN, buff=0.5)

        # 3. Text Content Definition
        # Point 1
        dot1 = Dot(color=ORANGE)
        text1 = Text("Used in BSL-2 and BSL-3 labs", font_size=24, color=WHITE)
        line1 = VGroup(dot1, text1).arrange(RIGHT, buff=0.2)

        # Point 2
        dot2 = Dot(color=ORANGE)
        text2 = Text("Handles large volumes of blood\nor infectious materials", font_size=24, color=WHITE, line_spacing=1)
        line2 = VGroup(dot2, text2).arrange(RIGHT, buff=0.2, aligned_edge=UP)

        # Point 3
        dot3 = Dot(color=ORANGE)
        text3 = Text("Back-closing design offers\nbetter protection", font_size=24, color=WHITE, line_spacing=1)
        line3 = VGroup(dot3, text3).arrange(RIGHT, buff=0.2, aligned_edge=UP)

        # Grouping text
        content_group = VGroup(line1, line2, line3).arrange(DOWN, aligned_edge=LEFT, buff=0.8)
        content_group.to_edge(LEFT, buff=1.0).shift(UP * 0.5)

        # 4. Animation Sequence
        # Show Image 1 and basic usage
        self.play(FadeIn(img1, shift=LEFT))
        self.play(FadeIn(line1, shift=RIGHT))

        # Show protection capability
        self.play(FadeIn(line2, shift=RIGHT))

        # Show Image 2 (Back-closing) and specific feature text
        self.play(FadeIn(img2, shift=UP))

        # Highlight the back-closing feature
        frame = SurroundingRectangle(img2, color=YELLOW, buff=0.1)
        self.play(
            FadeIn(line3, shift=RIGHT),
            Create(frame)
        )
