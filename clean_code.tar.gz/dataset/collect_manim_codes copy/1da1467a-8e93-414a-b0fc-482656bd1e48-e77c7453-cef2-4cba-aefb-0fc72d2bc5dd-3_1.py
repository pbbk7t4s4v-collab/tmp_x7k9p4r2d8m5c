from manim import *

class StoredProgramConcept(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("冯·诺伊曼体系：存储程序思想与区分",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 绘制内存模型 (右侧)
        # 创建内存单元格
        cell_height = 0.6
        cell_width = 3.5
        memory_cells = VGroup()
        binary_contents = ["1011 0010", "0100 1111", "1110 0001", "0000 1101"]

        for i, bits in enumerate(binary_contents):
            rect = Rectangle(height=cell_height, width=cell_width, color=BLUE)
            text = Text(bits, font="AR PL UKai CN", font_size=24)
            # 添加地址标号
            addr = Text(f"地址 0x0{i}", font="AR PL UKai CN", font_size=16, color=GRAY)
            addr.next_to(rect, LEFT, buff=0.1)

            cell_group = VGroup(rect, text, addr)
            # 组合在一起，文字居中
            text.move_to(rect.get_center())
            memory_cells.add(cell_group)

        # 纵向排列内存
        memory_cells.arrange(DOWN, buff=0)
        memory_cells.shift(RIGHT * 3 + DOWN * 0.5)

        mem_label = Text("主存储器 (Memory)", font="AR PL UKai CN", font_size=24, color=BLUE)
        mem_label.next_to(memory_cells, UP, buff=0.2)

        # 3. 绘制CPU模型 (左侧)
        cpu_box = Rectangle(height=3.5, width=3.5, color=WHITE)
        cpu_box.shift(LEFT * 3 + DOWN * 0.5)

        cpu_label = Text("CPU", font="AR PL UKai CN", font_size=28)
        cpu_label.next_to(cpu_box, UP, buff=0.2)

        # PC 寄存器
        pc_rect = Rectangle(height=0.8, width=2.5, color=GREEN)
        pc_rect.move_to(cpu_box.get_center() + UP * 0.8)
        pc_text = Text("PC 寄存器", font="AR PL UKai CN", font_size=20)
        pc_text.move_to(pc_rect.get_center())
        pc_group = VGroup(pc_rect, pc_text)

        # IR/通用寄存器 (示意)
        other_regs = Rectangle(height=0.8, width=2.5, color=GRAY)
        other_regs.move_to(cpu_box.get_center() + DOWN * 0.8)
        other_text = Text("其它寄存器/ALU", font="AR PL UKai CN", font_size=20)
        other_text.move_to(other_regs.get_center())

        cpu_group = VGroup(cpu_box, pc_group, other_regs, other_text, cpu_label)

        # 进场动画
        self.play(
            FadeIn(mem_label),
            Create(memory_cells),
            Create(cpu_group),
            run_time=1.5
        )

        # 4. 提出核心问题
        question_text = Text("内存中的二进制：是指令还是数据？", font="AR PL UKai CN", font_size=24, color=YELLOW)
        question_text.next_to(title_line, DOWN, buff=0.3)
        self.play(Write(question_text))

        # 高亮内存中的第一行
        target_cell = memory_cells[0][0] # 获取第一个矩形框
        highlight_rect = SurroundingRectangle(target_cell, color=YELLOW, buff=0.05)
        self.play(Create(highlight_rect), run_time=0.5)

        # 5. 展示解决方案：PC指针的作用
        # 箭头从PC指向内存地址0
        arrow = Arrow(start=pc_rect.get_right(), end=memory_cells[0].get_left(), color=RED, buff=0.1)

        fetch_text = Text("取指周期", font="AR PL UKai CN", font_size=20, color=RED)
        fetch_text.next_to(arrow, UP, buff=0.05)

        self.play(
            GrowArrow(arrow),
            FadeIn(fetch_text)
        )

        # 结论文字
        answer_text = Text("PC 指向的内容被视为【指令】", font="AR PL UKai CN", font_size=28, color=GREEN)
        answer_text.move_to(DOWN * 3)

        # 强调逻辑
        self.play(
            Transform(question_text, answer_text),
            Indicate(pc_group, color=GREEN),
            run_time=1.5
        )

        # 补充说明数据的情况 (简单的淡入)
        data_note = Text("指令执行时操作的地址即为【数据】", font="AR PL UKai CN", font_size=22, color=GRAY)
        data_note.next_to(answer_text, DOWN, buff=0.2)
        self.play(FadeIn(data_note))
