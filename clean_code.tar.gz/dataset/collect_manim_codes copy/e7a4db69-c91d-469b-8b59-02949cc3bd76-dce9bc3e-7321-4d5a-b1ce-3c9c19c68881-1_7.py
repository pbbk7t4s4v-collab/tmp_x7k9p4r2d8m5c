from manim import *

class PCBPadAndTrace(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("PCB基础：焊盘与铜箔的连接关系",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 绘制图形示意 (中心区域)
        # 模拟PCB背景颜色 (可选，这里为了简洁只画核心元素)

        # 定义焊盘 (圆形，金色)
        pad_left = Circle(radius=0.4, color=GOLD_A, fill_opacity=0.8, fill_color=GOLD_E)
        pad_right = pad_left.copy()

        # 布局焊盘位置
        pad_left.move_to(LEFT * 3 + UP * 0.5)
        pad_right.move_to(RIGHT * 3 + UP * 0.5)

        # 定义铜箔 (连接线，橙色)
        trace = Line(pad_left.get_right(), pad_right.get_left(), color=ORANGE, stroke_width=8)

        # 标签
        label_pad = Text("焊盘 (Pad)", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(pad_left, UP)
        label_trace = Text("铜箔 (Trace)", font="AR PL UKai CN", font_size=20, color=ORANGE).next_to(trace, UP)

        # 组合图形
        visual_group = VGroup(pad_left, pad_right, trace, label_pad, label_trace)

        # 动画展示图形
        self.play(
            DrawBorderThenFill(pad_left),
            DrawBorderThenFill(pad_right),
            run_time=1.0
        )
        self.play(Create(trace), run_time=0.8)
        self.play(FadeIn(label_pad), FadeIn(label_trace))

        # 3. 文本解释 (分左右两栏展示特性)

        # 左侧：焊盘特性
        pad_text_content = [
            "● 用于焊接元件引脚",
            "● 表面镀有抗氧化层",
            "● 形状多样(圆/方等)"
        ]
        pad_text_group = VGroup(*[
            Text(t, font="AR PL UKai CN", font_size=18, color=WHITE)
            for t in pad_text_content
        ]).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        pad_text_group.next_to(pad_left, DOWN, buff=0.5)

        # 右侧：铜箔特性
        trace_text_content = [
            "● 铜材料蚀刻而成",
            "● 宽度决定载流能力",
            "● 连接形成电气通路"
        ]
        trace_text_group = VGroup(*[
            Text(t, font="AR PL UKai CN", font_size=18, color=WHITE)
            for t in trace_text_content
        ]).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        trace_text_group.next_to(pad_right, DOWN, buff=0.5)

        # 底部：连接关系总结
        summary_text = Text(
            "总结：锡液连接引脚与焊盘，焊盘通过铜箔导通电流",
            font="AR PL UKai CN", font_size=22, color=BLUE_B
        )
        summary_text.to_edge(DOWN, buff=0.8)

        # 装饰框
        rect_pad = SurroundingRectangle(pad_text_group, color=YELLOW, buff=0.15)
        rect_trace = SurroundingRectangle(trace_text_group, color=ORANGE, buff=0.15)

        # 动画展示文本
        self.play(
            FadeIn(pad_text_group, shift=UP),
            Create(rect_pad),
            run_time=1.0
        )
        self.play(
            FadeIn(trace_text_group, shift=UP),
            Create(rect_trace),
            run_time=1.0
        )

        # 4. 电流演示动画 (展示连接关系)
        # 创建一个发光点模拟电流
        electron = Dot(color=YELLOW, radius=0.08)
        electron.move_to(pad_left.get_center())

        path = Line(pad_left.get_center(), pad_right.get_center())

        self.play(Write(summary_text))

        # 电流流动动画
        self.play(
            MoveAlongPath(electron, path),
            run_time=2,
            rate_func=linear
        )

        # 稍微闪烁一下表示连通
        self.play(
            Indicate(pad_right, color=WHITE),
            Flash(pad_right, color=YELLOW, line_length=0.2),
            run_time=0.5
        )
