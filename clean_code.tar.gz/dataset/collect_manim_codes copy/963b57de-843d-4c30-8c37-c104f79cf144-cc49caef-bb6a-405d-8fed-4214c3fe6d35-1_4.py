from manim import *

class IndustrialProductionScene(Scene):
    def construct(self):

        self.camera.background_color = "#1E1E1E"

        # 1. Title
        title = Text("Fluid Mechanics in Industrial Production",
                     font_size=34,
                     color=WHITE,
                     weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Create a bulleted list for key applications
        applications_list = BulletedList(
            "Material Forming Processes (e.g., spraying, injection molding)",
            "Cooling System Optimization (e.g., electronics heat dissipation)",
            "Nuclear Industry Safety (e.g., reactor cooling analysis)",
            font_size=28,
            buff=0.4  # Vertical spacing between items
        ).next_to(title_group, DOWN, buff=0.7).to_edge(LEFT, buff=1.0)

        # 3. Animate the list items appearing sequentially
        for item in applications_list:
            self.play(FadeIn(item, shift=RIGHT), run_time=1.2)

        # 4. Highlight key concepts with SurroundingRectangle
        box1 = SurroundingRectangle(applications_list[0], color=BLUE, buff=0.1)
        box2 = SurroundingRectangle(applications_list[1], color=GREEN, buff=0.1)
        box3 = SurroundingRectangle(applications_list[2], color=ORANGE, buff=0.1)

        self.play(Create(box1))
        self.play(Transform(box1, box2))
        self.play(Transform(box1, box3))
        self.play(FadeOut(box1))
