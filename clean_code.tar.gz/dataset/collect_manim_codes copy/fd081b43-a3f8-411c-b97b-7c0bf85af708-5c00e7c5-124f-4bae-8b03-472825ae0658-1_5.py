from manim import *

class MarginalPropensityToConsume(Scene):
    def construct(self):

        # 1. 标题部分 (按照模板要求)
        title = Text("边际消费倾向(MPC)的直观理解",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 场景核心：收入展示
        # 这是一个简单的矩形表示钞票
        income_box = Rectangle(height=1.2, width=2.5, color=GREEN, fill_opacity=0.2)
        income_label = Text("新增收入\n100元", font="AR PL UKai CN", font_size=28, color=GREEN_A)
        income_label.move_to(income_box.get_center())

        income_group = VGroup(income_box, income_label)
        income_group.shift(UP * 1.0) # 放置在屏幕中上方

        # 提问文本
        question_text = Text("互动：如果你多了一笔100元收入，\n你会花掉多少？",
                           font="AR PL UKai CN", font_size=24, color=YELLOW)
        question_text.next_to(income_group, UP, buff=0.3)

        self.play(
            FadeIn(question_text, shift=DOWN),
            Create(income_box),
            Write(income_label)
        )

        # 3. 场景核心：决策分支 (消费 vs 储蓄)
        # 左下箭头指向消费
        arrow_spend = Arrow(start=income_box.get_bottom(), end=income_box.get_bottom() + DOWN*1.5 + LEFT*2.5, buff=0.1, color=RED)
        # 右下箭头指向储蓄
        arrow_save = Arrow(start=income_box.get_bottom(), end=income_box.get_bottom() + DOWN*1.5 + RIGHT*2.5, buff=0.1, color=BLUE)

        # 假设的回答文本
        spend_val = Text("花掉 (例如 80元)", font="AR PL UKai CN", font_size=24, color=RED)
        spend_val.next_to(arrow_spend.get_end(), DOWN)

        save_val = Text("存下 (剩余 20元)", font="AR PL UKai CN", font_size=24, color=BLUE)
        save_val.next_to(arrow_save.get_end(), DOWN)

        self.play(
            GrowArrow(arrow_spend),
            GrowArrow(arrow_save),
            FadeIn(spend_val, shift=UP),
            FadeIn(save_val, shift=UP)
        )

        # 4. 概念引出：边际消费倾向
        # 定义文本
        concept_text = Text("这个花钱的比例就是：边际消费倾向 (c)",
                          font="AR PL UKai CN", font_size=28, color=WHITE)

        # 公式展示
        # c = Delta C / Delta Y
        formula_part1 = MathTex(r"c = \frac{\Delta C}{\Delta Y} \approx")
        formula_part2 = MathTex(r"\frac{80}{100} = 0.8")

        formula_group = VGroup(formula_part1, formula_part2).arrange(RIGHT)

        # 组合定义和公式
        final_concept_group = VGroup(concept_text, formula_group).arrange(DOWN, buff=0.3)
        final_concept_group.move_to(DOWN * 2.5) # 放置在底部

        # 强调框
        surround_rect = SurroundingRectangle(final_concept_group, color=ORANGE, buff=0.2)

        self.play(
            Write(concept_text),
            FadeIn(formula_group, shift=UP)
        )
        self.play(Create(surround_rect))
