from manim import *

class TimeComplexityCases(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("时间复杂度的三种情况与量阶",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("35", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 三种情况展示
        # 创建文本对象
        t_best = Text("最好情况", font="AR PL UKai CN", font_size=28, color=GREEN)
        t_avg = Text("平均情况", font="AR PL UKai CN", font_size=28, color=YELLOW)
        t_worst = Text("最坏情况", font="AR PL UKai CN", font_size=28, color=RED)

        # 排列位置
        cases_group = VGroup(t_best, t_avg, t_worst).arrange(RIGHT, buff=1.2)
        cases_group.shift(UP * 1.5)

        self.play(FadeIn(cases_group, shift=UP))

        # 3. 强调最坏情况（核心概念）
        # 使用 SurroundingRectangle
        rect = SurroundingRectangle(t_worst, color=RED, buff=0.15)
        # 说明文字
        label = Text("算法时间复杂度的通用标准", font="AR PL UKai CN", font_size=20, color=WHITE)
        label.next_to(rect, DOWN, buff=0.15)

        self.play(
            Create(rect),
            Write(label)
        )

        # 4. Big O 的含义
        # 分隔线
        sep_line = Line(LEFT, RIGHT, color=GRAY, stroke_opacity=0.5).match_width(title_line).scale(1.5)
        sep_line.move_to(ORIGIN) # 居中

        self.play(Create(sep_line))

        # 下半部分内容
        big_o = MathTex(r"O(f(n))", font_size=60, color=BLUE)

        # 解释文本，使用VGroup对齐
        desc_1 = Text("不是精确运行时间", font="AR PL UKai CN", font_size=24, color=LIGHT_GRAY)
        desc_2 = Text("表示数量级 (增长趋势)", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        desc_3 = Text("描述大规模数据的增长上限", font="AR PL UKai CN", font_size=24, color=WHITE)

        desc_group = VGroup(desc_1, desc_2, desc_3).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # 左右排列 Big O 和解释
        bottom_group = VGroup(big_o, desc_group).arrange(RIGHT, buff=0.8)
        bottom_group.next_to(sep_line, DOWN, buff=0.5)

        self.play(
            Write(big_o),
            FadeIn(desc_group, shift=LEFT, run_time=1.5)
        )

        # 5. 最后的强调
        # 强调"数量级"概念
        rect_desc = SurroundingRectangle(desc_2, color=BLUE, buff=0.1)
        self.play(Create(rect_desc))
