from manim import *

class MainThemeSummary(Scene):
    def construct(self):

        # 1. 标题设置 (严格遵循模板)
        title = Text("文章主旨归纳",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("27", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容部分设计
        # 第一部分:说明方法与对象
        # 创建文本内容
        p1_title = Text("说明方法与对象", font="AR PL UKai CN", font_size=28, color=BLUE_B)
        p1_desc = Text(
            "综合运用多种说明方法\n科学、准确、艺术地说明\n荔枝的形态、果实及生产情况",
            font="AR PL UKai CN",
            font_size=24,
            line_spacing=0.8,
            t2c={"科学": YELLOW, "准确": YELLOW, "艺术": YELLOW} # 强调关键词
        )

        # 组合第一部分并添加边框
        p1_content = VGroup(p1_title, p1_desc).arrange(DOWN, buff=0.3)
        p1_box = SurroundingRectangle(p1_content, color=BLUE, buff=0.2, stroke_width=2)
        group1 = VGroup(p1_box, p1_content)

        # 第二部分:知识融合与特性
        # 创建文本内容,使用类似公式的结构展示融合
        p2_title = Text("知识融合与高度特性", font="AR PL UKai CN", font_size=28, color=GREEN_B)

        # 融合公式:科学+历史+文学
        p2_formula = VGroup(
            Text("科学知识", font="AR PL UKai CN", font_size=22, color=TEAL),
            Text("+", font="AR PL UKai CN", font_size=22),
            Text("历史知识", font="AR PL UKai CN", font_size=22, color=TEAL),
            Text("+", font="AR PL UKai CN", font_size=22),
            Text("文学知识", font="AR PL UKai CN", font_size=22, color=TEAL)
        ).arrange(RIGHT, buff=0.2)

        # 向下箭头
        arrow = Arrow(start=UP, end=DOWN, buff=0).scale(0.5).set_color(GREY)

        # 结果:三性合一
        p2_result = Text(
            "融为一体:思想性、科学性、艺术性",
            font="AR PL UKai CN",
            font_size=24,
            t2c={"融为一体": RED}
        )

        # 组合第二部分并添加边框
        p2_content = VGroup(p2_title, p2_formula, arrow, p2_result).arrange(DOWN, buff=0.2)
        p2_box = SurroundingRectangle(p2_content, color=GREEN, buff=0.2, stroke_width=2)
        group2 = VGroup(p2_box, p2_content)

        # 3. 布局与动画
        # 整体布局:垂直排列
        main_content = VGroup(group1, group2).arrange(DOWN, buff=0.6)
        main_content.next_to(title_group, DOWN, buff=0.5)

        # 播放动画
        self.play(FadeIn(group1, shift=UP), run_time=1.2)
        self.play(FadeIn(group2, shift=UP), run_time=1.2)

        # 最后的强调
        self.play(Indicate(p2_result, color=RED), run_time=1.5)
