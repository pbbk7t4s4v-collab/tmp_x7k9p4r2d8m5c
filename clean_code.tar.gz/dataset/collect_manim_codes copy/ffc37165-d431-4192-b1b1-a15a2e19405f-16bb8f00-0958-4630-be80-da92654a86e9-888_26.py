from manim import *

class BFSAndConnectivity(Scene):
    def construct(self):

        # 1. 标题设定
        title = Text("BFS复杂度与图的连通性",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("26", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧内容：BFS复杂度
        left_config = {
            "font": "AR PL UKai CN",
            "font_size": 24
        }

        bfs_header = Text("BFS 实现要点 (邻接表)", **left_config, color=BLUE).scale(1.1)
        bfs_p1 = Text("• 数据结构：队列 (Queue)", **left_config)
        bfs_p2 = Text("• 复杂度分析：", **left_config)

        # 数学公式
        complexity_eq = MathTex(
            r"T(n, e) = \underbrace{O(n)}_{\text{init}} + \underbrace{O(e)}_{\text{edges}}",
            font_size=28
        )
        complexity_res = MathTex(
            r"= O(n + e)",
            font_size=32, color=YELLOW
        )

        bfs_group = VGroup(bfs_header, bfs_p1, bfs_p2, complexity_eq, complexity_res)
        bfs_group.arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        bfs_group.to_edge(LEFT, buff=1)
        bfs_group.shift(UP * 0.5)

        # 3. 右侧内容：连通性示意图
        # 手动绘制两个连通分量以展示非连通图

        # 分量1
        c1_center = RIGHT * 3 + UP * 0.5
        d1 = Dot(c1_center + UP*0.8, color=TEAL)
        d2 = Dot(c1_center + LEFT*0.7, color=TEAL)
        d3 = Dot(c1_center + RIGHT*0.7, color=TEAL)
        l1 = Line(d1.get_center(), d2.get_center())
        l2 = Line(d1.get_center(), d3.get_center())
        comp1 = VGroup(d1, d2, d3, l1, l2)

        # 分量2
        c2_center = RIGHT * 3 + DOWN * 1.5
        d4 = Dot(c2_center + LEFT*0.5, color=MAROON)
        d5 = Dot(c2_center + RIGHT*0.5, color=MAROON)
        l3 = Line(d4.get_center(), d5.get_center())
        comp2 = VGroup(d4, d5, l3)

        graph_group = VGroup(comp1, comp2)

        # 连通性说明文字
        conn_header = Text("图的连通性判定", **left_config, color=BLUE).scale(1.1)
        conn_header.next_to(graph_group, UP, buff=0.5)

        conn_desc = Text("遍历调用次数 = 连通分量数", **left_config).scale(22/24)
        conn_desc.next_to(graph_group, DOWN, buff=0.4)

        # 边框
        rect1 = SurroundingRectangle(comp1, color=TEAL, buff=0.2)
        rect2 = SurroundingRectangle(comp2, color=MAROON, buff=0.2)

        label1 = Text("计数: 1", font="AR PL UKai CN", font_size=20, color=TEAL).next_to(rect1, RIGHT)
        label2 = Text("计数: 2", font="AR PL UKai CN", font_size=20, color=MAROON).next_to(rect2, RIGHT)

        right_group = VGroup(conn_header, graph_group, rect1, rect2, label1, label2, conn_desc)

        # 4. 动画流程
        # 左侧入场
        self.play(
            FadeIn(bfs_group, shift=RIGHT),
            run_time=1.5
        )

        # 右侧入场
        self.play(FadeIn(conn_header, shift=LEFT))
        self.play(
            Create(comp1),
            Create(comp2),
            run_time=1.5
        )

        # 强调连通分量
        self.play(
            Create(rect1),
            Write(label1),
            run_time=0.5
        )
        self.play(
            Create(rect2),
            Write(label2),
            run_time=0.5
        )

        # 总结文字
        self.play(Write(conn_desc))
