from manim import *

class CreativeSharingSession(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("创意分享环节",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 场景布局设计
        # 左侧:个人思考区 (Individual Ideation)
        start_x = -5
        y_pos = -1.5

        # 创建三个代表学生的圆圈
        student_1 = Circle(radius=0.4, color=BLUE, fill_opacity=0.5).move_to(RIGHT * (start_x) + UP * y_pos)
        student_2 = Circle(radius=0.4, color=TEAL, fill_opacity=0.5).move_to(RIGHT * (start_x + 1.5) + UP * y_pos)
        student_3 = Circle(radius=0.4, color=PURPLE, fill_opacity=0.5).move_to(RIGHT * (start_x + 3) + UP * y_pos)

        students = VGroup(student_1, student_2, student_3)
        student_label = Text("小组成员", font="AR PL UKai CN", font_size=20).next_to(students, DOWN)

        # 创建三个代表创意的便利贴 (初始在学生上方)
        idea_1 = Square(side_length=0.5, color=YELLOW, fill_opacity=0.8).next_to(student_1, UP, buff=0.2)
        idea_2 = Square(side_length=0.5, color=GREEN, fill_opacity=0.8).next_to(student_2, UP, buff=0.2)
        idea_3 = Square(side_length=0.5, color=RED, fill_opacity=0.8).next_to(student_3, UP, buff=0.2)

        ideas = VGroup(idea_1, idea_2, idea_3)
        idea_text = Text("初始创意", font="AR PL UKai CN", font_size=18).next_to(ideas, UP, buff=0.2)

        # 展示左侧元素
        self.play(FadeIn(students), Write(student_label))
        self.play(GrowFromCenter(idea_1), GrowFromCenter(idea_2), GrowFromCenter(idea_3), FadeIn(idea_text))

        # 右侧:公共展示区 (Public Display/Sharing Board)
        board = Rectangle(height=4, width=5, color=WHITE).to_edge(RIGHT, buff=1).shift(DOWN*0.5)
        board_label = Text("创意展示墙", font="AR PL UKai CN", font_size=24).next_to(board, UP)

        # 装饰展示板内部线条
        board_lines = VGroup(*[
            Line(board.get_left(), board.get_right(), stroke_width=1, color=GRAY).shift(UP * i)
            for i in range(-1, 2)
        ])

        self.play(Create(board), Create(board_lines), Write(board_label))

        # 3. 动画演示:分享过程
        # 定义箭头和动作文字
        arrow = Arrow(start=idea_text.get_right(), end=board.get_left(), color=GOLD, buff=0.5)
        action_text = Text("上台分享 & 粘贴", font="AR PL UKai CN", font_size=20, color=GOLD).next_to(arrow, UP)

        self.play(GrowArrow(arrow), Write(action_text))

        # 创意移动到展示板的不同位置
        target_1 = board.get_center() + UP * 1 + LEFT * 1.5
        target_2 = board.get_center() + UP * 1
        target_3 = board.get_center() + UP * 1 + RIGHT * 1.5

        self.play(
            idea_1.animate.move_to(target_1),
            idea_2.animate.move_to(target_2),
            idea_3.animate.move_to(target_3),
            run_time=2
        )

        # 4. 互评与反馈环节
        # 在创意下方出现反馈标记 (代表便利贴互动)
        feedback_1 = Star(color=ORANGE, fill_opacity=1).scale(0.2).next_to(idea_1, DR, buff=-0.1)
        feedback_2 = Star(color=ORANGE, fill_opacity=1).scale(0.2).next_to(idea_2, DR, buff=-0.1)

        # 高亮框选
        highlight_rect = SurroundingRectangle(VGroup(idea_1, idea_3), color=YELLOW, buff=0.2)
        highlight_text = Text("互相评价与迭代", font="AR PL UKai CN", font_size=24, color=YELLOW).next_to(board, DOWN)

        self.play(
            FadeIn(feedback_1),
            FadeIn(feedback_2),
            Create(highlight_rect),
            Write(highlight_text)
        )
