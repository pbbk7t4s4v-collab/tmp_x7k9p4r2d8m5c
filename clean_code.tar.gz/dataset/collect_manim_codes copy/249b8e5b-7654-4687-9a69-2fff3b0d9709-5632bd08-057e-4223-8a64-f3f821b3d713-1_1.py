from manim import *

class PKUvsTHUComparison(Scene):
    def construct(self):

        # 1. 标题部分
        title = Text("北京大学与清华大学的比较",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧北京大学
        pku_header = Text("北京大学", font="AR PL UKai CN", font_size=30, color=RED_D)
        pku_box = SurroundingRectangle(pku_header, color=RED_D, buff=0.2)
        pku_header_group = VGroup(pku_box, pku_header)

        pku_features = VGroup(
            Text("综合性大学", font="AR PL UKai CN", font_size=24),
            Text("文理基础学科强", font="AR PL UKai CN", font_size=24),
            Text("注重理论研究", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, buff=0.3, aligned_edge=LEFT)

        pku_full = VGroup(pku_header_group, pku_features).arrange(DOWN, buff=0.5)

        # 3. 内容布局 - 右侧清华大学
        thu_header = Text("清华大学", font="AR PL UKai CN", font_size=30, color=PURPLE_D)
        thu_box = SurroundingRectangle(thu_header, color=PURPLE_D, buff=0.2)
        thu_header_group = VGroup(thu_box, thu_header)

        thu_features = VGroup(
            Text("理工科大学", font="AR PL UKai CN", font_size=24),
            Text("工科技术顶尖", font="AR PL UKai CN", font_size=24),
            Text("强调工程应用", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, buff=0.3, aligned_edge=LEFT)

        thu_full = VGroup(thu_header_group, thu_features).arrange(DOWN, buff=0.5)

        # 4. 整体布局与中间分割
        content_group = VGroup(pku_full, thu_full).arrange(RIGHT, buff=2.5)
        content_group.next_to(title_line, DOWN, buff=0.8)

        # 中间的VS标志
        vs_text = Text("VS", font_size=40, color=YELLOW, weight=BOLD)
        vs_text.move_to(content_group.get_center())

        # 5. 动画展示
        # 展示左右标题
        self.play(
            Create(pku_box),
            Write(pku_header),
            Create(thu_box),
            Write(thu_header),
            run_time=1.5
        )

        # 展示VS
        self.play(FadeIn(vs_text, scale=1.5), run_time=0.5)

        # 展示特征列表
        self.play(
            FadeIn(pku_features, shift=UP),
            FadeIn(thu_features, shift=UP),
            run_time=1.5
        )
