from manim import *

class HamiltonianPhysicalMeaning(Scene):
    def construct(self):

        # 1. 标题部分
        title = Text("哈密顿量分量的物理意义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧文字，右侧图示

        # 左侧文字块 1: h_x, h_y
        term_xy = MathTex(r"h_x, h_y", color=YELLOW, font_size=36)
        label_xy = Text("(非对角项)", font="AR PL UKai CN", font_size=24, color=YELLOW)
        header_xy = VGroup(term_xy, label_xy).arrange(RIGHT, buff=0.2)

        desc_xy_1 = Text("来源于子晶格 A-B 最近邻跃迁", font="AR PL UKai CN", font_size=22)
        desc_xy_2 = Text("描述晶格的连通性", font="AR PL UKai CN", font_size=22)

        group_xy = VGroup(header_xy, desc_xy_1, desc_xy_2).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        group_xy.to_edge(LEFT, buff=1).shift(UP*0.5)

        # 左侧文字块 2: h_z
        term_z = MathTex(r"h_z", color=GREEN, font_size=36)
        label_z = Text("(对角项)", font="AR PL UKai CN", font_size=24, color=GREEN)
        header_z = VGroup(term_z, label_z).arrange(RIGHT, buff=0.2)

        desc_z_1 = Text("来源于次近邻跃迁(含相位)及质量项", font="AR PL UKai CN", font_size=22)
        desc_z_2 = Text("直接控制能隙的开启与闭合", font="AR PL UKai CN", font_size=22)

        group_z = VGroup(header_z, desc_z_1, desc_z_2).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        group_z.next_to(group_xy, DOWN, buff=0.8, aligned_edge=LEFT)

        # 右侧图示 - 简单的晶格模型示意
        # 定义点的位置
        origin = RIGHT * 3.5 + UP * 0.5
        pos_a = origin + LEFT * 1.2
        pos_b = origin + RIGHT * 1.2

        dot_a = Dot(pos_a, color=RED, radius=0.15)
        dot_b = Dot(pos_b, color=BLUE, radius=0.15)
        label_a = MathTex("A", color=RED).next_to(dot_a, UP)
        label_b = MathTex("B", color=BLUE).next_to(dot_b, UP)

        sites_group = VGroup(dot_a, dot_b, label_a, label_b)

        # 3. 动画演示流程

        # 演示 h_x, h_y 部分
        self.play(FadeIn(group_xy, shift=RIGHT))

        # 显示 A, B 格点
        self.play(FadeIn(sites_group))

        # 绘制最近邻跃迁 (hx, hy)
        line_nn = Line(pos_a, pos_b, color=YELLOW)
        arrow_nn_1 = Arrow(pos_a, pos_b, color=YELLOW, buff=0, max_tip_length_to_length_ratio=0.15)
        text_nn = MathTex(r"t_1", color=YELLOW, font_size=24).next_to(line_nn, UP, buff=0.1)

        self.play(Create(arrow_nn_1), Write(text_nn))

        rect_xy = SurroundingRectangle(group_xy, color=YELLOW, buff=0.1)
        self.play(Create(rect_xy))

        # 演示 h_z 部分
        self.play(FadeIn(group_z, shift=RIGHT))

        # 绘制次近邻跃迁 (hz) - 弯曲箭头
        path_nnn = ArcBetweenPoints(pos_a, pos_a + DOWN*1.5 + RIGHT*0.5, angle=-PI/1.5)
        # 这里为了简单展示，用一个自环或者同类格点跃迁示意
        # 修正：次近邻通常是 A->A，这里画一个指向自己的虚构位置或简单示意
        # 采用 A -> A 的环形箭头示意次近邻
        arrow_nnn = Arrow(
            start=pos_a + DOWN*0.1 + LEFT*0.1,
            end=pos_a + DOWN*0.1 + RIGHT*0.1,
            path_arc=-3, # 大弧度形成环
            color=GREEN,
            buff=0
        ).scale(2).shift(DOWN*0.6)

        text_nnn = MathTex(r"t_2 e^{i\phi}", color=GREEN, font_size=24).next_to(arrow_nnn, DOWN, buff=0.1)
        text_mass = Text("Mass Term m", font="AR PL UKai CN", font_size=20, color=GREEN).next_to(text_nnn, DOWN, buff=0.1)

        self.play(Create(arrow_nnn), Write(text_nnn), Write(text_mass))

        rect_z = SurroundingRectangle(group_z, color=GREEN, buff=0.1)
        self.play(Create(rect_z))
