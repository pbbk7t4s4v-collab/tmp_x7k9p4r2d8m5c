from manim import *

class AgileInitiationScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("敏捷项目启动:电梯演讲与干系人地图",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("48", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 电梯演讲 (Elevator Pitch)
        # ---------------------------------------------------------
        # 标题
        pitch_header = Text("1. 电梯演讲 (30秒价值陈述)", font="AR PL UKai CN", font_size=28, color=BLUE)
        pitch_header.next_to(title_line, DOWN, buff=0.5)
        pitch_header.to_edge(LEFT, buff=1)

        # 模板内容 - 使用Text模拟代码块,避免Code类的字体问题,并手动高亮
        # 定义每一行文本
        lines_config = [
            ("对于 [目标客户]", {"[目标客户]": YELLOW}),
            ("他们 [需求或痛点]", {"[需求或痛点]": YELLOW}),
            ("我们的 [产品名称] 是一个 [产品类别]", {"[产品名称]": YELLOW, "[产品类别]": YELLOW}),
            ("它可以 [核心价值]", {"[核心价值]": YELLOW}),
            ("不同于 [竞争对手]", {"[竞争对手]": YELLOW}),
            ("我们的产品 [关键差异]", {"[关键差异]": YELLOW}),
        ]

        pitch_lines = VGroup()
        for text_str, color_map in lines_config:
            line = Text(text_str, font="AR PL UKai CN", font_size=24, t2c=color_map)
            pitch_lines.add(line)

        # 排版:左对齐,垂直排列
        pitch_lines.arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        pitch_lines.next_to(pitch_header, DOWN, buff=0.2, aligned_edge=LEFT)

        # 添加外框
        pitch_box = SurroundingRectangle(pitch_lines, color=WHITE, buff=0.2, corner_radius=0.1)
        pitch_label = Text("模板", font="AR PL UKai CN", font_size=20, color=GRAY).next_to(pitch_box, UP, buff=0.1, aligned_edge=RIGHT)

        pitch_group = VGroup(pitch_header, pitch_lines, pitch_box, pitch_label)

        # ---------------------------------------------------------
        # 3. 干系人地图 (Stakeholder Map)
        # ---------------------------------------------------------
        # 标题
        map_header = Text("2. 干系人地图", font="AR PL UKai CN", font_size=28, color=BLUE)
        # 布局在右侧或者下方,考虑到屏幕比例,放在下方比较合适,或者右侧
        # 这里选择放在右侧,与左侧的电梯演讲并列,充分利用宽屏
        map_header.next_to(title_line, DOWN, buff=0.5)
        map_header.to_edge(RIGHT, buff=2) # 稍微靠右

        # 核心步骤可视化:识别 -> 分析 -> 策略

        # 定义节点创建函数
        def create_node(text, subtext):
            box = Rectangle(height=1.2, width=2.2, color=TEAL, fill_opacity=0.2, fill_color=TEAL_E)
            t = Text(text, font="AR PL UKai CN", font_size=24).move_to(box.get_center() + UP*0.2)
            s = Text(subtext, font="AR PL UKai CN", font_size=16, color=LIGHT_GRAY).next_to(t, DOWN, buff=0.1)
            return VGroup(box, t, s)

        node1 = create_node("识别", "所有利益相关方")
        node2 = create_node("分析", "影响力 & 利益")
        node3 = create_node("策略", "参与 & 管理")

        # 垂直排列在右侧标题下方
        nodes = VGroup(node1, node2, node3).arrange(DOWN, buff=0.4)
        nodes.next_to(map_header, DOWN, buff=0.3)

        # 添加箭头
        arrow1 = Arrow(start=node1.get_bottom(), end=node2.get_top(), buff=0.05, color=GREY)
        arrow2 = Arrow(start=node2.get_bottom(), end=node3.get_top(), buff=0.05, color=GREY)

        map_group = VGroup(map_header, nodes, arrow1, arrow2)

        # ---------------------------------------------------------
        # 4. 动画播放
        # ---------------------------------------------------------

        # 第一部分:展示电梯演讲
        self.play(FadeIn(pitch_header, shift=RIGHT))
        self.play(Create(pitch_box), Write(pitch_label))
        self.play(Write(pitch_lines), run_time=2.5)

        # 第二部分:展示干系人地图
        self.play(FadeIn(map_header, shift=LEFT))
        self.play(
            FadeIn(node1, shift=UP),
        )
        self.play(
            GrowArrow(arrow1),
            FadeIn(node2, shift=UP)
        )
        self.play(
            GrowArrow(arrow2),
            FadeIn(node3, shift=UP)
        )
