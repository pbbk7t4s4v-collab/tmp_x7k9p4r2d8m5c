from manim import *

class Unit2WarmUp(Scene):
    def construct(self):

        # 1. 标题部分 (严格按照模板要求)
        title = Text("课程导入与热身",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 播放标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 左侧:话题引入 (Greeting)
        topic_label = Text("话题引入", font="AR PL UKai CN", font_size=24, color=BLUE)

        greeting_eng = Text("How was your weekend?", font="AR PL UKai CN", font_size=28)
        greeting_cn = Text("周末与家人过得如何?", font="AR PL UKai CN", font_size=24, color=GRAY_B)

        # 组合文本
        greeting_content = VGroup(greeting_eng, greeting_cn).arrange(DOWN, buff=0.2)

        # 组合标签和内容
        left_group = VGroup(topic_label, greeting_content).arrange(DOWN, buff=0.4)
        left_group.to_edge(LEFT, buff=1.5).shift(UP * 0.5)

        # 添加边框
        left_box = SurroundingRectangle(greeting_content, color=BLUE, buff=0.3)

        # 右侧:回顾复习 (Review)
        review_label = Text("旧知回顾", font="AR PL UKai CN", font_size=24, color=GREEN)

        review_title = Text("上一单元:喜好活动", font="AR PL UKai CN", font_size=26)
        # 手动创建列表以确保中文字体支持
        item1 = Text("• Swimming (游泳)", font="AR PL UKai CN", font_size=24)
        item2 = Text("• Drawing (画画)", font="AR PL UKai CN", font_size=24)

        review_content = VGroup(review_title, item1, item2).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # 组合标签和内容
        right_group = VGroup(review_label, review_content).arrange(DOWN, buff=0.4)
        right_group.to_edge(RIGHT, buff=1.5).shift(UP * 0.5)

        # 添加边框
        right_box = SurroundingRectangle(review_content, color=GREEN, buff=0.3)

        # 中间连接箭头
        arrow = Arrow(left_box.get_right(), right_box.get_left(), color=YELLOW, buff=0.2)
        arrow_text = Text("关联", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(arrow, UP, buff=0.1)

        # 3. 动画展示流程
        # 展示左侧话题引入
        self.play(
            FadeIn(topic_label, shift=DOWN),
            Create(left_box),
            Write(greeting_content)
        )

        # 展示连接
        self.play(
            GrowArrow(arrow),
            FadeIn(arrow_text)
        )

        # 展示右侧复习内容
        self.play(
            FadeIn(review_label, shift=DOWN),
            Create(right_box),
            Write(review_content)
        )

        # 4. 结尾停留
