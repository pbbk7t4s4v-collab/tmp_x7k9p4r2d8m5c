from manim import *

class ParametricSurfaceArea(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (Title Setup)
        # ---------------------------------------------------------
        title = Text("参数曲面的面积",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("44", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 定义部分 (Definition Section)
        # ---------------------------------------------------------
        # 使用 VGroup 整理布局，避免遮挡

        # 左侧标签
        label_def = Text("1. 参数方程定义：", font_size=26, font="AR PL UKai CN", color=BLUE_A)

        # 参数方程公式
        tex_def = MathTex(
            r"\mathbf{r}(u, v) = (x(u,v), y(u,v), z(u,v))",
            font_size=30
        )

        # 区域定义
        tex_domain = MathTex(r"(u,v) \in D", font_size=30)

        # 组合定义部分
        group_def = VGroup(label_def, tex_def, tex_domain).arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        group_def.to_edge(LEFT, buff=1.0).shift(UP * 1.5)

        self.play(FadeIn(group_def, shift=RIGHT))

        # ---------------------------------------------------------
        # 3. 偏导数部分 (Partial Derivatives Section)
        # ---------------------------------------------------------

        label_deriv = Text("2. 计算切向量（偏导数）：", font_size=26, font="AR PL UKai CN", color=BLUE_A)

        # 偏导数公式
        tex_deriv = MathTex(
            r"\mathbf{r}_u = \frac{\partial \mathbf{r}}{\partial u}, \quad \mathbf{r}_v = \frac{\partial \mathbf{r}}{\partial v}",
            font_size=30
        )

        group_deriv = VGroup(label_deriv, tex_deriv).arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        group_deriv.next_to(group_def, DOWN, buff=0.6, aligned_edge=LEFT)

        self.play(FadeIn(group_deriv, shift=RIGHT))

        # ---------------------------------------------------------
        # 4. 面积公式部分 (Area Formula Section)
        # ---------------------------------------------------------

        label_formula = Text("3. 曲面面积积分公式：", font_size=28, font="AR PL UKai CN", color=YELLOW)

        # 核心公式
        tex_formula = MathTex(
            r"A = \iint_D |\mathbf{r}_u \times \mathbf{r}_v| \, du \, dv",
            font_size=38
        )

        # 布局公式部分
        group_formula = VGroup(label_formula, tex_formula).arrange(DOWN, buff=0.3)
        # 放置在屏幕下方中央
        group_formula.move_to(DOWN * 1.5)

        # ---------------------------------------------------------
        # 5. 强调与注释 (Highlights & Annotations)
        # ---------------------------------------------------------

        # 这里的矩形框强调核心公式
        rect = SurroundingRectangle(tex_formula, color=ORANGE, buff=0.2, stroke_width=2)

        # 对叉积模长的解释（注释）
        # 指向公式中的叉积部分
        arrow = Arrow(start=RIGHT, end=LEFT, color=GRAY, buff=0.1).scale(0.6)
        arrow.next_to(rect, RIGHT, buff=0.2)

        note_text = Text("面积微元\n(切向量叉积的模)", font_size=20, font="AR PL UKai CN", color=GRAY)
        note_text.next_to(arrow, RIGHT, buff=0.1)

        # 播放公式相关动画
        self.play(Write(label_formula))
        self.play(Write(tex_formula))
        self.play(
            Create(rect),
            FadeIn(arrow),
            FadeIn(note_text)
        )
