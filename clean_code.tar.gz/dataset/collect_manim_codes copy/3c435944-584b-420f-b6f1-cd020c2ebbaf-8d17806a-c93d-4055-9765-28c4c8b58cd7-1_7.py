from manim import *

class ConvexUnitBallExample(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("凸集示例：单位球与几何直观",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局规划：左侧几何图形，右侧数学推导
        # 左侧：可视化单位球
        left_center = LEFT * 3.5 + DOWN * 0.5

        # 简单的坐标轴示意
        axes = Axes(
            x_range=[-1.5, 1.5], y_range=[-1.5, 1.5],
            x_length=4, y_length=4,
            axis_config={"include_tip": True, "tip_shape": StealthTip}
        ).move_to(left_center)

        # 单位球 B
        unit_circle = Circle(radius=1.5, color=BLUE, fill_opacity=0.3).move_to(axes.c2p(0,0))
        label_B = MathTex("B").next_to(unit_circle, UP+LEFT, buff=0)

        # 凸性定义的点和线
        p1_coords = axes.c2p(-0.5, 0.8)
        p2_coords = axes.c2p(0.8, -0.4)

        dot1 = Dot(p1_coords, color=YELLOW)
        dot2 = Dot(p2_coords, color=YELLOW)
        label_x1 = MathTex("x_1", font_size=24).next_to(dot1, UP)
        label_x2 = MathTex("x_2", font_size=24).next_to(dot2, DOWN)

        line_seg = Line(p1_coords, p2_coords, color=RED)
        label_x = MathTex("x", font_size=24, color=RED).next_to(line_seg.get_center(), UP, buff=0.1)

        visual_group = VGroup(axes, unit_circle, label_B, dot1, dot2, label_x1, label_x2, line_seg, label_x)

        # 3. 右侧：数学推导
        # 公式内容
        math_scale = 0.75
        step1 = MathTex(r"x = \theta x_1 + (1-\theta)x_2", font_size=32).set_color(RED)

        # 三角不等式推导
        step2 = MathTex(r"\|x\|_2 \leq \theta\|x_1\|_2 + (1-\theta)\|x_2\|_2", font_size=32)

        # 利用单位球性质
        step3 = MathTex(r"\leq \theta(1) + (1-\theta)(1) = 1", font_size=32)

        # 结论
        conclusion = Text("由此证明单位球是凸集", font="AR PL UKai CN", font_size=28, color=GREEN)

        # 其它例子
        others = Text("其他凸集：半空间、多面体、椭球", font="AR PL UKai CN", font_size=24, color=GRAY)

        # 排版右侧元素
        right_group = VGroup(step1, step2, step3, conclusion, others).arrange(DOWN, buff=0.4, aligned_edge=LEFT)
        right_group.to_edge(RIGHT, buff=1.0).shift(DOWN * 0.5)

        # 4. 动画流程

        # 显示左侧几何直观 (快速)
        self.play(FadeIn(axes), Create(unit_circle), Write(label_B), run_time=1.5)
        self.play(
            FadeIn(dot1), FadeIn(dot2), Write(label_x1), Write(label_x2),
            Create(line_seg), Write(label_x),
            run_time=1.5
        )

        # 显示右侧推导 (逐步)
        self.play(Write(step1), run_time=1)
        self.play(FadeIn(step2, shift=LEFT), run_time=1)
        self.play(FadeIn(step3, shift=LEFT), run_time=1)

        # 强调结论
        box = SurroundingRectangle(conclusion, color=GREEN, buff=0.1)
        self.play(Write(conclusion), Create(box), run_time=1)

        # 显示底部其他例子
        self.play(FadeIn(others, shift=UP), run_time=1)
