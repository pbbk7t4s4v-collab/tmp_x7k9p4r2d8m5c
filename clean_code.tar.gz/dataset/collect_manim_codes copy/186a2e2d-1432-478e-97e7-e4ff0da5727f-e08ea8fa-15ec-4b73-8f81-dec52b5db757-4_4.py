from manim import *

class DescendingSortExercise(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (符合模板要求)
        # ---------------------------------------------------------
        title = Text("课堂练习：数组降序排列",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("11", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 布局设计：左侧代码逻辑，右侧数据演示
        # ---------------------------------------------------------

        # --- 左侧：代码修改演示 ---
        # 手动构建代码行以便单独操作运算符
        code_part1 = Text("if arr[j]", font="Monospace", font_size=32, color=WHITE)
        operator_old = Text(">", font="Monospace", font_size=32, color=RED)
        code_part2 = Text("arr[j+1]:", font="Monospace", font_size=32, color=WHITE)

        # 组合代码行
        code_line = VGroup(code_part1, operator_old, code_part2).arrange(RIGHT, buff=0.2)

        code_label = Text("基础排序逻辑", font="AR PL UKai CN", font_size=24, color=BLUE)
        code_label.next_to(code_line, UP, buff=0.5)

        left_group = VGroup(code_label, code_line).move_to(LEFT * 3)

        # --- 右侧：数组可视化 ---
        # 初始数据 [3, 1, 4, 1, 5]
        data_values = [3, 1, 4, 1, 5]
        squares = VGroup(*[Square(side_length=1.0, color=BLUE_C) for _ in range(5)]).arrange(RIGHT, buff=0.1)
        numbers = VGroup()
        for i, val in enumerate(data_values):
            num = Text(str(val), font_size=36).move_to(squares[i].get_center())
            numbers.add(num)

        array_group = VGroup(squares, numbers).move_to(RIGHT * 3)
        array_label = Text("当前状态", font="AR PL UKai CN", font_size=24, color=BLUE)
        array_label.next_to(array_group, UP, buff=0.5)

        # ---------------------------------------------------------
        # 3. 动画演示流程
        # ---------------------------------------------------------

        # 第一步：展示初始状态
        self.play(
            FadeIn(left_group),
            FadeIn(array_label),
            Create(squares),
            Write(numbers)
        )

        # 第二步：强调修改点
        focus_rect = SurroundingRectangle(operator_old, color=YELLOW, buff=0.1)
        hint_text = Text("修改此处为小于号", font="AR PL UKai CN", font_size=20, color=YELLOW)
        hint_text.next_to(focus_rect, DOWN, buff=0.2)

        self.play(Create(focus_rect), Write(hint_text))

        # 第三步：执行修改 (由 > 变为 <)
        operator_new = Text("<", font="Monospace", font_size=32, color=GREEN)
        operator_new.move_to(operator_old.get_center())

        new_code_label = Text("降序排序逻辑", font="AR PL UKai CN", font_size=24, color=GREEN)
        new_code_label.move_to(code_label)

        self.play(
            Transform(operator_old, operator_new),
            Transform(code_label, new_code_label)
        )

        # 第四步：展示结果变化
        # 目标降序数据 [5, 4, 3, 1, 1]
        sorted_values = [5, 4, 3, 1, 1]
        sorted_numbers = VGroup()
        for i, val in enumerate(sorted_values):
            num = Text(str(val), font_size=36).move_to(squares[i].get_center())
            sorted_numbers.add(num)

        new_array_label = Text("降序结果", font="AR PL UKai CN", font_size=24, color=GREEN)
        new_array_label.move_to(array_label)

        self.play(
            FadeOut(focus_rect),
            FadeOut(hint_text),
            Transform(numbers, sorted_numbers),
            Transform(array_label, new_array_label)
        )

        # 结束停顿
