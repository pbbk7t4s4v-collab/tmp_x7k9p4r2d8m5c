from manim import *

class GenericProgramming(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("C++ 泛型编程：模板 (Templates)",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("11", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念文本
        concept_text = Text(
            "概念：编写与类型无关的代码，编译时自动生成对应类型",
            font="AR PL UKai CN",
            font_size=24,
            color=LIGHT_GRAY
        )
        concept_text.next_to(title_line, DOWN, buff=0.3)
        self.play(FadeIn(concept_text, shift=DOWN * 0.2))

        # 3. 视觉化展示：左侧模板定义
        # 使用 Text 模拟代码结构，避免 Code 类的兼容性问题
        template_str = "template <typename T>\nstruct Node {\n    T data;\n    Node* next;\n};"
        template_code = Text(
            template_str,
            font="AR PL UKai CN",
            font_size=22,
            line_spacing=1.2,
            t2c={"T": RED, "Node": BLUE, "struct": ORANGE, "template": ORANGE, "typename": ORANGE}
        )
        template_code.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        template_box = SurroundingRectangle(template_code, color=BLUE, buff=0.2)
        template_label = Text("通用模板 (Blueprint)", font="AR PL UKai CN", font_size=20, color=BLUE)
        template_label.next_to(template_box, UP, buff=0.1)

        self.play(
            Create(template_box),
            Write(template_label),
            Write(template_code, run_time=1.5)
        )

        # 4. 中间过程：编译生成
        arrow = Arrow(start=LEFT, end=RIGHT, color=WHITE).next_to(template_box, RIGHT, buff=0.5)
        compile_txt = Text("编译时实例化", font="AR PL UKai CN", font_size=18, color=YELLOW)
        compile_txt.next_to(arrow, UP, buff=0.05)

        self.play(GrowArrow(arrow), FadeIn(compile_txt))

        # 5. 右侧应用：具体类型实例
        # 实例 1: int
        node_int = Text("Node<int>", font="AR PL UKai CN", font_size=22, t2c={"int": RED})
        box_int = SurroundingRectangle(node_int, color=RED, buff=0.15)
        g_int = VGroup(box_int, node_int)

        # 实例 2: string
        node_str = Text("Node<string>", font="AR PL UKai CN", font_size=22, t2c={"string": GREEN})
        box_str = SurroundingRectangle(node_str, color=GREEN, buff=0.15)
        g_str = VGroup(box_str, node_str)

        # 实例 3: Employee
        node_emp = Text("Node<Employee>", font="AR PL UKai CN", font_size=22, t2c={"Employee": PURPLE})
        box_emp = SurroundingRectangle(node_emp, color=PURPLE, buff=0.15)
        g_emp = VGroup(box_emp, node_emp)

        # 排列右侧元素
        instances = VGroup(g_int, g_str, g_emp).arrange(DOWN, buff=0.5)
        instances.next_to(arrow, RIGHT, buff=0.5)

        # 依次展示实例
        self.play(FadeIn(g_int, shift=LEFT))
        self.play(FadeIn(g_str, shift=LEFT))
        self.play(FadeIn(g_emp, shift=LEFT))

        # 6. 总结标签
        summary = Text("一套代码 -> 支持多种数据类型", font="AR PL UKai CN", font_size=24, color=GOLD)
        summary.next_to(instances, DOWN, buff=0.5).shift(LEFT * 1.5)

        # 确保总结文字不超出屏幕下边缘
        if summary.get_bottom()[1] < -3.5:
            summary.shift(UP * 0.5)

        self.play(Write(summary))
