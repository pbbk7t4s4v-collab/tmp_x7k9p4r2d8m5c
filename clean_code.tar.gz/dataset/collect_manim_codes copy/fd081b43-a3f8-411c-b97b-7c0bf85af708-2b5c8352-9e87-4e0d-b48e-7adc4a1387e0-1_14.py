from manim import *

class KeynesianCrossScene(Scene):
    def construct(self):

        # --- 1. 标题设置 (严格按照模板) ---
        title = Text("均衡的图形表示：凯恩斯十字图",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("14", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- 2. 布局规划 ---
        # 左侧放图表,右侧放说明文字

        # --- 3. 图表绘制 (左侧) ---
        # 创建坐标轴
        ax = Axes(
            x_range=[0, 8, 1],
            y_range=[0, 8, 1],
            x_length=5.5,
            y_length=5.5,
            axis_config={
                "include_tip": True,
                "include_numbers": False,
                "color": GREY
            }
        ).to_edge(LEFT, buff=0.8).shift(DOWN * 0.3)

        # 坐标轴标签
        y_label = MathTex("E", color=WHITE).next_to(ax.y_axis, UP, buff=0.1)
        x_label = MathTex("Y", color=WHITE).next_to(ax.x_axis, RIGHT, buff=0.1)

        # 45度线: Y = E
        line_45 = ax.plot(lambda x: x, color=WHITE, x_range=[0, 7.5])
        label_45 = MathTex("Y=E", font_size=26).next_to(line_45.get_end(), UP, buff=0.1).shift(LEFT*0.5)

        # 总支出曲线 (假设 E = 2 + 0.6Y)
        # 均衡点计算: Y = 2 + 0.6Y => 0.4Y = 2 => Y = 5
        line_ae = ax.plot(lambda x: 2 + 0.6*x, color=YELLOW, x_range=[0, 7.5])
        label_ae = MathTex("E = C_0 + cY + I + G", font_size=26, color=YELLOW)
        label_ae.next_to(line_ae.get_end(), DOWN, buff=0.1).shift(LEFT*2)

        # 均衡点
        eq_val = 5
        eq_point = Dot(ax.c2p(eq_val, eq_val), color=RED, radius=0.1)

        # 虚线垂线指向横轴
        dashed_line = DashedLine(
            start=ax.c2p(eq_val, eq_val),
            end=ax.c2p(eq_val, 0),
            color=RED
        )
        label_ystar = MathTex("Y^*", color=RED).next_to(dashed_line, DOWN, buff=0.1)

        # --- 4. 文字说明 (右侧) ---
        # 使用 VGroup 排版,避免 BulletedList 的潜在问题
        text_config = {"font": "AR PL UKai CN", "font_size": 22, "color": WHITE}

        item1 = Text("• 横轴：收入 Y,纵轴:支出 E", **text_config)
        item2 = Text("• 45度线：Y = E 的轨迹", **text_config)
        item3 = Text("• 黄线：总支出曲线 (斜率 c)", **text_config)
        item4 = Text("• 交点：均衡国民收入 Y*", **text_config)
        item5 = Text("• 此时企业产品被完全购买", **text_config)

        # 组合文本并排版
        text_group = VGroup(item1, item2, item3, item4, item5)
        text_group.arrange(DOWN, aligned_edge=LEFT, buff=0.35)
        text_group.to_edge(RIGHT, buff=0.8).shift(UP * 0.5)

        # 强调框
        rect = SurroundingRectangle(item5, color=BLUE, buff=0.1)
        rect_label = Text("市场出清,无非计划存货", font="AR PL UKai CN", font_size=18, color=BLUE)
        rect_label.next_to(rect, DOWN, buff=0.1)

        # --- 5. 动画流程 ---

        # 第一步：显示坐标轴和含义
        self.play(
            Create(ax),
            Write(y_label),
            Write(x_label),
            FadeIn(item1, shift=LEFT),
            run_time=1.5
        )

        # 第二步：画出45度线
        self.play(
            Create(line_45),
            Write(label_45),
            FadeIn(item2, shift=LEFT),
            run_time=1.5
        )

        # 第三步：画出总支出曲线
        self.play(
            Create(line_ae),
            Write(label_ae),
            FadeIn(item3, shift=LEFT),
            run_time=1.5
        )

        # 第四步：标示均衡点
        self.play(
            FadeIn(eq_point, scale=0.5),
            Create(dashed_line),
            Write(label_ystar),
            FadeIn(item4, shift=LEFT),
            run_time=1.5
        )

        # 第五步：总结含义
        self.play(
            FadeIn(item5),
            Create(rect),
            Write(rect_label),
            run_time=1.5
        )
