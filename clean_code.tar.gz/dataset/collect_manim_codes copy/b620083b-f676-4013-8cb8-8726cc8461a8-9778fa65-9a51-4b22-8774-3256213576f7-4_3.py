from manim import *

class PolymorphismTypeConversion(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("多态中的类型转换",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("16", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 视觉模型构建 (右侧展示内存模型)
        # ---------------------------------------------------------
        # 派生类对象内存模型:包含基类部分和派生类特有部分
        derived_box = Rectangle(width=3, height=4, color=BLUE, fill_opacity=0.2)

        # 分隔线
        sep_line = Line(start=derived_box.get_left(), end=derived_box.get_right())
        sep_line.move_to(derived_box.get_center() + UP * 0.5)

        # 标签
        base_label = Text("基类部分 (Base)", font="AR PL UKai CN", font_size=20, color=BLUE_A)
        base_label.move_to(derived_box.get_top() + DOWN * 0.75)

        derived_label = Text("派生类特有成员", font="AR PL UKai CN", font_size=20, color=WHITE)
        derived_label.move_to(derived_box.get_bottom() + UP * 1)

        object_label = Text("派生类对象内存", font="AR PL UKai CN", font_size=24, color=YELLOW)
        object_label.next_to(derived_box, UP, buff=0.2)

        visual_group = VGroup(derived_box, sep_line, base_label, derived_label, object_label)
        visual_group.to_edge(RIGHT, buff=1.5).shift(DOWN*0.5)

        # ---------------------------------------------------------
        # 3. 文本内容构建 (左侧展示三种转换方式)
        # ---------------------------------------------------------
        # 定义辅助函数创建文本项
        def create_item(text_str, code_str, color=WHITE):
            t = Text(text_str, font="AR PL UKai CN", font_size=24, color=color)
            c = Text(code_str, font="AR PL UKai CN", font_size=20, color=YELLOW) # 使用Text模拟代码以保持字体一致且避免Code类的bug
            return VGroup(t, c).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        item1 = create_item("1. 派生类对象赋给基类对象", "Base b = derived_obj;")
        item2 = create_item("2. 基类指针指向派生类对象", "Base* ptr = &derived_obj;")
        item3 = create_item("3. 基类对象引用派生类对象", "Base& ref = derived_obj;")

        text_group = VGroup(item1, item2, item3).arrange(DOWN, aligned_edge=LEFT, buff=0.8)
        text_group.to_edge(LEFT, buff=1.0).shift(UP*0.5)

        # ---------------------------------------------------------
        # 4. 动画流程
        # ---------------------------------------------------------

        # 4.1 显示内存模型
        self.play(FadeIn(visual_group, shift=LEFT), run_time=1)

        # 4.2 第一点:对象赋值 (强调对象切割/Slicing)
        self.play(FadeIn(item1, shift=RIGHT))

        # 高亮基类部分,暗示只拷贝了这一部分
        highlight_rect = SurroundingRectangle(
            VGroup(sep_line, base_label, derived_box),
            color=RED,
            buff=0.05,
            stroke_width=2
        )
        # 调整高亮框位置以匹配上半部分
        highlight_rect.stretch_to_fit_height(1.5).align_to(derived_box, UP)

        self.play(Create(highlight_rect))
        self.play(FadeOut(highlight_rect))

        # 4.3 第二点:指针指向 (强调可视范围)
        self.play(FadeIn(item2, shift=RIGHT))

        # 箭头指向基类部分
        pointer_arrow = Arrow(
            start=visual_group.get_left() + LEFT,
            end=base_label.get_center() + LEFT*1.5,
            color=GREEN,
            buff=0.1
        )
        pointer_text = Text("ptr", font="AR PL UKai CN", font_size=20, color=GREEN).next_to(pointer_arrow, UP, buff=0.05)

        self.play(GrowArrow(pointer_arrow), Write(pointer_text))

        # 再次框选基类部分,表示指针只能看到这里
        scope_rect = SurroundingRectangle(
            VGroup(sep_line, base_label, derived_box),
            color=GREEN,
            buff=0.05
        )
        scope_rect.stretch_to_fit_height(1.5).align_to(derived_box, UP)

        self.play(Create(scope_rect))

        # 4.4 第三点:引用绑定 (类似指针,视作别名)
        self.play(FadeIn(item3, shift=RIGHT))

        # 修改箭头文字为 ref
        ref_text = Text("ref", font="AR PL UKai CN", font_size=20, color=ORANGE).move_to(pointer_text)

        self.play(
            Transform(pointer_text, ref_text),
            scope_rect.animate.set_color(ORANGE),
            pointer_arrow.animate.set_color(ORANGE)
        )
