from manim import *

class RandomVsDeterministic(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("随机现象与确定性现象",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局辅助函数
        # ---------------------------------------------------------
        def create_section(title_text, items, color, pos_direction):
            # 标题
            header = Text(title_text, font="AR PL UKai CN", font_size=28, color=color)

            # 列表项
            list_items = VGroup()
            for item_text in items:
                # 手动构建列表项,避免BulletedList的兼容性问题
                dot = MathTex(r"\bullet", color=color).scale(0.8)
                txt = Text(item_text, font="AR PL UKai CN", font_size=24, color=WHITE)
                row = VGroup(dot, txt).arrange(RIGHT, buff=0.2)
                list_items.add(row)

            # 左对齐列表
            list_items.arrange(DOWN, buff=0.3, aligned_edge=LEFT)

            # 组合标题和列表
            group = VGroup(header, list_items).arrange(DOWN, buff=0.5)

            # 边框
            box = SurroundingRectangle(group, color=color, buff=0.3)

            return group, box, list_items

        # ---------------------------------------------------------
        # 3. 创建左右两侧内容
        # ---------------------------------------------------------

        # 左侧:随机现象
        random_items_text = [
            "彩票中奖号码",
            "股市指数涨跌",
            "射击命中环数"
        ]
        random_group, random_box, random_list = create_section(
            "随机现象", random_items_text, BLUE, LEFT
        )

        # 右侧:确定性现象
        determ_items_text = [
            "抛石块落地",
            "导体通电发热",
            "异性电荷相吸"
        ]
        determ_group, determ_box, determ_list = create_section(
            "确定性现象", determ_items_text, GREEN, RIGHT
        )

        # ---------------------------------------------------------
        # 4. 定位与排版
        # ---------------------------------------------------------
        # 将两组内容并排,居中放置在标题下方
        content_group = VGroup(random_group, determ_group).arrange(RIGHT, buff=2.0)
        content_group.next_to(title_line, DOWN, buff=1.0)

        # 更新边框位置(因为group移动了,box需要重新定位)
        random_box.move_to(random_group)
        determ_box.move_to(determ_group)

        # VS 符号
        vs_text = Text("VS", font_size=40, color=YELLOW, weight=BOLD).move_to(content_group.get_center())

        # ---------------------------------------------------------
        # 5. 动画序列
        # ---------------------------------------------------------

        # 左侧入场
        self.play(FadeIn(random_group[0], shift=DOWN), run_time=0.8) # 标题
        self.play(Create(random_box), run_time=0.8)
        self.play(Write(random_list), run_time=2) # 列表逐个写出

        # 中间VS
        self.play(ScaleInPlace(vs_text, 1.2), run_time=0.5)
        self.play(ScaleInPlace(vs_text, 1.0/1.2), run_time=0.3)

        # 右侧入场
        self.play(FadeIn(determ_group[0], shift=DOWN), run_time=0.8) # 标题
        self.play(Create(determ_box), run_time=0.8)
        self.play(Write(determ_list), run_time=2) # 列表逐个写出

        # 停留
