from manim import *

class InflectionVsDerivation(Scene):
    def construct(self):

        # 1. Title Section (Standard Template)
        title = Text("Inflection vs Derivation",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # Bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Group title elements
        title_group = VGroup(title, title_line)

        # Title Animation
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Layout Setup
        # Vertical Separator
        separator = Line(UP, DOWN, color=GRAY).set_length(5)
        separator.next_to(title_line, DOWN, buff=0.5)

        # 3. Left Side: Inflection Content
        inf_title = Text("Inflection", font_size=30, color=BLUE, weight=BOLD)

        # Example: walk -> walked
        inf_ex_1 = MathTex(r"\text{walk}", font_size=36)
        inf_arrow = Arrow(LEFT, RIGHT, color=BLUE).scale(0.5)
        inf_ex_2 = MathTex(r"\text{walk}\textbf{ed}", font_size=36)
        # Color the suffix
        inf_ex_2[0][4:].set_color(BLUE)

        inf_group_ex = VGroup(inf_ex_1, inf_arrow, inf_ex_2).arrange(RIGHT, buff=0.2)

        # Characteristics
        inf_desc = VGroup(
            Text("• Grammatical change", font_size=22),
            Text("• Same part of speech", font_size=22),
            Text("(Verb $\\rightarrow$ Verb)", font_size=22, color=GRAY_A)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # Assemble Left Column
        left_col = VGroup(inf_title, inf_group_ex, inf_desc).arrange(DOWN, buff=0.6)
        left_col.next_to(separator, LEFT, buff=1.0)

        # 4. Right Side: Derivation Content
        der_title = Text("Derivation", font_size=30, color=GREEN, weight=BOLD)

        # Example: teach -> teacher
        der_ex_1 = MathTex(r"\text{teach}", font_size=36)
        der_arrow = Arrow(LEFT, RIGHT, color=GREEN).scale(0.5)
        der_ex_2 = MathTex(r"\text{teach}\textbf{er}", font_size=36)
        # Color the suffix
        der_ex_2[0][5:].set_color(GREEN)

        der_group_ex = VGroup(der_ex_1, der_arrow, der_ex_2).arrange(RIGHT, buff=0.2)

        # Characteristics
        der_desc = VGroup(
            Text("• Creates new word", font_size=22),
            Text("• Changes meaning/category", font_size=22),
            Text("(Verb $\\rightarrow$ Noun)", font_size=22, color=GRAY_A)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # Assemble Right Column
        right_col = VGroup(der_title, der_group_ex, der_desc).arrange(DOWN, buff=0.6)
        right_col.next_to(separator, RIGHT, buff=1.0)

        # 5. Animations
        # Show structure
        self.play(
            Create(separator),
            FadeIn(inf_title, shift=DOWN),
            FadeIn(der_title, shift=DOWN)
        )

        # Show Examples
        self.play(
            Write(inf_group_ex),
            Write(der_group_ex)
        )

        # Show Descriptions
        self.play(
            FadeIn(inf_desc, shift=UP),
            FadeIn(der_desc, shift=UP)
        )

        # 6. Highlight Difference
        # Highlight "Same POS" vs "Changes Category"
        rect_inf = SurroundingRectangle(inf_desc, color=BLUE, buff=0.15)
        rect_der = SurroundingRectangle(der_desc, color=GREEN, buff=0.15)

        self.play(
            Create(rect_inf),
            Create(rect_der),
            run_time=1.5
        )
