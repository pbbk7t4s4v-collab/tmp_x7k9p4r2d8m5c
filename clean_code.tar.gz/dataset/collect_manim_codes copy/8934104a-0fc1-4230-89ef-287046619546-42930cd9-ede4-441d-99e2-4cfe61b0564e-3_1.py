from manim import *
import random

class DataDimReduction(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("数据降维：动机与目标",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局规划
        # 左侧：高维困境
        # 右侧：降维目标

        # 定义辅助函数创建中文列表（避免BulletedList的LaTeX中文问题）
        def create_cn_list(items, color=WHITE):
            group = VGroup()
            for item in items:
                dot = Dot(color=ORANGE, radius=0.06)
                text = Text(item, font="AR PL UKai CN", font_size=24, color=color)
                row = VGroup(dot, text).arrange(RIGHT, buff=0.2)
                group.add(row)
            return group.arrange(DOWN, buff=0.25, aligned_edge=LEFT)

        # 左侧内容
        left_label = Text("高维数据 (High-Dim)", font="AR PL UKai CN", font_size=28, color=RED_C)
        left_box = Square(side_length=3, color=GREY, stroke_opacity=0.5).move_to(LEFT * 3.5 + UP * 0.5)
        left_label.next_to(left_box, UP, buff=0.2)

        # 在盒子内生成随机散点（模拟高维稀疏/混乱）
        high_dim_dots = VGroup()
        for _ in range(30):
            high_dim_dots.add(Dot(point=left_box.get_center() + np.array([
                random.uniform(-1.2, 1.2),
                random.uniform(-1.2, 1.2),
                0
            ]), radius=0.06, color=BLUE_B))

        left_text_items = ["维数灾难 (Curse)", "样本稀疏", "距离计算困难", "训练成本巨大"]
        left_list = create_cn_list(left_text_items).next_to(left_box, DOWN, buff=0.4)

        left_group = VGroup(left_label, left_box, high_dim_dots, left_list)

        # 右侧内容
        right_label = Text("低维子空间 (Low-Dim)", font="AR PL UKai CN", font_size=28, color=GREEN_C)
        right_box = Rectangle(width=3, height=1, color=GREY, stroke_opacity=0.5).move_to(RIGHT * 3.5 + UP * 0.5)
        right_label.next_to(right_box, UP, buff=1.2) # 调整位置以对齐

        # 生成投影后的点（模拟降维后的主成分）
        low_dim_dots = VGroup()
        for i in range(30):
            # 将点映射到一条线上
            x_pos = (i - 15) * 0.08
            low_dim_dots.add(Dot(point=right_box.get_center() + np.array([x_pos, 0, 0]), radius=0.06, color=BLUE_B))

        right_text_items = ["保留主信息", "便于可视化", "利于分类/聚类", "数据压缩"]
        right_list = create_cn_list(right_text_items).next_to(right_box, DOWN, buff=1.4) # 调整垂直间距对齐左侧

        # 3. 动画展示流程

        # 显示左侧高维部分
        self.play(FadeIn(left_label), Create(left_box))
        self.play(ShowIncreasingSubsets(high_dim_dots), run_time=1.5)
        self.play(Write(left_list), run_time=1.5)

        # 箭头转换
        arrow = Arrow(left_box.get_right(), right_box.get_left(), buff=0.5, color=YELLOW)
        arrow_text = Text("降维", font="AR PL UKai CN", font_size=24, color=YELLOW).next_to(arrow, UP, buff=0.1)

        self.play(GrowArrow(arrow), FadeIn(arrow_text))

        # 显示右侧低维部分（包含点的变换动画）
        self.play(FadeIn(right_label), Create(right_box))

        # 关键动画：点从高维盒子移动到低维盒子
        # 复制一份高维点用于变换
        dots_copy = high_dim_dots.copy()
        self.add(dots_copy)
        self.play(
            Transform(dots_copy, low_dim_dots),
            run_time=2,
            path_arc=0.5 # 增加弧度使动画更生动
        )

        # 显示目标列表
        self.play(Write(right_list), run_time=1.5)

        # 4. 强调总结
        # 强调右侧列表
        surround_rect = SurroundingRectangle(right_list, color=GREEN, buff=0.15)
        self.play(Create(surround_rect))
