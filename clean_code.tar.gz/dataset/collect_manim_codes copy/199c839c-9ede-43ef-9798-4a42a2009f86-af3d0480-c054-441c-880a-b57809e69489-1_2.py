from manim import *

class FluidMechanicsInEngineering(Scene):
    def construct(self):

        self.camera.background_color = "#1E1E1E"

        # 1. Create Title
        title = Text("Role of Fluid Mechanics in Engineering",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        # Animate Title
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Create Bulleted List for applications
        applications = BulletedList(
            "Aerospace Engineering: Aircraft wing design, rocket propulsion.",
            "Mechanical \\& Energy: Turbine and pump efficiency, energy loss reduction.",
            "Industrial Manufacturing: Chemical reactor mixing, cooling system design.",
            font_size=28
        )
        applications.next_to(title_group, DOWN, buff=0.7).to_edge(LEFT, buff=1)

        # 3. Animate each point sequentially
        for item in applications:
            self.play(FadeIn(item, shift=DOWN*0.5), run_time=1.2)

        # 4. Highlight key terms with SurroundingRectangle
        rect1 = SurroundingRectangle(applications[0][16:28], color=BLUE, buff=0.05) # "wing design"
        rect2 = SurroundingRectangle(applications[1][21:40], color=GREEN, buff=0.05) # "Turbine and pump"
        rect3 = SurroundingRectangle(applications[2][28:48], color=ORANGE, buff=0.05) # "Chemical reactor mixing"

        self.play(Create(rect1), run_time=0.8)
        self.play(Create(rect2), run_time=0.8)
        self.play(Create(rect3), run_time=0.8)

        # Final wait
