from manim import *

class CurvatureDefinitionAndFormula(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("曲线的曲率定义与公式",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("42", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 定义部分
        # 核心定义文本
        def_text = Text("曲率：描述曲线在某点处的弯曲程度", font="AR PL UKai CN", font_size=28, color=YELLOW)
        sub_text = Text("定义为单位弧长上切向量方向的变化率", font="AR PL UKai CN", font_size=24, color=WHITE)

        text_group = VGroup(def_text, sub_text).arrange(DOWN, buff=0.2)
        text_group.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(text_group, shift=DOWN))

        # 3. 内容布局 - 下半部分分为左右两栏
        # 左侧：公式展示
        # 公式1：参数曲线
        label_param = Text("参数曲线 r(t)", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        formula_param = MathTex(
            r"\kappa = \frac{|\mathbf{r}'(t) \times \mathbf{r}''(t)|}{|\mathbf{r}'(t)|^3}",
            font_size=32
        )
        group_param = VGroup(label_param, formula_param).arrange(DOWN, buff=0.15)

        # 公式2：平面曲线
        label_plane = Text("平面曲线 y=f(x)", font="AR PL UKai CN", font_size=24, color=GREEN_B)
        formula_plane = MathTex(
            r"\kappa = \frac{|f''(x)|}{(1 + (f'(x))^2)^{3/2}}",
            font_size=32
        )
        group_plane = VGroup(label_plane, formula_plane).arrange(DOWN, buff=0.15)

        # 组合左侧公式块
        formulas_col = VGroup(group_param, group_plane).arrange(DOWN, buff=0.6)
        formulas_col.to_edge(LEFT, buff=1.5).shift(DOWN * 0.5)

        # 给公式添加边框以示强调
        box_param = SurroundingRectangle(group_param, color=BLUE, buff=0.15)
        box_plane = SurroundingRectangle(group_plane, color=GREEN, buff=0.15)

        # 4. 右侧：可视化图示 (示意切向量变化)
        # 创建一个简单的坐标系和曲线
        ax = Axes(
            x_range=[-0.5, 3.5], y_range=[-1, 3],
            x_length=4, y_length=3,
            tips=False,
            axis_config={"color": GREY}
        )

        # 绘制一条弯曲的曲线
        curve = ax.plot(lambda x: 0.3 * (x-1.5)**3 + 1, x_range=[0, 3], color=RED)
        curve_label = MathTex("C", color=RED).next_to(curve, UP)

        # 示意切向量 (简单的箭头)
        # 点1 (弯曲前)
        t1 = 0.5
        p1 = ax.c2p(t1, 0.3 * (t1-1.5)**3 + 1)
        # 粗略计算切线角度
        slope1 = 0.9 * (t1-1.5)**2
        angle1 = np.arctan(slope1)
        vec1 = Arrow(p1, p1 + 0.8 * np.array([np.cos(angle1), np.sin(angle1), 0]), color=YELLOW, buff=0)

        # 点2 (弯曲后)
        t2 = 2.5
        p2 = ax.c2p(t2, 0.3 * (t2-1.5)**3 + 1)
        slope2 = 0.9 * (t2-1.5)**2
        angle2 = np.arctan(slope2)
        vec2 = Arrow(p2, p2 + 0.8 * np.array([np.cos(angle2), np.sin(angle2), 0]), color=YELLOW, buff=0)

        # 辅助虚线示意切向量变化
        dashed_line = DashedLine(p1, p2, color=GRAY, stroke_opacity=0.5)

        visual_group = VGroup(ax, curve, curve_label, vec1, vec2, dashed_line)
        visual_group.next_to(formulas_col, RIGHT, buff=1.0)

        # 5. 动画播放序列
        # 显示左侧公式
        self.play(
            FadeIn(formulas_col, shift=RIGHT),
            Create(box_param),
            Create(box_plane)
        )

        # 显示右侧图示
        self.play(Create(ax), run_time=0.5)
        self.play(Create(curve), Write(curve_label), run_time=1)

        # 动态展示切向量，强调方向变化
        self.play(GrowArrow(vec1), GrowArrow(vec2))

        # 最后的停顿，确保观众看清
