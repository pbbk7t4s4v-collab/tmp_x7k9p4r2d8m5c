from manim import *

class DataOrganizationStrategy(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("面向训练流程的数据组织方法",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容模块构建
        # 字体配置
        my_font = "AR PL UKai CN"
        content_color = BLUE_B
        text_scale = 0.6

        # 模块1: Dataset抽象
        t1_header = Text("1. Dataset抽象: 接口隔离", font=my_font, color=YELLOW, font_size=24)
        # 简单的示意图：存储 -> Dataset -> 训练
        box_storage = Rectangle(height=0.6, width=1.2, color=GRAY).set_fill(GRAY, opacity=0.5)
        txt_storage = Text("存储", font=my_font, font_size=18).move_to(box_storage)

        box_dataset = Rectangle(height=0.6, width=1.2, color=BLUE).set_fill(BLUE, opacity=0.5)
        txt_dataset = Text("Dataset", font=my_font, font_size=18).move_to(box_dataset)

        arrow1 = Arrow(start=LEFT, end=RIGHT, buff=0.1, max_tip_length_to_length_ratio=0.3, color=WHITE).scale(0.5)

        group1_visual = VGroup(VGroup(box_storage, txt_storage), arrow1, VGroup(box_dataset, txt_dataset)).arrange(RIGHT)
        group1 = VGroup(t1_header, group1_visual).arrange(DOWN, buff=0.3)

        # 模块2: 样本粒度
        t2_header = Text("2. 样本建模: 输入形态", font=my_font, color=YELLOW, font_size=24)
        # 示意图：文本 -> Tensor
        txt_raw = Text("原始文本", font=my_font, font_size=18, color=WHITE)
        arrow2 = Arrow(start=LEFT, end=RIGHT, buff=0.1, color=WHITE).scale(0.5)

        # 简单的矩阵表示Tensor
        grid = VGroup(*[Square(side_length=0.15, fill_opacity=0.8, fill_color=GREEN, color=GREEN) for _ in range(9)]).arrange_in_grid(3, 3, buff=0.05)
        txt_tensor = Text("Tensor", font=my_font, font_size=16).next_to(grid, DOWN, buff=0.1)
        tensor_group = VGroup(grid, txt_tensor)

        group2_visual = VGroup(txt_raw, arrow2, tensor_group).arrange(RIGHT)
        group2 = VGroup(t2_header, group2_visual).arrange(DOWN, buff=0.3)

        # 模块3: 加载解耦
        t3_header = Text("3. DataLoader: 异步预取", font=my_font, color=YELLOW, font_size=24)
        # 示意图：CPU -> Buffer -> GPU
        cpu_box = RoundedRectangle(corner_radius=0.1, height=0.5, width=0.8, color=RED)
        cpu_txt = Text("CPU", font_size=16).move_to(cpu_box)

        gpu_box = RoundedRectangle(corner_radius=0.1, height=0.5, width=0.8, color=GREEN)
        gpu_txt = Text("GPU", font_size=16).move_to(gpu_box)

        # Buffer
        buffer_lines = VGroup(*[Line(UP*0.2, DOWN*0.2, color=WHITE) for _ in range(3)]).arrange(RIGHT, buff=0.1)
        buffer_rect = SurroundingRectangle(buffer_lines, color=BLUE, buff=0.1)
        buffer_lbl = Text("预取", font=my_font, font_size=14).next_to(buffer_rect, UP, buff=0.05)
        buffer_grp = VGroup(buffer_rect, buffer_lines, buffer_lbl)

        group3_visual = VGroup(VGroup(cpu_box, cpu_txt), buffer_grp, VGroup(gpu_box, gpu_txt)).arrange(RIGHT, buff=0.2)
        group3 = VGroup(t3_header, group3_visual).arrange(DOWN, buff=0.3)

        # 模块4: 工程目录
        t4_header = Text("4. 元信息: 目录结构", font=my_font, color=YELLOW, font_size=24)
        # 示意图：文件夹结构
        folder_rect = Rectangle(height=0.8, width=0.6, color=ORANGE)
        file_lines = VGroup(*[Line(LEFT*0.2, RIGHT*0.2, color=WHITE, stroke_width=2) for _ in range(3)]).arrange(DOWN, buff=0.1)
        file_lines.move_to(folder_rect)
        json_txt = Text("info.json", font_size=14, color=ORANGE).next_to(folder_rect, DOWN, buff=0.1)

        group4_visual = VGroup(folder_rect, file_lines, json_txt)
        group4 = VGroup(t4_header, group4_visual).arrange(DOWN, buff=0.3)

        # 3. 布局与展示
        # 将四个模块排列成 2x2 网格
        main_content = VGroup(group1, group2, group3, group4).arrange_in_grid(rows=2, cols=2, buff=(1.5, 0.8))
        main_content.next_to(title_line, DOWN, buff=0.8)

        # 为每个模块添加边框
        rects = VGroup()
        for item in [group1, group2, group3, group4]:
            rect = SurroundingRectangle(item, color=WHITE, buff=0.2, stroke_width=1, stroke_opacity=0.5)
            rects.add(rect)

        # 动画播放
        # 依次展示四个部分
        self.play(
            LaggedStart(
                AnimationGroup(FadeIn(group1, shift=UP), Create(rects[0])),
                AnimationGroup(FadeIn(group2, shift=UP), Create(rects[1])),
                AnimationGroup(FadeIn(group3, shift=UP), Create(rects[2])),
                AnimationGroup(FadeIn(group4, shift=UP), Create(rects[3])),
                lag_ratio=0.4
            ),
            run_time=3
        )
