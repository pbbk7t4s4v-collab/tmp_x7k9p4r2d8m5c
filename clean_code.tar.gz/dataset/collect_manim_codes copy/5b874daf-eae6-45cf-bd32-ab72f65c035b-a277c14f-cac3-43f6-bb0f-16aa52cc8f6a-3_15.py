from manim import *

class KeyMistakesSummary(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("特征值与对角化关键易错点",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("31", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容定义
        my_font = "AR PL UKai CN"

        # 易错点 1
        # 重点：代数重数 != 几何重数
        label_1 = Text("易错点 1：勿将代数重数等同于几何重数", font=my_font, font_size=26, color=YELLOW)
        label_1.to_edge(LEFT, buff=1).shift(UP * 1.5)

        math_1 = MathTex(
            r"m_\lambda = k \quad \nRightarrow \quad \dim(N(A-\lambda I)) = k",
            font_size=32, color=WHITE
        )
        math_1.next_to(label_1, DOWN, buff=0.15, aligned_edge=LEFT).shift(RIGHT * 0.5)

        # 易错点 2
        # 重点：非对角线元素的影响
        label_2 = Text("易错点 2：非对角线元素决定几何重数", font=my_font, font_size=26, color=YELLOW)
        label_2.next_to(math_1, DOWN, buff=0.6, aligned_edge=LEFT).shift(LEFT * 0.5)

        # 展示两个矩阵的对比
        mat_a = MathTex(r"A = \begin{bmatrix} \lambda & 1 \\ 0 & \lambda \end{bmatrix}", font_size=30)
        mat_b = MathTex(r"B = \begin{bmatrix} \lambda & 0 \\ 0 & \lambda \end{bmatrix}", font_size=30)

        # 标注：不可对角化 vs 可对角化
        desc_a = Text("不可对角化", font=my_font, font_size=20, color=RED).next_to(mat_a, DOWN, buff=0.1)
        desc_b = Text("可对角化", font=my_font, font_size=20, color=GREEN).next_to(mat_b, DOWN, buff=0.1)

        group_a = VGroup(mat_a, desc_a)
        group_b = VGroup(mat_b, desc_b)

        # 将两个矩阵组横向排列
        matrix_group = VGroup(group_a, group_b).arrange(RIGHT, buff=1.5)
        matrix_group.next_to(label_2, DOWN, buff=0.2, aligned_edge=LEFT).shift(RIGHT * 0.5)

        # 易错点 3
        # 重点：几何重数计算公式
        label_3 = Text("易错点 3：几何重数(GM)计算公式", font=my_font, font_size=26, color=YELLOW)
        label_3.next_to(matrix_group, DOWN, buff=0.6, aligned_edge=LEFT).shift(LEFT * 0.5)

        math_3 = MathTex(
            r"GM = n - \text{rank}(A - \lambda I)",
            font_size=32, color=WHITE
        )
        math_3.next_to(label_3, DOWN, buff=0.15, aligned_edge=LEFT).shift(RIGHT * 0.5)

        # 强调框
        rect_3 = SurroundingRectangle(math_3, color=BLUE, buff=0.1)

        # 3. 动画展示序列
        # 第一部分：代数 vs 几何
        self.play(FadeIn(label_1, shift=RIGHT * 0.5))
        self.play(Write(math_1))

        # 第二部分：矩阵对比
        self.play(FadeIn(label_2, shift=RIGHT * 0.5))
        self.play(FadeIn(matrix_group, shift=UP * 0.2))

        # 第三部分：计算公式
        self.play(FadeIn(label_3, shift=RIGHT * 0.5))
        self.play(Write(math_3))
        self.play(Create(rect_3))
