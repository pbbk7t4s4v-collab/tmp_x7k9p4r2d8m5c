from manim import *

class MultiplierMechanism(Scene):
    def construct(self):

        # 1. 标题设置 (严格遵守模板)
        title = Text("乘数传导机制逐轮分析",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("41", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 表格头部构建 (手动布局以保证中文和公式对齐)
        # 定义列的位置
        col_x = [-5, -2, 3] # 轮次, 收入增加, 消费增加
        header_y = 2.0

        h1 = Text("轮次", font="AR PL UKai CN", font_size=24, color=BLUE_B).move_to([col_x[0], header_y, 0])
        h2 = Text("收入增加 (ΔY)", font="AR PL UKai CN", font_size=24, color=BLUE_B).move_to([col_x[1], header_y, 0])
        h3 = Text("消费增加 (ΔC = 0.8ΔY)", font="AR PL UKai CN", font_size=24, color=BLUE_B).move_to([col_x[2], header_y, 0])

        headers = VGroup(h1, h2, h3)

        # 分隔线
        sep_line = Line(start=[-6, header_y - 0.3, 0], end=[6, header_y - 0.3, 0], color=GRAY, stroke_width=1)

        self.play(FadeIn(headers, shift=DOWN * 0.2), Create(sep_line), run_time=1)

        # 3. 数据行内容 (逐行展示)
        rows_data = [
            ("第1轮", "20 (由ΔG引发)", "20 \\times 0.8 = 16"),
            ("第2轮", "16", "16 \\times 0.8 = 12.8"),
            ("第3轮", "12.8", "12.8 \\times 0.8 = 10.24"),
            ("...", "...", "...")
        ]

        row_start_y = 1.2
        y_step = 0.7

        # 存储所有行对象以便后续操作
        all_rows = VGroup()

        for i, data in enumerate(rows_data):
            current_y = row_start_y - i * y_step

            # 轮次
            t1 = Text(data[0], font="AR PL UKai CN", font_size=22).move_to([col_x[0], current_y, 0])

            # 收入
            if i == 0:
                # 第一行特殊处理，包含中文说明
                t2 = Text(data[1], font="AR PL UKai CN", font_size=22, color=YELLOW).move_to([col_x[1], current_y, 0])
            elif i == 3:
                 t2 = Text(data[1], font="AR PL UKai CN", font_size=22).move_to([col_x[1], current_y, 0])
            else:
                t2 = MathTex(data[1], font_size=26, color=YELLOW).move_to([col_x[1], current_y, 0])

            # 消费计算
            if i == 3:
                t3 = Text(data[2], font="AR PL UKai CN", font_size=22).move_to([col_x[2], current_y, 0])
            else:
                t3 = MathTex(data[2], font_size=26).move_to([col_x[2], current_y, 0])
                # 高亮MPC 0.8
                t3.set_color_by_tex("0.8", ORANGE)

            row_group = VGroup(t1, t2, t3)
            all_rows.add(row_group)

            # 动画播放：每一行淡入
            self.play(Write(row_group), run_time=0.8)
            if i == 0:
                pass
            elif i == 1:
                pass
            elif i == 2:
                pass
            elif i == 3:
                pass

        # 4. 底部公式推导 (几何级数求和)
        # 位置在表格下方
        formula_y = -2.5

        # 公式文本
        formula_part1 = MathTex(r"\Delta Y_{total} = 20 + 16 + 12.8 + ...", font_size=30)
        formula_part2 = MathTex(r"= 20(1 + 0.8 + 0.8^2 + ...)", font_size=30)
        formula_part3 = MathTex(r"= 20 \times \frac{1}{1-0.8} = 100", font_size=30, color=YELLOW)

        # 组合公式组，垂直排列
        formula_group = VGroup(formula_part1, formula_part2, formula_part3).arrange(DOWN, buff=0.2)
        formula_group.move_to([0, formula_y, 0])

        # 强调框
        box = SurroundingRectangle(formula_group, color=GREEN, buff=0.2)

        # 播放公式动画
        self.play(FadeIn(formula_group, shift=UP), run_time=1.5)
        self.play(Create(box), run_time=0.8)
