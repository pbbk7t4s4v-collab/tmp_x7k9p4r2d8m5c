from manim import *

class InOrderRecursiveScene(Scene):
    def construct(self):

        # 1. 标题
        title = Text("中序遍历：递归实现",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 整体布局
        left_pos = LEFT * 4.5
        right_pos = RIGHT * 2.5

        # 3. 伪代码（左侧）
        code_lines_text = [
            "InOrder(node):",
            "    if node is null: return",
            "    InOrder(node.left)  # 1. 递归左子树",
            "    visit(node)         # 2. 访问根节点",
            "    InOrder(node.right) # 3. 递归右子树"
        ]
        code = VGroup(
            *[Text(line, font="Monospace", font_size=24, color=WHITE) for line in code_lines_text]
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.25).move_to(left_pos)

        code_box = SurroundingRectangle(code, buff=0.2, color=BLUE_D)

        self.play(Write(code), Create(code_box))

        # 4. 二叉树可视化（右侧）
        nodes = {
            4: {"pos": UP * 2},
            2: {"pos": LEFT * 1.5 + UP * 0.5},
            6: {"pos": RIGHT * 1.5 + UP * 0.5},
            1: {"pos": LEFT * 2.5 + DOWN * 1},
            3: {"pos": LEFT * 0.5 + DOWN * 1},
            5: {"pos": RIGHT * 0.5 + DOWN * 1},
            7: {"pos": RIGHT * 2.5 + DOWN * 1}
        }

        node_mobs = {}
        for val, data in nodes.items():
            circle = Circle(radius=0.4, color=WHITE, fill_opacity=1, fill_color=BLACK)
            text = Text(str(val), font_size=30, weight=BOLD).move_to(circle.get_center())
            node_mobs[val] = VGroup(circle, text).move_to(data["pos"])

        edges = VGroup()
        connections = [(4, 2), (4, 6), (2, 1), (2, 3), (6, 5), (6, 7)]
        for parent, child in connections:
            edges.add(Line(node_mobs[parent].get_center(), node_mobs[child].get_center(), buff=0.4, stroke_width=3))

        tree_group = VGroup(*node_mobs.values(), edges).move_to(right_pos).scale(0.9)

        # 将树和代码同时淡入
        self.play(FadeIn(tree_group))

        # 创建子树分组以便高亮
        left_subtree = VGroup(node_mobs[1], node_mobs[2], node_mobs[3], edges[2], edges[3])
        right_subtree = VGroup(node_mobs[5], node_mobs[6], node_mobs[7], edges[4], edges[5])

        # 5. 遍历过程动画
