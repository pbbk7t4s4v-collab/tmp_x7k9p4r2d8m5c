from manim import *

class ParameterReduction(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置
        # ---------------------------------------------------------
        title = Text("参数减少:全连接层 vs 卷积层",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心内容布局
        # ---------------------------------------------------------

        # 左侧:全连接层 (Fully Connected)
        fc_title = Text("原全连接层", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        # 用一个大的矩形代表巨大的参数矩阵
        fc_matrix = Rectangle(height=2.5, width=2.0, color=BLUE, fill_opacity=0.3)
        fc_matrix_label = Text("参数矩阵 W", font="AR PL UKai CN", font_size=18).move_to(fc_matrix)
        fc_param_math = MathTex(r"hw \times m", font_size=32, color=BLUE_A)

        fc_group = VGroup(fc_title, fc_matrix, fc_matrix_label, fc_param_math).arrange(DOWN, buff=0.2)
        fc_group.shift(LEFT * 3 + DOWN * 0.2)

        # 右侧:卷积层 (Convolution / Weight Sharing)
        conv_title = Text("权重共享后", font="AR PL UKai CN", font_size=24, color=GREEN_B)
        # 用一个小的正方形代表卷积核
        conv_kernel = Square(side_length=0.8, color=GREEN, fill_opacity=0.8)
        conv_kernel_label = Text("卷积核 K", font="AR PL UKai CN", font_size=18, color=BLACK).move_to(conv_kernel)
        conv_param_math = MathTex(r"k \times k \times m", font_size=32, color=GREEN_A)

        conv_group = VGroup(conv_title, conv_kernel, conv_kernel_label, conv_param_math).arrange(DOWN, buff=0.2)
        # 调整右侧组的位置,使其顶部与左侧对齐,保持视觉平衡
        conv_group.move_to(RIGHT * 3 + DOWN * 0.2)
        conv_group.align_to(fc_group, UP)

        # 修正右侧内部间距,因为Square比Rectangle小,需要重新调整下方公式位置以对齐
        conv_param_math.next_to(conv_kernel, DOWN, buff=1.05) # 手动调整对齐视觉中心

        # ---------------------------------------------------------
        # 3. 动画展示过程
        # ---------------------------------------------------------

        # 展示全连接层信息
        self.play(
            FadeIn(fc_group, shift=RIGHT),
            run_time=1.2
        )

        # 展示卷积层信息
        self.play(
            FadeIn(conv_group, shift=LEFT),
            run_time=1.2
        )

        # ---------------------------------------------------------
        # 4. 结论与对比
        # ---------------------------------------------------------

        # 核心假设:k << h, w
        assumption = MathTex(r"k \ll h, w", font_size=36, color=YELLOW)
        assumption.move_to(DOWN * 2.2)

        # 结论文本
        conclusion_text = Text("参数量减少数千倍", font="AR PL UKai CN", font_size=28, color=YELLOW)
        conclusion_text.next_to(assumption, DOWN, buff=0.2)

        # 强调框
        highlight_box = SurroundingRectangle(VGroup(assumption, conclusion_text), color=YELLOW, buff=0.2)

        # 播放结论动画
        self.play(Write(assumption))
        self.play(
            Write(conclusion_text),
            Create(highlight_box),
            run_time=1.5
        )

        # 视觉连线:表示对比关系
        comparison_arrow = DoubleArrow(
            start=fc_matrix.get_right(),
            end=conv_kernel.get_left() + LEFT*0.5, # 稍微调整箭头指向
            color=GRAY,
            buff=0.1
        )
        # 调整箭头垂直位置到两个图形中间
        comparison_arrow.set_y(fc_matrix.get_y())

        self.play(GrowFromCenter(comparison_arrow))
