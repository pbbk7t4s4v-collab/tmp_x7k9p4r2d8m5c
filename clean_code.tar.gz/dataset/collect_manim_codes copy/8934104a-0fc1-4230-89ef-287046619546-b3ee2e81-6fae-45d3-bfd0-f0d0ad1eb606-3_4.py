from manim import *

class DecisionTreePruning(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("决策树的剪枝处理",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("11", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 绘制决策树结构
        # 树的根节点
        root = Dot(point=UP*1.5, radius=0.15, color=WHITE)

        # 第一层
        l1_left = Dot(point=UP*0.5 + LEFT*2, radius=0.12, color=BLUE)
        l1_right = Dot(point=UP*0.5 + RIGHT*2, radius=0.12, color=BLUE)

        # 连线
        line_root_l = Line(root.get_center(), l1_left.get_center(), color=GREY)
        line_root_r = Line(root.get_center(), l1_right.get_center(), color=GREY)

        # 左侧子树(简单,正常)
        l2_ll = Dot(point=DOWN*0.5 + LEFT*2.5, radius=0.1, color=GREEN)
        l2_lr = Dot(point=DOWN*0.5 + LEFT*1.5, radius=0.1, color=GREEN)
        line_l1l_ll = Line(l1_left.get_center(), l2_ll.get_center(), color=GREY)
        line_l1l_lr = Line(l1_left.get_center(), l2_lr.get_center(), color=GREY)

        left_branch = VGroup(l1_left, l2_ll, l2_lr, line_l1l_ll, line_l1l_lr, line_root_l)

        # 右侧子树(复杂,模拟过拟合)
        # 这一部分是将被剪掉的
        l2_rl = Dot(point=DOWN*0.5 + RIGHT*1.2, radius=0.1, color=RED)
        l2_rr = Dot(point=DOWN*0.5 + RIGHT*2.8, radius=0.1, color=RED)

        line_l1r_rl = Line(l1_right.get_center(), l2_rl.get_center(), color=GREY)
        line_l1r_rr = Line(l1_right.get_center(), l2_rr.get_center(), color=GREY)

        # 第三层(过密细节)
        l3_rrl = Dot(point=DOWN*1.5 + RIGHT*2.4, radius=0.08, color=RED_A)
        l3_rrr = Dot(point=DOWN*1.5 + RIGHT*3.2, radius=0.08, color=RED_A)
        line_l2rr_rrl = Line(l2_rr.get_center(), l3_rrl.get_center(), color=GREY)
        line_l2rr_rrr = Line(l2_rr.get_center(), l3_rrr.get_center(), color=GREY)

        # 定义需要剪枝的部分 (Pruning Target)
        # 包括右侧节点下的所有复杂分支,保留 l1_right 作为新的叶子节点
        prune_group = VGroup(
            l2_rl, l2_rr, l3_rrl, l3_rrr,
            line_l1r_rl, line_l1r_rr, line_l2rr_rrl, line_l2rr_rrr
        )

        # 基础树结构(不含剪枝部分)
        base_tree = VGroup(root, left_branch, l1_right, line_root_r)

        # 3. 动画展示过程

        # 阶段一:展示过拟合的树
        self.play(
            Create(base_tree),
            Create(prune_group),
            run_time=1.5
        )

        text_overfit = Text("树过大过密:过拟合", font="AR PL UKai CN", font_size=24, color=RED)
        text_overfit.next_to(prune_group, DOWN, buff=0.2)

        self.play(FadeIn(text_overfit, shift=UP))

        # 阶段二:识别剪枝区域
        rect = SurroundingRectangle(prune_group, color=YELLOW, buff=0.1)
        label_prune = Text("进行剪枝", font="AR PL UKai CN", font_size=24, color=YELLOW)
        label_prune.next_to(rect, RIGHT, buff=0.2)

        self.play(
            Create(rect),
            Write(label_prune),
            run_time=1
        )

        # 阶段三:执行剪枝
        # 将 l1_right 变为叶子节点(比如变绿)
        new_leaf_color = GREEN

        self.play(
            FadeOut(prune_group),
            FadeOut(rect),
            FadeOut(text_overfit),
            l1_right.animate.set_color(new_leaf_color), # 变为叶子颜色
            run_time=1.2
        )

        # 阶段四:剪枝后效果
        text_result = Text("提升泛化能力", font="AR PL UKai CN", font_size=24, color=GREEN)
        text_result.next_to(l1_right, DOWN, buff=0.5)

        # 调整 label_prune 的位置或内容,这里简单淡出旧标签,显示新标签
        self.play(
            Transform(label_prune, text_result),
            run_time=1
        )
