from manim import *

class PythonListDemo(Scene):
    def construct(self):

        # 1. 标题部分 (根据模板)
        title = Text("Python列表简介",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 代码定义展示
        # 使用Text模拟代码显示,避免Code类的兼容性问题
        code_str = "numbers = [10, 20, 30, 40]"
        code_text = Text(code_str, font_size=32, font="Monospace", color=BLUE_B)
        code_text.next_to(title_line, DOWN, buff=0.5)

        self.play(Write(code_text))

        # 3. 列表可视化构建
        # 创建列表数据的几何表示
        values = [10, 20, 30, 40]
        squares = VGroup()
        val_texts = VGroup()
        indices = VGroup()

        # 生成方块、数值和索引
        for i, val in enumerate(values):
            # 列表单元格
            sq = Square(side_length=1.2, color=WHITE, stroke_width=2)
            # 列表内的值
            txt = Text(str(val), font_size=36, font="AR PL UKai CN", color=WHITE)
            txt.move_to(sq.get_center())
            # 索引数字
            idx = Text(str(i), font_size=24, font="AR PL UKai CN", color=GRAY)

            squares.add(sq)
            val_texts.add(txt)
            indices.add(idx)

        # 排列方块
        squares.arrange(RIGHT, buff=0)
        squares.move_to(ORIGIN).shift(UP * 0.2) # 放置在屏幕中央稍偏上

        # 将数值和索引对齐到排列好的方块
        for i in range(len(values)):
            val_texts[i].move_to(squares[i].get_center())
            indices[i].next_to(squares[i], DOWN, buff=0.15)

        # 组合整体
        list_visual = VGroup(squares, val_texts, indices)

        # 动画:从代码生成列表图形
        self.play(
            FadeIn(squares, shift=DOWN),
            Write(val_texts)
        )

        # 4. 讲解:索引从0开始
        index_label = Text("索引 (Index)", font_size=24, font="AR PL UKai CN", color=YELLOW)
        index_label.next_to(indices, DOWN, buff=0.2)

        self.play(
            Write(indices),
            FadeIn(index_label)
        )

        # 强调索引0
        zero_highlight = SurroundingRectangle(indices[0], color=RED, buff=0.05)
        zero_note = Text("从0开始!", font_size=24, font="AR PL UKai CN", color=RED)
        zero_note.next_to(zero_highlight, DOWN, buff=0.1)

        self.play(
            Create(zero_highlight),
            Write(zero_note)
        )

        # 5. 讲解:访问元素
        # 清除之前的强调,准备展示访问
        self.play(
            FadeOut(zero_note),
            FadeOut(zero_highlight),
            FadeOut(code_text) # 腾出空间
        )

        # 展示访问代码
        access_code = Text("print(numbers[2])", font_size=32, font="Monospace", color=GREEN)
        access_code.to_edge(UP, buff=2.0) # 放在上方

        # 箭头指向目标
        target_index = 2
        arrow = Arrow(start=access_code.get_bottom(), end=squares[target_index].get_top(), color=GREEN, buff=0.1)

        # 目标元素高亮框
        target_rect = SurroundingRectangle(squares[target_index], color=GREEN, stroke_width=4)

        self.play(Write(access_code))
        self.play(GrowArrow(arrow))
        self.play(Create(target_rect))

        # 提取值
        extracted_val = val_texts[target_index].copy()
        output_label = Text("输出: 30", font_size=32, font="AR PL UKai CN", color=GREEN)
        output_label.next_to(access_code, RIGHT, buff=1)

        self.play(
            Transform(extracted_val, output_label), # 视觉上值移动变成了输出
        )
