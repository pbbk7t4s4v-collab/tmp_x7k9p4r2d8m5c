from manim import *

class HaldaneFinalFormula(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("最终锁定的公式",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 主要内容构建
        # 解释性文本
        intro_text = Text("明确了三组次近邻跃迁的相位关系：",
                         font="AR PL UKai CN",
                         font_size=26,
                         color=LIGHT_GRAY)

        # 核心公式
        # 将公式拆分以便进行局部着色强调
        # h_z(k) = m + 2t_2 sin(phi) [ ... ]
        formula = MathTex(
            r"h_z(k) = ",              # 0
            r"m",                      # 1: 质量项
            r" + ",                    # 2
            r"2t_2 \sin(\phi)",        # 3: Haldane项系数
            r" \left[ \sin(k \cdot a_1) - \sin(k \cdot a_2) - \sin(k_y a) \right]", # 4: 结构因子
            font_size=36
        )

        # 设置颜色以区分不同物理意义
        formula[1].set_color(BLUE)    # 质量项 m
        formula[3].set_color(YELLOW)  # 跃迁与磁通项

        # 底部注释文本
        note_text = Text("注意：正负号的组合反映 Haldane 磁通的环绕方向 (Chirality)",
                        font="AR PL UKai CN",
                        font_size=22,
                        color=ORANGE)

        # 3. 布局排版
        # 使用 VGroup 统一管理位置，避免遮挡
        content_group = VGroup(intro_text, formula, note_text)
        content_group.arrange(DOWN, buff=1.0) # 增大间距
        content_group.next_to(title_line, DOWN, buff=0.8)

        # 4. 动画展示流程

        # 步骤 1: 显示解释文本
        self.play(FadeIn(intro_text, shift=DOWN * 0.5))

        # 步骤 2: 书写公式
        self.play(Write(formula, run_time=2))

        # 步骤 3: 强调关键部分 (Haldane Flux 项)
        # 使用 SurroundingRectangle 框选包含 sin(phi) 的部分和括号内的结构因子
        highlight_rect = SurroundingRectangle(
            VGroup(formula[3], formula[4]),
            color=YELLOW,
            buff=0.15
        )

        self.play(Create(highlight_rect))

        # 步骤 4: 显示 Chirality 注释
        self.play(
            FadeIn(note_text, shift=UP * 0.3),
            FadeOut(highlight_rect) # 淡出方框以保持画面整洁
        )

        # 步骤 5: 最终强调公式中的符号变化部分
        key_signs = MathTex(r"-", font_size=36, color=RED).move_to(formula[4].get_center()) # 仅示意，不直接覆盖
        # 这里通过闪烁公式的最后一部分来强调正负号
        self.play(Indicate(formula[4], color=RED, scale_factor=1.05))
