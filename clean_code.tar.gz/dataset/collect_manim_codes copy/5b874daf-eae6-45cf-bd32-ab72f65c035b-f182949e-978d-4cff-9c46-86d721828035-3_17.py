from manim import *

class BFSTraversalAnimation(Scene):
    def construct(self):

        # 1. 设置标题
        title = Text("二叉树的广度优先遍历 (BFS)",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("19", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 创建二叉树
        nodes_pos = {
            'A': UP * 2, 'B': LEFT * 2.5, 'C': RIGHT * 2.5,
            'D': LEFT * 3.5 + DOWN * 1.5, 'E': LEFT * 1.5 + DOWN * 1.5,
            'F': RIGHT * 1.5 + DOWN * 1.5, 'G': RIGHT * 3.5 + DOWN * 1.5
        }

        node_map = {}
        for name, pos in nodes_pos.items():
            circle = Circle(radius=0.4, color=BLUE, fill_opacity=0.8)
            text = Text(name, font_size=28, color=WHITE).move_to(circle.get_center())
            node = VGroup(circle, text).move_to(pos)
            node_map[name] = node

        edges_list = [('A', 'B'), ('A', 'C'), ('B', 'D'), ('B', 'E'), ('C', 'F'), ('C', 'G')]
        edges = VGroup(*[Line(node_map[start].get_center(), node_map[end].get_center(), stroke_width=3, color=GRAY) for start, end in edges_list])

        tree = VGroup(edges, *node_map.values()).move_to(ORIGIN).shift(UP * 0.7)
        self.play(Create(tree), run_time=1.0)

        # 3. 设置队列和访问顺序的UI
        queue_label = Text("队列:", font="AR PL UKai CN", font_size=28).to_corner(DL, buff=0.8)
        queue_content = VGroup().next_to(queue_label, RIGHT, buff=0.3)

        visited_label = Text("访问顺序:", font="AR PL UKai CN", font_size=28).next_to(queue_label, DOWN, buff=0.6, aligned_edge=LEFT)
        visited_content = VGroup().next_to(visited_label, RIGHT, buff=0.3)

        self.play(FadeIn(queue_label, visited_label))

        # 4. 广度优先遍历动画
        # 步骤 1: 队列初始化 [A]
        node_A_q = node_map['A'][1].copy()
        self.play(
            node_map['A'][0].animate.set_color(YELLOW),
            node_A_q.animate.move_to(queue_content.get_right() + RIGHT * 0.4)
        )
        queue_content.add(node_A_q)

        # 步骤 2: 出队 A, 访问 A, 将 B, C 入队
        dequeued_A = queue_content[0]
        self.play(
            dequeued_A.animate.move_to(visited_content.get_right()),
            node_map['A'][0].animate.set_color(GREEN)
        )
        queue_content.remove(dequeued_A)
        visited_content.add(dequeued_A)

        node_B_q = node_map['B'][1].copy()
        node_C_q = node_map['C'][1].copy()
        self.play(
            node_map['B'][0].animate.set_color(YELLOW),
            node_map['C'][0].animate.set_color(YELLOW)
        )
        queue_content.add(node_B_q, node_C_q)
        self.play(queue_content.animate.arrange(RIGHT, buff=0.2).next_to(queue_label, RIGHT, buff=0.3))

        # 步骤 3: 依次处理B和C
        # 处理 B
        dequeued_B = queue_content[0]
        arrow1 = Text("→", font_size=28).next_to(visited_content, RIGHT, buff=0.2)
        self.play(
            dequeued_B.animate.next_to(arrow1, RIGHT, buff=0.2),
            Write(arrow1),
            node_map['B'][0].animate.set_color(GREEN)
        )
        queue_content.remove(dequeued_B)
        visited_content.add(arrow1, dequeued_B)
        self.play(queue_content.animate.arrange(RIGHT, buff=0.2).next_to(queue_label, RIGHT, buff=0.3))

        node_D_q = node_map['D'][1].copy()
        node_E_q = node_map['E'][1].copy()
        self.play(node_map['D'][0].animate.set_color(YELLOW), node_map['E'][0].animate.set_color(YELLOW))
        queue_content.add(node_D_q, node_E_q)
        self.play(queue_content.animate.arrange(RIGHT, buff=0.2).next_to(queue_label, RIGHT, buff=0.3))

        # 处理 C
        dequeued_C = queue_content[0]
        arrow2 = Text("→", font_size=28).next_to(visited_content, RIGHT, buff=0.2)
        self.play(
            dequeued_C.animate.next_to(arrow2, RIGHT, buff=0.2),
            Write(arrow2),
            node_map['C'][0].animate.set_color(GREEN)
        )
        queue_content.remove(dequeued_C)
        visited_content.add(arrow2, dequeued_C)
        self.play(queue_content.animate.arrange(RIGHT, buff=0.2).next_to(queue_label, RIGHT, buff=0.3))

        node_F_q = node_map['F'][1].copy()
        node_G_q = node_map['G'][1].copy()
        self.play(node_map['F'][0].animate.set_color(YELLOW), node_map['G'][0].animate.set_color(YELLOW))
        queue_content.add(node_F_q, node_G_q)
        self.play(queue_content.animate.arrange(RIGHT, buff=0.2).next_to(queue_label, RIGHT, buff=0.3))

        # 步骤 4: 依次出队叶子节点
        for node_name in ['D', 'E', 'F', 'G']:
            dequeued_node = queue_content[0]
            arrow = Text("→", font_size=28).next_to(visited_content, RIGHT, buff=0.2)
            self.play(
                dequeued_node.animate.next_to(arrow, RIGHT, buff=0.2),
                Write(arrow),
                node_map[node_name][0].animate.set_color(GREEN),
                run_time=0.4
            )
            queue_content.remove(dequeued_node)
            visited_content.add(arrow, dequeued_node)
            if len(queue_content) > 0:
                self.play(queue_content.animate.arrange(RIGHT, buff=0.2).next_to(queue_label, RIGHT, buff=0.3), run_time=0.2)

        # 最终结果高亮
        final_box = SurroundingRectangle(visited_content, color=ORANGE, buff=0.15)
        self.play(Create(final_box))
