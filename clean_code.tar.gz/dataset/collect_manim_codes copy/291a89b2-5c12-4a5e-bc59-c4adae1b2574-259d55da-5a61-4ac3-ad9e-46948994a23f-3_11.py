from manim import *

class LawValueTheory(Scene):
    def construct(self):

        # 1. 标题部分 (严格按照模板)
        title = Text("法律作为价值表达工具的理论基础",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("41", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心定义：法律 vs 价值
        # 左侧：法律（行为规范）
        law_text = Text("法律", font="AR PL UKai CN", font_size=32, color=BLUE)
        law_desc = Text("(不仅是行为规范)", font="AR PL UKai CN", font_size=20, color=GRAY)
        law_desc.next_to(law_text, DOWN, buff=0.1)
        law_group = VGroup(law_text, law_desc)

        # 右侧：价值宣示载体
        value_text = Text("价值宣示载体", font="AR PL UKai CN", font_size=32, color=YELLOW)

        # 布局
        top_group = VGroup(law_group, value_text).arrange(RIGHT, buff=3)
        top_group.next_to(title_line, DOWN, buff=1.0)

        # 箭头
        arrow = Arrow(law_text.get_right(), value_text.get_left(), buff=0.2, color=WHITE)
        arrow_label = Text("更是", font="AR PL UKai CN", font_size=20).next_to(arrow, UP, buff=0.1)

        # 强调框
        rect = SurroundingRectangle(value_text, color=YELLOW, buff=0.2)

        # 播放第一部分动画
        self.play(FadeIn(law_group), run_time=0.8)
        self.play(GrowArrow(arrow), FadeIn(arrow_label), run_time=0.8)
        self.play(Write(value_text), Create(rect), run_time=1.0)

        # 3. 机制：如何实现 (立法、司法、实施 -> 制度化)
        # 创建三个步骤
        step1 = Text("立法确认", font="AR PL UKai CN", font_size=24, color=TEAL)
        step2 = Text("司法裁判", font="AR PL UKai CN", font_size=24, color=TEAL)
        step3 = Text("法律实施", font="AR PL UKai CN", font_size=24, color=TEAL)

        steps_group = VGroup(step1, step2, step3).arrange(RIGHT, buff=0.8)
        steps_group.next_to(top_group, DOWN, buff=1.2)

        # 连接线/大括号
        brace = Brace(steps_group, DOWN, color=WHITE)
        result_text = Text("价值的制度化表达", font="AR PL UKai CN", font_size=26, color=ORANGE)
        result_text.next_to(brace, DOWN, buff=0.1)

        # 播放第二部分动画
        self.play(
            LaggedStart(
                FadeIn(step1, shift=DOWN),
                FadeIn(step2, shift=DOWN),
                FadeIn(step3, shift=DOWN),
                lag_ratio=0.2
            ),
            run_time=1.5
        )
        self.play(GrowFromCenter(brace), Write(result_text), run_time=1.0)

        # 4. 符号性维度 (底部总结)
        symbolic_box = VGroup()
        symbol_icon = Text("符号性维度：", font="AR PL UKai CN", font_size=24, color=PURPLE)
        narrative = Text("文本/裁判叙事", font="AR PL UKai CN", font_size=24, color=WHITE)
        arrow_s = Arrow(LEFT, RIGHT, buff=0.1, max_stroke_width_to_length_ratio=5).scale(0.5)
        identity = Text("塑造价值认同", font="AR PL UKai CN", font_size=24, color=GREEN)

        symbol_row = VGroup(symbol_icon, narrative, arrow_s, identity).arrange(RIGHT, buff=0.2)
        symbol_row.next_to(result_text, DOWN, buff=0.8)

        # 播放第三部分动画
        self.play(FadeIn(symbol_row), run_time=1.0)

        # 5. 最终停留
