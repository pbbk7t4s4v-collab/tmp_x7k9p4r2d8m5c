from manim import *

class EngineeringApplications(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("流体力学的工程技术应用",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容数据准备
        # 将长文本精简以适应排版,保持核心关键词
        data = [
            ("航空航天", "机翼升力、火箭气动\n卫星热防护"),
            ("能源动力", "水轮汽轮、风力发电\n输油管道流量"),
            ("水利工程", "水坝设计、河道治理\n防洪排涝、海洋工程"),
            ("环境工程", "大气/水体污染控制\n通风空调系统设计"),
            ("化工过程", "反应器设计、流体输送\n混合分离设备"),
            ("生物医学", "血液流动分析\n人工心脏、呼吸系统")
        ]

        # 3. 创建卡片元素
        cards = VGroup()

        for category, detail in data:
            # 分类标题
            cat_text = Text(category, font="AR PL UKai CN", font_size=24, color=YELLOW, weight=BOLD)
            # 详情文本
            detail_text = Text(detail, font="AR PL UKai CN", font_size=18, color=WHITE, line_spacing=0.8)

            # 组合文本并设置间距
            text_group = VGroup(cat_text, detail_text).arrange(DOWN, buff=0.2)

            # 创建边框 (SurroundingRectangle)
            border = SurroundingRectangle(
                text_group,
                color=BLUE_C,
                buff=0.3,
                corner_radius=0.2,
                stroke_width=2
            )

            # 组合单个卡片
            card = VGroup(border, text_group)
            cards.add(card)

        # 4. 网格布局排版
        # 2行3列布局
        cards.arrange_in_grid(rows=2, cols=3, buff=0.4)

        # 整体居中并位于标题下方
        cards.move_to(ORIGIN).next_to(title_group, DOWN, buff=0.5)

        # 5. 动画展示
        # 使用 LaggedStart 依次展示每个应用领域
        self.play(
            LaggedStart(
                *[FadeIn(card, shift=UP * 0.3) for card in cards],
                lag_ratio=0.15,
                run_time=2.5
            )
        )

        # 6. 停留展示
