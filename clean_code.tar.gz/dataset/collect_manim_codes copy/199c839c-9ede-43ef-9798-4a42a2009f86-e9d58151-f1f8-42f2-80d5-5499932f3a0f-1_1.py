from manim import *

class PhilosophyObjectTransformation(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("哲学对象的转变：从抽象的人到现实的人",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容可视化设计
        # ---------------------------------------------------------

        # 左侧：旧哲学 - 抽象的人
        old_concept_text = Text("抽象的人", font="AR PL UKai CN", font_size=36, color=BLUE_B)
        old_desc = Text("脱离历史\n孤立的个体\n精神的存在",
                       font="AR PL UKai CN",
                       font_size=24,
                       color=GRAY_B,
                       line_spacing=1.2)
        old_desc.next_to(old_concept_text, DOWN, buff=0.3)

        left_group = VGroup(old_concept_text, old_desc)
        left_group.move_to(LEFT * 3.5)

        # 使用 SurroundingRectangle 框住左侧内容
        left_box = SurroundingRectangle(left_group, color=BLUE, buff=0.2)

        # 右侧：马克思主义哲学 - 现实的人
        new_concept_text = Text("现实的人", font="AR PL UKai CN", font_size=36, color=RED_B)
        new_desc = Text("社会关系的总和\n从事物质生产\n实践的主体",
                       font="AR PL UKai CN",
                       font_size=24,
                       color=GRAY_B,
                       line_spacing=1.2)
        new_desc.next_to(new_concept_text, DOWN, buff=0.3)

        right_group = VGroup(new_concept_text, new_desc)
        right_group.move_to(RIGHT * 3.5)

        # 使用 SurroundingRectangle 框住右侧内容
        right_box = SurroundingRectangle(right_group, color=RED, buff=0.2)

        # 中间：转换箭头与标签
        arrow = Arrow(start=left_box.get_right(), end=right_box.get_left(), buff=0.5, color=YELLOW)
        transform_label = Text("革命性变革", font="AR PL UKai CN", font_size=28, color=YELLOW)
        transform_label.next_to(arrow, UP, buff=0.1)

        # ---------------------------------------------------------
        # 3. 动画流程
        # ---------------------------------------------------------

        # 展示左侧：旧哲学观点
        self.play(
            FadeIn(left_group, shift=UP),
            Create(left_box),
            run_time=1.5
        )

        # 展示中间过程：变革
        self.play(
            GrowArrow(arrow),
            Write(transform_label),
            run_time=1.0
        )

        # 展示右侧：新哲学观点
        self.play(
            FadeIn(right_group, shift=UP),
            Create(right_box),
            run_time=1.5
        )

        # 强调右侧核心
        self.play(
            Indicate(new_concept_text, scale_factor=1.1, color=RED),
            run_time=1.0
        )
