from manim import Scene, Dot, RIGHT, FadeIn

class MinimalScene(Scene):
    def construct(self):

        dot = Dot()
        self.play(FadeIn(dot))
        self.play(dot.animate.shift(RIGHT))
