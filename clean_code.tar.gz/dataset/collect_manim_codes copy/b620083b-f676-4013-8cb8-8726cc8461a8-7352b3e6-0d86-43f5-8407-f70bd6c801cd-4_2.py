from manim import *

class LibraryBookStructure(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("从图书馆看数据结构:线性与树形",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 线性部分:书架上的书
        # 创建书本矩形
        book_colors = [BLUE, RED, GREEN, YELLOW, PURPLE]
        books = VGroup()
        for i, color in enumerate(book_colors):
            book = Rectangle(
                height=1.2, width=0.3,
                fill_color=color, fill_opacity=0.8,
                stroke_color=WHITE, stroke_width=2
            )
            books.add(book)

        # 排列书本
        books.arrange(RIGHT, buff=0.05)

        # 创建书架横板
        shelf_line = Line(
            start=books.get_corner(DL) + LEFT * 0.2,
            end=books.get_corner(DR) + RIGHT * 0.2,
            color=GREY_B, stroke_width=5
        )

        # 线性标签
        linear_label = Text("物理视角:书架线性排列", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        linear_label.next_to(shelf_line, DOWN, buff=0.2)

        # 组合线性部分并放置在上方
        linear_group = VGroup(books, shelf_line, linear_label)
        linear_group.move_to(UP * 1.0)

        # 3. 树形部分:背后的逻辑分类
        # 手动构建简单的树结构 - 缩小节点间距离
        # 根节点
        root = Circle(radius=0.35, color=WHITE, fill_opacity=0.3, fill_color=GREY)
        root_text = Text("总类", font="AR PL UKai CN", font_size=16).move_to(root)
        root_group = VGroup(root, root_text).move_to(DOWN * 1.0)

        # 子节点层 - 缩小水平和垂直距离 (从1.5/0.5调整为1.0/0.3)
        child_l = Circle(radius=0.3, color=WHITE, fill_opacity=0.3, fill_color=GREY)
        child_l_text = Text("人文", font="AR PL UKai CN", font_size=14).move_to(child_l)
        child_l_group = VGroup(child_l, child_l_text).move_to(root.get_center() + DL * 1.0 + DOWN * 0.3)

        child_r = Circle(radius=0.3, color=WHITE, fill_opacity=0.3, fill_color=GREY)
        child_r_text = Text("理工", font="AR PL UKai CN", font_size=14).move_to(child_r)
        child_r_group = VGroup(child_r, child_r_text).move_to(root.get_center() + DR * 1.0 + DOWN * 0.3)

        # 叶子节点 - 缩小与子节点的距离 (从0.8调整为0.5)
        leaf = Rectangle(height=0.4, width=0.3, fill_color=RED, fill_opacity=0.8, stroke_color=WHITE, stroke_width=1)
        leaf_text = Text("史书", font="AR PL UKai CN", font_size=12).move_to(leaf)
        leaf_group = VGroup(leaf, leaf_text).next_to(child_l, DOWN, buff=0.5)

        # 连线
        line1 = Line(root.get_bottom(), child_l.get_top(), color=GREY)
        line2 = Line(root.get_bottom(), child_r.get_top(), color=GREY)
        line3 = Line(child_l.get_bottom(), leaf.get_top(), color=GREY)

        tree_edges = VGroup(line1, line2, line3)
        tree_nodes = VGroup(root_group, child_l_group, child_r_group, leaf_group)

        # 树形标签 - 调整位置：向右偏移+向上偏移，适配缩小后的树结构
        tree_label = Text("逻辑视角:层级化索引", font="AR PL UKai CN", font_size=24, color=GREEN_B)
        # 核心修改：在原有对齐基础上向上偏移0.5个单位（可根据需要调整0.5这个数值）
        tree_label.next_to(leaf_group, RIGHT, buff=0.8).align_to(leaf_group, DOWN).shift(UP * 0.5)

        # 整体树形组
        tree_full_group = VGroup(tree_edges, tree_nodes, tree_label)

        # 4. 动画流程
        # 展示线性部分
        self.play(FadeIn(linear_group, shift=DOWN), run_time=1.2)

        # 展示树形部分
        self.play(
            Create(tree_edges, lag_ratio=0.5),
            FadeIn(tree_nodes, lag_ratio=0.5),
            run_time=1.5
        )
        self.play(Write(tree_label))

        # 5. 建立联系 (高亮)
        # 假设红书是目标
        target_book_idx = 1 # 红色书的索引

        highlight_rect_linear = SurroundingRectangle(books[target_book_idx], color=YELLOW, buff=0.05)
        highlight_rect_tree = SurroundingRectangle(leaf_group, color=YELLOW, buff=0.05)

        # 连接线:从书架上的书连到树形结构的叶子
        connection_line = DashedLine(
            start=books[target_book_idx].get_bottom(),
            end=leaf_group.get_top(),
            color=YELLOW
        )

        self.play(
            Create(highlight_rect_linear),
            Create(highlight_rect_tree),
            Create(connection_line),
            run_time=1.5
        )
