from manim import *

class ScientificEssayFeatures(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("体裁特点：科学小品",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("23", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念展示 - 科学小品
        # 创建中心节点
        core_text = Text("科学小品", font="AR PL UKai CN", font_size=40, color=YELLOW)
        core_rect = SurroundingRectangle(core_text, color=YELLOW, buff=0.3, corner_radius=0.2)
        core_group = VGroup(core_rect, core_text)

        # 将核心节点放置在屏幕左侧
        core_group.move_to(LEFT * 3)

        self.play(FadeIn(core_group, shift=RIGHT))

        # 3. 特点分支展示
        # 定义三个特点的内容
        feature_texts = [
            "充实内容",
            "增添文采",
            "纠正不实记载"
        ]

        feature_groups = VGroup()
        arrows = VGroup()

        # 构建右侧的三个分支
        for i, text_str in enumerate(feature_texts):
            # 特点文本
            # 最后一个特点（纠正不实）使用不同颜色强调，对应原文加粗
            color = RED_B if i == 2 else WHITE
            t = Text(text_str, font="AR PL UKai CN", font_size=32, color=color)

            # 外框
            r = SurroundingRectangle(t, color=color, buff=0.2)
            g = VGroup(r, t)
            feature_groups.add(g)

            # 箭头
            arrow = Arrow(
                start=core_rect.get_right(),
                end=g.get_left(),
                buff=0.1,
                color=GREY_B
            )
            arrows.add(arrow)

        # 布局右侧元素：垂直排列
        feature_groups.arrange(DOWN, buff=0.8)
        feature_groups.next_to(core_group, RIGHT, buff=2.5)

        # 更新箭头位置（因为feature_groups位置变了）
        for i, arrow in enumerate(arrows):
            arrow.put_start_and_end_on(
                core_rect.get_right(),
                feature_groups[i].get_left()
            )

        # 4. 动画播放流程
        # 分步展示三个特点
        for i in range(3):
            self.play(
                GrowArrow(arrows[i]),
                FadeIn(feature_groups[i], shift=LEFT),
                run_time=0.8
            )
            # 最后一个点进行额外强调
            if i == 2:
                emphasis_text = Text("体现科学性", font="AR PL UKai CN", font_size=24, color=RED_A)
                emphasis_text.next_to(feature_groups[i], DOWN, buff=0.2)
                self.play(
                    Indicate(feature_groups[i], color=RED),
                    Write(emphasis_text),
                    run_time=1.0
                )
