from manim import *

class EpigraphConvexityProof(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Proof: Epigraph Convexity ⇒ Function Convexity",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Split Layout
        # Left: Geometric Visualization
        # Right: Mathematical Derivation

        # --- Left Side: Graph ---
        ax = Axes(
            x_range=[-2, 4, 1],
            y_range=[-1, 5, 1],
            x_length=5,
            y_length=4.5,
            axis_config={"include_tip": True, "tip_shape": StealthTip}
        )

        # Define function f(x) = 0.25*(x-1)^2 + 1
        func = lambda x: 0.25 * (x - 1)**2 + 1
        graph = ax.plot(func, color=BLUE, x_range=[-1, 3.5])

        # Epigraph (area above curve)
        epigraph_area = ax.get_area(graph, x_range=[-1, 3.5], color=BLUE, opacity=0.3, bounded_graph=0)
        # Note: bounded_graph=0 usually fills down, but for epigraph we want up.
        # Manim's get_area fills to x-axis. We cheat by creating a polygon for the upper area manually for precision or using bounded_graph carefully.
        # Let's use a simpler polygon approach for the visual "Epigraph" look
        epigraph_poly = Polygon(
            *[ax.c2p(x, func(x)) for x in np.arange(-1, 3.6, 0.1)],
            ax.c2p(3.5, 5),
            ax.c2p(-1, 5),
            color=BLUE,
            fill_opacity=0.2,
            stroke_width=0
        )

        graph_label = MathTex("f(x)", color=BLUE, font_size=24).next_to(graph, DOWN, buff=0.1)
        epi_label = MathTex(r"\text{epi}(f)", color=BLUE_A, font_size=24).move_to(ax.c2p(1, 3.5))

        # Points setup
        x1, x2 = 0, 3
        p1 = ax.c2p(x1, func(x1))
        p2 = ax.c2p(x2, func(x2))

        dot1 = Dot(p1, color=YELLOW)
        dot2 = Dot(p2, color=YELLOW)
        label1 = MathTex("P_1", font_size=20).next_to(dot1, DOWN)
        label2 = MathTex("P_2", font_size=20).next_to(dot2, DOWN)

        # Secant line (convex combination)
        line = Line(p1, p2, color=ORANGE)

        # A point on the line
        theta = 0.5
        mid_point_coords = line.point_from_proportion(theta)
        mid_dot = Dot(mid_point_coords, color=RED)
        mid_label = MathTex(r"\theta P_1 + (1-\theta)P_2", font_size=18, color=RED).next_to(mid_dot, UP, buff=0.1)

        graph_group = VGroup(ax, graph, epigraph_poly, graph_label, epi_label, dot1, dot2, label1, label2, line, mid_dot, mid_label)
        graph_group.scale(0.8).to_edge(LEFT, buff=0.5).shift(DOWN*0.5)

        # --- Right Side: Math Steps ---
        step1 = MathTex(
            r"\text{Assume } \text{epi}(f) \text{ is convex.}",
            font_size=26
        )

        step2 = MathTex(
            r"\forall x_1, x_2, \text{ let } P_1=(x_1, f(x_1)), P_2=(x_2, f(x_2))",
            font_size=26
        )

        step3 = MathTex(
            r"\text{By convexity: } \theta P_1 + (1-\theta)P_2 \in \text{epi}(f)",
            font_size=26
        )

        step4 = MathTex(
            r"\Rightarrow (\theta x_1 + (1-\theta)x_2, \underbrace{\theta f(x_1) + (1-\theta)f(x_2)}_{y_{comb}}) \in \text{epi}(f)",
            font_size=24
        )

        step5 = MathTex(
            r"\text{Def of epi: } f(\theta x_1 + (1-\theta)x_2) \leq y_{comb}",
            font_size=26,
            color=YELLOW
        )

        step6 = MathTex(
            r"\therefore f \text{ is a convex function.}",
            font_size=28
        )

        math_group = VGroup(step1, step2, step3, step4, step5, step6).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        math_group.next_to(graph_group, RIGHT, buff=0.5).to_edge(RIGHT, buff=0.5)

        # Correct vertical alignment to title
        math_group.shift(UP * 0.5)

        # 3. Animation Sequence
        # Show Graph base
        self.play(Create(ax), Create(graph), FadeIn(epigraph_poly), Write(graph_label), Write(epi_label))

        # Show Assumption and Points
        self.play(
            Write(step1),
            FadeIn(dot1, dot2, label1, label2),
            Write(step2)
        )

        # Show Convex Combination Line and Math
        self.play(
            Create(line),
            Create(mid_dot),
            Write(mid_label),
            Write(step3)
        )

        # Show Derivation
        self.play(Write(step4))

        # Show Conclusion
        self.play(Write(step5))

        # Final Result
        box = SurroundingRectangle(step6, color=GREEN, buff=0.1)
        self.play(Write(step6), Create(box))
