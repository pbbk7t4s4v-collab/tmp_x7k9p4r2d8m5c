from manim import *

class EmbeddedOSPruning(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("嵌入式操作系统：资源裁剪策略",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("46", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 定义通用操作系统的大模块 (左侧)
        # 使用 2x3 网格表示全功能OS
        box_config = {
            "height": 1.2, "width": 1.8,
            "fill_opacity": 0.8, "stroke_width": 2
        }

        # 核心模块 (保留)
        core_mod = Rectangle(color=BLUE, **box_config)
        core_text = Text("内核调度", font="AR PL UKai CN", font_size=20).move_to(core_mod)
        core_group = VGroup(core_mod, core_text)

        mem_mod = Rectangle(color=BLUE, **box_config)
        mem_text = Text("内存管理", font="AR PL UKai CN", font_size=20).move_to(mem_mod)
        mem_group = VGroup(mem_mod, mem_text)

        driver_mod = Rectangle(color=BLUE, **box_config)
        driver_text = Text("基础驱动", font="AR PL UKai CN", font_size=20).move_to(driver_mod)
        driver_group = VGroup(driver_mod, driver_text)

        # 冗余模块 (将被裁剪)
        gui_mod = Rectangle(color=RED, **box_config)
        gui_text = Text("复杂GUI", font="AR PL UKai CN", font_size=20).move_to(gui_mod)
        gui_group = VGroup(gui_mod, gui_text)

        net_mod = Rectangle(color=RED, **box_config)
        net_text = Text("完整网络栈", font="AR PL UKai CN", font_size=20).move_to(net_mod)
        net_group = VGroup(net_mod, net_text)

        debug_mod = Rectangle(color=RED, **box_config)
        debug_text = Text("调试工具", font="AR PL UKai CN", font_size=20).move_to(debug_mod)
        debug_group = VGroup(debug_mod, debug_text)

        # 排列模块
        modules = VGroup(
            core_group, gui_group,
            mem_group, net_group,
            driver_group, debug_group
        ).arrange_in_grid(rows=2, cols=3, buff=0.2)

        modules.shift(LEFT * 2 + DOWN * 0.5)

        # 标签：通用OS
        label_gpos = Text("通用操作系统 (庞大)", font="AR PL UKai CN", font_size=24, color=GRAY)
        label_gpos.next_to(modules, UP, buff=0.3)

        self.play(
            FadeIn(label_gpos),
            Create(modules, lag_ratio=0.1)
        )

        # 3. 定义嵌入式硬件约束 (右侧)
        hardware_box = Rectangle(width=2.5, height=3, color=WHITE, stroke_width=4)
        hardware_label = Text("嵌入式硬件\n(资源受限)", font="AR PL UKai CN", font_size=24, color=YELLOW)
        hardware_label.move_to(hardware_box)
        hardware_group = VGroup(hardware_box, hardware_label)
        hardware_group.to_edge(RIGHT, buff=1.0).align_to(modules, UP)

        # 硬件参数
        specs = Text("ROM: KB级\nRAM: KB级", font="AR PL UKai CN", font_size=18, color=GRAY_B)
        specs.next_to(hardware_box, DOWN, buff=0.2)

        self.play(
            Create(hardware_box),
            Write(hardware_label),
            FadeIn(specs)
        )

        # 4. 裁剪过程动画
        # 红色模块淡出，表示被裁剪
        prune_text = Text("裁剪策略：去除冗余", font="AR PL UKai CN", font_size=28, color=ORANGE)
        prune_text.move_to(UP * 2) # 临时显示

        self.play(FadeIn(prune_text))

        # 变灰并淡出不需要的模块
        self.play(
            gui_group.animate.set_opacity(0.2),
            net_group.animate.set_opacity(0.2),
            debug_group.animate.set_opacity(0.2),
            run_time=1
        )
        self.play(
            FadeOut(gui_group),
            FadeOut(net_group),
            FadeOut(debug_group),
            FadeOut(prune_text), # 移除临时文字
            run_time=0.8
        )

        # 5. 重组与适配
        # 保留的模块重新排列
        kept_modules = VGroup(core_group, mem_group, driver_group)

        # 目标位置：在硬件盒子内部的上方，稍微缩小一点以适应
        target_group = kept_modules.copy()
        target_group.arrange(DOWN, buff=0.1)
        target_group.scale(0.6)
        target_group.move_to(hardware_box.get_center())

        # 箭头指示
        arrow = Arrow(start=modules.get_right(), end=hardware_box.get_left(), buff=0.2, color=GREEN)

        strategy_label = Text("核心方法：模块化 & 条件编译", font="AR PL UKai CN", font_size=26, color=GREEN)
        strategy_label.next_to(arrow, UP, buff=0.1)

        self.play(
            Transform(kept_modules, target_group),
            FadeOut(label_gpos), # 移除旧标签
            GrowArrow(arrow),
            Write(strategy_label)
        )

        # 6. 最终强调
        final_rect = SurroundingRectangle(hardware_group, color=GREEN, buff=0.1)
        result_text = Text("适配完成", font="AR PL UKai CN", font_size=24, color=GREEN)
        result_text.next_to(final_rect, DOWN, buff=0.1)

        self.play(
            Create(final_rect),
            Write(result_text)
        )
