from manim import *

class FluidDynamicsForSustainability(Scene):
    def construct(self):

        # 1. Title
        title = Text("Fluid Dynamics for Sustainability",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Core Concept Header
        header = Text("Applications in Environmental Science", font_size=28, weight=BOLD)
        header.next_to(title_group, DOWN, buff=0.7)
        self.play(FadeIn(header, shift=DOWN*0.5))

        # 3. Bulleted List of Applications
        # Using a VGroup to better control layout and animation
        points_group = VGroup()

        # Point 1: Simulation
        point1_text = Text("• Simulating flows in rivers, oceans, and atmosphere", font_size=26)
        point1_text.next_to(header, DOWN, buff=0.5).align_to(header, LEFT)
        points_group.add(point1_text)

        # Point 2: Analysis
        point2_text = Text("• Analyzing pollutant diffusion and climate change", font_size=26)
        point2_text.next_to(point1_text, DOWN, buff=0.3).align_to(point1_text, LEFT)
        points_group.add(point2_text)

        # Point 3: Decision Support
        point3_text = Text("• Informing decisions on water, floods, and air quality", font_size=26)
        point3_text.next_to(point2_text, DOWN, buff=0.3).align_to(point2_text, LEFT)
        points_group.add(point3_text)

        # Animate points appearing one by one
        self.play(Write(point1_text), run_time=1.5)
        self.play(Write(point2_text), run_time=1.5)
        self.play(Write(point3_text), run_time=1.5)

        # Highlight the final goal
        goal_box = SurroundingRectangle(points_group, color=BLUE, buff=0.2)
        goal_text = Text("Achieving Sustainable Development", font_size=28, color=BLUE, weight=BOLD)
        goal_text.next_to(goal_box, DOWN, buff=0.3)

        self.play(Create(goal_box))
        self.play(Write(goal_text))
