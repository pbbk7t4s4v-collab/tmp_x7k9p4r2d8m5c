from manim import *

class MaterialScienceScene(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("材料科学：晶体结构与相变预测",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("64", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 主要内容布局
        # 左侧：晶体结构
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/2d420861-da71-474e-b5d0-92a9e702d1ee/b28e272c-affb-4a4e-8370-e037b9e3294b/pictures/888_65/1.png") # 这里期望是一张精细的3D微观晶体结构图，展示原子球体通过化学键连接成复杂的空间点阵，原子带有金属光泽或发光效果。风格为高科技科研可视化，背景深邃，体现材料科学的微观奥秘。
        img1.height = 3.5 # 调整图片高度

        label1 = Text("晶体结构数字化表征", font="AR PL UKai CN", font_size=24, color=BLUE_B)

        group1 = Group(img1, label1).arrange(DOWN, buff=0.3)
        group1.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # 右侧：相变预测
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/2d420861-da71-474e-b5d0-92a9e702d1ee/b28e272c-affb-4a4e-8370-e037b9e3294b/pictures/888_65/2.png") # 这里期望是一张抽象的概念图，展示数据流和算法线条正在构建或分析一个新材料的形态，象征机器学习与材料发现的结合。风格为未来科幻风，色调以科技蓝和银色为主。
        img2.height = 3.5 # 调整图片高度

        label2 = Text("相变行为智能预测", font="AR PL UKai CN", font_size=24, color=BLUE_B)

        group2 = Group(img2, label2).arrange(DOWN, buff=0.3)
        group2.to_edge(RIGHT, buff=1.0).shift(DOWN * 0.5)

        # 中间：连接逻辑
        arrow = Arrow(group1.get_right(), group2.get_left(), color=YELLOW, buff=0.2)

        mid_text_1 = Text("热力学原理", font="AR PL UKai CN", font_size=20, color=WHITE)
        mid_text_sym = MathTex("+", color=WHITE).scale(0.8)
        mid_text_2 = Text("机器学习模型", font="AR PL UKai CN", font_size=20, color=WHITE)

        mid_group = VGroup(mid_text_1, mid_text_sym, mid_text_2).arrange(RIGHT, buff=0.1)
        mid_group.next_to(arrow, UP, buff=0.2)

        # 强调框
        surround_rect = SurroundingRectangle(mid_group, color=TEAL, buff=0.15)

        bottom_desc = Text("加速新材料发现", font="AR PL UKai CN", font_size=22, color=YELLOW)
        bottom_desc.next_to(arrow, DOWN, buff=0.2)

        # 3. 动画展示
        # 展示左侧晶体结构
        self.play(
            FadeIn(img1, shift=UP),
            Write(label1),
            run_time=1.5
        )

        # 展示中间的处理过程
        self.play(
            GrowArrow(arrow),
            FadeIn(mid_group, shift=UP),
            Create(surround_rect),
            run_time=1.5
        )

        # 展示右侧预测结果
        self.play(
            FadeIn(img2, shift=UP),
            Write(label2),
            Write(bottom_desc),
            run_time=1.5
        )
