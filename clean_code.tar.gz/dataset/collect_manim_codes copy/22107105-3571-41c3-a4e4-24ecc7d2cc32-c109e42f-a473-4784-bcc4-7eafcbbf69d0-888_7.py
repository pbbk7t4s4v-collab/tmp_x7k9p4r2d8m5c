from manim import *

class MethodOfExhaustion(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("矩形逼近法原理",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 坐标系与函数构建
        # 创建坐标系，位置稍微靠左
        axes = Axes(
            x_range=[0, 5, 1],
            y_range=[0, 6, 1],
            x_length=5,
            y_length=4,
            axis_config={"include_tip": True, "tip_shape": StealthTip}
        ).shift(LEFT * 2 + DOWN * 0.5)

        # 定义函数 y = 0.2x^2 + 1
        func = lambda x: 0.2 * x**2 + 1
        graph = axes.plot(func, x_range=[0, 4.5], color=BLUE, stroke_width=4)
        graph_label = MathTex("y = f(x)").next_to(graph, UP, buff=0.1).scale(0.8)

        # 3. 初始动画：显示坐标系和曲线
        self.play(
            Create(axes),
            Create(graph),
            Write(graph_label),
            run_time=2
        )

        # 4. 第一阶段：粗略分割 (dx=1.0)
        # 4个矩形
        rects_coarse = axes.get_riemann_rectangles(
            graph,
            x_range=[0, 4],
            dx=1.0,
            input_sample_type="left",
            stroke_width=1,
            stroke_color=WHITE,
            fill_opacity=0.6,
            color=TEAL
        )

        text_coarse = Text("将不规则图形\n分割为规则小矩形",
                          font="AR PL UKai CN",
                          font_size=24,
                          color=TEAL).next_to(axes, RIGHT, buff=1.0).shift(UP)

        arrow_1 = Arrow(start=text_coarse.get_left(), end=rects_coarse.get_right(), color=TEAL)

        self.play(
            FadeIn(rects_coarse, lag_ratio=0.1),
            Write(text_coarse),
            GrowArrow(arrow_1),
            run_time=2
        )

        # 5. 第二阶段：精细分割 (dx=0.25)
        # 16个矩形，误差变小
        rects_fine = axes.get_riemann_rectangles(
            graph,
            x_range=[0, 4],
            dx=0.25,
            input_sample_type="left",
            stroke_width=0.5,
            stroke_color=WHITE,
            fill_opacity=0.8,
            color=GREEN
        )

        text_fine = Text("分割越细\n逼近误差越小",
                        font="AR PL UKai CN",
                        font_size=24,
                        color=GREEN).move_to(text_coarse.get_center())

        # 误差区域的高亮框（示意）
        error_highlight = SurroundingRectangle(graph, color=YELLOW, buff=0.1)

        self.play(
            ReplacementTransform(rects_coarse, rects_fine),
            ReplacementTransform(text_coarse, text_fine),
            arrow_1.animate.set_color(GREEN),
            run_time=2
        )

        # 简单闪烁一下示意误差减小
        self.play(Create(error_highlight), run_time=0.5)
        self.play(FadeOut(error_highlight), run_time=0.5)

        # 6. 总结公式
        area_formula = MathTex(r"Area \approx \sum f(x_i) \Delta x").next_to(text_fine, DOWN, buff=0.5)

        self.play(Write(area_formula), run_time=1.5)
