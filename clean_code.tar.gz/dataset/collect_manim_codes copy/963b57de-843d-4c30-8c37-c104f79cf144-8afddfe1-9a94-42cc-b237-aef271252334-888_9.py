from manim import *

class Unit3NaziGermany(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Unit 3: The Stories of Nazi Germany",
                    font_size=34,  # Larger font size
                    color=WHITE,   # White text for contrast
                    weight=BOLD)   # Bold weight
        title.to_edge(UP, buff=0.5)

        # Title underline
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Title Animation
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Image Setup
        # Image 1: Historical Context
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/963b57de-843d-4c30-8c37-c104f79cf144/8afddfe1-9a94-42cc-b237-aef271252334/pictures/888_9/1.png") # A vintage, sepia-toned historical illustration representing the World War II era. The scene features a stack of old leather-bound books and a newspaper from the 1940s on a wooden desk, symbolizing historical literature and research. Realistic style.
        img1.height = 3.5
        img1.to_edge(RIGHT, buff=1).shift(DOWN * 0.5)

        # Image 2: Specific Reading Topic
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/963b57de-843d-4c30-8c37-c104f79cf144/8afddfe1-9a94-42cc-b237-aef271252334/pictures/888_9/2.png") # A retro-style illustration mimicking 1940s propaganda art. It depicts the concept of the 'Perfect Aryan' child: a young child with blonde hair and blue eyes, smiling, framed like a vintage poster. The style is historical and illustrative.
        img2.height = 3.5
        img2.move_to(img1.get_center()) # Same position for transition

        # 3. Content List Setup
        # Using BulletedList for clear structure
        content_list = BulletedList(
            "Historical Perspective: WWII Literature",
            "Reading: The 'Perfect Aryan' Child",
            "Speaking: Ethical Dilemmas & Debates",
            "Writing: Argumentative Essays",
            font_size=28,
            buff=0.4
        )
        content_list.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 4. Animation Sequence
        # Show first point and general historical context image
        self.play(
            FadeIn(img1, shift=LEFT),
            Write(content_list[0], run_time=1)
        )

        # Transition to specific reading topic image and show second point
        self.play(
            FadeOut(img1),
            FadeIn(img2),
            Write(content_list[1], run_time=1)
        )

        # Show remaining skills (Speaking and Writing)
        self.play(
            Write(content_list[2], run_time=1),
            Write(content_list[3], run_time=1)
        )

        # 5. Emphasis
        # Highlight the key theme with a surrounding rectangle
        rect = SurroundingRectangle(content_list, color=BLUE, buff=0.2)
        self.play(Create(rect, run_time=1.0))
