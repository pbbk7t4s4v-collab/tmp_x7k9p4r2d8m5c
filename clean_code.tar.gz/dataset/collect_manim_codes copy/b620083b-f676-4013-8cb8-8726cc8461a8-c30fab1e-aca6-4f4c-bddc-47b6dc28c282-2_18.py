from manim import *

class UncertaintyRelations(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("不确定度关系",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("26", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 一般形式部分
        # 文本说明
        label_general = Text("一般形式：",
                            font="AR PL UKai CN",
                            font_size=28,
                            color=BLUE_A)
        label_general.to_edge(LEFT, buff=1.5).shift(UP * 1.5)

        # 数学公式
        # u_x = sqrt( sum ( (df/dx_i * u_xi)^2 ) )
        tex_general = MathTex(
            r"u_x = \sqrt{\sum_{i=1}^{n} \left(\frac{\partial f}{\partial x_i} \cdot u_{x_i}\right)^2}",
            font_size=40
        )
        tex_general.next_to(label_general, DOWN, buff=0.3).align_to(label_general, LEFT).shift(RIGHT * 0.5)

        # 强调框
        rect_general = SurroundingRectangle(tex_general, color=BLUE, buff=0.2)

        # 3. 相对不确定度形式部分
        # 文本说明
        label_relative = Text("相对不确定度形式（适用于乘除、指数）：",
                             font="AR PL UKai CN",
                             font_size=28,
                             color=GREEN_A)
        label_relative.next_to(tex_general, DOWN, buff=1.0).align_to(label_general, LEFT)

        # 数学公式
        # u_rx = u_x / x_bar = sqrt( sum ( (d ln f / dx_i * u_xi)^2 ) )
        tex_relative = MathTex(
            r"u_{rx} = \frac{u_x}{\bar{x}} = \sqrt{\sum_{i=1}^{n} \left(\frac{\partial \ln f}{\partial x_i} \cdot u_{x_i}\right)^2}",
            font_size=40
        )
        tex_relative.next_to(label_relative, DOWN, buff=0.3).align_to(label_relative, LEFT).shift(RIGHT * 0.5)

        # 强调框
        rect_relative = SurroundingRectangle(tex_relative, color=GREEN, buff=0.2)

        # 4. 执行内容动画
        # 展示一般形式
        self.play(Write(label_general, run_time=0.8))
        self.play(
            FadeIn(tex_general, shift=RIGHT),
            Create(rect_general),
            run_time=1.2
        )

        # 展示相对形式
        self.play(Write(label_relative, run_time=0.8))
        self.play(
            FadeIn(tex_relative, shift=RIGHT),
            Create(rect_relative),
            run_time=1.2
        )
