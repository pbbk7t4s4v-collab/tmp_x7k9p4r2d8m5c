from manim import *

class FluidMechanicsIntro(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (按照模板要求)
        # ---------------------------------------------------------
        title = Text("流体力学概述：定义与核心价值",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局 - 分为左右两部分
        # 左侧：什么是流体？（定义）
        # 右侧：有什么作用？（重要性）
        # ---------------------------------------------------------

        # --- 左侧：定义模块 ---
        def_header = Text("什么是流体？", font="AR PL UKai CN", font_size=28, color=BLUE)

        # 使用几何图形展示分类
        # 液体框
        liquid_box = Rectangle(height=1.5, width=2.5, color=BLUE_A, fill_opacity=0.2)
        liquid_text = Text("液体\n(Liquid)", font="AR PL UKai CN", font_size=24).move_to(liquid_box)
        liquid_group = VGroup(liquid_box, liquid_text)

        # 气体框
        gas_box = Rectangle(height=1.5, width=2.5, color=BLUE_C, fill_opacity=0.2)
        gas_text = Text("气体\n(Gas)", font="AR PL UKai CN", font_size=24).move_to(gas_box)
        gas_group = VGroup(gas_box, gas_text)

        # 排列液气框
        shapes_group = VGroup(liquid_group, gas_group).arrange(RIGHT, buff=0.5)

        # 核心特性描述
        core_feature = Text("核心特性：受剪切力持续变形", font="AR PL UKai CN", font_size=22, color=YELLOW)
        core_feature.next_to(shapes_group, DOWN, buff=0.3)

        # 组合左侧
        left_content = VGroup(def_header, shapes_group, core_feature).arrange(DOWN, buff=0.5)
        left_content.to_edge(LEFT, buff=1.0).shift(DOWN*0.5)

        # --- 右侧：重要性模块 ---
        imp_header = Text("重要性与应用", font="AR PL UKai CN", font_size=28, color=GREEN)

        # 手动创建列表以避免BulletedList的LaTeX/字体问题
        list_texts = [
            "1. 航空航天 (气动设计)",
            "2. 能源工程 (管道运输)",
            "3. 气象环境 (天气预报)",
            "4. 生物医疗 (血液循环)"
        ]

        list_group = VGroup()
        for text_str in list_texts:
            dot = Dot(color=GREEN, radius=0.06)
            t = Text(text_str, font="AR PL UKai CN", font_size=24)
            line = VGroup(dot, t).arrange(RIGHT, buff=0.2)
            list_group.add(line)

        list_group.arrange(DOWN, buff=0.4, aligned_edge=LEFT)

        # 组合右侧
        right_content = VGroup(imp_header, list_group).arrange(DOWN, buff=0.5)
        right_content.to_edge(RIGHT, buff=1.5).align_to(left_content, UP)

        # 添加分隔线
        separator = DashedLine(UP, DOWN, color=GRAY).scale(2.5)
        separator.move_to(ORIGIN).shift(DOWN*0.5)

        # ---------------------------------------------------------
        # 3. 动画展示流程
        # ---------------------------------------------------------

        # 展示左侧定义
        self.play(FadeIn(def_header, shift=UP), run_time=0.8)
        self.play(
            Create(liquid_box), Write(liquid_text),
            Create(gas_box), Write(gas_text),
            run_time=1.5
        )
        self.play(Write(core_feature), run_time=1.0)

        # 展示中间分隔线
        self.play(Create(separator), run_time=0.5)

        # 展示右侧应用
        self.play(FadeIn(imp_header, shift=UP), run_time=0.8)

        # 逐条展示列表
        for item in list_group:
            self.play(FadeIn(item, shift=RIGHT), run_time=0.4)

        # 强调框：强调广泛性
        surround_rect = SurroundingRectangle(list_group, color=GREEN, buff=0.2)
        self.play(Create(surround_rect), run_time=1.0)

        # 停留
