from manim import *

class CNN_vs_DNN_Comparison(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("卷积网络为何优于全连接网络",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 构建左侧内容：全连接网络 (DNN)
        # 简单的全连接示意图：两层节点全连接
        dnn_left_nodes = VGroup(*[Dot(radius=0.08, color=BLUE) for _ in range(3)]).arrange(DOWN, buff=0.4)
        dnn_right_nodes = VGroup(*[Dot(radius=0.08, color=BLUE) for _ in range(3)]).arrange(DOWN, buff=0.4)
        dnn_nodes = VGroup(dnn_left_nodes, dnn_right_nodes).arrange(RIGHT, buff=1.5)

        dnn_lines = VGroup()
        for l_node in dnn_left_nodes:
            for r_node in dnn_right_nodes:
                line = Line(l_node.get_center(), r_node.get_center(), stroke_width=1, stroke_opacity=0.6, color=GREY)
                dnn_lines.add(line)

        dnn_group = VGroup(dnn_lines, dnn_nodes)
        dnn_group.shift(LEFT * 3.5 + UP * 0.5)

        dnn_label = Text("全连接网络", font="AR PL UKai CN", font_size=28, color=RED).next_to(dnn_group, UP)

        # DNN 特性文本
        dnn_text_1 = Text("参数量随维度爆炸", font="AR PL UKai CN", font_size=24, color=WHITE)
        dnn_text_2 = Text("易记忆噪声/过拟合", font="AR PL UKai CN", font_size=24, color=WHITE)
        dnn_text_group = VGroup(dnn_text_1, dnn_text_2).arrange(DOWN, buff=0.2).next_to(dnn_group, DOWN, buff=0.5)

        # 3. 构建右侧内容：卷积网络 (CNN)
        # 简单的卷积示意图：网格 + 卷积核框
        grid = VGroup(*[Square(side_length=0.4, stroke_width=1, stroke_color=WHITE, fill_opacity=0) for _ in range(16)])
        grid.arrange_in_grid(rows=4, cols=4, buff=0)

        # 卷积核示意 (黄色框)
        kernel_rect = SurroundingRectangle(grid[0:2], color=YELLOW, buff=0.05, stroke_width=3)
        # 调整大小以覆盖2x2区域 (这里简单模拟视觉效果)
        kernel_rect.stretch_to_fit_width(0.85)
        kernel_rect.stretch_to_fit_height(0.85)
        kernel_rect.move_to(grid[5].get_center() + UL * 0.2) # 放置在某个局部位置

        cnn_group = VGroup(grid, kernel_rect)
        cnn_group.shift(RIGHT * 3.5 + UP * 0.5)

        cnn_label = Text("卷积网络", font="AR PL UKai CN", font_size=28, color=GREEN).next_to(cnn_group, UP)

        # CNN 特性文本
        cnn_text_1 = Text("权重共享 & 参数少", font="AR PL UKai CN", font_size=24, color=WHITE)
        cnn_text_2 = Text("局部性假设 & 抗噪", font="AR PL UKai CN", font_size=24, color=WHITE)
        cnn_text_group = VGroup(cnn_text_1, cnn_text_2).arrange(DOWN, buff=0.2).next_to(cnn_group, DOWN, buff=0.5)

        # 4. 底部总结：组合优势
        summary_box = SurroundingRectangle(VGroup(dnn_text_group, cnn_text_group), color=BLUE, buff=0.2)
        # 放置在更下方
        summary_text = Text("最佳组合：前端卷积提取特征 + 后端全连接分类",
                           font="AR PL UKai CN", font_size=26, color=YELLOW)
        summary_text.to_edge(DOWN, buff=1.0)

        # 装饰线连接
        arrow_left = Arrow(start=dnn_text_group.get_bottom(), end=summary_text.get_top() + LEFT*2, color=GREY, buff=0.1)
        arrow_right = Arrow(start=cnn_text_group.get_bottom(), end=summary_text.get_top() + RIGHT*2, color=GREY, buff=0.1)

        # 5. 动画播放流程
        # 显示左右两边的图示和标签
        self.play(
            FadeIn(dnn_group, shift=UP),
            Write(dnn_label),
            FadeIn(cnn_group, shift=UP),
            Write(cnn_label),
            run_time=2
        )

        # 强调卷积核的局部性
        self.play(ScaleInPlace(kernel_rect, 1.2, rate_func=wiggle), run_time=1)

        # 显示文字对比点
        self.play(
            Write(dnn_text_group),
            Write(cnn_text_group),
            run_time=2
        )

        # 显示底部结论
        self.play(
            Create(arrow_left),
            Create(arrow_right),
            FadeIn(summary_text, shift=UP),
            run_time=2
        )
