from manim import *

class VonNeumannArchitecture(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("冯·诺伊曼体系结构与存储程序",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("14", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 绘制五大部件布局 (采用总线结构布局以避免遮挡)
        # 中央总线
        bus_line = Line(LEFT * 5.5, RIGHT * 5.5, color=GREY_B, stroke_width=8).shift(UP * 0.2)
        bus_label = Text("系统总线", font="AR PL UKai CN", font_size=20, color=GREY_B).next_to(bus_line, UP, buff=0.1)

        # 部件文本定义
        txt_cu = Text("控制器", font="AR PL UKai CN", font_size=24, color=YELLOW)
        txt_alu = Text("运算器", font="AR PL UKai CN", font_size=24, color=BLUE)
        txt_mem = Text("存储器", font="AR PL UKai CN", font_size=24, color=GREEN)
        txt_in = Text("输入", font="AR PL UKai CN", font_size=24)
        txt_out = Text("输出", font="AR PL UKai CN", font_size=24)

        # 设置位置：CPU在上，存储/IO在下
        txt_cu.move_to(UP * 2 + LEFT * 2.5)
        txt_alu.move_to(UP * 2 + RIGHT * 2.5)

        txt_in.move_to(DOWN * 1.5 + LEFT * 4)
        txt_mem.move_to(DOWN * 1.5) # 居中
        txt_out.move_to(DOWN * 1.5 + RIGHT * 4)

        # 创建边框
        box_cu = SurroundingRectangle(txt_cu, color=YELLOW, buff=0.2)
        box_alu = SurroundingRectangle(txt_alu, color=BLUE, buff=0.2)
        box_mem = SurroundingRectangle(txt_mem, color=GREEN, buff=0.2)
        box_in = SurroundingRectangle(txt_in, color=WHITE, buff=0.2)
        box_out = SurroundingRectangle(txt_out, color=WHITE, buff=0.2)

        # 组合显示
        components = VGroup(
            txt_cu, box_cu, txt_alu, box_alu,
            txt_mem, box_mem, txt_in, box_in,
            txt_out, box_out, bus_line, bus_label
        )
        self.play(FadeIn(components), run_time=1.5)

        # 3. 绘制连接线 (连接到总线)
        conn_cu = DoubleArrow(box_cu.get_bottom(), [box_cu.get_center()[0], bus_line.get_center()[1], 0], color=GREY, tip_length=0.15)
        conn_alu = DoubleArrow(box_alu.get_bottom(), [box_alu.get_center()[0], bus_line.get_center()[1], 0], color=GREY, tip_length=0.15)
        conn_mem = DoubleArrow(box_mem.get_top(), [box_mem.get_center()[0], bus_line.get_center()[1], 0], color=GREY, tip_length=0.15)
        conn_in = Arrow(box_in.get_top(), [box_in.get_center()[0], bus_line.get_center()[1], 0], color=GREY, tip_length=0.15)
        conn_out = Arrow([box_out.get_center()[0], bus_line.get_center()[1], 0], box_out.get_top(), color=GREY, tip_length=0.15)

        connections = VGroup(conn_cu, conn_alu, conn_mem, conn_in, conn_out)
        self.play(Create(connections), run_time=1.0)

        # 4. 演示存储程序思想
        # 底部解释文字
        explain_text = Text("程序指令与数据均以二进制形式存储", font="AR PL UKai CN", font_size=28, color=ORANGE)
        explain_text.to_edge(DOWN, buff=0.5)

        # 存储器内部变化：文字变二进制
        binary_content = Text("1011 0010\n1100 1110", font_size=16, color=RED).move_to(box_mem)

        self.play(
            Write(explain_text),
            Transform(txt_mem, binary_content),
            run_time=1.5
        )

        # 5. 演示指令自动执行 (数据流：存储器 -> 总线 -> 控制器)
        packet = Dot(color=RED, radius=0.08).move_to(box_mem.get_center())
        # 定义路径
        path_points = [
            box_mem.get_center(),
            [box_mem.get_center()[0], bus_line.get_center()[1], 0],
            [box_cu.get_center()[0], bus_line.get_center()[1], 0],
            box_cu.get_center()
        ]
        trace_path = VMobject()
        trace_path.set_points_as_corners(path_points)

        explain_text_2 = Text("机器自动读取并执行指令", font="AR PL UKai CN", font_size=28, color=YELLOW)
        explain_text_2.to_edge(DOWN, buff=0.5)

        self.play(
            MoveAlongPath(packet, trace_path),
            Transform(explain_text, explain_text_2),
            run_time=2.0
        )
