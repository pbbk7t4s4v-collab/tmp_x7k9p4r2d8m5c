from manim import *

class OrgChartRecursion(Scene):
    def construct(self):

        # 1. 标题部分 (按照模板要求)
        title = Text("案例引入:组织架构图的递归结构",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 定义节点位置和内容
        # 根节点
        ceo_pos = UP * 1.5
        node_ceo = Text("CEO", font="AR PL UKai CN", font_size=28).move_to(ceo_pos)

        # 第一层
        cto_pos = UP * 0 + LEFT * 3
        cfo_pos = UP * 0 + RIGHT * 3
        node_cto = Text("CTO", font="AR PL UKai CN", font_size=28).move_to(cto_pos)
        node_cfo = Text("CFO", font="AR PL UKai CN", font_size=28).move_to(cfo_pos)

        # 第二层 (CTO下)
        rd_pos = DOWN * 1.5 + LEFT * 4.5
        test_pos = DOWN * 1.5 + LEFT * 1.5
        node_rd = Text("研发", font="AR PL UKai CN", font_size=28).move_to(rd_pos)
        node_test = Text("测试", font="AR PL UKai CN", font_size=28).move_to(test_pos)

        # 第二层 (CFO下)
        fin_pos = DOWN * 1.5 + RIGHT * 3
        node_fin = Text("财务", font="AR PL UKai CN", font_size=28).move_to(fin_pos)

        # 3. 绘制连接线
        line_ceo_cto = Line(node_ceo.get_bottom(), node_cto.get_top(), color=GREY)
        line_ceo_cfo = Line(node_ceo.get_bottom(), node_cfo.get_top(), color=GREY)

        line_cto_rd = Line(node_cto.get_bottom(), node_rd.get_top(), color=GREY)
        line_cto_test = Line(node_cto.get_bottom(), node_test.get_top(), color=GREY)

        line_cfo_fin = Line(node_cfo.get_bottom(), node_fin.get_top(), color=GREY)

        # 4. 动画展示完整的树
        # 组合元素以便管理
        tree_nodes = VGroup(node_ceo, node_cto, node_cfo, node_rd, node_test, node_fin)
        tree_lines = VGroup(line_ceo_cto, line_ceo_cfo, line_cto_rd, line_cto_test, line_cfo_fin)

        self.play(FadeIn(node_ceo, shift=DOWN), run_time=0.5)
        self.play(
            Create(line_ceo_cto), Create(line_ceo_cfo),
            FadeIn(node_cto, shift=DOWN), FadeIn(node_cfo, shift=DOWN),
            run_time=1
        )
        self.play(
            Create(line_cto_rd), Create(line_cto_test), Create(line_cfo_fin),
            FadeIn(node_rd, shift=DOWN), FadeIn(node_test, shift=DOWN), FadeIn(node_fin, shift=DOWN),
            run_time=1
        )

        # 5. 强调递归性 (CTO子树)
        # 创建CTO子树的包围框
        subtree_group = VGroup(node_cto, node_rd, node_test, line_cto_rd, line_cto_test)
        rect = SurroundingRectangle(subtree_group, color=YELLOW, buff=0.3)

        # 解释文本
        explanation = Text("CTO 分支本身也是一棵完整的树",
                         font="AR PL UKai CN",
                         font_size=24,
                         color=YELLOW)
        explanation.next_to(rect, DOWN, buff=0.2)

        # 动画展示强调内容
        self.play(Create(rect), run_time=1)
        self.play(Write(explanation), run_time=1)

        # 6. 总结文本
        recursion_note = Text("这就是树的递归特性:子组织即子树",
                            font="AR PL UKai CN",
                            font_size=26,
                            color=BLUE_B)
        recursion_note.to_edge(DOWN, buff=0.5)

        self.play(FadeIn(recursion_note), run_time=1)
