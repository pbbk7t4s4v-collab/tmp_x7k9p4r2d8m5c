from manim import *

class UncertaintyRepresentation(Scene):
    def construct(self):

        # 1. 标题设置 (标准模板)
        title = Text("合成不确定度与结果表示",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("24", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局配置
        # 定义通用字体和大小
        text_font = "AR PL UKai CN"
        label_size = 28
        math_size = 32

        # --- 第一部分:合成不确定度 ---
        label_combined = Text("1. 合成不确定度 (Combined Uncertainty)", font=text_font, font_size=label_size, color=BLUE_B)
        # 公式: u_d = √(Δₐ² + Δᵦ²) ≈ 0.004 mm
        # 注意:使用 \Delta_a 和 \Delta_{\beta} 对应讲义中的下标
        math_combined = MathTex(
            r"u_d = \sqrt{\Delta_a^2 + \Delta_{\beta}^2} \approx 0.004 \text{ mm}",
            font_size=math_size
        )
        group_combined = VGroup(label_combined, math_combined).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        # --- 第二部分:相对不确定度 ---
        label_relative = Text("2. 相对不确定度 (Relative Uncertainty)", font=text_font, font_size=label_size, color=BLUE_B)
        # 公式: uᵣd = (u_d/x̄)×100% = 2%
        math_relative = MathTex(
            r"u_{rd} = \frac{u_d}{\bar{x}} \times 100\% = 2\%",
            font_size=math_size
        )
        group_relative = VGroup(label_relative, math_relative).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        # --- 第三部分:测量结果表示 ---
        label_result = Text("3. 最终测量结果表示", font=text_font, font_size=label_size, color=BLUE_B)
        # 结果: d = 0.246 ± 0.004 (mm);uᵣd = 2%
        math_result = MathTex(
            r"d = 0.246 \pm 0.004 \, (\text{mm}); \quad u_{rd} = 2\%",
            font_size=36,
            color=YELLOW
        )
        # 重点框选
        result_box = SurroundingRectangle(math_result, color=YELLOW, buff=0.15)

        group_result = VGroup(label_result, math_result).arrange(DOWN, buff=0.25, aligned_edge=LEFT)

        # 3. 整体布局与动画
        # 将三个部分垂直排列,左对齐
        main_content = VGroup(group_combined, group_relative, group_result).arrange(DOWN, buff=0.7, aligned_edge=LEFT)
        main_content.move_to(ORIGIN).shift(DOWN * 0.3) # 整体居中偏下一点,避开标题

        # 动画序列
        # 展示合成不确定度
        self.play(FadeIn(label_combined, shift=RIGHT))
        self.play(Write(math_combined))

        # 展示相对不确定度
        self.play(FadeIn(label_relative, shift=RIGHT))
        self.play(Write(math_relative))

        # 展示最终结果
        self.play(FadeIn(label_result, shift=RIGHT))
        self.play(Write(math_result))
        self.play(Create(result_box))
