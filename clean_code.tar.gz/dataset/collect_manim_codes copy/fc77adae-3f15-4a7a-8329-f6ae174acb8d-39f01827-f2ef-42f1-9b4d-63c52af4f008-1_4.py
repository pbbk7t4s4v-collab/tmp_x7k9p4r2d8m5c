from manim import *

class FluidMechanicsApplications(Scene):
    def construct(self):

        # Set a dark background for better contrast
        self.camera.background_color = "#1E1E1E"

        # 1. Title
        title = Text("Fluid Mechanics in Natural & Environmental Sciences",
                     font_size=34,
                     color=WHITE,
                     weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # Add bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Animate the title
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Create two columns for the main content

        # Column 1: Meteorology
        meteo_header = Text("1. Weather Forecasting", font_size=28, color=BLUE_C)
        meteo_desc = BulletedList(
            "Models atmospheric circulation",
            "Simulates temperature, pressure, etc.",
            "Based on fluid dynamics equations:",
            font_size=24
        ).set_color(WHITE)

        meteo_formula = MathTex(
            r"\rho \left( \frac{\partial \mathbf{v}}{\partial t} + \mathbf{v} \cdot \nabla \mathbf{v} \right) = -\nabla p + \mu \nabla^2 \mathbf{v}",
            font_size=32
        ).set_color(WHITE)

        meteo_group = VGroup(meteo_header, meteo_desc, meteo_formula).arrange(
            DOWN, buff=0.4, aligned_edge=LEFT
        )

        # Column 2: Environmental Science
        env_header = Text("2. Environmental Protection", font_size=28, color=GREEN_C)
        env_desc = BulletedList(
            "Predicts pollutant diffusion in water/air",
            "Guides water quality management",
            "Uses the convection-diffusion equation:",
            font_size=24
        ).set_color(WHITE)

        env_formula = MathTex(
            r"\frac{\partial c}{\partial t} + \nabla \cdot (\mathbf{u} c) = \nabla \cdot (D \nabla c)",
            font_size=32
        ).set_color(WHITE)

        env_group = VGroup(env_header, env_desc, env_formula).arrange(
            DOWN, buff=0.4, aligned_edge=LEFT
        )

        # Arrange the two columns side-by-side
        main_content = VGroup(meteo_group, env_group).arrange(RIGHT, buff=1.0).next_to(title_line, DOWN, buff=0.6)

        # 3. Animate the content sequentially

        # Animate the first column (Meteorology)
        self.play(FadeIn(meteo_group, shift=UP, run_time=1.5))

        # Highlight the Navier-Stokes equation
        box1 = SurroundingRectangle(meteo_formula, color=BLUE_C, buff=0.15)
        self.play(Create(box1), run_time=1)

        # Animate the second column (Environmental Science)
        self.play(FadeIn(env_group, shift=UP, run_time=1.5))

        # Highlight the Convection-Diffusion equation
        box2 = SurroundingRectangle(env_formula, color=GREEN_C, buff=0.15)
        self.play(Create(box2), run_time=1)
