from manim import *

class AutoclaveIntroduction(Scene):
    def construct(self):

        # Title Configuration
        title = Text("Autoclaves: Sterilization Equipment",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # Add bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Group title elements
        title_group = VGroup(title, title_line)

        # Title Animation
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("24", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # Main Content Layout
        # Left Side: Image of Autoclave
        # Right Side: Key points and reference to Section 8

        # Image setup with specific comment description
        img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_24/1.png") # An image showing a realistic illustration of a laboratory autoclave machine used for sterilization. The device features a stainless steel body, a heavy-duty door with a locking mechanism, and a digital control panel. The background is clean and neutral, suitable for scientific educational content, in a realistic style.

        # Adjust image size and position
        img.height = 4.0
        img.to_edge(LEFT, buff=1.5)
        img.shift(DOWN * 0.3)

        # Add a frame around the image
        img_frame = SurroundingRectangle(img, color=BLUE_C, buff=0.1, stroke_width=3)
        img_label = Text("Laboratory Autoclave", font_size=24, color=BLUE_C).next_to(img_frame, DOWN, buff=0.2)

        # Text Content Setup
        # Highlighting the function and the forward reference
        points = VGroup(
            Text("• High-pressure steam sterilization", font_size=26),
            Text("• Used for decontamination", font_size=26),
            Text("• Critical for biological safety", font_size=26),
            Text("• Detailed discussion in Section 8", font_size=26, color=YELLOW, weight=BOLD)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.6)

        points.next_to(img_frame, RIGHT, buff=1.0)

        # Animation Sequence
        # 1. Fade in Image and Frame
        self.play(
            FadeIn(img),
            Create(img_frame),
            Write(img_label)
        )

        # 2. Write Bullet Points one by one
        for point in points:
            self.play(Write(point), run_time=0.8)

        # 3. Highlight the last point (Section 8 reference)
        highlight_box = SurroundingRectangle(points[-1], color=YELLOW, buff=0.1)
        self.play(Create(highlight_box))
