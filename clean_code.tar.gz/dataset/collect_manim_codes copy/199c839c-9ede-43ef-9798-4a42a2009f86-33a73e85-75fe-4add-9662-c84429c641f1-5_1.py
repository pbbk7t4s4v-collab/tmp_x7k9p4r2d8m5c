from manim import *

class DeterminantPractice(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("行列式练习题",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局
        # 左侧:题目
        # 示例题目:计算二阶行列式
        problem_label = Text("例题:计算下列二阶行列式", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        problem_label.to_edge(LEFT, buff=1).shift(UP * 1.5)

        matrix_tex = MathTex(r"D = \begin{vmatrix} 3 & 4 \\ 2 & 5 \end{vmatrix}", font_size=48)
        matrix_tex.next_to(problem_label, DOWN, buff=0.5).align_to(problem_label, LEFT)

        # 右侧:公式提示
        # 使用方框展示公式
        formula_text = MathTex(r"\begin{vmatrix} a & b \\ c & d \end{vmatrix} = ad - bc", font_size=32)
        formula_desc = Text("主对角线 - 副对角线", font="AR PL UKai CN", font_size=20, color=YELLOW)
        formula_group = VGroup(formula_text, formula_desc).arrange(DOWN, buff=0.2)

        formula_box = SurroundingRectangle(formula_group, color=YELLOW, buff=0.2)
        formula_container = VGroup(formula_group, formula_box)
        formula_container.to_edge(RIGHT, buff=1).align_to(matrix_tex, UP)

        # 3. 动画展示题目和公式
        self.play(
            FadeIn(problem_label),
            Write(matrix_tex),
            FadeIn(formula_container)
        )

        # 4. 计算过程可视化
        # 步骤1: 代入数值
        step1 = MathTex(r"= 3 \times 5 - 4 \times 2", font_size=40)
        step1.next_to(matrix_tex, DOWN, buff=0.5).align_to(matrix_tex, LEFT)
        # 手动对齐等号(微调)
        step1.shift(RIGHT * 0.1)

        # 步骤2: 计算乘积
        step2 = MathTex(r"= 15 - 8", font_size=40)
        step2.next_to(step1, DOWN, buff=0.3).align_to(step1, LEFT)

        # 步骤3: 最终结果
        step3 = MathTex(r"= 7", font_size=40)
        step3.next_to(step2, DOWN, buff=0.3).align_to(step2, LEFT)

        # 演示主对角线 (3*5)
        # 这里使用简单的Indicate来强调,避免复杂的索引操作导致IndexError
        self.play(
            Write(step1),
            run_time=1.5
        )

        # 辅助箭头,展示交叉相乘的概念
        arrow_main = Arrow(start=matrix_tex.get_left() + UP*0.2 + RIGHT*1.2, end=matrix_tex.get_right() + DOWN*0.2 - RIGHT*1.2, color=GREEN, stroke_width=2, tip_length=0.1)
        arrow_sub = Arrow(start=matrix_tex.get_right() + UP*0.2 - RIGHT*1.2, end=matrix_tex.get_left() + DOWN*0.2 + RIGHT*1.2, color=RED, stroke_width=2, tip_length=0.1)
        # 注意:这里的坐标是大致估算的,为了视觉效果,实际中通常用Indicate

        self.play(FadeIn(arrow_main), FadeIn(arrow_sub), run_time=0.5)

        # 逐步显示计算结果
        self.play(TransformMatchingTex(step1.copy(), step2), run_time=1)
        self.play(TransformMatchingTex(step2.copy(), step3), run_time=1)

        # 5. 结果强调
        result_box = SurroundingRectangle(step3, color=GREEN, buff=0.1)
        self.play(Create(result_box), run_time=0.5)

        # 清理箭头保持画面整洁
        self.play(FadeOut(arrow_main), FadeOut(arrow_sub), run_time=0.5)
