from manim import *

class ConsolidationAndApplication(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("本章小结:巩固与应用",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容设计:学习闭环流程图 (理论 -> 实践 -> 应用)
        # ---------------------------------------------------------

        # 定义通用的样式配置
        box_config = {"color": BLUE, "buff": 0.2, "corner_radius": 0.2}
        text_font = "AR PL UKai CN"

        # 第一步:理论回顾
        step1_text = Text("理论回顾", font=text_font, font_size=28, color=YELLOW)
        step1_sub = Text("核心概念与公式", font=text_font, font_size=20, color=WHITE).next_to(step1_text, DOWN, buff=0.15)
        step1_group = VGroup(step1_text, step1_sub)
        step1_box = SurroundingRectangle(step1_group, **box_config)
        step1_obj = VGroup(step1_box, step1_group)

        # 第二步:编程实践
        step2_text = Text("编程实践", font=text_font, font_size=28, color=GREEN)
        step2_sub = Text("代码实现与调试", font=text_font, font_size=20, color=WHITE).next_to(step2_text, DOWN, buff=0.15)
        step2_group = VGroup(step2_text, step2_sub)
        step2_box = SurroundingRectangle(step2_group, color=GREEN, buff=0.2, corner_radius=0.2)
        step2_obj = VGroup(step2_box, step2_group)

        # 第三步:场景应用
        step3_text = Text("实际应用", font=text_font, font_size=28, color=RED)
        step3_sub = Text("解决真实问题", font=text_font, font_size=20, color=WHITE).next_to(step3_text, DOWN, buff=0.15)
        step3_group = VGroup(step3_text, step3_sub)
        step3_box = SurroundingRectangle(step3_group, color=RED, buff=0.2, corner_radius=0.2)
        step3_obj = VGroup(step3_box, step3_group)

        # 布局排列:水平居中
        main_flow = VGroup(step1_obj, step2_obj, step3_obj).arrange(RIGHT, buff=1.5)
        main_flow.move_to(ORIGIN).shift(UP * 0.5)

        # 连接箭头
        arrow1 = Arrow(start=step1_box.get_right(), end=step2_box.get_left(), color=GREY, buff=0.1)
        arrow2 = Arrow(start=step2_box.get_right(), end=step3_box.get_left(), color=GREY, buff=0.1)

        # 底部总结性文字
        bottom_text = Text("通过 动手写代码 将抽象的数学原理转化为具体的 解决方案",
                          font=text_font, font_size=24, color=BLUE_A)
        bottom_text.next_to(main_flow, DOWN, buff=1.0)

        # ---------------------------------------------------------
        # 3. 动画展示
        # ---------------------------------------------------------

        # 逐步显示流程块
        self.play(FadeIn(step1_obj, shift=DOWN), run_time=0.8)

        self.play(GrowArrow(arrow1), run_time=0.6)
        self.play(FadeIn(step2_obj, shift=DOWN), run_time=0.8)

        self.play(GrowArrow(arrow2), run_time=0.6)
        self.play(FadeIn(step3_obj, shift=DOWN), run_time=0.8)

        # 显示底部总结
        self.play(Write(bottom_text), run_time=1.5)

        # 最后强调一下中间的编程实践部分,因为是"应用"的核心
        self.play(
            step2_box.animate.set_stroke(width=6, color=YELLOW),
            Flash(step2_box, color=YELLOW, line_length=0.2, num_lines=8),
            run_time=1.0
        )
