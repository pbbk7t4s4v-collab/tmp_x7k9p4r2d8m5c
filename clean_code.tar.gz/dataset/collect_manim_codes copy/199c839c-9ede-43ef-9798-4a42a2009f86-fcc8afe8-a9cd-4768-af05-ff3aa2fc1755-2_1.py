from manim import *

class CalculusIntro(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("微积分的核心研究对象",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧文本内容：核心概念
        text_1 = Text("1. 处理连续变化的量", font="AR PL UKai CN", font_size=24)
        text_2 = Text("2. 研究变化的累积效应", font="AR PL UKai CN", font_size=24)
        text_3 = Text("3. 从有限近似到无限精确", font="AR PL UKai CN", font_size=24)

        # 组合文本并左对齐
        text_group = VGroup(text_1, text_2, text_3).arrange(DOWN, aligned_edge=LEFT, buff=0.6)
        text_group.to_edge(LEFT, buff=1.0).shift(UP * 0.5)

        # 文本强调框
        text_box = SurroundingRectangle(text_group, color=TEAL, buff=0.3)

        # 3. 右侧可视化：从有限矩形到积分面积
        # 坐标系
        ax = Axes(
            x_range=[0, 5, 1],
            y_range=[0, 5, 1],
            x_length=5,
            y_length=4,
            axis_config={"include_tip": True, "tip_width": 0.2, "tip_height": 0.2}
        ).next_to(text_group, RIGHT, buff=1.5)

        # 曲线函数
        func = ax.plot(lambda x: 0.2 * x**2 + 0.5, x_range=[0, 4.5], color=BLUE)
        func_label = MathTex("f(x)", color=BLUE, font_size=24).next_to(func, UP, buff=0.1)

        # 有限近似 (Riemann Rectangles)
        rects = ax.get_riemann_rectangles(
            ax.plot(lambda x: 0.2 * x**2 + 0.5),
            x_range=[0, 4],
            dx=0.5,
            stroke_width=1,
            stroke_color=WHITE,
            fill_opacity=0.6,
            color=YELLOW
        )

        # 无限精确 (Area)
        area = ax.get_area(
            func,
            x_range=[0, 4],
            color=GREEN,
            opacity=0.6
        )

        # 4. 动画流程

        # 展示文本列表
        self.play(FadeIn(text_group, shift=RIGHT), run_time=1)
        self.play(Create(text_box), run_time=0.8)

        # 展示坐标系和曲线
        self.play(Create(ax), Create(func), run_time=1.5)
        self.play(FadeIn(func_label, run_time=0.5))

        # 展示有限近似（离散矩形）
        self.play(Create(rects), run_time=1.5)

        # 展示从有限到无限的跨越（矩形变为平滑面积）
        # 添加数学符号说明
        limit_tex = MathTex(r"\lim_{n \to \infty} \sum \to \int", font_size=30, color=YELLOW)
        limit_tex.next_to(ax, DOWN)

        self.play(
            Transform(rects, area),
            Write(limit_tex),
            run_time=2
        )
