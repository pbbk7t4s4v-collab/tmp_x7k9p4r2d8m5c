from manim import *

class AbstractAlgebraSummary(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("抽象代数思想总结",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心思想演变:从具体到抽象
        # ---------------------------------------------------------
        # 左侧:具体计算
        concrete_label = Text("具体计算", font="AR PL UKai CN", font_size=28, color=BLUE_C)
        concrete_math = MathTex(r"1 + 2 = 3", color=BLUE_B).scale(0.8)
        concrete_group = VGroup(concrete_label, concrete_math).arrange(DOWN, buff=0.2)

        # 右侧:抽象结构
        abstract_label = Text("抽象结构", font="AR PL UKai CN", font_size=28, color=GREEN_C)
        abstract_math = MathTex(r"(G, \cdot)", color=GREEN_B).scale(0.8)
        abstract_group = VGroup(abstract_label, abstract_math).arrange(DOWN, buff=0.2)

        # 布局:左右分布
        top_content = VGroup(concrete_group, abstract_group).arrange(RIGHT, buff=3)
        top_content.next_to(title_line, DOWN, buff=0.8)

        # 转换箭头
        arrow = Arrow(start=concrete_group.get_right(), end=abstract_group.get_left(), color=YELLOW, buff=0.2)
        arrow_text = Text("演变", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(arrow, UP, buff=0.1)

        # 动画展示第一部分
        self.play(FadeIn(concrete_group, shift=RIGHT))
        self.play(GrowArrow(arrow), Write(arrow_text))
        self.play(FadeIn(abstract_group, shift=LEFT))

        # ---------------------------------------------------------
        # 3. 研究内容分类 (三个框图)
        # ---------------------------------------------------------
        # 定义内容文本
        item_texts = ["代数运算", "封闭性与性质", "对称性与结构"]
        item_groups = VGroup()

        for text in item_texts:
            t = Text(text, font="AR PL UKai CN", font_size=24, color=WHITE)
            # 使用矩形框包裹
            box = SurroundingRectangle(t, color=TEAL, buff=0.2, corner_radius=0.1)
            group = VGroup(box, t)
            item_groups.add(group)

        # 横向排列
        item_groups.arrange(RIGHT, buff=0.5)
        item_groups.next_to(top_content, DOWN, buff=1.0)

        # 连接线(从抽象结构指向下面三个内容)
        lines = VGroup()
        for item in item_groups:
            line = Line(abstract_group.get_bottom(), item.get_top(), color=GREY_B, stroke_opacity=0.5)
            lines.add(line)

        # 动画展示第二部分
        self.play(Create(lines, run_time=1))
        self.play(
            LaggedStart(
                *[FadeIn(item, shift=UP) for item in item_groups],
                lag_ratio=0.3
            )
        )

        # ---------------------------------------------------------
        # 4. 底部总结强调
        # ---------------------------------------------------------
        summary_text = Text("核心:研究结构而非数值", font="AR PL UKai CN", font_size=30, color=ORANGE)
        summary_text.next_to(item_groups, DOWN, buff=0.8)

        # 强调背景框
        summary_bg = SurroundingRectangle(summary_text, color=ORANGE, buff=0.15, fill_opacity=0.1, fill_color=ORANGE)

        self.play(
            Write(summary_text),
            FadeIn(summary_bg)
        )
