from manim import *

class WaveEquationDerivation(Scene):
    def construct(self):

        # 1. Title Configuration
        title = Text("Wave Equations: Divergence & Dimension Reduction",
                    font_size=34,  # Larger font size
                    color=WHITE,   # White text for contrast
                    weight=BOLD)   # Bold weight
        title.to_edge(UP, buff=0.5)  # Position at top

        # Add bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Combine title elements
        title_group = VGroup(title, title_line)

        # Title Animation
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("15", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Content Layout

        # --- Section 1: 3D Wave Equation ---
        label_1 = Text("Take divergence:", font_size=28, color=YELLOW)

        # Equation 1.1.20
        # Split into parts to isolate the summation for highlighting
        eq_3d = MathTex(
            r"\partial_{t}^{2} s - a^{2}",  # Part 0
            r"\sum_{j=1}^{3}",              # Part 1: Summation to 3
            r"\partial_{x_j}^{2} s = 0",    # Part 2
            font_size=42
        )
        tag_3d = MathTex(r"(1.1.20)", font_size=30, color=GRAY)
        tag_3d.next_to(eq_3d, RIGHT, buff=0.5)

        group_3d = VGroup(eq_3d, tag_3d).arrange(RIGHT, buff=0.5)
        section_1 = VGroup(label_1, group_3d).arrange(DOWN, aligned_edge=LEFT, buff=0.3)

        # --- Section 2: 2D Wave Equation ---
        label_2 = Text("If independent of x_3 (Dimension Reduction):", font_size=28, color=YELLOW)

        # Equation 1.1.21
        eq_2d = MathTex(
            r"\partial_{t}^{2} s - a^{2}",  # Part 0
            r"\sum_{j=1}^{2}",              # Part 1: Summation to 2
            r"\partial_{x_j}^{2} s = 0",    # Part 2
            font_size=42
        )
        tag_2d = MathTex(r"(1.1.21)", font_size=30, color=GRAY)
        tag_2d.next_to(eq_2d, RIGHT, buff=0.5)

        group_2d = VGroup(eq_2d, tag_2d).arrange(RIGHT, buff=0.5)
        section_2 = VGroup(label_2, group_2d).arrange(DOWN, aligned_edge=LEFT, buff=0.3)

        # Main grouping to center everything
        main_content = VGroup(section_1, section_2).arrange(DOWN, buff=1.0, aligned_edge=LEFT)
        main_content.move_to(ORIGIN)

        # 3. Animation Sequence

        # Show Section 1
        self.play(FadeIn(label_1, shift=RIGHT))
        self.play(Write(eq_3d), FadeIn(tag_3d))

        # Highlight the 3D summation index
        box_3d = SurroundingRectangle(eq_3d[1], color=BLUE, buff=0.1)
        self.play(Create(box_3d))

        # Show Section 2
        self.play(FadeIn(label_2, shift=RIGHT))

        # Transform logic: Show parts remain same, but sum changes
        self.play(
            TransformFromCopy(eq_3d[0], eq_2d[0]),
            TransformFromCopy(eq_3d[2], eq_2d[2]),
            Write(eq_2d[1]),
            FadeIn(tag_2d),
            Uncreate(box_3d)
        )

        # Highlight the 2D summation index
        box_2d = SurroundingRectangle(eq_2d[1], color=GREEN, buff=0.1)
        self.play(Create(box_2d))
