from manim import *

class ResistorColorCodeScene(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("色环电阻识读与计算",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧色环参考表 (可视化替代繁琐的文字表格)
        # 定义颜色数据: (颜色值, 名称, 数字/倍率)
        color_data = [
            (BLACK, "黑", "0"), ("#8B4513", "棕", "1"), (RED, "红", "2"),
            (ORANGE, "橙", "3"), (YELLOW, "黄", "4"), (GREEN, "绿", "5"),
            (BLUE, "蓝", "6"), (PURPLE, "紫", "7"), (GREY, "灰", "8"),
            (WHITE, "白", "9")
        ]

        ref_group = VGroup()
        ref_title = Text("色码对应表", font="AR PL UKai CN", font_size=20, color=BLUE_B)
        ref_group.add(ref_title)

        # 创建颜色条
        for col, name, num in color_data:
            row = VGroup()
            box = Rectangle(width=0.4, height=0.25, fill_color=col, fill_opacity=1, stroke_width=1, stroke_color=WHITE)
            txt = Text(f"{name} {num}", font="AR PL UKai CN", font_size=16).next_to(box, RIGHT, buff=0.1)
            row.add(box, txt)
            ref_group.add(row)

        ref_group.arrange(DOWN, buff=0.15, aligned_edge=LEFT)
        ref_group.to_edge(LEFT, buff=0.5).shift(DOWN*0.3)

        # 3. 右侧绘制电阻图形
        # 电阻主体 (米黄色)
        body_color = "#F0E68C"
        resistor_body = RoundedRectangle(width=4, height=1.2, corner_radius=0.3,
                                       fill_color=body_color, fill_opacity=1, stroke_color=WHITE)
        resistor_body.shift(RIGHT * 2 + UP * 0.5)

        # 引脚
        wire_left = Line(resistor_body.get_left() + LEFT, resistor_body.get_left(), color=GRAY, stroke_width=8)
        wire_right = Line(resistor_body.get_right(), resistor_body.get_right() + RIGHT, color=GRAY, stroke_width=8)

        resistor_group = VGroup(wire_left, wire_right, resistor_body)

        # 4. 示例: 棕-黑-红-金
        # 创建色环
        band_width = 0.25
        band_height = 1.2

        # 棕色环 (1)
        b1 = Rectangle(width=band_width, height=band_height, fill_color="#8B4513", fill_opacity=1, stroke_opacity=0)
        b1.move_to(resistor_body.get_left() + RIGHT * 0.6)

        # 黑色环 (0)
        b2 = Rectangle(width=band_width, height=band_height, fill_color=BLACK, fill_opacity=1, stroke_opacity=0)
        b2.next_to(b1, RIGHT, buff=0.4)

        # 红色环 (x10^2)
        b3 = Rectangle(width=band_width, height=band_height, fill_color=RED, fill_opacity=1, stroke_opacity=0)
        b3.next_to(b2, RIGHT, buff=0.4)

        # 金色环 (±5%)
        b4 = Rectangle(width=band_width, height=band_height, fill_color="#FFD700", fill_opacity=1, stroke_opacity=0)
        b4.move_to(resistor_body.get_right() + LEFT * 0.6)

        bands = VGroup(b1, b2, b3, b4)

        # 显示参考表和电阻
        self.play(
            FadeIn(ref_group, shift=RIGHT),
            Create(resistor_group),
            run_time=1.5
        )
        self.play(FadeIn(bands), run_time=0.5)

        # 5. 解读过程动画
        # 辅助函数:创建说明文字
        def create_label(text, target_obj, direction=DOWN):
            lbl = Text(text, font="AR PL UKai CN", font_size=20, color=YELLOW)
            lbl.next_to(target_obj, direction, buff=0.2)
            return lbl

        # 第一环:棕 -> 1
        lbl_1 = create_label("1 (有效位)", b1)
        hl_1 = SurroundingRectangle(ref_group[2], color=YELLOW, buff=0.02) # 对应左侧棕色行

        self.play(FadeIn(lbl_1), Create(hl_1), run_time=0.8)

        # 第二环:黑 -> 0
        lbl_2 = create_label("0 (有效位)", b2)
        hl_2 = SurroundingRectangle(ref_group[1], color=YELLOW, buff=0.02) # 对应左侧黑色行

        self.play(
            ReplacementTransform(hl_1, hl_2),
            FadeIn(lbl_2),
            run_time=0.8
        )

        # 第三环:红 -> 10^2
        lbl_3 = create_label("×10² (倍率)", b3)
        hl_3 = SurroundingRectangle(ref_group[3], color=YELLOW, buff=0.02) # 对应左侧红色行

        self.play(
            ReplacementTransform(hl_2, hl_3),
            FadeIn(lbl_3),
            run_time=0.8
        )

        # 第四环:金 -> 误差
        lbl_4 = create_label("±5% (误差)", b4)

        self.play(
            FadeOut(hl_3),
            FadeIn(lbl_4),
            run_time=0.8
        )

        # 6. 最终计算公式展示
        # 组合成公式: 10 * 10^2 = 1000 Ohm
        formula = MathTex(r"R = 10 \times 10^2 \Omega = 1000 \Omega = 1 k\Omega", font_size=36)
        formula.next_to(resistor_body, DOWN, buff=1.0)

        tolerance_text = Text("误差: ±5% (J级)", font="AR PL UKai CN", font_size=28, color=ORANGE)
        tolerance_text.next_to(formula, DOWN, buff=0.2)

        # 方框强调
        final_group = VGroup(formula, tolerance_text)
        box = SurroundingRectangle(final_group, color=BLUE, buff=0.2)

        self.play(
            FadeOut(lbl_1), FadeOut(lbl_2), FadeOut(lbl_3), FadeOut(lbl_4),
            Write(formula),
            run_time=1.5
        )
        self.play(Write(tolerance_text), Create(box), run_time=1)
