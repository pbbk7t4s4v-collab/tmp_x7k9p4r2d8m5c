from manim import *

class OnlineEducationExample(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格遵守模板)
        # ---------------------------------------------------------
        title = Text("在线教育平台多媒体应用示例",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局设计
        # ---------------------------------------------------------

        # 左侧：视频点播模块
        video_rect = Rectangle(height=3, width=4.5, color=BLUE)
        play_icon = Triangle(color=BLUE, fill_opacity=1).rotate(-90*DEGREES).scale(0.3)
        video_label = Text("视频点播系统", font="AR PL UKai CN", font_size=24, color=BLUE)
        video_label.next_to(play_icon, DOWN)

        # 视频技术细节列表
        video_details = VGroup(
            Text("• H.265编码压缩", font="AR PL UKai CN", font_size=20),
            Text("• CDN节点存储", font="AR PL UKai CN", font_size=20),
            Text("• 自适应码率(360p-1080p)", font="AR PL UKai CN", font_size=20)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        video_details.next_to(video_label, DOWN, buff=0.3)

        # 组合视频模块元素 (图标和文字居中)
        video_content = VGroup(play_icon, video_label, video_details).move_to(video_rect.get_center())
        video_group = VGroup(video_rect, video_content)

        # 右侧：交互与编程模块
        interact_rect = Rectangle(height=3, width=4.5, color=GREEN)
        code_icon = VGroup(
            Line(LEFT, RIGHT, color=GREEN).scale(0.5),
            Line(LEFT, RIGHT, color=GREEN).scale(0.5),
            Line(LEFT, RIGHT, color=GREEN).scale(0.3).align_to(LEFT, LEFT)
        ).arrange(DOWN, buff=0.2)
        interact_label = Text("交互式编程环境", font="AR PL UKai CN", font_size=24, color=GREEN)
        interact_label.next_to(code_icon, DOWN)

        # 交互技术细节列表
        interact_details = VGroup(
            Text("• 即时运行代码", font="AR PL UKai CN", font_size=20),
            Text("• 可视化结果反馈", font="AR PL UKai CN", font_size=20),
            Text("• 虚拟实验功能", font="AR PL UKai CN", font_size=20)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        interact_details.next_to(interact_label, DOWN, buff=0.3)

        # 组合交互模块元素
        interact_content = VGroup(code_icon, interact_label, interact_details).move_to(interact_rect.get_center())
        interact_group = VGroup(interact_rect, interact_content)

        # 将左右模块水平排列
        main_modules = VGroup(video_group, interact_group).arrange(RIGHT, buff=1)
        main_modules.next_to(title_group, DOWN, buff=0.5)

        # 底部：后台数据分析模块
        data_text = Text("学习行为数据", font="AR PL UKai CN", font_size=24, color=YELLOW)
        arrow = Arrow(LEFT, RIGHT, color=YELLOW)
        ai_text = Text("知识图谱 & 个性化推荐", font="AR PL UKai CN", font_size=24, color=YELLOW)

        bottom_group = VGroup(data_text, arrow, ai_text).arrange(RIGHT, buff=0.5)
        bottom_group.next_to(main_modules, DOWN, buff=0.8)

        # 底部边框
        bottom_rect = SurroundingRectangle(bottom_group, color=YELLOW, buff=0.2)

        # ---------------------------------------------------------
        # 3. 动画演示流程
        # ---------------------------------------------------------

        # 步骤 1: 展示视频点播模块
        self.play(Create(video_rect), FadeIn(video_content))

        # 步骤 2: 展示交互编程模块
        self.play(Create(interact_rect), FadeIn(interact_content))

        # 步骤 3: 展示后台数据流
        self.play(
            Write(data_text),
            GrowArrow(arrow),
            Write(ai_text)
        )
        self.play(Create(bottom_rect))

        # 步骤 4: 总结文字 (位于最下方)
        summary = Text("视频 · 音频 · 文本 · 图形 无缝整合",
                      font="AR PL UKai CN", font_size=28, color=ORANGE)
        summary.next_to(bottom_rect, DOWN, buff=0.3)

        self.play(FadeIn(summary, shift=UP))
