from manim import *

class AIGenomicsScene(Scene):
    def construct(self):

        # 1. 设置标题
        title = Text("AI在基因组学中的应用",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("21", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 主要应用列表
        applications_intro = Text("在基因组分析中，AI常用于：", font="AR PL UKai CN", font_size=28)
        applications_intro.next_to(title_group, DOWN, buff=0.5).to_edge(LEFT, buff=0.8)

        # 使用Tex来支持换行和更好的排版
        app_list = VGroup(
            Text("• 序列分析与基因预测 (CNN, RNN)", font="AR PL UKai CN", font_size=26, t2c={"CNN": YELLOW, "RNN": YELLOW}),
            Text("• 变异功能预测 (GBDT, 深度学习)", font="AR PL UKai CN", font_size=26, t2c={"GBDT": YELLOW}),
            Text("• 群体基因组分析 (t-SNE, UMAP)", font="AR PL UKai CN", font_size=26, t2c={"t-SNE": YELLOW, "UMAP": YELLOW})
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        app_list.next_to(applications_intro, DOWN, buff=0.3).align_to(applications_intro, LEFT)

        self.play(Write(applications_intro))
        self.play(FadeIn(app_list, shift=DOWN, lag_ratio=0.5), run_time=2)

        # 3. DeepVariant 示例
        example_title = Text("示例：DeepVariant", font="AR PL UKai CN", font_size=28, weight=BOLD)
        example_title.next_to(app_list, DOWN, buff=0.7).align_to(applications_intro, LEFT)

        self.play(Write(example_title))

        # 创建流程图
        step1_text = Text("DNA测序数据", font="AR PL UKai CN", font_size=24)
        arrow1 = Arrow(LEFT, RIGHT, buff=0.2)

        # 用一个简单的网格代表图像数据
        image_grid = VGroup(*[
            VGroup(*[Square(side_length=0.15, stroke_width=2, color=BLUE) for _ in range(4)])
            .arrange(RIGHT, buff=0.05)
            for _ in range(4)
        ]).arrange(DOWN, buff=0.05)
        image_text = Text("图像化数据", font="AR PL UKai CN", font_size=24).next_to(image_grid, DOWN, buff=0.15)
        image_group = VGroup(image_grid, image_text)

        arrow2 = Arrow(LEFT, RIGHT, buff=0.2)
        step3_text = Text("CNN模型", font="AR PL UKai CN", font_size=24, t2c={"CNN": YELLOW})
        arrow3 = Arrow(LEFT, RIGHT, buff=0.2)
        step4_text = Text("识别基因突变", font="AR PL UKai CN", font_size=24, color=RED)

        flowchart = VGroup(step1_text, arrow1, image_group, arrow2, step3_text, arrow3, step4_text)
        flowchart.arrange(RIGHT, buff=0.3)
        flowchart.next_to(example_title, DOWN, buff=0.4).scale(0.9)

        # 动画展示流程
        self.play(FadeIn(step1_text, shift=RIGHT))
        self.play(GrowArrow(arrow1))
        self.play(FadeIn(image_group, scale=0.5))
        self.play(GrowArrow(arrow2))
        self.play(FadeIn(step3_text, shift=RIGHT))

        # 高亮CNN模型
        cnn_box = SurroundingRectangle(step3_text, color=ORANGE, buff=0.1)
        self.play(Create(cnn_box))

        self.play(GrowArrow(arrow3))
        self.play(FadeIn(step4_text, scale=1.2))
