from manim import *
import numpy as np

class CriticalAngleComparison(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("水与玻璃的临界角对比",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 定义辅助函数来创建示意图和计算过程
        def create_setup(medium_name, n_value, angle_deg, color, pos_direction):
            # 容器
            group = VGroup()

            # 文本标签
            label = Text(f"{medium_name}\n(n ≈ {n_value})", font="AR PL UKai CN", font_size=24, color=color)

            # 界面线
            interface = Line(LEFT*2, RIGHT*2, color=WHITE)

            # 法线 (虚线)
            normal = DashedLine(DOWN*1.5, UP*1.5, color=GREY)

            # 介质标记 (界面下方)
            medium_rect = Rectangle(width=4, height=1.5, fill_color=color, fill_opacity=0.2, stroke_width=0)
            medium_rect.next_to(interface, DOWN, buff=0)

            # 入射光线 (从下往上)
            # 计算起始点
            angle_rad = np.radians(angle_deg)
            start_point = 1.5 * np.array([np.sin(-angle_rad), -np.cos(-angle_rad), 0])
            incident_ray = Arrow(start=start_point, end=ORIGIN, buff=0, color=YELLOW, stroke_width=3)

            # 折射光线 (沿界面掠射)
            refracted_ray = Arrow(start=ORIGIN, end=RIGHT*1.5, buff=0, color=RED, stroke_width=3)

            # 角度标注
            angle_arc = Angle(Line(ORIGIN, start_point), Line(ORIGIN, DOWN), radius=0.6, other_angle=True, color=WHITE)
            angle_label = MathTex(f"{angle_deg}^\circ", font_size=24).next_to(angle_arc, DOWN, buff=0.1)

            # 计算公式
            math_formula = MathTex(
                r"\sin C = \frac{1}{" + str(n_value) + r"} \\",
                r"\Rightarrow C \approx " + str(angle_deg) + r"^\circ",
                font_size=28
            )

            # 组合图形元素
            diagram = VGroup(medium_rect, interface, normal, incident_ray, refracted_ray, angle_arc, angle_label)

            # 整体布局
            # 标签在最上方
            # 图形在中间
            # 公式在下方
            diagram.next_to(label, DOWN, buff=0.2)
            math_formula.next_to(diagram, DOWN, buff=0.3)

            full_group = VGroup(label, diagram, math_formula)

            # 位置调整
            if np.all(pos_direction == LEFT):
                full_group.move_to(LEFT * 3.5 + DOWN * 0.5)
            else:
                full_group.move_to(RIGHT * 3.5 + DOWN * 0.5)

            return full_group, diagram, math_formula

        # 3. 创建两组内容
        # 水: n=1.33, C=48.8
        water_group, water_diag, water_math = create_setup("水 (Water)", 1.33, 48.8, BLUE, LEFT)

        # 玻璃: n=1.50, C=41.8
        glass_group, glass_diag, glass_math = create_setup("玻璃 (Glass)", 1.50, 41.8, TEAL, RIGHT)

        # 4. 动画展示

        # 显示介质名称和公式
        self.play(
            FadeIn(water_group[0]), # Label
            FadeIn(glass_group[0]), # Label
            run_time=1
        )

        # 同步绘制图形
        self.play(
            Create(water_diag),
            Create(glass_diag),
            run_time=2
        )

        # 显示计算结果
        self.play(
            Write(water_math),
            Write(glass_math),
            run_time=2
        )

        # 5. 结论强调
        conclusion_box = SurroundingRectangle(VGroup(water_math, glass_math), color=YELLOW, buff=0.2)
        conclusion_text = Text("结论:折射率 n 越大,临界角 C 越小",
                             font="AR PL UKai CN",
                             font_size=28,
                             color=YELLOW)
        conclusion_text.next_to(conclusion_box, UP, buff=0.1)
        # 放到两个公式中间上方稍微一点,避免遮挡图形
        conclusion_text.move_to(UP * 0.5) # 重新手动微调位置到中心

        # 绘制强调框和结论
        self.play(
            Create(conclusion_box),
            FadeIn(conclusion_text),
            run_time=1.5
        )

        # 稍微停顿
