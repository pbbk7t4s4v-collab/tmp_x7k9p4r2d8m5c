from manim import *

class EventRelationships(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (根据模板)
        # ---------------------------------------------------------
        title = Text("互不相容事件与对立事件",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容部分
        # ---------------------------------------------------------

        # --- 左侧:互不相容事件 (Mutually Exclusive) ---

        # 定义外框 (样本空间 Omega)
        left_box = Rectangle(height=3.5, width=4.5, color=WHITE)
        left_label_omega = MathTex(r"\Omega", font_size=24).move_to(left_box.get_corner(UR) + DL * 0.3)

        # 定义两个不相交的圆
        circle_a = Circle(radius=0.8, color=BLUE, fill_opacity=0.5).move_to(left_box.get_center() + LEFT * 1.2)
        circle_b = Circle(radius=0.8, color=RED, fill_opacity=0.5).move_to(left_box.get_center() + RIGHT * 1.2)

        label_a = MathTex("A", color=WHITE).move_to(circle_a)
        label_b = MathTex("B", color=WHITE).move_to(circle_b)

        # 文本描述
        left_text = Text("互不相容 (互斥)", font="AR PL UKai CN", font_size=28).next_to(left_box, UP, buff=0.2)
        left_math = MathTex(r"A \cap B = \emptyset", color=YELLOW, font_size=32).next_to(left_box, DOWN, buff=0.2)

        left_group = VGroup(left_box, left_label_omega, circle_a, circle_b, label_a, label_b, left_text, left_math)

        # --- 右侧:对立事件 (Complementary) ---

        # 定义外框,分为两半
        right_box = Rectangle(height=3.5, width=4.5, color=WHITE)

        # 左半边 A
        rect_a = Rectangle(height=3.5, width=2.25, color=BLUE, fill_opacity=0.5)
        rect_a.align_to(right_box, LEFT)

        # 右半边 A_bar
        rect_not_a = Rectangle(height=3.5, width=2.25, color=RED, fill_opacity=0.5)
        rect_not_a.align_to(right_box, RIGHT)

        # 确保位置对齐
        rect_a.move_to(right_box.get_center() + LEFT * 1.125)
        rect_not_a.move_to(right_box.get_center() + RIGHT * 1.125)

        right_label_omega = MathTex(r"\Omega", font_size=24).move_to(right_box.get_corner(UR) + DL * 0.3)

        label_ra = MathTex("A", color=WHITE).move_to(rect_a)
        label_rnot_a = MathTex(r"\overline{A}", color=WHITE).move_to(rect_not_a)

        # 文本描述
        right_text = Text("对立事件", font="AR PL UKai CN", font_size=28).next_to(right_box, UP, buff=0.2)

        # 公式组
        right_math = VGroup(
            MathTex(r"B = \overline{A}", font_size=32),
            MathTex(r"\overline{A} \cup A = \Omega", font_size=32)
        ).arrange(DOWN, buff=0.1).next_to(right_box, DOWN, buff=0.2).set_color(YELLOW)

        right_group = VGroup(right_box, rect_a, rect_not_a, right_label_omega, label_ra, label_rnot_a, right_text, right_math)

        # ---------------------------------------------------------
        # 3. 布局与动画
        # ---------------------------------------------------------

        # 整体布局:左右排列
        content_group = VGroup(left_group, right_group).arrange(RIGHT, buff=1.0)
        content_group.next_to(title_line, DOWN, buff=0.5)

        # 动画流程

        # 展示左侧:互斥
        self.play(FadeIn(left_text), Create(left_box), Write(left_label_omega))
        self.play(
            DrawBorderThenFill(circle_a),
            DrawBorderThenFill(circle_b),
            Write(label_a),
            Write(label_b)
        )
        self.play(Write(left_math))

        # 展示右侧:对立
        self.play(FadeIn(right_text), Create(right_box), Write(right_label_omega))
        self.play(
            FadeIn(rect_a),
            FadeIn(rect_not_a),
            Write(label_ra),
            Write(label_rnot_a)
        )
        self.play(Write(right_math))

        # 稍微停顿
