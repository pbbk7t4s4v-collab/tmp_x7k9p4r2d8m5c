from manim import *

class TaskTaxonomy(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("构建开放式任务分类体系",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("29", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容可视化：Taxonomy 树状结构
        # ---------------------------------------------------------

        # 根节点:开放式任务
        root_text = Text("开放式生成任务", font="AR PL UKai CN", font_size=28, color=BLACK)
        root_box = RoundedRectangle(corner_radius=0.2, width=4, height=1, color=BLUE, fill_opacity=1)
        root_group = VGroup(root_box, root_text)

        # 放置在标题下方
        root_group.next_to(title_line, DOWN, buff=1.0)

        # 子节点:具体的分类维度 (示例)
        leaf_configs = ["创意写作", "逻辑推理", "角色扮演"]
        leaves = VGroup()

        for text_str in leaf_configs:
            l_text = Text(text_str, font="AR PL UKai CN", font_size=24, color=WHITE)
            l_box = RoundedRectangle(corner_radius=0.15, width=2.5, height=0.8, color=TEAL, fill_opacity=0.8)
            l_group = VGroup(l_box, l_text)
            leaves.add(l_group)

        # 排列子节点
        leaves.arrange(RIGHT, buff=0.8)
        leaves.next_to(root_group, DOWN, buff=1.5)

        # 连线
        arrows = VGroup()
        for leaf in leaves:
            arrow = Arrow(start=root_group.get_bottom(), end=leaf.get_top(), buff=0.1, color=GREY_C)
            arrows.add(arrow)

        # ---------------------------------------------------------
        # 3. 动画展示流程
        # ---------------------------------------------------------

        # 显示根节点
        self.play(FadeIn(root_group, shift=DOWN), run_time=0.8)

        # 显示连线和子节点
        self.play(
            LaggedStart(
                *[Create(arrow) for arrow in arrows],
                lag_ratio=0.2
            ),
            LaggedStart(
                *[FadeIn(leaf, shift=UP) for leaf in leaves],
                lag_ratio=0.2
            ),
            run_time=1.5
        )

        # 强调分类体系的概念
        # 使用 SurroundingRectangle 包裹整体结构
        full_group = VGroup(root_group, leaves)
        surround_rect = SurroundingRectangle(full_group, color=YELLOW, buff=0.3, corner_radius=0.2)
        label = Text("Taxonomy (分类体系)", font="AR PL UKai CN", font_size=24, color=YELLOW)
        label.next_to(surround_rect, DOWN, buff=0.2)

        self.play(
            Create(surround_rect),
            Write(label),
            run_time=1.2
        )
