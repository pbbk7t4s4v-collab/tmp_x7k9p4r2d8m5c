from manim import *

class AIFairnessIntro(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("可信AI：公正性与决策公平",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("19", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念展示
        # 使用 Text 展示核心观点
        concept_text = Text("算法准确性 ≠ 公平性", font="AR PL UKai CN", font_size=36, color=YELLOW)
        concept_text.next_to(title_line, DOWN, buff=0.5)

        # 解释文本
        explanation = Text("历史数据中的偏见会被模型学习并放大", font="AR PL UKai CN", font_size=24, color=WHITE)
        explanation.next_to(concept_text, DOWN, buff=0.3)

        # 强调框
        rect = SurroundingRectangle(explanation, color=RED, buff=0.15)
        explanation_group = VGroup(explanation, rect)

        self.play(Write(concept_text))
        self.play(FadeIn(explanation), Create(rect))

        # 3. 三个应用场景图片展示
        # 图片 1: 招聘
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/835d5475-a08d-4cd1-935c-338eea91cae9/pictures/6_1/1.png") # 这里期望是一张扁平化风格的插画，代表"招聘"场景。画面显示一只机械手或放大镜正在筛选一堆纸质简历，象征AI筛选求职者，写实风
        img1.height = 2.2  # 调整高度适应屏幕

        # 图片 2: 信贷
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/835d5475-a08d-4cd1-935c-338eea91cae9/pictures/6_1/2.png") # 这里期望是一张扁平化风格的插画，代表"信贷"场景。画面包含银行卡、钱袋和一份写有数据的信用报告，象征金融贷款审批，写实风
        img2.height = 2.2

        # 图片 3: 司法
        img3 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/835d5475-a08d-4cd1-935c-338eea91cae9/pictures/6_1/3.png") # 这里期望是一张扁平化风格的插画，代表"司法"场景。画面主要是一个木质法槌和象征公正的天平，背景简洁，象征法律判决，写实风
        img3.height = 2.2

        # 图片排版：居中对齐，img2在中间，img1在左，img3在右
        img2.next_to(explanation_group, DOWN, buff=0.8)
        img1.next_to(img2, LEFT, buff=0.8)
        img3.next_to(img2, RIGHT, buff=0.8)

        # 4. 场景标签
        label_font_size = 24
        label1 = Text("招聘筛选", font="AR PL UKai CN", font_size=label_font_size).next_to(img1, DOWN, buff=0.2)
        label2 = Text("信贷审批", font="AR PL UKai CN", font_size=label_font_size).next_to(img2, DOWN, buff=0.2)
        label3 = Text("司法判决", font="AR PL UKai CN", font_size=label_font_size).next_to(img3, DOWN, buff=0.2)

        # 5. 动画展示图片和标签
        # 分组展示
        group1 = Group(img1, label1)
        group2 = Group(img2, label2)
        group3 = Group(img3, label3)

        self.play(
            FadeIn(img1, shift=UP),
            Write(label1),
            run_time=0.8
        )
        self.play(
            FadeIn(img2, shift=UP),
            Write(label2),
            run_time=0.8
        )
        self.play(
            FadeIn(img3, shift=UP),
            Write(label3),
            run_time=0.8
        )

        # 6. 总结性强调（可选，增强视觉效果）
        # 在图片下方添加一个总的说明文字
        summary = Text("争议高发领域", font="AR PL UKai CN", font_size=20, color=GRAY)
        summary.next_to(VGroup(label1, label2, label3), DOWN, buff=0.4)

        self.play(FadeIn(summary))
