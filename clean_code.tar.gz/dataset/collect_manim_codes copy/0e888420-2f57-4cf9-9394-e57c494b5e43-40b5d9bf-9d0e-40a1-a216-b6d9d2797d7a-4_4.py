from manim import *

class WeaponCharacteristics(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("关键武器装备:特点与战略意义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 定义三个主要板块
        # 辅助函数:创建内容卡片
        def create_card(title_text, desc_text, icon_mob, color):
            # 标题
            t = Text(title_text, font="AR PL UKai CN", font_size=24, color=color)
            # 描述 (分两行以避免太宽)
            lines = desc_text.split("\n")
            d_group = VGroup()
            for line in lines:
                d_group.add(Text(line, font="AR PL UKai CN", font_size=18, color=WHITE))
            d_group.arrange(DOWN, buff=0.1)

            # 组合图标和文字
            icon_mob.set_color(color)
            content = VGroup(icon_mob, t, d_group).arrange(DOWN, buff=0.3)

            # 边框
            box = SurroundingRectangle(content, color=color, buff=0.2, corner_radius=0.2)

            return VGroup(box, content)

        # 板块1:精确制导武器
        icon_precision = VGroup(
            Circle(radius=0.4, color=BLUE),
            Line(UP*0.5, DOWN*0.5, color=BLUE),
            Line(LEFT*0.5, RIGHT*0.5, color=BLUE)
        )
        card_precision = create_card(
            "精确制导武器",
            "直接命中率高\n附带损伤小",
            icon_precision,
            BLUE
        )

        # 板块2:核化生武器
        # 使用三角形代表警示
        icon_nbc = Triangle(color=RED).scale(0.5)
        exclamation = Text("!", font="AR PL UKai CN", color=RED).move_to(icon_nbc.get_center())
        icon_nbc_group = VGroup(icon_nbc, exclamation)
        card_nbc = create_card(
            "核化生武器",
            "杀伤破坏范围大\n具有心理威慑",
            icon_nbc_group,
            RED
        )

        # 板块3:新概念武器
        # 使用多角星代表高科技/激光
        icon_new = Star(n=5, outer_radius=0.4, inner_radius=0.2, color=PURPLE)
        card_new = create_card(
            "新概念武器",
            "机理与技术创新\n改变战争形态",
            icon_new,
            PURPLE
        )

        # 3. 排版与动画
        # 将三个卡片水平排列
        cards = VGroup(card_precision, card_nbc, card_new).arrange(RIGHT, buff=0.5)
        cards.move_to(ORIGIN).shift(UP*0.2)

        # 底部总结文字
        summary_text = Text(
            "意义:信息化战争中夺取优势的关键力量",
            font="AR PL UKai CN",
            font_size=24,
            color=YELLOW
        )
        summary_text.next_to(cards, DOWN, buff=0.8)

        # 动画展示
        # 依次显示三个板块
        self.play(FadeIn(cards[0], shift=UP), run_time=1)
        self.play(FadeIn(cards[1], shift=UP), run_time=1)
        self.play(FadeIn(cards[2], shift=UP), run_time=1)

        # 显示底部总结
        self.play(Write(summary_text), run_time=1.5)

        # 强调动画:给底部文字加一个框
        summary_box = SurroundingRectangle(summary_text, color=YELLOW, buff=0.15)
        self.play(Create(summary_box))
