from manim import *

class TraditionalBottlenecks(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("传统范式的瓶颈：维数灾难与求解困难",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局设计 - 分为左右两部分
        # 左侧：数据驱动范式
        left_title = Text("数据驱动范式", font="AR PL UKai CN", font_size=26, color=BLUE)

        # 可视化：简单的散点图表示数据采集
        axes = Axes(
            x_range=[0, 4], y_range=[0, 4],
            x_length=2.5, y_length=2.5,
            axis_config={"include_tip": False}
        )
        # 生成一些稀疏的数据点，象征数据获取不易
        dots = VGroup(*[
            Dot(axes.c2p(x, y), color=BLUE_A, radius=0.08)
            for x, y in [(1, 1), (1, 3), (2, 2), (3, 1), (3, 3)]
        ])
        left_visual = VGroup(axes, dots)

        # 左侧文字列表
        l_item1 = Text("• 科学数据采集昂贵(材料/药物)", font="AR PL UKai CN", font_size=20)
        l_item2 = Text("• 缺乏适应高维结构的通用方法", font="AR PL UKai CN", font_size=20)
        left_list = VGroup(l_item1, l_item2).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # 组合左侧元素
        left_group = VGroup(left_title, left_visual, left_list).arrange(DOWN, buff=0.4)
        left_group.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # 右侧：理论模型范式
        right_title = Text("理论模型范式", font="AR PL UKai CN", font_size=26, color=GREEN)

        # 可视化：薛定谔方程
        equation = MathTex(
            r"i\hbar\frac{\partial}{\partial t}\Psi = \hat{H}\Psi",
            font_size=36
        )
        # 保持视觉高度一致
        equation.match_height(left_visual).scale(0.6)

        # 右侧文字列表
        r_item1 = Text("• 原理已解(如薛定谔方程)", font="AR PL UKai CN", font_size=20)
        r_item2 = Text("• 自由度高，数值求解成本极高", font="AR PL UKai CN", font_size=20)
        right_list = VGroup(r_item1, r_item2).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # 组合右侧元素
        right_group = VGroup(right_title, equation, right_list).arrange(DOWN, buff=0.8) # 调整buff以对齐
        right_group.to_edge(RIGHT, buff=1.0).shift(DOWN * 0.5)

        # 对齐调整：确保左右两边的文字部分在同一水平线上
        right_list.align_to(left_list, UP)

        # 3. 动画展示内容
        # 第一阶段：展示标题和图标
        self.play(
            FadeIn(left_title, shift=RIGHT),
            FadeIn(right_title, shift=LEFT)
        )

        # 展示左侧数据点和右侧公式
        self.play(
            Create(axes),
            FadeIn(dots, scale=0.5),
            Write(equation)
        )

        # 第二阶段：展示具体问题文本
        self.play(
            Write(left_list),
            Write(right_list)
        )

        # 4. 强调瓶颈 (SurroundingRectangle)
        rect_left = SurroundingRectangle(left_list, color=RED, buff=0.15)
        rect_right = SurroundingRectangle(right_list, color=RED, buff=0.15)

        # 瓶颈标签
        label_left = Text("高维数据稀缺", font="AR PL UKai CN", font_size=18, color=RED)
        label_left.next_to(rect_left, DOWN)

        label_right = Text("计算复杂度爆炸", font="AR PL UKai CN", font_size=18, color=RED)
        label_right.next_to(rect_right, DOWN)

        self.play(
            Create(rect_left),
            Create(rect_right),
            FadeIn(label_left, shift=UP),
            FadeIn(label_right, shift=UP)
        )
