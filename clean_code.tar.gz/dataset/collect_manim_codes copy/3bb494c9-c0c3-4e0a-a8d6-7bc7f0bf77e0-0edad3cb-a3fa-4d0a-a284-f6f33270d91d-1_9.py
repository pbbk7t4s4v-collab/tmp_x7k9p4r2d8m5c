from manim import *

class ConservationLaws(Scene):
    def construct(self):

        # 1. Title Setup (Template provided)
        title = Text("Conservation Laws: Mass Conservation",
                    font_size=34,  # 增大字号
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Content Layout
        # Left side: Mathematical Derivation
        condition = MathTex(r"\text{If } f \equiv 0 \text{ (No Source/Sink):}", font_size=32, color=BLUE_B)

        eq_pde = MathTex(r"u_t + \mathrm{div} \vec{F} = 0", font_size=38)

        arrow = MathTex(r"\Downarrow", font_size=32)

        eq_integral = MathTex(r"\frac{d}{dt} \int_{\Omega} u(t, x) \, dx \equiv 0", font_size=38)

        # Arrange equations vertically
        math_group = VGroup(condition, eq_pde, arrow, eq_integral).arrange(DOWN, buff=0.4)
        math_group.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # Right side: Visual Representation
        # A simple domain Omega
        domain = Ellipse(width=3.5, height=2.5, color=BLUE, fill_opacity=0.2, stroke_width=4)
        label_omega = MathTex(r"\Omega", color=BLUE).next_to(domain, UP, buff=0.1)

        # Particles or Text inside to represent Mass
        mass_label = Text("Total Mass\nConstant", font_size=24, color=WHITE).move_to(domain.get_center())

        visual_group = VGroup(domain, label_omega, mass_label)
        visual_group.next_to(math_group, RIGHT, buff=1.5)

        # 3. Animation Sequence
        # Step 1: Show the condition
        self.play(FadeIn(condition, shift=RIGHT))

        # Step 2: Show the PDE
        self.play(Write(eq_pde))

        # Step 3: Show implication and Integral form
        self.play(FadeIn(arrow, shift=DOWN))
        self.play(Write(eq_integral))

        # Step 4: Show Visualization and Conclusion
        self.play(
            Create(domain),
            Write(label_omega),
            FadeIn(mass_label, scale=0.8)
        )

        # Highlight the result
        highlight_rect = SurroundingRectangle(eq_integral, color=YELLOW, buff=0.15)
        highlight_text = Text("Conservation of Mass", font_size=24, color=YELLOW).next_to(highlight_rect, DOWN)

        self.play(
            Create(highlight_rect),
            Write(highlight_text)
        )
