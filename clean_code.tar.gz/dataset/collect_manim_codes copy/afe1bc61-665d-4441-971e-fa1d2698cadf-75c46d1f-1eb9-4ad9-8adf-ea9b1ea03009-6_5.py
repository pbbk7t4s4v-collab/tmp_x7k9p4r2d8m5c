from manim import *

class SprintMechanism(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("Scrum核心机制：Sprint(冲刺)",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("35", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：循环示意图
        # 创建一个带有箭头的圆弧表示迭代
        cycle_radius = 1.2
        cycle_arc = Arc(
            radius=cycle_radius,
            start_angle=90 * DEGREES,
            angle=-330 * DEGREES,
            color=BLUE,
            stroke_width=6
        ).add_tip(tip_length=0.3)

        center_text = Text("Sprint\n(1-4周)", font="AR PL UKai CN", font_size=28, line_spacing=1.2)
        center_text.move_to(cycle_arc.get_center())

        cycle_group = VGroup(cycle_arc, center_text)
        cycle_group.to_edge(LEFT, buff=1.5).shift(DOWN * 0.5)

        # 3. 右侧：核心特征列表
        # 使用Text而不是BulletedList以确保中文字体支持更稳健
        list_config = {
            "font": "AR PL UKai CN",
            "font_size": 26,
            "color": WHITE
        }

        # 定义列表项内容
        items_text = [
            "• 固定时长：建立稳定节奏 (不可更改)",
            "• 明确目标：清晰的 Sprint Goal",
            "• 完整周期：规划→开发→测试→回顾",
            "• 可交付增量：潜在可发布产品",
            "• 保护机制：期间不接受新需求"
        ]

        text_objects = VGroup()
        for text in items_text:
            text_obj = Text(text, **list_config)
            text_objects.add(text_obj)

        # 排版列表
        text_objects.arrange(DOWN, aligned_edge=LEFT, buff=0.45)
        text_objects.next_to(cycle_group, RIGHT, buff=1.0)

        # 4. 动画展示
        # 显示左侧循环图
        self.play(
            Create(cycle_arc),
            FadeIn(center_text),
            run_time=1.5
        )

        # 逐条显示右侧文字
        for i, item in enumerate(text_objects):
            self.play(
                FadeIn(item, shift=RIGHT * 0.2),
                run_time=0.6
            )

            # 特别强调最后一点"保护机制"
            if i == len(text_objects) - 1:
                highlight_box = SurroundingRectangle(item, color=YELLOW, buff=0.1)
                self.play(Create(highlight_box), run_time=0.5)
