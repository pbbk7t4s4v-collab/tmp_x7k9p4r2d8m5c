from manim import *

class IOPollingInefficiency(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("I/O 控制方式：轮询方式的低效",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("22", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心可视化：CPU 与 I/O 设备的交互模型
        # 定义组件
        cpu_box = Square(side_length=1.5, color=BLUE, fill_opacity=0.2)
        cpu_text = Text("CPU", font="AR PL UKai CN", font_size=24).move_to(cpu_box)
        cpu_group = VGroup(cpu_box, cpu_text).shift(LEFT * 3)

        io_box = Square(side_length=1.5, color=GREEN, fill_opacity=0.2)
        io_text = Text("I/O设备", font="AR PL UKai CN", font_size=24).move_to(io_box)
        io_group = VGroup(io_box, io_text).shift(RIGHT * 3)

        # 绘制组件
        self.play(FadeIn(cpu_group), FadeIn(io_group))

        # 3. 动画展示：轮询过程（忙等）
        # 定义箭头路径
        arrow_query = Arrow(start=cpu_box.get_right(), end=io_box.get_left(), color=YELLOW, buff=0.1).shift(UP*0.3)
        label_query = Text("准备好了吗？", font="AR PL UKai CN", font_size=16, color=YELLOW).next_to(arrow_query, UP, buff=0.05)

        arrow_reply = Arrow(start=io_box.get_left(), end=cpu_box.get_right(), color=RED, buff=0.1).shift(DOWN*0.3)
        label_reply = Text("没呢(未就绪)", font="AR PL UKai CN", font_size=16, color=RED).next_to(arrow_reply, DOWN, buff=0.05)

        # 第一次查询
        self.play(GrowArrow(arrow_query), FadeIn(label_query), run_time=0.5)
        self.play(GrowArrow(arrow_reply), FadeIn(label_reply), run_time=0.5)

        # 模拟循环（快速闪烁表示频繁查询）
        for _ in range(2):
            self.play(
                Indicate(arrow_query, color=WHITE, scale_factor=1.1),
                Indicate(arrow_reply, color=WHITE, scale_factor=1.1),
                run_time=0.4
            )

        # 4. 概念总结（右侧或下方列表）
        # 这里为了布局不遮挡，放在下方
        summary_items = [
            "CPU 处于"忙等"状态 (Busy Waiting)",
            "不断重复查询，无法执行其他任务",
            "严重浪费 CPU 资源",
        ]
        summary_list = VGroup(*[
            Text(f"• {item}", font="AR PL UKai CN", font_size=24)
            for item in summary_items
        ])
        summary_list.arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        summary_list.to_edge(DOWN, buff=0.5)

        # 5. 强调低效区域
        # 框选中间的交互区域，表示这里是瓶颈
        interaction_area = VGroup(arrow_query, arrow_reply, label_query, label_reply)
        surround_rect = SurroundingRectangle(interaction_area, color=ORANGE, buff=0.2)

        warn_text = Text("低效瓶颈", font="AR PL UKai CN", font_size=20, color=ORANGE)
        warn_text.next_to(surround_rect, UP, buff=0.1)

        self.play(
            Create(surround_rect),
            Write(warn_text),
            run_time=1
        )

        # 逐步显示总结文字
        for item in summary_list:
            self.play(FadeIn(item, shift=UP * 0.2), run_time=0.6)
