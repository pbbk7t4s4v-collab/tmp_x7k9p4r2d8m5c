from manim import *

class SecondaryContainerScene(Scene):
    def construct(self):

        # Title Setup
        title = Text("Secondary Container Specifications",
                    font_size=34,  # Larger font size
                    color=WHITE,   # White text for contrast
                    weight=BOLD)   # Bold weight
        title.to_edge(UP, buff=0.5)  # Position at top

        # Add bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Combine title elements
        title_group = VGroup(title, title_line)

        # Title Animation
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # Image Setup
        # Loading the planner suggested image
        img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_10/1.png") # A realistic educational illustration of a medical secondary container used for transporting infectious substances. The container is a durable, watertight cylindrical canister or leak-proof pouch. Attached to the outside of this container is a transparent waterproof bag holding paper documents. The style is clean and clinical, suitable for a safety manual, on a white background.

        # Adjust image size and position (1:1 aspect ratio expected)
        img.set_height(4.0)
        img.to_edge(RIGHT, buff=1.5)
        img.shift(DOWN * 0.5)

        # Text Content Setup
        # Using Text objects manually arranged to avoid BulletedList LaTeX issues
        # and to ensure perfect alignment without overflow.
        p1_line1 = Text("• Durable, water-resistant,", font_size=24)
        p1_line2 = Text("  and leak-proof structure.", font_size=24)

        p2_line1 = Text("• Protects the primary container", font_size=24)
        p2_line2 = Text("  during transport.", font_size=24)

        p3_line1 = Text("• Related documents placed within", font_size=24)
        p3_line2 = Text("  waterproof bags on the outside.", font_size=24)

        # Grouping text lines
        text_content = VGroup(
            p1_line1, p1_line2,
            p2_line1, p2_line2,
            p3_line1, p3_line2
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # Positioning text
        text_content.to_edge(LEFT, buff=1.0)
        text_content.match_y(img) # Align vertically with the image

        # Highlighting with SurroundingRectangle
        highlight_box = SurroundingRectangle(text_content, color=BLUE, buff=0.3)

        # Animation Sequence
        # 1. Fade in the image
        self.play(FadeIn(img, shift=LEFT), run_time=1.0)

        # 2. Draw the box
        self.play(Create(highlight_box), run_time=1.0)

        # 3. Write the text points
        self.play(Write(text_content), run_time=3.0)

        # Hold final state
