from manim import *

class JudicialNarrativeStrategies(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板要求)
        title = Text("裁判文书中的价值叙事策略",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("42", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 定义三个策略的容器,使用 VGroup 排列

        # 通用字体配置
        font_conf = {"font": "AR PL UKai CN"}

        # --- 策略 1: 法理论证 ---
        s1_title = Text("法理论证策略", font_size=24, color=BLUE_A, **font_conf)
        s1_text1 = Text("价值判断", font_size=20, **font_conf)
        s1_arrow = MathTex(r"\rightarrow", color=WHITE).scale(0.8)
        s1_text2 = Text("法律原则", font_size=20, color=YELLOW, **font_conf)
        s1_sub = Text("(如:诚实信用)", font_size=16, color=GRAY_B, **font_conf)

        s1_content = VGroup(s1_text1, s1_arrow, s1_text2).arrange(RIGHT, buff=0.1)
        s1_group = VGroup(s1_title, s1_content, s1_sub).arrange(DOWN, buff=0.3)

        s1_box = SurroundingRectangle(s1_group, color=BLUE, buff=0.2, fill_opacity=0.1, fill_color=BLUE_E)
        s1_full = VGroup(s1_box, s1_group)

        # --- 策略 2: 情理融合 ---
        s2_title = Text("情理融合策略", font_size=24, color=GREEN_A, **font_conf)
        s2_text1 = Text("法律适用", font_size=20, **font_conf)
        s2_plus = MathTex("+", color=WHITE)
        s2_text2 = Text("伦理道德", font_size=20, color=YELLOW, **font_conf)
        s2_sub = Text("(如:孝道伦理)", font_size=16, color=GRAY_B, **font_conf)

        s2_content = VGroup(s2_text1, s2_plus, s2_text2).arrange(RIGHT, buff=0.1)
        s2_group = VGroup(s2_title, s2_content, s2_sub).arrange(DOWN, buff=0.3)

        s2_box = SurroundingRectangle(s2_group, color=GREEN, buff=0.2, fill_opacity=0.1, fill_color=GREEN_E)
        s2_full = VGroup(s2_box, s2_group)

        # --- 策略 3: 社会效果论证 ---
        s3_title = Text("社会效果论证", font_size=24, color=RED_A, **font_conf)
        s3_text1 = Text("裁判判决", font_size=20, **font_conf)
        s3_arrow = MathTex(r"\Rightarrow", color=WHITE).scale(0.8)
        s3_text2 = Text("社会导向", font_size=20, color=YELLOW, **font_conf)
        s3_sub = Text("(弘扬正气、惩恶扬善)", font_size=16, color=GRAY_B, **font_conf)

        s3_content = VGroup(s3_text1, s3_arrow, s3_text2).arrange(RIGHT, buff=0.1)
        s3_group = VGroup(s3_title, s3_content, s3_sub).arrange(DOWN, buff=0.3)

        s3_box = SurroundingRectangle(s3_group, color=RED, buff=0.2, fill_opacity=0.1, fill_color=RED_E)
        s3_full = VGroup(s3_box, s3_group)

        # 3. 整体排列
        strategies = VGroup(s1_full, s2_full, s3_full).arrange(RIGHT, buff=0.5)
        strategies.move_to(ORIGIN).shift(DOWN * 0.5)

        # 4. 动画展示
        # 依次展示三个策略框
        self.play(FadeIn(strategies, shift=UP), run_time=1.5)

        # 强调关键概念 (依次放大)
        self.play(
            Indicate(s1_text2, color=YELLOW),
            run_time=1
        )
        self.play(
            Indicate(s2_text2, color=YELLOW),
            run_time=1
        )
        self.play(
            Indicate(s3_text2, color=YELLOW),
            run_time=1
        )

        # 5. 总结文字
        summary_text = Text("法官通过叙事策略实现价值表达", font_size=26, color=GOLD, **font_conf)
        summary_text.next_to(strategies, DOWN, buff=0.5)

        self.play(Write(summary_text), run_time=1.5)
