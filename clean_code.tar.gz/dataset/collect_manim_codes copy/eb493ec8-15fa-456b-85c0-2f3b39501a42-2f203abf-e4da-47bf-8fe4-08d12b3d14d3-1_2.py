from manim import *

class WhatIsIntelligence(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("思考：什么是智能？",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念展示 - 中心节点
        center_text = Text("智能", font="AR PL UKai CN", font_size=48, color=YELLOW)
        center_box = SurroundingRectangle(center_text, color=YELLOW, buff=0.3, corner_radius=0.2)
        center_group = VGroup(center_box, center_text).move_to(DOWN * 0.5)

        self.play(FadeIn(center_group, scale=0.5))

        # 3. 四大要素分支
        # 定义四个方向的属性:(:文字, 相对位置向量)
        attributes_data = [
            ("感知环境", UL * 2.5),
            ("逻辑推理", UR * 2.5),
            ("自我学习", DL * 2.5),
            ("决策行动", DR * 2.5)
        ]

        arrows = VGroup()
        attribute_groups = VGroup()

        for text_str, direction in attributes_data:
            # 创建文字
            attr_text = Text(text_str, font="AR PL UKai CN", font_size=32, color=BLUE_A)
            # 定位
            attr_text.move_to(center_group.get_center() + direction)
            # 创建外框
            attr_box = SurroundingRectangle(attr_text, color=BLUE, buff=0.15)
            # 组合
            attr_group = VGroup(attr_box, attr_text)
            attribute_groups.add(attr_group)

            # 创建箭头
            arrow = Arrow(
                start=center_box.get_edge_center(direction),
                end=attr_box.get_edge_center(-direction),
                color=WHITE,
                buff=0.1,
                stroke_width=3,
                max_tip_length_to_length_ratio=0.15
            )
            arrows.add(arrow)

        # 4. 动画展示分支
        self.play(
            LaggedStart(
                *[GrowArrow(arrow) for arrow in arrows],
                lag_ratio=0.2,
                run_time=1.5
            ),
            LaggedStart(
                *[Write(group) for group in attribute_groups],
                lag_ratio=0.2,
                run_time=1.5
            )
        )

        # 5. 总结性描述
        summary_text = Text("模拟人类认知与解决问题的能力",
                           font="AR PL UKai CN",
                           font_size=28,
                           color=GREY_A)
        summary_text.next_to(center_group, DOWN, buff=2.5)

        self.play(FadeIn(summary_text, shift=UP))

        # 停顿,保持画面
