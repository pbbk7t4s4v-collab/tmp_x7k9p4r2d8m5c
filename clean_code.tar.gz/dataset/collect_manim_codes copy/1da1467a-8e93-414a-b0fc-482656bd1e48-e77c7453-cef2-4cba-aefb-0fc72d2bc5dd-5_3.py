from manim import *

class LoaderIntroduction(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("装入程序的引入与自动化萌芽",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("29", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心可视化：内存模型与装入过程
        # ---------------------------------------------------------

        # 定义内存条
        mem_height = 5
        mem_width = 2
        memory_outline = Rectangle(height=mem_height, width=mem_width, color=WHITE)
        memory_outline.shift(LEFT * 2.5) # 放置在左侧区域

        mem_label = Text("主存储器", font="AR PL UKai CN", font_size=24).next_to(memory_outline, UP)

        self.play(Create(memory_outline), FadeIn(mem_label))

        # 第一步：展示装入程序 (Loader) 驻留在内存中
        loader_height = 1
        loader_block = Rectangle(
            height=loader_height,
            width=mem_width,
            color=BLUE,
            fill_opacity=0.6
        )
        # 将装入程序放置在内存底部
        loader_block.move_to(memory_outline.get_bottom() + UP * (loader_height / 2))

        loader_text = Text("装入程序\n(Loader)", font="AR PL UKai CN", font_size=20, color=WHITE)
        loader_text.move_to(loader_block)

        self.play(
            FadeIn(loader_block, shift=UP),
            Write(loader_text)
        )

        # 第二步：外部输入 (模拟纸带/磁带)
        input_label = Text("外部程序\n(纸带/磁带)", font="AR PL UKai CN", font_size=24, color=GRAY)
        input_label.next_to(memory_outline, LEFT, buff=2)

        # 箭头指示
        arrow = Arrow(start=input_label.get_right(), end=memory_outline.get_left(), color=YELLOW)

        self.play(FadeIn(input_label), GrowArrow(arrow))

        # 第三步：用户程序被自动装入
        user_prog_height = 2.5
        user_prog_block = Rectangle(
            height=user_prog_height,
            width=mem_width,
            color=GREEN,
            fill_opacity=0.6
        )
        # 放置在装入程序上方
        user_prog_block.move_to(loader_block.get_top() + UP * (user_prog_height / 2))

        user_prog_text = Text("用户程序", font="AR PL UKai CN", font_size=22, color=WHITE)
        user_prog_text.move_to(user_prog_block)

        self.play(
            FadeIn(user_prog_block, shift=RIGHT), # 模拟从外部进入
            Write(user_prog_text),
            run_time=1.5
        )

        # ---------------------------------------------------------
        # 3. 右侧文字讲解 (核心概念)
        # ---------------------------------------------------------

        # 使用 Text 而不是 BulletedList 避免 LaTeX 问题，手动排列
        line1 = Text("1. 引入：预先存入的"搬运工"程序", font="AR PL UKai CN", font_size=26, color=BLUE_B)
        line2 = Text("2. 机制：计算机自动读入用户作业", font="AR PL UKai CN", font_size=26, color=GREEN_B)
        line3 = Text("3. 意义：操作系统的自动化萌芽", font="AR PL UKai CN", font_size=26, color=YELLOW)

        # 组合并排列
        text_group = VGroup(line1, line2, line3).arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        text_group.next_to(memory_outline, RIGHT, buff=1.5).shift(UP * 0.5)

        # 强调框
        surround_box = SurroundingRectangle(text_group, color=WHITE, buff=0.3)

        # 依次展示文字
        self.play(Write(line1))
        self.play(Write(line2))
        self.play(Write(line3))

        # 最后展示强调框
        self.play(Create(surround_box))
