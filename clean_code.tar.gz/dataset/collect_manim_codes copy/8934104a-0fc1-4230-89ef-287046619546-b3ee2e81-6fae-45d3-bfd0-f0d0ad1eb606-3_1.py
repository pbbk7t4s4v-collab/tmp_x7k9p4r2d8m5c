from manim import *

class DecisionTreeBasicFlow(Scene):
    def construct(self):

        # 1. 标题部分
        title = Text("决策树的基本流程",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 创建决策树的图形元素
        # 根节点 (内部节点)
        root_box = RoundedRectangle(corner_radius=0.2, width=3, height=1, color=BLUE, fill_opacity=0.5)
        root_text = Text("内部节点\n(特征判断)", font="AR PL UKai CN", font_size=24)
        root_node = VGroup(root_box, root_text).shift(UP * 1.5)

        # 分支线条
        start_point = root_box.get_bottom()
        end_point_left = start_point + DL * 2.5 + LEFT * 0.5
        end_point_right = start_point + DR * 2.5 + RIGHT * 0.5

        line_left = Line(start_point, end_point_left, color=GREY)
        line_right = Line(start_point, end_point_right, color=GREY)

        # 分支标签
        label_left = Text("是 (结果1)", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(line_left, LEFT, buff=-1.0).shift(UP*0.3, LEFT*0.2)
        label_right = Text("否 (结果2)", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(line_right, RIGHT, buff=-1.0).shift(UP*0.3, RIGHT*0.2)

        # 叶节点
        leaf_box_left = RoundedRectangle(corner_radius=0.2, width=2.5, height=1, color=GREEN, fill_opacity=0.5)
        leaf_text_left = Text("叶节点\n(分类A)", font="AR PL UKai CN", font_size=24)
        leaf_node_left = VGroup(leaf_box_left, leaf_text_left).move_to(end_point_left)

        leaf_box_right = RoundedRectangle(corner_radius=0.2, width=2.5, height=1, color=GREEN, fill_opacity=0.5)
        leaf_text_right = Text("叶节点\n(分类B)", font="AR PL UKai CN", font_size=24)
        leaf_node_right = VGroup(leaf_box_right, leaf_text_right).move_to(end_point_right)

        # 3. 动画展示流程
        # 步骤1:显示根节点
        self.play(FadeIn(root_node, shift=DOWN))

        # 步骤2:生长出分支
        self.play(
            Create(line_left),
            Create(line_right),
            Write(label_left),
            Write(label_right)
        )

        # 步骤3:显示叶节点
        self.play(FadeIn(leaf_node_left, shift=UP), FadeIn(leaf_node_right, shift=UP))

        # 4. 概念强调 (使用SurroundingRectangle)
        # 强调内部节点
        rect_root = SurroundingRectangle(root_node, color=RED, buff=0.1)
        desc_root = Text("表示一个判断", font="AR PL UKai CN", font_size=20, color=RED).next_to(rect_root, RIGHT)
        self.play(Create(rect_root), Write(desc_root))
        self.play(Uncreate(rect_root), FadeOut(desc_root))

        # 强调分支
        rect_branch = SurroundingRectangle(VGroup(line_left, label_left), color=ORANGE, buff=0.1)
        desc_branch = Text("代表判断结果", font="AR PL UKai CN", font_size=20, color=ORANGE).next_to(rect_branch, LEFT)
        self.play(Create(rect_branch), Write(desc_branch))
        self.play(Uncreate(rect_branch), FadeOut(desc_branch))

        # 强调叶节点
        rect_leaves = SurroundingRectangle(VGroup(leaf_node_left, leaf_node_right), color=TEAL, buff=0.1)
        desc_leaves = Text("代表最终分类结果", font="AR PL UKai CN", font_size=20, color=TEAL).next_to(rect_leaves, DOWN)
        self.play(Create(rect_leaves), Write(desc_leaves))
