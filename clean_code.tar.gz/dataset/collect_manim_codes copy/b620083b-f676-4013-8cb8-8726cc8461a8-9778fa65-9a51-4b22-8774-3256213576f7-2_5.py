from manim import *

class InheritanceExamples(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置
        # ---------------------------------------------------------
        title = Text("继承实例讲解",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 辅助函数:创建类节点
        # ---------------------------------------------------------
        def create_class_node(name_cn, name_en, color=BLUE):
            # 文本内容
            text_group = VGroup(
                Text(name_cn, font="AR PL UKai CN", font_size=24, color=WHITE),
                Text(name_en, font="AR PL UKai CN", font_size=20, color=GREY_B)
            ).arrange(DOWN, buff=0.1)

            # 外框 (使用SurroundingRectangle)
            box = SurroundingRectangle(
                text_group,
                color=color,
                buff=0.2,
                corner_radius=0.1,
                fill_opacity=0.1,
                fill_color=color
            )

            return VGroup(box, text_group)

        # ---------------------------------------------------------
        # 3. 实例一：池塘类派生 (左侧)
        # ---------------------------------------------------------
        # 父类
        pool_base = create_class_node("池塘类", "(Pool)", color=BLUE)
        pool_base.move_to(LEFT * 3.5 + UP * 1.0)

        # 子类
        swim_pool = create_class_node("游泳池", "(SwimmingPool)", color=GREEN)
        fish_pond = create_class_node("鱼塘", "(FishPond)", color=GREEN)

        # 布局子类
        swim_pool.next_to(pool_base, DOWN, buff=1.5).shift(LEFT * 1.8)
        fish_pond.next_to(pool_base, DOWN, buff=1.5).shift(RIGHT * 1.8)

        # 连接箭头
        arrow_swim = Arrow(start=pool_base.get_bottom(), end=swim_pool.get_top(), color=GREY, buff=0.1)
        arrow_fish = Arrow(start=pool_base.get_bottom(), end=fish_pond.get_top(), color=GREY, buff=0.1)

        # ---------------------------------------------------------
        # 4. 实例二：人员类派生 (右侧)
        # ---------------------------------------------------------
        # 父类
        people_base = create_class_node("人员类", "(People)", color=BLUE)
        people_base.move_to(RIGHT * 3.5 + UP * 1.0)

        # 子类
        student = create_class_node("学生类", "(Student)", color=GREEN)
        student.next_to(people_base, DOWN, buff=1.5)

        # 连接箭头
        arrow_student = Arrow(start=people_base.get_bottom(), end=student.get_top(), color=GREY, buff=0.1)

        # ---------------------------------------------------------
        # 5. 动画展示流程
        # ---------------------------------------------------------

        # 步骤1：展示池塘父类
        self.play(
            FadeIn(pool_base, shift=DOWN),
            run_time=1
        )

        # 步骤2：展示池塘的派生 (分支结构)
        self.play(
            GrowArrow(arrow_swim),
            GrowArrow(arrow_fish),
            FadeIn(swim_pool, shift=UP),
            FadeIn(fish_pond, shift=UP),
            run_time=1.5
        )

        # 步骤3：展示人员父类
        self.play(
            FadeIn(people_base, shift=DOWN),
            run_time=1
        )

        # 步骤4：展示人员的派生 (单线结构)
        self.play(
            GrowArrow(arrow_student),
            FadeIn(student, shift=UP),
            run_time=1
        )

        # ---------------------------------------------------------
        # 6. 添加派生关系说明文字 (少量)
        # ---------------------------------------------------------
        label_text = Text("父类 (基类) -> 子类 (派生类)", font="AR PL UKai CN", font_size=20, color=YELLOW)
        label_text.to_edge(DOWN, buff=1.0)

        self.play(Write(label_text), run_time=1)
