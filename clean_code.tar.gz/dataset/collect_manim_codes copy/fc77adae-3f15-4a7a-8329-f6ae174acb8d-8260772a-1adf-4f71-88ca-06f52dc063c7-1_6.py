from manim import *

class EnvironmentalSustainability(Scene):
    def construct(self):

        title = Text("Environmental Sustainability",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # Placeholder for an image illustrating environmental simulation or urban planning
        # This image could show a simulation of pollutant dispersion or an optimized city layout.
        environmental_image = Rectangle(color=WHITE)
        environmental_image.scale(2.5) # Adjust scale as needed
        environmental_image.move_to(ORIGIN) # Center the image

        self.play(FadeIn(environmental_image))
