from manim import *

class ImageDefinitionAndCharacteristics(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("图像的定义与信息传递特点",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局规划
        # 左侧放一张示意图(代表图像的直观性)
        # 右侧放文本描述(代表定义和特点)

        # 左侧内容:图像占位符
        # 注意:此处使用 placeholder.png,请确保目录下有此文件
        # 这张图片旨在展示"图像"这一概念本身,作为视觉信息的载体
        image_obj = Rectangle()
        image_obj.set_height(4)  # 设置高度
        image_obj.to_edge(LEFT, buff=1.5) # 放置在左侧
        image_obj.shift(DOWN * 0.5) # 稍微下移以避开标题

        # 给图片加个边框,使其看起来更像一张"照片"
        image_border = SurroundingRectangle(image_obj, color=BLUE, buff=0.05)

        image_label = Text("直观视觉表达", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        image_label.next_to(image_border, DOWN, buff=0.2)

        left_group = VGroup(image_obj, image_border, image_label)

        # 右侧内容:特点列表
        # 使用 Text 而不是 BulletedList 避免 LaTeX 中文排版问题
        char_title = Text("信息传递特点:", font="AR PL UKai CN", font_size=28, color=YELLOW)

        # 特点列表项
        p1 = Text("1. 信息量大:百闻不如一见", font="AR PL UKai CN", font_size=24)
        p2 = Text("2. 直观易懂:具体形象", font="AR PL UKai CN", font_size=24)
        p3 = Text("3. 通用性强:跨越语言障碍", font="AR PL UKai CN", font_size=24)

        # 组合列表
        text_group = VGroup(char_title, p1, p2, p3)
        text_group.arrange(DOWN, aligned_edge=LEFT, buff=0.5)
        text_group.next_to(image_border, RIGHT, buff=1.5)
        text_group.shift(UP * 0.5) # 稍微上移保持平衡

        # 3. 动画展示

        # 展示左侧图像概念
        self.play(FadeIn(image_obj), Create(image_border))
        self.play(Write(image_label))

        # 展示右侧文本特点
        self.play(FadeIn(char_title, shift=LEFT))

        # 逐条展示特点
        for item in [p1, p2, p3]:
            self.play(Write(item), run_time=0.8)

        # 强调重点(给右侧文本加个框)
        highlight_rect = SurroundingRectangle(text_group, color=YELLOW, buff=0.2)
        self.play(Create(highlight_rect))
