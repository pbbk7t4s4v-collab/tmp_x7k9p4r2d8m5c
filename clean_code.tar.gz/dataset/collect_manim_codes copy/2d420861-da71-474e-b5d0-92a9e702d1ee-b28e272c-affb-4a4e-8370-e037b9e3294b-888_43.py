from manim import *

class NobleGasLJ(Scene):
    def construct(self):

        # ---------------------------------------------------------------------
        # 1. 标题设置 (严格遵守模板)
        # ---------------------------------------------------------------------
        title = Text("稀有气体体系的LJ参数",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("42", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------------------
        # 2. 文本特性描述 (左侧)
        # ---------------------------------------------------------------------
        # 使用 VGroup 手动构建列表，避免 BulletedList 的潜在字体/LaTeX 问题
        p1 = Text("• 闭壳层电子结构，球形对称", font="AR PL UKai CN", font_size=24, color=WHITE)
        p2 = Text("• 无永久偶极矩，色散力主导", font="AR PL UKai CN", font_size=24, color=WHITE)
        p3 = Text("• LJ势能模型最理想的应用对象", font="AR PL UKai CN", font_size=24, color=YELLOW)

        text_group = VGroup(p1, p2, p3).arrange(DOWN, aligned_edge=LEFT, buff=0.25)
        text_group.to_edge(LEFT, buff=1.0).shift(UP*0.5)

        self.play(FadeIn(text_group, shift=RIGHT), run_time=1.2)

        # ---------------------------------------------------------------------
        # 3. 视觉化展示：原子半径变化趋势 (右侧/下方)
        # ---------------------------------------------------------------------
        # 定义稀有气体数据 (名称, 相对半径大小)
        atoms_data = [("He", 0.3), ("Ne", 0.45), ("Ar", 0.6), ("Kr", 0.75)]
        atom_group = VGroup()

        for name, r in atoms_data:
            # 原子球体
            circle = Circle(radius=r, color=BLUE_C, fill_opacity=0.5, fill_color=BLUE_E)
            # 原子核
            nucleus = Dot(color=WHITE, radius=0.05)
            # 标签
            label = Text(name, font="AR PL UKai CN", font_size=20).next_to(circle, UP, buff=0.1)

            atom_unit = VGroup(circle, nucleus, label)
            atom_group.add(atom_unit)

        # 排列原子，底部对齐
        atom_group.arrange(RIGHT, buff=0.5, aligned_edge=DOWN)
        atom_group.next_to(text_group, DOWN, buff=1.0).shift(RIGHT * 1.5)

        # ---------------------------------------------------------------------
        # 4. 趋势说明逻辑 (底部)
        # ---------------------------------------------------------------------
        # 箭头指示
        arrow = Arrow(start=atom_group.get_left() + DOWN*0.5,
                      end=atom_group.get_right() + DOWN*0.5,
                      color=ORANGE, buff=0.1)

        trend_text = Text("原子序数增加 (Z↑)", font="AR PL UKai CN", font_size=20, color=ORANGE)
        trend_text.next_to(arrow, DOWN, buff=0.1)

        # 结论公式
        conclusion = MathTex(
            r"\text{r} \uparrow \Rightarrow \sigma \uparrow, \epsilon \uparrow",
            tex_template=TexTemplateLibrary.simple,
            color=WHITE
        )
        # 修正MathTex中的中文部分字体
        conclusion[0][0:2].set_color(BLUE) # 半径二字

        # 将结论放在原子组上方右侧空白处，或者箭头下方
        # 这里的布局策略：原子在屏幕中下方，结论在原子右侧或下方
        conclusion.next_to(atom_group, UP, buff=0.5)

        # ---------------------------------------------------------------------
        # 5. 动画播放序列
        # ---------------------------------------------------------------------
        # 展示原子从小到大
        self.play(
            AnimationGroup(
                *[GrowFromCenter(atom) for atom in atom_group],
                lag_ratio=0.2
            ),
            run_time=2.0
        )

        # 展示趋势箭头
        self.play(GrowArrow(arrow), Write(trend_text))

        # 强调框和结论
        box = SurroundingRectangle(atom_group, color=BLUE, buff=0.2)

        self.play(
            Create(box),
            Write(conclusion)
        )

        # 最后的强调：极化率概念
        polar_text = Text("极化率增加", font="AR PL UKai CN", font_size=24, color=YELLOW)
        polar_text.next_to(box, RIGHT, buff=0.3)

        self.play(FadeIn(polar_text, shift=LEFT))
