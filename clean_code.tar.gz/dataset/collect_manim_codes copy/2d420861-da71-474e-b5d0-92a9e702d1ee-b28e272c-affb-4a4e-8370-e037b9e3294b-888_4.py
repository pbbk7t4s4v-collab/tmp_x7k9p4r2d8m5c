from manim import *

class BOMultipoleScene(Scene):
    def construct(self):

        # ---------------------------------------------------------------------
        # 1. 标题部分 (按照模板要求)
        # ---------------------------------------------------------------------
        title = Text("BO近似与多极展开基础",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题动画
        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------------------
        # 2. Born-Oppenheimer (BO) 近似讲解
        # ---------------------------------------------------------------------
        # 核心公式
        bo_formula = MathTex(r"M_{n} \gg m_{e}", color=YELLOW).scale(1.2)
        bo_formula.move_to(UP * 1.5)

        # 解释文本
        bo_desc_1 = Text("核运动极慢，电子瞬时调整", font="AR PL UKai CN", font_size=24, color=WHITE)
        bo_desc_1.next_to(bo_formula, DOWN, buff=0.2)

        bo_desc_2 = Text("运动分离 → 定义势能 V(r)", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        bo_desc_2.next_to(bo_desc_1, DOWN, buff=0.2)

        # 视觉化 BO 近似 (简单的原子示意图)
        nucleus = Dot(radius=0.2, color=RED).move_to(LEFT * 4 + UP * 1.5)
        electron_orbit = Circle(radius=0.8, color=BLUE, stroke_opacity=0.5).move_to(nucleus)
        electron = Dot(radius=0.08, color=BLUE).move_to(electron_orbit.point_at_angle(0))

        bo_group = VGroup(bo_formula, bo_desc_1, bo_desc_2)

        # 动画展示 BO 部分
        self.play(
            FadeIn(nucleus),
            Create(electron_orbit),
            FadeIn(electron),
            Write(bo_group),
            run_time=2
        )

        # 简单的电子运动动画暗示 (仅作为视觉辅助，不需太长)
        self.play(MoveAlongPath(electron, electron_orbit), run_time=1.0)

        # 分割线
        sep_line = Line(LEFT*6, RIGHT*6, color=GRAY, stroke_opacity=0.5).next_to(bo_desc_2, DOWN, buff=0.4)
        self.play(Create(sep_line), run_time=0.5)

        # ---------------------------------------------------------------------
        # 3. 多极展开与粒子类型
        # ---------------------------------------------------------------------
        # 副标题
        sub_title = Text("多极展开：粒子类型与距离标度", font="AR PL UKai CN", font_size=28, color=ORANGE)
        sub_title.next_to(sep_line, DOWN, buff=0.3)
        self.play(FadeIn(sub_title))

        # 准备三个类型的展示对象

        # (1) 单极子 Monopole
        mono_sphere = Circle(radius=0.4, color=RED, fill_opacity=0.3)
        mono_sign = MathTex("+").move_to(mono_sphere)
        mono_label = Text("单极子 (离子)", font="AR PL UKai CN", font_size=20).next_to(mono_sphere, DOWN, buff=0.2)
        mono_math = MathTex("q").next_to(mono_label, DOWN, buff=0.1).scale(0.8)
        mono_group = VGroup(mono_sphere, mono_sign, mono_label, mono_math)

        # (2) 偶极子 Dipole
        di_pos = Circle(radius=0.25, color=RED, fill_opacity=0.5).shift(LEFT*0.25)
        di_neg = Circle(radius=0.25, color=BLUE, fill_opacity=0.5).shift(RIGHT*0.25)
        di_p_sign = MathTex("+", font_size=24).move_to(di_pos)
        di_n_sign = MathTex("-", font_size=24).move_to(di_neg)
        di_shape = VGroup(di_pos, di_neg, di_p_sign, di_n_sign)
        di_label = Text("偶极子 (极性)", font="AR PL UKai CN", font_size=20).next_to(di_shape, DOWN, buff=0.2)
        di_math = MathTex(r"\mu").next_to(di_label, DOWN, buff=0.1).scale(0.8)
        di_group = VGroup(di_shape, di_label, di_math)

        # (3) 四极子 Quadrupole (线性示意，如 CO2: O- C+ O-)
        # 注意：这里用简单的 + - + 排列示意对称性
        quad_c = Circle(radius=0.25, color=RED, fill_opacity=0.5) # 中间正
        quad_l = Circle(radius=0.2, color=BLUE, fill_opacity=0.5).next_to(quad_c, LEFT, buff=0)
        quad_r = Circle(radius=0.2, color=BLUE, fill_opacity=0.5).next_to(quad_c, RIGHT, buff=0)
        quad_shape = VGroup(quad_c, quad_l, quad_r)
        quad_label = Text("四极子 (对称)", font="AR PL UKai CN", font_size=20).next_to(quad_c, DOWN, buff=0.35)
        quad_math = MathTex("Q").next_to(quad_label, DOWN, buff=0.1).scale(0.8)
        quad_group = VGroup(quad_shape, quad_label, quad_math)

        # 排版
        types_group = VGroup(mono_group, di_group, quad_group).arrange(RIGHT, buff=1.5)
        types_group.next_to(sub_title, DOWN, buff=0.4)

        # 动画展示分类
        self.play(
            FadeIn(mono_group, shift=UP),
            run_time=0.8
        )
        self.play(
            FadeIn(di_group, shift=UP),
            run_time=0.8
        )
        self.play(
            FadeIn(quad_group, shift=UP),
            run_time=0.8
        )

        # 强调框
        rect = SurroundingRectangle(types_group, color=YELLOW, buff=0.2, stroke_width=2)
        final_note = Text("阶数越高，方向性越强，衰减越快", font="AR PL UKai CN", font_size=18, color=YELLOW)
        final_note.next_to(rect, DOWN, buff=0.1)

        self.play(Create(rect), Write(final_note), run_time=1.5)
