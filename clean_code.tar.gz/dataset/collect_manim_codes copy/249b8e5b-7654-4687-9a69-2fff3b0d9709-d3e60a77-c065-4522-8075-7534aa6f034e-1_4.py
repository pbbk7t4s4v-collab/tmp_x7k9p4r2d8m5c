from manim import *

class WhileLoopCommonIssues(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("While 循环常见的问题",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局设计
        # ---------------------------------------------------------

        # 定义通用的样式配置
        text_font = "AR PL UKai CN"
        code_font = "Monospace" # 使用等宽字体模拟代码
        card_width = 4.0

        # --- 模块一:忘记更新变量(死循环) ---

        # 标题
        l1_title = Text("1. 忘记更新变量", font=text_font, font_size=24, color=RED_A)

        # 代码片段 (手动构建以保证对齐)
        l1_code_lines = VGroup(
            Text("i = 0", font=code_font, font_size=20, color=YELLOW),
            Text("while i < 5:", font=code_font, font_size=20, color=YELLOW),
            Text("    print(i)", font=code_font, font_size=20, color=YELLOW),
            # 这里的空隙暗示缺少代码
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # 警告文字
        l1_alert = Text("缺少 i += 1 → 死循环", font=text_font, font_size=20, color=RED)

        # 组合模块一
        group1 = VGroup(l1_title, l1_code_lines, l1_alert).arrange(DOWN, buff=0.4)
        l1_code_lines[2].shift(RIGHT * 0.6)  # 第三行右移
        box1 = SurroundingRectangle(group1, color=GRAY, buff=0.2)
        full_group1 = VGroup(box1, group1)

        # --- 模块二:循环条件错误 ---

        l2_title = Text("2. 循环条件错误", font=text_font, font_size=24, color=BLUE_A)

        l2_code_lines = VGroup(
            Text("x = 1", font=code_font, font_size=20, color=YELLOW),
            Text("while x != 10:", font=code_font, font_size=20, color=YELLOW),
            Text("    x += 2", font=code_font, font_size=20, color=YELLOW)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        l2_alert = Text("1,3,5...永远≠10", font=text_font, font_size=20, color=BLUE)

        group2 = VGroup(l2_title, l2_code_lines, l2_alert).arrange(DOWN, buff=0.4)
        l2_code_lines[2].shift(RIGHT * 0.6)  # 第三行右移
        box2 = SurroundingRectangle(group2, color=GRAY, buff=0.2)
        full_group2 = VGroup(box2, group2)

        # --- 模块三:输入转换异常 ---

        l3_title = Text("3. 输入转换异常", font=text_font, font_size=24, color=PURPLE_A)

        l3_code_lines = VGroup(
            Text("# 输入 'abc'", font=code_font, font_size=20, color=GREEN),
            Text("age_str = input()", font=code_font, font_size=20, color=YELLOW),
            Text("age = int(age_str)", font=code_font, font_size=20, color=YELLOW)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        l3_alert = Text("非数字转换 → 崩溃", font=text_font, font_size=20, color=PURPLE)

        group3 = VGroup(l3_title, l3_code_lines, l3_alert).arrange(DOWN, buff=0.4)
        box3 = SurroundingRectangle(group3, color=GRAY, buff=0.2)
        full_group3 = VGroup(box3, group3)

        # ---------------------------------------------------------
        # 3. 整体定位
        # ---------------------------------------------------------

        # 将三个卡片横向排列
        cards = VGroup(full_group1, full_group2, full_group3).arrange(RIGHT, buff=0.5)
        cards.move_to(DOWN * 0.5) # 整体下移,避开标题

        # ---------------------------------------------------------
        # 4. 动画展示
        # ---------------------------------------------------------

        # 逐步展示每一个问题模块

        # 1. 死循环
        self.play(Create(box1), FadeIn(group1, shift=UP))

        # 强调缺少代码的位置
        missing_code_indicator = Arrow(start=RIGHT, end=LEFT, color=RED).next_to(l1_code_lines, RIGHT)
        self.play(FadeIn(missing_code_indicator), Indicate(l1_alert, color=RED))
        self.play(FadeOut(missing_code_indicator))

        # 2. 逻辑错误
        self.play(Create(box2), FadeIn(group2, shift=UP))

        # 3. 输入异常
        self.play(Create(box3), FadeIn(group3, shift=UP))

        # 强调最后的崩溃
        flash_rect = SurroundingRectangle(l3_code_lines[-1], color=RED)
        self.play(Create(flash_rect))
        self.play(Uncreate(flash_rect))
