from manim import *

class MLDefinitionAndHistory(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("机器学习的定义与发展简史",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 定义部分:流程图 (上半部分)
        # 核心概念:数据 + 算法 -> 模型 -> 预测
        # ---------------------------------------------------------

        # 定义文本节点
        t_data = Text("数据\n(Data)", font="AR PL UKai CN", font_size=20, color=BLUE)
        t_algo = Text("算法\n(Algorithm)", font="AR PL UKai CN", font_size=20, color=GREEN)
        t_model = Text("模型\n(Model)", font="AR PL UKai CN", font_size=20, color=YELLOW)
        t_result = Text("预测/决策\n(Prediction)", font="AR PL UKai CN", font_size=20, color=RED)

        # 排列位置
        flow_group = VGroup(t_data, t_algo, t_model, t_result)
        flow_group.arrange(RIGHT, buff=1.5)
        flow_group.move_to(UP * 1.0) # 放置在屏幕上半区

        # 绘制边框
        box_data = SurroundingRectangle(t_data, color=BLUE, buff=0.15)
        box_algo = SurroundingRectangle(t_algo, color=GREEN, buff=0.15)
        box_model = SurroundingRectangle(t_model, color=YELLOW, buff=0.15)
        box_result = SurroundingRectangle(t_result, color=RED, buff=0.15)

        # 绘制箭头
        arrow1 = Arrow(box_data.get_right(), box_algo.get_left(), buff=0.1, color=GRAY)
        arrow2 = Arrow(box_algo.get_right(), box_model.get_left(), buff=0.1, color=GRAY)
        arrow3 = Arrow(box_model.get_right(), box_result.get_left(), buff=0.1, color=GRAY)

        # 组合定义部分的动画
        def_label = Text("定义:从数据中学习规律", font="AR PL UKai CN", font_size=24, color=WHITE)
        def_label.next_to(flow_group, UP, buff=0.5)

        self.play(FadeIn(def_label, shift=DOWN))
        self.play(
            AnimationGroup(
                Create(box_data), Write(t_data),
                Create(arrow1),
                Create(box_algo), Write(t_algo),
                Create(arrow2),
                Create(box_model), Write(t_model),
                Create(arrow3),
                Create(box_result), Write(t_result),
                lag_ratio=0.2
            ),
            run_time=4
        )

        # ---------------------------------------------------------
        # 3. 历史部分:时间轴 (下半部分)
        # ---------------------------------------------------------

        # 历史标签
        hist_label = Text("发展历程:", font="AR PL UKai CN", font_size=24, color=WHITE)
        hist_label.move_to(LEFT * 5 + DOWN * 1.5)

        # 时间轴线
        timeline = Arrow(start=LEFT * 3, end=RIGHT * 5, color=WHITE, buff=0)
        timeline.align_to(hist_label, UP).shift(DOWN * 0.5) # 稍微下移

        # 时间节点数据
        # 格式: (位置比例, 年代, 关键词, 颜色)
        milestones_data = [
            (LEFT * 2, "1950s", "符号主义\n(逻辑推理)", TEAL),
            (RIGHT * 1, "1980s", "统计学习\n(概率模型)", GOLD),
            (RIGHT * 4, "2010s", "深度学习\n(神经网络)", PURPLE),
        ]

        milestones_group = VGroup()

        for pos, year, desc, col in milestones_data:
            dot = Dot(point=timeline.get_center(), color=col).move_to([pos[0], timeline.get_y(), 0])
            t_year = Text(year, font="AR PL UKai CN", font_size=18, color=col).next_to(dot, UP, buff=0.1)
            t_desc = Text(desc, font="AR PL UKai CN", font_size=16, color=WHITE).next_to(dot, DOWN, buff=0.2)
            milestones_group.add(dot, t_year, t_desc)

        # 历史部分动画
        self.play(
            Write(hist_label),
            Create(timeline),
            run_time=1.5
        )

        self.play(
            FadeIn(milestones_group, shift=UP),
            run_time=2
        )

        # ---------------------------------------------------------
        # 4. 结尾停顿
        # ---------------------------------------------------------
