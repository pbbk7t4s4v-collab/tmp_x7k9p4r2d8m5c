from manim import *

class AIResearchAssistant(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("文献与知识工作流：AI科研助手",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("27", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心元素定义
        # 左侧：文献输入
        # 使用 Polygon 绘制简单的文档图标
        doc_shape = Polygon(
            [-0.4, -0.5, 0], [0.4, -0.5, 0], [0.4, 0.3, 0], [0.2, 0.5, 0], [-0.4, 0.5, 0],
            color=BLUE_C, fill_opacity=0.5, stroke_width=2
        )
        doc_lines = VGroup(*[
            Line(start=[-0.2, 0.2 - i*0.2, 0], end=[0.2, 0.2 - i*0.2, 0], color=WHITE, stroke_width=2)
            for i in range(3)
        ])
        doc_icon = VGroup(doc_shape, doc_lines).scale(1.2)
        doc_label = Text("文献知识库", font="AR PL UKai CN", font_size=20, color=BLUE_B).next_to(doc_icon, DOWN)
        doc_group = VGroup(doc_icon, doc_label).to_edge(LEFT, buff=1.5).shift(UP*0.5)

        # 中间：大模型核心
        llm_circle = Circle(radius=0.8, color=TEAL, fill_opacity=0.3)
        llm_text = Text("大模型\n内核", font="AR PL UKai CN", font_size=24, line_spacing=1.2)
        llm_group = VGroup(llm_circle, llm_text).next_to(doc_group, RIGHT, buff=2)

        # 连接箭头 1
        arrow_1 = Arrow(doc_icon.get_right(), llm_circle.get_left(), color=GREY_B, buff=0.1)

        # 右侧：四大功能
        func_texts = ["文献分类", "智能检索", "论文推荐", "学术问答"]
        func_group = VGroup()
        for t in func_texts:
            item = Text(t, font="AR PL UKai CN", font_size=22, color=YELLOW_A)
            func_group.add(item)

        func_group.arrange(DOWN, buff=0.5).next_to(llm_group, RIGHT, buff=2)

        # 连接箭头 2 (从圆心发散)
        arrows_out = VGroup()
        for item in func_group:
            arr = Arrow(llm_circle.get_right(), item.get_left(), color=GREY_B, buff=0.1, max_tip_length_to_length_ratio=0.15)
            arrows_out.add(arr)

        # 底部：ChatGPT Store
        store_text = Text("ChatGPT Store：涌现大批学术"科研助手"应用",
                         font="AR PL UKai CN", font_size=24, color=WHITE)
        store_rect = SurroundingRectangle(store_text, color=PURPLE, buff=0.2, corner_radius=0.1)
        store_group = VGroup(store_rect, store_text).to_edge(DOWN, buff=1)

        # 3. 动画流程
        # 展示输入和核心
        self.play(
            FadeIn(doc_group, shift=RIGHT),
            FadeIn(llm_group, shift=UP),
            Create(arrow_1),
            run_time=1.5
        )

        # 展示功能发散
        self.play(
            LaggedStart(
                *[Create(arr) for arr in arrows_out],
                lag_ratio=0.1
            ),
            LaggedStart(
                *[Write(item) for item in func_group],
                lag_ratio=0.1
            ),
            run_time=2
        )

        # 强调功能块
        rect_funcs = SurroundingRectangle(func_group, color=YELLOW, buff=0.2)
        self.play(Create(rect_funcs), run_time=1)

        # 展示底部生态
        self.play(FadeIn(store_group, shift=UP), run_time=1.5)

        # 稍微停留
