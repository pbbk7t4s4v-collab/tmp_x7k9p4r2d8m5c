from manim import *

class CalculusSignificance(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("微积分的核心价值",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念转换:不仅仅是计算 -> 世界观
        # ---------------------------------------------------------
        # 定义字体配置
        font_conf = {"font": "AR PL UKai CN"}

        # 左侧:计算技术
        tech_text = Text("计算技术", font_size=28, color=GRAY, **font_conf)
        # 否定红叉
        cross = Cross(tech_text, stroke_width=4, scale_factor=1.2)

        # 中间:箭头
        arrow = Arrow(LEFT, RIGHT, color=WHITE, buff=0.2)

        # 右侧:世界观
        view_text = Text("看待世界的方式", font_size=36, color=YELLOW, weight=BOLD, **font_conf)

        # 布局:水平排列
        concept_group = VGroup(tech_text, arrow, view_text).arrange(RIGHT, buff=0.5)
        concept_group.move_to(UP * 1.5) # 放置在标题下方

        # 修正红叉位置
        cross.move_to(tech_text.get_center())

        # 动画播放
        self.play(FadeIn(tech_text))
        self.play(Create(cross), run_time=0.5)
        self.play(
            GrowArrow(arrow),
            Write(view_text),
            run_time=1.0
        )

        # ---------------------------------------------------------
        # 3. 三大支柱可视化:分析变化、优化决策、预测未来
        # ---------------------------------------------------------

        # 辅助函数:创建带边框的模块
        def create_module(title_str, math_tex, box_color):
            t = Text(title_str, font_size=24, color=WHITE, **font_conf)
            m = MathTex(math_tex, color=box_color).scale(0.9)
            m.next_to(t, DOWN, buff=0.3)

            # 组合内容
            content = VGroup(t, m)

            # 添加外框
            box = SurroundingRectangle(content, color=box_color, corner_radius=0.2, buff=0.2)

            return VGroup(box, content)

        # 模块1:分析变化 (导数/变化率)
        module_change = create_module("分析变化", r"\frac{dy}{dx} \approx \frac{\Delta y}{\Delta x}", TEAL)

        # 模块2:优化决策 (极值点)
        module_opt = create_module("优化决策", r"\nabla f(x) = 0", GOLD)

        # 模块3:预测未来 (积分/累积)
        module_predict = create_module("预测未来", r"\int_{t_0}^{T} v(t)dt", MAROON)

        # 整体布局:排列在下方
        modules = VGroup(module_change, module_opt, module_predict).arrange(RIGHT, buff=0.6)
        modules.next_to(concept_group, DOWN, buff=1.2)

        # 动画:依次出现
        self.play(
            LaggedStart(
                FadeIn(module_change, shift=UP),
                FadeIn(module_opt, shift=UP),
                FadeIn(module_predict, shift=UP),
                lag_ratio=0.4
            ),
            run_time=2.5
        )

        # ---------------------------------------------------------
        # 4. 底部总结:永恒价值
        # ---------------------------------------------------------
        summary_line = Line(LEFT, RIGHT, color=GREY, stroke_width=1).match_width(modules)
        summary_line.next_to(modules, DOWN, buff=0.5)

        summary_text = Text("微积分的永恒价值", font_size=22, color=LIGHT_GREY, slant=ITALIC, **font_conf)
        summary_text.next_to(summary_line, DOWN, buff=0.2)

        self.play(
            Create(summary_line),
            FadeIn(summary_text),
            run_time=1.5
        )
