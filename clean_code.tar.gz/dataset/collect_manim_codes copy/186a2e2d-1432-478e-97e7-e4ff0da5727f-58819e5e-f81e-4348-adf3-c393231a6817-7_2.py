from manim import *
import numpy as np

class GradientDescentQA(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (符合模板要求)
        # ---------------------------------------------------------
        title = Text("梯度下降常见问题解析",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("22", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局 - 左右分栏
        # ---------------------------------------------------------

        # 左侧区域:Adam vs SGD (非凸问题)
        # 问题文本
        q1_text = Text("Q1: 为何 Adam 在非凸问题更优?", font="AR PL UKai CN", font_size=24, color=YELLOW)

        # 示意图:非凸函数(波浪线)
        ax1 = Axes(
            x_range=[-2, 2, 1],
            y_range=[-1, 2, 1],
            x_length=4,
            y_length=2.5,
            axis_config={"include_tip": True, "tip_shape": StealthTip}
        )
        # 一个带有局部极小值的函数
        curve1 = ax1.plot(lambda x: 0.5 * x**4 - x**2 + 0.3 * x + 0.5, color=BLUE)
        curve1_label = Text("非凸函数地形", font="AR PL UKai CN", font_size=18, color=BLUE).next_to(curve1, UP, buff=0.1)

        # 解释文本
        ans1_items = [
            Text("• SGD: 易陷入局部最优或鞍点", font="AR PL UKai CN", font_size=20),
            Text("• Adam: 自适应步长 + 动量", font="AR PL UKai CN", font_size=20),
            Text("• 能快速穿越平坦区域", font="AR PL UKai CN", font_size=20),
        ]
        for item in ans1_items:
            item.set_color(WHITE)
        ans1_list = VGroup(*ans1_items)
        ans1_list.arrange(DOWN, buff=0.15, aligned_edge=LEFT)
        ans1_list.set_color(WHITE)

        # 组合左侧元素
        left_group = VGroup(q1_text, VGroup(ax1, curve1, curve1_label), ans1_list)
        left_group.arrange(DOWN, buff=0.3, aligned_edge=LEFT)
        left_group.to_edge(LEFT, buff=1.0).shift(DOWN*0.5)

        # 右侧区域:全局最优 (凸优化)
        # 问题文本
        q2_text = Text("Q2: 何时能找到全局最优?", font="AR PL UKai CN", font_size=24, color=YELLOW)

        # 示意图:凸函数(U型)
        ax2 = Axes(
            x_range=[-2, 2, 1],
            y_range=[0, 4, 1],
            x_length=4,
            y_length=2.5,
            axis_config={"include_tip": True, "tip_shape": StealthTip}
        )
        curve2 = ax2.plot(lambda x: x**2, color=GREEN)
        curve2_label = Text("凸函数 (Convex)", font="AR PL UKai CN", font_size=18, color=GREEN).move_to(ax2.c2p(0, 2.5))

        # 解释文本
        ans2_items = [
            Text("• 条件: 损失函数必须是凸函数", font="AR PL UKai CN", font_size=20),
            Text("• 性质: 局部最优 = 全局最优", font="AR PL UKai CN", font_size=20),
            Text("• 此时梯度下降保证收敛", font="AR PL UKai CN", font_size=20),
        ]
        for item in ans2_items:
            item.set_color(WHITE)
        ans2_list = VGroup(*ans2_items)
        ans2_list.arrange(DOWN, buff=0.15, aligned_edge=LEFT)
        ans2_list.set_color(WHITE)

        # 组合右侧元素
        right_group = VGroup(q2_text, VGroup(ax2, curve2, curve2_label), ans2_list)
        right_group.arrange(DOWN, buff=0.3, aligned_edge=LEFT)
        right_group.to_edge(RIGHT, buff=1.0).shift(DOWN*0.5)

        # 对齐左右两组的顶部
        right_group.align_to(left_group, UP)

        # ---------------------------------------------------------
        # 3. 动画演示
        # ---------------------------------------------------------

        # 分隔线
        divider = Line(UP*2, DOWN*3, color=GRAY, stroke_opacity=0.5)

        self.play(
            FadeIn(left_group, shift=RIGHT),
            Create(divider),
            run_time=1.5
        )

        self.play(
            FadeIn(right_group, shift=LEFT),
            run_time=1.5
        )

        # 强调框
        rect_adam = SurroundingRectangle(ans1_list[1], color=BLUE, buff=0.05)
        rect_convex = SurroundingRectangle(ans2_list[0], color=GREEN, buff=0.05)

        self.play(
            Create(rect_adam),
            Create(rect_convex),
            run_time=1.0
        )
