from manim import *

class ConvexFunctionDefinition(Scene):
    def construct(self):

        # 1. Title Setup (per template)
        title = Text("Definition of Convex Functions",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Layout - Left (Theory) and Right (Visualization)

        # --- Left Column: Definitions and Formula ---
        # Definition Text
        def_text = VGroup(
            Text("A function f is convex if domain is convex", font_size=24, color=WHITE),
            Text("and for all x, y in domain and \u03b8 in [0,1]:", font_size=24, color=WHITE)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # The Inequality Formula
        formula = MathTex(
            r"f(\theta x + (1-\theta)y) \leq \theta f(x) + (1-\theta)f(y)",
            font_size=30,
            color=YELLOW
        )

        # Geometric Interpretation
        geo_title = Text("Geometric Interpretation:", font_size=24, weight=BOLD, color=BLUE)
        geo_desc = Text("The chord connecting any two points\nlies above the function graph.",
                        font_size=22, color=GRAY_B, line_spacing=1.2)

        # Strict and Concave definitions
        extra_info = VGroup(
            Text("• Strict Convex: Inequality is strict (<) if x != y", font_size=22),
            Text("• Concave Function: if -f is convex", font_size=22)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # Combine Left Elements
        left_group = VGroup(
            def_text,
            formula,
            geo_title,
            geo_desc,
            extra_info
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        left_group.to_edge(LEFT, buff=0.5).shift(UP*0.2)

        # --- Right Column: Visualization ---
        # Axes
        axes = Axes(
            x_range=[-2, 4, 1],
            y_range=[-1, 5, 1],
            x_length=5,
            y_length=4,
            axis_config={"color": WHITE, "include_numbers": False}
        )

        # Convex Function (Parabola-like)
        func_curve = axes.plot(lambda x: 0.3 * (x - 1)**2 + 0.5, color=BLUE, x_range=[-1, 3])
        func_label = MathTex("f(x)", color=BLUE, font_size=24).next_to(func_curve, UP)

        # Points x and y
        x_val = -0.5
        y_val = 2.5

        pt_x = Dot(axes.c2p(x_val, 0.3 * (x_val - 1)**2 + 0.5), color=RED)
        pt_y = Dot(axes.c2p(y_val, 0.3 * (y_val - 1)**2 + 0.5), color=RED)

        lbl_x = MathTex("x", font_size=24).next_to(pt_x, DOWN)
        lbl_y = MathTex("y", font_size=24).next_to(pt_y, DOWN)

        # The Chord (Line segment)
        chord = Line(pt_x.get_center(), pt_y.get_center(), color=YELLOW)
        chord_label = Text("Chord", font_size=20, color=YELLOW).next_to(chord, UP, buff=0.05)

        # Group Right Elements
        graph_group = VGroup(axes, func_curve, func_label, pt_x, pt_y, lbl_x, lbl_y, chord, chord_label)
        graph_group.next_to(left_group, RIGHT, buff=0.8)

        # Box around formula for emphasis
        box = SurroundingRectangle(formula, color=YELLOW, buff=0.1, stroke_width=2)

        # 3. Animation Sequence

        # Phase 1: Show Definition and Graph Axes
        self.play(
            FadeIn(def_text, shift=RIGHT),
            Create(axes),
            Create(func_curve),
            run_time=2
        )
        self.add(func_label)

        # Phase 2: Show Formula and Points
        self.play(
            Write(formula),
            FadeIn(pt_x, scale=0.5), FadeIn(lbl_x),
            FadeIn(pt_y, scale=0.5), FadeIn(lbl_y),
            run_time=2
        )
        self.play(Create(box), run_time=1)

        # Phase 3: Geometric Interpretation (Draw Chord)
        self.play(
            FadeIn(geo_title, shift=UP),
            FadeIn(geo_desc, shift=UP),
            Create(chord),
            Write(chord_label),
            run_time=2
        )

        # Phase 4: Additional Definitions
        self.play(
            Write(extra_info),
            run_time=2
        )
