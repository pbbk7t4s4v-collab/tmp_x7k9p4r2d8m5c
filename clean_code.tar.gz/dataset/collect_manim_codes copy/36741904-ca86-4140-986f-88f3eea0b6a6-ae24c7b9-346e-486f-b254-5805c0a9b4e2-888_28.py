from manim import *

class LabEquipmentSafety(Scene):
    def construct(self):

        # 1. Title Configuration
        title = Text("Electrophoresis & Amplification Safety",
                    font_size=34,  # Larger font size
                    color=WHITE,   # White text for contrast
                    weight=BOLD)   # Bold weight
        title.to_edge(UP, buff=0.5)  # Position at top

        # Bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Group title elements
        title_group = VGroup(title, title_line)

        # Title Animation
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("28", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Content Layout Setup
        # Left Side: Electrophoresis
        # Right Side: Amplification & Cultivation

        # --- Left Side: Electrophoresis Apparatus ---

        # Image 1: Electrophoresis
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_28/1.png") # A scientific illustration of a horizontal gel electrophoresis apparatus system, showing the gel tank, buffer solution, and electrical leads connected to a power supply unit, clean vector style with a white background.
        img1.height = 2.8  # Adjust size to fit screen
        img1.to_edge(LEFT, buff=1.0).shift(UP * 0.2)

        # Safety Rules for Electrophoresis
        # Using BulletedList for clear steps
        electro_points = BulletedList(
            "Must be grounded to prevent shock",
            "No plug/unplug while powered",
            "Stop if arcing or smoke occurs",
            font_size=22,
            buff=0.15,
            height=2.0,
            width=5.5
        )
        electro_points.next_to(img1, DOWN, buff=0.3)
        electro_points.set_color(BLUE_A)

        # Highlight box for Electrophoresis safety
        rect1 = SurroundingRectangle(electro_points, color=BLUE, buff=0.1)

        # --- Right Side: Amplification & Cultivation ---

        # Image 2: Incubator/PCR
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_28/2.png") # A realistic photo of a laboratory incubator or a PCR machine sitting on a clean lab bench, representing amplification and cultivation equipment, professional medical laboratory style.
        img2.height = 2.8
        img2.to_edge(RIGHT, buff=1.0).match_y(img1)

        # Critical Points for Amplification
        ampli_points = BulletedList(
            "Contamination control is critical",
            "Requires environmental stability",
            font_size=22,
            buff=0.15,
            height=1.5,
            width=5.5
        )
        ampli_points.next_to(img2, DOWN, buff=0.3)
        ampli_points.align_to(electro_points, UP) # Align top with left list
        ampli_points.set_color(GREEN_A)

        # Highlight box for Amplification info
        rect2 = SurroundingRectangle(ampli_points, color=GREEN, buff=0.1)

        # 3. Animation Sequence

        # Show Left Side (Electrophoresis)
        self.play(FadeIn(img1, shift=RIGHT))
        self.play(
            Write(electro_points, run_time=2),
            Create(rect1)
        )

        # Show Right Side (Amplification)
        self.play(FadeIn(img2, shift=LEFT))
        self.play(
            Write(ampli_points, run_time=2),
            Create(rect2)
        )

        # Final pause to read
