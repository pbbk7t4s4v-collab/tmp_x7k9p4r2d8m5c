from manim import *

class GaloisTheoryBirth(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("伽罗瓦理论:对称性与方程可解性",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 问题背景:多项式方程
        # 展示一个五次方程,代表不可解问题的边界
        equation = MathTex(r"P(x) = x^5 + ax^4 + bx^3 + cx^2 + dx + e = 0", color=BLUE_B)
        equation.scale(0.8)
        equation.shift(UP * 1.5)

        # 问题描述文本
        q_text = Text("是否存在根式通解?", font="AR PL UKai CN", font_size=24, color=GREY_A)
        q_text.next_to(equation, DOWN, buff=0.2)

        self.play(Write(equation), FadeIn(q_text))

        # 3. 核心洞见:根的置换与对称性
        # 概念文本
        concept_text = Text("核心洞见:根的置换群", font="AR PL UKai CN", font_size=28, color=YELLOW)
        concept_text.move_to(ORIGIN).shift(UP * 0.2)

        # 可视化根的置换 (简单的三个点代表根,用箭头表示置换关系)
        r1 = MathTex("x_1", color=RED).move_to(LEFT * 2 + DOWN * 0.8)
        r2 = MathTex("x_2", color=GREEN).move_to(DOWN * 0.8)
        r3 = MathTex("x_3", color=BLUE).move_to(RIGHT * 2 + DOWN * 0.8)

        roots_group = VGroup(r1, r2, r3)

        # 绘制置换箭头 (CurvedArrows)
        arrow_12 = CurvedArrow(r1.get_top(), r2.get_top(), angle=-PI/4, color=WHITE, tip_length=0.15)
        arrow_23 = CurvedArrow(r2.get_top(), r3.get_top(), angle=-PI/4, color=WHITE, tip_length=0.15)

        # 标记置换操作 sigma
        sigma_label = MathTex(r"\sigma").next_to(arrow_12, UP, buff=0.05).scale(0.8)

        self.play(FadeIn(concept_text))
        self.play(Write(roots_group))
        self.play(
            Create(arrow_12),
            Create(arrow_23),
            Write(sigma_label)
        )

        # 4. 理论奠基:群论与域论
        # 连接线指向下方
        center_line = Line(DOWN * 1.5, DOWN * 2.2, color=GREY)

        # 两个基础理论的文本框
        group_theory = Text("群论 (Group Theory)", font="AR PL UKai CN", font_size=24)
        field_theory = Text("域论 (Field Theory)", font="AR PL UKai CN", font_size=24)

        # 水平排列
        theories = VGroup(group_theory, field_theory).arrange(RIGHT, buff=1.5)
        theories.to_edge(DOWN, buff=0.8)

        # 为文本添加矩形框
        box_group = SurroundingRectangle(group_theory, color=TEAL, buff=0.15)
        box_field = SurroundingRectangle(field_theory, color=PURPLE, buff=0.15)

        # 分支箭头
        arrow_left = Arrow(center_line.get_end(), box_group.get_top(), color=GREY, buff=0.05)
        arrow_right = Arrow(center_line.get_end(), box_field.get_top(), color=GREY, buff=0.05)

        self.play(Create(center_line))
        self.play(
            GrowFromCenter(box_group), Write(group_theory),
            GrowFromCenter(box_field), Write(field_theory),
            Create(arrow_left), Create(arrow_right)
        )
