from manim import *

class MethodStrategies(Scene):
    def construct(self):

        # 1. 标题设置 (根据模板要求)
        title = Text("方法互补的实践策略",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("99", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局规划
        # 我们将三种策略分为三列展示,每列包含图示和简要说明

        # --- 策略一:三角验证 (Triangulation) ---
        # 概念可视化:中心目标点,四周箭头指向它,表示多角度检验
        t_color = BLUE
        target_dot = Dot(color=t_color, radius=0.15)
        arrow1 = Arrow(start=UP+LEFT, end=ORIGIN, color=t_color, buff=0.2).scale(0.6)
        arrow2 = Arrow(start=UP+RIGHT, end=ORIGIN, color=t_color, buff=0.2).scale(0.6)
        arrow3 = Arrow(start=DOWN, end=ORIGIN, color=t_color, buff=0.2).scale(0.6)

        t_icon = VGroup(target_dot, arrow1, arrow2, arrow3).move_to(ORIGIN)

        t_label = Text("三角验证", font="AR PL UKai CN", font_size=24, color=t_color)
        t_desc = Text("统计 + 案例\n交叉检验", font="AR PL UKai CN", font_size=20, line_spacing=0.8, color=WHITE)

        col1 = VGroup(t_icon, t_label, t_desc).arrange(DOWN, buff=0.4)

        # --- 策略二:序列设计 (Sequential Design) ---
        # 概念可视化:流程图,步骤A指向步骤B
        s_color = GREEN
        box_a = Rectangle(height=0.6, width=0.8, color=s_color, fill_opacity=0.3)
        text_a = Text("定性", font="AR PL UKai CN", font_size=16).move_to(box_a)
        box_b = Rectangle(height=0.6, width=0.8, color=s_color, fill_opacity=0.3)
        text_b = Text("定量", font="AR PL UKai CN", font_size=16).move_to(box_b)

        grp_a = VGroup(box_a, text_a)
        grp_b = VGroup(box_b, text_b)

        # 排列 A -> B
        seq_flow = VGroup(grp_a, grp_b).arrange(RIGHT, buff=0.8)
        seq_arrow = Arrow(grp_a.get_right(), grp_b.get_left(), color=s_color, buff=0.1, max_tip_length_to_length_ratio=0.3)

        s_icon = VGroup(seq_flow, seq_arrow)

        s_label = Text("序列设计", font="AR PL UKai CN", font_size=24, color=s_color)
        s_desc = Text("生成假设 -> 检验\n发现反常 -> 探究", font="AR PL UKai CN", font_size=20, line_spacing=0.8, color=WHITE)

        col2 = VGroup(s_icon, s_label, s_desc).arrange(DOWN, buff=0.4)

        # --- 策略三:嵌入式整合 (Embedded Integration) ---
        # 概念可视化:大框包含小框
        e_color = YELLOW
        main_frame = Square(side_length=1.8, color=e_color)
        embedded_elem = Square(side_length=0.8, color=e_color, fill_opacity=0.5).move_to(main_frame.get_corner(DR) + UL*0.6)
        main_text = Text("主导框架", font="AR PL UKai CN", font_size=14).move_to(main_frame.get_corner(UL) + DR*0.4)

        e_icon = VGroup(main_frame, embedded_elem, main_text).scale(0.8)

        e_label = Text("嵌入式整合", font="AR PL UKai CN", font_size=24, color=e_color)
        e_desc = Text("主框架嵌入\n其他方法元素", font="AR PL UKai CN", font_size=20, line_spacing=0.8, color=WHITE)

        col3 = VGroup(e_icon, e_label, e_desc).arrange(DOWN, buff=0.4)

        # 3. 整体布局与动画
        # 将三列水平排列
        content_group = VGroup(col1, col2, col3).arrange(RIGHT, buff=1.0)
        content_group.move_to(DOWN * 0.5) # 整体下移,避开标题

        # 4. 动画执行

        # 分组淡入
        self.play(FadeIn(col1, shift=UP), run_time=1)

        self.play(FadeIn(col2, shift=UP), run_time=1)

        self.play(FadeIn(col3, shift=UP), run_time=1)

        # 5. 强调动画 (使用 SurroundingRectangle)
        # 依次强调这三个概念
        rect1 = SurroundingRectangle(col1, color=t_color, buff=0.15)
        rect2 = SurroundingRectangle(col2, color=s_color, buff=0.15)
        rect3 = SurroundingRectangle(col3, color=e_color, buff=0.15)

        self.play(Create(rect1), run_time=0.5)
        self.play(Transform(rect1, rect2), run_time=0.8)
        self.play(Transform(rect1, rect3), run_time=0.8)
        self.play(FadeOut(rect1), run_time=0.5)
