from manim import *

class EmulsionPolymerizationStage2(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("乳液聚合第二阶段：恒速期机理",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心内容布局
        # 左侧：微观机理示意图 (占位符)
        # 注释：此处展示乳胶粒生长期恒速期的微观机理示意图,包含单体液滴、水相和正在长大的乳胶粒
        mech_image = ImageMobject("/home/TeachMasterAppV2/backend/uploads/attachments/guolaoshi/step2.png")
        mech_image.set_height(3.0) # 减小高度
        mech_image.to_edge(LEFT, buff=1.5) # 放置在左侧

        # 右侧：文字描述与关键特征
        # 定义字体样式
        text_font = "AR PL UKai CN"

        # 第一点：单体迁移过程
        p1_title = Text("单体迁移路径：", font=text_font, font_size=26, color=BLUE_B)

        # 使用箭头可视化迁移过程
        source_text = Text("大液滴", font=text_font, font_size=24)
        arrow = Arrow(start=LEFT, end=RIGHT, color=WHITE, buff=0.1).scale(0.5)
        dest_text = Text("乳胶粒", font=text_font, font_size=24)

        migration_flow = VGroup(source_text, arrow, dest_text).arrange(RIGHT, buff=0.2)
        migration_group = VGroup(p1_title, migration_flow).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        # 第二点：动力学特征 (恒速期核心)
        p2_title = Text("恒速期关键特征：", font=text_font, font_size=26, color=BLUE_B)

        # 特征列表
        feat1 = Text("1. 乳胶粒数量 (Np) 保持不变", font=text_font, font_size=24, color=YELLOW)
        feat2 = Text("2. 乳胶粒粒径 (Dp) 不断增大", font=text_font, font_size=24, color=YELLOW)

        features_list = VGroup(feat1, feat2).arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        features_group = VGroup(p2_title, features_list).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        # 组合右侧所有文字
        right_content = VGroup(migration_group, features_group).arrange(DOWN, buff=0.8, aligned_edge=LEFT)
        right_content.next_to(mech_image, RIGHT, buff=1.0)

        # 强调框
        rect = SurroundingRectangle(features_list, color=ORANGE, buff=0.15)

        # 3. 动画流程
        # 步骤1: 淡入图片
        self.play(FadeIn(mech_image, shift=RIGHT))

        # 步骤2: 展示单体迁移概念
        self.play(Write(p1_title))
        self.play(
            FadeIn(source_text, shift=UP),
            Create(arrow),
            FadeIn(dest_text, shift=UP)
        )

        # 步骤3: 展示恒速期特征
        self.play(FadeIn(p2_title, shift=LEFT))
        self.play(
            Write(feat1, run_time=1),
            Write(feat2, run_time=1)
        )

        # 步骤4: 强调核心结论
        self.play(Create(rect))
