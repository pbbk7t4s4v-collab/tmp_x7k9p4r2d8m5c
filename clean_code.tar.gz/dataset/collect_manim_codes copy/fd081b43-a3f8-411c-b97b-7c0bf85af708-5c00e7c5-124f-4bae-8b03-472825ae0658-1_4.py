from manim import *

class LinearConsumptionFunction(Scene):
    def construct(self):

        # 1. 标题设置 (严格遵守模板)
        title = Text("线性消费函数",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧内容：定义与公式
        # 描述文本
        desc_text = Text("居民消费由收入决定", font="AR PL UKai CN", font_size=28)

        # 公式
        formula = MathTex(r"C = C_0 + cY", font_size=48)

        # 约束条件
        condition = MathTex(r"0 < c < 1", font_size=32, color=YELLOW)

        # 组合左侧元素并排版
        left_content = VGroup(desc_text, formula, condition).arrange(DOWN, buff=0.6)
        left_content.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 给公式添加强调框
        rect = SurroundingRectangle(formula, color=BLUE, buff=0.2)

        # 3. 右侧内容：几何可视化
        # 创建坐标系
        ax = Axes(
            x_range=[0, 6, 1],
            y_range=[0, 6, 1],
            x_length=5.5,
            y_length=4.5,
            axis_config={"include_tip": True, "color": GREY},
        ).to_edge(RIGHT, buff=0.5).shift(DOWN * 0.5)

        # 坐标轴标签
        labels = ax.get_axis_labels(
            x_label=Text("Y(收入)", font="AR PL UKai CN", font_size=26),
            y_label=Text("C(消费)", font="AR PL UKai CN", font_size=26)
        )
        labels[0].scale(0.6).set_color(WHITE)
        labels[1].scale(0.6).set_color(WHITE)

        # 绘制线性函数 C = 1 + 0.6Y (假设 C0=1, c=0.6 用于绘图)
        c0_val = 1.0
        slope_val = 0.6
        graph_line = ax.plot(lambda y: c0_val + slope_val * y, color=BLUE, x_range=[0, 5.5])

        # 截距标注 (自发消费)
        intercept_dot = Dot(ax.c2p(0, c0_val), color=RED)
        intercept_label = MathTex("C_0", color=RED, font_size=30).next_to(intercept_dot, LEFT, buff=0.1)
        intercept_text = Text("自发消费", font="AR PL UKai CN", font_size=20, color=RED).next_to(intercept_dot, RIGHT, buff=0.1)

        # 斜率标注 (MPC)
        # 在直线上取两点画三角形表示斜率
        x1, x2 = 3, 4.5
        y1 = c0_val + slope_val * x1
        y2 = c0_val + slope_val * x2
        p1 = ax.c2p(x1, y1)
        p2 = ax.c2p(x2, y1)
        p3 = ax.c2p(x2, y2)

        slope_lines = VGroup(
            DashedLine(p1, p2, color=YELLOW),
            DashedLine(p2, p3, color=YELLOW)
        )
        slope_label = MathTex("c", color=YELLOW, font_size=30).next_to(slope_lines, RIGHT, buff=0.1)
        slope_desc = Text("边际消费倾向", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(slope_label, RIGHT, buff=0.1)

        # 4. 动画流程
        # 左侧文字和公式淡入
        self.play(Write(desc_text), run_time=1)
        self.play(FadeIn(formula, shift=UP), Create(rect))
        self.play(Write(condition))

        # 右侧图表展示
        self.play(Create(ax), Write(labels), run_time=1.5)
        self.play(Create(graph_line), run_time=1.5)

        # 标注关键点 C0
        self.play(FadeIn(intercept_dot), Write(intercept_label), FadeIn(intercept_text))

        # 标注斜率 c
        self.play(Create(slope_lines), Write(slope_label), Write(slope_desc))
