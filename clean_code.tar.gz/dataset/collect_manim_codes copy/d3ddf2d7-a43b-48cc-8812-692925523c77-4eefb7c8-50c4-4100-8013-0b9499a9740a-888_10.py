from manim import *

class LitchiStructureAnalysis(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("《南州六月荔枝丹》结构与特征",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心内容布局
        # ---------------------------------------------------------

        # 定义说明顺序文本
        order_text = Text("说明顺序：由表及里 / 由主到次", font="AR PL UKai CN", font_size=24, color=YELLOW)
        order_text.next_to(title_line, DOWN, buff=0.3)
        self.play(FadeIn(order_text))

        # 加载并配置图片 (严格按照 Planner 建议)
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/d3ddf2d7-a43b-48cc-8812-692925523c77/4eefb7c8-50c4-4100-8013-0b9499a9740a/pictures/888_10/1.png") # 这里期望是一张展示荔枝红色龟裂片粗糙外壳的特写图片，要求画面写实，白色背景，光影自然，写实风
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/d3ddf2d7-a43b-48cc-8812-692925523c77/4eefb7c8-50c4-4100-8013-0b9499a9740a/pictures/888_10/2.png") # 这里期望是一张展示剖开荔枝内部结构（红壳白肉褐核）的图片，要求微距视角，写实风
        img3 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/d3ddf2d7-a43b-48cc-8812-692925523c77/4eefb7c8-50c4-4100-8013-0b9499a9740a/pictures/888_10/3.png") # 这里期望是一张展示荔枝树繁茂枝头开满小花或挂果的图片，背景为亚热带果园，写实风景风格

        # 统一设置图片大小 (保持 1:1 比例)
        for img in [img1, img2, img3]:
            img.height = 2.0
            img.width = 2.0

        # 创建图片对应的标签文本
        label1 = Text("外部形态\n(壳/色/形)", font="AR PL UKai CN", font_size=20, line_spacing=1.2)
        label2 = Text("内部组织\n(膜/肉/核)", font="AR PL UKai CN", font_size=20, line_spacing=1.2)
        label3 = Text("生产习性\n(花期/产地)", font="AR PL UKai CN", font_size=20, line_spacing=1.2)

        # 组合图片和标签
        group1 = Group(img1, label1).arrange(DOWN, buff=0.2)
        group2 = Group(img2, label2).arrange(DOWN, buff=0.2)
        group3 = Group(img3, label3).arrange(DOWN, buff=0.2)

        # 水平排列这三组内容
        content_row = Group(group1, group2, group3).arrange(RIGHT, buff=1.0)
        content_row.next_to(order_text, DOWN, buff=0.5)

        # ---------------------------------------------------------
        # 3. 结构分类框图
        # ---------------------------------------------------------

        # 第一部分框 (包含 img1 和 img2)
        part1_rect = SurroundingRectangle(Group(group1, group2), color=BLUE, buff=0.15)
        part1_label = Text("第一部分：生态知识", font="AR PL UKai CN", font_size=22, color=BLUE)
        part1_label.next_to(part1_rect, UP, buff=0.1)

        # 第二部分框 (包含 img3)
        part2_rect = SurroundingRectangle(group3, color=GREEN, buff=0.15)
        part2_label = Text("第二部分：生产情况", font="AR PL UKai CN", font_size=22, color=GREEN)
        part2_label.next_to(part2_rect, UP, buff=0.1)

        # ---------------------------------------------------------
        # 4. 动画展示流程
        # ---------------------------------------------------------

        # 展示第一部分：生态知识
        self.play(Write(part1_label), Create(part1_rect))
        self.play(
            FadeIn(img1, shift=UP), Write(label1),
            FadeIn(img2, shift=UP), Write(label2),
            run_time=2
        )

        # 展示第二部分：生产情况
        self.play(Write(part2_label), Create(part2_rect))
        self.play(
            FadeIn(img3, shift=UP), Write(label3),
            run_time=1.5
        )

        # 强调重点
