from manim import *

class ProofGoalVisualization(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("证明目标 (Proof Goal)",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("15", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心内容构建
        # ---------------------------------------------------------

        # 定义分割线 (模拟交互式证明工具的界面)
        separator = Line(LEFT, RIGHT, color=WHITE, stroke_width=4).set_width(5)
        separator.shift(UP * 0.2) # 稍微上移，保持视觉平衡

        # 上方：可用的前提 (Hypotheses/Context)
        # 使用 MathTex 展示逻辑公式
        premise_1 = MathTex(r"H_1 : P", color=BLUE_A)
        premise_2 = MathTex(r"H_2 : P \to Q", color=BLUE_A)

        # 组合前提，垂直排列
        premises_group = VGroup(premise_1, premise_2).arrange(DOWN, buff=0.2)
        premises_group.next_to(separator, UP, buff=0.3)

        # 下方：待证的结论 (Conclusion)
        conclusion = MathTex(r"Q", color=YELLOW)
        conclusion.next_to(separator, DOWN, buff=0.4)

        # ---------------------------------------------------------
        # 3. 辅助说明 (中文标签与框图)
        # ---------------------------------------------------------

        # 前提部分的说明
        desc_top = Text("可用的前提 (假设/上下文)", font="AR PL UKai CN", font_size=24, color=BLUE)
        desc_top.next_to(separator, RIGHT, buff=1.5).shift(UP * 1.0)

        rect_top = SurroundingRectangle(premises_group, color=BLUE, buff=0.15)
        arrow_top = Arrow(start=desc_top.get_left(), end=rect_top.get_right(), color=BLUE, buff=0.1)

        # 结论部分的说明
        desc_bottom = Text("待证的结论", font="AR PL UKai CN", font_size=24, color=YELLOW)
        desc_bottom.next_to(separator, RIGHT, buff=1.5).shift(DOWN * 1.0)

        rect_bottom = SurroundingRectangle(conclusion, color=YELLOW, buff=0.15)
        arrow_bottom = Arrow(start=desc_bottom.get_left(), end=rect_bottom.get_right(), color=YELLOW, buff=0.1)

        # ---------------------------------------------------------
        # 4. 动画展示流程
        # ---------------------------------------------------------

        # 第一步：画出分割线，建立结构
        self.play(Create(separator), run_time=1)

        # 第二步：显示上方前提及其说明
        self.play(
            FadeIn(premises_group, shift=DOWN),
            Create(rect_top),
            Write(desc_top),
            GrowArrow(arrow_top),
            run_time=1.5
        )

        # 第三步：显示下方结论及其说明
        self.play(
            FadeIn(conclusion, shift=UP),
            Create(rect_bottom),
            Write(desc_bottom),
            GrowArrow(arrow_bottom),
            run_time=1.5
        )

        # 停顿，留给观众阅读时间
