from manim import *

class FluidMechanicsIntroduction(Scene):
    def construct(self):

        # 1. Title
        title = Text("What is Fluid Mechanics?",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Definition of Fluid Mechanics
        definition_text = Text(
            "The science studying the behavior of fluids (liquids, gases)\n"
            "at rest and in motion, and their interaction with solid boundaries.",
            font_size=28,
            line_spacing=1.2
        ).next_to(title_group, DOWN, buff=0.7)

        self.play(FadeIn(definition_text, shift=DOWN), run_time=2)

        # 3. Importance and Applications Section
        applications_title = Text(
            "Core Roles and Applications",
            font_size=30,
            color=BLUE_C,
            weight=BOLD
        ).next_to(definition_text, DOWN, buff=1.0)

        self.play(Write(applications_title))

        # 4. List of Application Areas
        applications_list = BulletedList(
            "Engineering",
            "Environmental Science",
            "Medical Science",
            "Aerospace",
            "Energy Development",
            font_size=28
        ).next_to(applications_title, DOWN, buff=0.4, aligned_edge=LEFT)

        # Animate the list items sequentially
        self.play(
            LaggedStart(*[FadeIn(item, shift=RIGHT) for item in applications_list], lag_ratio=0.25, run_time=4)
        )

        # 5. Highlight the list with a surrounding rectangle
        frame = SurroundingRectangle(applications_list, buff=0.2, color=YELLOW, stroke_width=2)
        self.play(Create(frame), run_time=1.0)
