from manim import *

class BFComplexityAnalysis(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("BF算法复杂度分析",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("26", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 复杂度文本展示 (最好情况与最坏情况)
        # ---------------------------------------------------------
        # 最好情况
        best_case_label = Text("最好情况：", font="AR PL UKai CN", font_size=28, color=GREEN)
        best_case_math = MathTex(r"O(m)\ \text{or}\ O(n)", font_size=32)
        best_case_desc = Text("首次匹配即成功，或每次都在首字符失败", font="AR PL UKai CN", font_size=24, color=GRAY_A)

        best_group = VGroup(best_case_label, best_case_math).arrange(RIGHT, buff=0.2)
        best_full = VGroup(best_group, best_case_desc).arrange(DOWN, buff=0.15, aligned_edge=LEFT)

        # 最坏情况
        worst_case_label = Text("最坏情况：", font="AR PL UKai CN", font_size=28, color=RED)
        worst_case_math = MathTex(r"O(n \times m)", font_size=32)
        worst_case_desc = Text("每轮比对到模式串最后才失败", font="AR PL UKai CN", font_size=24, color=GRAY_A)

        worst_group = VGroup(worst_case_label, worst_case_math).arrange(RIGHT, buff=0.2)
        worst_full = VGroup(worst_group, worst_case_desc).arrange(DOWN, buff=0.15, aligned_edge=LEFT)

        # 整体布局
        content_group = VGroup(best_full, worst_full).arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        content_group.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(content_group, shift=UP))

        # ---------------------------------------------------------
        # 3. 可视化最坏情况 (Example: AAAAAB vs AAB)
        # ---------------------------------------------------------
        # 示例展示位置
        example_start_pos = content_group.get_bottom() + DOWN * 0.8

        # 主串
        text_s_label = Text("主串 S: ", font="AR PL UKai CN", font_size=26).move_to(example_start_pos + LEFT*2)
        text_s_str = Text("A A A A A B", font="AR PL UKai CN", font_size=26, color=BLUE).next_to(text_s_label, RIGHT)

        # 模式串
        text_p_label = Text("模式 P: ", font="AR PL UKai CN", font_size=26).next_to(text_s_label, DOWN, buff=0.5)
        text_p_str = Text("A A B", font="AR PL UKai CN", font_size=26, color=ORANGE).align_to(text_s_str, LEFT).match_y(text_p_label)

        example_group = VGroup(text_s_label, text_s_str, text_p_label, text_p_str)

        self.play(Write(example_group))

        # 强调频繁回溯的问题
        # 用框框住模式串和对应的部分主串
        rect = SurroundingRectangle(VGroup(text_s_str, text_p_str), color=YELLOW, buff=0.1)
        backtrack_text = Text("频繁回溯导致效率低", font="AR PL UKai CN", font_size=24, color=YELLOW)
        backtrack_text.next_to(rect, RIGHT, buff=0.2)

        self.play(
            Create(rect),
            Write(backtrack_text)
        )

        # ---------------------------------------------------------
        # 4. KMP 预告
        # ---------------------------------------------------------
        kmp_arrow = Arrow(start=backtrack_text.get_bottom(), end=backtrack_text.get_bottom() + DOWN * 1.2, color=WHITE)
        kmp_box = RoundedRectangle(corner_radius=0.2, height=1.0, width=5.0, color=BLUE)
        kmp_text = Text("引入 KMP 算法解决回溯问题", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        kmp_group = VGroup(kmp_box, kmp_text).next_to(kmp_arrow, DOWN, buff=0.1)

        # 调整位置防止超出屏幕
        if kmp_group.get_bottom()[1] < -3.5:
            kmp_group.shift(UP * 0.5)
            kmp_arrow.match_points(Arrow(start=backtrack_text.get_bottom(), end=kmp_group.get_top(), color=WHITE))

        self.play(GrowArrow(kmp_arrow))
        self.play(FadeIn(kmp_group, scale=0.9))
