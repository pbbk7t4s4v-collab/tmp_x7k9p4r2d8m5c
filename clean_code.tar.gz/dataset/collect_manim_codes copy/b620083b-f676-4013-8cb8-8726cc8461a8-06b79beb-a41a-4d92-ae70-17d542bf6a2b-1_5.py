from manim import *

class LinearStorageLimitations(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("线性表存储层级数据的局限性",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧可视化：线性表结构
        # 模拟数据：[home, user1, documents]
        data_items = ["home", "user1", "docs"]
        boxes = VGroup()
        for item in data_items:
            # 矩形框
            rect = Rectangle(height=1.0, width=1.8, color=BLUE_C)
            # 文字标签
            lbl = Text(item, font="AR PL UKai CN", font_size=24)
            # 组合
            box_group = VGroup(rect, lbl)
            boxes.add(box_group)

        # 线性排列
        boxes.arrange(RIGHT, buff=0)
        boxes.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 线性表标签
        list_label = Text("线性表结构", font="AR PL UKai CN", font_size=20, color=GRAY)
        list_label.next_to(boxes, UP, buff=0.2)

        self.play(FadeIn(list_label), Create(boxes, run_time=1.5))

        # 3. 右侧文本内容：三个问题
        # 问题1
        p1_title = Text("1. 关系表达困难", font="AR PL UKai CN", font_size=26, color=YELLOW)
        p1_desc = Text("无法直接表示嵌套所属关系", font="AR PL UKai CN", font_size=20, color=WHITE)
        p1_group = VGroup(p1_title, p1_desc).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # 问题2
        p2_title = Text("2. 查找效率低下", font="AR PL UKai CN", font_size=26, color=YELLOW)
        p2_desc = Text("路径查找需遍历整个列表", font="AR PL UKai CN", font_size=20, color=WHITE)
        p2_group = VGroup(p2_title, p2_desc).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # 问题3
        p3_title = Text("3. 操作复杂", font="AR PL UKai CN", font_size=26, color=YELLOW)
        p3_desc = Text("删除节点需手动维护关联", font="AR PL UKai CN", font_size=20, color=WHITE)
        p3_group = VGroup(p3_title, p3_desc).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # 整体排版
        text_content = VGroup(p1_group, p2_group, p3_group).arrange(DOWN, buff=0.7, aligned_edge=LEFT)
        text_content.to_edge(RIGHT, buff=1.5).shift(UP * 0.5)

        # 4. 逐步展示与动画演示

        # --- 演示点 1: 关系困难 ---
        self.play(FadeIn(p1_group, shift=LEFT))
        # 可视化：在盒子之间显示问号,表示关系不明确
        q_marks = VGroup()
        for i in range(2):
            qm = Text("?", font_size=30, color=RED).move_to(boxes[i].get_right())
            q_marks.add(qm)
        self.play(FadeIn(q_marks, run_time=0.5))
        self.play(FadeOut(q_marks, run_time=0.2))

        # --- 演示点 2: 查找效率 ---
        self.play(FadeIn(p2_group, shift=LEFT))
        # 可视化：指针遍历
        pointer = Arrow(start=UP, end=DOWN, color=GREEN).scale(0.5)
        pointer.next_to(boxes[0], UP, buff=0.1)
        self.play(FadeIn(pointer, run_time=0.2))
        # 指针移动动画
        self.play(
            pointer.animate.next_to(boxes[2], UP, buff=0.1),
            run_time=1.5,
            rate_func=linear
        )
        self.play(FadeOut(pointer, run_time=0.2))

        # --- 演示点 3: 操作复杂 ---
        self.play(FadeIn(p3_group, shift=LEFT))
        # 可视化：删除中间项，强调后续项的处理
        cross = Cross(boxes[1], color=RED, scale_factor=0.8)
        self.play(Create(cross, run_time=0.5))

        # 使用 SurroundingRectangle 强调受影响的子项
        orphan_highlight = SurroundingRectangle(boxes[2], color=ORANGE, buff=0.05)
        orphan_text = Text("需维护!", font="AR PL UKai CN", font_size=18, color=ORANGE)
        orphan_text.next_to(orphan_highlight, DOWN, buff=0.1)

        self.play(
            Create(orphan_highlight),
            Write(orphan_text)
        )
