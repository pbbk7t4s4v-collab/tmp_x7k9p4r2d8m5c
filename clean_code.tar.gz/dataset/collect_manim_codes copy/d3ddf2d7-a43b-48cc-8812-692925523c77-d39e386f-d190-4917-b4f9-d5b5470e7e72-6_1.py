from manim import *

class LycheePrefaceAnalysis(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (根据模板)
        # ---------------------------------------------------------
        title = Text("引用白居易《荔枝图序》的作用",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("15", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 左侧：引用内容可视化 (提取核心比喻)
        # ---------------------------------------------------------
        # 引用标签
        quote_label = Text("《荔枝图序》原文", font="AR PL UKai CN", font_size=24, color=BLUE_A)

        # 核心比喻句，使用不同颜色对应不同部位
        q1 = Text("壳如红缯", font="AR PL UKai CN", font_size=26, color=RED_C)
        q2 = Text("膜如紫绡", font="AR PL UKai CN", font_size=26, color=PURPLE_C)
        q3 = Text("瓤肉莹白", font="AR PL UKai CN", font_size=26, color=WHITE)
        q4 = Text("浆液甘酸", font="AR PL UKai CN", font_size=26, color=YELLOW_C)

        quote_content = VGroup(q1, q2, q3, q4).arrange(DOWN, buff=0.4, aligned_edge=LEFT)

        # 组合左侧内容
        left_group = VGroup(quote_label, quote_content).arrange(DOWN, buff=0.4)
        left_group.to_edge(LEFT, buff=1.5).shift(UP*0.5)

        # 添加边框
        quote_box = SurroundingRectangle(left_group, color=BLUE, buff=0.3)

        # ---------------------------------------------------------
        # 3. 右侧：三大作用解析
        # ---------------------------------------------------------
        # 定义作用文本生成函数以保持格式统一
        def create_point(title_text, desc_text):
            t = Text(title_text, font="AR PL UKai CN", font_size=24, color=GOLD)
            d = Text(desc_text, font="AR PL UKai CN", font_size=20, color=WHITE)
            return VGroup(t, d).arrange(DOWN, buff=0.15, aligned_edge=LEFT)

        # 作用1：比喻生动
        p1 = create_point("1. 生动比喻", "展现外壳红艳、肉膜轻柔、瓤肉洁白、浆液香甜")
        # 作用2：结构总领
        p2 = create_point("2. 结构作用", "作为引子总领全文，对荔枝形态做总说明")
        # 作用3：文学色彩
        p3 = create_point("3. 文学色彩", "文字优美简练，富有诗情画意")

        # 组合右侧列表
        right_group = VGroup(p1, p2, p3).arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        right_group.next_to(quote_box, RIGHT, buff=1.5)

        # ---------------------------------------------------------
        # 4. 动画展示流程
        # ---------------------------------------------------------

        # 展示左侧引用
        self.play(
            Create(quote_box),
            FadeIn(left_group, shift=RIGHT),
            run_time=1.5
        )

        # 创建连接箭头
        arrow_top = Arrow(quote_box.get_right(), right_group.get_top(), color=GREY, buff=0.1)
        arrow_bottom = Arrow(quote_box.get_right(), right_group.get_bottom(), color=GREY, buff=0.1)

        # 逐步展示右侧作用
        self.play(FadeIn(arrow_top), FadeIn(arrow_bottom))

        # 逐条展示分析点
        for point in [p1, p2, p3]:
            # 简单的强调框
            highlight = SurroundingRectangle(point, color=YELLOW, buff=0.1, stroke_width=1)
            self.play(
                Write(point),
                Create(highlight),
                run_time=1.2
            )
            self.play(FadeOut(highlight), run_time=0.5)
