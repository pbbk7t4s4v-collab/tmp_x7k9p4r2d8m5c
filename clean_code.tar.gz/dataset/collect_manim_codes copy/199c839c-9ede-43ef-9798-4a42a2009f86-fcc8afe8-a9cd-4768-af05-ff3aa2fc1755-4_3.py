from manim import *

class RiemannSumScene(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("黎曼和：面积的近似计算",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("11", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 坐标系与函数图像
        # 向上移动坐标系，为底部公式留出空间
        axes = Axes(
            x_range=[0, 6],
            y_range=[0, 5],
            x_length=7,
            y_length=4,
            axis_config={"include_tip": True, "color": GREY},
        ).shift(UP * 0.5)

        labels = axes.get_axis_labels(x_label="x", y_label="y")

        # 定义函数 f(x) = 0.15(x-1)^2 + 1，平滑曲线
        func = lambda x: 0.15 * (x - 1) ** 2 + 1
        graph = axes.plot(func, x_range=[0.5, 5.5], color=BLUE)
        graph_label = axes.get_graph_label(graph, label="f(x)", x_val=5.5, direction=UP)

        # 3. 黎曼矩形 (Riemann Rectangles)
        # 将区间 [1, 5] 分割，dx=0.5
        rects = axes.get_riemann_rectangles(
            graph,
            x_range=[1, 5],
            dx=0.5,
            input_sample_type="left", # 左端点作为样本点
            stroke_width=1,
            fill_opacity=0.6,
            color=TEAL
        )

        # 4. 公式展示
        # 黎曼和公式
        formula = MathTex(
            r"S_n = \sum_{i=1}^{n} f(\xi_i) \Delta x_i",
            font_size=38
        )

        # 解释文本
        desc_text = Text(
            "总面积 ≈ 矩形面积之和",
            font="AR PL UKai CN",
            font_size=28,
            color=YELLOW
        )

        # 组合公式和文本，放置在坐标系下方
        formula_group = VGroup(formula, desc_text).arrange(RIGHT, buff=0.8)
        formula_group.next_to(axes, DOWN, buff=0.5)

        # 5. 动画流程
        # 绘制坐标系和曲线
        self.play(Create(axes), FadeIn(labels), run_time=1)
        self.play(Create(graph), FadeIn(graph_label), run_time=1)

        # 逐步显示矩形，模拟分割过程
        self.play(Create(rects), run_time=2)

        # 标注其中一个矩形的含义（高度与宽度）
        # 选取中间的一个矩形
        sample_rect = rects[4]
        # 闪烁强调
        self.play(sample_rect.animate.set_color(YELLOW), run_time=0.5)
        self.play(sample_rect.animate.set_color(TEAL), run_time=0.5)

        # 显示公式
        self.play(Write(formula), run_time=1.5)
        self.play(FadeIn(desc_text), run_time=1)

        # 框选公式重点
        box = SurroundingRectangle(formula, color=ORANGE, buff=0.15)
        self.play(Create(box), run_time=1)
