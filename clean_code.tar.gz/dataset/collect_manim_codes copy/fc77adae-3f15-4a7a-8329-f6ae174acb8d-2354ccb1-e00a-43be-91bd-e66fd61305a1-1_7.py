from manim import *

class FluidMechanicsEnvironmental(Scene):
    def construct(self):

        # 1. Title
        title = Text("Fluid Mechanics in Environmental Science",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Core Concept: Process Flow
        box1_text = Text("Pollutant Diffusion\n(in Water/Air)", font_size=28)
        box2_text = Text("Fluid Mechanics\nSimulation", font_size=28)
        box3_text = Text("Environmental\nGovernance", font_size=28)

        box1 = SurroundingRectangle(box1_text, buff=0.3, color=BLUE)
        box2 = SurroundingRectangle(box2_text, buff=0.3, color=GREEN)
        box3 = SurroundingRectangle(box3_text, buff=0.3, color=ORANGE)

        step1 = VGroup(box1, box1_text)
        step2 = VGroup(box2, box2_text)
        step3 = VGroup(box3, box3_text)

        process_flow = VGroup(step1, step2, step3).arrange(RIGHT, buff=1.0)
        process_flow.center().shift(UP * 0.5)

        arrow1 = Arrow(step1.get_right(), step2.get_left(), buff=0.1, color=WHITE)
        arrow2 = Arrow(step2.get_right(), step3.get_left(), buff=0.1, color=WHITE)

        # 3. Animate the Process Flow
        self.play(FadeIn(step1, shift=DOWN), run_time=1)
        self.play(GrowArrow(arrow1), FadeIn(step2, shift=DOWN), run_time=1.2)
        self.play(GrowArrow(arrow2), FadeIn(step3, shift=DOWN), run_time=1.2)

        # 4. Applications List
        applications_title = Text("Key Application Areas:", font_size=30, weight=BOLD)
        applications_title.next_to(process_flow, DOWN, buff=1.0)

        applications_list = BulletedList(
            "Ocean Pollution Analysis",
            "Acid Rain Formation & Spread",
            "Atmospheric Particulate Transport",
            font_size=28
        ).next_to(applications_title, DOWN, buff=0.3, aligned_edge=LEFT)

        self.play(Write(applications_title), run_time=1)
        self.play(FadeIn(applications_list, shift=UP), run_time=1.5)
