from manim import *

class PhilosophicalShift(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("哲学对象的转变：从抽象的人到现实的人",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧展示：抽象的人
        # 图片 1
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/199c839c-9ede-43ef-9798-4a42a2009f86/be962362-0e7b-4d63-8290-a87589daaf86/pictures/2_1/1.png") # 这里期望是一张展示一个由几何线条和光点构成的虚幻人形轮廓，悬浮在空白背景中，看起来孤立、静止且完美的，象征'抽象的人'的图片，要求画面极简主义线条艺术或科技感蓝图风格，写实风
        img1.height = 3
        img1.to_edge(LEFT, buff=1.5).shift(DOWN * 0.5)

        # 边框
        rect1 = SurroundingRectangle(img1, color=BLUE, buff=0.1)

        # 标签
        label1 = Text("抽象的人", font="AR PL UKai CN", font_size=28, color=BLUE)
        label1.next_to(rect1, UP, buff=0.2)

        # 特征描述
        desc1 = VGroup(
            Text("• 孤立个体", font="AR PL UKai CN", font_size=20),
            Text("• 静止不变", font="AR PL UKai CN", font_size=20),
            Text("• 臆想完美", font="AR PL UKai CN", font_size=20)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        desc1.next_to(rect1, DOWN, buff=0.2)

        group1 = Group(img1, rect1, label1, desc1)

        # 3. 右侧展示：现实的人
        # 图片 2
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/199c839c-9ede-43ef-9798-4a42a2009f86/be962362-0e7b-4d63-8290-a87589daaf86/pictures/2_1/2.png") # 这里期望是一张展示一个穿着具体衣物（如工装或日常便服）的真实人物，置身于具体的社会场景中（如热闹的集市或繁忙的工厂），表情生动，象征处于社会关系和历史中的'现实的人'的图片，要求画面写实插画风或油画风，写实风
        img2.height = 3
        img2.to_edge(RIGHT, buff=1.5).shift(DOWN * 0.5)

        # 边框
        rect2 = SurroundingRectangle(img2, color=GREEN, buff=0.1)

        # 标签
        label2 = Text("现实的人", font="AR PL UKai CN", font_size=28, color=GREEN)
        label2.next_to(rect2, UP, buff=0.2)

        # 特征描述
        desc2 = VGroup(
            Text("• 社会关系", font="AR PL UKai CN", font_size=20),
            Text("• 历史活动", font="AR PL UKai CN", font_size=20),
            Text("• 劳动实践", font="AR PL UKai CN", font_size=20)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        desc2.next_to(rect2, DOWN, buff=0.2)

        group2 = Group(img2, rect2, label2, desc2)

        # 4. 中间转换箭头
        arrow = Arrow(start=rect1.get_right(), end=rect2.get_left(), buff=0.5, color=YELLOW)
        arrow_text = Text("根本转变", font="AR PL UKai CN", font_size=24, color=YELLOW)
        arrow_text.next_to(arrow, UP, buff=0.1)

        # 5. 动画播放流程
        # 显示左侧
        self.play(FadeIn(img1), Create(rect1), Write(label1))
        self.play(Write(desc1), run_time=1)

        # 显示箭头过渡
        self.play(GrowArrow(arrow), FadeIn(arrow_text))

        # 显示右侧
        self.play(FadeIn(img2), Create(rect2), Write(label2))
        self.play(Write(desc2), run_time=1)

        # 稍微停顿
