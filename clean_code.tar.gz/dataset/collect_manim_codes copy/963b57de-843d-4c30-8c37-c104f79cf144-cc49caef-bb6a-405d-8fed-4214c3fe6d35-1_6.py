from manim import *

class FluidMechanicsProgressScene(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Driving Scientific and Technological Progress",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Core Concept: Fluid Mechanics
        core_concept_text = Text("Fluid Mechanics", font_size=28)
        core_concept_box = SurroundingRectangle(core_concept_text, color=BLUE, buff=0.3, corner_radius=0.1)
        core_concept = VGroup(core_concept_text, core_concept_box).move_to(LEFT * 4.5)

        self.play(FadeIn(core_concept, scale=0.8))

        # 3. Branch 1: Computational Fluid Dynamics (CFD)
        cfd_text = Text("Computational Fluid Dynamics (CFD)", font_size=26)
        cfd_box = SurroundingRectangle(cfd_text, color=GREEN, buff=0.2, corner_radius=0.1)
        cfd_group = VGroup(cfd_text, cfd_box).move_to(RIGHT * 1.5 + UP * 2)

        arrow_to_cfd = Arrow(core_concept.get_right(), cfd_group.get_left(), buff=0.2, color=WHITE)

        self.play(
            Create(arrow_to_cfd),
            Write(cfd_group)
        )

        # 4. Sub-branch from CFD: High-Performance Computing
        hpc_text = Text("High-Performance Computing", font_size=26)
        hpc_box = SurroundingRectangle(hpc_text, color=ORANGE, buff=0.2, corner_radius=0.1)
        hpc_group = VGroup(hpc_text, hpc_box).next_to(cfd_group, UP, buff=0.8)

        arrow_to_hpc = Arrow(cfd_group.get_top(), hpc_group.get_bottom(), buff=0.2, color=WHITE)

        self.play(
            Create(arrow_to_hpc),
            FadeIn(hpc_group, shift=UP)
        )

        # 5. Branch 2: Interdisciplinary Fields
        inter_text = Text("Interdisciplinary Support", font_size=26)
        inter_box = SurroundingRectangle(inter_text, color=PURPLE, buff=0.2, corner_radius=0.1)
        inter_group = VGroup(inter_text, inter_box).move_to(RIGHT * 1.5 + DOWN * 1.5)

        arrow_to_inter = Arrow(core_concept.get_right(), inter_group.get_left(), buff=0.2, color=WHITE)

        self.play(
            Create(arrow_to_inter),
            Write(inter_group)
        )

        # 6. List of supported fields
        fields_list = BulletedList(
            "Heat Transfer",
            "Chemical Reactions",
            "Materials Science",
            font_size=24
        ).next_to(inter_group, DOWN, buff=0.5).align_to(inter_group.get_left(), LEFT)

        self.play(FadeIn(fields_list, shift=UP, lag_ratio=0.5))
