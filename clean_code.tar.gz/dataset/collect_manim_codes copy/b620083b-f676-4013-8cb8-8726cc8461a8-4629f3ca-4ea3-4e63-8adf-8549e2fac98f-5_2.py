from manim import *

class LinkedListOperations(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("链表：基本操作实现与复杂度",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("19", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧文字描述
        text_group = VGroup()

        # 辅助函数：创建文本行
        def create_text_line(content, sub_content=None):
            line = VGroup()
            main_text = Text(content, font="AR PL UKai CN", font_size=24, color=WHITE)
            line.add(main_text)
            if sub_content:
                sub_text = MathTex(sub_content, font_size=26, color=YELLOW).next_to(main_text, RIGHT, buff=0.2)
                line.add(sub_text)
            return line

        # 条目1：构造与析构
        item1 = create_text_line("1. 构造与析构：Python自动回收 / C++手动释放")

        # 条目2：插入与删除
        item2 = create_text_line("2. 插入与删除：核心是修改指针")
        item2_sub1 = create_text_line("   - 已知前驱节点：", "O(1)")
        item2_sub2 = create_text_line("   - 需查找位置：", "O(N)")

        # 条目3：查找操作
        item3 = create_text_line("3. 查找数值/位置：不支持随机访问")
        item3_sub = create_text_line("   - 必须从头遍历：", "O(N)")

        text_group.add(item1, item2, item2_sub1, item2_sub2, item3, item3_sub)
        text_group.arrange(DOWN, aligned_edge=LEFT, buff=0.35)
        text_group.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # 3. 内容布局 - 右侧插入操作可视化
        # 创建节点函数
        def create_node(label_text, color=BLUE):
            box = Square(side_length=1.0, color=color, fill_opacity=0.5, fill_color=color)
            txt = Text(label_text, font="AR PL UKai CN", font_size=24)
            return VGroup(box, txt)

        # 初始状态：A -> B
        node_a = create_node("A", BLUE).move_to(RIGHT * 2 + UP * 0.5)
        node_b = create_node("B", BLUE).next_to(node_a, RIGHT, buff=1.5)

        arrow_ab = Arrow(node_a.get_right(), node_b.get_left(), buff=0.1, color=WHITE)

        initial_group = VGroup(node_a, node_b, arrow_ab)

        # 插入状态：A -> New -> B
        node_new = create_node("新", GREEN).move_to(arrow_ab.get_center() + UP * 1.2)

        arrow_a_new = Arrow(node_a.get_right(), node_new.get_left(), buff=0.1, color=YELLOW)
        arrow_new_b = Arrow(node_new.get_right(), node_b.get_left(), buff=0.1, color=YELLOW)

        insert_label = Text("插入逻辑：无需移动元素", font="AR PL UKai CN", font_size=20, color=YELLOW)
        insert_label.next_to(node_new, UP, buff=0.2)

        # 强调框
        highlight_rect = SurroundingRectangle(VGroup(node_a, node_b, node_new), color=ORANGE, buff=0.2)

        # 4. 动画流程
        # 4.1 显示左侧文字
        self.play(FadeIn(text_group, shift=RIGHT), run_time=1.5)

        # 4.2 显示初始链表节点
        self.play(FadeIn(initial_group), run_time=1.0)

        # 4.3 演示插入过程
        self.play(
            FadeIn(node_new, shift=DOWN),
            FadeIn(insert_label),
            run_time=0.8
        )

        # 4.4 变换箭头（核心逻辑展示）
        self.play(
            Transform(arrow_ab, arrow_a_new), # 这里的Transform视觉上可能不完美，但在教学中表示断开旧的连新的
            Create(arrow_new_b),
            run_time=1.2
        )

        # 4.5 移动新节点到位（可选，为了整齐）
        target_y = node_a.get_y()
        self.play(
            node_new.animate.move_to([node_new.get_x(), target_y, 0]),
            insert_label.animate.shift(DOWN * 1.2),
            # 重新调整箭头位置
            arrow_ab.animate.put_start_and_end_on(node_a.get_right() + RIGHT*0.1, [node_new.get_x() - 0.5, target_y, 0]),
            arrow_new_b.animate.put_start_and_end_on([node_new.get_x() + 0.5, target_y, 0], node_b.get_left() - LEFT*0.1),
            run_time=1.0
        )

        # 4.6 强调框
        self.play(Create(highlight_rect), run_time=0.5)
