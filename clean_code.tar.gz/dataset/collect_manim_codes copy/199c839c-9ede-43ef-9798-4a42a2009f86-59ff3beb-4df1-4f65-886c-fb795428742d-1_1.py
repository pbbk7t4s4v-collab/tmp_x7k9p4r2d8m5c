from manim import *

class DeterminantBasicConcept(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (符合模板要求)
        # ---------------------------------------------------------
        title = Text("行列式的基本概念",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容展示:从矩阵到行列式的概念引入
        # ---------------------------------------------------------

        # 概念文本
        concept_text = Text("方阵 \u2192 特定的数值 (标量)", font="AR PL UKai CN", font_size=28, color=BLUE_B)
        concept_text.next_to(title_line, DOWN, buff=0.6)
        self.play(FadeIn(concept_text))

        # 步骤1:展示方阵 A
        # 使用 split 使得后续变换更自然
        matrix_tex = MathTex(
            r"A =",
            r"\begin{bmatrix} a & b \\ c & d \end{bmatrix}"
        )
        matrix_tex.scale(1.2)
        matrix_tex.move_to(ORIGIN).shift(DOWN * 0.5)

        # 标签:这是一个表格/数组
        matrix_label = Text("方阵 (表格)", font="AR PL UKai CN", font_size=24, color=GRAY)
        matrix_label.next_to(matrix_tex, DOWN, buff=0.3)

        self.play(Write(matrix_tex))
        self.play(FadeIn(matrix_label))

        # 步骤2:变换为行列式记号
        # 注意这里用竖线代替方括号
        det_tex = MathTex(
            r"|A| =",
            r"\begin{vmatrix} a & b \\ c & d \end{vmatrix}"
        )
        det_tex.scale(1.2)
        det_tex.move_to(matrix_tex.get_center())

        # 标签变化
        det_label = Text("行列式 (数值)", font="AR PL UKai CN", font_size=24, color=YELLOW)
        det_label.next_to(det_tex, DOWN, buff=0.3)

        self.play(
            ReplacementTransform(matrix_tex, det_tex),
            ReplacementTransform(matrix_label, det_label)
        )

        # ---------------------------------------------------------
        # 3. 展示计算规则 (可视化的对角线法则)
        # ---------------------------------------------------------

        # 构造结果公式: ad - bc
        # 分开写以便上色
        equals = MathTex("=")
        term_1 = MathTex("a", "d") # 主对角线
        minus = MathTex("-")
        term_2 = MathTex("b", "c") # 副对角线

        # 设置颜色以突出对角线关系
        term_1.set_color(GREEN) # ad 绿色
        term_2.set_color(RED)   # bc 红色

        formula_group = VGroup(equals, term_1, minus, term_2).arrange(RIGHT, buff=0.2)
        formula_group.scale(1.2)
        formula_group.next_to(det_tex, RIGHT, buff=0.3)

        # 播放公式出现
        self.play(Write(formula_group))

        # ---------------------------------------------------------
        # 4. 总结与强调
        # ---------------------------------------------------------

        # 使用矩形框强调整个算式
        full_equation = VGroup(det_tex, formula_group)
        box = SurroundingRectangle(full_equation, color=YELLOW, buff=0.2)

        # 解释文字
        explanation = Text("主对角线乘积 - 副对角线乘积", font="AR PL UKai CN", font_size=22, color=YELLOW)
        explanation.next_to(box, DOWN, buff=0.2)
        # 移除之前的标签以防重叠
        self.play(FadeOut(det_label))

        self.play(
            Create(box),
            Write(explanation)
        )
