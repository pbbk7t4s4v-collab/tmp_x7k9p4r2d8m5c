from manim import *

class SimplePathAndCycle(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("简单路径与简单回路",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 标题动画
        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局规划
        # 左侧用于放图，右侧用于放文字定义

        # ----------- 图形构建 (左侧) -----------
        # 定义节点坐标
        p1 = LEFT * 5.5 + UP * 0.5
        p2 = LEFT * 2.5 + UP * 0.5
        p3 = LEFT * 2.5 + DOWN * 1.5
        p4 = LEFT * 5.5 + DOWN * 1.5

        # 创建节点
        dot1 = Dot(p1, color=BLUE, radius=0.12)
        dot2 = Dot(p2, color=BLUE, radius=0.12)
        dot3 = Dot(p3, color=BLUE, radius=0.12)
        dot4 = Dot(p4, color=BLUE, radius=0.12)

        # 节点标签
        l1 = MathTex("v_1").next_to(dot1, UL, buff=0.1)
        l2 = MathTex("v_2").next_to(dot2, UR, buff=0.1)
        l3 = MathTex("v_3").next_to(dot3, DR, buff=0.1)
        l4 = MathTex("v_4").next_to(dot4, DL, buff=0.1)

        nodes = VGroup(dot1, dot2, dot3, dot4, l1, l2, l3, l4)

        # 创建底层的边 (灰色)
        edge1 = Line(p1, p2, color=GRAY, stroke_opacity=0.3)
        edge2 = Line(p2, p3, color=GRAY, stroke_opacity=0.3)
        edge3 = Line(p3, p4, color=GRAY, stroke_opacity=0.3)
        edge4 = Line(p4, p1, color=GRAY, stroke_opacity=0.3)
        edge5 = Line(p1, p3, color=GRAY, stroke_opacity=0.3) # 对角线

        edges = VGroup(edge1, edge2, edge3, edge4, edge5)
        graph_group = VGroup(edges, nodes)

        # ----------- 文本定义 (右侧) -----------
        # 简单路径定义
        def1_title = Text("简单路径", font="AR PL UKai CN", font_size=28, color=YELLOW)
        def1_content = Text("除首尾外顶点不重复", font="AR PL UKai CN", font_size=24, color=WHITE)
        def1_note = Text("(即不兜圈子)", font="AR PL UKai CN", font_size=20, color=LIGHT_GRAY)

        def1_group = VGroup(def1_title, def1_content, def1_note).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        def1_group.to_edge(RIGHT, buff=1.0).shift(UP*1.5)

        # 简单回路定义
        def2_title = Text("简单回路 (简单环)", font="AR PL UKai CN", font_size=28, color=GREEN)
        def2_content = Text("首尾相同的简单路径", font="AR PL UKai CN", font_size=24, color=WHITE)

        def2_group = VGroup(def2_title, def2_content).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        def2_group.next_to(def1_group, DOWN, buff=1.5, aligned_edge=LEFT)

        # ----------- 动画流程 -----------

        # Step 1: 显示基础图结构
        self.play(FadeIn(graph_group), run_time=1.0)

        # Step 2: 讲解简单路径
        # 框选文本
        box1 = SurroundingRectangle(def1_group, color=YELLOW, buff=0.2)
        self.play(
            Write(def1_group),
            Create(box1),
            run_time=1.0
        )

        # 高亮演示路径: v1 -> v2 -> v3
        path_line1 = Line(p1, p2, color=YELLOW, stroke_width=6)
        path_line2 = Line(p2, p3, color=YELLOW, stroke_width=6)
        path_vis = VGroup(path_line1, path_line2)

        self.play(Create(path_vis), run_time=1.5)

        # Step 3: 讲解简单回路
        # 框选文本
        box2 = SurroundingRectangle(def2_group, color=GREEN, buff=0.2)

        self.play(
            ReplacementTransform(box1, box2), # 框移动到下面
            FadeOut(path_vis),                # 清楚上一条路径
            Write(def2_group),
            run_time=1.0
        )

        # 高亮演示回路: v1 -> v2 -> v3 -> v4 -> v1
        cycle_line1 = Line(p1, p2, color=GREEN, stroke_width=6)
        cycle_line2 = Line(p2, p3, color=GREEN, stroke_width=6)
        cycle_line3 = Line(p3, p4, color=GREEN, stroke_width=6)
        cycle_line4 = Line(p4, p1, color=GREEN, stroke_width=6)
        cycle_vis = VGroup(cycle_line1, cycle_line2, cycle_line3, cycle_line4)

        self.play(Create(cycle_vis), run_time=2.0)
