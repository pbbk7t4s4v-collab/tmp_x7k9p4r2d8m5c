from manim import *

class MultipleLinkedListNode(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("多重链表：概念与应用",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("19", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念文本
        concept_text = Text("定义：节点同时隶属于多个逻辑链表",
                           font="AR PL UKai CN",
                           font_size=28,
                           color=BLUE_A)
        concept_text.next_to(title_group, DOWN, buff=0.5)
        self.play(FadeIn(concept_text, shift=DOWN))

        # 3. 可视化部分：十字链表节点示意图
        # 创建中心节点
        node_box = Square(side_length=1.5, color=BLUE, fill_opacity=0.2)
        node_text = Text("数据\n节点", font="AR PL UKai CN", font_size=24).move_to(node_box)

        # 创建行指针（向右）
        arrow_row = Arrow(start=node_box.get_right(), end=node_box.get_right() + RIGHT * 2, buff=0.1, color=YELLOW)
        label_row = Text("行链表 (Row)", font="AR PL UKai CN", font_size=20, color=YELLOW)
        label_row.next_to(arrow_row, UP, buff=0.1)

        # 创建列指针（向下）
        arrow_col = Arrow(start=node_box.get_bottom(), end=node_box.get_bottom() + DOWN * 2, buff=0.1, color=GREEN)
        label_col = Text("列链表 (Col)", font="AR PL UKai CN", font_size=20, color=GREEN)
        label_col.next_to(arrow_col, LEFT, buff=0.1)

        # 组合图示
        diagram = VGroup(node_box, node_text, arrow_row, label_row, arrow_col, label_col)
        diagram.to_edge(LEFT, buff=1.5).shift(UP * 0.5)

        # 添加图示边框
        diagram_frame = SurroundingRectangle(diagram, color=WHITE, buff=0.2, corner_radius=0.1)
        diagram_title = Text("十字链表结构示意", font="AR PL UKai CN", font_size=20).next_to(diagram_frame, UP, buff=0.1)

        # 4. 应用场景列表 (位于右侧)
        app_title = Text("主要应用：", font="AR PL UKai CN", font_size=26, color=TEAL)

        # 使用VGroup手动排版列表，避免BulletedList的潜在问题
        item1 = Text("• 高效存储稀疏矩阵", font="AR PL UKai CN", font_size=24)
        item1_sub = Text("  (行与列链表交叉)", font="AR PL UKai CN", font_size=20, color=GRAY)
        item2 = Text("• 图的邻接表表示", font="AR PL UKai CN", font_size=24)

        app_group = VGroup(app_title, item1, item1_sub, item2).arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        app_group.next_to(diagram_frame, RIGHT, buff=1.0).align_to(diagram_frame, UP)

        # 5. 动画播放序列
        # 显示图示结构
        self.play(Create(diagram_frame), Write(diagram_title))
        self.play(
            Create(node_box),
            Write(node_text)
        )
        self.play(
            GrowArrow(arrow_row),
            Write(label_row),
            run_time=0.8
        )
        self.play(
            GrowArrow(arrow_col),
            Write(label_col),
            run_time=0.8
        )

        # 显示应用场景
        self.play(Write(app_group), run_time=1.5)

        # 停顿
