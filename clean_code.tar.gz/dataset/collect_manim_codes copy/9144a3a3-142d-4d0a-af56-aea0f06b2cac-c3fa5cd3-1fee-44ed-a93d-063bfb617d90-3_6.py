from manim import *

class AI4SFirstBeam(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (根据模板)
        # ---------------------------------------------------------
        title = Text("AI4S基础设施：模型算法与软件系统",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("19", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念展示：原理 + 数据 -> 模型/软件
        # ---------------------------------------------------------

        # 左侧：基本原理
        principle_icon = MathTex(r"\hat{H}\psi = E\psi", color=BLUE_B).scale(0.8)
        principle_text = Text("基本原理", font="AR PL UKai CN", font_size=24, color=BLUE)
        principle_group = VGroup(principle_icon, principle_text).arrange(DOWN, buff=0.2)
        principle_group.shift(UP * 1.5 + LEFT * 4)

        # 右侧：数据驱动
        data_icon = MathTex(r"y = f(x; \theta)", color=GREEN_B).scale(0.8)
        data_text = Text("数据驱动", font="AR PL UKai CN", font_size=24, color=GREEN)
        data_group = VGroup(data_icon, data_text).arrange(DOWN, buff=0.2)
        data_group.shift(UP * 1.5 + RIGHT * 4)

        # 中间：核心基础设施（模型算法与软件系统）
        core_text = Text("模型算法与软件系统", font="AR PL UKai CN", font_size=28, color=YELLOW)
        core_box = SurroundingRectangle(core_text, color=YELLOW, buff=0.3)
        core_group = VGroup(core_box, core_text).move_to(ORIGIN)

        # 箭头连接
        arrow_left = Arrow(start=principle_group.get_bottom(), end=core_box.get_left(), color=BLUE_C, buff=0.1)
        arrow_right = Arrow(start=data_group.get_bottom(), end=core_box.get_right(), color=GREEN_C, buff=0.1)

        # 动画展示第一阶段
        self.play(FadeIn(principle_group, shift=RIGHT), FadeIn(data_group, shift=LEFT))
        self.play(
            Create(arrow_left),
            Create(arrow_right),
            FadeIn(core_group, scale=0.5)
        )

        # ---------------------------------------------------------
        # 3. 示例展示 (DPA, DeePMD, ABACUS)
        # ---------------------------------------------------------

        # 创建示例文本
        examples_label = Text("代表性示例：", font="AR PL UKai CN", font_size=24, color=WHITE).next_to(core_box, DOWN, buff=0.5)

        ex_1 = Text("DPA", font="AR PL UKai CN", font_size=24, color=TEAL)
        ex_2 = Text("DeePMD", font="AR PL UKai CN", font_size=24, color=TEAL)
        ex_3 = Text("ABACUS", font="AR PL UKai CN", font_size=24, color=TEAL)

        examples_list = VGroup(ex_1, ex_2, ex_3).arrange(RIGHT, buff=0.8)
        examples_list.next_to(examples_label, DOWN, buff=0.2)

        self.play(Write(examples_label))
        self.play(
            FadeIn(ex_1, shift=UP),
            FadeIn(ex_2, shift=UP),
            FadeIn(ex_3, shift=UP)
        )

        # ---------------------------------------------------------
        # 4. 目标展示
        # ---------------------------------------------------------

        # 底部目标
        goal_text = Text("目标：跨尺度、跨物理过程的统一高效平台",
                        font="AR PL UKai CN",
                        font_size=26,
                        color=ORANGE)
        goal_bg = SurroundingRectangle(goal_text, color=ORANGE, fill_opacity=0.1, buff=0.2)
        goal_group = VGroup(goal_bg, goal_text).to_edge(DOWN, buff=1.0)

        # 连接线：从示例指向目标
        arrow_down = Arrow(start=examples_list.get_bottom(), end=goal_bg.get_top(), color=GREY, buff=0.1)

        self.play(Create(arrow_down))
        self.play(
            FadeIn(goal_bg),
            Write(goal_text)
        )
