from manim import *

class PreorderTraversalScene(Scene):
    def construct(self):

        # 1. 标题
        title = Text("二叉树的前序遍历",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 定义和核心思想
        definition = Text(
            "核心思想：先访问根节点，再依次遍历左子树和右子树。",
            font="AR PL UKai CN",
            font_size=28
        ).next_to(title_group, DOWN, buff=0.4)

        rule = Text(
            "根节点 → 左子树 → 右子树",
            font="AR PL UKai CN",
            font_size=32,
            t2c={"根节点": YELLOW, "左子树": GREEN, "右子树": BLUE}
        ).next_to(definition, DOWN, buff=0.4)

        self.play(FadeIn(definition, shift=DOWN*0.5))
        self.play(Write(rule))

        # 3. 创建二叉树示例
        nodes = {
            'A': (0, 1.5, 0),
            'B': (-2, 0, 0),
            'C': (2, 0, 0),
            'D': (-3, -1.5, 0),
            'E': (-1, -1.5, 0)
        }

        circles = {name: Circle(radius=0.3, color=WHITE, fill_opacity=1).move_to(pos) for name, pos in nodes.items()}
        labels = {name: Text(name, font_size=24, color=BLACK).move_to(c.get_center()) for name, c in circles.items()}

        edges = [
            Line(circles['A'].get_bottom(), circles['B'].get_top(), buff=0.1),
            Line(circles['A'].get_bottom(), circles['C'].get_top(), buff=0.1),
            Line(circles['B'].get_bottom(), circles['D'].get_top(), buff=0.1),
            Line(circles['B'].get_bottom(), circles['E'].get_top(), buff=0.1)
        ]

        tree_nodes = VGroup(*[VGroup(c, l) for c, l in zip(circles.values(), labels.values())])
        tree_edges = VGroup(*edges)
        tree = VGroup(tree_edges, tree_nodes).scale(0.9).shift(LEFT * 3 + DOWN * 0.8)

        self.play(FadeIn(tree, shift=UP))

        # 4. 演示遍历过程
        result_label = Text("遍历顺序:", font="AR PL UKai CN", font_size=28).to_edge(RIGHT, buff=1.5).shift(UP*1.5)
        result_text = VGroup().next_to(result_label, DOWN, buff=0.3, aligned_edge=LEFT)
        self.play(Write(result_label))

        traversal_order = ['A', 'B', 'D', 'E', 'C']
        highlight_box = SurroundingRectangle(circles['A'], color=YELLOW, buff=0.1)
        self.play(Create(highlight_box))

        for i, node_name in enumerate(traversal_order):
            target_node_group = VGroup(circles[node_name], labels[node_name])

            # 移动高亮框
            self.play(highlight_box.animate.move_to(target_node_group.get_center()), run_time=0.7)

            # 添加结果
            current_result = Text(node_name, font_size=30, color=YELLOW).move_to(result_text)
            if result_text:
                current_result.next_to(result_text, RIGHT, buff=0.2)

            result_text.add(current_result)
            self.play(FadeIn(current_result, scale=1.5), run_time=0.5)
