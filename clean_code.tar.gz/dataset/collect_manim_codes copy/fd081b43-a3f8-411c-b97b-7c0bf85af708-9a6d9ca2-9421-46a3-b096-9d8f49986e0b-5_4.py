from manim import *
import numpy as np

class GradientOrthogonality(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("梯度与等高线的正交关系",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("35", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心定理文本
        theorem_text = Text("定理：梯度向量垂直于过该点的等高线", font_size=26, font="AR PL UKai CN", color=YELLOW)
        theorem_text.next_to(title_line, DOWN, buff=0.3)
        self.play(FadeIn(theorem_text))

        # 3. 左侧：数学推导
        # 步骤 1: 参数方程
        step1_text = Text("设等高线参数方程:", font_size=22, font="AR PL UKai CN", color=GRAY_B)
        step1_math = MathTex(r"f(x(t), y(t)) = c", font_size=32)

        # 步骤 2: 求导
        step2_text = Text("对 t 求导(链式法则):", font_size=22, font="AR PL UKai CN", color=GRAY_B)
        step2_math = MathTex(r"\frac{\partial f}{\partial x}\frac{dx}{dt} + \frac{\partial f}{\partial y}\frac{dy}{dt} = 0", font_size=32)

        # 步骤 3: 向量形式
        step3_text = Text("写成点积形式:", font_size=22, font="AR PL UKai CN", color=GRAY_B)
        step3_math = MathTex(r"\nabla f \cdot \mathbf{r}'(t) = 0", font_size=38, color=BLUE_A)

        # 布局左侧内容
        left_group = VGroup(
            step1_text, step1_math,
            step2_text, step2_math,
            step3_text, step3_math
        ).arrange(DOWN, buff=0.25, aligned_edge=LEFT)
        left_group.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # 4. 右侧：几何可视化
        # 坐标系 (隐藏轴线，只展示几何关系)
        plane = NumberPlane(x_range=[-2, 2], y_range=[-2, 2], background_line_style={"stroke_opacity": 0})
        plane.to_edge(RIGHT, buff=2.0).shift(DOWN * 0.5)

        # 绘制一条曲线 (等高线片段) - 使用椭圆的一部分
        # x = 1.5 cos(t), y = 1.0 sin(t)
        curve = ParametricFunction(
            lambda t: np.array([1.5 * np.cos(t), 1.0 * np.sin(t), 0]),
            t_range=[0, PI/2 + 0.2],
            color=WHITE
        ).move_to(plane.get_center())

        curve_label = MathTex("f(x,y)=c", font_size=24).next_to(curve, UP, buff=0.1)

        # 选取曲线上的一点 P (t = PI/4)
        t_val = PI/4
        # 计算点的位置 (需要基于 curve 的位置)
        local_p = np.array([1.5 * np.cos(t_val), 1.0 * np.sin(t_val), 0])
        p_point = curve.get_center() + local_p # 调整到绝对坐标

        dot = Dot(p_point, color=YELLOW)
        dot_label = Text("P", font_size=20, font="AR PL UKai CN").next_to(dot, DL, buff=0.1)

        # 切向量 r'(t) = (-1.5 sin(t), 1.0 cos(t))
        tan_vec = np.array([-1.5 * np.sin(t_val), 1.0 * np.cos(t_val), 0])
        tan_vec = tan_vec / np.linalg.norm(tan_vec) # 归一化
        arrow_tan = Arrow(start=p_point, end=p_point + tan_vec * 1.2, color=GREEN, buff=0)
        label_tan = MathTex(r"\mathbf{r}'(t)", font_size=24, color=GREEN).next_to(arrow_tan.get_end(), LEFT, buff=0.1)

        # 梯度向量 (法向量) - 垂直于切向量
        # 椭圆法向量 (2x/a^2, 2y/b^2) -> (2*1.5cos/2.25, 2*1.sin/1)
        grad_vec = np.array([2 * (1.5 * np.cos(t_val)) / 2.25, 2 * (1.0 * np.sin(t_val)), 0])
        grad_vec = grad_vec / np.linalg.norm(grad_vec) # 归一化
        arrow_grad = Arrow(start=p_point, end=p_point + grad_vec * 1.2, color=RED, buff=0)
        label_grad = MathTex(r"\nabla f", font_size=24, color=RED).next_to(arrow_grad.get_end(), UP, buff=0.1)

        # 直角标记
        right_angle = RightAngle(arrow_tan, arrow_grad, length=0.25, quadrant=(-1, -1))

        # 5. 动画流程控制

        # 阶段 1: 展示等高线和公式
        self.play(
            FadeIn(step1_text),
            Write(step1_math),
            Create(curve),
            Write(curve_label),
            run_time=2
        )

        # 阶段 2: 展示点和切线，以及求导过程
        self.play(
            FadeIn(step2_text),
            Write(step2_math),
            FadeIn(dot),
            FadeIn(dot_label),
            GrowArrow(arrow_tan),
            Write(label_tan),
            run_time=2
        )

        # 阶段 3: 推导结论，展示梯度
        self.play(
            FadeIn(step3_text),
            TransformMatchingTex(step2_math.copy(), step3_math), # 变换效果
            GrowArrow(arrow_grad),
            Write(label_grad),
            run_time=2
        )

        # 阶段 4: 强调正交关系
        rect = SurroundingRectangle(step3_math, color=RED, buff=0.1)
        self.play(
            Create(right_angle),
            Create(rect),
            Indicate(step3_math),
            run_time=1.5
        )
