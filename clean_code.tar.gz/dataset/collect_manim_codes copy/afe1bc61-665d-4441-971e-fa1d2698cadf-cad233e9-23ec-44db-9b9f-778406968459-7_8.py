from manim import *

class ProjectManagementConcepts(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("检查点、里程碑与基线",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("31", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 创建时间轴
        timeline = Arrow(start=LEFT * 5, end=RIGHT * 5, color=GREY)
        timeline_label = Text("项目时间轴", font="AR PL UKai CN", font_size=20, color=GREY)
        timeline_label.next_to(timeline, DOWN, buff=0.1).to_edge(RIGHT)

        self.play(Create(timeline), FadeIn(timeline_label), run_time=1.0)

        # 3. 定义可视化元素

        # 概念1: 检查点 (Checkpoints) - 用小的点表示定期采样
        cp_dots = VGroup(
            Dot(point=LEFT*3, color=BLUE),
            Dot(point=LEFT*1.5, color=BLUE),
            Dot(point=ORIGIN, color=BLUE)
        )
        cp_label = Text("检查点", font="AR PL UKai CN", font_size=24, color=BLUE)
        cp_label.next_to(cp_dots[0], UP, buff=0.2)

        cp_desc = Text("规定间隔内的"采样"点", font="AR PL UKai CN", font_size=20, color=BLUE_A)
        cp_desc.next_to(timeline, DOWN, buff=1.5).to_edge(LEFT, buff=1)

        # 概念2: 里程碑 (Milestone) - 用菱形表示重要事件
        milestone_shape = Square(side_length=0.4, color=YELLOW, fill_opacity=1).rotate(PI/4)
        milestone_shape.move_to(RIGHT * 2)

        ms_label = Text("里程碑", font="AR PL UKai CN", font_size=24, color=YELLOW)
        ms_label.next_to(milestone_shape, UP, buff=0.2)

        ms_desc = Text("重要时点或事件", font="AR PL UKai CN", font_size=20, color=YELLOW_A)
        ms_desc.next_to(cp_desc, DOWN, buff=0.3, aligned_edge=LEFT)

        # 概念3: 基线 (Baseline) - 用垂直线和框表示受控状态
        baseline_line = Line(UP, DOWN, color=RED).move_to(RIGHT * 4)
        baseline_line.scale(0.5).shift(UP*0.2)
        baseline_box = SurroundingRectangle(baseline_line, color=RED, buff=0.1)

        bl_group = VGroup(baseline_line, baseline_box)

        bl_label = Text("基线", font="AR PL UKai CN", font_size=24, color=RED)
        bl_label.next_to(bl_group, UP, buff=0.2)

        bl_desc = Text("正式评审后的受控状态", font="AR PL UKai CN", font_size=20, color=RED_A)
        bl_desc.next_to(ms_desc, DOWN, buff=0.3, aligned_edge=LEFT)

        # 4. 动画展示逻辑

        # 展示检查点
        self.play(
            FadeIn(cp_dots, shift=DOWN),
            Write(cp_label),
            run_time=0.8
        )
        self.play(Write(cp_desc), run_time=0.8)

        # 展示里程碑
        self.play(
            GrowFromCenter(milestone_shape),
            Write(ms_label),
            run_time=0.8
        )
        self.play(Write(ms_desc), run_time=0.8)

        # 展示基线
        self.play(
            Create(bl_group),
            Write(bl_label),
            run_time=0.8
        )
        self.play(Write(bl_desc), run_time=0.8)

        # 5. 最后的强调 (用矩形框住下方的定义区域)
        desc_group = VGroup(cp_desc, ms_desc, bl_desc)
        highlight_rect = SurroundingRectangle(desc_group, color=WHITE, buff=0.2, stroke_width=1)

        self.play(Create(highlight_rect), run_time=1)
