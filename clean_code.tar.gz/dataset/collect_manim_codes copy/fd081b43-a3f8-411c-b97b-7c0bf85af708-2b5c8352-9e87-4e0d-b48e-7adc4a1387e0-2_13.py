from manim import *

class EquilibriumIncomeDerivation(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("均衡收入的推导",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("30", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局初始化
        # 使用 VGroup 进行垂直排列,确保不遮挡

        # 第一部分:代入
        text_step1 = Text("将消费函数代入均衡条件:", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        eq_step1 = MathTex(r"Y = C_0 + c(Y - T) + I + G", font_size=32)
        group_step1 = VGroup(text_step1, eq_step1).arrange(DOWN, buff=0.2)

        # 第二部分:整理推导
        text_step2 = Text("整理得:", font="AR PL UKai CN", font_size=24, color=BLUE_A)

        # 逐步推导的公式
        eq_process_1 = MathTex(r"Y = C_0 + cY - cT + I + G", font_size=28)
        eq_process_2 = MathTex(r"Y - cY = C_0 - cT + I + G", font_size=28)
        eq_process_3 = MathTex(r"Y(1 - c) = C_0 - cT + I + G", font_size=28)

        group_process = VGroup(eq_process_1, eq_process_2, eq_process_3).arrange(DOWN, buff=0.15)
        group_step2 = VGroup(text_step2, group_process).arrange(DOWN, buff=0.2)

        # 第三部分:最终结果
        text_step3 = Text("因此,均衡收入为:", font="AR PL UKai CN", font_size=24, color=YELLOW)
        eq_final = MathTex(r"Y = \frac{1}{1-c}(C_0 - cT + I + G)", font_size=38, color=YELLOW)

        # 结果强调框
        result_box = SurroundingRectangle(eq_final, color=ORANGE, buff=0.15)

        group_step3 = VGroup(text_step3, eq_final, result_box).arrange(DOWN, buff=0.2)

        # 整体布局:将三组内容垂直排列
        main_content = VGroup(group_step1, group_step2, group_step3).arrange(DOWN, buff=0.5)
        main_content.next_to(title_line, DOWN, buff=0.5)

        # 3. 动画演示流程

        # 展示第一步:代入
        self.play(FadeIn(text_step1))
        self.play(Write(eq_step1))

        # 展示第二步:整理过程
        self.play(FadeIn(text_step2))
        self.play(
            AnimationGroup(
                FadeIn(eq_process_1, shift=UP*0.1),
                FadeIn(eq_process_2, shift=UP*0.1),
                FadeIn(eq_process_3, shift=UP*0.1),
                lag_ratio=0.8
            )
        )

        # 展示第三步:结论
        self.play(FadeIn(text_step3))
        self.play(Write(eq_final))
        self.play(Create(result_box))
