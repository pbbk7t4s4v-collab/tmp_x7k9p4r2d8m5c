from manim import *

class TransportEquationScene(Scene):
    def construct(self):

        # 1. Title Setup (Standard Template)
        title = Text("Derivation of Transport Equations: Basic Quantities",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Visual Representation (Left Side)
        # Domain Omega
        omega_shape = Ellipse(width=5, height=4, color=BLUE_C, fill_opacity=0.1)
        omega_label = MathTex(r"\Omega", color=BLUE_C).move_to(omega_shape.get_corner(UL) + RIGHT*1.5 + DOWN*0.5)

        # Subdomain D
        d_shape = Circle(radius=1.2, color=YELLOW, fill_opacity=0.2).move_to(omega_shape.get_center() + RIGHT*0.5 + DOWN*0.2)
        d_label = MathTex("D", color=YELLOW).move_to(d_shape.get_center())

        # Vectors (Normal and Flux)
        # Point on boundary
        p_bound = d_shape.get_right()

        # Normal vector n (outward)
        n_arrow = Arrow(start=p_bound, end=p_bound + RIGHT*0.8, color=RED, buff=0, max_tip_length_to_length_ratio=0.3)
        n_label = MathTex(r"\vec{n}", color=RED, font_size=28).next_to(n_arrow, UP, buff=0.05)

        # Flux vector F (transportation) - arbitrary direction
        f_arrow = Arrow(start=p_bound + UL*0.5, end=p_bound + DR*0.5, color=GREEN, buff=0, max_tip_length_to_length_ratio=0.3)
        f_label = MathTex(r"\vec{F}", color=GREEN, font_size=28).next_to(f_arrow.get_start(), UP, buff=0.05)

        graphics_group = VGroup(omega_shape, omega_label, d_shape, d_label, n_arrow, n_label, f_arrow, f_label)
        graphics_group.scale(0.8).to_edge(LEFT, buff=1.0).shift(DOWN*0.5)

        # 3. Mathematical Definitions (Right Side)
        # Definitions
        def_u = MathTex(r"u(t, x): \text{Density distribution}", font_size=30)
        def_F = MathTex(r"\vec{F}: \text{Flux vector}", font_size=30)
        defs = VGroup(def_u, def_F).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # Quantity 1: Increase in D
        q1_title = Text("Quantity Increase in D:", font_size=24, color=YELLOW)
        q1_eq = MathTex(
            r"Q_1 = \int_D (u(t_2, x) - u(t_1, x)) \, dx",
            font_size=32
        )

        # Quantity 2: Inflow across boundary
        q2_title = Text("Quantity Flowing into D:", font_size=24, color=GREEN)
        # Using t_1 to t_2 for logical consistency with standard derivation
        q2_eq = MathTex(
            r"Q_2 = \int_{t_1}^{t_2} \int_{\partial D} \vec{F} \cdot (-\vec{n}) \, ds \, dt",
            font_size=32
        )

        formulas_group = VGroup(defs, q1_title, q1_eq, q2_title, q2_eq).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        formulas_group.next_to(graphics_group, RIGHT, buff=1.0)

        # Highlight box
        box = SurroundingRectangle(formulas_group, color=WHITE, buff=0.2, stroke_width=1)

        # 4. Animation Sequence
        # Show Graphics
        self.play(
            Create(omega_shape), Write(omega_label),
            Create(d_shape), Write(d_label),
            run_time=2
        )
        self.play(
            GrowArrow(n_arrow), Write(n_label),
            GrowArrow(f_arrow), Write(f_label),
            run_time=1.5
        )

        # Show Definitions
        self.play(FadeIn(defs, shift=LEFT), run_time=1)

        # Show Q1
        self.play(
            FadeIn(q1_title, shift=UP),
            Write(q1_eq),
            run_time=1.5
        )

        # Show Q2
        self.play(
            FadeIn(q2_title, shift=UP),
            Write(q2_eq),
            run_time=1.5
        )

        # Highlight
        self.play(Create(box), run_time=1)
