from manim import *

class CriticalAngleDerivation(Scene):
    def construct(self):

        # 1. 标题设置 (严格遵守模板)
        title = Text("临界角公式推导：折射率比值法",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("27", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局规划：左侧为数学推导,右侧为几何示意图
        # 右侧：几何示意图构建
        diagram_origin = RIGHT * 3.5 + DOWN * 0.5

        # 介质分界线
        interface = Line(LEFT*3, RIGHT*3, color=BLUE_C).move_to(diagram_origin)
        # 法线
        normal = DashedLine(UP*2, DOWN*2, color=GRAY).move_to(diagram_origin)

        # 介质标记
        n1_text = MathTex("n_1", color=BLUE_A).next_to(interface, DOWN, buff=0.5).shift(LEFT*2)
        n2_text = MathTex("n_2", color=TEAL_A).next_to(interface, UP, buff=0.5).shift(LEFT*2)
        medium_note = Text("光密 (n1 > n2) -> 光疏", font="AR PL UKai CN", font_size=20, color=GRAY)
        medium_note.next_to(interface, DOWN, buff=1.5)

        # 光线 (入射角为临界角C，折射角为90度)
        # 入射光线
        incident_ray = Line(start=diagram_origin + DL * 2, end=diagram_origin, color=YELLOW)
        # 折射光线 (沿界面)
        refracted_ray = Line(start=diagram_origin, end=diagram_origin + RIGHT * 2.5, color=RED, stroke_width=4)

        # 角度标记
        angle_c = Angle(normal, incident_ray, radius=0.5, other_angle=True, quadrant=(3,4))
        label_c = MathTex("C", color=YELLOW).next_to(angle_c, DL, buff=0.1)

        right_angle = RightAngle(normal, refracted_ray, length=0.3, quadrant=(1,1))
        label_90 = MathTex("90^\\circ", font_size=24).next_to(right_angle, UR, buff=0.1)

        diagram_group = VGroup(interface, normal, n1_text, n2_text, medium_note,
                             incident_ray, refracted_ray, angle_c, label_c, right_angle, label_90)

        # 左侧：数学推导构建
        step1_text = Text("1. 斯涅尔定律 (Snell's Law)", font="AR PL UKai CN", font_size=24, color=BLUE)
        step1_math = MathTex(r"n_1 \sin \theta_1 = n_2 \sin \theta_2")

        step2_text = Text("2. 临界条件", font="AR PL UKai CN", font_size=24, color=BLUE)
        step2_cond = MathTex(r"\theta_1 = C, \quad \theta_2 = 90^\circ")

        step3_text = Text("3. 代入计算", font="AR PL UKai CN", font_size=24, color=BLUE)
        step3_math = MathTex(r"n_1 \sin C = n_2 \sin 90^\circ")
        step3_simp = MathTex(r"n_1 \sin C = n_2 \cdot 1")

        result_math = MathTex(r"\sin C = \frac{n_2}{n_1}", color=YELLOW)
        result_box = SurroundingRectangle(result_math, color=YELLOW, buff=0.2)

        # 组合左侧元素
        math_group = VGroup(
            step1_text, step1_math,
            step2_text, step2_cond,
            step3_text, step3_math, step3_simp,
            result_math, result_box
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.25).to_edge(LEFT, buff=1)

        # 3. 动画流程

        # 第一步：显示几何背景和斯涅尔定律
        self.play(
            FadeIn(interface), FadeIn(normal),
            Write(n1_text), Write(n2_text),
            FadeIn(medium_note),
            Write(step1_text), Write(step1_math),
            run_time=2
        )

        # 第二步：显示光线和临界条件
        self.play(
            Create(incident_ray),
            Create(angle_c), Write(label_c),
            Create(refracted_ray),
            Create(right_angle), Write(label_90),
            Write(step2_text), Write(step2_cond),
            run_time=2.5
        )

        # 第三步：推导过程
        self.play(
            Write(step3_text),
            TransformFromCopy(step1_math, step3_math),
            run_time=1.5
        )

        self.play(
            TransformMatchingTex(step3_math, step3_simp),
            run_time=1
        )

        # 第四步：得出结论
        self.play(
            TransformMatchingTex(step3_simp, result_math),
            Create(result_box),
            run_time=1.5
        )
