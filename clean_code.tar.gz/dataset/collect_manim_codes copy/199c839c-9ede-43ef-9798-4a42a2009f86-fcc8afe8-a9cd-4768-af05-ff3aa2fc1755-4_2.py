from manim import *

class MethodOfExhaustion(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("矩形逼近法：利用规则图形估算面积",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 绘制坐标系和曲线
        # 将图形整体向左移动，为右侧文字留出空间
        axes = Axes(
            x_range=[0, 5, 1],
            y_range=[0, 5, 1],
            x_length=5,
            y_length=4,
            axis_config={"include_tip": True, "tip_shape": StealthTip}
        ).shift(DOWN * 0.5 + LEFT * 2.5)

        labels = axes.get_axis_labels(x_label="x", y_label="y")

        # 定义曲线函数 f(x) = 0.2x^2 + 1
        def func_formula(x):
            return 0.2 * (x ** 2) + 1

        curve = axes.plot(func_formula, x_range=[0, 4.5], color=BLUE, stroke_width=3)

        # 绘制坐标系和曲线
        self.play(Create(axes), Write(labels), run_time=1.5)
        self.play(Create(curve), run_time=1.0)

        # 3. 第一阶段：粗略分割 (宽矩形)
        # 使用黎曼和矩形可视化
        rects_coarse = axes.get_riemann_rectangles(
            curve,
            x_range=[0, 4.5],
            dx=1.5,
            input_sample_type="left",
            stroke_width=1.5,
            stroke_color=WHITE,
            fill_opacity=0.5,
            color=YELLOW
        )

        # 说明文字1
        desc_text1 = Text("将图形分割为\n少数宽矩形", font="AR PL UKai CN", font_size=24)
        desc_text1.next_to(axes, RIGHT, buff=1.0).shift(UP * 1)

        self.play(
            FadeIn(rects_coarse),
            Write(desc_text1)
        )

        # 4. 第二阶段：精细分割 (窄矩形)
        rects_fine = axes.get_riemann_rectangles(
            curve,
            x_range=[0, 4.5],
            dx=0.25, # 更小的宽度
            input_sample_type="left",
            stroke_width=0.5,
            stroke_color=WHITE,
            fill_opacity=0.7,
            color=GREEN # 颜色变化表示更加精确
        )

        # 说明文字2
        desc_text2 = Text("分割越细密\n面积越精确", font="AR PL UKai CN", font_size=24, color=GREEN)
        desc_text2.move_to(desc_text1.get_center())

        # 强调框
        box = SurroundingRectangle(desc_text2, color=YELLOW, buff=0.2)

        # 变换动画：粗矩形 -> 细矩形，文字更新
        self.play(
            ReplacementTransform(rects_coarse, rects_fine),
            ReplacementTransform(desc_text1, desc_text2),
            Create(box),
            run_time=2.0
        )

        # 5. 总结视觉元素：显示误差减少
        # 在右侧显示简单的总结
        summary = Text("矩形组合 -> 原图形", font="AR PL UKai CN", font_size=20, color=GRAY)
        summary.next_to(box, DOWN, buff=0.5)
        self.play(FadeIn(summary))
