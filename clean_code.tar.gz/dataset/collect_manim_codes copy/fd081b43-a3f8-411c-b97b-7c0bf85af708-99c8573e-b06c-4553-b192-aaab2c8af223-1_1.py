from manim import *

class AreaAccumulation(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Area Accumulation: Geometric Interpretation",
                    font_size=34,  # 增大字号
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Layout and Coordinate System
        # Create axes for the graph
        ax = Axes(
            x_range=[0, 6, 1],
            y_range=[0, 5, 1],
            x_length=7,
            y_length=4,
            axis_config={"include_tip": True, "color": GREY}
        ).to_edge(DOWN, buff=0.8).shift(LEFT * 0.5)

        labels = ax.get_axis_labels(x_label="t", y_label="f(t)")

        # Define the function f(t)
        def func(t):
            return 0.15 * (t - 1)**2 + 1

        curve = ax.plot(func, color=BLUE, x_range=[0, 5.5])
        curve_label = MathTex("f(t)", color=BLUE, font_size=24).next_to(curve, UP, buff=0.1)

        # 3. Mathematical Concept Display
        # Formula A(x) = integral
        formula = MathTex(
            r"A(x) = \int_a^x f(t) \, dt",
            font_size=38
        )
        formula.to_edge(RIGHT, buff=1.5).shift(UP * 0.5)

        desc = Text("Area accumulates as x moves", font_size=24, color=GREY_A)
        desc.next_to(formula, DOWN, buff=0.3)

        formula_box = SurroundingRectangle(formula, color=YELLOW, buff=0.2)

        # 4. Animation Elements
        start_x = 1.0
        end_x = 5.0
        x_tracker = ValueTracker(start_x)

        # Dynamic area under the curve
        area = always_redraw(lambda: ax.get_area(
            curve,
            x_range=[start_x, x_tracker.get_value()],
            color=BLUE_E,
            opacity=0.6
        ))

        # Dynamic vertical line at current x
        v_line = always_redraw(lambda: ax.get_vertical_line(
            ax.i2gp(x_tracker.get_value(), curve),
            color=YELLOW
        ))

        # Label for 'x'
        x_label = always_redraw(lambda: MathTex("x", color=YELLOW, font_size=28)
                                .next_to(v_line, DOWN))

        # Static label for start point 'a'
        a_line = ax.get_vertical_line(ax.i2gp(start_x, curve), color=WHITE)
        a_label = MathTex("a", font_size=28).next_to(a_line, DOWN)

        # 5. Play Animations
        # Draw static graph elements
        self.play(Create(ax), FadeIn(labels), run_time=1.0)
        self.play(Create(curve), FadeIn(curve_label), run_time=1.0)

        # Show formula and definition
        self.play(Write(formula), Create(formula_box), FadeIn(desc), run_time=1.0)

        # Setup accumulation start
        self.play(Create(a_line), Write(a_label), FadeIn(area), FadeIn(v_line), Write(x_label))

        # Animate the integration (accumulation)
        self.play(
            x_tracker.animate.set_value(end_x),
            run_time=4.0,
            rate_func=linear
        )
