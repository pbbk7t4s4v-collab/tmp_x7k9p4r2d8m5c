from manim import *

class PythonVariablesScene(Scene):
    def construct(self):

        # --- 1. 标题部分 (标准模板) ---
        title = Text("Python变量：命名规则与本质",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- 2. 变量命名规则 (左侧内容) ---
        # 使用VGroup布局,避免BulletedList的潜在问题
        rule_header = Text("命名规则：", font_size=28, font="AR PL UKai CN", color=BLUE)
        rule_1 = Text("• 只能包含字母、数字、下划线", font_size=24, font="AR PL UKai CN", color=WHITE)
        rule_2 = Text("• 不能以数字开头", font_size=24, font="AR PL UKai CN", color=WHITE)
        rule_3 = Text("• 避免使用Python关键字", font_size=24, font="AR PL UKai CN", color=WHITE)

        rules_group = VGroup(rule_header, rule_1, rule_2, rule_3).arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        rules_group.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 示例展示
        example_good = Text("√ user_name (正确)", font_size=22, font="AR PL UKai CN", color=GREEN)
        example_bad = Text("× 1_user (错误)", font_size=22, font="AR PL UKai CN", color=RED)
        examples = VGroup(example_good, example_bad).arrange(RIGHT, buff=0.5).next_to(rules_group, DOWN, buff=0.5)

        # 显示规则部分
        self.play(FadeIn(rules_group, shift=RIGHT))
        self.play(Write(examples))

        # --- 3. 变量的本质：标签 (右侧可视化) ---
        # 概念标题
        concept_title = Text("变量本质：标签", font_size=28, font="AR PL UKai CN", color=YELLOW)
        concept_title.to_edge(RIGHT, buff=2).align_to(rule_header, UP)

        # 内存对象 (盒子)
        memory_val = Text('"Hello"', font_size=24, font="AR PL UKai CN", color=BLACK)
        memory_box = SurroundingRectangle(memory_val, color=WHITE, fill_color=WHITE, fill_opacity=0.8, corner_radius=0.1)
        memory_group = VGroup(memory_box, memory_val).next_to(concept_title, DOWN, buff=1.5)

        # 内存地址标签 (模拟)
        memory_addr = Text("内存地址: 0x7f...", font_size=16, font="AR PL UKai CN", color=ORANGE).next_to(memory_group, DOWN, buff=0.1)

        # 变量名 (标签)
        var_name = Text("message", font_size=24, font="AR PL UKai CN", color=WHITE)
        var_tag = SurroundingRectangle(var_name, color=ORANGE, buff=0.1)
        var_group = VGroup(var_tag, var_name).next_to(memory_group, UP, buff=1.5).shift(LEFT * 1 + DOWN * 1)

        # 连接线 (引用)
        arrow = Arrow(start=var_group.get_bottom(), end=memory_group.get_top(), color=ORANGE, buff=0.1)

        # 底部代码说明
        code_text = Text('message = "Hello"', font_size=24, font="AR PL UKai CN", color=GRAY_B)
        code_text.next_to(arrow, RIGHT, buff=0.5)

        # 动画展示变量赋值过程
        self.play(FadeIn(concept_title))

        # 1. 先生成数据对象
        self.play(
            FadeIn(memory_group, scale=0.5),
            FadeIn(memory_addr),
            run_time=0.8
        )

        # 2. 生成变量标签
        self.play(FadeIn(var_group, shift=DOWN), run_time=0.5)

        # 3. 建立引用关系 (贴标签)
        self.play(
            GrowArrow(arrow),
            Write(code_text),
            run_time=0.8
        )
