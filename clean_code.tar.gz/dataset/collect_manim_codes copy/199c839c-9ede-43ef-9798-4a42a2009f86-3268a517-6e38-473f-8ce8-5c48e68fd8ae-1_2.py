from manim import *

class GreekRationalMan(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("古希腊哲学的理性人",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局设计
        # ---------------------------------------------------------

        # 定义通用字体配置
        text_font = "AR PL UKai CN"
        text_size = 26

        # --- 柏拉图部分 (Plato) ---
        plato_header = Text("柏拉图 (Plato)", font=text_font, font_size=30, color=BLUE)

        plato_p1 = Text("• 人的本质归结为“理性灵魂”", font=text_font, font_size=text_size)
        plato_p2 = Text("• 理念世界=永恒，肉体=牢笼", font=text_font, font_size=text_size)

        # 组合柏拉图的内容
        plato_group = VGroup(plato_header, plato_p1, plato_p2).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # 添加边框强调
        plato_box = SurroundingRectangle(plato_group, color=BLUE, buff=0.2)

        # 整体组合
        plato_block = VGroup(plato_box, plato_group)

        # --- 亚里士多德部分 (Aristotle) ---
        ari_header = Text("亚里士多德 (Aristotle)", font=text_font, font_size=30, color=GREEN)

        ari_p1 = Text("• 定义人是“理性的动物”", font=text_font, font_size=text_size)
        ari_p2 = Text("• 强调理性能力 > 社会实践", font=text_font, font_size=text_size)

        # 组合亚里士多德的内容
        ari_group = VGroup(ari_header, ari_p1, ari_p2).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # 添加边框强调
        ari_box = SurroundingRectangle(ari_group, color=GREEN, buff=0.2)

        # 整体组合
        ari_block = VGroup(ari_box, ari_group)

        # ---------------------------------------------------------
        # 3. 整体排版与位置调整
        # ---------------------------------------------------------

        # 将两块内容垂直排列，并居中显示
        content_group = VGroup(plato_block, ari_block).arrange(DOWN, buff=0.8)
        content_group.next_to(title_line, DOWN, buff=0.5)

        # ---------------------------------------------------------
        # 4. 动画展示 (控制时间在15秒以内)
        # ---------------------------------------------------------

        # 展示柏拉图部分
        self.play(FadeIn(plato_block, shift=UP), run_time=1.5)

        # 强调柏拉图的核心词
        self.play(Indicate(plato_p1[7:11], color=YELLOW)) # 强调"理性灵魂"

        # 展示亚里士多德部分
        self.play(FadeIn(ari_block, shift=UP), run_time=1.5)

        # 强调亚里士多德的核心词
        self.play(Indicate(ari_p1[5:10], color=YELLOW)) # 强调"理性的动物"

        # 最后的停留
