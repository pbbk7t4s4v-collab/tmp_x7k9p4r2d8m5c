from manim import *

class BMIEssenceAndLimitations(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("BMI的本质：筛查与局限",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心主体：BMI
        bmi_text = Text("BMI", font_size=60, font="AR PL UKai CN", weight=BOLD, color=BLUE)
        bmi_box = SurroundingRectangle(bmi_text, color=BLUE, buff=0.3)
        bmi_group = VGroup(bmi_box, bmi_text).shift(UP * 0.5)

        self.play(FadeIn(bmi_group, shift=DOWN))

        # 3. 左侧：本质（筛查工具）
        # 使用VGroup组合文字和框，确保结构清晰
        essence_label = Text("本质", font_size=24, font="AR PL UKai CN", color=YELLOW)
        essence_content = Text("筛查工具", font_size=32, font="AR PL UKai CN", color=YELLOW)
        essence_group = VGroup(essence_label, essence_content).arrange(DOWN, buff=0.2)
        essence_group.next_to(bmi_group, LEFT, buff=2)

        # 箭头
        arrow_left = Arrow(start=bmi_group.get_left(), end=essence_group.get_right(), color=YELLOW, buff=0.2)

        self.play(
            GrowArrow(arrow_left),
            Write(essence_group)
        )

        # 4. 右侧：缺点（有局限性）
        limit_label = Text("缺点", font_size=24, font="AR PL UKai CN", color=RED)
        limit_content = Text("有局限性", font_size=32, font="AR PL UKai CN", color=RED)
        limit_group = VGroup(limit_label, limit_content).arrange(DOWN, buff=0.2)
        limit_group.next_to(bmi_group, RIGHT, buff=2)

        # 箭头
        arrow_right = Arrow(start=bmi_group.get_right(), end=limit_group.get_left(), color=RED, buff=0.2)

        self.play(
            GrowArrow(arrow_right),
            Write(limit_group)
        )

        # 5. 底部：解决方案（结合其他指标）
        combine_text = Text("需与其他指标结合", font_size=36, font="AR PL UKai CN", color=GREEN)
        combine_rect = SurroundingRectangle(combine_text, color=GREEN, buff=0.2)
        combine_group = VGroup(combine_rect, combine_text)
        combine_group.next_to(bmi_group, DOWN, buff=2.0)

        # 连接线，表示汇总
        line_down = Line(bmi_group.get_bottom(), combine_group.get_top(), color=WHITE)

        # 添加具体的其他指标例子，作为注释显示在连线两侧
        example_text_1 = Text("体脂率", font_size=20, font="AR PL UKai CN", color=GRAY).next_to(line_down, LEFT, buff=0.2)
        example_text_2 = Text("腰围", font_size=20, font="AR PL UKai CN", color=GRAY).next_to(line_down, RIGHT, buff=0.2)

        self.play(
            Create(line_down),
            FadeIn(example_text_1),
            FadeIn(example_text_2)
        )

        self.play(
            Write(combine_text),
            Create(combine_rect)
        )

        # 6. 最后的强调动画
        self.play(
            Indicate(combine_text, color=GREEN_A, scale_factor=1.1)
        )
