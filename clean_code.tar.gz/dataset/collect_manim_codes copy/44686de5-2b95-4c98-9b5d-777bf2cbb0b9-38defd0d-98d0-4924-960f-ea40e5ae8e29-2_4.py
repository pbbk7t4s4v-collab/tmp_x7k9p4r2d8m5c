from manim import *

class SeriesRemainderConcept(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("级数余项的概念",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 定义收敛级数 S
        # 使用 Text 和 MathTex 组合,避免 LaTeX 编译中文问题
        label_series = Text("收敛级数:", font="AR PL UKai CN", font_size=28).move_to(UP * 2 + LEFT * 2)
        math_series = MathTex(r"\sum_{n=1}^{\infty} u_n = S", font_size=36).next_to(label_series, RIGHT)

        group_series = VGroup(label_series, math_series)
        group_series.move_to(UP * 2) # 整体居中上方

        self.play(FadeIn(group_series))

        # 3. 可视化展示：整体与部分
        # 创建代表总和 S 的长条
        bar_total_width = 8
        bar_height = 0.8

        # S_n (部分和) 的部分 - 蓝色
        sn_width = 5.5
        rect_sn = Rectangle(width=sn_width, height=bar_height, color=BLUE, fill_opacity=0.6)

        # R_n (余项) 的部分 - 红色
        rn_width = bar_total_width - sn_width
        rect_rn = Rectangle(width=rn_width, height=bar_height, color=RED, fill_opacity=0.6)

        # 组合长条
        bar_group = VGroup(rect_sn, rect_rn).arrange(RIGHT, buff=0)
        bar_group.move_to(ORIGIN) # 放置在屏幕中央

        # 标签 S_n
        brace_sn = Brace(rect_sn, DOWN)
        label_sn = MathTex(r"S_n = \sum_{k=1}^{n} u_k", font_size=32).next_to(brace_sn, DOWN)
        text_sn_desc = Text("部分和 (近似值)", font="AR PL UKai CN", font_size=24, color=BLUE).next_to(label_sn, DOWN, buff=0.1)

        # 标签 R_n
        brace_rn = Brace(rect_rn, DOWN)
        label_rn = MathTex(r"R_n = \sum_{k=n+1}^{\infty} u_k", font_size=32).next_to(brace_rn, DOWN)
        text_rn_desc = Text("余项 (误差)", font="AR PL UKai CN", font_size=24, color=RED).next_to(label_rn, DOWN, buff=0.1)

        # 总和 S 的标签 (上方)
        brace_total = Brace(bar_group, UP)
        label_total = MathTex("S", font_size=36).next_to(brace_total, UP)

        # 动画流程
        # 显示总和 S
        self.play(
            GrowFromCenter(bar_group),
            FadeIn(brace_total),
            Write(label_total)
        )

        # 分割展示 S_n
        self.play(
            rect_sn.animate.set_fill(BLUE, opacity=0.8),
            FadeIn(brace_sn),
            Write(label_sn),
            FadeIn(text_sn_desc)
        )

        # 强调展示 R_n
        self.play(
            rect_rn.animate.set_fill(RED, opacity=0.8),
            FadeIn(brace_rn),
            Write(label_rn),
            FadeIn(text_rn_desc)
        )

        # 4. 结论与强调
        # 强调框选住 R_n 及其描述
        rn_group = VGroup(rect_rn, brace_rn, label_rn, text_rn_desc)
        surround_rect = SurroundingRectangle(rn_group, color=YELLOW, buff=0.2)

        final_text = Text("余项表示用部分和近似时的误差", font="AR PL UKai CN", font_size=30, color=YELLOW)
        final_text.next_to(surround_rect, DOWN, buff=0.3)
        # 确保文字不超出下边界
        if final_text.get_bottom()[1] < -3.5:
             final_text.move_to(DOWN * 3.5)

        self.play(
            Create(surround_rect),
            Write(final_text)
        )
