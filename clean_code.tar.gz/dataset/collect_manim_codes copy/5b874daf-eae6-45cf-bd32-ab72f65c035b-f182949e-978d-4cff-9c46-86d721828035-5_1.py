from manim import *

class OtherFormsOfBinaryTrees(Scene):
    def construct(self):

        # 1. 创建标题
        title = Text("二叉树的其他形式",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("23", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 定义三个区域的中心位置
        pos1 = LEFT * 4.5
        pos2 = ORIGIN
        pos3 = RIGHT * 4.5

        # --- 第一部分: 满二叉树 ---
        full_tree_title = Text("满二叉树", font="AR PL UKai CN", font_size=28, weight=BOLD).move_to(pos1 + UP * 1.5)
        self.play(Write(full_tree_title), run_time=1)

        # 满二叉树的可视化
        f_nodes = VGroup(*[Circle(radius=0.25, color=BLUE, fill_opacity=0.8, stroke_color=BLUE_A) for _ in range(7)])
        f_nodes[0].move_to(full_tree_title.get_center() + DOWN * 1.2)
        f_nodes[1].move_to(f_nodes[0].get_center() + DOWN * 1.1 + LEFT * 1.2)
        f_nodes[2].move_to(f_nodes[0].get_center() + DOWN * 1.1 + RIGHT * 1.2)
        f_nodes[3].move_to(f_nodes[1].get_center() + DOWN * 1.1 + LEFT * 0.7)
        f_nodes[4].move_to(f_nodes[1].get_center() + DOWN * 1.1 + RIGHT * 0.7)
        f_nodes[5].move_to(f_nodes[2].get_center() + DOWN * 1.1 + LEFT * 0.7)
        f_nodes[6].move_to(f_nodes[2].get_center() + DOWN * 1.1 + RIGHT * 0.7)

        f_edges = VGroup(
            Line(f_nodes[0], f_nodes[1]), Line(f_nodes[0], f_nodes[2]),
            Line(f_nodes[1], f_nodes[3]), Line(f_nodes[1], f_nodes[4]),
            Line(f_nodes[2], f_nodes[5]), Line(f_nodes[2], f_nodes[6])
        )
        full_tree_visual = VGroup(f_edges, f_nodes)
        self.play(Create(full_tree_visual), run_time=1.2)

        full_tree_desc = Text("所有非叶子节点\n都具有两个子节点", font="AR PL UKai CN", font_size=24, line_spacing=0.9)
        full_tree_desc.next_to(full_tree_visual, DOWN, buff=0.3)
        self.play(Write(full_tree_desc), run_time=1)

        # --- 第二部分: 完全二叉树 ---
        complete_tree_title = Text("完全二叉树", font="AR PL UKai CN", font_size=28, weight=BOLD).move_to(pos2 + UP * 1.5)
        self.play(Write(complete_tree_title), run_time=1)

        # 完全二叉树的可视化
        c_nodes_coords = [
            complete_tree_title.get_center() + DOWN * 1.2,
            complete_tree_title.get_center() + DOWN * 2.3 + LEFT * 1.2,
            complete_tree_title.get_center() + DOWN * 2.3 + RIGHT * 1.2,
            complete_tree_title.get_center() + DOWN * 3.4 + LEFT * 1.9,
            complete_tree_title.get_center() + DOWN * 3.4 + LEFT * 0.5,
        ]
        c_nodes = VGroup(*[Circle(radius=0.25, color=GREEN, fill_opacity=0.8, stroke_color=GREEN_A).move_to(coord) for coord in c_nodes_coords])
        c_edges = VGroup(
            Line(c_nodes[0], c_nodes[1]), Line(c_nodes[0], c_nodes[2]),
            Line(c_nodes[1], c_nodes[3]), Line(c_nodes[1], c_nodes[4]),
        )
        complete_tree_visual = VGroup(c_edges, c_nodes)
        self.play(Create(complete_tree_visual), run_time=1.2)

        complete_tree_desc = Text("除最底层外是满的\n且最底层节点靠左排列", font="AR PL UKai CN", font_size=24, line_spacing=0.9)
        complete_tree_desc.next_to(complete_tree_visual, DOWN, buff=0.3)
        self.play(Write(complete_tree_desc), run_time=1)

        # --- 第三部分: 斜树 ---
        skewed_tree_title = Text("斜树 (Skewed Tree)", font="AR PL UKai CN", font_size=28, weight=BOLD).move_to(pos3 + UP * 1.5)
        self.play(Write(skewed_tree_title), run_time=1)

        # 斜树的可视化 (左斜树)
        s_nodes = VGroup(*[Circle(radius=0.25, color=YELLOW, fill_opacity=0.8, stroke_color=YELLOW_A) for _ in range(4)])
        s_nodes[0].move_to(skewed_tree_title.get_center() + DOWN * 1.0)
        s_nodes[1].move_to(s_nodes[0].get_center() + DOWN * 0.9 + LEFT * 0.9)
        s_nodes[2].move_to(s_nodes[1].get_center() + DOWN * 0.9 + LEFT * 0.9)
        s_nodes[3].move_to(s_nodes[2].get_center() + DOWN * 0.9 + LEFT * 0.9)

        s_edges = VGroup(
            Line(s_nodes[0], s_nodes[1]),
            Line(s_nodes[1], s_nodes[2]),
            Line(s_nodes[2], s_nodes[3])
        )
        skewed_tree_visual = VGroup(s_edges, s_nodes)
        self.play(Create(skewed_tree_visual), run_time=1.2)

        skewed_tree_desc = Text("所有节点都只有\n左子节点(左斜树)", font="AR PL UKai CN", font_size=24, line_spacing=0.9)
        skewed_tree_desc.next_to(skewed_tree_visual, DOWN, buff=0.3)
        self.play(Write(skewed_tree_desc), run_time=1)
