from manim import *

class DiskDeviceAndSwitching(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("磁盘设备：程序切换的硬件基础",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("35", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容可视化设计
        # ---------------------------------------------------------

        # 左侧：磁带（旧技术）
        tape_title = Text("磁带 (Magnetic Tape)", font="AR PL UKai CN", font_size=26, color=GRAY)
        # 简单的磁带示意图：长条矩形代表线性存储
        tape_rect = Rectangle(width=2.5, height=0.6, color=GRAY, fill_opacity=0.2)
        tape_line = Line(tape_rect.get_left(), tape_rect.get_right(), color=GRAY)
        tape_visual = VGroup(tape_rect, tape_line)

        tape_desc = Text("特性：顺序读写\n缺点：难以快速跳转",
                        font="AR PL UKai CN", font_size=22, line_spacing=0.8, color=GRAY_B)

        tape_group = VGroup(tape_title, tape_visual, tape_desc).arrange(DOWN, buff=0.4)

        # 右侧：磁盘（新技术）
        disk_title = Text("磁盘 (Disk)", font="AR PL UKai CN", font_size=26, color=BLUE)
        # 简单的磁盘示意图：圆形代表旋转存储
        disk_circle = Circle(radius=0.6, color=BLUE, fill_opacity=0.2)
        disk_center = Dot(color=BLUE)
        # 模拟磁头臂
        disk_arm = Line(disk_circle.get_top() + UP*0.2, disk_circle.get_center(), color=WHITE)
        disk_visual = VGroup(disk_circle, disk_center, disk_arm)

        disk_desc = Text("特性：随机读写\n优点：毫秒级定位",
                        font="AR PL UKai CN", font_size=22, line_spacing=0.8, color=BLUE_B)

        disk_group = VGroup(disk_title, disk_visual, disk_desc).arrange(DOWN, buff=0.4)

        # 布局：左右并列
        content_row = VGroup(tape_group, disk_group).arrange(RIGHT, buff=2.0).shift(UP * 0.5)

        # ---------------------------------------------------------
        # 3. 核心结论：程序切换
        # ---------------------------------------------------------

        # 箭头指向结论
        arrow = Arrow(start=disk_group.get_bottom(), end=disk_group.get_bottom() + DOWN * 1.5, color=YELLOW, buff=0.2)

        # 结论文本
        result_text = Text("使多道程序切换成为可能", font="AR PL UKai CN", font_size=30, color=YELLOW, weight=BOLD)
        result_text.next_to(arrow, DOWN)

        # 强调框
        result_box = SurroundingRectangle(result_text, color=YELLOW, buff=0.2)

        # ---------------------------------------------------------
        # 4. 动画流程展示
        # ---------------------------------------------------------

        # 步骤1：展示磁带的局限性
        self.play(FadeIn(tape_group, shift=RIGHT), run_time=1.2)

        # 步骤2：展示磁盘的优势
        self.play(FadeIn(disk_group, shift=LEFT), run_time=1.2)

        # 步骤3：导出结论
        self.play(GrowArrow(arrow), run_time=0.8)
        self.play(
            Write(result_text),
            Create(result_box),
            run_time=1.5
        )
