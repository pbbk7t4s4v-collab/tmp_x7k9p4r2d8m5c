from manim import *
import numpy as np

class DomainProperGraphEpigraph(Scene):
    def construct(self):

        # 1. Standard Title Configuration
        title = Text("Definitions: Domain, Proper, Graph, Epigraph",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Left Side: Text Definitions
        # Using VGroup instead of BulletedList for precise control and avoiding LaTeX errors
        def_scale = 0.7

        # Domain
        t_domain_title = Text("Domain (dom):", font_size=24, weight=BOLD, color=BLUE)
        t_domain_math = MathTex(r"\text{dom}(f) = \{x \mid f(x) \text{ is defined}\}", font_size=28)

        # Proper Function
        t_proper_title = Text("Proper Function:", font_size=24, weight=BOLD, color=BLUE)
        t_proper_math = MathTex(r"\text{dom}(f) \neq \emptyset, \quad f(x) > -\infty", font_size=28)

        # Graph
        t_graph_title = Text("Graph:", font_size=24, weight=BOLD, color=BLUE)
        t_graph_math = MathTex(r"\text{graph}(f) = \{(x, f(x))\} \subseteq \mathbb{R}^{n+1}", font_size=28)

        # Epigraph
        t_epi_title = Text("Epigraph (epi):", font_size=24, weight=BOLD, color=BLUE)
        t_epi_math = MathTex(r"\text{epi}(f) = \{(x, t) \mid f(x) \leq t\}", font_size=28)
        t_epi_desc = Text("(Area above the graph)", font_size=20, color=GRAY).next_to(t_epi_math, DOWN, buff=0.1)

        # Grouping text blocks
        text_group = VGroup(
            VGroup(t_domain_title, t_domain_math).arrange(DOWN, aligned_edge=LEFT),
            VGroup(t_proper_title, t_proper_math).arrange(DOWN, aligned_edge=LEFT),
            VGroup(t_graph_title, t_graph_math).arrange(DOWN, aligned_edge=LEFT),
            VGroup(t_epi_title, t_epi_math, t_epi_desc).arrange(DOWN, aligned_edge=LEFT)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.4)

        text_group.to_edge(LEFT, buff=1).shift(UP*0.5)

        # 3. Right Side: Visualization
        # Create Axes
        axes = Axes(
            x_range=[-2.5, 2.5, 1],
            y_range=[-1, 5, 1],
            x_length=5,
            y_length=4.5,
            axis_config={"include_tip": True, "font_size": 20}
        )
        labels = axes.get_axis_labels(x_label="x", y_label="f(x)")

        plot_group = VGroup(axes, labels)
        plot_group.to_edge(RIGHT, buff=1).shift(DOWN*0.5)

        # Function: f(x) = 0.5 * x^2
        func = lambda x: 0.5 * x**2
        graph_curve = axes.plot(func, x_range=[-2.5, 2.5], color=YELLOW, stroke_width=4)

        # Epigraph Shading (Area above curve)
        # Construct points for the polygon: curve points + top corners
        x_vals = np.linspace(-2.5, 2.5, 50)
        curve_points = [axes.c2p(x, func(x)) for x in x_vals]
        # Add top right and top left to close the loop above
        top_right = axes.c2p(2.5, 5)
        top_left = axes.c2p(-2.5, 5)

        epigraph_points = curve_points + [top_right, top_left]
        epigraph_area = Polygon(*epigraph_points, color=GREEN, fill_opacity=0.3, stroke_width=0)

        # Labels for visual
        lbl_graph = Text("Graph", font_size=20, color=YELLOW).next_to(graph_curve.get_point_from_function(1.5), RIGHT, buff=0.1)
        lbl_epi = Text("Epigraph", font_size=24, color=GREEN).move_to(axes.c2p(0, 3))

        # 4. Animation Sequence

        # Show Definitions sequentially
        self.play(FadeIn(text_group[0], shift=RIGHT), run_time=1) # Domain
        self.play(FadeIn(text_group[1], shift=RIGHT), run_time=1) # Proper

        # Show Axes and Graph definition
        self.play(
            Create(axes),
            Write(labels),
            FadeIn(text_group[2], shift=RIGHT)
        )
        self.play(Create(graph_curve), Write(lbl_graph))

        # Highlight Graph relationship
        box_graph = SurroundingRectangle(t_graph_math, color=YELLOW, buff=0.1)
        self.play(Create(box_graph), run_time=0.5)
        self.play(FadeOut(box_graph), run_time=0.5)

        # Show Epigraph definition and visual
        self.play(FadeIn(text_group[3], shift=RIGHT))
        self.play(
            FadeIn(epigraph_area),
            Write(lbl_epi)
        )

        # Highlight Epigraph relationship
        box_epi = SurroundingRectangle(t_epi_math, color=GREEN, buff=0.1)
        self.play(Create(box_epi))
