from manim import *

class FluidMechanicsInScience(Scene):
    def construct(self):

        self.camera.background_color = "#1E1E1E"

        # Title setup
        title = MarkupText("Role of Fluid Mechanics in Scientific Research",
                    font_size=34,
                    color=WHITE)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # Main definition
        intro_text = MarkupText(
            "Fluid mechanics provides a theoretical framework for the motion and "
            "mechanical properties of continuous media.",
            font_size=28,
            line_spacing=0.8
        ).next_to(title_group, DOWN, buff=0.4)

        self.play(FadeIn(intro_text, shift=DOWN, run_time=1.2))

        # Core concepts studied
        studies_header = MarkupText(
            "It enables prediction of phenomena by studying:",
            font_size=28,
            color=BLUE_C
        ).next_to(intro_text, DOWN, buff=0.5).align_to(intro_text, LEFT)

        concepts_list = BulletedList(
            "Flow states (laminar, turbulent)",
            "Pressure distribution & velocity fields",
            "Conservation laws (mass, momentum, energy)",
            font_size=26,
            buff=0.2
        ).next_to(studies_header, DOWN, buff=0.3).align_to(studies_header, LEFT)

        self.play(Write(studies_header, run_time=1))
        self.play(Write(concepts_list), run_time=2)

        # Applications
        applications_header = MarkupText(
            "Real-world applications include:",
            font_size=28,
            color=GREEN_C
        ).next_to(concepts_list, DOWN, buff=0.5).align_to(intro_text, LEFT)

        applications_list = BulletedList(
            "Atmospheric circulation patterns",
            "Movement of ocean currents",
            "Evolution of celestial gas clouds",
            font_size=26,
            buff=0.2
        ).next_to(applications_header, DOWN, buff=0.3).align_to(applications_header, LEFT)

        self.play(Write(applications_header, run_time=1))
        self.play(Write(applications_list), run_time=2)
