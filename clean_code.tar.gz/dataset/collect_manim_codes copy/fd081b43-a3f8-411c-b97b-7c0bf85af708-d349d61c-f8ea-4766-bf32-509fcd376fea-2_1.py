from manim import *
import random

class ImageFormationAndPixels(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("图像形成与像素表示",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 内容布局:左侧(成像原理),右侧(像素矩阵)
        # ---------------------------------------------------------

        # --- 左侧:物理世界到传感器的抽象 ---

        # 1. 物理对象 (简单的三角形代表物体)
        obj = Triangle(color=GREEN, fill_opacity=0.8).scale(0.6)
        obj_label = Text("物理场景", font="AR PL UKai CN", font_size=20).next_to(obj, DOWN, buff=0.2)
        obj_group = VGroup(obj, obj_label).move_to(LEFT * 4.5)

        # 2. 传感器 (简单的矩形)
        sensor = Rectangle(height=2.0, width=0.3, color=BLUE, fill_opacity=0.5)
        sensor_label = Text("传感器/CCD", font="AR PL UKai CN", font_size=20).next_to(sensor, DOWN, buff=0.2)
        sensor_group = VGroup(sensor, sensor_label).move_to(LEFT * 1.5)

        # 3. 光线/投影箭头
        arrow_light = Arrow(start=obj.get_right(), end=sensor.get_left(), buff=0.2, color=YELLOW)
        process_text = Text("投影 & 采样", font="AR PL UKai CN", font_size=18, color=YELLOW)
        process_text.next_to(arrow_light, UP, buff=0.1)

        # --- 右侧:像素矩阵可视化 ---

        # 4. 构建像素网格 (4x4 Grid)
        grid_group = VGroup()
        rows, cols = 4, 4

        # 预先定义一个高亮像素的位置 (row=1, col=1)
        target_row, target_col = 1, 1
        target_pixel_mob = None

        for i in range(rows):
            for j in range(cols):
                # 模拟灰度值
                val = random.randint(50, 220)
                # 如果是目标像素,设为固定值方便讲解
                if i == target_row and j == target_col:
                    val = 128

                color_val = interpolate_color(BLACK, WHITE, val/255.0)

                # 像素方块
                sq = Square(side_length=0.8, fill_color=color_val, fill_opacity=1, stroke_color=GRAY, stroke_width=1)

                # 在方块内显示数值
                num = Text(str(val), font_size=16, color=RED if val > 100 else YELLOW, font="AR PL UKai CN")
                num.move_to(sq.get_center())

                pixel_unit = VGroup(sq, num)
                grid_group.add(pixel_unit)

                if i == target_row and j == target_col:
                    target_pixel_mob = pixel_unit

        grid_group.arrange_in_grid(rows=4, cols=4, buff=0)
        grid_group.move_to(RIGHT * 3.5)

        grid_title = Text("数字图像 I(x,y)", font="AR PL UKai CN", font_size=24, color=WHITE)
        grid_title.next_to(grid_group, UP, buff=0.3)

        # 5. 连接传感器到矩阵的箭头
        arrow_digit = Arrow(start=sensor.get_right(), end=grid_group.get_left(), buff=0.5, color=WHITE)
        quant_text = Text("量化", font="AR PL UKai CN", font_size=18).next_to(arrow_digit, UP, buff=0.1)

        # --- 动画演示序列 ---

        # 第一步:展示物理成像过程
        self.play(FadeIn(obj_group, shift=RIGHT))
        self.play(
            GrowArrow(arrow_light),
            Write(process_text),
            FadeIn(sensor_group)
        )

        # 第二步:展示数字化过程
        self.play(
            GrowArrow(arrow_digit),
            Write(quant_text),
            FadeIn(grid_group),
            Write(grid_title)
        )

        # 第三步:强调像素概念
        # 使用 SurroundingRectangle 强调单个像素
        if target_pixel_mob:
            surround_rect = SurroundingRectangle(target_pixel_mob, color=RED, buff=0.05, stroke_width=3)

            # 解释文字
            pixel_desc = Text("像素:强度值", font="AR PL UKai CN", font_size=20, color=RED)
            pixel_desc.next_to(grid_group, DOWN, buff=0.3)

            # 数学公式
            math_formula = MathTex(r"f(x, y) \in [0, 255]", font_size=26, color=BLUE_B)
            math_formula.next_to(pixel_desc, DOWN, buff=0.2)

            self.play(Create(surround_rect))
            self.play(
                Write(pixel_desc),
                Write(math_formula)
            )
