from manim import *

class DefiniteConditions(Scene):
    def construct(self):

        # 1. 标准化标题构建
        title = Text("偏微分方程的定解条件",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 分为左右两部分:初始条件 和 边界条件

        # --- 左侧:初始条件 ---
        init_header = Text("初始条件", font="AR PL UKai CN", font_size=28, color=BLUE)
        init_desc = Text("描述物理过程的初始状态", font="AR PL UKai CN", font_size=22, color=GRAY_A)
        init_math = MathTex(r"t=0", color=YELLOW, font_size=36)
        init_example = MathTex(r"u(x, 0) = \varphi(x)", font_size=30)

        init_content = VGroup(init_header, init_desc, init_math, init_example)
        init_content.arrange(DOWN, buff=0.4)

        # 给左侧添加边框
        init_box = SurroundingRectangle(init_content, color=BLUE, buff=0.3)
        init_group = VGroup(init_box, init_content)

        # --- 右侧:边界条件 ---
        bound_header = Text("边界条件", font="AR PL UKai CN", font_size=28, color=GREEN)
        bound_desc = Text("描述边界上的约束情况", font="AR PL UKai CN", font_size=22, color=GRAY_A)

        # 边界条件的三种类型,使用 VGroup 手动排列以获得更好控制
        # 第一类
        type1_label = Text("1. Dirichlet 条件 (第一类)", font="AR PL UKai CN", font_size=20, color=TEAL)
        type1_math = MathTex(r"u|_{\partial \Omega} = g(x)", font_size=24) # 给定函数值
        type1_note = Text("给定边界上的函数值", font="AR PL UKai CN", font_size=18, color=WHITE)
        type1_group = VGroup(type1_label, type1_math, type1_note).arrange(DOWN, buff=0.15)

        # 第二类
        type2_label = Text("2. Neumann 条件 (第二类)", font="AR PL UKai CN", font_size=20, color=TEAL)
        type2_math = MathTex(r"\left. \frac{\partial u}{\partial n} \right|_{\partial \Omega} = h(x)", font_size=24) # 给定法向导数
        type2_note = Text("给定边界上的法向导数值", font="AR PL UKai CN", font_size=18, color=WHITE)
        type2_group = VGroup(type2_label, type2_math, type2_note).arrange(DOWN, buff=0.15)

        # 第三类
        type3_label = Text("3. Robin 条件 (第三类)", font="AR PL UKai CN", font_size=20, color=TEAL)
        type3_math = MathTex(r"\alpha u + \beta \frac{\partial u}{\partial n} = \sigma(x)", font_size=24) # 线性组合
        type3_note = Text("函数值与法向导数的线性组合", font="AR PL UKai CN", font_size=18, color=WHITE)
        type3_group = VGroup(type3_label, type3_math, type3_note).arrange(DOWN, buff=0.15)

        # 组合右侧内容
        bound_list = VGroup(type1_group, type2_group, type3_group).arrange(DOWN, buff=0.3, aligned_edge=LEFT)
        bound_content = VGroup(bound_header, bound_desc, bound_list).arrange(DOWN, buff=0.3)

        # 给右侧添加边框
        bound_box = SurroundingRectangle(bound_content, color=GREEN, buff=0.2)
        bound_group = VGroup(bound_box, bound_content)

        # 3. 整体布局定位
        # 将左右两组并排显示,并向下移动避开标题
        content_group = VGroup(init_group, bound_group).arrange(RIGHT, buff=1.0)
        content_group.next_to(title_line, DOWN, buff=0.5)

        # 4. 动画展示
        # 逐步显示初始条件
        self.play(Create(init_box), FadeIn(init_header))
        self.play(Write(init_desc), Write(init_math), FadeIn(init_example))

        # 逐步显示边界条件
        self.play(Create(bound_box), FadeIn(bound_header), Write(bound_desc))

        # 依次显示三种边界条件
        self.play(FadeIn(type1_group, shift=RIGHT))
        self.play(FadeIn(type2_group, shift=RIGHT))
        self.play(FadeIn(type3_group, shift=RIGHT))
