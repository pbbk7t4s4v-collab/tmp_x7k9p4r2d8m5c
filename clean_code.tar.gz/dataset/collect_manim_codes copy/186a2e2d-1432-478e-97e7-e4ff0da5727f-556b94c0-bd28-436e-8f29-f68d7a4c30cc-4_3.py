from manim import *

class HexagonBasisDifference(Scene):
    def construct(self):

        # 3. 标题设置
        title = Text("六角晶格基矢定义的差异",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 左侧：定义方式 A (标准取向)
        # ---------------------------------------------------------
        hex_a = RegularPolygon(n=6, color=BLUE, fill_opacity=0.2).scale(1.2)
        # 旋转使得顶点对齐习惯
        hex_a.rotate(PI/6)

        # 定义基矢 A
        vec_a1 = Arrow(start=ORIGIN, end=hex_a.get_vertices()[0], color=YELLOW, buff=0)
        vec_a2 = Arrow(start=ORIGIN, end=hex_a.get_vertices()[1], color=YELLOW, buff=0)
        label_a1 = MathTex(r"\vec{a}_1", color=YELLOW).next_to(vec_a1.get_end(), RIGHT, buff=0.1).scale(0.6)
        label_a2 = MathTex(r"\vec{a}_2", color=YELLOW).next_to(vec_a2.get_end(), UP, buff=0.1).scale(0.6)

        text_a = Text("文献定义一", font="AR PL UKai CN", font_size=24).next_to(hex_a, DOWN)

        group_a = VGroup(hex_a, vec_a1, vec_a2, label_a1, label_a2, text_a)

        # ---------------------------------------------------------
        # 右侧：定义方式 B (旋转30度)
        # ---------------------------------------------------------
        hex_b = RegularPolygon(n=6, color=GREEN, fill_opacity=0.2).scale(1.2)
        # 这里的角度不同，模拟不同文献的差异
        # hex_b 保持默认或旋转不同角度

        # 定义基矢 B (随晶格旋转)
        vec_b1 = Arrow(start=ORIGIN, end=hex_b.get_vertices()[0], color=RED, buff=0)
        vec_b2 = Arrow(start=ORIGIN, end=hex_b.get_vertices()[1], color=RED, buff=0)
        label_b1 = MathTex(r"\vec{a}'_1", color=RED).next_to(vec_b1.get_end(), RIGHT, buff=0.1).scale(0.6)
        label_b2 = MathTex(r"\vec{a}'_2", color=RED).next_to(vec_b2.get_end(), UP, buff=0.1).scale(0.6)

        text_b = Text("文献定义二(旋转)", font="AR PL UKai CN", font_size=24).next_to(hex_b, DOWN)

        group_b = VGroup(hex_b, vec_b1, vec_b2, label_b1, label_b2, text_b)

        # 布局
        group_a.shift(LEFT * 3 + DOWN * 0.5)
        group_b.shift(RIGHT * 3 + DOWN * 0.5)

        # 动画展示图形
        self.play(FadeIn(group_a), FadeIn(group_b), run_time=1.5)

        # ---------------------------------------------------------
        # 底部：影响与结论
        # ---------------------------------------------------------

        # 影响展示
        impact_text = Text("内积数值发生改变：", font="AR PL UKai CN", font_size=28, color=LIGHT_GRAY)
        math_eq = MathTex(r"\vec{k} \cdot \vec{a}_i \neq \vec{k} \cdot \vec{a}'_i", color=RED)

        impact_group = VGroup(impact_text, math_eq).arrange(RIGHT, buff=0.3)
        impact_group.next_to(VGroup(group_a, group_b), DOWN, buff=0.5)

        self.play(Write(impact_group), run_time=1.5)

        # 结论强调
        conclusion = Text("必须进行坐标系标准化！", font="AR PL UKai CN", font_size=32, color=YELLOW)
        conclusion.next_to(impact_group, DOWN, buff=0.5)

        rect = SurroundingRectangle(conclusion, color=YELLOW, buff=0.2)

        self.play(
            Write(conclusion),
            Create(rect),
            run_time=1.5
        )
