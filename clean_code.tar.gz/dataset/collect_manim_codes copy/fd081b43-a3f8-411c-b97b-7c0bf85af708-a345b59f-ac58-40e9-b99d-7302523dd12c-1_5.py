from manim import *

class CommodityMarketEquilibrium(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("商品市场均衡条件",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念文本展示
        # ---------------------------------------------------------
        # 简要说明文字
        intro_text = Text("简单凯恩斯模型：总供给 = 总需求",
                         font="AR PL UKai CN",
                         font_size=28,
                         color=BLUE_B)
        intro_text.next_to(title_line, DOWN, buff=0.8)

        self.play(FadeIn(intro_text, shift=DOWN))

        # ---------------------------------------------------------
        # 3. 公式展示与解析
        # ---------------------------------------------------------
        # 主公式 Y = C + I + G
        # 分别对应：0:Y, 1:=, 2:C, 3:+, 4:I, 5:+, 6:G
        formula = MathTex("Y", "=", "C", "+", "I", "+", "G", font_size=60)
        formula.move_to(ORIGIN).shift(DOWN * 0.5)

        # 步骤1：显示公式左边（总供给）
        self.play(Write(formula[0]))

        # 对应的中文注释 - 总供给
        label_supply = Text("国民收入\n(总供给)", font="AR PL UKai CN", font_size=24, color=YELLOW)
        label_supply.next_to(formula[0], LEFT, buff=0.5)
        arrow_supply = Arrow(label_supply.get_right(), formula[0].get_left(), buff=0.1, color=YELLOW)

        self.play(FadeIn(label_supply), GrowArrow(arrow_supply))

        # 步骤2：显示等号和右边（总需求）
        self.play(Write(formula[1:]))

        # 对应的中文注释 - 各个分量
        # 消费
        label_c = Text("消费", font="AR PL UKai CN", font_size=20, color=TEAL)
        label_c.next_to(formula[2], UP, buff=1.0)
        line_c = DashedLine(label_c.get_bottom(), formula[2].get_top(), color=TEAL)

        # 投资
        label_i = Text("投资", font="AR PL UKai CN", font_size=20, color=TEAL)
        label_i.next_to(formula[4], UP, buff=1.0)
        line_i = DashedLine(label_i.get_bottom(), formula[4].get_top(), color=TEAL)

        # 政府支出
        label_g = Text("政府支出", font="AR PL UKai CN", font_size=20, color=TEAL)
        label_g.next_to(formula[6], UP, buff=1.0)
        line_g = DashedLine(label_g.get_bottom(), formula[6].get_top(), color=TEAL)

        # 组合动画展示右侧注释
        self.play(
            FadeIn(label_c, shift=DOWN), Create(line_c),
            FadeIn(label_i, shift=DOWN), Create(line_i),
            FadeIn(label_g, shift=DOWN), Create(line_g),
            run_time=1.5
        )

        # ---------------------------------------------------------
        # 4. 强调与总结
        # ---------------------------------------------------------
        # 使用 SurroundingRectangle 强调整个公式
        box = SurroundingRectangle(formula, color=ORANGE, buff=0.2)
        label_demand = Text("总需求", font="AR PL UKai CN", font_size=24, color=ORANGE)
        label_demand.next_to(box, DOWN, buff=0.2)

        self.play(
            Create(box),
            Write(label_demand)
        )
