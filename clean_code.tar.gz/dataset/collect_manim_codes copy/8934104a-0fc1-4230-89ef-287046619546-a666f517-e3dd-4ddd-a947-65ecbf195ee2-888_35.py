from manim import *

class ISOMAP_MDS_Flow(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("ISOMAP流程与MDS目标",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("35", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. ISOMAP 步骤列表 (左侧)
        # 使用 BulletedList 展示三个核心步骤
        isomap_steps = VGroup(
            Text("1. 构建近邻图 (kNN)", font="AR PL UKai CN", font_size=26),
            Text("2. 计算最短路径 (测地线)", font="AR PL UKai CN", font_size=26),
            Text("3. 利用 MDS 算法降维", font="AR PL UKai CN", font_size=26),
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        isomap_steps.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 3. MDS 核心概念展示 (右侧)
        # 用图形和公式展示 MDS 的输入输出和目标

        # 概念标题
        mds_header = Text("MDS (多维放缩) 目标", font="AR PL UKai CN", font_size=28, color=YELLOW)

        # 输入：距离矩阵
        input_text = Text("输入: 距离矩阵 D", font="AR PL UKai CN", font_size=24)

        # 箭头
        arrow = Arrow(start=UP, end=DOWN, buff=0.1, color=BLUE).scale(0.6)

        # 输出：低维坐标
        output_text = Text("寻找: 低维坐标 Z", font="AR PL UKai CN", font_size=24)

        # 核心公式
        # 使用 Text 以避免 LaTeX 依赖
        equation = Text(
            "||z_i - z_j|| ≈ d_{ij}",
            font="AR PL UKai CN",
            font_size=32,
            color=GREEN
        )
        equation_desc = Text("欧氏距离 还原 原始距离", font="AR PL UKai CN", font_size=20, color=GRAY)

        # 组合右侧元素
        mds_group = VGroup(
            mds_header,
            input_text,
            arrow,
            output_text,
            equation,
            equation_desc
        ).arrange(DOWN, buff=0.3)

        # 将右侧组放到屏幕右侧
        mds_group.to_edge(RIGHT, buff=1.5).align_to(isomap_steps, UP)

        # 添加强调框
        frame = SurroundingRectangle(mds_group, color=BLUE, buff=0.3)

        # 4. 动画流程
        # 第一步：写出 ISOMAP 步骤
        self.play(Write(isomap_steps), run_time=3)

        # 第二步：针对第三点(MDS)引出右侧详情
        # 强调第三步
        self.play(
            isomap_steps[2].animate.set_color(YELLOW),
            run_time=0.5
        )

        # 第三步：展示 MDS 详情
        self.play(
            Create(frame),
            FadeIn(mds_group, shift=LEFT),
            run_time=2
        )

        # 停顿以供阅读
