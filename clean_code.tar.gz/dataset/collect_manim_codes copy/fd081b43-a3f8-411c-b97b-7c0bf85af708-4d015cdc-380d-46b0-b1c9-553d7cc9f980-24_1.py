from manim import *

class VectorFieldArrowPlot(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("向量场的箭头图",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("24", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧文本，右侧图形

        # 左侧：概念解释
        # 使用 VGroup 手动排列，避免 BulletedList 的潜在问题
        explanation_group = VGroup()

        text_def = Text("定义：空间中每一点都对应一个向量", font="AR PL UKai CN", font_size=24, color=WHITE)

        # 数学公式展示向量函数
        math_func = MathTex(r"\vec{F}(x, y) = -y\hat{i} + x\hat{j}", font_size=30, color=BLUE_B)

        text_dir = Text("• 箭头指向：表示向量的方向", font="AR PL UKai CN", font_size=24, color=YELLOW)
        text_mag = Text("• 箭头长短：表示向量的大小(模)", font="AR PL UKai CN", font_size=24, color=GREEN)

        explanation_group.add(text_def, math_func, text_dir, text_mag)
        explanation_group.arrange(DOWN, buff=0.5, aligned_edge=LEFT)
        explanation_group.to_edge(LEFT, buff=1.0).shift(UP * 0.5)

        # 添加强调框
        box = SurroundingRectangle(explanation_group, color=BLUE, buff=0.2)

        # 右侧：可视化坐标系与向量场
        # 创建一个小型的坐标系
        plane = NumberPlane(
            x_range=[-3, 3, 1],
            y_range=[-3, 3, 1],
            x_length=6,
            y_length=6,
            background_line_style={
                "stroke_color": GREY,
                "stroke_width": 1,
                "stroke_opacity": 0.5
            }
        ).scale(0.6)
        plane.to_edge(RIGHT, buff=1.0).shift(DOWN * 0.2)

        # 手动生成一些向量箭头以展示旋转场 (-y, x)
        vectors = VGroup()
        for x in range(-2, 3):
            for y in range(-2, 3):
                if x == 0 and y == 0:
                    continue

                # 计算向量 (-y, x) 并缩放以便显示
                vec_x = -y * 0.4
                vec_y = x * 0.4

                start_point = plane.c2p(x, y)
                end_point = plane.c2p(x + vec_x, y + vec_y)

                # 根据位置创建箭头
                arrow = Arrow(
                    start=start_point,
                    end=end_point,
                    buff=0,
                    stroke_width=2,
                    max_tip_length_to_length_ratio=0.3,
                    color=YELLOW if (x*x + y*y) < 2 else GREEN # 简单的颜色区分
                )
                vectors.add(arrow)

        # 3. 动画流程

        # 第一步：显示左侧文本
        self.play(FadeIn(text_def), Create(box))
        self.play(Write(math_func))

        # 第二步：显示坐标系
        self.play(Create(plane), run_time=1.0)

        # 第三步：结合文本显示向量特征
        self.play(FadeIn(text_dir))
        # 动画显示箭头生成 (模拟场的效果)
        self.play(LaggedStartMap(GrowArrow, vectors, lag_ratio=0.05), run_time=2.0)

        # 第四步：显示大小概念
        self.play(FadeIn(text_mag))

        # 强调几个不同长度的箭头
        highlight_rect = SurroundingRectangle(vectors[0], color=RED) # 随意选一个外围的长箭头
        self.play(Create(highlight_rect))
        self.play(FadeOut(highlight_rect))
