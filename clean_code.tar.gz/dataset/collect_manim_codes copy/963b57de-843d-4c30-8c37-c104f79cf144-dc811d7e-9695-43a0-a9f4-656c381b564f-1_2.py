from manim import *

class FluidInNature(Scene):
    def construct(self):

        # 1. 标题部分 (严格按照模板)
        title = Text("流体力学在自然界中的作用",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 左侧:大气层现象
        atmos_title = Text("大气层流体运动", font="AR PL UKai CN", font_size=28, color=BLUE_C)
        atmos_items = VGroup(
            Text("• 风 (Wind)", font="AR PL UKai CN", font_size=24),
            Text("• 云 (Cloud)", font="AR PL UKai CN", font_size=24),
            Text("• 降水 (Rain)", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        # 简单的风示意图 (几何图形)
        wind_lines = VGroup(
            CubicBezier(ORIGIN, RIGHT + UP*0.5, RIGHT + UP*0.5, RIGHT*2, color=WHITE).set_stroke(opacity=0.6),
            CubicBezier(ORIGIN, RIGHT + DOWN*0.5, RIGHT + DOWN*0.5, RIGHT*2, color=WHITE).set_stroke(opacity=0.6).shift(DOWN*0.3)
        ).scale(0.5)

        atmos_group = VGroup(atmos_title, wind_lines, atmos_items).arrange(DOWN, buff=0.4)
        atmos_group.to_edge(LEFT, buff=1.5).shift(UP*0.5)

        # 右侧:海洋现象
        ocean_title = Text("海洋流体运动", font="AR PL UKai CN", font_size=28, color=TEAL_C)
        ocean_items = VGroup(
            Text("• 洋流 (Currents)", font="AR PL UKai CN", font_size=24),
            Text("• 潮汐 (Tides)", font="AR PL UKai CN", font_size=24),
            Text("• 波浪 (Waves)", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        # 简单的波浪示意图 (几何图形)
        wave_line = FunctionGraph(lambda x: 0.2 * np.sin(3 * x), x_range=[-1.5, 1.5], color=TEAL_A)

        ocean_group = VGroup(ocean_title, wave_line, ocean_items).arrange(DOWN, buff=0.4)
        ocean_group.to_edge(RIGHT, buff=1.5).shift(UP*0.5)

        # 底部:综合影响
        impact_text = Text("核心影响:塑造气候 · 维持生态 · 人类生活",
                          font="AR PL UKai CN", font_size=26, color=YELLOW)
        impact_box = SurroundingRectangle(impact_text, color=YELLOW, buff=0.2)
        impact_group = VGroup(impact_box, impact_text)
        impact_group.to_edge(DOWN, buff=1.0)

        # 连线箭头
        arrow_left = Arrow(start=atmos_group.get_bottom(), end=impact_box.get_top(), buff=0.1, color=GREY)
        arrow_right = Arrow(start=ocean_group.get_bottom(), end=impact_box.get_top(), buff=0.1, color=GREY)

        # 3. 动画流程
        # 展示左右两侧分类
        self.play(
            FadeIn(atmos_group, shift=RIGHT),
            FadeIn(ocean_group, shift=LEFT),
            run_time=1.5
        )

        # 展示汇聚影响
        self.play(
            GrowArrow(arrow_left),
            GrowArrow(arrow_right),
            run_time=1.0
        )

        self.play(
            Create(impact_box),
            Write(impact_text),
            run_time=1.5
        )

        # 稍微停顿,总时长控制在15秒内
