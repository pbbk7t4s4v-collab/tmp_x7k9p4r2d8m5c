from manim import *

class ATPDefinitionAndHistory(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("自动定理证明：定义与发展历程",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 定义部分
        def_text = Text("利用计算机算法对数学命题进行逻辑推导，验证其在公理体系下是否成立。",
                       font="AR PL UKai CN",
                       font_size=22,
                       color=BLUE_A)
        def_text.next_to(title_line, DOWN, buff=0.5)

        def_rect = SurroundingRectangle(def_text, color=BLUE, buff=0.2)

        self.play(
            FadeIn(def_text, shift=DOWN),
            Create(def_rect)
        )

        # 3. 历史发展节点 (图片与描述)
        # 图片布局参数
        img_size = 2.2
        text_buff = 0.2

        # 节点 1: 17世纪 莱布尼兹
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/92b59baa-35fb-4716-a1f6-c0ef1d11a39b/pictures/2_1/1.png") # 这里期望是一张戈特弗里德·威廉·莱布尼茨的肖像画，17世纪巴洛克风格，戴着标志性的卷发假发，表情睿智，古典油画质感
        img1.height = img_size

        label1_time = Text("17世纪", font="AR PL UKai CN", font_size=20, color=YELLOW)
        label1_desc = Text("莱布尼兹：推理计算器", font="AR PL UKai CN", font_size=16)

        group1 = Group(img1, label1_time, label1_desc).arrange(DOWN, buff=text_buff)

        # 节点 2: 20世纪40年代 电子计算机
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/92b59baa-35fb-4716-a1f6-c0ef1d11a39b/pictures/2_1/2.png") # 这里期望是一张20世纪40年代的大型电子计算机（类似ENIAC），占据整个房间的巨大金属机柜，布满复杂的线缆和真空管，黑白复古摄影风格
        img2.height = img_size

        label2_time = Text("1940s", font="AR PL UKai CN", font_size=20, color=YELLOW)
        label2_desc = Text("逻辑理论学派：机器模拟", font="AR PL UKai CN", font_size=16)

        group2 = Group(img2, label2_time, label2_desc).arrange(DOWN, buff=text_buff)

        # 节点 3: 20世纪70年代 吴文俊
        img3 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/92b59baa-35fb-4716-a1f6-c0ef1d11a39b/pictures/2_1/3.png") # 这里期望是一张中国数学家吴文俊院士的半身肖像，戴着眼镜，面带和蔼的微笑，背景可以是模糊的数学公式或书房，写实风格
        img3.height = img_size

        label3_time = Text("1970s", font="AR PL UKai CN", font_size=20, color=YELLOW)
        label3_desc = Text("吴文俊：几何代数化", font="AR PL UKai CN", font_size=16)

        group3 = Group(img3, label3_time, label3_desc).arrange(DOWN, buff=text_buff)

        # 整体布局
        timeline_group = Group(group1, group2, group3).arrange(RIGHT, buff=1.0)
        timeline_group.to_edge(DOWN, buff=1.5)

        # 连接箭头
        arrow1 = Arrow(start=group1.get_right(), end=group2.get_left(), color=GRAY, buff=0.1, stroke_width=2)
        arrow2 = Arrow(start=group2.get_right(), end=group3.get_left(), color=GRAY, buff=0.1, stroke_width=2)

        # 4. 动画展示
        # 展示第一个节点
        self.play(FadeIn(group1, shift=UP), run_time=1)

        # 展示箭头和第二个节点
        self.play(
            GrowArrow(arrow1),
            FadeIn(group2, shift=UP),
            run_time=1
        )

        # 展示箭头和第三个节点
        self.play(
            GrowArrow(arrow2),
            FadeIn(group3, shift=UP),
            run_time=1
        )
