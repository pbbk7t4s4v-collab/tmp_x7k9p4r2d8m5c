from manim import *

class LimitNotation(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("极限的标准符号表示",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("11", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心公式展示 (替换模板的坐标系部分)
        # 将公式拆分以便于分别解释：lim部分，函数部分，等号，极限值L
        lim_main = Text("lim", font_size=80, font="AR PL UKai CN", color=WHITE)
        lim_sub = Text("x → a", font_size=40, font="AR PL UKai CN", color=WHITE)
        lim_sub.next_to(lim_main, DOWN, buff=0.1).align_to(lim_main, RIGHT)
        lim_group = VGroup(lim_main, lim_sub)

        f_text = Text("f(x)", font_size=80, font="AR PL UKai CN", color=WHITE)
        eq_text = Text("=", font_size=80, font="AR PL UKai CN", color=WHITE)
        l_text = Text("L", font_size=80, font="AR PL UKai CN", color=WHITE)

        math_formula = VGroup(lim_group, f_text, eq_text, l_text).arrange(RIGHT, buff=0.6)
        math_formula.shift(UP * 0.5)

        # 3. 辅助说明元素 (替换模板的文本解释部分)
        # 针对 x -> a 的说明
        brace_input = Brace(math_formula[0], DOWN, buff=0.2)
        text_input = Text("自变量趋近过程", font="AR PL UKai CN", color=BLUE_B)
        text_input.scale(0.6)
        text_input.next_to(brace_input, DOWN, buff=0.1)

        # 针对 L 的说明
        brace_limit = Brace(math_formula[3], DOWN, buff=0.2)
        text_limit = Text("目标极限值", font="AR PL UKai CN", color=YELLOW)
        text_limit.scale(0.6)
        text_limit.next_to(brace_limit, DOWN, buff=0.1)

        # 底部解释性文本
        explanation = Text(
            "表示函数值与极限值 L 的距离可以任意小",
            font="AR PL UKai CN",
            font_size=28,
            color=LIGHT_GREY
        )
        explanation.next_to(math_formula, DOWN, buff=2.0)

        # 强调重点框
        box = SurroundingRectangle(math_formula, color=TEAL, buff=0.3)

        # 4. 动画执行
        # 写入公式
        self.play(Write(math_formula), run_time=1.5)

        # 同时显示上下部分的标注
        self.play(
            GrowFromCenter(brace_input),
            FadeIn(text_input),
            GrowFromCenter(brace_limit),
            FadeIn(text_limit),
            run_time=1.5
        )

        # 强调重点框
        self.play(
            Create(box),
            Write(explanation),
            run_time=1.5
        )
