from manim import *

class LaminarVsTurbulent(Scene):
    def construct(self):

        # 1. 标题部分
        title = Text("层流与湍流的对比",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局设置
        # 左侧区域:层流
        left_center = LEFT * 3.5
        # 右侧区域:湍流
        right_center = RIGHT * 3.5

        # 3. 绘制管道边界 (上下两根线)
        def create_pipe(center_point):
            top_wall = Line(LEFT*2.5, RIGHT*2.5, color=GRAY).move_to(center_point + UP*1.5)
            bottom_wall = Line(LEFT*2.5, RIGHT*2.5, color=GRAY).move_to(center_point + DOWN*1.5)
            return VGroup(top_wall, bottom_wall)

        left_pipe = create_pipe(left_center)
        right_pipe = create_pipe(right_center)

        self.play(Create(left_pipe), Create(right_pipe), run_time=1)

        # 4. 绘制流线内容
        # 层流:平行的直线
        laminar_lines = VGroup()
        for i in range(-2, 3):
            if i == 0: continue # 中间留点空隙或画线
            line = Arrow(start=LEFT*2, end=RIGHT*2, buff=0, color=BLUE_D, stroke_width=4, max_tip_length_to_length_ratio=0.1)
            line.move_to(left_center + UP * i * 0.4)
            laminar_lines.add(line)

        # 湍流:混乱的曲线
        turbulent_lines = VGroup()
        # 曲线1:波浪
        path1 = FunctionGraph(lambda x: 0.3 * np.sin(3*x), x_range=[-2, 2], color=BLUE_D).move_to(right_center + UP*0.8)
        # 曲线2:螺旋/打结 (用贝塞尔曲线模拟)
        path2 = CubicBezier(
            LEFT*2 + right_center,
            LEFT*0.5 + UP*2 + right_center,
            RIGHT*0.5 + DOWN*2 + right_center,
            RIGHT*2 + right_center,
            color=BLUE_D
        )
        # 曲线3:小漩涡
        path3 = FunctionGraph(lambda x: 0.2 * np.cos(5*x), x_range=[-2, 2], color=BLUE_D).move_to(right_center + DOWN*0.8)

        # 给湍流线条加上箭头尖端
        t_arrow1 = Arrow(start=LEFT, end=RIGHT, color=BLUE_D).scale(0).put_start_and_end_on(path1.get_end()+LEFT*0.1, path1.get_end())
        t_arrow2 = Arrow(start=LEFT, end=RIGHT, color=BLUE_D).scale(0).put_start_and_end_on(path2.get_end()+LEFT*0.1, path2.get_end())
        t_arrow3 = Arrow(start=LEFT, end=RIGHT, color=BLUE_D).scale(0).put_start_and_end_on(path3.get_end()+LEFT*0.1, path3.get_end())

        turbulent_lines.add(path1, path2, path3, t_arrow1, t_arrow2, t_arrow3)

        # 5. 文字标签
        font_style = {"font": "AR PL UKai CN", "font_size": 24}

        # 左侧文字
        laminar_label = Text("层流 (Laminar)", color=YELLOW, **font_style).next_to(left_pipe, UP)
        laminar_desc = VGroup(
            Text("流线平行有序", **font_style),
            Text("流层互不混合", **font_style),
            MathTex(r"Re < 2300", color=WHITE, font_size=26)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2).move_to(left_center)

        # 右侧文字
        turbulent_label = Text("湍流 (Turbulent)", color=RED, **font_style).next_to(right_pipe, UP)
        turbulent_desc = VGroup(
            Text("流线混乱交错", **font_style),
            Text("存在剧烈混合", **font_style),
            MathTex(r"Re > 4000", color=WHITE, font_size=26)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2).move_to(right_center)

        # 6. 动画演示
        # 显示标签
        self.play(FadeIn(laminar_label), FadeIn(turbulent_label), run_time=0.5)

        # 绘制流线 (层流平滑,湍流较快且混乱)
        self.play(
            GrowFromEdge(laminar_lines, edge=LEFT, run_time=2),
            Create(turbulent_lines, run_time=2, rate_func=linear)
        )

        # 显示描述文字
        self.play(
            Write(laminar_desc),
            Write(turbulent_desc),
            run_time=1.5
        )

        # 7. 强调对比框
        rect_left = SurroundingRectangle(laminar_desc, color=YELLOW, buff=0.2)
        rect_right = SurroundingRectangle(turbulent_desc, color=RED, buff=0.2)

        self.play(Create(rect_left), Create(rect_right), run_time=1)
