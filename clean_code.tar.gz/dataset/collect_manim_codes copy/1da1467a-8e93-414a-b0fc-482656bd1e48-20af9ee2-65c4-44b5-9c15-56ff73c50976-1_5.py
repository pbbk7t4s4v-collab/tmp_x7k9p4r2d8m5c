from manim import *

class TypicalDataPipeline(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("典型训练数据流水线",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title)
        , run_time=1.5)
        self.play(
            GrowFromCenter(title_line)
        , run_time=0.8)

        # ---------------------------------------------------------
        # 2. 内容可视化设计
        # ---------------------------------------------------------

        # A. 原始数据阶段 (左侧)
        # 用几条杂乱的折线代表原始时序数据
        raw_lines = VGroup()
        for i in range(3):
            line = VMobject().set_points_as_corners(
                [[-0.5, 0, 0], [-0.2, 0.3, 0], [0.1, -0.2, 0], [0.4, 0.1, 0], [0.5, 0, 0]]
            ).set_stroke(color=BLUE_B, width=2).shift(DOWN * 0.3 * i + UP * 0.3)
            raw_lines.add(line)

        raw_label = Text("原始数据采集", font="AR PL UKai CN", font_size=20, color=BLUE)
        raw_label.next_to(raw_lines, UP, buff=0.2)

        raw_group = VGroup(raw_lines, raw_label)
        raw_group.to_edge(LEFT, buff=1).shift(UP*0.5)

        # B. 预处理阶段 (中间)
        # 一个方框代表处理过程
        process_box = Rectangle(height=2.5, width=3.5, color=GREEN, fill_opacity=0.1)

        # 列表展示处理步骤
        process_list_items = ["数据清洗", "对齐/切片", "重采样"]
        process_list = VGroup(*[
            Text(f"• {item}", font="AR PL UKai CN", font_size=22)
            for item in process_list_items
        ])
        process_list.arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        process_list.move_to(process_box.get_center())

        process_label = Text("预处理流水线", font="AR PL UKai CN", font_size=20, color=GREEN)
        process_label.next_to(process_box, UP, buff=0.2)

        process_group = VGroup(process_box, process_list, process_label)
        process_group.next_to(raw_group, RIGHT, buff=1.5)

        # 箭头 1: 原始 -> 处理
        arrow1 = Arrow(raw_group.get_right(), process_group.get_left(), buff=0.1, color=GREY)

        # C. 张量与训练阶段 (右侧)
        # 用矩阵符号代表 Tensor
        tensor_matrix = Text(
            "[ 0.1  0.5 ]\n[ 0.3  0.9 ]\n[  ⋮     ⋮  ]",
            font="AR PL UKai CN",
            font_size=30
        )
        tensor_label = Text("张量 (Tensor)", font="AR PL UKai CN", font_size=20, color=YELLOW)
        tensor_label.next_to(tensor_matrix, UP, buff=0.2)

        tensor_group = VGroup(tensor_matrix, tensor_label)
        tensor_group.next_to(process_group, RIGHT, buff=1.5)

        # 箭头 2: 处理 -> 张量
        arrow2 = Arrow(process_group.get_right(), tensor_group.get_left(), buff=0.1, color=GREY)

        # D. 随机采样说明 (底部强调)
        # 使用 SurroundingRectangle 强调 Tensor 区域，说明 Mini-batch
        batch_rect = SurroundingRectangle(tensor_group, color=RED, buff=0.2)
        batch_text = Text("随机批量采样 (Mini-batch)\n要求极高随机读取性能",
                         font="AR PL UKai CN", font_size=24, color=RED)
        batch_text.next_to(batch_rect, DOWN, buff=0.3)

        # ---------------------------------------------------------
        # 3. 动画流程
        # ---------------------------------------------------------

        # 第一步：展示原始数据和预处理
        self.play(FadeIn(raw_group), run_time=1)
        self.play(GrowArrow(arrow1), FadeIn(process_group), run_time=1)

        # 第二步：展示转化为张量
        self.play(GrowArrow(arrow2), FadeIn(tensor_group), run_time=1)

        # 第三步：强调训练时的访问模式
        self.play(
            Create(batch_rect),
            Write(batch_text),
            run_time=1.5
        )

        # 简单的闪烁效果强调随机性
        self.play(
            batch_rect.animate.set_stroke(width=6),
            tensor_matrix.animate.set_color(YELLOW),
            run_time=0.5
        )
        self.play(
            batch_rect.animate.set_stroke(width=4),
            tensor_matrix.animate.set_color(WHITE),
            run_time=0.5
        )
