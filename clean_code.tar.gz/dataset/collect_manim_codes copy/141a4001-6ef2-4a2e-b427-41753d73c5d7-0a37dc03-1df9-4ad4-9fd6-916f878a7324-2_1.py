from manim import *

class CoqFunctionIntro(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("Coq中的函数定义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("23", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 数学表示部分
        # f(x) = x + 1
        math_label = Text("数学函数表示：", font="AR PL UKai CN", font_size=28, color=BLUE_B)
        math_eq = MathTex("f(x) = x + 1", font_size=40)

        math_group = VGroup(math_label, math_eq).arrange(RIGHT, buff=0.3)
        math_group.next_to(title_line, DOWN, buff=1.0)

        self.play(FadeIn(math_group, shift=DOWN))

        # 3. Coq 代码展示
        # 使用 Code 类展示代码,注意 Code 不支持 font_size
        code_str = "Definition plus_one (x: Z): Z := x + 1."
        coq_code = Text(
            code_str,
            font="Monospace",
        )
        coq_code.scale(0.9) # 调整大小
        coq_code.next_to(math_group, DOWN, buff=1.0)

        # 确保代码居中
        coq_code.move_to(ORIGIN).shift(DOWN * 0.5)

        # 代码标签
        code_label = Text("Coq 代码定义：", font="AR PL UKai CN", font_size=28, color=YELLOW)
        code_label.next_to(coq_code, UP, buff=0.2, aligned_edge=LEFT)

        self.play(
            FadeIn(code_label),
            Write(coq_code)
        )

        # 4. 代码结构解析（使用 SurroundingRectangle 和连线）
        # 左侧：类型定义解释
        type_explanation = Text("输入与输出均为整数 (Z)", font="AR PL UKai CN", font_size=24, color=GREEN)
        type_explanation.next_to(coq_code, DOWN, buff=1.0).shift(LEFT * 2.5)

        # 使用箭头指向代码的大致左侧位置 (x: Z): Z
        arrow_type = Arrow(start=type_explanation.get_top(), end=coq_code.get_left() + RIGHT * 2.5, color=GREEN, buff=0.1)

        # 右侧：函数体解释
        body_explanation = Text("计算逻辑: x + 1", font="AR PL UKai CN", font_size=24, color=RED)
        body_explanation.next_to(coq_code, DOWN, buff=1.0).shift(RIGHT * 2.5)

        # 使用箭头指向代码的大致右侧位置 x + 1
        arrow_body = Arrow(start=body_explanation.get_top(), end=coq_code.get_right() + LEFT * 1.5, color=RED, buff=0.1)

        # 动画展示解释
        self.play(
            FadeIn(type_explanation, shift=UP),
            GrowArrow(arrow_type)
        )

        # 这里的 SurroundingRectangle 用于强调下方的文字说明
        rect_type = SurroundingRectangle(type_explanation, color=GREEN, buff=0.1)
        self.play(Create(rect_type))

        self.play(
            FadeIn(body_explanation, shift=UP),
            GrowArrow(arrow_body)
        )

        rect_body = SurroundingRectangle(body_explanation, color=RED, buff=0.1)
        self.play(Create(rect_body))
