from manim import *

class TsFileEcosystem(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("TsFile 的开源生态与社区建设",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("17", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 图片展示 (根据 Planner 建议)
        # 图片布局：左右分列，下方文字

        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/1da1467a-8e93-414a-b0fc-482656bd1e48/20af9ee2-65c4-44b5-9c15-56ff73c50976/pictures/1_17/1.png") # 这里期望是一张充满未来科技感的物联网应用场景插图，画面融合了智慧工厂的机械臂、风力发电机和城市建筑，背景中有蓝色的数据流穿梭其中，象征工业界产生的海量时序数据。风格为2.5D等距科技风
        img1.height = 2.8
        img1.to_edge(LEFT, buff=1.5).shift(UP * 0.5)

        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/1da1467a-8e93-414a-b0fc-482656bd1e48/20af9ee2-65c4-44b5-9c15-56ff73c50976/pictures/1_17/2.png") # 这里期望是一张概念插图，展示“学术界”与“工业界”的结合。画面左侧是象牙塔或大学实验室建筑，右侧是现代化的服务器机房或工厂，中间通过一个发光的桥梁或文件图标（代表TsFile）连接，象征理论研究与工程实践的融合。风格为现代扁平矢量插画
        img2.height = 2.8
        img2.to_edge(RIGHT, buff=1.5).shift(UP * 0.5)

        # 图片说明文字
        label1 = Text("工业界应用与数据流", font="AR PL UKai CN", font_size=20, color=BLUE_B).next_to(img1, DOWN, buff=0.2)
        label2 = Text("学术研究与工程实践融合", font="AR PL UKai CN", font_size=20, color=BLUE_B).next_to(img2, DOWN, buff=0.2)

        # 3. 核心文字内容 (使用自定义列表以确保排版)
        # 准备内容
        item1 = Text("定位：Apache IoTDB 底层存储，亦可独立使用", font="AR PL UKai CN", font_size=24)
        item2 = Text("社区：汇聚工业需求，持续迭代优化性能与功能", font="AR PL UKai CN", font_size=24)
        item3 = Text("价值：提供标准化时序基准，促进算法研究复现", font="AR PL UKai CN", font_size=24)

        # 添加项目符号
        dot1 = Dot(color=ORANGE)
        dot2 = Dot(color=ORANGE)
        dot3 = Dot(color=ORANGE)

        # 组合行
        line1 = VGroup(dot1, item1).arrange(RIGHT, buff=0.2)
        line2 = VGroup(dot2, item2).arrange(RIGHT, buff=0.2)
        line3 = VGroup(dot3, item3).arrange(RIGHT, buff=0.2)

        # 组合文本块并定位
        content_group = VGroup(line1, line2, line3).arrange(DOWN, buff=0.4, aligned_edge=LEFT)
        content_group.move_to(DOWN * 2.2) # 放置在页面下方

        # 装饰框
        box = SurroundingRectangle(content_group, color=TEAL, buff=0.3, stroke_width=2)

        # 4. 动画流程
        # 4.1 显示图片
        self.play(
            FadeIn(img1, shift=RIGHT),
            FadeIn(img2, shift=LEFT),
            run_time=1.0
        )
        self.play(
            Write(label1),
            Write(label2),
            run_time=0.8
        )

        # 4.2 显示下方文字内容
        self.play(Create(box), run_time=0.8)

        self.play(
            FadeIn(line1, shift=UP * 0.2),
            run_time=0.8
        )
        self.play(
            FadeIn(line2, shift=UP * 0.2),
            run_time=0.8
        )
        self.play(
            FadeIn(line3, shift=UP * 0.2),
            run_time=0.8
        )
