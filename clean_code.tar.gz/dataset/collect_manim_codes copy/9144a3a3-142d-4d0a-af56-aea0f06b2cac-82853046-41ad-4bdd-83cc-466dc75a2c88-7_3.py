from manim import *

class InfinityChatDataset(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("开放式数据集：INFINITY-CHAT",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        # 播放标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("28", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念展示：INFINITY-CHAT 数据集
        # 创建数据集的视觉表示（类似数据库或文件夹的抽象）
        dataset_text = Text("INFINITY-CHAT", font_size=48, color=BLUE_A)
        dataset_desc = Text("大规模开放式对话数据", font="AR PL UKai CN", font_size=24, color=GRAY_B)
        dataset_desc.next_to(dataset_text, DOWN, buff=0.2)

        center_content = VGroup(dataset_text, dataset_desc)
        center_content.move_to(ORIGIN).shift(UP * 0.5)

        # 使用 SurroundingRectangle 框住
        rect = SurroundingRectangle(center_content, color=BLUE, buff=0.4, stroke_width=4)

        # 3. 装饰性数据流元素（表示数据汇聚）
        data_dots = VGroup()
        for i in range(8):
            dot = Square(side_length=0.15, color=random_color(), fill_opacity=0.8)
            # 随机分布在框的周围
            direction = rotate_vector(RIGHT, i * TAU / 8)
            dot.move_to(rect.get_center() + direction * 3.5)
            data_dots.add(dot)

        # 4. 底部说明文字
        info_1 = Text("• 提供多样化的用户指令与回答", font="AR PL UKai CN", font_size=28)
        info_2 = Text("• 用于研究语言模型的同质化现象", font="AR PL UKai CN", font_size=28)

        info_group = VGroup(info_1, info_2).arrange(DOWN, buff=0.3, aligned_edge=LEFT)
        info_group.next_to(rect, DOWN, buff=1.0)

        # 5. 动画流程
        # 显示核心数据集框
        self.play(
            Create(rect),
            FadeIn(center_content, scale=0.8),
            run_time=1.5
        )

        # 数据汇聚动画
        self.play(
            AnimationGroup(
                *[
                    MoveAlongPath(
                        dot,
                        Line(dot.get_center(), rect.get_edge_center(normalize(rect.get_center() - dot.get_center())))
                    )
                    for dot in data_dots
                ],
                lag_ratio=0.1
            ),
            run_time=1.5
        )
        # 数据点到达后消失(模拟存入)
        self.remove(data_dots)

        # 显示底部说明
        self.play(
            FadeIn(info_1, shift=UP * 0.2),
            run_time=0.8
        )
        self.play(
            FadeIn(info_2, shift=UP * 0.2),
            run_time=0.8
        )

        # 6. 停留
