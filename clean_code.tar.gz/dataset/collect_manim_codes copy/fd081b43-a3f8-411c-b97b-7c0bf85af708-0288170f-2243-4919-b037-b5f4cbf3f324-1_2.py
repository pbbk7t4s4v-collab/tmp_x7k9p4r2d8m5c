from manim import *

class IdleResourcesScene(Scene):
    def construct(self):

        # 1. 标题设置（严格按照模板）
        title = Text("闲置资源与总供给",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧文字，右侧图表

        # 左侧文字说明
        text_content = VGroup(
            Text("• 经济存在失业与闲置产能", font="AR PL UKai CN", font_size=24, color=WHITE),
            Text("• 总供给曲线(AS)完全弹性", font="AR PL UKai CN", font_size=24, color=YELLOW),
            Text("• 价格水平保持不变", font="AR PL UKai CN", font_size=24, color=WHITE),
            Text("• 产出完全由总需求(AD)决定", font="AR PL UKai CN", font_size=24, color=GREEN)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.5)

        text_content.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 右侧图表 - 凯恩斯主义总供给曲线
        # 坐标轴
        axes = Axes(
            x_range=[0, 10, 1],
            y_range=[0, 8, 1],
            x_length=5,
            y_length=4,
            axis_config={"color": GREY, "include_tip": True},
            tips=False
        ).to_edge(RIGHT, buff=1).shift(DOWN * 0.5)

        # 坐标轴标签
        y_label = axes.get_y_axis_label(MathTex("P"), edge=LEFT, direction=LEFT, buff=0.2)
        x_label = axes.get_x_axis_label(MathTex("Y"), edge=DOWN, direction=DOWN, buff=0.2)
        labels = VGroup(x_label, y_label)

        # 绘制 AS 曲线 (水平线)
        as_start = axes.c2p(0, 4)
        as_end = axes.c2p(9, 4)
        as_curve = Line(as_start, as_end, color=YELLOW, stroke_width=4)
        as_text = MathTex("AS").next_to(as_curve, RIGHT, buff=0.1).set_color(YELLOW)

        # 绘制 AD 曲线 (下倾线)
        ad_start = axes.c2p(2, 7)
        ad_end = axes.c2p(7, 2)
        ad_curve = Line(ad_start, ad_end, color=BLUE, stroke_width=4)
        ad_text = MathTex("AD").next_to(ad_curve, UP, buff=0.1).set_color(BLUE)

        # 均衡点虚线
        # 计算交点：y=4. AD线方程: (y-2)/(x-7) = (7-2)/(2-7) => y-2 = -1(x-7) => y = -x + 9
        # 交点: 4 = -x + 9 => x = 5
        intersect_point = axes.c2p(5, 4)
        dashed_line = DashedLine(intersect_point, axes.c2p(5, 0), color=WHITE)
        y_star = MathTex("Y^*").next_to(axes.c2p(5, 0), DOWN, buff=0.1)

        # 3. 动画流程
        # 显示左侧第一、二条文字
        self.play(FadeIn(text_content[0], shift=RIGHT), run_time=0.8)
        self.play(FadeIn(text_content[1], shift=RIGHT), run_time=0.8)

        # 显示坐标轴
        self.play(Create(axes), Write(labels), run_time=1.2)

        # 绘制 AS 曲线 (强调完全弹性/水平)
        self.play(Create(as_curve), Write(as_text), run_time=1.0)

        # 显示左侧第三条文字
        self.play(FadeIn(text_content[2], shift=RIGHT), run_time=0.8)

        # 绘制 AD 曲线
        self.play(Create(ad_curve), Write(ad_text), run_time=1.0)

        # 显示均衡产出
        self.play(Create(dashed_line), Write(y_star), run_time=0.8)

        # 强调结论：产出由需求决定
        self.play(FadeIn(text_content[3], shift=RIGHT), run_time=0.8)

        # 使用矩形框重点强调最后的结论
        surround_rect = SurroundingRectangle(text_content[3], color=GREEN, buff=0.1)
        self.play(Create(surround_rect), run_time=0.8)
