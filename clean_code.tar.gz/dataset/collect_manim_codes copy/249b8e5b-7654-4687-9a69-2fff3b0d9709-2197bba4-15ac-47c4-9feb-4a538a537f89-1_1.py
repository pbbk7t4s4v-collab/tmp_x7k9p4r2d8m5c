from manim import *

class PythonPackageIntro(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("Python中的包:概念与结构",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念可视化:模块 vs 包
        # ---------------------------------------------------------

        # 左侧:模块 (Module) - 代表单个文件
        module_box = Rectangle(width=2, height=2.5, color=BLUE, fill_opacity=0.1)
        module_ext = Text(".py", font_size=24, color=WHITE).move_to(module_box.get_center())
        module_icon = VGroup(module_box, module_ext)
        module_label = Text("模块 (Module)\n单文件", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        module_label.next_to(module_icon, DOWN, buff=0.2)

        module_group = VGroup(module_icon, module_label)

        # 右侧:包 (Package) - 代表文件夹包含多个文件
        package_box = Rectangle(width=3.5, height=2.5, color=GOLD, fill_opacity=0.1)
        # 包里面的小模块
        sub_m1 = Rectangle(width=0.6, height=0.8, color=BLUE, fill_opacity=0.3)
        sub_m2 = Rectangle(width=0.6, height=0.8, color=BLUE, fill_opacity=0.3)
        sub_m3 = Rectangle(width=0.6, height=0.8, color=BLUE, fill_opacity=0.3)
        sub_modules = VGroup(sub_m1, sub_m2, sub_m3).arrange(RIGHT, buff=0.2).move_to(package_box.get_center())

        package_icon = VGroup(package_box, sub_modules)
        package_label = Text("包 (Package)\n文件夹 (含多个模块)", font="AR PL UKai CN", font_size=24, color=GOLD_A)
        package_label.next_to(package_icon, DOWN, buff=0.2)

        package_group = VGroup(package_icon, package_label)

        # 布局:并排展示
        visual_content = VGroup(module_group, package_group).arrange(RIGHT, buff=2).shift(UP * 0.5)

        # ---------------------------------------------------------
        # 3. 定义与优势文本
        # ---------------------------------------------------------

        # 核心定义
        definition_text = Text(
            "包是 Python 用来组织和管理模块的层次结构",
            font="AR PL UKai CN", font_size=28, color=WHITE
        ).next_to(visual_content, DOWN, buff=0.6)

        # 使用SurroundingRectangle强调定义
        def_rect = SurroundingRectangle(definition_text, color=TEAL, buff=0.2)

        # 优势列表
        benefits = VGroup(
            Text("✅ 归类存放", font="AR PL UKai CN", font_size=24, color=GREEN_B),
            Text("✅ 便于维护", font="AR PL UKai CN", font_size=24, color=GREEN_B),
            Text("✅ 易于复用", font="AR PL UKai CN", font_size=24, color=GREEN_B)
        ).arrange(RIGHT, buff=1).next_to(def_rect, DOWN, buff=0.4)

        # ---------------------------------------------------------
        # 4. 动画编排
        # ---------------------------------------------------------

        # 1. 展示模块概念
        self.play(FadeIn(module_group, shift=RIGHT), run_time=1)

        # 2. 展示包概念
        self.play(FadeIn(package_group, shift=LEFT), run_time=1)

        # 3. 展示定义
        self.play(Write(definition_text), run_time=1.5)
        self.play(Create(def_rect), run_time=0.8)

        # 4. 逐个展示优势
        self.play(
            LaggedStart(
                *[FadeIn(item, shift=UP) for item in benefits],
                lag_ratio=0.3
            ),
            run_time=1.5
        )
