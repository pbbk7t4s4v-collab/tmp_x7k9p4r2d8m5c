from manim import *

class BinaryOperationDef(Scene):
    def construct(self):

        # 1. 标题设置 (严格遵守模板)
        title = Text("二元运算的定义",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 数学定义展示
        # 使用MathTex展示映射公式
        math_def = MathTex(
            r"f: S \times S \longrightarrow S",
            font_size=42
        )
        math_map = MathTex(
            r"(a, b) \longmapsto f(a, b)",
            font_size=36,
            color=BLUE_B
        )

        # 布局公式
        math_group = VGroup(math_def, math_map).arrange(DOWN, buff=0.3)
        math_group.next_to(title_group, DOWN, buff=0.5)

        self.play(Write(math_def))
        self.play(FadeIn(math_map, shift=UP * 0.2))

        # 3. 集合可视化 (展示封闭性概念)
        # 创建集合 S 的边界
        set_s = Circle(radius=1.8, color=WHITE, fill_opacity=0.1, fill_color=GREY)
        label_s = MathTex("S", font_size=36).next_to(set_s, UP, buff=0.1)

        # 集合内的元素点
        dot_a = Dot(color=YELLOW).move_to(set_s.get_center() + LEFT * 0.8 + UP * 0.5)
        label_a = MathTex("a", font_size=28, color=YELLOW).next_to(dot_a, LEFT, buff=0.1)

        dot_b = Dot(color=YELLOW).move_to(set_s.get_center() + LEFT * 0.8 + DOWN * 0.5)
        label_b = MathTex("b", font_size=28, color=YELLOW).next_to(dot_b, LEFT, buff=0.1)

        # 运算结果点
        dot_res = Dot(color=RED).move_to(set_s.get_center() + RIGHT * 0.8)
        label_res = MathTex("f(a,b)", font_size=28, color=RED).next_to(dot_res, RIGHT, buff=0.1)

        # 运算过程箭头
        arrow1 = Arrow(dot_a.get_center(), dot_res.get_center(), buff=0.1, color=GREY_B, stroke_width=2)
        arrow2 = Arrow(dot_b.get_center(), dot_res.get_center(), buff=0.1, color=GREY_B, stroke_width=2)

        # 组合左侧图示
        visual_group = VGroup(set_s, label_s, dot_a, label_a, dot_b, label_b, dot_res, label_res, arrow1, arrow2)
        visual_group.move_to(LEFT * 3 + DOWN * 1.5)

        # 4. 关键问题文本 (右侧)
        # 使用 Text 并指定中文字体
        q_title = Text("核心研究问题：", font="AR PL UKai CN", font_size=28, color=ORANGE)
        q1 = Text("1. 运算是否封闭？", font="AR PL UKai CN", font_size=26)
        q2 = Text("2. 满足哪些代数性质？", font="AR PL UKai CN", font_size=26)

        # 补充说明封闭性
        note = Text("(结果是否仍在集合S内)", font="AR PL UKai CN", font_size=20, color=GRAY)

        text_group = VGroup(q_title, q1, note, q2).arrange(DOWN, buff=0.4, aligned_edge=LEFT)
        text_group.next_to(visual_group, RIGHT, buff=1.5)

        # 5. 动画流程
        # 绘制集合轮廓
        self.play(Create(set_s), Write(label_s), run_time=1)

        # 出现输入元素
        self.play(
            FadeIn(dot_a), Write(label_a),
            FadeIn(dot_b), Write(label_b),
            run_time=0.8
        )

        # 演示运算过程（箭头汇聚）
        self.play(
            GrowArrow(arrow1),
            GrowArrow(arrow2),
            FadeIn(dot_res),
            Write(label_res),
            run_time=1
        )

        # 显示右侧问题
        self.play(
            Write(text_group),
            run_time=1.5
        )

        # 强调封闭性 (使用矩形框)
        rect = SurroundingRectangle(q1, color=YELLOW, buff=0.1)
        self.play(Create(rect), run_time=0.5)
