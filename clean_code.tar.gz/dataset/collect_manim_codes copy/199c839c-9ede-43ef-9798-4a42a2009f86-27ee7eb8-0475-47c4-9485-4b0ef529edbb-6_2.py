from manim import *

class SubtractionCounterexample(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("二元运算的反例：减法",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 引入概念文本
        # 使用 VGroup 方便排版
        text_group = VGroup()

        intro_text = Text("实数集 R 上的减法运算 (-)", font="AR PL UKai CN", font_size=28, color=BLUE_B)

        # 封闭性描述
        closure_text = Text("1. 满足封闭性：任意实数相减仍在 R 中", font="AR PL UKai CN", font_size=24, color=GREEN)

        # 结合律描述（核心反例）
        assoc_text = Text("2. 不满足结合律：(a-b)-c ≠ a-(b-c)", font="AR PL UKai CN", font_size=24, color=RED)

        text_group.add(intro_text, closure_text, assoc_text)
        text_group.arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        text_group.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(intro_text, shift=DOWN))
        self.play(Write(closure_text))
        self.play(Write(assoc_text))

        # 3. 具体的数值反例演示
        # 设置参数
        example_label = Text("反例演示 (a=5, b=3, c=1)：", font="AR PL UKai CN", font_size=26, color=YELLOW)
        example_label.next_to(text_group, DOWN, buff=0.5).align_to(text_group, LEFT)

        self.play(FadeIn(example_label))

        # 左侧计算过程 (5-3)-1
        lhs_tex = MathTex(r"(5 - 3) - 1", r"=", r"2 - 1", r"=", r"1")
        # 为了排版好看，分行显示
        lhs_step1 = MathTex(r"(5 - 3) - 1")
        lhs_step2 = MathTex(r"= 2 - 1")
        lhs_step3 = MathTex(r"= 1")

        lhs_group = VGroup(lhs_step1, lhs_step2, lhs_step3).arrange(DOWN, aligned_edge=LEFT)

        # 右侧计算过程 5-(3-1)
        rhs_step1 = MathTex(r"5 - (3 - 1)")
        rhs_step2 = MathTex(r"= 5 - 2")
        rhs_step3 = MathTex(r"= 3")

        rhs_group = VGroup(rhs_step1, rhs_step2, rhs_step3).arrange(DOWN, aligned_edge=LEFT)

        # 布局左右两组公式
        calculation_group = VGroup(lhs_group, rhs_group).arrange(RIGHT, buff=2.5)
        calculation_group.next_to(example_label, DOWN, buff=0.4)

        # 4. 动画展示计算过程
        self.play(Write(lhs_group), run_time=1.5)
        self.play(Write(rhs_group), run_time=1.5)

        # 5. 强调结果不相等
        neq_symbol = MathTex(r"\neq", color=RED, font_size=48)
        neq_symbol.move_to(calculation_group.get_center())

        # 结果框
        result_rect = SurroundingRectangle(VGroup(lhs_step3, rhs_step3, neq_symbol), color=YELLOW, buff=0.2)

        self.play(
            FadeIn(neq_symbol, scale=0.5),
            Create(result_rect)
        )

        # 6. 最终结论
        conclusion = Text("结论：减法不是结合的", font="AR PL UKai CN", font_size=24, color=RED)
        conclusion.next_to(result_rect, DOWN, buff=0.2)
        self.play(Write(conclusion))
