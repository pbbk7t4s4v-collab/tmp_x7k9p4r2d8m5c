from manim import *

class HaldaneModelIntro(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("六角晶格 Haldane 模型与哈密顿量",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：六角晶格可视化
        # 创建六边形顶点
        hex_radius = 1.8
        center_hex = RegularPolygon(n=6, radius=hex_radius, color=GRAY, stroke_opacity=0.5).rotate(PI/6)
        vertices = center_hex.get_vertices()

        # 定义子格点
        # 偶数索引为A子格，奇数索引为B子格
        sublattice_a = VGroup(*[Dot(v, color=RED, radius=0.12) for i, v in enumerate(vertices) if i % 2 == 0])
        sublattice_b = VGroup(*[Dot(v, color=BLUE, radius=0.12) for i, v in enumerate(vertices) if i % 2 != 0])

        # 连线 (最近邻 t1)
        edges = VGroup()
        for i in range(6):
            p1 = vertices[i]
            p2 = vertices[(i+1)%6]
            edges.add(Line(p1, p2, color=WHITE, stroke_width=2))

        # 连线 (次近邻 t2 - 虚线或箭头示意)
        # 演示从点0到点2的次近邻跳跃
        nnn_arrow = CurvedArrow(vertices[0], vertices[2], angle=-PI/3, color=YELLOW, tip_length=0.2)
        nnn_label = MathTex(r"t_2 e^{i\phi}", color=YELLOW, font_size=24).next_to(nnn_arrow, UP, buff=0.05)

        # 组合晶格图形
        lattice_group = VGroup(edges, sublattice_a, sublattice_b, nnn_arrow, nnn_label)
        lattice_group.scale(0.8).shift(LEFT * 3.5 + DOWN * 0.5)

        # 3. 右侧：文本描述与公式
        # 图例
        legend_a = VGroup(Dot(color=RED), Text("子格 A", font="AR PL UKai CN", font_size=24)).arrange(RIGHT)
        legend_b = VGroup(Dot(color=BLUE), Text("子格 B", font="AR PL UKai CN", font_size=24)).arrange(RIGHT)
        legend = VGroup(legend_a, legend_b).arrange(RIGHT, buff=1.0).next_to(title_line, DOWN, buff=0.5).shift(LEFT * 3.5)

        # 公式部分 (分行写以防过长)
        eq_text = Text("Haldane 哈密顿量：", font="AR PL UKai CN", font_size=28, color=TEAL).shift(RIGHT * 3 + UP * 1)

        # 使用 MathTex 展示公式
        # H = -t1 sum <i,j> ... - t2 sum <<i,j>> ...
        hamiltonian1 = MathTex(r"H = -t_1 \sum_{\langle i,j \rangle} c^\dagger_i c_j", font_size=32)
        hamiltonian2 = MathTex(r"- t_2 \sum_{\langle\langle i,j \rangle\rangle} e^{i\phi_{ij}} c^\dagger_i c_j", font_size=32)

        hamiltonian_group = VGroup(hamiltonian1, hamiltonian2).arrange(DOWN, buff=0.3).next_to(eq_text, DOWN, buff=0.5)

        # 解释列表
        desc_list = VGroup(
            Text("1. 最近邻跃迁 (实线)", font="AR PL UKai CN", font_size=24, color=WHITE),
            Text("2. 次近邻跃迁 (黄线)", font="AR PL UKai CN", font_size=24, color=YELLOW),
            Text("3. 破缺时间反演对称性", font="AR PL UKai CN", font_size=24, color=GRAY_B)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.3).next_to(hamiltonian_group, DOWN, buff=0.8)

        # 强调框
        box = SurroundingRectangle(hamiltonian_group, color=BLUE, buff=0.2)
        label_t1 = Text("最近邻 t1", font="AR PL UKai CN", font_size=20, color=WHITE).next_to(hamiltonian1, RIGHT)
        label_t2 = Text("次近邻 t2", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(hamiltonian2, RIGHT)

        # 4. 动画流程

        # 展示晶格结构
        self.play(FadeIn(legend), run_time=0.5)
        self.play(Create(edges), run_time=1)
        self.play(FadeIn(sublattice_a), FadeIn(sublattice_b), run_time=0.5)

        # 展示次近邻跳跃
        self.play(Create(nnn_arrow), Write(nnn_label), run_time=0.8)

        # 展示右侧公式与解释
        self.play(Write(eq_text), run_time=0.5)
        self.play(Write(hamiltonian_group), run_time=1.5)
        self.play(Create(box), FadeIn(label_t1), FadeIn(label_t2), run_time=0.8)

        # 展示关键点列表
        self.play(
            AnimationGroup(
                *[FadeIn(item, shift=RIGHT*0.5) for item in desc_list],
                lag_ratio=0.2
            )
        )
