from manim import *

class TreeRecursionPrinciple(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("树的递归性：整体与部分",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心问题文本
        question_text = Text("核心问题：如何统一描述"整体"与"部分"？",
                             font="AR PL UKai CN", font_size=24, color=LIGHT_GREY)
        question_text.next_to(title_line, DOWN, buff=0.3)
        self.play(FadeIn(question_text))

        # 3. 构建树的几何图形展示递归结构
        # 根节点
        root_node = Circle(radius=0.4, color=BLUE, fill_opacity=0.5)
        root_node.move_to(UP * 0.5)
        root_label = Text("根", font="AR PL UKai CN", font_size=20).move_to(root_node)

        # 左子树 (用三角形表示抽象的树结构)
        left_subtree = Polygon(
            [-2, -0.5, 0], [-3, -2.5, 0], [-1, -2.5, 0],
            color=GREEN, fill_opacity=0.3
        )
        left_label = MathTex("T_{left}", color=WHITE).move_to(left_subtree.get_center() + DOWN*0.2)

        # 右子树
        right_subtree = Polygon(
            [2, -0.5, 0], [1, -2.5, 0], [3, -2.5, 0],
            color=GREEN, fill_opacity=0.3
        )
        right_label = MathTex("T_{right}", color=WHITE).move_to(right_subtree.get_center() + DOWN*0.2)

        # 连接线
        line_l = Line(root_node.get_bottom(), left_subtree.get_top(), color=GREY)
        line_r = Line(root_node.get_bottom(), right_subtree.get_top(), color=GREY)

        tree_group = VGroup(root_node, root_label, left_subtree, left_label, right_subtree, right_label, line_l, line_r)

        # 动画：展示整体结构
        self.play(
            Create(root_node), Write(root_label),
            run_time=0.8
        )
        self.play(
            Create(line_l), Create(line_r),
            FadeIn(left_subtree), FadeIn(right_subtree),
            Write(left_label), Write(right_label),
            run_time=1.0
        )

        # 4. 递归定义的展示
        # 公式
        recursion_formula = MathTex(r"Tree = \{ Root, T_{left}, T_{right} \}")
        recursion_formula.next_to(tree_group, DOWN, buff=0.5)

        self.play(Write(recursion_formula))

        # 5. 强调部分也是整体（递归的关键）
        # 框选左子树
        rect = SurroundingRectangle(left_subtree, color=YELLOW, buff=0.1)
        # 说明文字
        desc_text = Text("子树 T_left 本身也是一棵树", font="AR PL UKai CN", font_size=22, color=YELLOW)
        desc_text.next_to(rect, LEFT, buff=0.2)

        self.play(
            Create(rect),
            Write(desc_text),
            run_time=1.0
        )

        # 6. 总结
        summary = Text("递归定义：用自身定义自身", font="AR PL UKai CN", font_size=26, color=BLUE_B)
        summary.move_to(desc_text.get_center() + DOWN * 0.8 + RIGHT * 2.5) # 调整位置到下方居中

        self.play(FadeIn(summary))
