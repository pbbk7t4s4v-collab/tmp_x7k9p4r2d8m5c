from manim import *

class ConservationLawDerivation(Scene):
    def construct(self):

        # ---- Title Configuration ----
        title = Text("Conservation Law & Source Term",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # Bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Group title elements
        title_group = VGroup(title, title_line)

        # Title Animation
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---- Visual Elements (Left Side) ----
        # Abstract Domain D
        domain = Circle(radius=1.6, color=BLUE_C, fill_opacity=0.3)
        # Deform the circle slightly to look like an arbitrary domain
        domain.apply_function(lambda p: p + np.array([0.2*np.sin(3*p[1]), 0.15*np.cos(3*p[0]), 0]))
        domain.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # Labels for the domain
        label_D = MathTex("D", color=BLUE_A).move_to(domain.get_center() + DOWN * 0.8)
        label_f = MathTex("f(t, x)", font_size=30, color=WHITE).move_to(domain.get_center())

        # Boundary elements (Normal vector and Flux)
        boundary_point = domain.point_at_angle(PI/6)
        normal_vec = Arrow(start=boundary_point, end=boundary_point + UR * 0.8, buff=0, color=YELLOW, stroke_width=3)
        label_n = MathTex(r"\vec{n}", font_size=28, color=YELLOW).next_to(normal_vec, UR, buff=0.1)

        flux_vec = Arrow(start=boundary_point, end=boundary_point + RIGHT * 1.0 + UP * 0.2, buff=0, color=RED, stroke_width=3)
        label_F = MathTex(r"\vec{F}", font_size=28, color=RED).next_to(flux_vec, RIGHT, buff=0.1)

        visual_group = VGroup(domain, label_D, label_f, normal_vec, label_n, flux_vec, label_F)

        # ---- Math Elements (Right Side) ----
        # 1. Source Term Definition
        eq_source = MathTex(
            r"Q_3 = \int_{t_1}^{t_2} \int_D f \, dx \, dt",
            font_size=32
        )

        # 2. Conservation Balance
        eq_balance = MathTex(
            r"Q_1 = Q_2 + Q_3",
            font_size=36,
            color=GOLD
        )

        # 3. Final Integral Equation (Split for layout)
        # LHS: Change in quantity
        eq_final_lhs = MathTex(
            r"\int_D (u(t_2, x) - u(t_1, x))dx =",
            font_size=28
        )

        # RHS: Flux + Source
        eq_final_rhs_flux = MathTex(
            r"- \int_{t_1}^{t_2} \int_{\partial D} \vec{F} \cdot \vec{n} \, ds \, dt",
            font_size=28
        )
        eq_final_rhs_source = MathTex(
            r"+ \int_{t_1}^{t_2} \int_D f \, dx \, dt",
            font_size=28
        )

        # Group RHS parts vertically
        eq_final_rhs = VGroup(eq_final_rhs_flux, eq_final_rhs_source).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # Combine LHS and RHS
        eq_final_group = VGroup(eq_final_lhs, eq_final_rhs).arrange(RIGHT, aligned_edge=UP, buff=0.2)

        # Layout all math groups
        math_group = VGroup(eq_source, eq_balance, eq_final_group).arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        math_group.next_to(domain, RIGHT, buff=1.0).shift(UP * 0.5)

        # ---- Animations ----

        # 1. Draw Domain and Vectors
        self.play(
            DrawBorderThenFill(domain, run_time=1.5),
            FadeIn(label_D),
            Write(label_f)
        )
        self.play(
            GrowArrow(normal_vec), Write(label_n),
            GrowArrow(flux_vec), Write(label_F),
            run_time=1.0
        )

        # 2. Show Source Term Definition
        self.play(FadeIn(eq_source, shift=LEFT))

        # 3. Show Conservation Balance
        self.play(Write(eq_balance))

        # 4. Reveal Final Equation
        self.play(
            FadeIn(eq_final_group, shift=UP),
            run_time=1.5
        )

        # 5. Highlight Result
        box = SurroundingRectangle(eq_final_group, color=BLUE, buff=0.15)
        tag = MathTex("(1.1.3)", font_size=24, color=GRAY).next_to(box, DOWN, aligned_edge=RIGHT)

        self.play(
            Create(box),
            Write(tag)
        )
