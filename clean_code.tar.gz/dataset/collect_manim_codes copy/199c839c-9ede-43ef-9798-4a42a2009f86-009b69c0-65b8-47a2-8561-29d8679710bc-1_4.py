from manim import *

class BioengineeringRoleScene(Scene):
    def construct(self):

        # 1. 标题
        title = Text("生物医学与生物工程中的作用",
                    font_size=34,
                    color=WHITE)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 第一部分: 循环系统与生物流体力学
        topic1_text = Text(
            "人体的血液循环、呼吸过程均符合流体力学原理。",
            font_size=26
        )
        topic1_text.next_to(title_group, DOWN, buff=0.6).to_edge(LEFT, buff=0.8)

        applications1 = BulletedList(
            "分析心血管疾病发生机制",
            "优化人工心脏瓣膜或支架的设计",
            font_size=24, buff=0.2
        )
        applications1.next_to(topic1_text, DOWN, buff=0.3, aligned_edge=LEFT)

        group1_text = VGroup(topic1_text, applications1)

        # 循环系统可视化
        vessel = Annulus(inner_radius=0.4, outer_radius=0.5, color=RED_C, fill_opacity=0.8).stretch_to_fit_width(2.5)
        stent = Rectangle(height=0.8, width=0.8, color=BLUE_D, fill_opacity=0.5, stroke_width=2).move_to(vessel.get_center())
        visual1 = VGroup(vessel, stent).scale(0.9).next_to(group1_text, RIGHT, buff=0.8)

        self.play(FadeIn(group1_text, shift=DOWN*0.5), run_time=1.5)
        self.play(FadeIn(visual1, scale=0.5), run_time=1)

        # 3. 第二部分: 微流控与药物输送
        topic2_text = Text(
            "在医学成像与药物输送研究中，流体力学用于分析...",
            font_size=26
        )
        topic2_text.next_to(group1_text, DOWN, buff=0.8).align_to(topic1_text, LEFT)

        applications2 = BulletedList(
            "微流控芯片内的液体流动",
            "实现精确样本处理或药物混合",
            font_size=24, buff=0.2
        )
        applications2.next_to(topic2_text, DOWN, buff=0.3, aligned_edge=LEFT)

        group2_text = VGroup(topic2_text, applications2)

        # 微流控芯片可视化
        chip_body = Rectangle(width=2.5, height=1.2, color=TEAL_E, stroke_width=2)
        channel_in1 = Line(LEFT, ORIGIN).shift(UP*0.3)
        channel_in2 = Line(LEFT, ORIGIN).shift(DOWN*0.3)
        channel_out = Line(ORIGIN, RIGHT*1.2)
        channels = VGroup(channel_in1, channel_in2, channel_out).set_color(WHITE).set_stroke(width=5)
        visual2 = VGroup(chip_body, channels).scale(0.9).next_to(group2_text, RIGHT, buff=0.8)
        visual2.align_to(visual1, LEFT)

        self.play(FadeIn(group2_text, shift=DOWN*0.5), run_time=1.5)
        self.play(FadeIn(visual2, scale=0.5), run_time=1)

        # 芯片内流动动画
        dot1 = Dot(color=YELLOW).move_to(channel_in1.get_start())
        dot2 = Dot(color=CYAN).move_to(channel_in2.get_start())
        self.add(dot1, dot2)

        path1 = VMobject().set_points_as_corners([channel_in1.get_start(), channel_in1.get_end(), channel_out.get_end()])
        path2 = VMobject().set_points_as_corners([channel_in2.get_start(), channel_in2.get_end(), channel_out.get_end()])

        self.play(
            MoveAlongPath(dot1, path1),
            MoveAlongPath(dot2, path2),
            run_time=2.5
        )
