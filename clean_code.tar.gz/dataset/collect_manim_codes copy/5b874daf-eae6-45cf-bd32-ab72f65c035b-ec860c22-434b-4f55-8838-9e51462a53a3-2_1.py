from manim import *

class ImageDisplayExample(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("单张图片展示示例",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 图片展示部分
        # 加载占位符图片,用于展示讲义中提到的"测试图片0"的内容
        # 注意:实际运行时目录下需要有 placeholder.png
        try:
            image_obj = ImageMobject("placeholder.png")
            # 调整图片大小,防止过大遮挡
            image_obj.set_height(4)
        except:
            # 如果找不到图片,用一个带文字的方块代替,防止代码报错
            image_obj = Square(side_length=4, color=GRAY, fill_opacity=0.5)
            alt_text = Text("Placeholder Image", font_size=24, color=WHITE)
            image_obj = VGroup(image_obj, alt_text)

        # 将图片放置在标题下方
        image_obj.next_to(title_group, DOWN, buff=0.5)

        # 3. 添加装饰框
        # 使用 SurroundingRectangle 进行强调
        frame = SurroundingRectangle(image_obj, color=BLUE, buff=0.1, stroke_width=4)

        # 4. 添加说明文字
        description = Text("这是一张测试图片0",
                         font="AR PL UKai CN",
                         font_size=28,
                         color=LIGHT_GRAY)
        description.next_to(frame, DOWN, buff=0.3)

        # 5. 播放动画
        # 图片淡入
        self.play(FadeIn(image_obj, shift=UP), run_time=1.2)

        # 边框生成
        self.play(Create(frame), run_time=0.8)

        # 文字书写
        self.play(Write(description), run_time=1.0)

        # 停留片刻
