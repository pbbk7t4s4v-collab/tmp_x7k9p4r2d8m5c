from manim import *

class IntroductionAnalysis(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("探究课文第一段（引子）的作用",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("17", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 提出问题
        question = Text("问题：课文第一段（引子）能否删除？",
                       font="AR PL UKai CN",
                       font_size=28,
                       color=BLUE_A)
        question.next_to(title_group, DOWN, buff=0.8)

        self.play(Write(question))

        # 3. 给出核心结论
        answer = Text("不能",
                     font="AR PL UKai CN",
                     font_size=48,
                     color=RED,
                     weight=BOLD)
        answer.next_to(question, DOWN, buff=0.6)

        # 使用 SurroundingRectangle 进行强调
        answer_box = SurroundingRectangle(answer, color=YELLOW, buff=0.2, stroke_width=4)

        self.play(
            FadeIn(answer, scale=0.5),
            Create(answer_box)
        )

        # 4. 展示原因 (使用 VGroup 手动排列 Text，避免 BulletedList 的 LaTeX 中文问题)
        # 原因内容
        r1_text = "1. 引出说明的对象"
        r2_text = "2. 总领全文"
        r3_text = "3. 开头亲切活泼，符合读者阅读心理"

        reason_1 = Text(r1_text, font="AR PL UKai CN", font_size=26, color=WHITE)
        reason_2 = Text(r2_text, font="AR PL UKai CN", font_size=26, color=WHITE)
        reason_3 = Text(r3_text, font="AR PL UKai CN", font_size=26, color=WHITE)

        # 组合并排列
        reasons_group = VGroup(reason_1, reason_2, reason_3)
        reasons_group.arrange(DOWN, aligned_edge=LEFT, buff=0.4)

        # 将原因放置在答案下方
        reasons_group.next_to(answer_box, DOWN, buff=0.8)

        # 整体居中微调（防止视觉偏左）
        reasons_group.set_x(0)

        # 5. 逐步展示原因动画
        for reason in reasons_group:
            self.play(
                FadeIn(reason, shift=UP * 0.3), # 向上浮动淡入
                run_time=0.8
            )
