from manim import *
import numpy as np

class AudioGenAndFormats(Scene):
    def construct(self):

        # --- 标题设置 (根据模板) ---
        title = Text("音频生成原理与常见格式",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("16", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- 左侧内容:音频生成过程 (1.2.5.3) ---
        # 布局:左侧放置
        left_anchor = [-3.5, 1.5, 0]

        step1_title = Text("1. 音频生成过程:A/D转换", font="AR PL UKai CN", font_size=26, color=BLUE)
        step1_title.move_to(left_anchor)

        # 绘制坐标轴示意图
        axes = Axes(
            x_range=[0, 6.5],
            y_range=[-1.2, 1.2],
            x_length=4.5,
            y_length=2.5,
            axis_config={"include_tip": True, "color": GREY},
        ).scale(0.8).next_to(step1_title, DOWN, buff=0.5)

        # 模拟信号(正弦波)
        sine_wave = axes.plot(lambda x: np.sin(x), color=YELLOW)
        analog_label = Text("模拟信号", font="AR PL UKai CN", font_size=18, color=YELLOW)
        analog_label.next_to(sine_wave, UP, buff=0.1).shift(LEFT*1.5)

        # 采样点(垂直线段和点)
        samples = VGroup()
        for x in np.arange(0.5, 6.0, 0.5):
            y = np.sin(x)
            line = Line(axes.c2p(x, 0), axes.c2p(x, y), color=RED, stroke_width=2)
            dot = Dot(axes.c2p(x, y), color=RED, radius=0.06)
            samples.add(line, dot)

        sample_text = Text("采样 & 量化", font="AR PL UKai CN", font_size=18, color=RED)
        sample_text.next_to(axes, DOWN, buff=0.2)

        # --- 右侧内容:音频格式 (1.2.5.4) ---
        # 布局:右侧放置
        right_anchor = [3.5, 1.5, 0]

        step2_title = Text("2. 常见音频格式", font="AR PL UKai CN", font_size=26, color=GREEN)
        step2_title.move_to(right_anchor)

        # 格式列表
        # 使用VGroup手动排列,避免BulletList的潜在问题
        fmt_wav = Text("WAV: 无损未压缩 (原始波形)", font="AR PL UKai CN", font_size=20)
        fmt_mp3 = Text("MP3: 有损压缩 (去除听不到的声音)", font="AR PL UKai CN", font_size=20)
        fmt_flac = Text("FLAC: 无损压缩 (保留音质)", font="AR PL UKai CN", font_size=20)

        fmt_group = VGroup(fmt_wav, fmt_mp3, fmt_flac)
        fmt_group.arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        fmt_group.next_to(step2_title, DOWN, buff=0.8)

        # 给右侧加一个框
        rect = SurroundingRectangle(fmt_group, color=GREEN, buff=0.3)

        # --- 动画展示流程 ---

        # 1. 展示左侧:模拟信号
        self.play(FadeIn(step1_title))
        self.play(Create(axes), Create(sine_wave), Write(analog_label), run_time=2)

        # 2. 展示左侧:采样过程
        self.play(
            Create(samples, lag_ratio=0.1),
            Write(sample_text),
            run_time=2
        )

        # 3. 展示右侧:格式列表
        self.play(FadeIn(step2_title))
        self.play(
            AnimationGroup(
                Write(fmt_wav),
                Write(fmt_mp3),
                Write(fmt_flac),
                lag_ratio=0.5
            ),
            Create(rect),
            run_time=3
        )
