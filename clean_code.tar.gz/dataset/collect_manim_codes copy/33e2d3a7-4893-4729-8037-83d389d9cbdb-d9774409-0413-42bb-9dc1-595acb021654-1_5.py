from manim import *

class OnlineFuelProcessing(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("2.3 在线燃料处理与嬗变",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧内容：氦气鼓泡（对应讲义第一点）
        # 按照Planner建议加载图片2
        img_bubble = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/33e2d3a7-4893-4729-8037-83d389d9cbdb/d9774409-0413-42bb-9dc1-595acb021654/pictures/1_5/2.png") # 这里期望是一张展示氦气鼓泡法去除气态裂变产物的微观原理示意图，画面中表现液体熔盐中氦气气泡上升，并吸附带走微小的有害气体粒子（如氙-135），风格为微观透视的教学演示风
        img_bubble.height = 3.0
        img_bubble.to_edge(LEFT, buff=1.0).shift(DOWN * 0.2)

        # 左侧文字说明
        text_bubble_title = Text("氦气鼓泡除毒", font="AR PL UKai CN", font_size=24, color=YELLOW)
        text_bubble_title.next_to(img_bubble, UP, buff=0.2)

        text_bubble_desc = VGroup(
            Text("去除中子毒物 (氙-135)", font="AR PL UKai CN", font_size=20),
            Text("解除“碘坑效应”限制", font="AR PL UKai CN", font_size=20)
        ).arrange(DOWN, buff=0.15).next_to(img_bubble, DOWN, buff=0.2)

        group_left = Group(text_bubble_title, img_bubble, text_bubble_desc)

        # 3. 右侧内容：化学分离（对应讲义第二点）
        # 按照Planner建议加载图片1
        img_bypass = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/33e2d3a7-4893-4729-8037-83d389d9cbdb/d9774409-0413-42bb-9dc1-595acb021654/pictures/1_5/1.png") # 这里期望是一张熔盐堆在线燃料处理系统的流程示意图，画面需要展示主回路之外的旁路系统（Bypass System），包含“氦气鼓泡”、“氟化挥发”和“真空蒸馏”等处理环节的抽象设备连接关系，风格为扁平化的工程科技风
        img_bypass.height = 3.0
        img_bypass.to_edge(RIGHT, buff=1.0).shift(DOWN * 0.2)

        # 调整两图垂直对齐
        img_bypass.match_y(img_bubble)

        # 右侧文字说明
        text_bypass_title = Text("旁路化学分离", font="AR PL UKai CN", font_size=24, color=BLUE)
        text_bypass_title.next_to(img_bypass, UP, buff=0.2)

        text_bypass_desc = VGroup(
            Text("氟化挥发：分离铀", font="AR PL UKai CN", font_size=20),
            Text("真空蒸馏：分离裂变产物", font="AR PL UKai CN", font_size=20),
            Text("实现核燃料闭式循环", font="AR PL UKai CN", font_size=20, color=GREEN)
        ).arrange(DOWN, buff=0.15).next_to(img_bypass, DOWN, buff=0.2)

        group_right = Group(text_bypass_title, img_bypass, text_bypass_desc)

        # 4. 动画展示流程

        # 展示左侧：在线处理原理
        self.play(FadeIn(img_bubble, shift=RIGHT), Write(text_bubble_title))
        self.play(Write(text_bubble_desc))

        # 添加左侧强调框
        rect_left = SurroundingRectangle(group_left, color=YELLOW, buff=0.15)
        self.play(Create(rect_left))

        # 展示右侧：具体工艺流程
        self.play(FadeIn(img_bypass, shift=LEFT), Write(text_bypass_title))
        self.play(Write(text_bypass_desc))

        # 添加右侧强调框
        rect_right = SurroundingRectangle(group_right, color=BLUE, buff=0.15)
        self.play(Create(rect_right))
