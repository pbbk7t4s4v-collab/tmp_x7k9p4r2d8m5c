from manim import *
import numpy as np

class ContourAndGradient(Scene):
    def construct(self):

        # 1. 标题设置 (符合模板要求)
        title = Text("多元函数的等高线与梯度",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局规划：左侧为几何示意图，右侧为概念说明

        # --- 左侧：等高线示意图 ---
        # 创建同心圆代表等高线 f(x,y) = x^2 + y^2
        center_pos = LEFT * 3.5 + DOWN * 0.5
        c1 = Circle(radius=1.0, color=BLUE_C).move_to(center_pos)
        c2 = Circle(radius=2.0, color=BLUE_B).move_to(center_pos)
        c3 = Circle(radius=3.0, color=BLUE_A).move_to(center_pos)

        contours = VGroup(c1, c2, c3)

        # 标注函数值 (模拟山坡，外圈值大)
        l1 = MathTex("f=10", font_size=20, color=BLUE_C).move_to(c1.get_top() + DOWN * 0.3)
        l2 = MathTex("f=20", font_size=20, color=BLUE_B).move_to(c2.get_top() + DOWN * 0.3)
        l3 = MathTex("f=30", font_size=20, color=BLUE_A).move_to(c3.get_top() + DOWN * 0.3)
        labels = VGroup(l1, l2, l3)

        # 选取中间等高线上的一点 P
        angle = 45 * DEGREES
        p_offset = np.array([2.0 * np.cos(angle), 2.0 * np.sin(angle), 0])
        p_point = Dot(center_pos + p_offset, color=YELLOW)
        p_label = MathTex("P", font_size=24, color=YELLOW).next_to(p_point, DOWN, buff=0.1)

        # 切线 (Tangent)
        tangent_vec = np.array([-np.sin(angle), np.cos(angle), 0])
        tangent_line = Line(
            p_point.get_center() - tangent_vec * 1.5,
            p_point.get_center() + tangent_vec * 1.5,
            color=GREY, stroke_width=2
        ).set_opacity(0.8)
        tangent_text = Text("切线", font="AR PL UKai CN", font_size=18, color=GREY).next_to(tangent_line, UP, buff=0.05)

        # 梯度 (Gradient) - 垂直于切线，指向数值增长方向(外圈)
        grad_vec = np.array([np.cos(angle), np.sin(angle), 0])
        gradient_arrow = Arrow(
            start=p_point.get_center(),
            end=p_point.get_center() + grad_vec * 1.5,
            color=RED, buff=0, stroke_width=4, max_tip_length_to_length_ratio=0.2
        )
        grad_text = MathTex(r"\nabla f", color=RED, font_size=28).next_to(gradient_arrow, UP, buff=0.1)

        # 垂直标记
        right_angle = RightAngle(
            Line(p_point.get_center(), p_point.get_center() + tangent_vec),
            Line(p_point.get_center(), p_point.get_center() + grad_vec),
            length=0.2, quadrant=(-1, 1), stroke_width=2, color=WHITE
        )

        # --- 右侧：文字说明 ---
        text_group = VGroup()

        # 1. 定义
        item1 = VGroup(
            MathTex(r"\bullet", color=BLUE),
            Text(" 等高线：函数值常数的集合", font="AR PL UKai CN", font_size=24)
        ).arrange(RIGHT, buff=0.2)

        # 2. 垂直性质
        item2 = VGroup(
            MathTex(r"\bullet", color=YELLOW),
            Text(" 梯度方向与等高线垂直", font="AR PL UKai CN", font_size=24)
        ).arrange(RIGHT, buff=0.2)

        # 3. 增长性质
        item3 = VGroup(
            MathTex(r"\bullet", color=RED),
            Text(" 指向函数增长最快的方向", font="AR PL UKai CN", font_size=24)
        ).arrange(RIGHT, buff=0.2)

        text_group.add(item1, item2, item3)
        text_group.arrange(DOWN, aligned_edge=LEFT, buff=0.6)
        text_group.to_edge(RIGHT, buff=1.0).shift(UP * 0.5)

        # 强调框
        box = SurroundingRectangle(text_group, color=WHITE, buff=0.3, corner_radius=0.1)

        # --- 动画流程 ---

        # 1. 显示等高线和定义
        self.play(Create(contours), FadeIn(labels), run_time=1.5)
        self.play(FadeIn(item1), Create(box), run_time=1)

        # 2. 显示点P和切线
        self.play(FadeIn(p_point), FadeIn(p_label))
        self.play(Create(tangent_line), FadeIn(tangent_text))

        # 3. 强调垂直关系
        self.play(FadeIn(item2))
        self.play(Create(right_angle))

        # 4. 显示梯度向量和增长方向
        self.play(GrowArrow(gradient_arrow), Write(grad_text))
        self.play(FadeIn(item3))
