from manim import *

class PrivacyLevels(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("隐私的三个层面",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("24", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 简要说明文字
        intro_text = Text("隐私是多维度概念：涵盖个人、社会与数据",
                         font_size=24,
                         font="AR PL UKai CN",
                         color=LIGHT_GRAY)
        intro_text.next_to(title_line, DOWN, buff=0.4)
        self.play(FadeIn(intro_text, shift=DOWN * 0.2))

        # 3. 核心内容可视化
        # 定义三个层面的元素

        # 3.1 个人隐私 (Personal)
        p1_icon = VGroup(
            Circle(radius=0.4, color=BLUE_C, fill_opacity=0.3),
            Dot(color=WHITE)
        )
        p1_title = Text("个人隐私", font_size=26, font="AR PL UKai CN", color=BLUE_C)
        p1_desc = Text("个人空间", font_size=20, font="AR PL UKai CN", color=GREY_B)

        group1 = VGroup(p1_icon, p1_title, p1_desc).arrange(DOWN, buff=0.25)
        box1 = SurroundingRectangle(group1, color=BLUE_C, buff=0.2)

        # 3.2 领域隐私 (Domain/Territorial)
        p2_icon = Square(side_length=0.8, color=GREEN_C, fill_opacity=0.3)
        p2_title = Text("领域隐私", font_size=26, font="AR PL UKai CN", color=GREEN_C)
        p2_desc = Text("社会角色", font_size=20, font="AR PL UKai CN", color=GREY_B)

        group2 = VGroup(p2_icon, p2_title, p2_desc).arrange(DOWN, buff=0.25)
        box2 = SurroundingRectangle(group2, color=GREEN_C, buff=0.2)

        # 3.3 信息隐私 (Information)
        p3_icon = VGroup(
            Line(LEFT * 0.4, RIGHT * 0.4, color=YELLOW_C),
            Line(LEFT * 0.4, RIGHT * 0.4, color=YELLOW_C),
            Line(LEFT * 0.4, RIGHT * 0.4, color=YELLOW_C)
        ).arrange(DOWN, buff=0.15)
        p3_title = Text("信息隐私", font_size=26, font="AR PL UKai CN", color=YELLOW_C)
        p3_desc = Text("信息流动", font_size=20, font="AR PL UKai CN", color=GREY_B)

        group3 = VGroup(p3_icon, p3_title, p3_desc).arrange(DOWN, buff=0.25)
        box3 = SurroundingRectangle(group3, color=YELLOW_C, buff=0.2)

        # 布局排列
        main_content = VGroup(
            VGroup(group1, box1),
            VGroup(group2, box2),
            VGroup(group3, box3)
        ).arrange(RIGHT, buff=1.0)

        main_content.move_to(ORIGIN).shift(DOWN * 0.5)

        # 4. 动画展示
        # 依次展示三个层面
        self.play(
            Create(box1),
            FadeIn(group1, shift=UP),
            run_time=0.8
        )

        self.play(
            Create(box2),
            FadeIn(group2, shift=UP),
            run_time=0.8
        )

        self.play(
            Create(box3),
            FadeIn(group3, shift=UP),
            run_time=0.8
        )

        # 5. 连接关系 (表示多维度统一)
        brace = Brace(main_content, DOWN, buff=0.2)
        brace_text = Text("构成可信AI的隐私保护基石", font_size=22, font="AR PL UKai CN", color=WHITE)
        brace_text.next_to(brace, DOWN, buff=0.1)

        self.play(
            GrowFromCenter(brace),
            Write(brace_text),
            run_time=1.0
        )
