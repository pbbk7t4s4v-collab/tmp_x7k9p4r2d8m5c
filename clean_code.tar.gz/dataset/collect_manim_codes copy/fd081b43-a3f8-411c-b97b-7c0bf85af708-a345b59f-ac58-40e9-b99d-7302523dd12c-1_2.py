from manim import *

class EffectiveDemandPrinciple(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("有效需求原则：产出与就业的决定",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心原则展示 (左侧区域)
        # ---------------------------------------------------------

        # 核心公式概念: 总产出 <--- 总需求
        output_text = Text("总产出", font="AR PL UKai CN", color=BLUE, font_size=36)
        arrow = Text("←", color=WHITE, font="AR PL UKai CN", font_size=36)
        demand_text = Text("总需求", font="AR PL UKai CN", color=GREEN, font_size=36)

        principle_group = VGroup(output_text, arrow, demand_text).arrange(RIGHT, buff=0.5)
        principle_group.shift(UP * 0.5 + LEFT * 3)

        # 强调：不是供给能力
        not_supply_text = Text("× 非供给能力决定", font="AR PL UKai CN", color=RED, font_size=24)
        not_supply_text.next_to(principle_group, DOWN, buff=0.3)

        # 企业行为逻辑
        firm_label = Text("企业行为：", font="AR PL UKai CN", color=YELLOW, font_size=28)
        firm_action = Text("预期需求 ➔ 安排生产", font="AR PL UKai CN", color=WHITE, font_size=26)
        firm_group = VGroup(firm_label, firm_action).arrange(RIGHT, buff=0.2)
        firm_group.next_to(not_supply_text, DOWN, buff=0.8)
        firm_group.align_to(principle_group, LEFT)

        # 框选左侧内容
        left_box = SurroundingRectangle(VGroup(principle_group, not_supply_text, firm_group), color=BLUE_C, buff=0.3)
        left_label = Text("核心机制", font="AR PL UKai CN", font_size=20, color=BLUE_C)
        left_label.next_to(left_box, UP, aligned_edge=LEFT)

        # 动画展示左侧
        self.play(FadeIn(left_label), Create(left_box))
        self.play(
            Write(output_text),
            Write(arrow),
            Write(demand_text)
        )
        self.play(Write(not_supply_text))
        self.play(Write(firm_group))

        # ---------------------------------------------------------
        # 3. 非充分就业均衡可视化 (右侧区域)
        # ---------------------------------------------------------

        # 绘制一个表示“充分就业/潜在产能”的容器（虚线框）
        full_capacity_rect = Rectangle(height=4, width=2, color=GREY)
        full_capacity_rect.shift(RIGHT * 3 + DOWN * 0.5)

        full_label = Text("充分就业", font="AR PL UKai CN", font_size=22, color=GREY)
        full_label.next_to(full_capacity_rect, UP)

        # 绘制一个表示“实际就业/有效需求”的填充块（实心）
        # 假设有效需求不足，只占70%
        actual_level = 0.7 * 4
        actual_rect = Rectangle(height=actual_level, width=2, color=GREEN, fill_opacity=0.6, stroke_width=0)
        actual_rect.align_to(full_capacity_rect, DOWN)
        actual_rect.align_to(full_capacity_rect, LEFT) # 确保对齐

        actual_label = Text("实际就业", font="AR PL UKai CN", font_size=22, color=GREEN)
        actual_label.move_to(actual_rect.get_center())

        # 标注差距：失业
        gap_brace = Brace(full_capacity_rect, RIGHT)
        gap_text = Text("长期非充分\n就业状态", font="AR PL UKai CN", font_size=22, color=RED)
        gap_text.next_to(gap_brace, RIGHT)

        # 动画展示右侧
        self.play(Create(full_capacity_rect), Write(full_label))
        self.play(
            GrowFromEdge(actual_rect, DOWN),
            FadeIn(actual_label)
        )
        self.play(
            GrowFromCenter(gap_brace),
            Write(gap_text)
        )

        # ---------------------------------------------------------
        # 4. 结尾停留
        # ---------------------------------------------------------
