from manim import *

class FluidMechanicsValueScene(Scene):
    def construct(self):

        self.camera.background_color = "#1E1E1E"

        # 1. 制作标题
        title = Text("流体力学的价值与意义",
                    font_size=34,
                    color=WHITE)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 展示流体力学的核心作用
        intro_text = Text(
            "流体力学的作用不仅是解释与预测流动现象，更在于...",
            font_size=28
        ).next_to(title_line, DOWN, buff=0.5)
        self.play(FadeIn(intro_text, shift=DOWN*0.5), run_time=1.5)

        # 3. 列出其推动价值
        value_points = BulletedList(
            "推动科学进步",
            "推动工程创新",
            "推动社会经济发展",
            font_size=32,
            buff=0.4
        ).next_to(intro_text, DOWN, buff=0.6).shift(LEFT * 0.5)

        for item in value_points:
            self.play(FadeIn(item, shift=RIGHT), run_time=0.7)

        # 4. 强调其作为核心技能的重要性
        conclusion_text = Text(
            "掌握流体力学原理是现代科技工作者的核心技能",
            font_size=30
        ).to_edge(DOWN, buff=1)

        self.play(Write(conclusion_text), run_time=2)

        # 5. 高亮“核心技能”
        core_skill = Text("核心技能", font_size=30, color=WHITE)
        core_skill.move_to(conclusion_text[-4:].get_center())
        highlight_box = SurroundingRectangle(
            core_skill,
            color=YELLOW,
            buff=0.1,
            corner_radius=0.05
        )
        self.play(Create(highlight_box), run_time=1)
