from manim import *

class NVNMDChipIntro(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("高度整合算力与专用芯片",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("26", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心芯片展示 (左侧)
        # 芯片主体
        chip_rect = Rectangle(height=3.5, width=4.5, color=BLUE, fill_opacity=0.2)
        chip_name = Text("NVNMD", font_size=40, weight=BOLD, color=BLUE_A)
        chip_desc = Text("存算一体分子动力学芯片", font="AR PL UKai CN", font_size=24, color=WHITE)

        # 布局芯片内部文字
        chip_name.move_to(chip_rect.get_center() + UP * 0.5)
        chip_desc.next_to(chip_name, DOWN, buff=0.3)

        # 精度约束说明
        precision_text = Text("前提：保持第一性原理精度", font="AR PL UKai CN", font_size=20, color=GREY_B)
        precision_text.next_to(chip_desc, DOWN, buff=0.5)

        chip_group = VGroup(chip_rect, chip_name, chip_desc, precision_text)
        chip_group.shift(LEFT * 2.5 + DOWN * 0.5)

        self.play(
            Create(chip_rect),
            Write(chip_name),
            FadeIn(chip_desc)
        )
        self.play(Write(precision_text, run_time=1))

        # 3. 性能指标展示 (右侧)
        # 速度提升
        speed_icon = Text("速度", font="AR PL UKai CN", font_size=32, color=GREEN)
        speed_arrow = Arrow(start=DOWN, end=UP, color=GREEN, buff=0).scale(0.6)
        speed_val = MathTex(r"10^1 \sim 10^2", color=GREEN, font_size=36)
        speed_unit = Text("倍提升", font="AR PL UKai CN", font_size=24, color=GREEN)

        speed_group = VGroup(speed_icon, speed_arrow, speed_val, speed_unit)
        speed_group.arrange(RIGHT, buff=0.2)
        speed_group.move_to(RIGHT * 3 + UP * 1)

        # 能耗降低
        energy_icon = Text("能耗", font="AR PL UKai CN", font_size=32, color=YELLOW)
        energy_arrow = Arrow(start=UP, end=DOWN, color=YELLOW, buff=0).scale(0.6)
        energy_val = MathTex(r"10^2 \sim 10^3", color=YELLOW, font_size=36)
        energy_unit = Text("倍降低", font="AR PL UKai CN", font_size=24, color=YELLOW)

        energy_group = VGroup(energy_icon, energy_arrow, energy_val, energy_unit)
        energy_group.arrange(RIGHT, buff=0.2)
        energy_group.next_to(speed_group, DOWN, buff=1.5, aligned_edge=LEFT)

        # 连接箭头
        arrow_speed = Arrow(chip_rect.get_right(), speed_group.get_left(), buff=0.2, color=GREY)
        arrow_energy = Arrow(chip_rect.get_right(), energy_group.get_left(), buff=0.2, color=GREY)

        # 4. 动画展示性能指标
        self.play(
            GrowArrow(arrow_speed),
            FadeIn(speed_group, shift=RIGHT)
        )

        self.play(
            GrowArrow(arrow_energy),
            FadeIn(energy_group, shift=RIGHT)
        )

        # 5. 强调框
        highlight_rect = SurroundingRectangle(VGroup(speed_group, energy_group), color=WHITE, buff=0.2)
        self.play(Create(highlight_rect, run_time=1))
