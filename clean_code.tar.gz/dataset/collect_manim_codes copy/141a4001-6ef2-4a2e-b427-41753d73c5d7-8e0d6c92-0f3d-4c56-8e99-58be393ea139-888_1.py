from manim import *

class CoqIntroduction(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("形式化验证：从自然语言到逻辑表述",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 左侧：自然语言描述
        nl_title = Text("自然语言描述", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        nl_content = Text(
            "对于任意自然数 n，\n n 加 0 恒等于 n",
            font="AR PL UKai CN",
            font_size=28,
            line_spacing=1.2
        )
        nl_group = VGroup(nl_title, nl_content).arrange(DOWN, buff=0.4)
        nl_group.shift(LEFT * 3.5 + UP * 0.5)

        nl_box = SurroundingRectangle(nl_group, color=BLUE, buff=0.3)

        # 右侧：Coq 代码描述
        coq_title = Text("Coq 形式化语言", font="AR PL UKai CN", font_size=24, color=GREEN_A)
        # 模拟代码高亮
        coq_content = Text(
            "forall n : nat,\n  n + 0 = n .",
            font="AR PL UKai CN", # 保持字体一致
            font_size=28,
            line_spacing=1.2,
            t2c={"forall": ORANGE, "nat": YELLOW, "n": WHITE, "0": PURPLE}
        )
        coq_group = VGroup(coq_title, coq_content).arrange(DOWN, buff=0.4)
        coq_group.shift(RIGHT * 3.5 + UP * 0.5)

        coq_box = SurroundingRectangle(coq_group, color=GREEN, buff=0.3)

        # 中间：转化箭头
        arrow = Arrow(
            start=nl_box.get_right(),
            end=coq_box.get_left(),
            buff=0.2,
            color=YELLOW
        )
        trans_text = Text("精确转化", font="AR PL UKai CN", font_size=20, color=YELLOW)
        trans_text.next_to(arrow, UP, buff=0.1)

        # 底部：核心概念总结
        summary_text = Text(
            "通过形式化，消除自然语言的歧义性",
            font="AR PL UKai CN",
            font_size=26,
            color=LIGHT_GREY
        )
        summary_text.next_to(VGroup(nl_box, coq_box), DOWN, buff=1.0)

        # 3. 动画流程
        # 展示左侧自然语言
        self.play(
            FadeIn(nl_group, shift=RIGHT),
            Create(nl_box, run_time=1)
        )

        # 展示转化过程
        self.play(
            GrowArrow(arrow),
            Write(trans_text)
        )

        # 展示右侧形式化代码
        self.play(
            FadeIn(coq_group, shift=LEFT),
            Create(coq_box, run_time=1)
        )

        # 强调总结
        self.play(Write(summary_text))
