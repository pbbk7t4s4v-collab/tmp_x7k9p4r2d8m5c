from manim import *

class CNNInstances(Scene):
    def construct(self):

        # ---------------------------------------------------------------------
        # 1. 标题设置
        # ---------------------------------------------------------------------
        title = Text("CNN 经典实例应用：AlexNet, GoogleNet, ResNet",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------------------
        # 2. 内容构建 - 三个主要网络架构
        # ---------------------------------------------------------------------
        # AlexNet 部分
        alex_name = Text("AlexNet", font="AR PL UKai CN", font_size=32, color=BLUE_A)
        alex_desc = Text("2012年 冠军\n深度学习突破", font="AR PL UKai CN", font_size=20, color=GRAY_B, line_spacing=1.2)
        alex_desc.next_to(alex_name, DOWN, buff=0.2)
        alex_group = VGroup(alex_name, alex_desc)
        alex_box = SurroundingRectangle(alex_group, color=BLUE, buff=0.2, corner_radius=0.2)
        alex_full = VGroup(alex_box, alex_group)

        # GoogleNet 部分
        google_name = Text("GoogleNet", font="AR PL UKai CN", font_size=32, color=GREEN_A)
        google_desc = Text("2014年 冠军\nInception 模块", font="AR PL UKai CN", font_size=20, color=GRAY_B, line_spacing=1.2)
        google_desc.next_to(google_name, DOWN, buff=0.2)
        google_group = VGroup(google_name, google_desc)
        google_box = SurroundingRectangle(google_group, color=GREEN, buff=0.2, corner_radius=0.2)
        google_full = VGroup(google_box, google_group)

        # ResNet 部分
        resnet_name = Text("ResNet", font="AR PL UKai CN", font_size=32, color=RED_A)
        resnet_desc = Text("2015年 冠军\n残差连接(Residual)", font="AR PL UKai CN", font_size=20, color=GRAY_B, line_spacing=1.2)
        resnet_desc.next_to(resnet_name, DOWN, buff=0.2)
        resnet_group = VGroup(resnet_name, resnet_desc)
        resnet_box = SurroundingRectangle(resnet_group, color=RED, buff=0.2, corner_radius=0.2)
        resnet_full = VGroup(resnet_box, resnet_group)

        # ---------------------------------------------------------------------
        # 3. 布局排版
        # ---------------------------------------------------------------------
        # 将三个模块水平排列
        models_group = VGroup(alex_full, google_full, resnet_full).arrange(RIGHT, buff=1.2)
        models_group.move_to(ORIGIN).shift(DOWN * 0.5)

        # 添加连接箭头表示演进
        arrow1 = Arrow(start=alex_box.get_right(), end=google_box.get_left(), color=YELLOW, buff=0.1, max_tip_length_to_length_ratio=0.15)
        arrow2 = Arrow(start=google_box.get_right(), end=resnet_box.get_left(), color=YELLOW, buff=0.1, max_tip_length_to_length_ratio=0.15)

        # ---------------------------------------------------------------------
        # 4. 动画展示
        # ---------------------------------------------------------------------
        # 逐步显示各个网络
        self.play(FadeIn(alex_full, shift=UP), run_time=1)

        self.play(
            GrowArrow(arrow1),
            FadeIn(google_full, shift=UP),
            run_time=1
        )

        self.play(
            GrowArrow(arrow2),
            FadeIn(resnet_full, shift=UP),
            run_time=1
        )

        # ---------------------------------------------------------------------
        # 5. 强调关键特征
        # ---------------------------------------------------------------------
        self.play(
            Indicate(alex_desc, color=BLUE),
            Indicate(google_desc, color=GREEN),
            Indicate(resnet_desc, color=RED),
            run_time=1.5
        )

        # ---------------------------------------------------------------------
        # 6. 结尾
        # ---------------------------------------------------------------------
