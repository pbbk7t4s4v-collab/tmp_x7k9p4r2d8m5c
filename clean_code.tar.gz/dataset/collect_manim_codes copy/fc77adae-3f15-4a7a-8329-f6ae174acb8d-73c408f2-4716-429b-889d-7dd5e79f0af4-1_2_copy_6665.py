from manim import *

class FluidDynamicsScene(Scene):
    def construct(self):
        self.camera.background_color = "#1E1E1E"

        # Title setup
        title = Text("Fluid Dynamics: Analyzing & Predicting Natural Phenomena",
                     font_size=34,
                     color=WHITE,
                     weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.2)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        # Animate title
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Core concept
        intro_text = Text(
            "Fluid dynamics provides the theoretical basis for natural flow phenomena.",
            font_size=28,
            color=WHITE
        ).next_to(title_group, DOWN, buff=0.5)
        self.play(FadeIn(intro_text, shift=DOWN*0.5))

        # Key Equation: Navier-Stokes
        equation_label = Text("Key Tool: Navier-Stokes Equations", font_size=26, color=BLUE_C, weight=BOLD)
        navier_stokes_eq = MathTex(
            r"\rho \left( \frac{\partial \mathbf{v}}{\partial t} + \mathbf{v} \cdot \nabla \mathbf{v} \right) = -\nabla p + \mu \nabla^2 \mathbf{v} + \mathbf{f}",
            font_size=40
        )
        equation_group = VGroup(equation_label, navier_stokes_eq).arrange(DOWN, buff=0.3)
        equation_group.next_to(intro_text, DOWN, buff=0.7).to_edge(LEFT, buff=1.0)

        self.play(Write(equation_group))

        # Applications
        applications_label = Text("Primary Applications:", font_size=26, color=GREEN_C, weight=BOLD)
        applications_list = BulletedList(
            "Atmospheric Dynamics (wind, typhoons)",
            "Oceanography (waves, tides)",
            "Weather Forecasting",
            "Disaster Prevention",
            font_size=26,
            buff=0.2
        )
        applications_group = VGroup(applications_label, applications_list).arrange(DOWN, buff=0.3, alignment=LEFT)
        applications_group.next_to(equation_group, RIGHT, buff=1.5, aligned_edge=UP)

        self.play(FadeIn(applications_label))
        self.play(Write(applications_list), run_time=3)

        # Highlight practical value
        highlight_box = SurroundingRectangle(applications_list.submobjects[-2:], color=YELLOW, buff=0.1)
        highlight_text = Text("Direct Practical Value", font_size=22, color=YELLOW).next_to(highlight_box, DOWN, buff=0.2)

        self.play(Create(highlight_box))
        self.play(Write(highlight_text))
