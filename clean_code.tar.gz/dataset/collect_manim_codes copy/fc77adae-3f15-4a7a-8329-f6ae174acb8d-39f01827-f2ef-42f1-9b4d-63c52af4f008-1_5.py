from manim import *

class FluidDynamicsInLifeSciences(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Fluid Dynamics in Life Sciences",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Introduction of key areas
        intro_text = Text("Key application areas include:", font_size=28).next_to(title_group, DOWN, buff=0.5)
        self.play(FadeIn(intro_text, shift=DOWN))

        # 3. Create two columns for applications
        # Cardiovascular System Column
        cardio_title = Text("Cardiovascular System", font_size=28, color=RED_C)
        cardio_items = BulletedList(
            "Blood flow simulation",
            "Cardiovascular disease research",
            "Design of artificial hearts and stents",
            font_size=26
        ).next_to(cardio_title, DOWN, buff=0.3, aligned_edge=LEFT)
        cardio_group = VGroup(cardio_title, cardio_items)

        # Respiratory System Column
        respiratory_title = Text("Respiratory System", font_size=28, color=BLUE_C)
        respiratory_items = BulletedList(
            "Airflow in trachea and alveoli",
            "Respiratory disease prevention",
            "Understanding aerodynamic properties",
            font_size=26
        ).next_to(respiratory_title, DOWN, buff=0.3, aligned_edge=LEFT)
        respiratory_group = VGroup(respiratory_title, respiratory_items)

        # 4. Arrange and display columns
        app_groups = VGroup(cardio_group, respiratory_group).arrange(RIGHT, buff=1.0)
        app_groups.next_to(intro_text, DOWN, buff=0.5)

        self.play(
            LaggedStart(
                Write(cardio_title),
                Write(respiratory_title),
                lag_ratio=0.5
            )
        )
        self.play(
            LaggedStart(
                FadeIn(cardio_items, shift=UP),
                FadeIn(respiratory_items, shift=UP),
                lag_ratio=0.7,
                run_time=3
            )
        )

        # 5. Highlight the groups
        cardio_box = SurroundingRectangle(cardio_group, color=RED_C, buff=0.2)
        respiratory_box = SurroundingRectangle(respiratory_group, color=BLUE_C, buff=0.2)

        self.play(
            Create(cardio_box),
            Create(respiratory_box),
            run_time=1.5
        )
