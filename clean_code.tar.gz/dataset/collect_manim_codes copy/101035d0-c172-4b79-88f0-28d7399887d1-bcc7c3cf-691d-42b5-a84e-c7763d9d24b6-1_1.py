from manim import *

class UnitFiveFunClubs(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("Unit 5 Warm-up: 社团招新",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局设计 (左右对照布局)
        # ---------------------------------------------------------

        # 数据定义：(社团名称, 学生活动)
        club_data = [
            ("Robotics Club (机器人社团)", "Making robots (制作机器人)"),
            ("Art Club (美术社团)", "Drawing pictures (画画)"),
            ("Science Club (科学社团)", "Doing experiments (做实验)"),
            ("Chess Club (象棋社团)", "Playing chess (下象棋)"),
            ("Ping-pong Club (乒乓球社团)", "Playing ping-pong (打乒乓球)"),
        ]

        # 创建列容器
        left_col = VGroup()
        arrows = VGroup()
        right_col = VGroup()

        # 字体配置
        content_font = "AR PL UKai CN"
        font_sz = 26

        for club_text, act_text in club_data:
            # 左侧：社团名
            l_item = Text(club_text, font=content_font, font_size=font_sz, color=BLUE_A)
            left_col.add(l_item)

            # 中间：箭头
            arrow = Arrow(start=LEFT, end=RIGHT, buff=0.1, color=GREY).set_length(0.8)
            arrows.add(arrow)

            # 右侧：活动
            r_item = Text(act_text, font=content_font, font_size=font_sz, color=YELLOW_A)
            right_col.add(r_item)

        # ---------------------------------------------------------
        # 3. 排版与对齐 (Center Spine Layout)
        # ---------------------------------------------------------

        # 垂直排列各列
        left_col.arrange(DOWN, buff=0.6, aligned_edge=RIGHT)
        arrows.arrange(DOWN, buff=0.6)
        right_col.arrange(DOWN, buff=0.6, aligned_edge=LEFT)

        # 组合并居中
        # 箭头居中,文字分布在两侧
        arrows.move_to(ORIGIN).shift(DOWN * 0.3) # 稍微下移避开标题
        left_col.next_to(arrows, LEFT, buff=0.3)
        right_col.next_to(arrows, RIGHT, buff=0.3)

        # ---------------------------------------------------------
        # 4. 动画展示
        # ---------------------------------------------------------

        # 逐行显示内容
        for i in range(len(club_data)):
            # 组合每一行的元素进行动画
            row_group = VGroup(left_col[i], arrows[i], right_col[i])

            self.play(
                FadeIn(left_col[i], shift=RIGHT * 0.5),
                GrowArrow(arrows[i]),
                FadeIn(right_col[i], shift=LEFT * 0.5),
                run_time=0.8
            )

        # ---------------------------------------------------------
        # 5. 总结与强调
        # ---------------------------------------------------------

        # 使用矩形框强调整体列表
        full_group = VGroup(left_col, arrows, right_col)
        box = SurroundingRectangle(full_group, color=TEAL, buff=0.2, stroke_width=2)

        self.play(Create(box), run_time=1)
