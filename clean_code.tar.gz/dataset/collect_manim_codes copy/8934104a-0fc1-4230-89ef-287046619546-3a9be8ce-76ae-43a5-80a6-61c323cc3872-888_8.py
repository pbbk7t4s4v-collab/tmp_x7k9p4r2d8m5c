from manim import *

class GNNBasicIdea(Scene):
    def construct(self):

        # 1. 标题部分 - 严格按照模板样式
        title = Text("图神经网络：信息聚合与消息传递",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 左侧：图卷积的直观理解
        left_subtitle = Text("图卷积 vs 图像卷积", font_size=24, font="AR PL UKai CN", color=BLUE_A)

        # 插入图片1：对比示意图
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/3a9be8ce-76ae-43a5-80a6-61c323cc3872/pictures/888_8/1.png") # 这里期望是一张对比示意图，左侧展示规则网格上的图像卷积操作（例如在一个像素矩阵上滑动的窗口），右侧展示不规则图结构上的卷积操作（中心节点聚合周围邻居节点的信息），用于直观展示两者的异同，写实风
        img1.height = 3.0  # 设置合适的高度，防止遮挡

        left_desc = Text("规则网格滑动 vs 邻域信息聚合", font_size=20, font="AR PL UKai CN", color=GRAY_B)

        left_group = Group(left_subtitle, img1, left_desc).arrange(DOWN, buff=0.3)
        left_group.to_edge(LEFT, buff=1.5).shift(DOWN * 0.3)

        # 右侧：消息传递框架
        right_subtitle = Text("消息传递机制 (MPNN)", font_size=24, font="AR PL UKai CN", color=BLUE_A)

        # 插入图片2：消息传递架构
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/3a9be8ce-76ae-43a5-80a6-61c323cc3872/pictures/888_8/2.png") # 这里期望是一张图神经网络消息传递（Message Passing）的架构示意图，清晰展示节点之间传递信息、聚合邻居特征（Aggregate）并更新（Update）自身状态的完整流程，风格简洁，类似技术原理图，写实风
        img2.height = 3.0  # 保持与左侧一致的大小

        right_desc = Text("传递消息 -> 聚合特征 -> 更新状态", font_size=20, font="AR PL UKai CN", color=GRAY_B)

        right_group = Group(right_subtitle, img2, right_desc).arrange(DOWN, buff=0.3)
        right_group.to_edge(RIGHT, buff=1.5).shift(DOWN * 0.3)

        # 确保左右两组视觉上水平对齐
        right_group.match_y(left_group)

        # 3. 底部总结文字
        summary_box = SurroundingRectangle(Group(left_group, right_group), color=BLUE, buff=0.2, stroke_width=1)
        # 实际上不显示框，只用来定位下面的文字，或者可以用框强调

        summary_text = Text("核心理念：通过模拟信息在图上的传播来学习节点表示",
                           font_size=22, font="AR PL UKai CN", color=YELLOW)
        summary_text.move_to(DOWN * 3.2) # 放置在底部

        # 4. 动画流程
        # 展示左侧：图卷积直观理解
        self.play(FadeIn(left_group, shift=RIGHT), run_time=1.0)

        # 展示右侧：消息传递
        self.play(FadeIn(right_group, shift=LEFT), run_time=1.0)

        # 展示底部核心总结
        self.play(Write(summary_text), run_time=1.5)

        # 简单的强调动画
        self.play(Indicate(img2, color=YELLOW, scale_factor=1.05), run_time=1.0)
