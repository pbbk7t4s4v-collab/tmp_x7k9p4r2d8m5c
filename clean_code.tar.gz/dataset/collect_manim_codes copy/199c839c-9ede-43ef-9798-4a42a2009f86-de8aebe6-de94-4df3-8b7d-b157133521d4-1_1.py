from manim import *
import numpy as np

class WhatIsFluidMechanics(Scene):
    def construct(self):

        # --- 标题部分 (严格遵守模板) ---

        # --- 内容部分 ---

        # 1. 定义展示

        # 2. 分类图示 (流体 -> 液体 & 气体)

        # 根节点

        # 分支节点

        # 连接线

        # 播放分类动画

        # 3. 核心区别 (底部强调)

        # 4. 简单装饰 (简单的流体示意)
        # 液体示意：简单的波浪线

        # 气体示意：分散的点
