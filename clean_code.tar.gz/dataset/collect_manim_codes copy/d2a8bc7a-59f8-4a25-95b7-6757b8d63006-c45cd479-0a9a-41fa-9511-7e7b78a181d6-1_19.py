from manim import *

class NaturalHCI(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("自然人机交互:多模态融合",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("19", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念文本
        # ---------------------------------------------------------
        # 定义一段简短的说明文字
        intro_text = Text("目标:摆脱键鼠束缚,实现符合人类直觉的自然交流",
                         font="AR PL UKai CN",
                         font_size=24,
                         color=LIGHT_GRAY)
        intro_text.next_to(title_line, DOWN, buff=0.3)
        self.play(FadeIn(intro_text, shift=DOWN * 0.3))

        # ---------------------------------------------------------
        # 3. 构建多模态交互的星型拓扑图
        # ---------------------------------------------------------

        # 中心节点:智能理解系统
        center_circle = Circle(radius=1.0, color=BLUE_C, fill_opacity=0.2)
        center_text = Text("意图理解\n(AI Agent)", font="AR PL UKai CN", font_size=26, color=WHITE)
        center_group = VGroup(center_circle, center_text).move_to(DOWN * 0.5)

        # 外围节点:各种交互方式
        # 定义交互方式的数据:(名称, 颜色, 位置偏移方向)
        modes_data = [
            ("语音交互\n(Voice)", TEAL, UL),
            ("手势姿态\n(Gesture)", GREEN, UR),
            ("眼动追踪\n(Gaze)", MAROON, DL),
            ("脑机接口\n(BCI)", PURPLE, DR),
        ]

        mode_objects = VGroup()
        arrows = VGroup()

        radius_offset = 2.8 # 距离中心的距离

        for text_str, color, direction in modes_data:
            # 创建外围圆形节点
            dot = Circle(radius=0.7, color=color, fill_opacity=0.1)
            label = Text(text_str, font="AR PL UKai CN", font_size=20, color=color)

            # 组合节点并放置位置
            node = VGroup(dot, label)
            node.move_to(center_group.get_center() + direction * radius_offset)
            mode_objects.add(node)

            # 创建指向中心的箭头
            # 计算箭头起点和终点,留出一点空隙
            start_point = node.get_center() - direction * 0.6
            end_point = center_group.get_center() + direction * 0.9
            arrow = Arrow(start=start_point, end=end_point, color=color, buff=0.1, max_tip_length_to_length_ratio=0.15)
            arrows.add(arrow)

        # ---------------------------------------------------------
        # 4. 动画展示流程
        # ---------------------------------------------------------

        # 第一步:展示外围交互方式(输入)
        self.play(
            LaggedStart(
                *[FadeIn(node, shift=-node.get_center()*0.1) for node in mode_objects],
                lag_ratio=0.2
            ),
            run_time=2
        )

        # 第二步:数据汇聚流向中心
        self.play(
            LaggedStart(
                *[GrowArrow(arrow) for arrow in arrows],
                lag_ratio=0.1
            ),
            run_time=1.5
        )

        # 第三步:中心处理节点出现
        self.play(
            DrawBorderThenFill(center_circle),
            Write(center_text),
            run_time=1.5
        )

        # ---------------------------------------------------------
        # 5. 强调与总结
        # ---------------------------------------------------------

        # 使用框图强调整个系统
        system_group = VGroup(center_group, mode_objects, arrows)
        surround_rect = SurroundingRectangle(system_group, color=YELLOW, buff=0.2, corner_radius=0.2)
        surround_label = Text("多模态融合感知系统", font="AR PL UKai CN", font_size=22, color=YELLOW)
        surround_label.next_to(surround_rect, UP, buff=0.1)

        self.play(
            Create(surround_rect),
            Write(surround_label),
            run_time=1.5
        )

        # 稍微停顿,确保观众看清
