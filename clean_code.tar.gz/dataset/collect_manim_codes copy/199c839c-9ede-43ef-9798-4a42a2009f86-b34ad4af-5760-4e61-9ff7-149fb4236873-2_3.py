from manim import *

class GovernmentMultiplierExample(Scene):
    def construct(self):

        # 1. 标题设置 (符合模板要求)
        title = Text("政府支出乘数：数值计算示例",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 设定参数部分 (左侧)
        param_label = Text("设定参数", font_size=28, font="AR PL UKai CN", color=BLUE)
        param_c = MathTex(r"c = 0.8", font_size=32)
        param_g = MathTex(r"\Delta G = 10", font_size=32)

        param_group = VGroup(param_label, param_c, param_g).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        param_group.to_edge(LEFT, buff=1.5).shift(UP * 0.5)

        # 使用SurroundingRectangle框住参数
        param_box = SurroundingRectangle(param_group, color=BLUE, buff=0.2)

        self.play(
            FadeIn(param_group, shift=RIGHT),
            Create(param_box)
        )

        # 3. 计算过程 (右侧)
        # 第一步：计算乘数
        step1_text = Text("1. 计算乘数", font_size=26, font="AR PL UKai CN", color=YELLOW)
        step1_math = MathTex(r"k_G = \frac{1}{1 - 0.8} = \frac{1}{0.2} = 5", font_size=36)

        step1_group = VGroup(step1_text, step1_math).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # 第二步：计算收入变化
        step2_text = Text("2. 计算均衡收入增加", font_size=26, font="AR PL UKai CN", color=YELLOW)
        step2_math = MathTex(r"\Delta Y = k_G \cdot \Delta G = 5 \times 10 = 50", font_size=36)

        step2_group = VGroup(step2_text, step2_math).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # 整体计算部分的布局
        calc_group = VGroup(step1_group, step2_group).arrange(DOWN, aligned_edge=LEFT, buff=0.8)
        calc_group.next_to(param_box, RIGHT, buff=1.5)

        # 逐步展示计算过程
        self.play(Write(step1_text))
        self.play(Write(step1_math))

        self.play(Write(step2_text))
        self.play(Write(step2_math))

        # 4. 结论强调 (底部)
        conclusion = Text("结论：政府支出 10  →  产出增加 50", font_size=32, font="AR PL UKai CN", color=GREEN)
        conclusion.to_edge(DOWN, buff=1.0)

        # 简单的箭头示意图辅助理解
        arrow = Arrow(LEFT, RIGHT, color=GREEN).scale(0.5)
        val_in = MathTex("10", color=BLUE).next_to(arrow, LEFT)
        val_out = MathTex("50", color=GREEN).next_to(arrow, RIGHT)
        visual_aid = VGroup(val_in, arrow, val_out).next_to(conclusion, UP, buff=0.3)

        self.play(FadeIn(conclusion, shift=UP))
        self.play(Indicate(step2_math, color=GREEN))
