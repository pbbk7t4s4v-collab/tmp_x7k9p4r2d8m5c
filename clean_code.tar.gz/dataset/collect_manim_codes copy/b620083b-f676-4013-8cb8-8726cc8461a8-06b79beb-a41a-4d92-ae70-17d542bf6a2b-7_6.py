from manim import *

class BinaryTreeLevelOrder(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("二叉树层次遍历实践",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("39", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：二叉树可视化
        # 定义节点位置
        root_pos = UP * 1.5 + LEFT * 3.5
        left_pos = root_pos + DL * 1.5
        right_pos = root_pos + DR * 1.5

        # 创建节点
        def create_node(pos, label_text):
            circle = Circle(radius=0.4, color=BLUE, fill_opacity=0.5, fill_color=BLUE_E)
            label = Text(label_text, font_size=24, color=WHITE).move_to(circle)
            circle.move_to(pos)
            label.move_to(pos)
            return VGroup(circle, label)

        node_root = create_node(root_pos, "1")
        node_left = create_node(left_pos, "2")
        node_right = create_node(right_pos, "3")

        # 创建连线
        edge_l = Line(node_root.get_center(), node_left.get_center(), color=GREY)
        edge_r = Line(node_root.get_center(), node_right.get_center(), color=GREY)

        # 确保连线在节点下方
        tree_edges = VGroup(edge_l, edge_r)
        tree_nodes = VGroup(node_root, node_left, node_right)
        tree_group = VGroup(tree_edges, tree_nodes)

        # 3. 右侧：核心代码逻辑展示
        code_str = """
    size = len(q)  # 关键：记录当前层节点数
    level_nodes = []

    for _ in range(size):
        node = q.popleft()
        level_nodes.append(node.val)

        if node.left: q.append(node.left)
        if node.right: q.append(node.right)

    print(level_nodes)
        # 使用 Text 行构造代码块（避免使用不支持参数的 Code 对象）
        code_lines_raw = code_str.split("\n")
        if code_lines_raw and code_lines_raw[0].strip() == "":
            code_lines_raw = code_lines_raw[1:]
        code_lines = VGroup(*[
            Text(line, font="Monospace", font_size=24, color=WHITE)
            for line in code_lines_raw
        ])
        code_lines.arrange(DOWN, aligned_edge=LEFT, buff=0.1)
        code_obj = VGroup(code_lines)
        # 手动调整代码大小和位置，避免使用不支持的font_size参数
        code_obj.scale(0.65).to_edge(RIGHT, buff=0.5).shift(DOWN * 0.5)

        # 4. 辅助说明文字
        # 队列示意
        queue_label = Text("辅助结构：队列 (Queue)", font="AR PL UKai CN", font_size=24, color=YELLOW)
        queue_label.next_to(tree_group, DOWN, buff=0.5)

        # 5. 动画流程
        # 展示树结构
        self.play(FadeIn(tree_group), run_time=1)
        self.play(Write(queue_label), run_time=1)

        # 展示代码
        self.play(FadeIn(code_obj), run_time=1.5)

        # 6. 强调核心逻辑
        # 这里的逻辑是找到代码中 size = len(q) 这一行进行强调
        # 为了稳健,我们直接用 SurroundingRectangle 框选大致位置
        highlight_rect = SurroundingRectangle(code_lines[2], color=RED, buff=0.05)
        highlight_text = Text("记录每层节点数量\n以便分层处理", font="AR PL UKai CN", font_size=20, color=RED)
        highlight_text.next_to(highlight_rect, LEFT, buff=0.2)

        self.play(
            Create(highlight_rect),
            FadeIn(highlight_text),
            run_time=1.5
        )

        # 简单的层序遍历演示动画（示意）
        # 第一层
        self.play(
            node_root[0].animate.set_color(GREEN),
            Indicate(code_lines[6]),  # 对应 for 循环附近
            run_time=1
        )

        # 第二层
        self.play(
            node_left[0].animate.set_color(GREEN),
            node_right[0].animate.set_color(GREEN),
            run_time=1
        )
