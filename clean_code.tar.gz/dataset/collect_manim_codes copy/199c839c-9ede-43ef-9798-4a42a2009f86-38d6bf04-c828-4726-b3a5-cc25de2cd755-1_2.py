from manim import *

class SupervisedLearningBasics(Scene):
    def construct(self):

        # 1. 标题部分 (按照模板要求)
        title = Text("监督学习：分类与回归",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计 - 分为左右两部分

        # --- 左侧：分类问题 (Classification) ---
        class_title = Text("分类问题", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        class_desc = Text("输出：离散类别标签", font="AR PL UKai CN", font_size=20, color=GRAY_B)

        # 分类可视化图表
        c_axes = Axes(
            x_range=[0, 5], y_range=[0, 5],
            x_length=3.5, y_length=2.5,
            axis_config={"include_tip": True, "tip_width": 0.1, "tip_height": 0.1}
        )

        # 分类数据点 (两类)
        c_dots_group1 = VGroup(*[
            Dot(c_axes.c2p(x, y), color=RED, radius=0.08)
            for x, y in [(1, 1), (1.5, 2), (2, 1), (1.2, 1.5)]
        ])
        c_dots_group2 = VGroup(*[
            Dot(c_axes.c2p(x, y), color=BLUE, radius=0.08)
            for x, y in [(3.5, 3.5), (4, 3), (3, 4), (4.2, 4.2)]
        ])

        # 分类边界线
        c_line = Line(
            c_axes.c2p(0.5, 4.5),
            c_axes.c2p(4.5, 0.5),
            color=YELLOW,
            stroke_width=3
        )

        # 组合左侧元素
        class_group = VGroup(class_title, class_desc, c_axes, c_dots_group1, c_dots_group2, c_line)
        class_group.arrange(DOWN, buff=0.3)

        # --- 右侧：回归问题 (Regression) ---
        reg_title = Text("回归问题", font="AR PL UKai CN", font_size=28, color=GREEN_A)
        reg_desc = Text("输出：连续数值预测", font="AR PL UKai CN", font_size=20, color=GRAY_B)

        # 回归可视化图表
        r_axes = Axes(
            x_range=[0, 5], y_range=[0, 5],
            x_length=3.5, y_length=2.5,
            axis_config={"include_tip": True, "tip_width": 0.1, "tip_height": 0.1}
        )

        # 回归数据点 (趋势)
        r_data_points = [
            (0.5, 0.8), (1.0, 1.2), (1.5, 1.4), (2.0, 2.1),
            (2.5, 2.3), (3.0, 3.1), (3.5, 3.4), (4.0, 4.2)
        ]
        r_dots = VGroup(*[
            Dot(r_axes.c2p(x, y), color=WHITE, radius=0.06)
            for x, y in r_data_points
        ])

        # 回归拟合线
        r_line = r_axes.plot(lambda x: x + 0.1, color=GREEN, x_range=[0, 4.5])

        # 组合右侧元素
        reg_group = VGroup(reg_title, reg_desc, r_axes, r_dots, r_line)
        reg_group.arrange(DOWN, buff=0.3)

        # 3. 整体布局定位
        # 将左右两组内容放置在屏幕中央,稍微下移
        content_group = VGroup(class_group, reg_group).arrange(RIGHT, buff=1.5)
        content_group.next_to(title_line, DOWN, buff=0.5)

        # 4. 装饰框
        rect_left = SurroundingRectangle(class_group, color=BLUE, buff=0.2, stroke_width=2)
        rect_right = SurroundingRectangle(reg_group, color=GREEN, buff=0.2, stroke_width=2)

        # 5. 动画播放序列
        # 显示标题文字
        self.play(
            FadeIn(class_title, shift=UP),
            FadeIn(reg_title, shift=UP),
            run_time=0.8
        )

        # 显示坐标系
        self.play(
            Create(c_axes),
            Create(r_axes),
            run_time=1.0
        )

        # 显示数据点
        self.play(
            FadeIn(c_dots_group1),
            FadeIn(c_dots_group2),
            FadeIn(r_dots),
            run_time=0.8
        )

        # 关键概念演示：分类画线 vs 回归拟合
        self.play(
            Create(c_line),
            Create(r_line),
            run_time=1.2
        )

        # 显示描述文本和外框
        self.play(
            Write(class_desc),
            Write(reg_desc),
            Create(rect_left),
            Create(rect_right),
            run_time=1.0
        )

        # 稍微停顿
