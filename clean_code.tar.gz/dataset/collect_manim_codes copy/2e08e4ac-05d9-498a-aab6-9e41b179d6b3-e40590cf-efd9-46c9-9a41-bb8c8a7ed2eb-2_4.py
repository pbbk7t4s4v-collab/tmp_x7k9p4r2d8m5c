from manim import *

class SquareAreaDerivation(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("正方形面积公式的推导",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 左侧:一般长方形 (8cm x 6cm)
        # ---------------------------------------------------------
        # 定义几何图形
        rect = Rectangle(width=4.0, height=3.0, color=BLUE, fill_opacity=0.3)
        rect.shift(LEFT * 3.5 + UP * 0.5)

        # 标签
        rect_len = Text("8cm", font="AR PL UKai CN", font_size=24).next_to(rect, UP)
        rect_wid = Text("6cm", font="AR PL UKai CN", font_size=24).next_to(rect, LEFT)

        # 面积计算公式
        rect_calc = Text("长方形面积 = 8 × 6 = 48 (cm²)", font="AR PL UKai CN", font_size=24)
        rect_calc.next_to(rect, DOWN, buff=0.3)

        # 动画展示左侧内容
        self.play(
            Create(rect),
            FadeIn(rect_len),
            FadeIn(rect_wid)
        )
        self.play(Write(rect_calc))

        # ---------------------------------------------------------
        # 3. 右侧:特殊长方形/正方形 (6cm x 6cm)
        # ---------------------------------------------------------
        # 定义几何图形
        square = Rectangle(width=3.0, height=3.0, color=GREEN, fill_opacity=0.3)
        square.shift(RIGHT * 3.5 + UP * 0.5)

        # 标签
        sq_len = Text("6cm", font="AR PL UKai CN", font_size=24).next_to(square, UP)
        sq_wid = Text("6cm", font="AR PL UKai CN", font_size=24).next_to(square, LEFT)

        # 特殊说明
        special_note = Text("长 = 宽 (正方形)", font="AR PL UKai CN", font_size=24, color=YELLOW)
        special_note.next_to(square, RIGHT, buff=0.5)

        # 动画展示右侧内容
        self.play(
            Create(square),
            FadeIn(sq_len),
            FadeIn(sq_wid)
        )
        self.play(FadeIn(special_note))

        # 正方形计算过程
        sq_calc = Text("正方形面积 = 6 × 6 = 36 (cm²)", font="AR PL UKai CN", font_size=24)
        sq_calc.next_to(square, DOWN, buff=0.3)
        self.play(Write(sq_calc))

        # ---------------------------------------------------------
        # 4. 底部:公式推导总结
        # ---------------------------------------------------------
        # 箭头指示
        arrow = Arrow(start=sq_calc.get_bottom(), end=sq_calc.get_bottom() + DOWN * 1.2, color=WHITE, buff=0.1)

        # 最终公式
        final_formula = Text("正方形的面积 = 边长 × 边长", font="AR PL UKai CN", font_size=36, color=GOLD)
        final_formula.next_to(arrow, DOWN)

        # 强调框
        box = SurroundingRectangle(final_formula, color=WHITE, buff=0.2)

        # 动画展示总结
        self.play(GrowArrow(arrow))
        self.play(
            Write(final_formula),
            Create(box)
        )
