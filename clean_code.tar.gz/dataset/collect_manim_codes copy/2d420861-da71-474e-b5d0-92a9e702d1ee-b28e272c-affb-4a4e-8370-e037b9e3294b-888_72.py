from manim import *

class MolecularChaperonesAndDrugs(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("分子伴侣与药物受体相互作用",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("71", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：分子伴侣内容
        # 标题
        left_header = Text("分子伴侣 (Chaperones)", font="AR PL UKai CN", font_size=28, color=BLUE)

        # 图片1：GroEL/GroES
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/2d420861-da71-474e-b5d0-92a9e702d1ee/b28e272c-affb-4a4e-8370-e037b9e3294b/pictures/888_72/1.png") # 这里期望是一张展示GroEL/GroES分子伴侣复合物的科学插画，画面主体展示一个巨大的桶状蛋白质结构（GroEL）和盖子结构（GroES），展示其内部的中空微环境，用于隔离蛋白质进行折叠，风格为3D生物医学渲染，色彩区分清晰，背景干净，写实风
        img1.height = 3.0  # 调整大小

        # 文本列表
        list_items = [
            "• 结合暴露的疏水区域",
            "• 防止非特异性聚集",
            "• 提供隔离微环境(GroEL/GroES)",
        ]
        list1 = VGroup(
            *[Text(item, font="AR PL UKai CN", font_size=20, color=WHITE) for item in list_items]
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # 组合左侧元素
        left_group = Group(left_header, img1, list1).arrange(DOWN, buff=0.3)
        left_group.to_edge(LEFT, buff=1.0).shift(DOWN * 0.3)

        # 3. 右侧：药物-受体相互作用
        # 标题
        right_header = Text("药物-受体相互作用", font="AR PL UKai CN", font_size=28, color=GREEN)

        # 图片2：药物结合
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/2d420861-da71-474e-b5d0-92a9e702d1ee/b28e272c-affb-4a4e-8370-e037b9e3294b/pictures/888_72/2.png") # 这里期望是一张展示药物分子与受体蛋白结合的微观3D结构图，画面展示巨大的受体蛋白表面有一个特定的结合口袋，一个小的药物分子正精确地嵌入其中，体现“锁与钥匙”的特异性识别，风格为高精度的生物化学模型渲染，写实风
        img2.height = 3.0 # 调整大小

        # 文本说明
        desc_text = Text(
            "“锁与钥匙”模型：\n依赖精确的分子识别",
            font="AR PL UKai CN",
            font_size=20,
            color=WHITE,
            line_spacing=1.2
        )

        # 组合右侧元素
        right_group = Group(right_header, img2, desc_text).arrange(DOWN, buff=0.3)
        right_group.to_edge(RIGHT, buff=1.0).shift(DOWN * 0.3)

        # 确保左右两边顶部对齐
        right_group.align_to(left_group, UP)

        # 4. 动画展示流程

        # 展示左侧
        self.play(FadeIn(left_header, shift=DOWN))
        self.play(FadeIn(img1, scale=0.8))

        # 强调框
        box1 = SurroundingRectangle(list1, color=BLUE, buff=0.1)
        self.play(
            Write(list1, run_time=1.5),
            Create(box1)
        )

        # 展示右侧
        self.play(FadeIn(right_header, shift=DOWN))
        self.play(FadeIn(img2, scale=0.8))

        # 强调框
        box2 = SurroundingRectangle(desc_text, color=GREEN, buff=0.1)
        self.play(
            Write(desc_text),
            Create(box2)
        )
