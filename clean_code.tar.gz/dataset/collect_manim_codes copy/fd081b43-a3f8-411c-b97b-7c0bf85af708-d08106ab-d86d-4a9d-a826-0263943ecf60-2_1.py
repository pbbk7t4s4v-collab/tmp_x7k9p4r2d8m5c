from manim import *

class TranscriptionScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格遵守模板要求)
        # ---------------------------------------------------------
        title = Text("转录：从 DNA 到 RNA",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念可视化：DNA 解旋与 RNA 合成
        # ---------------------------------------------------------

        # 定义位置常数
        CENTER_Y = 0.5

        # DNA 双螺旋 (简化为梯子)
        # 上链 (非模板链)
        dna_top = Line(LEFT * 4, RIGHT * 4, color=BLUE_C, stroke_width=4)
        dna_top.move_to(UP * (CENTER_Y + 0.3))
        dna_top_label = Text("DNA (非模板链)", font="AR PL UKai CN", font_size=20, color=BLUE_C)
        dna_top_label.next_to(dna_top, UP, buff=0.1)

        # 下链 (模板链)
        dna_bottom = Line(LEFT * 4, RIGHT * 4, color=BLUE_E, stroke_width=4)
        dna_bottom.move_to(UP * (CENTER_Y - 0.3))
        dna_bottom_label = Text("DNA (模板链)", font="AR PL UKai CN", font_size=20, color=BLUE_E)
        dna_bottom_label.next_to(dna_bottom, DOWN, buff=0.1)

        # 碱基对 (连接线)
        base_pairs = VGroup()
        for x in range(-4, 5):
            bp = Line(UP * (CENTER_Y + 0.3), UP * (CENTER_Y - 0.3), color=WHITE, stroke_opacity=0.5)
            bp.move_to(RIGHT * x * 0.8 + UP * CENTER_Y)
            base_pairs.add(bp)

        dna_group = VGroup(dna_top, dna_bottom, base_pairs, dna_top_label, dna_bottom_label)

        # 动画：展示 DNA
        self.play(FadeIn(dna_group, shift=UP), run_time=1.5)

        # 动画：解旋 (上下分开)
        self.play(
            dna_top.animate.shift(UP * 0.8),
            dna_top_label.animate.shift(UP * 0.8),
            dna_bottom.animate.shift(DOWN * 0.8),
            dna_bottom_label.animate.shift(DOWN * 0.8),
            FadeOut(base_pairs), # 氢键断裂
            run_time=1.5
        )

        # RNA 合成 (红色线条从左向右生长)
        rna_strand = Line(LEFT * 4, RIGHT * 4, color=RED, stroke_width=4)
        rna_strand.move_to(UP * CENTER_Y) # 在中间生成
        rna_label = Text("mRNA (信使RNA)", font="AR PL UKai CN", font_size=20, color=RED)
        rna_label.next_to(rna_strand, RIGHT, buff=0.2)

        # 模拟聚合酶移动的效果 (Create)
        self.play(
            Create(rna_strand, run_time=2.5, rate_func=linear),
            Write(rna_label, run_time=1)
        )

        # ---------------------------------------------------------
        # 3. 关键知识点总结 (BulletedList)
        # ---------------------------------------------------------

        # 知识点列表(使用 Text 以避免 LaTeX 编译问题)
        info_items = [
            "场所：细胞核 (真核生物)",
            "模板：DNA 的一条链",
            "产物：单链 RNA",
        ]
        info_list = VGroup(*[Text(f"• {item}", font_size=24, font="AR PL UKai CN") for item in info_items])
        info_list.arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        info_list.to_edge(DOWN, buff=1.0).shift(LEFT * 2)

        # 特殊规则强调：碱基互补配对
        rule_text = Text("碱基配对规则：", font="AR PL UKai CN", font_size=24, color=YELLOW)
        rule_text.next_to(info_list, RIGHT, buff=1.0, aligned_edge=UP)

        # 使用非 LaTeX 方式展示 T -> U 的变化
        math_rule = VGroup(
            MarkupText("A<sub>DNA</sub> -> U<sub>RNA</sub>", font_size=28, font="AR PL UKai CN"),
            MarkupText("T<sub>DNA</sub> -> A<sub>RNA</sub>", font_size=28, font="AR PL UKai CN"),
        )
        math_rule.arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        math_rule.next_to(rule_text, DOWN, buff=0.2)

        # 边框强调
        rule_box = SurroundingRectangle(VGroup(rule_text, math_rule), color=YELLOW, buff=0.2)

        # 动画：展示文字和规则
        self.play(
            FadeIn(info_list, shift=RIGHT),
            FadeIn(rule_text),
            Write(math_rule),
            Create(rule_box),
            run_time=2
        )
