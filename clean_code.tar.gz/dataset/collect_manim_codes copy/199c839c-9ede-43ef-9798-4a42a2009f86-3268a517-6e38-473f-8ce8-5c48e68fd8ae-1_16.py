from manim import *

class EnvironmentalPollutionExample(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("实践应用：环境污染中的质量互变",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("16", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧可视化：环境容量容器
        # 定义容器轮廓 (左、下、右三条线)
        container_width = 3
        container_height = 5
        container_bottom = DOWN * 2.5 + LEFT * 3

        left_wall = Line(container_bottom + UP * container_height, container_bottom)
        bottom_wall = Line(container_bottom, container_bottom + RIGHT * container_width)
        right_wall = Line(container_bottom + RIGHT * container_width, container_bottom + UP * container_height + RIGHT * container_width)

        container = VGroup(left_wall, bottom_wall, right_wall).set_color(WHITE)

        # 定义临界线 (度)
        limit_height = 3.5
        limit_line = DashedLine(
            start=container_bottom + UP * limit_height,
            end=container_bottom + RIGHT * container_width + UP * limit_height,
            color=RED
        )
        limit_text = Text("环境容量 (度)", font="AR PL UKai CN", font_size=20, color=RED)
        limit_text.next_to(limit_line, LEFT, buff=0.1)

        # 污染物 (初始状态 - 安全)
        pollutant = Rectangle(
            width=container_width,
            height=2.0,
            fill_color=GREEN,
            fill_opacity=0.6,
            stroke_width=0
        )
        pollutant.align_to(bottom_wall, DOWN).align_to(left_wall, LEFT)

        visual_group = VGroup(container, limit_line, limit_text, pollutant)
        visual_group.shift(RIGHT * 0.5) # 整体微调位置

        # 3. 右侧文字说明
        # 使用 VGroup 手动排列 Text，避免 BulletedList 的 LaTeX 问题和对齐问题
        text_start_x = 1.0
        text_scale = 0.65

        txt_1 = Text("1. 量变阶段：", font="AR PL UKai CN", color=YELLOW).scale(text_scale)
        txt_1_content = Text("污染物在限度内，自然自净，相对稳定。", font="AR PL UKai CN", color=WHITE).scale(text_scale)

        txt_2 = Text("2. 质变发生：", font="AR PL UKai CN", color=RED).scale(text_scale)
        txt_2_content = Text("突破临界点，引发生态危机，不可逆转。", font="AR PL UKai CN", color=WHITE).scale(text_scale)

        txt_3 = Text("3. 实践启示：", font="AR PL UKai CN", color=BLUE).scale(text_scale)
        txt_3_content = Text("坚持可持续发展，防微杜渐。", font="AR PL UKai CN", color=WHITE).scale(text_scale)

        # 组合文字行
        line1 = VGroup(txt_1, txt_1_content).arrange(RIGHT, buff=0.1).to_edge(RIGHT, buff=1).shift(UP*1)
        line2 = VGroup(txt_2, txt_2_content).arrange(RIGHT, buff=0.1).next_to(line1, DOWN, buff=0.6, aligned_edge=LEFT)
        line3 = VGroup(txt_3, txt_3_content).arrange(RIGHT, buff=0.1).next_to(line2, DOWN, buff=0.8, aligned_edge=LEFT)

        # 4. 动画流程

        # 显示容器和临界线
        self.play(
            Create(container),
            Create(limit_line),
            Write(limit_text),
            run_time=1.5
        )

        # 阶段一：量变 (绿色)
        self.play(
            FadeIn(pollutant),
            FadeIn(line1, shift=LEFT),
            run_time=1.5
        )

        # 阶段二：质变 (变为红色并溢出)
        # 创建一个新的高矩形代表溢出
        pollutant_overflow = Rectangle(
            width=container_width,
            height=4.5,
            fill_color=RED,
            fill_opacity=0.8,
            stroke_width=0
        )
        pollutant_overflow.align_to(bottom_wall, DOWN).align_to(left_wall, LEFT)
        # 调整位置以匹配原来的组
        pollutant_overflow.shift(RIGHT * 0.5)

        self.play(
            Transform(pollutant, pollutant_overflow),
            FadeIn(line2, shift=LEFT),
            run_time=1.5
        )

        # 阶段三：启示 (强调)
        # 添加强调框
        box = SurroundingRectangle(line3, color=BLUE, buff=0.15)

        self.play(
            FadeIn(line3, shift=UP),
            Create(box),
            run_time=1.5
        )
