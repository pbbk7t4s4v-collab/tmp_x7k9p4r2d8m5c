from manim import *

class BMIInterpretation(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("如何解读 BMI：亚洲成年人参考标准",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容可视化：BMI 分类色块图 (健康地图)
        # ---------------------------------------------------------

        # 定义配置参数
        box_height = 2.0
        box_width = 3.0
        y_pos = 0.5  # 中心稍微偏上

        # 数据结构：(标签, 范围, 颜色, 描述)
        bmi_data = [
            ("偏瘦", "< 18.5", BLUE_D, "需关注营养"),
            ("正常", "18.5 - 23.9", GREEN_D, "风险最小"),
            ("超重", "24.0 - 27.9", GOLD_E, "警惕风险"),
            ("肥胖", "\\ge 28.0", RED_D, "风险较高"),
        ]

        # 创建图形组
        chart_group = VGroup()

        for label_text, range_tex, color, desc in bmi_data:
            # 创建色块
            rect = Rectangle(height=box_height, width=box_width, fill_color=color, fill_opacity=0.8, color=WHITE)

            # 创建内部标签 (分类)
            label = Text(label_text, font="AR PL UKai CN", font_size=28, color=WHITE)
            label.move_to(rect.get_center() + UP * 0.4)

            # 创建内部描述 (简要说明)
            desc_txt = Text(desc, font="AR PL UKai CN", font_size=20, color=WHITE)
            desc_txt.move_to(rect.get_center() + DOWN * 0.4)

            # 创建下方数值 (范围)
            val = MathTex(range_tex, font_size=28, color=color)
            val.next_to(rect, DOWN, buff=0.2)

            # 组合单个部分
            segment = VGroup(rect, label, desc_txt, val)
            chart_group.add(segment)

        # 横向排列
        chart_group.arrange(RIGHT, buff=0)
        chart_group.move_to(ORIGIN).shift(DOWN * 0.5)

        # ---------------------------------------------------------
        # 3. 动画展示流程
        # ---------------------------------------------------------

        # 依次展示每个区间
        for segment in chart_group:
            self.play(
                FadeIn(segment, shift=UP * 0.5),
                run_time=0.6
            )

        # ---------------------------------------------------------
        # 4. 强调核心概念 (正常范围)
        # ---------------------------------------------------------

        normal_segment = chart_group[1] # 索引1是正常范围

        # 使用 SurroundingRectangle 强调正常范围
        highlight_rect = SurroundingRectangle(normal_segment[0], color=YELLOW, buff=0.05, stroke_width=4)
        highlight_text = Text("健康目标", font="AR PL UKai CN", font_size=24, color=YELLOW)
        highlight_text.next_to(highlight_rect, UP, buff=0.1)

        self.play(
            Create(highlight_rect),
            Write(highlight_text),
            run_time=1.0
        )
