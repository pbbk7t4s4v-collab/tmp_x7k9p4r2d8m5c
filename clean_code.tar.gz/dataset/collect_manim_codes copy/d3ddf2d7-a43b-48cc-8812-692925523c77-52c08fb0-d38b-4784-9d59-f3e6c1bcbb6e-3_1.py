from manim import *

class AuthorIntroduction(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (按照模板要求)
        # ---------------------------------------------------------
        title = Text("作者简介：贾祖璋",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局:左侧图片,右侧简介
        # ---------------------------------------------------------

        # 左侧:作者图片
        # 注意:这里使用 placeholder.png 占位,实际应展示贾祖璋先生的照片
        try:
            author_img = ImageMobject("placeholder.png")
        except Exception:
            author_img = Rectangle(width=3, height=4.5)
        author_img.scale_to_fit_height(4.5)  # 设置高度,保持纵横比
        author_img.to_edge(LEFT, buff=1.0).shift(DOWN * 0.3) # 放置在左侧,稍微下移避开标题

        # 给图片添加边框
        img_rect = SurroundingRectangle(author_img, color=BLUE, buff=0.1, stroke_width=4)

        # 右侧:文字简介
        # 使用 VGroup 和 Text 模拟列表,避免 BulletedList 的 LaTeX 中文问题
        content_data = [
            "浙江省嘉兴市海宁人 (1901-1988)",
            "著名科普作家与编辑家",
            "中国科学小品文的开拓者之一",
            "中国科普作协第一届副理事长"
        ]

        text_lines = VGroup()
        for i, text_str in enumerate(content_data):
            # 创建项目符号(小圆点)
            dot = Dot(color=YELLOW, radius=0.08)
            # 创建文字
            txt = Text(text_str, font="AR PL UKai CN", font_size=26, color=WHITE)
            # 组合点和文字
            line = VGroup(dot, txt).arrange(RIGHT, buff=0.3)
            text_lines.add(line)

        # 排列文字行:垂直排列,左对齐
        text_lines.arrange(DOWN, buff=0.7, aligned_edge=LEFT)

        # 将文字组放置在图片右侧
        text_lines.next_to(author_img, RIGHT, buff=1.0)

        # 防止文字超出右边界 (如果文字太长,整体左移一点)
        if text_lines.get_right()[0] > config.frame_width / 2:
            text_lines.shift(LEFT * 0.5)

        # ---------------------------------------------------------
        # 3. 动画展示
        # ---------------------------------------------------------

        # 淡入图片
        self.play(FadeIn(author_img, shift=RIGHT), run_time=1)

        # 绘制边框
        self.play(Create(img_rect), run_time=0.8)

        # 逐行写出简介文字
        for line in text_lines:
            self.play(
                FadeIn(line[0], scale=0.5), # 点淡入
                Write(line[1]),             # 文字书写
                run_time=1.2
            )
