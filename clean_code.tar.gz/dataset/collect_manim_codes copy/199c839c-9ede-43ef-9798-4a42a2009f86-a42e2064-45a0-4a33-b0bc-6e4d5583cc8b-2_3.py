from manim import *

class EMBACoreModules(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("EMBA核心课程体系概览",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局 (核心课程模块展示)
        # ---------------------------------------------------------

        # 定义课程模块名称列表
        module_names = [
            "宏观经济", "商业决策", "管理决策", "领导力",
            "人工智能", "创新创业", "综合管理", "国际课程"
        ]

        # 定义颜色列表,用于区分不同模块
        colors = [
            BLUE_C, TEAL_C, GREEN_C, GOLD_C,
            PURPLE_C, RED_C, MAROON_C, ORANGE
        ]

        # 创建模块组
        modules_group = VGroup()

        for i, name in enumerate(module_names):
            # 创建文字
            text = Text(name, font="AR PL UKai CN", font_size=26, color=WHITE)

            # 创建边框 (使用 SurroundingRectangle)
            # buff=0.3 增加内部留白,corner_radius=0.1 使边角圆润
            box = SurroundingRectangle(
                text,
                color=colors[i],
                buff=0.3,
                corner_radius=0.1,
                stroke_width=4
            )

            # 组合单个模块
            item = VGroup(box, text)
            modules_group.add(item)

        # 网格布局:2行4列
        modules_group.arrange_in_grid(rows=2, cols=4, buff=0.6)

        # 整体位置调整:位于标题下方
        modules_group.next_to(title_line, DOWN, buff=1.0)

        # ---------------------------------------------------------
        # 3. 动画展示
        # ---------------------------------------------------------

        # 使用 LaggedStart 依次展示每个模块,带有淡入和缩放效果
        self.play(
            LaggedStart(
                *[
                    AnimationGroup(
                        Create(m[0]), # 画框
                        Write(m[1])   # 写字
                    ) for m in modules_group
                ],
                lag_ratio=0.2,
                run_time=4
            )
        )

        # ---------------------------------------------------------
        # 4. 总结强调 (用一个大框把所有课程框起来,表示整体性)
        # ---------------------------------------------------------
        total_rect = SurroundingRectangle(modules_group, color=WHITE, buff=0.2, stroke_width=2)
        label = Text("全方位管理知识图谱", font="AR PL UKai CN", font_size=20, color=GRAY).next_to(total_rect, DOWN, buff=0.2)

        self.play(
            Create(total_rect),
            FadeIn(label)
        )
