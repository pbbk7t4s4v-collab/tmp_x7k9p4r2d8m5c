from manim import *

class DeterminantVsMatrix(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("行列式与矩阵的关系",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 左侧：矩阵部分
        matrix_tex = MathTex(r"A = \begin{bmatrix} 1 & 2 \\ 3 & 4 \end{bmatrix}", font_size=40)
        matrix_label = Text("矩阵 (Matrix)", font="AR PL UKai CN", font_size=24, color=BLUE)
        matrix_desc = Text("数字排列成的表格", font="AR PL UKai CN", font_size=20, color=BLUE_A)

        matrix_group = VGroup(matrix_label, matrix_tex, matrix_desc).arrange(DOWN, buff=0.3)
        matrix_group.to_edge(LEFT, buff=1.5).shift(UP * 0.5)

        # 右侧：行列式部分
        det_tex = MathTex(r"|A| = \begin{vmatrix} 1 & 2 \\ 3 & 4 \end{vmatrix}", font_size=40)
        det_calc = MathTex(r"= 1\times4 - 2\times3 = -2", font_size=40, color=YELLOW)
        det_label = Text("行列式 (Determinant)", font="AR PL UKai CN", font_size=24, color=GREEN)
        det_desc = Text("计算得到的一个数值", font="AR PL UKai CN", font_size=20, color=GREEN_A)

        # 组合行列式的公式部分
        det_formula_group = VGroup(det_tex, det_calc).arrange(RIGHT, buff=0.2)
        det_group = VGroup(det_label, det_formula_group, det_desc).arrange(DOWN, buff=0.3)
        det_group.to_edge(RIGHT, buff=1.0).match_y(matrix_group)

        # 中间：转换箭头
        arrow = Arrow(start=matrix_group.get_right(), end=det_group.get_left(), buff=0.2, color=GREY)
        op_text = Text("取行列式运算", font="AR PL UKai CN", font_size=18).next_to(arrow, UP, buff=0.1)

        # 3. 动画演示流程

        # 展示矩阵
        self.play(FadeIn(matrix_group, shift=RIGHT), run_time=1)

        # 强调矩阵的括号
        matrix_rect = SurroundingRectangle(matrix_tex, color=BLUE, buff=0.1)
        self.play(Create(matrix_rect), run_time=0.8)
        self.play(Uncreate(matrix_rect), run_time=0.5)

        # 展示转换过程
        self.play(GrowArrow(arrow), Write(op_text), run_time=1)

        # 展示行列式及其计算
        self.play(FadeIn(det_label), Write(det_tex), run_time=1)

        # 强调计算结果
        self.play(Write(det_calc), run_time=1)
        self.play(FadeIn(det_desc, shift=UP), run_time=0.8)

        # 4. 总结对比框
        # 强调本质区别:数表 vs 数值
        highlight_box_left = SurroundingRectangle(matrix_desc, color=BLUE, corner_radius=0.1)
        highlight_box_right = SurroundingRectangle(det_calc, color=YELLOW, corner_radius=0.1)

        self.play(
            Create(highlight_box_left),
            Create(highlight_box_right),
            run_time=1
        )

        # 5. 核心结论
        conclusion = Text("矩阵是数据的容器,行列式是方阵的一个属性值",
                         font="AR PL UKai CN", font_size=26, color=ORANGE)
        conclusion.next_to(VGroup(matrix_group, det_group), DOWN, buff=1.0)

        self.play(Write(conclusion), run_time=1.5)
