from manim import *

class GraphicsAndAnimationGeneration(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("图形与动画的生成方法",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("24", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 分左右两栏展示

        # 左侧:图形生成
        graphic_title = Text("图形生成的主要方法", font="AR PL UKai CN", font_size=26, color=BLUE_A)

        graphic_content_list = [
            "矢量绘图软件 (AI, CorelDRAW)",
            "程序化生成 (代码绘制几何)",
            "CAD系统 (工程图形)",
            "数学函数绘制 (方程式曲线)",
            "转换生成 (位图矢量化)"
        ]

        graphic_items = VGroup()
        for item in graphic_content_list:
            # 使用Text而非BulletedList以避免LaTeX问题和字体问题
            dot = Dot(color=BLUE, radius=0.06)
            text = Text(item, font="AR PL UKai CN", font_size=20, color=WHITE)
            line_group = VGroup(dot, text).arrange(RIGHT, buff=0.2)
            graphic_items.add(line_group)

        graphic_items.arrange(DOWN, aligned_edge=LEFT, buff=0.35)

        # 组合左侧整体
        left_group = VGroup(graphic_title, graphic_items).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        left_group.move_to(LEFT * 3.5) # 移至左侧

        # 右侧:动画生成
        anim_title = Text("动画制作的常用技术", font="AR PL UKai CN", font_size=26, color=GREEN_A)

        anim_content_list = [
            "关键帧动画 (自动插值)",
            "骨骼动画 (骨架控制)",
            "粒子系统 (模拟自然现象)",
            "物理模拟 (物理引擎)",
            "脚本驱动 & 动作捕捉"
        ]

        anim_items = VGroup()
        for item in anim_content_list:
            dot = Dot(color=GREEN, radius=0.06)
            text = Text(item, font="AR PL UKai CN", font_size=20, color=WHITE)
            line_group = VGroup(dot, text).arrange(RIGHT, buff=0.2)
            anim_items.add(line_group)

        anim_items.arrange(DOWN, aligned_edge=LEFT, buff=0.35)

        # 组合右侧整体
        right_group = VGroup(anim_title, anim_items).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        right_group.move_to(RIGHT * 3.5) # 移至右侧

        # 垂直居中调整(相对于标题下方)
        content_y_pos = title_line.get_bottom()[1] - 0.8
        left_group.set_y(content_y_pos - 1.5) # 向下微调以适应屏幕
        right_group.set_y(content_y_pos - 1.5)

        # 3. 装饰性边框 (SurroundingRectangle)
        rect_left = SurroundingRectangle(left_group, color=BLUE, buff=0.2, corner_radius=0.2)
        rect_right = SurroundingRectangle(right_group, color=GREEN, buff=0.2, corner_radius=0.2)

        # 4. 动画展示流程
        # 展示左侧图形生成
        self.play(FadeIn(left_group, shift=UP), Create(rect_left), run_time=1.5)

        # 展示右侧动画生成
        self.play(FadeIn(right_group, shift=UP), Create(rect_right), run_time=1.5)

        # 5. 简单的视觉强调连接(可选,增加视觉关联)
        arrow = DoubleArrow(rect_left.get_right(), rect_right.get_left(), color=GRAY, buff=0.1)
        arrow_text = Text("互补技术", font="AR PL UKai CN", font_size=18, color=GRAY_A).next_to(arrow, UP, buff=0.05)

        self.play(GrowFromCenter(arrow), FadeIn(arrow_text))
