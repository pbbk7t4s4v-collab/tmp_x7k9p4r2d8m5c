from manim import *

class OPMArchitecture(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (根据模板)
        # ---------------------------------------------------------
        title = Text("组织级项目管理架构",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("19", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局设计
        # ---------------------------------------------------------
        # 定义层级节点生成函数
        def create_node(text_str, bg_color):
            t = Text(text_str, font="AR PL UKai CN", font_size=24, color=WHITE)
            box = SurroundingRectangle(t, color=bg_color, fill_opacity=0.6, fill_color=bg_color, buff=0.2, corner_radius=0.1)
            return VGroup(box, t)

        # 创建四个层级的节点
        node_strategy = create_node("战略目标", GREY_D)
        node_portfolio = create_node("项目组合管理", TEAL_D)
        node_program = create_node("项目集管理", BLUE_D)
        node_project = create_node("项目管理", INDIGO_D)

        # 垂直排列左侧主干流程
        main_flow = VGroup(node_strategy, node_portfolio, node_program, node_project)
        main_flow.arrange(DOWN, buff=0.9)
        main_flow.to_edge(LEFT, buff=2.0).shift(DOWN * 0.3)

        # 创建连接箭头
        arrow1 = Arrow(node_strategy.get_bottom(), node_portfolio.get_top(), color=GREY, buff=0.05, max_tip_length_to_length_ratio=0.1)
        arrow2 = Arrow(node_portfolio.get_bottom(), node_program.get_top(), color=GREY, buff=0.05, max_tip_length_to_length_ratio=0.1)
        arrow3 = Arrow(node_program.get_bottom(), node_project.get_top(), color=GREY, buff=0.05, max_tip_length_to_length_ratio=0.1)

        # 创建右侧描述文本
        # 项目组合描述
        desc_portfolio = VGroup(
            Text("做正确的事 | 资源优先级分配", font="AR PL UKai CN", font_size=20, color=YELLOW_A),
            Text("关注：价值实现", font="AR PL UKai CN", font_size=20, color=YELLOW)
        ).arrange(DOWN, buff=0.15, aligned_edge=LEFT)
        desc_portfolio.next_to(node_portfolio, RIGHT, buff=1.5)

        # 项目集描述
        desc_program = VGroup(
            Text("进行关联项目管理", font="AR PL UKai CN", font_size=20, color=BLUE_A),
            Text("关注：效益实现", font="AR PL UKai CN", font_size=20, color=BLUE)
        ).arrange(DOWN, buff=0.15, aligned_edge=LEFT)
        desc_program.next_to(node_program, RIGHT, buff=1.5)

        # 项目描述
        desc_project = VGroup(
            Text("进行单个项目管理", font="AR PL UKai CN", font_size=20, color=WHITE),
            Text("关注：可交付成果", font="AR PL UKai CN", font_size=20, color=GREY_A)
        ).arrange(DOWN, buff=0.15, aligned_edge=LEFT)
        desc_project.next_to(node_project, RIGHT, buff=1.5)

        # 创建指向描述的虚线
        line_portfolio = DashedLine(node_portfolio.get_right(), desc_portfolio.get_left(), color=YELLOW_E)
        line_program = DashedLine(node_program.get_right(), desc_program.get_left(), color=BLUE_E)
        line_project = DashedLine(node_project.get_right(), desc_project.get_left(), color=GREY)

        # ---------------------------------------------------------
        # 3. 动画演示
        # ---------------------------------------------------------

        # 第一层:战略目标
        self.play(FadeIn(node_strategy, shift=DOWN), run_time=1)

        # 第二层:项目组合
        self.play(GrowArrow(arrow1, run_time=0.6))
        self.play(
            FadeIn(node_portfolio, shift=DOWN),
            Create(line_portfolio),
            Write(desc_portfolio),
            run_time=1.2
        )

        # 第三层:项目集
        self.play(GrowArrow(arrow2, run_time=0.6))
        self.play(
            FadeIn(node_program, shift=DOWN),
            Create(line_program),
            Write(desc_program),
            run_time=1.2
        )

        # 第四层:项目
        self.play(GrowArrow(arrow3, run_time=0.6))
        self.play(
            FadeIn(node_project, shift=DOWN),
            Create(line_project),
            Write(desc_project),
            run_time=1.2
        )

        # 停留展示
