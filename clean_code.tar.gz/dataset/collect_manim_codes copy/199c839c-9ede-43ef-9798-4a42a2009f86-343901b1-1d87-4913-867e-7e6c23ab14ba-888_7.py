from manim import *

class LimitSymbolRepresentation(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("极限的符号表示",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 描述性文字
        description = Text("数学语言中用于严格表达“趋势”的标准记号",
                         font="AR PL UKai CN",
                         font_size=28,
                         color=LIGHT_GRAY)
        description.next_to(title_line, DOWN, buff=0.8)

        # 3. 核心数学公式
        # 将公式拆分以便进行颜色强调
        formula = MathTex(r"\lim_{x \to a}", r"f(x)", r"=", r"L", font_size=72)
        formula.next_to(description, DOWN, buff=1.0)

        # 设置颜色以区分不同部分
        formula[0].set_color(BLUE)   # 极限操作符和趋近过程
        formula[3].set_color(YELLOW) # 极限值 L

        # 重点框
        rect = SurroundingRectangle(formula, color=YELLOW, buff=0.3, stroke_width=2)

        # 4. 底部图解逻辑 (可视化概念)
        # 左侧：自变量趋近
        input_tex = MathTex(r"x \to a", color=BLUE, font_size=36)
        input_desc = Text("自变量趋近", font="AR PL UKai CN", font_size=20, color=BLUE)
        input_desc.next_to(input_tex, DOWN, buff=0.15)
        input_group = VGroup(input_tex, input_desc)

        # 中间：推导箭头
        arrow = Arrow(LEFT, RIGHT, color=WHITE).scale(0.8)

        # 右侧：函数值趋近
        output_tex = MathTex(r"f(x) \to L", color=YELLOW, font_size=36)
        output_desc = Text("函数值趋近", font="AR PL UKai CN", font_size=20, color=YELLOW)
        output_desc.next_to(output_tex, DOWN, buff=0.15)
        output_group = VGroup(output_tex, output_desc)

        # 组合底部解释部分
        explanation_group = VGroup(input_group, arrow, output_group)
        explanation_group.arrange(RIGHT, buff=0.8)
        explanation_group.next_to(rect, DOWN, buff=0.8)

        # 5. 动画播放流程
        self.play(FadeIn(description, shift=DOWN * 0.3))

        self.play(Write(formula), run_time=1.5)
        self.play(Create(rect))

        self.play(
            FadeIn(explanation_group, shift=UP * 0.2),
            run_time=1.2
        )
