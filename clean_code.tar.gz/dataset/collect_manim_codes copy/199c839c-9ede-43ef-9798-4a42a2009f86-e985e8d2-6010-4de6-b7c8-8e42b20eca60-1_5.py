from manim import *

class MarxPhilosophySignificance(Scene):
    def construct(self):

        # 字体配置
        font = "AR PL UKai CN"

        # ===================== 标题部分 (模板) =====================
        title = Text("马克思哲学的变革意义",
                    font_size=34,  # 增大字号
                    font=font,     # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ===================== 内容部分 1: 批判现实 =====================
        # 小标题
        sub1 = Text("1. 开辟了批判现实的理论武器", font=font, font_size=28, color=YELLOW)
        sub1.next_to(title_line, DOWN, buff=0.5)
        sub1.to_edge(LEFT, buff=1)

        # 流程图节点
        node1_text = Text("现实的人", font=font, font_size=24)
        node2_text = Text("揭示异化与私有制", font=font, font_size=24)
        node3_text = Text("无产阶级解放", font=font, font_size=24)

        # 为节点添加边框
        box1 = SurroundingRectangle(node1_text, color=BLUE, buff=0.2)
        box2 = SurroundingRectangle(node2_text, color=RED, buff=0.2)
        box3 = SurroundingRectangle(node3_text, color=GREEN, buff=0.2)

        # 组合节点
        group1 = VGroup(box1, node1_text)
        group2 = VGroup(box2, node2_text)
        group3 = VGroup(box3, node3_text)

        # 排列位置 (水平排列)
        flow_group = VGroup(group1, group2, group3).arrange(RIGHT, buff=1.5)
        flow_group.next_to(sub1, DOWN, buff=0.5).move_to(ORIGIN).shift(UP*0.5) # 居中调整

        # 箭头
        arrow1 = Arrow(box1.get_right(), box2.get_left(), buff=0.1, color=WHITE)
        arrow2 = Arrow(box2.get_right(), box3.get_left(), buff=0.1, color=WHITE)

        # 动画展示第一部分
        self.play(FadeIn(sub1, shift=RIGHT))
        self.play(
            Create(box1), Write(node1_text),
            run_time=1
        )
        self.play(GrowArrow(arrow1))
        self.play(
            Create(box2), Write(node2_text),
            run_time=1
        )
        self.play(GrowArrow(arrow2))
        self.play(
            Create(box3), Write(node3_text),
            run_time=1
        )

        # ===================== 内容部分 2: 唯物史观 =====================
        # 小标题
        sub2 = Text("2. 奠定了历史唯物主义的基础", font=font, font_size=28, color=YELLOW)
        sub2.next_to(flow_group, DOWN, buff=0.8)
        sub2.align_to(sub1, LEFT)

        # 结构图元素
        base_text = Text("经济基础 (物质生产)", font=font, font_size=24, color=BLUE_A)
        super_text = Text("上层建筑 (政治/法律/意识形态)", font=font, font_size=24, color=GOLD_A)

        # 边框
        base_box = SurroundingRectangle(base_text, color=BLUE_A, buff=0.15)
        super_box = SurroundingRectangle(super_text, color=GOLD_A, buff=0.15)

        # 组合
        base_group = VGroup(base_box, base_text)
        super_group = VGroup(super_box, super_text)

        # 垂直排列
        structure_group = VGroup(super_group, base_group).arrange(DOWN, buff=0.8)
        structure_group.next_to(sub2, DOWN, buff=0.3).set_x(0) # 居中

        # 向上箭头表示决定作用
        up_arrow = Arrow(base_box.get_top(), super_box.get_bottom(), buff=0.1, color=WHITE)
        arrow_label = Text("决定", font=font, font_size=18).next_to(up_arrow, RIGHT, buff=0.1)

        # 核心概念标签
        core_label = Text("唯物史观核心", font=font, font_size=20, color=GRAY)
        core_label.next_to(structure_group, RIGHT, buff=0.5)

        # 动画展示第二部分
        self.play(FadeIn(sub2, shift=RIGHT))
        self.play(
            FadeIn(base_group, shift=UP),
            run_time=0.8
        )
        self.play(
            GrowArrow(up_arrow),
            Write(arrow_label),
            run_time=0.6
        )
        self.play(
            FadeIn(super_group, shift=DOWN),
            Write(core_label),
            run_time=0.8
        )

        # 停顿
