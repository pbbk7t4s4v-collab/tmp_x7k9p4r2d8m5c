from manim import *

class ThermodynamicStateSpace(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("热力学状态空间图",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("111", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧文本内容：概念讲解
        # 使用 VGroup 手动排列 Text，避免 BulletedList 的兼容性问题
        text_config = {"font": "AR PL UKai CN", "font_size": 24, "color": LIGHT_GRAY}

        t1 = Text("1. 坐标轴：表示热力学性质 (如 P, V, T)", **text_config)
        t2 = Text("2. 状态点：系统特定的平衡状态", **text_config)
        t3 = Text("3. 过程线：状态变化的连续路径", **text_config)

        # 组合并排列文本
        text_group = VGroup(t1, t2, t3).arrange(DOWN, aligned_edge=LEFT, buff=0.6)
        text_group.to_edge(LEFT, buff=1).shift(UP * 0.5)

        self.play(Write(text_group, run_time=2))

        # 3. 右侧可视化：P-V 图示例
        # 创建坐标轴
        axes = Axes(
            x_range=[0, 6, 1],
            y_range=[0, 6, 1],
            x_length=5,
            y_length=4,
            axis_config={"color": BLUE},
            tips=True
        )

        # 坐标轴标签
        x_label = MathTex("V").next_to(axes.x_axis.get_end(), DR, buff=0.1)
        y_label = MathTex("P").next_to(axes.y_axis.get_end(), UL, buff=0.1)
        axes_labels = VGroup(x_label, y_label)

        # 定义两个状态点
        p1_coords = axes.c2p(1.5, 5)
        p2_coords = axes.c2p(5, 1.5)

        dot1 = Dot(p1_coords, color=YELLOW)
        dot2 = Dot(p2_coords, color=YELLOW)

        # 状态标签
        label1 = Text("状态 1", font="AR PL UKai CN", font_size=20).next_to(dot1, RIGHT)
        label2 = Text("状态 2", font="AR PL UKai CN", font_size=20).next_to(dot2, UP)

        # 绘制过程曲线 (模拟等温膨胀 P = k/V)
        # 使用 plot 绘制曲线
        curve = axes.plot(lambda x: 7.5 / x, x_range=[1.5, 5], color=RED)

        # 组合图表元素
        plot_group = VGroup(axes, axes_labels, dot1, dot2, label1, label2, curve)
        plot_group.to_edge(RIGHT, buff=1).shift(DOWN * 0.5)

        # 4. 动画展示图表构建过程
        # 画坐标轴
        self.play(Create(axes), Write(axes_labels), run_time=1.5)

        # 显示状态点
        self.play(
            FadeIn(dot1, scale=0.5),
            Write(label1),
            FadeIn(dot2, scale=0.5),
            Write(label2),
            run_time=1.5
        )

        # 画过程线
        self.play(Create(curve), run_time=1.5)

        # 5. 强调核心概念
        # 使用矩形框强调整个图表
        rect = SurroundingRectangle(plot_group, color=YELLOW, buff=0.2)
        rect_label = Text("P-V 示功图示例", font="AR PL UKai CN", font_size=20, color=YELLOW)
        rect_label.next_to(rect, DOWN)

        self.play(
            Create(rect),
            FadeIn(rect_label)
        )
