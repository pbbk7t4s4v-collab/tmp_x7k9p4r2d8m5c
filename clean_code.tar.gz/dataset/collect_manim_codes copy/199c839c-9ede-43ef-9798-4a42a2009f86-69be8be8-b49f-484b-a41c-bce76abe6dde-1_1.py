from manim import *

class WhatIsFluidMechanics(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("什么是流体力学",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧:流体定义
        # 标题
        fluid_title = Text("流体 (Fluid)", font="AR PL UKai CN", font_size=28, color=BLUE)

        # 液体示意图 (蓝色圆点代表水滴)
        liquid_dot = Circle(radius=0.15, color=BLUE, fill_opacity=0.8)
        liquid_text = Text("液体:具有流动性", font="AR PL UKai CN", font_size=22).next_to(liquid_dot, RIGHT)
        liquid_group = VGroup(liquid_dot, liquid_text)

        # 气体示意图 (灰色椭圆代表气体云)
        gas_cloud = Ellipse(width=0.5, height=0.3, color=GREY, fill_opacity=0.6)
        gas_text = Text("气体:容易被压缩", font="AR PL UKai CN", font_size=22).next_to(gas_cloud, RIGHT)
        gas_group = VGroup(gas_cloud, gas_text)

        # 左侧组合
        left_content = VGroup(fluid_title, liquid_group, gas_group).arrange(DOWN, buff=0.5, aligned_edge=LEFT)
        left_content.move_to(LEFT * 3.5)

        # 左侧框
        left_rect = SurroundingRectangle(left_content, color=BLUE, buff=0.2)

        # 3. 内容布局 - 右侧:力学定义
        # 标题
        mech_title = Text("力学 (Mechanics)", font="AR PL UKai CN", font_size=28, color=RED)

        # 力示意图 (箭头)
        force_arrow = Arrow(LEFT, RIGHT, buff=0, color=RED).scale(0.6)
        force_text = Text("力的作用与平衡", font="AR PL UKai CN", font_size=22).next_to(force_arrow, RIGHT)
        force_group = VGroup(force_arrow, force_text)

        # 运动示意图 (虚线路径)
        path_line = DashedLine(LEFT, RIGHT, color=YELLOW).scale(0.6)
        motion_text = Text("运动规律与能量", font="AR PL UKai CN", font_size=22).next_to(path_line, RIGHT)
        motion_group = VGroup(path_line, motion_text)

        # 右侧组合
        right_content = VGroup(mech_title, force_group, motion_group).arrange(DOWN, buff=0.5, aligned_edge=LEFT)
        right_content.move_to(RIGHT * 3.5)

        # 右侧框
        right_rect = SurroundingRectangle(right_content, color=RED, buff=0.2)

        # 4. 中间连接符号
        plus_sign = MathTex("+", font_size=60).move_to(ORIGIN)

        # 5. 底部总结定义
        summary_text = Text(
            "定义:研究流体在静止和运动状态下宏观规律的科学",
            font="AR PL UKai CN",
            font_size=26,
            color=YELLOW
        )
        summary_text.to_edge(DOWN, buff=1.5)

        # 6. 执行动画
        # 显示左右两部分
        self.play(
            FadeIn(left_content, shift=RIGHT),
            Create(left_rect),
            run_time=1.5
        )
        self.play(Write(plus_sign), run_time=0.5)
        self.play(
            FadeIn(right_content, shift=LEFT),
            Create(right_rect),
            run_time=1.5
        )

        # 显示底部总结
        self.play(Write(summary_text), run_time=1.5)
