from manim import *

class BatchProcessingJCL(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("批处理系统：作业控制语言 (JCL)",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("32", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心图形元素构建
        # 左侧：作业批 (Batch of Jobs)
        job_rects = VGroup()
        for i in range(3):
            rect = Rectangle(height=2.5, width=2, color=BLUE, fill_opacity=0.2)
            rect.shift(UP * i * 0.1 + RIGHT * i * 0.1)
            job_rects.add(rect)

        job_rects.center().to_edge(LEFT, buff=1.5)
        job_label = Text("作业批", font="AR PL UKai CN", font_size=24).next_to(job_rects, DOWN)

        # JCL 示例内容 (模拟代码卡片)
        jcl_content = VGroup(
            Text("// JOB A", font="Monospace", font_size=16, color=YELLOW),
            Text("// LOAD DATA", font="Monospace", font_size=16, color=WHITE),
            Text("// RUN", font="Monospace", font_size=16, color=GREEN)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        jcl_content.move_to(job_rects[-1].get_center())

        job_group = VGroup(job_rects, jcl_content, job_label)

        # 右侧：监督程序 (Monitor)
        monitor_box = Square(side_length=2.5, color=GREEN, fill_opacity=0.1)
        monitor_text = Text("监督程序\n(Monitor)", font="AR PL UKai CN", font_size=24, line_spacing=1.2)
        monitor_group = VGroup(monitor_box, monitor_text).arrange(ORIGIN).to_edge(RIGHT, buff=1.5)

        # 中间：流程箭头
        arrow = Arrow(start=job_rects.get_right(), end=monitor_box.get_left(), buff=0.5, color=GREY)
        jcl_label = Text("JCL 指令流", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(arrow, UP, buff=0.1)

        # 3. 底部说明文字 (手动构建列表以避免LaTeX中文问题)
        def create_bullet(text_str):
            dot = Text("•", font_size=24, color=ORANGE)
            txt = Text(text_str, font="AR PL UKai CN", font_size=24, color=WHITE)
            return VGroup(dot, txt).arrange(RIGHT, buff=0.2)

        bullet1 = create_bullet("用户使用JCL说明作业需求 (如加载、编译)")
        bullet2 = create_bullet("监督程序自动读取指令，减少人工干预")
        bullet3 = create_bullet("作业间自动过渡，提高CPU利用率")

        text_group = VGroup(bullet1, bullet2, bullet3).arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        text_group.to_edge(DOWN, buff=0.8)

        # 4. 动画流程
        # 第一步：展示作业批和JCL
        self.play(FadeIn(job_group, shift=RIGHT))

        # 强调 JCL 内容
        self.play(Indicate(jcl_content, color=YELLOW))
        self.play(Write(bullet1))

        # 第二步：展示监督程序和传输
        self.play(
            FadeIn(monitor_group, shift=LEFT),
            Create(arrow),
            Write(jcl_label)
        )
        self.play(Write(bullet2))

        # 第三步：模拟处理动画 (JCL指令移动到监督程序)
        jcl_copy = jcl_content.copy()
        self.play(
            jcl_copy.animate.move_to(monitor_box.get_center()).scale(0.5).set_opacity(0),
            Flash(monitor_box, color=GREEN, flash_radius=1.5),
            run_time=1.5
        )

        # 第四步：结论
        self.play(Write(bullet3))

        # 强调框
        final_rect = SurroundingRectangle(text_group, color=BLUE, buff=0.2)
        self.play(Create(final_rect))
