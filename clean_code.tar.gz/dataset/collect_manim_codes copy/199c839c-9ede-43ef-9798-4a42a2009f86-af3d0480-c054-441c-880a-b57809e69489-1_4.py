from manim import *

class FluidDynamicsInBiology(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Applications in Medicine & Biology",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Key Application Areas
        applications_list = BulletedList(
            "Hemodynamics: Modeling blood flow to assess cardiovascular health (e.g., arteriosclerosis).",
            "Medical Device Design: Simulating flow for artificial hearts, stents, and valves.",
            "Biofluid Dynamics: Explaining respiration, fish swimming, and bird flight.",
            font_size=28
        ).next_to(title_group, DOWN, buff=0.7).to_edge(LEFT, buff=0.8)

        # 3. Animate the list items sequentially
        for i, item in enumerate(applications_list):
            self.play(FadeIn(item, shift=UP*0.2), run_time=1.2)
