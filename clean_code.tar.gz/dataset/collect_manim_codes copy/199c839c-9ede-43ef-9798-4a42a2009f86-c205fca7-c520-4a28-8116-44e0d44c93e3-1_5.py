from manim import *

class LargeModelsAndTuring(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置
        # ---------------------------------------------------------
        title = Text("大模型的兴起与图灵测试",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 左侧:图灵测试示意图
        # ---------------------------------------------------------
        # 定义左侧区域中心
        left_center = LEFT * 3.5 + DOWN * 0.5

        # 裁判 (C)
        judge = Circle(radius=0.4, color=BLUE, fill_opacity=0.5).move_to(left_center + LEFT * 1.5)
        judge_label = Text("裁判", font="AR PL UKai CN", font_size=20).next_to(judge, UP)

        # 屏障 (Wall)
        wall = DashedLine(UP, DOWN, color=GREY).scale(1.5).move_to(left_center)

        # 机器 (A) 和 人类 (B)
        machine_box = Square(side_length=0.8, color=RED, fill_opacity=0.5).move_to(left_center + RIGHT * 1.5 + UP * 1.0)
        human_box = Square(side_length=0.8, color=GREEN, fill_opacity=0.5).move_to(left_center + RIGHT * 1.5 + DOWN * 1.0)

        machine_label = Text("机器", font="AR PL UKai CN", font_size=20).next_to(machine_box, RIGHT)
        human_label = Text("人类", font="AR PL UKai CN", font_size=20).next_to(human_box, RIGHT)

        # 交互箭头
        arrow_top = DoubleArrow(judge.get_right(), machine_box.get_left(), buff=0.1, color=YELLOW)
        arrow_bottom = DoubleArrow(judge.get_right(), human_box.get_left(), buff=0.1, color=YELLOW)

        # 核心问题文本
        question_text = Text("能否区分?", font="AR PL UKai CN", font_size=24, color=YELLOW).next_to(wall, UP)

        turing_group = VGroup(judge, judge_label, wall, machine_box, human_box, machine_label, human_label, arrow_top, arrow_bottom, question_text)

        # ---------------------------------------------------------
        # 3. 右侧:大模型的演进
        # ---------------------------------------------------------
        # 定义右侧区域中心
        right_center = RIGHT * 3.5 + DOWN * 0.5

        # 演进阶梯
        box_config = {"width": 3.5, "height": 0.8, "color": WHITE, "fill_opacity": 0.2}

        step1 = Rectangle(**box_config, fill_color=GREY).move_to(right_center + DOWN * 1.2)
        text1 = Text("早期规则/统计模型", font="AR PL UKai CN", font_size=20).move_to(step1)

        step2 = Rectangle(**box_config, fill_color=BLUE_D).move_to(right_center)
        text2 = Text("深度神经网络 (DNN)", font="AR PL UKai CN", font_size=20).move_to(step2)

        step3 = Rectangle(**box_config, fill_color=PURPLE).move_to(right_center + UP * 1.2)
        text3 = Text("大语言模型 (LLM)", font="AR PL UKai CN", font_size=20, weight=BOLD).move_to(step3)

        # 向上箭头表示参数量/能力提升
        evolution_arrow = Arrow(step1.get_right() + RIGHT*0.2, step3.get_right() + RIGHT*0.2, buff=0.1, color=GREEN)
        evolution_text = Text("规模与涌现", font="AR PL UKai CN", font_size=18, color=GREEN).next_to(evolution_arrow, RIGHT)

        llm_group = VGroup(step1, text1, step2, text2, step3, text3, evolution_arrow, evolution_text)

        # ---------------------------------------------------------
        # 4. 动画流程
        # ---------------------------------------------------------

        # 展示图灵测试
        self.play(Create(turing_group), run_time=3)

        # 展示大模型演进
        self.play(FadeIn(step1, shift=UP), Write(text1), run_time=1)
        self.play(FadeIn(step2, shift=UP), Write(text2), run_time=1)
        self.play(FadeIn(step3, shift=UP), Write(text3), run_time=1)
        self.play(GrowArrow(evolution_arrow), Write(evolution_text), run_time=1)

        # ---------------------------------------------------------
        # 5. 建立联系 (LLM 挑战 图灵测试)
        # ---------------------------------------------------------
        # 高亮 LLM
        highlight_rect = SurroundingRectangle(step3, color=YELLOW, buff=0.05)

        # 连接线:从 LLM 指向 机器
        connection = CurvedArrow(step3.get_left(), machine_box.get_top(), color=YELLOW, angle=TAU/4)
        connection_text = Text("逼近人类水平", font="AR PL UKai CN", font_size=24, color=YELLOW).next_to(connection, UP, buff=0.1)

        self.play(
            Create(highlight_rect),
            Create(connection),
            Write(connection_text),
            run_time=2
        )
