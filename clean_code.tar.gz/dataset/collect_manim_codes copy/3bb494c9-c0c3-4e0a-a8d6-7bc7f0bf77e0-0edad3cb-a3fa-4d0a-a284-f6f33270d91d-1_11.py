from manim import *

class EulerEquationsScene(Scene):
    def construct(self):

        # ---- Title Section (Template) ----
        title = Text("Derivation of Typical PDEs: Full System",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # Add bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Animate title
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("11", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---- Content Section ----

        # Define the two equations separately for better layout control
        # Equation 1: Mass Conservation
        eq1 = MathTex(r"\rho_t + \mathrm{div}(\rho u) = 0")

        # Equation 2: Momentum Conservation
        # \otimes represents the tensor product
        eq2 = MathTex(r"(\rho u)_t + \mathrm{div}(\rho u \otimes u) + \nabla p = 0")

        # Group and arrange them vertically
        eq_group = VGroup(eq1, eq2).arrange(DOWN, buff=0.8, aligned_edge=LEFT)

        # Create a brace to the left to represent the system (cases)
        brace = Brace(eq_group, LEFT)

        # Add the equation tag
        tag = MathTex(r"(1.1.12)", font_size=28, color=GRAY)
        tag.next_to(eq_group, RIGHT, buff=1.0)

        # Combine everything into a main group and center it
        main_system = VGroup(brace, eq_group, tag).move_to(ORIGIN)

        # Explanatory text for the equations
        label_mass = Text("Conservation of Mass", font_size=24, color=BLUE_C)
        label_mass.next_to(eq1, UP, buff=0.1).align_to(eq1, LEFT)

        label_momentum = Text("Conservation of Momentum", font_size=24, color=GREEN_C)
        label_momentum.next_to(eq2, DOWN, buff=0.1).align_to(eq2, LEFT)

        # ---- Animation Sequence ----

        # 1. Write the mathematical system
        self.play(
            Write(brace),
            Write(eq_group),
            FadeIn(tag),
            run_time=2.0
        )

        # 2. Reveal the physical meaning labels
        self.play(
            FadeIn(label_mass, shift=UP * 0.2),
            FadeIn(label_momentum, shift=DOWN * 0.2),
            run_time=1.5
        )

        # 3. Highlight the result with a rectangle
        rect = SurroundingRectangle(main_system, color=YELLOW, buff=0.2)
        self.play(Create(rect), run_time=1.0)
