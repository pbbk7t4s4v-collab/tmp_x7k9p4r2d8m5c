from manim import *

class BodyFrameRepresentation(Scene):
    def construct(self):

        # 1. Title Configuration
        title = Text("Body Frame Representation in Space Frame",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # Add bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Group title elements
        title_group = VGroup(title, title_line)

        # Title Animation - Scale and Fade In
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Visual Layout Definitions
        # Define origin for coordinate systems on the left side
        origin = LEFT * 3.5 + DOWN * 0.5

        # --- Space Frame {s} (Fixed, Gray) ---
        # Pseudo-3D representation: X right, Y up, Z diagonal down-left
        s_x = Arrow(start=origin, end=origin + RIGHT * 2, buff=0, color=GRAY, stroke_width=3)
        s_y = Arrow(start=origin, end=origin + UP * 2, buff=0, color=GRAY, stroke_width=3)
        # Projected Z axis
        s_z_end = origin + np.array([-1, -1, 0])
        s_z = Line(origin, s_z_end, color=GRAY, stroke_width=3).add_tip(tip_length=0.2)

        s_label_x = MathTex("x_s", color=GRAY, font_size=24).next_to(s_x.get_end(), RIGHT, buff=0.1)
        s_label_y = MathTex("y_s", color=GRAY, font_size=24).next_to(s_y.get_end(), UP, buff=0.1)
        s_label_frame = MathTex("\{s\}", color=GRAY, font_size=30).next_to(origin, DL, buff=0.2)

        space_frame = VGroup(s_x, s_y, s_z, s_label_x, s_label_y, s_label_frame)

        # --- Body Frame {b} (Rotated, Colored) ---
        # Rotate vectors by 30 degrees for visualization
        angle = 30 * DEGREES

        # Helper to rotate a vector in 2D (XY plane)
        def rotate_vector(vec, theta):
            x, y, z = vec
            new_x = x * np.cos(theta) - y * np.sin(theta)
            new_y = x * np.sin(theta) + y * np.cos(theta)
            return np.array([new_x, new_y, z])

        # Calculate rotated end points
        b_x_vec = rotate_vector(RIGHT * 2, angle)
        b_y_vec = rotate_vector(UP * 2, angle)
        b_z_vec = np.array([-1.2, -0.6, 0]) # Slightly different Z projection to show rotation

        b_x = Arrow(start=origin, end=origin + b_x_vec, buff=0, color=RED, stroke_width=5)
        b_y = Arrow(start=origin, end=origin + b_y_vec, buff=0, color=GREEN, stroke_width=5)
        b_z = Line(origin, origin + b_z_vec, color=BLUE, stroke_width=5).add_tip(tip_length=0.2)

        b_label_x = MathTex(r"\hat{x}_b", color=RED, font_size=30).next_to(b_x.get_end(), RIGHT, buff=0.1)
        b_label_y = MathTex(r"\hat{y}_b", color=GREEN, font_size=30).next_to(b_y.get_end(), UP, buff=0.1)
        b_label_z = MathTex(r"\hat{z}_b", color=BLUE, font_size=30).next_to(b_z.get_end(), LEFT, buff=0.1)

        body_frame = VGroup(b_x, b_y, b_z, b_label_x, b_label_y, b_label_z)

        # 3. Content and Formulas (Right Side)

        # Bullet points
        bullets = BulletedList(
            r"Rotation matrix $R_{sb}$ defines orientation",
            r"of $\{b\}$ relative to $\{s\}$",
            r"Columns are unit vectors of $\{b\}$ in $\{s\}$",
            font_size=28,
            buff=0.3
        )
        bullets.to_edge(RIGHT, buff=1.0).shift(UP * 1.0)

        # Matrix Equation Construction
        # R_sb = [ x_b  y_b  z_b ]
        eq_label = MathTex(r"R_{sb} =", font_size=44)

        # Construct matrix visually with vertical bars to emphasize columns
        matrix_left = MathTex(r"\begin{bmatrix}", font_size=44)
        matrix_right = MathTex(r"\end{bmatrix}", font_size=44)

        col_x = MathTex(r"| \\ \hat{x}_b \\ |", color=RED, font_size=38)
        col_y = MathTex(r"| \\ \hat{y}_b \\ |", color=GREEN, font_size=38)
        col_z = MathTex(r"| \\ \hat{z}_b \\ |", color=BLUE, font_size=38)

        # Group columns
        cols = VGroup(col_x, col_y, col_z).arrange(RIGHT, buff=0.4)
        matrix_group = VGroup(matrix_left, cols, matrix_right).arrange(RIGHT, buff=0.1)

        # Combine equation
        formula = VGroup(eq_label, matrix_group).arrange(RIGHT, buff=0.2)
        formula.next_to(bullets, DOWN, buff=1.0)
        formula.align_to(bullets, LEFT)

        # Highlight Box
        rect = SurroundingRectangle(formula, color=YELLOW, buff=0.2)
        rect_label = Text("Projection of Body Axes", font_size=24, color=YELLOW)
        rect_label.next_to(rect, DOWN, buff=0.1)

        # 4. Animation Sequence
        # Step 1: Draw Space Frame
        self.play(FadeIn(space_frame))

        # Step 2: Animate Body Frame vectors growing
        self.play(
            GrowArrow(b_x),
            GrowArrow(b_y),
            Create(b_z),
            run_time=1.5
        )
        self.play(Write(b_label_x), Write(b_label_y), Write(b_label_z))

        # Step 3: Show Bullet points
        self.play(Write(bullets, run_time=3))

        # Step 4: Transform vectors to Matrix representation idea
        # (We just write the formula, but logically it connects)
        self.play(FadeIn(formula, shift=UP))

        # Step 5: Highlight the concept
        self.play(Create(rect), Write(rect_label))
