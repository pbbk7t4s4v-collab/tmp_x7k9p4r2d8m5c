from manim import *

class CalculusSignificance(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (按照模板要求)
        # ---------------------------------------------------------
        title = Text("微积分的实际应用与意义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 实际应用示例:圆柱体优化问题
        # ---------------------------------------------------------
        # 简易圆柱体几何图形
        cyl_color = BLUE_C
        ellipse_top = Ellipse(width=2.0, height=0.6, color=cyl_color)
        ellipse_bottom = Ellipse(width=2.0, height=0.6, color=cyl_color)
        ellipse_bottom.shift(DOWN * 2.0) # 向下移动底部椭圆
        ellipse_top.next_to(ellipse_bottom, UP, buff=1.5) # 调整顶部位置

        # 连接线
        line_left = Line(ellipse_top.get_left(), ellipse_bottom.get_left(), color=cyl_color)
        line_right = Line(ellipse_top.get_right(), ellipse_bottom.get_right(), color=cyl_color)

        # 标注
        label_v = MathTex("V", color=WHITE).move_to(VGroup(ellipse_top, ellipse_bottom).get_center())
        label_r = MathTex("r", color=WHITE).next_to(ellipse_top, RIGHT, buff=0.1).scale(0.8)

        cylinder_group = VGroup(ellipse_top, ellipse_bottom, line_left, line_right, label_v, label_r)
        cylinder_group.scale(0.8).to_edge(LEFT, buff=1.5).shift(UP * 0.5)

        # 对应的数学公式
        problem_text = Text("给定容积 V,求最小表面积 S", font="AR PL UKai CN", font_size=24, color=YELLOW)
        problem_text.next_to(cylinder_group, UP, buff=0.3)

        formula_s = MathTex(r"S(r) = 2\pi r^2 + \frac{2V}{r}", font_size=32)
        formula_deriv = MathTex(r"\Rightarrow S'(r) = 0", color=RED, font_size=32)

        formulas = VGroup(formula_s, formula_deriv).arrange(DOWN, buff=0.3, aligned_edge=LEFT)
        formulas.next_to(cylinder_group, RIGHT, buff=1.0)

        # 展示第一部分:优化问题
        self.play(FadeIn(problem_text))
        self.play(Create(cylinder_group), run_time=1.5)
        self.play(Write(formulas))

        # ---------------------------------------------------------
        # 3. 核心概念升华:思维方式
        # ---------------------------------------------------------
        # 定义总结性文字
        summary_lines = VGroup(
            Text("微积分不仅是计算技巧,更是一种思维方式:", font="AR PL UKai CN", font_size=26, color=ORANGE),
            Text("1. 用数学眼光洞察变化的本质", font="AR PL UKai CN", font_size=24, color=WHITE),
            Text("2. 把握动态过程的规律", font="AR PL UKai CN", font_size=24, color=WHITE)
        ).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        # 将总结文字放在屏幕下方
        summary_lines.to_edge(DOWN, buff=1.0)

        # 添加强调框
        box = SurroundingRectangle(summary_lines, color=BLUE, buff=0.2)

        # 动画展示总结
        self.play(Create(box))
        self.play(Write(summary_lines), run_time=2)
