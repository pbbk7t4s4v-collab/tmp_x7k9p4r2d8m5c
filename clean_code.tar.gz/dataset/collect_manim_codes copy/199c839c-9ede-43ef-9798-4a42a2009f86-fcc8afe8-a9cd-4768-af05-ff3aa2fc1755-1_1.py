from manim import *

class CalculusIntroduction(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("微积分：从静态到动态的思维跃迁",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧静态思维
        # 定义坐标系
        left_axes = Axes(
            x_range=[0, 5], y_range=[0, 5],
            x_length=3.5, y_length=3.5,
            axis_config={"include_tip": True, "tip_shape": StealthTip}
        )

        # 静态直线 y = x
        static_graph = left_axes.plot(lambda x: x, color=BLUE)
        static_label = MathTex(r"y = kx + b", color=BLUE).next_to(static_graph, UP + LEFT, buff=0.1)

        left_text = Text("静态思维：恒定不变", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        left_text.next_to(left_axes, DOWN)

        left_group = VGroup(left_axes, static_graph, static_label, left_text)
        left_group.to_edge(LEFT, buff=1.5).shift(DOWN * 0.5)

        # 3. 内容布局 - 右侧动态思维
        right_axes = Axes(
            x_range=[0, 5], y_range=[0, 5],
            x_length=3.5, y_length=3.5,
            axis_config={"include_tip": True, "tip_shape": StealthTip}
        )

        # 动态曲线
        def func(x):
            return 0.1 * (x - 2)**3 + 2

        dynamic_graph = right_axes.plot(func, x_range=[0, 5], color=RED)
        right_text = Text("动态思维：瞬息万变", font="AR PL UKai CN", font_size=24, color=RED_A)
        right_text.next_to(right_axes, DOWN)

        # 动态点和切线
        t = ValueTracker(1)
        dot = always_redraw(lambda: Dot(right_axes.c2p(t.get_value(), func(t.get_value())), color=YELLOW))
        tangent = always_redraw(lambda: TangentLine(
            dynamic_graph,
            alpha=t.get_value() / 5, # alpha is 0 to 1
            length=3,
            color=YELLOW
        ))

        right_group_static_parts = VGroup(right_axes, dynamic_graph, right_text)
        right_group_static_parts.to_edge(RIGHT, buff=1.5).shift(DOWN * 0.5)

        # 4. 中间过渡箭头
        arrow = Arrow(left_axes.get_right(), right_axes.get_left(), buff=0.5, color=WHITE)
        arrow_text = Text("思维跃迁", font="AR PL UKai CN", font_size=20).next_to(arrow, UP, buff=0.1)

        # 5. 动画流程
        # 展示左侧
        self.play(Create(left_axes), run_time=1)
        self.play(Create(static_graph), Write(static_label), FadeIn(left_text))

        # 展示过渡
        self.play(GrowArrow(arrow), Write(arrow_text))

        # 展示右侧
        self.play(Create(right_axes), Create(dynamic_graph), FadeIn(right_text))

        # 强调框
        rect = SurroundingRectangle(right_group_static_parts, color=YELLOW, buff=0.2)

        # 动态演示切线变化
        self.add(dot, tangent)
        self.play(
            Create(rect),
            t.animate.set_value(4),
            run_time=3,
            rate_func=smooth
        )
