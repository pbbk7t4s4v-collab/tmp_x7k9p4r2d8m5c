from manim import *

class BSTStructureExample(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("二叉搜索树(BST)结构示例",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("28", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 定义节点生成函数
        def create_node(number, position, color=WHITE):
            circle = Circle(radius=0.4, color=color, fill_opacity=0.2, fill_color=color)
            text = Text(str(number), font="AR PL UKai CN", font_size=24).move_to(circle.get_center())
            node = VGroup(circle, text)
            node.move_to(position)
            return node

        # 3. 设置节点坐标
        # 根节点
        pos_8 = UP * 1.5
        # 第二层
        pos_3 = pos_8 + LEFT * 2.5 + DOWN * 1.5
        pos_10 = pos_8 + RIGHT * 2.5 + DOWN * 1.5
        # 第三层
        pos_1 = pos_3 + LEFT * 1.2 + DOWN * 1.5
        pos_6 = pos_3 + RIGHT * 1.2 + DOWN * 1.5
        pos_14 = pos_10 + RIGHT * 1.2 + DOWN * 1.5

        # 4. 创建节点对象
        node_8 = create_node(8, pos_8, color=YELLOW) # 根

        node_3 = create_node(3, pos_3, color=BLUE)   # 左子树 < 8
        node_10 = create_node(10, pos_10, color=RED) # 右子树 > 8

        node_1 = create_node(1, pos_1, color=BLUE)
        node_6 = create_node(6, pos_6, color=BLUE)
        node_14 = create_node(14, pos_14, color=RED)

        # 5. 创建连线
        line_8_3 = Line(node_8.get_bottom(), node_3.get_top(), color=WHITE)
        line_8_10 = Line(node_8.get_bottom(), node_10.get_top(), color=WHITE)

        line_3_1 = Line(node_3.get_bottom(), node_1.get_top(), color=BLUE_E)
        line_3_6 = Line(node_3.get_bottom(), node_6.get_top(), color=BLUE_E)

        line_10_14 = Line(node_10.get_bottom(), node_14.get_top(), color=RED_E)

        # 6. 动画展示流程
        # 第一步:显示根节点
        self.play(FadeIn(node_8, scale=0.5), run_time=0.8)

        # 第二步:生长出左右子节点 (强调大小关系)
        self.play(
            Create(line_8_3), FadeIn(node_3, shift=DOWN),
            Create(line_8_10), FadeIn(node_10, shift=DOWN),
            run_time=1.0
        )

        # 第三步:生长出叶子节点
        self.play(
            AnimationGroup(
                Create(line_3_1), FadeIn(node_1, shift=DOWN),
                Create(line_3_6), FadeIn(node_6, shift=DOWN),
                Create(line_10_14), FadeIn(node_14, shift=DOWN),
                lag_ratio=0.2
            ),
            run_time=1.2
        )

        # 7. 添加性质说明
        # 左边矩形框
        left_group = VGroup(node_3, node_1, node_6)
        rect_left = SurroundingRectangle(left_group, color=BLUE, buff=0.15, corner_radius=0.2)
        label_left = Text("左子树 < 8", font="AR PL UKai CN", font_size=20, color=BLUE).next_to(rect_left, DOWN)

        # 右边矩形框
        right_group = VGroup(node_10, node_14)
        rect_right = SurroundingRectangle(right_group, color=RED, buff=0.15, corner_radius=0.2)
        label_right = Text("右子树 > 8", font="AR PL UKai CN", font_size=20, color=RED).next_to(rect_right, DOWN)

        # 底部总结文字
        summary_text = Text(
            "性质:左子树所有节点 < 根节点 < 右子树所有节点",
            font="AR PL UKai CN",
            font_size=26,
            color=YELLOW
        ).to_edge(DOWN, buff=0.5)

        self.play(
            Create(rect_left), Write(label_left),
            Create(rect_right), Write(label_right),
            run_time=1.5
        )

        self.play(Write(summary_text), run_time=1.5)
