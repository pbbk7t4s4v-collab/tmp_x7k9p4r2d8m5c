from manim import *

class CalculusMeaning(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("微积分的核心思想",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念文本:无限逼近
        core_concept = Text("核心思想:无限逼近", font="AR PL UKai CN", font_size=28, color=YELLOW)
        core_concept.next_to(title_line, DOWN, buff=0.3)
        self.play(FadeIn(core_concept, shift=DOWN))

        # 3. 左右分栏展示导数与积分
        # 左侧:导数(瞬时变化率)
        axes_left = Axes(
            x_range=[0, 4], y_range=[0, 5],
            x_length=4, y_length=3,
            axis_config={"include_tip": True}
        )
        graph_left = axes_left.plot(lambda x: 0.5 * (x-1)**2 + 1, x_range=[0, 3.5], color=BLUE)

        # 切线展示瞬时变化率
        t_x = 2.0
        tangent = TangentLine(graph_left, alpha=t_x/3.5, length=3, color=RED)
        dot = Dot(axes_left.c2p(t_x, graph_left.underlying_function(t_x)), color=RED)

        label_left = Text("导数:瞬时变化率", font="AR PL UKai CN", font_size=24)
        label_left.next_to(axes_left, DOWN)

        group_left = VGroup(axes_left, graph_left, tangent, dot, label_left)
        group_left.to_edge(LEFT, buff=1).shift(DOWN*0.5)

        # 右侧:积分(累积效应)
        axes_right = Axes(
            x_range=[0, 4], y_range=[0, 5],
            x_length=4, y_length=3,
            axis_config={"include_tip": True}
        )
        graph_right = axes_right.plot(lambda x: 0.5 * (x-1)**2 + 1, x_range=[0, 3.5], color=BLUE)

        # 面积展示累积效应
        area = axes_right.get_area(graph_right, x_range=[0.5, 2.5], color=GREEN, opacity=0.5)

        label_right = Text("积分:累积效应", font="AR PL UKai CN", font_size=24)
        label_right.next_to(axes_right, DOWN)

        group_right = VGroup(axes_right, graph_right, area, label_right)
        group_right.to_edge(RIGHT, buff=1).shift(DOWN*0.5)

        # 4. 动画展示图形
        self.play(
            Create(axes_left), Create(graph_left),
            Create(axes_right), Create(graph_right),
            run_time=1.5
        )

        self.play(
            Create(tangent), FadeIn(dot), Write(label_left),
            FadeIn(area), Write(label_right),
            run_time=1.5
        )

        # 5. 微积分基本定理连接
        arrow = DoubleArrow(
            start=group_left.get_right() + LEFT*0.5,
            end=group_right.get_left() + RIGHT*0.5,
            color=ORANGE,
            buff=0.1
        )

        theorem_text = Text("互为逆运算\n(基本定理)", font="AR PL UKai CN", font_size=20, color=ORANGE)
        theorem_text.next_to(arrow, UP, buff=0.1)

        # 使用矩形框强调
        rect = SurroundingRectangle(theorem_text, color=WHITE, buff=0.1, corner_radius=0.1)

        self.play(
            GrowFromCenter(arrow),
            FadeIn(theorem_text),
            Create(rect),
            run_time=1.5
        )
