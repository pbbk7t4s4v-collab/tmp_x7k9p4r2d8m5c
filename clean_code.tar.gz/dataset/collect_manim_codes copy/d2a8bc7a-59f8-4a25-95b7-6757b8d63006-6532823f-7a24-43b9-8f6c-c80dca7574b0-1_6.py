from manim import *

class CrossMediaModelDesign(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (标准模板)
        # ---------------------------------------------------------
        title = Text("跨媒体大模型软件设计与开发",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 范式演进展示 (顶部)
        # ---------------------------------------------------------
        # 展示从"工具"到"助手"的演变
        t_old = Text("媒体处理工具", font="AR PL UKai CN", font_size=24, color=BLUE_C)
        arrow = Arrow(LEFT, RIGHT, color=WHITE).scale(0.8)
        t_new = Text("智能创作助手", font="AR PL UKai CN", font_size=24, color=GOLD_C)

        evolution_group = VGroup(t_old, arrow, t_new).arrange(RIGHT, buff=0.5)
        evolution_group.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(evolution_group, shift=UP))

        # ---------------------------------------------------------
        # 3. 核心技术可视化：多模态编码器与对齐 (中部)
        # ---------------------------------------------------------
        # 使用几何图形展示 CLIP 类的图文对齐原理

        # 左侧：图像处理流
        img_shape = Square(side_length=1.0, color=BLUE, fill_opacity=0.2)
        img_label = Text("图像", font="AR PL UKai CN", font_size=20).move_to(img_shape)
        img_group = VGroup(img_shape, img_label)

        # 右侧：文本处理流
        txt_shape = Square(side_length=1.0, color=GREEN, fill_opacity=0.2)
        txt_label = Text("文本", font="AR PL UKai CN", font_size=20).move_to(txt_shape)
        txt_group = VGroup(txt_shape, txt_label)

        # 布局输入
        inputs = VGroup(img_group, txt_group).arrange(RIGHT, buff=4)
        inputs.next_to(evolution_group, DOWN, buff=0.7)

        # 编码器表示
        encoder_box = RoundedRectangle(corner_radius=0.2, height=1.2, width=5.5, color=GREY)
        encoder_text = Text("Transformer 多模态编码器", font="AR PL UKai CN", font_size=20, color=GREY_A)
        encoder_group = VGroup(encoder_box, encoder_text).move_to(inputs.get_center())

        # 箭头流向
        arrow_img = Arrow(img_group.get_right(), encoder_box.get_left(), buff=0.1, color=BLUE)
        arrow_txt = Arrow(txt_group.get_left(), encoder_box.get_right(), buff=0.1, color=GREEN)

        # 核心公式 (统一语义空间)
        # 使用 Text 展示简单公式，避免 LaTeX 编译
        formula = Text(
            "sim = cos(v_img, v_txt)",
            color=YELLOW,
            font_size=32
        )
        formula.next_to(encoder_box, DOWN, buff=0.4)

        # 动画播放：输入 -> 编码 -> 公式
        self.play(
            FadeIn(img_group, shift=RIGHT),
            FadeIn(txt_group, shift=LEFT),
            Create(encoder_group)
        )
        self.play(
            GrowArrow(arrow_img),
            GrowArrow(arrow_txt)
        )
        self.play(Write(formula))

        # ---------------------------------------------------------
        # 4. 关键技术列表 (底部)
        # ---------------------------------------------------------
        # 总结三个核心技术点
        items = [
            "• 多模态编码器: 映射到统一语义空间 (CLIP)",
            "• 跨模态注意力: 关联不同媒体语义 (DALL·E)",
            "• 提示工程(Prompt): 引导模型完成任务",
        ]
        tech_list = VGroup(*[
            Text(item, font="AR PL UKai CN", font_size=22, color=WHITE)
            for item in items
        ])
        tech_list.set_color(WHITE)
        tech_list.arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        tech_list.next_to(formula, DOWN, buff=0.5)

        # 添加外框强调
        box = SurroundingRectangle(tech_list, color=TEAL, buff=0.2)

        self.play(
            FadeIn(tech_list, shift=UP),
            Create(box)
        )
