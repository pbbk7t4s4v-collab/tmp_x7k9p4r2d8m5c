from manim import *
import random
import numpy as np

class TimeMetaphorCase(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("典型案例:关于时间的隐喻",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 提示词展示 (顶部居中)
        prompt_label = Text("输入提示词 (Prompt)", font_size=24, color=GREY_B, font="AR PL UKai CN")
        prompt_content = Text(""写一个关于时间的隐喻"", font_size=32, color=YELLOW, font="AR PL UKai CN")

        prompt_box = VGroup(prompt_label, prompt_content).arrange(DOWN, buff=0.15)
        prompt_bg = SurroundingRectangle(prompt_box, color=BLUE, buff=0.2, fill_opacity=0.1)

        prompt_group = VGroup(prompt_bg, prompt_box)
        prompt_group.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(prompt_group, shift=DOWN))

        # 3. 数据规模展示 (左侧)
        stats_title = Text("实验规模", font_size=28, color=BLUE_A, font="AR PL UKai CN")
        stats_1 = Text("• 涉及模型:25 个", font_size=24, font="AR PL UKai CN")
        stats_2 = Text("• 生成回答:1250 条", font_size=24, font="AR PL UKai CN")

        stats_group = VGroup(stats_title, stats_1, stats_2).arrange(DOWN, buff=0.3, aligned_edge=LEFT)
        stats_group.to_edge(LEFT, buff=1.5).shift(DOWN * 0.5)

        self.play(Write(stats_group))

        # 4. 可视化:从散乱到聚类 (右侧)
        # 创建代表回答的点
        dots = VGroup()
        for _ in range(60): # 用60个点代表大量数据
            dot = Dot(radius=0.06, color=WHITE)
            # 初始位置:在右侧区域随机分布
            x_pos = random.uniform(0, 5)
            y_pos = random.uniform(-2, 2)
            dot.move_to(np.array([x_pos, y_pos, 0]))
            dots.add(dot)

        dots_center = dots.get_center()

        # 箭头连接
        arrow = Arrow(stats_group.get_right(), dots.get_left(), color=GREY, buff=0.2)

        self.play(
            Create(arrow),
            FadeIn(dots, lag_ratio=0.05, run_time=1)
        )

        # 5. 聚类动画:同质化现象
        # 定义两个主要的聚类中心
        cluster_center_1 = np.array([3.5, 0.5, 0])
        cluster_center_2 = np.array([3.5, -2.0, 0])

        anims = []
        for i, dot in enumerate(dots):
            # 模拟分为两类
            if i % 2 == 0:
                target = cluster_center_1
                color = TEAL
            else:
                target = cluster_center_2
                color = RED

            # 添加一点随机偏移,看起来更像簇
            offset = np.array([random.uniform(-0.6, 0.6), random.uniform(-0.4, 0.4), 0])
            anims.append(
                dot.animate.move_to(target + offset).set_color(color)
            )

        result_text = Text("结果:聚为仅两个主要簇", font_size=26, color=ORANGE, font="AR PL UKai CN")
        result_text.move_to(np.array([3.5, 2.0, 0])) # 放在上方

        self.play(
            *anims,
            Write(result_text),
            run_time=2
        )

        # 6. 强调框
        final_rect = SurroundingRectangle(dots, color=YELLOW, buff=0.2)
        self.play(Create(final_rect))
