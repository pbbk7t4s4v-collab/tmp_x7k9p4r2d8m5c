from manim import *

class PracticeElementsAndStatus(Scene):
    def construct(self):

        # --- 1. 标题设置 (严格按照模板) ---
        title = Text("实践活动的构成要素与核心地位",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("15", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- 2. 实践活动的构成要素 (可视化图解) ---
        # 定义字体配置
        font_conf = {"font": "AR PL UKai CN"}

        # 核心三要素
        subject = Text("主体", **font_conf, color=BLUE, font_size=28)
        object_ = Text("客体", **font_conf, color=GREEN, font_size=28)

        # 布局位置
        subject.shift(LEFT * 3 + UP * 1)
        object_.shift(RIGHT * 3 + UP * 1)

        # 连接箭头与中介
        arrow = Arrow(start=subject.get_right(), end=object_.get_left(), buff=0.5, color=WHITE)
        medium_label = Text("中介", **font_conf, color=YELLOW, font_size=24).next_to(arrow, UP, buff=0.1)
        medium_desc = Text("(工具、方法)", **font_conf, color=GRAY, font_size=18).next_to(medium_label, DOWN, buff=0.1)

        # 组合中介部分以避免遮挡
        medium_group = VGroup(medium_label, medium_desc)
        # 稍微调整箭头上的文字位置，避免压住箭头
        medium_group.shift(UP * 0.2)

        # 整体结构标签
        structure_label = Text("实践结构", **font_conf, font_size=20, color=ORANGE)
        structure_label.next_to(arrow, DOWN, buff=0.5)

        # 动画展示第一部分
        self.play(
            FadeIn(subject, shift=RIGHT),
            FadeIn(object_, shift=LEFT),
            Create(arrow),
            run_time=1.5
        )
        self.play(Write(medium_group), FadeIn(structure_label), run_time=1)

        # --- 3. 对旧唯物主义的超越 (对比展示) ---

        # 分隔线
        separator = Line(LEFT*6, RIGHT*6, color=GRAY, stroke_opacity=0.5).shift(DOWN * 0.5)
        self.play(Create(separator), run_time=0.5)

        # 核心观点对比
        # 左侧：旧唯物主义
        old_mat_title = Text("旧唯物主义 (费尔巴哈)", **font_conf, font_size=24, color=GRAY_C)
        old_mat_point = Text("直观、消极、客体形式", **font_conf, font_size=20, color=GRAY_B)

        old_group = VGroup(old_mat_title, old_mat_point).arrange(DOWN, buff=0.2)
        old_group.move_to(LEFT * 3.5 + DOWN * 2)

        # 右侧：马克思主义
        new_mat_title = Text("马克思主义", **font_conf, font_size=24, color=BLUE_A)
        new_mat_point = Text("感性活动、实践、主体方面", **font_conf, font_size=20, color=WHITE)

        new_group = VGroup(new_mat_title, new_mat_point).arrange(DOWN, buff=0.2)
        new_group.move_to(RIGHT * 3.5 + DOWN * 2)

        # 强调框 (SurroundingRectangle)
        highlight_rect = SurroundingRectangle(new_group, color=YELLOW, buff=0.2)
        highlight_text = Text("核心地位：超越", **font_conf, font_size=18, color=YELLOW).next_to(highlight_rect, UP)

        # 动画展示第二部分
        self.play(
            FadeIn(old_group, shift=UP),
            run_time=1
        )

        # 这里的VS可以用简单的文字表示
        vs_text = Text("VS", font_size=30, color=RED, weight=BOLD).move_to(DOWN * 2)
        self.play(FadeIn(vs_text, scale=0.5), run_time=0.5)

        self.play(
            FadeIn(new_group, shift=UP),
            run_time=1
        )

        # 强调马克思主义的超越性
        self.play(
            Create(highlight_rect),
            Write(highlight_text),
            run_time=1.5
        )
