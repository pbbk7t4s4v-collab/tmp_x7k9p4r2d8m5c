from manim import *

class FluorideSaltChallenges(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("氟盐化学挑战与应对策略",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.6)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局规划 - 分左右两列
        # 左侧：材料腐蚀
        left_center = LEFT * 3.5
        right_center = RIGHT * 3.5

        # 左侧标题
        t_corr = Text("材料腐蚀挑战", font="AR PL UKai CN", font_size=28, color=YELLOW).move_to(left_center + UP * 2.0)

        # 左侧图片
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/33e2d3a7-4893-4729-8037-83d389d9cbdb/d9774409-0413-42bb-9dc1-595acb021654/pictures/1_7/1.png") # 这里期望是一张展示金属材料发生晶间腐蚀的微观示意图，画面主要描绘不规则的金属晶粒，其边界处出现裂纹和腐蚀痕迹，表现高温熔盐杂质（如碲）对材料结构的破坏，写实风
        img1.height = 2.2 # 设置高度，保持1:1比例
        img1.next_to(t_corr, DOWN, buff=0.2)

        # 左侧说明文字
        t_corr_desc = Text("碲(Te)等杂质导致晶间腐蚀", font="AR PL UKai CN", font_size=20, color=WHITE).next_to(img1, DOWN, buff=0.2)

        # 左侧解决方案
        t_corr_sol = VGroup(
            Text("应对策略：", font="AR PL UKai CN", font_size=20, color=GREEN),
            Text("控制氧化还原电位", font="AR PL UKai CN", font_size=20, color=WHITE),
            MathTex(r"U(IV)/U(III)", font_size=24, color=BLUE)
        ).arrange(DOWN, buff=0.1).next_to(t_corr_desc, DOWN, buff=0.3)

        box_corr = SurroundingRectangle(t_corr_sol, color=GREEN, buff=0.15)

        # 右侧标题
        t_trit = Text("氚控制挑战", font="AR PL UKai CN", font_size=28, color=YELLOW).move_to(right_center + UP * 2.0)

        # 右侧图片
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/33e2d3a7-4893-4729-8037-83d389d9cbdb/d9774409-0413-42bb-9dc1-595acb021654/pictures/1_7/2.png") # 这里期望是一张双壁管蒸汽发生器的局部截面结构示意图，画面清晰展示内外两层金属管壁，两层之间留有空隙用于覆盖气体吹扫，以形象地解释阻挡氚渗透的物理机制，工业工程示意图
        img2.height = 2.2
        img2.next_to(t_trit, DOWN, buff=0.2)

        # 右侧说明文字
        t_trit_desc = Text("高温下氚极易渗透金属", font="AR PL UKai CN", font_size=20, color=WHITE).next_to(img2, DOWN, buff=0.2)

        # 右侧解决方案
        t_trit_sol = VGroup(
            Text("应对策略：", font="AR PL UKai CN", font_size=20, color=GREEN),
            Text("双壁管蒸汽发生器", font="AR PL UKai CN", font_size=20, color=WHITE),
            Text("+ 气体吹扫", font="AR PL UKai CN", font_size=20, color=BLUE)
        ).arrange(DOWN, buff=0.1).next_to(t_trit_desc, DOWN, buff=0.3)

        box_trit = SurroundingRectangle(t_trit_sol, color=GREEN, buff=0.15)

        # 3. 动画流程
        # 左侧淡入
        self.play(FadeIn(t_corr, shift=DOWN), run_time=0.5)
        self.play(FadeIn(img1, scale=0.8), run_time=0.8)
        self.play(Write(t_corr_desc), run_time=0.8)
        self.play(
            Create(box_corr),
            FadeIn(t_corr_sol),
            run_time=1.0
        )

        # 右侧淡入
        try:
            t_trit
        except NameError:
            t_trit = Text("氚控制挑战", font="AR PL UKai CN", font_size=28, color=YELLOW).move_to(right_center + UP * 2.0)
        self.play(FadeIn(t_trit, shift=DOWN), run_time=0.5)
        self.play(FadeIn(img2, scale=0.8), run_time=0.8)
        self.play(Write(t_trit_desc), run_time=0.8)
        self.play(
            Create(box_trit),
            FadeIn(t_trit_sol),
            run_time=1.0
        )
