from manim import *

class EigenvalueProductDeterminant(Scene):
    def construct(self):

        # 1. 标题部分 (按照模板要求)
        title = Text("特征值性质：特征值之积与行列式",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("35", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 定理展示部分
        # 文本标签
        theorem_label = Text("定理：矩阵特征值之积等于其行列式",
                           font="AR PL UKai CN", font_size=28, color=YELLOW)

        # 核心公式
        theorem_math = MathTex(r"\prod_{i=1}^{n} \lambda_i = \det(A)", font_size=48)

        # 组合并定位
        theorem_group = VGroup(theorem_label, theorem_math).arrange(DOWN, buff=0.3)
        theorem_group.next_to(title_line, DOWN, buff=0.8)

        # 强调框
        box = SurroundingRectangle(theorem_group, color=BLUE, buff=0.3)

        # 动画：显示定理
        self.play(FadeIn(theorem_label, shift=UP), run_time=0.8)
        self.play(Write(theorem_math), Create(box), run_time=1.2)

        # 3. 简要推导过程可视化
        # 为了避免遮挡，将定理部分整体上移一点，或者推导在下方展开
        self.play(
            theorem_group.animate.scale(0.8).shift(UP * 0.5),
            box.animate.scale(0.8).shift(UP * 0.5),
            run_time=1.0
        )

        # 推导步骤
        step1_text = Text("1. 特征多项式定义：", font="AR PL UKai CN", font_size=24, color=LIGHT_GRAY)
        step1_math = MathTex(r"p(\lambda) = \det(A - \lambda I)", font_size=30)
        step1 = VGroup(step1_text, step1_math).arrange(RIGHT, buff=0.2)

        step2_text = Text("2. 令参数为0求常数项：", font="AR PL UKai CN", font_size=24, color=LIGHT_GRAY)
        step2_math = MathTex(r"p(0) = \det(A - 0 \cdot I) = \det(A)", font_size=30)
        step2 = VGroup(step2_text, step2_math).arrange(RIGHT, buff=0.2)

        step3_text = Text("3. 根据韦达定理(Vieta's formulas)：", font="AR PL UKai CN", font_size=24, color=LIGHT_GRAY)
        # 公式较长，单独一行
        step3_math = MathTex(
            r"\prod_{i=1}^{n} \lambda_i = (-1)^n \frac{p(0)}{\text{coeff}(\lambda^n)} = (-1)^n \frac{\det(A)}{(-1)^n} = \det(A)",
            font_size=32
        )
        # 高亮最后的结果
        step3_math.set_color_by_tex(r"\det(A)", YELLOW)

        # 整体布局推导部分
        derivation_group = VGroup(step1, step2, step3_text, step3_math).arrange(DOWN, buff=0.35, aligned_edge=LEFT)
        derivation_group.next_to(box, DOWN, buff=0.6)

        # 动画：逐步显示推导
        # 步骤1
        self.play(FadeIn(step1, shift=LEFT), run_time=0.8)

        # 步骤2：强调 p(0) = det(A)
        self.play(FadeIn(step2, shift=LEFT), run_time=0.8)

        # 步骤3
        self.play(FadeIn(step3_text, shift=LEFT), run_time=0.8)
        self.play(Write(step3_math), run_time=1.5)

        # 4. 总结强调
        # 使用一个箭头指向最终结果
        arrow = Arrow(start=step3_math.get_right() + RIGHT*0.5, end=step3_math.get_right(), color=RED)
        self.play(GrowArrow(arrow), run_time=0.5)
        self.play(Indicate(step3_math, color=YELLOW), run_time=1.0)
