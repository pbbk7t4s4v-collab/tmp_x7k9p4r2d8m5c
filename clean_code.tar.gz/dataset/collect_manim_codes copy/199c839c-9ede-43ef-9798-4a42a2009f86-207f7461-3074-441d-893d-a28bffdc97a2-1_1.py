from manim import *

class PhilosophyObjectChange(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("哲学对象的转变:从抽象的人到现实的人",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧:旧哲学(抽象的人)
        left_header = Text("旧唯物主义", font="AR PL UKai CN", font_size=28, color=BLUE_B)
        left_concept = Text("抽象的人", font="AR PL UKai CN", font_size=36, color=BLUE)

        # 可视化:孤立的点
        left_dot = Dot(color=BLUE, radius=0.15)
        # 虚线圆圈表示封闭、孤立
        left_circle = DashedVMobject(Circle(radius=0.6, color=BLUE_E))
        left_visual = VGroup(left_circle, left_dot)

        left_desc = Text("脱离历史与社会\n孤立存在的个体", font="AR PL UKai CN", font_size=20, color=GRAY)

        left_group = VGroup(left_header, left_concept, left_visual, left_desc)
        left_group.arrange(DOWN, buff=0.4)
        left_group.move_to(LEFT * 3.5 + DOWN * 0.5)

        # 3. 右侧:马克思主义(现实的人)
        right_header = Text("马克思主义", font="AR PL UKai CN", font_size=28, color=GREEN_B)
        right_concept = Text("现实的人", font="AR PL UKai CN", font_size=36, color=GREEN)

        # 可视化:社会关系网络
        center_dot = Dot(color=GREEN, radius=0.15)
        # 周围的点表示社会关系
        p1 = Dot(color=GREEN_A).move_to(center_dot.get_center() + UP*0.6 + RIGHT*0.5)
        p2 = Dot(color=GREEN_A).move_to(center_dot.get_center() + DOWN*0.6 + RIGHT*0.5)
        p3 = Dot(color=GREEN_A).move_to(center_dot.get_center() + LEFT*0.7)

        lines = VGroup(
            Line(center_dot.get_center(), p1.get_center(), color=GREEN_E, stroke_width=2),
            Line(center_dot.get_center(), p2.get_center(), color=GREEN_E, stroke_width=2),
            Line(center_dot.get_center(), p3.get_center(), color=GREEN_E, stroke_width=2)
        )
        right_visual = VGroup(lines, center_dot, p1, p2, p3)

        right_desc = Text("是一切社会\n关系的总和", font="AR PL UKai CN", font_size=20, color=GRAY)

        right_group = VGroup(right_header, right_concept, right_visual, right_desc)
        right_group.arrange(DOWN, buff=0.4)
        right_group.move_to(RIGHT * 3.5 + DOWN * 0.5)

        # 4. 中间转换箭头
        arrow = Arrow(left_group.get_right(), right_group.get_left(), buff=0.5, color=YELLOW)
        trans_text = Text("革命性变革", font="AR PL UKai CN", font_size=24, color=YELLOW)
        trans_text.next_to(arrow, UP, buff=0.1)

        # 5. 动画播放序列
        # 显示左侧
        self.play(FadeIn(left_group, shift=RIGHT), run_time=1.5)

        # 显示中间转换
        self.play(
            GrowArrow(arrow),
            Write(trans_text),
            run_time=1.0
        )

        # 显示右侧
        self.play(FadeIn(right_group, shift=LEFT), run_time=1.5)

        # 强调右侧核心概念
        rect = SurroundingRectangle(right_group, color=YELLOW, buff=0.2)
        self.play(Create(rect), run_time=0.8)
