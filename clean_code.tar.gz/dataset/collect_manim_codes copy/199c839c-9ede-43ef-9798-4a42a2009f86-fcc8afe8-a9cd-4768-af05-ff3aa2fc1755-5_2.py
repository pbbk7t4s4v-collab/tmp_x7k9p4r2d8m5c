from manim import *

class LimitIntuition(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("极限的直观描述",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题组合
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("14", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 文本讲解内容（左侧布局）
        # 定义文本
        text_def = Text("当变量无限靠近特定数值时，\n函数值趋向于一个确定常数。",
                       font_size=24,
                       font="AR PL UKai CN",
                       line_spacing=1.2)

        # 重点强调
        text_key = Text("重点：无限接近 ≠ 等于",
                       font_size=26,
                       font="AR PL UKai CN",
                       color=YELLOW)

        # 组合文本并排版
        text_group = VGroup(text_def, text_key).arrange(DOWN, buff=0.5, aligned_edge=LEFT)
        text_group.to_edge(LEFT, buff=1.0).shift(UP*0.5)

        # 强调框
        rect = SurroundingRectangle(text_key, color=BLUE, buff=0.15)

        # 展示文本
        self.play(FadeIn(text_def))
        self.play(Write(text_key))
        self.play(Create(rect))

        # 3. 几何可视化（右侧布局）
        # 建立坐标系
        ax = Axes(
            x_range=[0, 5, 1],
            y_range=[0, 4, 1],
            x_length=5,
            y_length=3.5,
            axis_config={"include_tip": True, "color": GREY},
        ).to_edge(RIGHT, buff=1.0).shift(DOWN*0.5)

        # 绘制函数曲线 f(x)
        # 使用简单的平滑曲线
        graph = ax.plot(lambda x: 0.5 * (x - 1)**2 + 1, x_range=[0.5, 4.5], color=BLUE_C)
        graph_label = MathTex("f(x)", color=BLUE_C, font_size=24).next_to(graph, UP)

        self.play(Create(ax), Create(graph))
        self.play(FadeIn(graph_label))

        # 4. 动态演示过程
        # 设定目标点 a 和 L
        target_x = 3.0
        target_y = 0.5 * (target_x - 1)**2 + 1  # f(3) = 3

        # 移动的 x 值，从左侧趋近
        x_tracker = ValueTracker(0.5)

        # 动态点
        moving_dot = always_redraw(lambda: Dot(
            point=ax.c2p(x_tracker.get_value(), 0.5 * (x_tracker.get_value() - 1)**2 + 1),
            color=RED
        ))

        # 动态辅助线
        lines = always_redraw(lambda: VGroup(*[
            DashedVMobject(l, dashed_ratio=0.5).set_color(YELLOW)
            for l in ax.get_lines_to_point(
                ax.c2p(x_tracker.get_value(), 0.5 * (x_tracker.get_value() - 1)**2 + 1)
            )
            if l.get_num_points() > 0
        ]))

        self.add(moving_dot, lines)

        # 动画：x 趋近于 a
        self.play(x_tracker.animate.set_value(target_x - 0.05), run_time=2.5, rate_func=smooth)

        # 5. 标注最终结果
        # 标注 a 和 L
        label_a = MathTex("a", color=YELLOW, font_size=28).next_to(ax.c2p(target_x, 0), DOWN)
        label_L = MathTex("L", color=YELLOW, font_size=28).next_to(ax.c2p(0, target_y), LEFT)

        self.play(FadeIn(label_a), FadeIn(label_L))

        # 6. 展示数学公式
        formula = MathTex(r"\lim_{x \to a} f(x) = L", font_size=36, color=ORANGE)
        formula.next_to(text_group, DOWN, buff=1.0)

        self.play(Write(formula))
