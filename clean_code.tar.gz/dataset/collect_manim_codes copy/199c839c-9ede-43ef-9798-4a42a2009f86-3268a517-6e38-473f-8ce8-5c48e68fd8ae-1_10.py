from manim import *

class MaterialistDialectics(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (按照模板要求)
        # ---------------------------------------------------------
        title = Text("唯物辩证法的基本内涵",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心定义 (顶部居中)
        # ---------------------------------------------------------
        # 概念：世界观与方法论的统一
        def_text = Text("马克思主义哲学核心方法论：世界观与方法论的统一",
                        font_size=26, font="AR PL UKai CN", color=BLUE_A)
        def_text.next_to(title_line, DOWN, buff=0.6)

        self.play(FadeIn(def_text, shift=DOWN))

        # ---------------------------------------------------------
        # 3. 对比展示：形而上学 vs 唯物辩证法 (中间部分)
        # ---------------------------------------------------------

        # 左侧：形而上学 (旧思维)
        meta_title = Text("形而上学", font_size=28, font="AR PL UKai CN", color=GRAY_B)
        meta_content = Text("静止  孤立  片面", font_size=22, font="AR PL UKai CN", color=GRAY_C)
        meta_group = VGroup(meta_title, meta_content).arrange(DOWN, buff=0.2)

        meta_box = SurroundingRectangle(meta_group, color=GRAY, buff=0.2)
        meta_full = VGroup(meta_box, meta_group)

        # 右侧：唯物辩证法 (新思维)
        dia_title = Text("唯物辩证法", font_size=28, font="AR PL UKai CN", color=YELLOW)
        dia_content = Text("联系  发展  矛盾", font_size=22, font="AR PL UKai CN", color=YELLOW_A)
        dia_group = VGroup(dia_title, dia_content).arrange(DOWN, buff=0.2)

        dia_box = SurroundingRectangle(dia_group, color=YELLOW, buff=0.2)
        dia_full = VGroup(dia_box, dia_group)

        # 布局：左右排列
        comparison = VGroup(meta_full, dia_full).arrange(RIGHT, buff=2.0)
        comparison.next_to(def_text, DOWN, buff=0.8)

        # 中间添加一个对比箭头或VS
        vs_text = Text("VS", font_size=24, font="AR PL UKai CN", color=RED)
        vs_text.move_to(comparison.get_center())

        # 动画展示对比
        self.play(Create(meta_full))
        self.play(Write(vs_text))
        self.play(Create(dia_full))

        # ---------------------------------------------------------
        # 4. 理论来源与继承 (底部)
        # ---------------------------------------------------------
        # 逻辑：黑格尔(合理内核) + 唯物主义 = 科学变革

        source_text1 = Text("黑格尔辩证法", font_size=22, font="AR PL UKai CN", color=WHITE)
        sub_text1 = Text("(合理内核)", font_size=18, font="AR PL UKai CN", color=GREEN).next_to(source_text1, DOWN, buff=0.1)
        group1 = VGroup(source_text1, sub_text1)

        plus = MathTex("+", color=WHITE).scale(1.2)

        source_text2 = Text("唯物主义基础", font_size=22, font="AR PL UKai CN", color=BLUE)

        arrow = MathTex(r"\Rightarrow", color=WHITE).scale(1.2)

        result_text = Text("科学的世界观", font_size=22, font="AR PL UKai CN", color=YELLOW)
        sub_text2 = Text("(剔除唯心主义外壳)", font_size=18, font="AR PL UKai CN", color=GRAY).next_to(result_text, DOWN, buff=0.1)
        group_result = VGroup(result_text, sub_text2)

        # 组合公式行
        formula_group = VGroup(group1, plus, source_text2, arrow, group_result).arrange(RIGHT, buff=0.3)
        formula_group.next_to(comparison, DOWN, buff=0.8)

        # 动画展示来源
        self.play(FadeIn(formula_group, shift=UP))

        # 简单强调最终结果
        self.play(Indicate(group_result, color=YELLOW))
