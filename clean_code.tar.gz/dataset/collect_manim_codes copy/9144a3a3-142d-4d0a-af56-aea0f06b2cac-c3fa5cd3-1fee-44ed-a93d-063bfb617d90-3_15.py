from manim import *

class UniFinderIntro(Scene):
    def construct(self):

        # 1. 标题部分 (严格遵守模板)
        title = Text("Uni-Finder 信息检索系统",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("28", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心系统展示 (中间)
        system_text = Text("Uni-Finder", font="AR PL UKai CN", font_size=36, color=BLUE)
        system_box = SurroundingRectangle(system_text, color=BLUE, buff=0.3, corner_radius=0.2)
        system_group = VGroup(system_text, system_box).move_to(UP * 0.5)

        self.play(FadeIn(system_group, shift=UP))

        # 3. 输入端：多源信息 (左侧)
        input_label = Text("多源输入", font="AR PL UKai CN", font_size=24, color=GRAY_B)
        input_items = VGroup(
            Text("文献数据", font="AR PL UKai CN", font_size=20),
            Text("专利信息", font="AR PL UKai CN", font_size=20)
        ).arrange(DOWN, buff=0.2)

        input_group = VGroup(input_label, input_items).arrange(DOWN, buff=0.3)
        input_group.next_to(system_group, LEFT, buff=1.5)

        # 连接箭头
        arrow_in = Arrow(start=input_group.get_right(), end=system_box.get_left(), color=GRAY, buff=0.1)

        self.play(
            FadeIn(input_group, shift=RIGHT),
            GrowArrow(arrow_in)
        )

        # 4. 功能端：自动化能力 (右侧)
        # 使用自定义项目符号展示功能(避免 LaTeX)
        feature_items = [
            "自动筛选与聚合",
            "自动报告生成",
            "可视化与智能提醒",
        ]
        features_rows = VGroup(
            *[
                VGroup(
                    Dot(radius=0.06, color=YELLOW),
                    Text(item, font="AR PL UKai CN", font_size=22),
                ).arrange(RIGHT, buff=0.2)
                for item in feature_items
            ]
        ).arrange(DOWN, buff=0.3)
        features = features_rows
        features.next_to(system_group, RIGHT, buff=1.0)

        # 连接箭头
        arrow_out = Arrow(start=system_box.get_right(), end=features.get_left(), color=YELLOW, buff=0.1)

        self.play(
            GrowArrow(arrow_out),
            Write(features, run_time=2)
        )

        # 5. 目标价值：底部强调 (底部)
        # 调研成本下降
        cost_text = Text("调研成本", font="AR PL UKai CN", font_size=28, color=RED)
        cost_icon = Text("↓", font="AR PL UKai CN", font_size=36, color=RED).next_to(cost_text, RIGHT, buff=0.1)
        cost_group = VGroup(cost_text, cost_icon)

        # 创新思考提升
        inn_text = Text("关键创新", font="AR PL UKai CN", font_size=28, color=GREEN)
        inn_icon = Text("↑", font="AR PL UKai CN", font_size=36, color=GREEN).next_to(inn_text, RIGHT, buff=0.1)
        inn_group = VGroup(inn_text, inn_icon)

        # 组合底部元素
        bottom_group = VGroup(cost_group, inn_group).arrange(RIGHT, buff=3)
        bottom_group.to_edge(DOWN, buff=1.0)

        # 装饰框
        value_box = SurroundingRectangle(bottom_group, color=WHITE, buff=0.2, stroke_width=1, stroke_opacity=0.5)

        self.play(
            Create(value_box),
            FadeIn(cost_group, shift=UP),
            FadeIn(inn_group, shift=UP)
        )
