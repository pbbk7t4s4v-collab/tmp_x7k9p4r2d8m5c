from manim import *

class HCIMultimediaApps(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格遵守模板要求)
        # ---------------------------------------------------------
        title = Text("人机交互中的多媒体应用",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("20", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局规划 (左右两栏)
        # ---------------------------------------------------------

        # 左侧:基于文本处理
        # -----------------
        text_title = Text("1. 基于文本处理交互", font="AR PL UKai CN", font_size=28, color=BLUE_A)

        # 几何图标:模拟对话框/文档
        doc_box = Rectangle(width=1.2, height=1.5, color=BLUE, fill_opacity=0.1)
        line1 = Line(start=doc_box.get_left() + RIGHT*0.2 + UP*0.4, end=doc_box.get_right() + LEFT*0.2 + UP*0.4, color=BLUE_C)
        line2 = Line(start=doc_box.get_left() + RIGHT*0.2, end=doc_box.get_right() + LEFT*0.2, color=BLUE_C)
        line3 = Line(start=doc_box.get_left() + RIGHT*0.2 + DOWN*0.4, end=doc_box.get_right() + LEFT*0.4 + DOWN*0.4, color=BLUE_C)
        text_icon = VGroup(doc_box, line1, line2, line3)

        # 文本列表 (手动创建以避免LaTeX中文问题)
        t_item1 = Text("• 智能问答系统 (Chatbot)", font="AR PL UKai CN", font_size=22)
        t_item2 = Text("• 机器翻译与摘要生成", font="AR PL UKai CN", font_size=22)
        t_item3 = Text("• 情感分析与舆情监控", font="AR PL UKai CN", font_size=22)

        text_list = VGroup(t_item1, t_item2, t_item3).arrange(DOWN, aligned_edge=LEFT, buff=0.3)

        # 组合左侧内容
        left_group = VGroup(text_title, text_icon, text_list).arrange(DOWN, buff=0.5)

        # 右侧:基于图像处理
        # -----------------
        img_title = Text("2. 基于图像处理交互", font="AR PL UKai CN", font_size=28, color=GREEN_A)

        # 几何图标:模拟人脸识别扫描
        face_box = Square(side_length=1.5, color=GREEN, fill_opacity=0.1)
        face_circle = Circle(radius=0.5, color=WHITE).move_to(face_box)
        scan_line = Line(start=face_box.get_left(), end=face_box.get_right(), color=RED)
        img_icon = VGroup(face_box, face_circle, scan_line)

        # 图像列表
        i_item1 = Text("• 人脸识别与身份验证", font="AR PL UKai CN", font_size=22)
        i_item2 = Text("• OCR文字提取与识别", font="AR PL UKai CN", font_size=22)
        i_item3 = Text("• 手势控制与医学影像", font="AR PL UKai CN", font_size=22)

        img_list = VGroup(i_item1, i_item2, i_item3).arrange(DOWN, aligned_edge=LEFT, buff=0.3)

        # 组合右侧内容
        right_group = VGroup(img_title, img_icon, img_list).arrange(DOWN, buff=0.5)

        # ---------------------------------------------------------
        # 3. 整体位置调整
        # ---------------------------------------------------------
        # 将左右两组并排,位于标题下方
        content_group = VGroup(left_group, right_group).arrange(RIGHT, buff=1.5)
        content_group.next_to(title_line, DOWN, buff=0.8)

        # ---------------------------------------------------------
        # 4. 动画展示
        # ---------------------------------------------------------

        # 左侧入场
        self.play(FadeIn(text_title, shift=DOWN))
        self.play(Create(doc_box), Create(line1), Create(line2), Create(line3))
        self.play(Write(text_list), run_time=2)

        # 强调左侧
        rect_left = SurroundingRectangle(left_group, color=BLUE, buff=0.2)
        self.play(Create(rect_left))

        # 右侧入场
        self.play(FadeIn(img_title, shift=DOWN))
        self.play(Create(face_box), Create(face_circle))
        # 扫描线动画
        self.play(scan_line.animate.shift(DOWN * 0.6), rate_func=there_and_back, run_time=1)
        self.play(FadeOut(scan_line)) # 扫描结束隐藏线

        self.play(Write(img_list), run_time=2)

        # 强调右侧
        rect_right = SurroundingRectangle(right_group, color=GREEN, buff=0.2)
        self.play(Create(rect_right))

        # 最后的停顿
