from manim import *

class PhysicsScales(Scene):
    def construct(self):

        # 1. 标题部分 (严格按照模板)
        title = Text("不同距离尺度与物理模型的对应关系",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("54", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计 - 三栏布局

        # --- 微观尺度 (左) ---
        q_title = Text("微观尺度：量子力学", font="AR PL UKai CN", font_size=24, color=BLUE_B)

        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/2d420861-da71-474e-b5d0-92a9e702d1ee/b28e272c-affb-4a4e-8370-e037b9e3294b/pictures/888_55/1.png") # 这里期望是一张极具科技感的微观原子结构示意图，中心是发光的原子核，周围环绕着模糊的电子云或轨道，背景深色，表现量子力学的微观尺度，写实风
        img1.height = 2.0  # 统一高度，保持1:1比例

        q_eq = MathTex(r"i\hbar \frac{\partial}{\partial t}\Psi = \hat{H}\Psi", font_size=24, color=BLUE_A)
        q_desc = Text("尺度 < 10^{-9}米\n波粒二象性", font="AR PL UKai CN", font_size=20, line_spacing=1.2).set_color(GRAY_B)

        group_q = Group(q_title, img1, q_eq, q_desc).arrange(DOWN, buff=0.3)
        rect_q = SurroundingRectangle(group_q, color=BLUE, buff=0.2, corner_radius=0.2)

        # --- 宏观尺度 (中) ---
        c_title = Text("宏观尺度：经典力学", font="AR PL UKai CN", font_size=24, color=GREEN_B)

        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/2d420861-da71-474e-b5d0-92a9e702d1ee/b28e272c-affb-4a4e-8370-e037b9e3294b/pictures/888_55/2.png") # 这里期望是一张写实风格的城市生活照片，画面中有一辆正在行驶的汽车和现代化的建筑，阳光明媚，代表宏观常速尺度的经典力学世界，写实风
        img2.height = 2.0

        c_eq = MathTex(r"\mathbf{F} = m\mathbf{a}", font_size=24, color=GREEN_A)
        c_desc = Text("日常尺度 (毫米-千米)\n确定性轨迹", font="AR PL UKai CN", font_size=20, line_spacing=1.2).set_color(GRAY_B)

        group_c = Group(c_title, img2, c_eq, c_desc).arrange(DOWN, buff=0.3)
        rect_c = SurroundingRectangle(group_c, color=GREEN, buff=0.2, corner_radius=0.2)

        # --- 宇观尺度 (右) ---
        r_title = Text("宇观尺度：广义相对论", font="AR PL UKai CN", font_size=24, color=RED_B)

        img3 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/2d420861-da71-474e-b5d0-92a9e702d1ee/b28e272c-affb-4a4e-8370-e037b9e3294b/pictures/888_55/3.png") # 这里期望是一张壮观的宇宙星系图片，画面是一个巨大的旋涡星系或者黑洞扭曲周围光线的景象，深邃浩瀚，代表宇观与强引力尺度的广义相对论，写实风
        img3.height = 2.0

        # 简化版场方程以适应屏幕
        r_eq = MathTex(r"G_{\mu\nu} + \Lambda g_{\mu\nu} \propto T_{\mu\nu}", font_size=24, color=RED_A)
        r_desc = Text("尺度 > 10^{7}米\n时空弯曲", font="AR PL UKai CN", font_size=20, line_spacing=1.2).set_color(GRAY_B)

        group_r = Group(r_title, img3, r_eq, r_desc).arrange(DOWN, buff=0.3)
        rect_r = SurroundingRectangle(group_r, color=RED, buff=0.2, corner_radius=0.2)

        # 3. 整体布局与动画
        main_content = Group(
            Group(rect_q, group_q),
            Group(rect_c, group_c),
            Group(rect_r, group_r)
        ).arrange(RIGHT, buff=0.5).next_to(title_line, DOWN, buff=0.5)

        # 动画展示
        # 依次展示三个板块
        self.play(
            FadeIn(main_content[0], shift=UP),
            run_time=1.2
        )
        self.play(
            FadeIn(main_content[1], shift=UP),
            run_time=1.2
        )
        self.play(
            FadeIn(main_content[2], shift=UP),
            run_time=1.2
        )

        # 强调中间的经典力学是我们最熟悉的
        self.play(
            rect_c.animate.set_stroke(width=6),
            Flash(group_c, color=YELLOW, line_length=0.2),
            run_time=1.0
        )
