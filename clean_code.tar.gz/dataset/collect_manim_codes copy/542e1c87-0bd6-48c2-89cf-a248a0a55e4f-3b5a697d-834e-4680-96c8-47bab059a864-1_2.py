from manim import *

class FormulaStructureAndOrder(Scene):
    def construct(self):

        # 标题设置
        title = Text("观察算式结构与运算顺序",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 1. 展示混合运算算式
        # 算式:7 + 3 x 4
        equation = Text("7 + 3 × 4", font_size=72)
        equation.move_to(UP * 0.5)

        self.play(Write(equation))

        # 2. 视觉化"整体"概念
        # 提取乘法部分 (3 x 4)
        # 索引对应: 0->7, 1->+, 2->3, 3->×, 4->4
        mult_group = VGroup(*equation[2:])

        # 使用矩形框选乘法部分,强调其为一个整体
        highlight_box = SurroundingRectangle(mult_group, color=YELLOW, buff=0.15)
        highlight_text = Text("优先计算", font="AR PL UKai CN", font_size=24, color=YELLOW)
        highlight_text.next_to(highlight_box, UP, buff=0.1)

        self.play(
            Create(highlight_box),
            FadeIn(highlight_text),
            mult_group.animate.set_color(YELLOW)
        )

        # 3. 展示计算过程流程
        # 第一步结果: 7 + 12
        step_one = Text("7 + 12", font_size=72)
        step_one.next_to(equation, DOWN, buff=1.2)

        # 对应颜色的变化:12 变成黄色,表示是由上面的黄色部分计算得来的
        step_one_12_group = VGroup(step_one[2], step_one[3])
        step_one_12_group.set_color(YELLOW)

        # 绘制箭头表示转换逻辑
        arrow_left = Arrow(start=equation[0].get_bottom(), end=step_one[0].get_top(), color=WHITE, buff=0.1)
        arrow_right = Arrow(start=highlight_box.get_bottom(), end=step_one_12_group.get_top(), color=YELLOW, buff=0.1)

        self.play(
            GrowArrow(arrow_left),
            GrowArrow(arrow_right),
            TransformFromCopy(equation[0:2], step_one[0:2]), # 7 +
            TransformFromCopy(mult_group, step_one_12_group)       # 12
        )

        # 4. 最终结果
        # = 19
        final_result = Text("= 19", font_size=72)
        final_result.next_to(step_one, RIGHT, buff=0.3)

        self.play(Write(final_result))

        # 5. 总结规则
        rule_text = Text("规则:先乘除,后加减", font="AR PL UKai CN", font_size=32, color=BLUE_A)
        rule_text.next_to(step_one, DOWN, buff=0.8)
        # 居中调整
        rule_text.shift(RIGHT * 0.5)

        self.play(FadeIn(rule_text, shift=UP))
