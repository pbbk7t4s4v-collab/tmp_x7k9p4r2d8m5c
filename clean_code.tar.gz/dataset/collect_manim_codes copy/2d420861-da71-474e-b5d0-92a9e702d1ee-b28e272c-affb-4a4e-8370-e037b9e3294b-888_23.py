from manim import *

class SandwichStackingScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (标准模板)
        # ---------------------------------------------------------
        title = Text("面对面（Sandwich）堆积：E ∝ r⁻⁶",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("23", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 图像展示 (左侧)
        # ---------------------------------------------------------
        img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/2d420861-da71-474e-b5d0-92a9e702d1ee/b28e272c-affb-4a4e-8370-e037b9e3294b/pictures/888_23/1.png") # 这里期望是一张展示两个苯环呈现面对面（Sandwich）堆积方式的3D科学可视化渲染图。画面中两个六边形苯环平面相互平行，上下对齐，中心轴重合。苯环平面上方和下方显示出半透明的环状或云状区域，代表π电子云，直观体现电子云的重叠与排斥。整体风格为精细的化学结构示意图，背景纯白或浅灰，突出分子立体结构，写实风

        # 设置图片大小和位置，保持1:1比例视觉效果
        img.scale_to_fit_height(4.5)
        img.to_edge(LEFT, buff=1.5).shift(DOWN * 0.3)

        # ---------------------------------------------------------
        # 3. 文本与公式内容 (右侧)
        # ---------------------------------------------------------

        # 几何构型描述
        geo_header = Text("几何构型：", font_size=28, font="AR PL UKai CN", color=BLUE_B)
        geo_text = VGroup(
            Text("• 芳香环平面相互平行", font_size=24, font="AR PL UKai CN"),
            Text("• 中心轴完全重合", font_size=24, font="AR PL UKai CN")
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        geo_block = VGroup(geo_header, geo_text).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # 物理机制描述
        phy_header = Text("相互作用机制：", font_size=28, font="AR PL UKai CN", color=BLUE_B)
        phy_text = VGroup(
            Text("• π-π 电子云静电排斥", font_size=24, font="AR PL UKai CN", color=RED_C),
            Text("• 伦敦色散力 (主导吸引)", font_size=24, font="AR PL UKai CN", color=GREEN_C)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        phy_block = VGroup(phy_header, phy_text).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        # 核心公式
        formula = MathTex(r"E_{\text{disp}}", r"\propto", r"r^{-6}")
        formula.set_color_by_tex(r"r^{-6}", YELLOW)
        formula.scale(1.2)

        formula_desc = Text("色散势能与距离六次方成反比", font_size=22, font="AR PL UKai CN", color=YELLOW)
        formula_block = VGroup(formula, formula_desc).arrange(DOWN, buff=0.2)

        # 组合右侧所有内容
        right_content = VGroup(geo_block, phy_block, formula_block).arrange(DOWN, aligned_edge=LEFT, buff=0.6)
        right_content.next_to(img, RIGHT, buff=1.0)

        # ---------------------------------------------------------
        # 4. 动画流程
        # ---------------------------------------------------------

        # 图片淡入
        self.play(FadeIn(img, shift=RIGHT), run_time=1.0)

        # 几何构型文字出现
        self.play(
            FadeIn(geo_block, shift=LEFT),
            run_time=0.8
        )

        # 物理机制文字出现
        self.play(
            FadeIn(phy_block, shift=LEFT),
            run_time=0.8
        )

        # 公式强调展示
        self.play(Write(formula_block), run_time=1.0)

        # 强调框选公式中的 r^-6
        rect = SurroundingRectangle(formula[2], color=PURE_RED, buff=0.1)
        self.play(Create(rect), run_time=0.5)
