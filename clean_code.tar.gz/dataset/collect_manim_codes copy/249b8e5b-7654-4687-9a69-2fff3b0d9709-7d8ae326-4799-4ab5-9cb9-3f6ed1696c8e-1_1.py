from manim import *

class PythonPackageIntro(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("Python中的包:概念与定义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 定义左侧:模块 (Module) 的可视化
        # 创建文件图标
        file_rect = Rectangle(height=2.0, width=1.5, fill_color=BLUE_E, fill_opacity=0.7, color=BLUE)
        file_corner = Triangle(fill_color=BLACK, fill_opacity=1, color=BLUE).scale(0.15)
        file_corner.rotate(-90 * DEGREES)
        file_corner.align_to(file_rect, UP).align_to(file_rect, RIGHT)

        file_text = Text(".py", font_size=28, color=WHITE, font="AR PL UKai CN").move_to(file_rect.get_center())
        module_icon = VGroup(file_rect, file_text)

        module_label = Text("模块 (Module)", font="AR PL UKai CN", font_size=28, color=YELLOW).next_to(module_icon, UP, buff=0.3)
        module_desc = Text("单个源代码文件", font="AR PL UKai CN", font_size=24, color=GREY_B).next_to(module_icon, DOWN, buff=0.3)

        module_group = VGroup(module_label, module_icon, module_desc)
        module_group.move_to(LEFT * 3.5)

        # 3. 定义右侧:包 (Package) 的可视化
        # 创建文件夹图标
        folder_body = Rectangle(height=2.5, width=3.5, fill_color=GOLD_E, fill_opacity=0.6, color=GOLD)
        folder_tab = Rectangle(height=0.5, width=1.2, fill_color=GOLD_E, fill_opacity=0.6, color=GOLD)
        folder_tab.align_to(folder_body, UP).align_to(folder_body, LEFT).shift(UP * 0.4)

        # 在文件夹内放置几个小文件图标
        inner_file1 = file_rect.copy().scale(0.4).move_to(folder_body.get_center() + LEFT * 0.8 + DOWN * 0.2)
        inner_file2 = file_rect.copy().scale(0.4).move_to(folder_body.get_center() + DOWN * 0.2)
        inner_file3 = file_rect.copy().scale(0.4).move_to(folder_body.get_center() + RIGHT * 0.8 + DOWN * 0.2)

        package_icon = VGroup(folder_tab, folder_body, inner_file1, inner_file2, inner_file3)

        package_label = Text("包 (Package)", font="AR PL UKai CN", font_size=28, color=YELLOW).next_to(package_icon, UP, buff=0.3)
        package_desc = Text("包含多个模块的文件夹", font="AR PL UKai CN", font_size=24, color=GREY_B).next_to(package_icon, DOWN, buff=0.3)

        package_group = VGroup(package_label, package_icon, package_desc)
        package_group.move_to(RIGHT * 3.5)

        # 4. 动画展示核心概念
        # 先展示模块
        self.play(FadeIn(module_group, shift=UP), run_time=1)

        # 展示箭头过渡到包
        arrow = Arrow(start=module_group.get_right(), end=package_group.get_left(), buff=0.5, color=WHITE)
        organize_text = Text("组织与管理", font="AR PL UKai CN", font_size=20, color=WHITE).next_to(arrow, UP, buff=0.1)

        self.play(GrowArrow(arrow), Write(organize_text))

        # 展示包
        self.play(FadeIn(package_group, shift=UP), run_time=1)

        # 5. 底部总结:包的作用
        # 使用圆角框展示特性
        features_text = Text("作用:归类存放  |  便于维护  |  复用分享",
                           font="AR PL UKai CN",
                           font_size=30,
                           color=GREEN_B)

        features_box = SurroundingRectangle(features_text, color=GREEN, buff=0.2, corner_radius=0.2)
        features_group = VGroup(features_box, features_text)
        features_group.to_edge(DOWN, buff=1.0)

        self.play(Create(features_box), Write(features_text))
