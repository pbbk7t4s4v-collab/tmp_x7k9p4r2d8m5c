from manim import *

class AbstractAlgebraSystematization(Scene):
    def construct(self):

        # 1. 标题配置（严格按照模板）
        title = Text("抽象代数体系化与现代发展",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 历史演变部分 (上半部分)
        # 使用 VGroup 布局欧拉和狄德金的贡献

        # 欧拉部分
        euler_name = Text("欧拉", font="AR PL UKai CN", font_size=28, color=BLUE)
        euler_desc = Text("整数与函数\n发展代数思想", font="AR PL UKai CN", font_size=22, color=BLUE_A)
        euler_group = VGroup(euler_name, euler_desc).arrange(DOWN, buff=0.2)

        # 狄德金部分
        dedekind_name = Text("狄德金", font="AR PL UKai CN", font_size=28, color=TEAL)
        dedekind_desc = Text("提出"理想"\n代数结构概念", font="AR PL UKai CN", font_size=22, color=TEAL_A)
        dedekind_group = VGroup(dedekind_name, dedekind_desc).arrange(DOWN, buff=0.2)

        # 定位
        euler_group.move_to(UP * 1 + LEFT * 3.5)
        dedekind_group.move_to(UP * 1 + RIGHT * 3.5)

        # 连接箭头与中间过程
        arrow = Arrow(start=euler_group.get_right(), end=dedekind_group.get_left(), color=GREY, buff=0.5)
        trend_text = Text("严密化、抽象化", font="AR PL UKai CN", font_size=24, color=YELLOW).next_to(arrow, UP, buff=0.1)

        # 动画展示历史演变
        self.play(
            FadeIn(euler_group, shift=RIGHT),
            FadeIn(dedekind_group, shift=LEFT),
            run_time=1
        )
        self.play(
            GrowArrow(arrow),
            Write(trend_text),
            run_time=1
        )

        # 3. 现代常数问题 (下半部分)
        # 创建包含常数 e 和 pi 的展示区

        modern_label = Text("近现代关注：常数代数性质", font="AR PL UKai CN", font_size=26, color=WHITE)

        # 数学公式展示 e 和 pi
        constants_math = MathTex(r"e", r",\;", r"\pi", font_size=48, color=RED_B)

        # 标注性质
        prop_text = Text("（超越性）", font="AR PL UKai CN", font_size=26, color=RED)

        # 组合下方元素
        bottom_content = VGroup(constants_math, prop_text).arrange(RIGHT, buff=0.3)
        full_bottom_group = VGroup(modern_label, bottom_content).arrange(DOWN, buff=0.4)
        full_bottom_group.move_to(DOWN * 1.5)

        # 添加强调框
        box = SurroundingRectangle(full_bottom_group, color=WHITE, buff=0.3, stroke_width=2)

        # 动画展示常数部分
        self.play(
            Create(box),
            FadeIn(full_bottom_group, shift=UP),
            run_time=1.5
        )

        # 4. 停顿
