from manim import *

class LongRangeInteractions(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("长程相互作用的距离依赖关系",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心公式展示
        # 势能 V(r) 正比于 r^-n
        formula_text = MathTex(r"V(r) \propto \frac{1}{r^n}", font_size=48, color=YELLOW)
        formula_desc = Text("n 决定作用范围 (Range)", font="AR PL UKai CN", font_size=24, color=GREY_A)

        header_group = VGroup(formula_text, formula_desc).arrange(RIGHT, buff=0.5)
        header_group.next_to(title_group, DOWN, buff=0.5)

        self.play(FadeIn(header_group, shift=UP))

        # 3. 构建分类展示表格 (使用 VGroup 手动排版以避免 Table 类的兼容性问题)
        # 定义列内容生成函数
        def create_column(name, interaction_type, power, color, note):
            name_txt = Text(name, font="AR PL UKai CN", font_size=24, color=WHITE)
            type_txt = Text(interaction_type, font="AR PL UKai CN", font_size=20, color=GREY_B)
            math_tex = MathTex(power, font_size=36, color=color)
            note_txt = Text(note, font="AR PL UKai CN", font_size=18, color=color)

            # 垂直排列
            col = VGroup(name_txt, type_txt, math_tex, note_txt).arrange(DOWN, buff=0.3)
            return col

        # 创建四列数据
        # 1. 离子-离子 (n=1)
        col1 = create_column("离子-离子", "单极-单极", r"\propto r^{-1}", RED, "最长程")
        # 2. 离子-偶极 (n=2)
        col2 = create_column("离子-偶极", "单极-偶极", r"\propto r^{-2}", ORANGE, "取向相关")
        # 3. 偶极-偶极 (n=3)
        col3 = create_column("偶极-偶极", "偶极-偶极", r"\propto r^{-3}", GOLD, "Keesom")
        # 4. 色散力 (n=6)
        col4 = create_column("色散力", "诱导偶极对", r"\propto r^{-6}", BLUE, "所有分子")

        # 组合所有列并水平排列
        table_group = VGroup(col1, col2, col3, col4).arrange(RIGHT, buff=1.0)
        table_group.next_to(header_group, DOWN, buff=0.8)

        # 动画展示列
        self.play(LaggedStart(
            *[FadeIn(col, shift=UP) for col in table_group],
            lag_ratio=0.3,
            run_time=2.0
        ))

        # 4. 底部总结箭头和说明
        # 箭头指示衰减速度
        arrow = Arrow(start=table_group.get_left() + DOWN * 1.5,
                      end=table_group.get_right() + DOWN * 1.5,
                      color=WHITE, buff=0)
        arrow.next_to(table_group, DOWN, buff=0.4)

        summary_text = Text("随着 n 增大，相互作用随距离衰减显著加快",
                           font="AR PL UKai CN", font_size=24, color=TEAL)
        summary_text.next_to(arrow, DOWN, buff=0.2)

        # 框选强调 n=6 的情况 (色散力)
        rect = SurroundingRectangle(col4, color=BLUE, buff=0.15)

        self.play(GrowArrow(arrow), Write(summary_text))
        self.play(Create(rect))
