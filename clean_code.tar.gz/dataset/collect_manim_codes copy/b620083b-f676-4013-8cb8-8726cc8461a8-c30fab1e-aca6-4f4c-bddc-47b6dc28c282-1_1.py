from manim import *

class MeasurementDefinitionAndEvolution(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("测量定义与长度单位演进",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 测量的定义 (使用分式形式可视化比值概念)
        def_label = Text("测量的本质:", font="AR PL UKai CN", font_size=28, color=BLUE_B).to_edge(LEFT, buff=1).shift(UP*1.5)

        # 分子:被测物理量
        numerator = Text("被测物理量", font="AR PL UKai CN", font_size=26, color=WHITE)
        # 分母:标准单位
        denominator = Text("标准单位", font="AR PL UKai CN", font_size=26, color=YELLOW)
        # 分数线
        div_line = Line(LEFT, RIGHT, color=WHITE).match_width(numerator).scale(1.2)

        # 组合分式
        fraction = VGroup(numerator, div_line, denominator).arrange(DOWN, buff=0.15)

        # 等号与结果
        equals = MathTex("=").scale(1.5)
        result = Text("测量值", font="AR PL UKai CN", font_size=26, color=GREEN)

        # 整个公式组合
        formula_group = VGroup(def_label, fraction, equals, result).arrange(RIGHT, buff=0.5)
        formula_group.move_to(UP * 1.5)

        # 强调框
        rect_def = SurroundingRectangle(formula_group, color=BLUE, buff=0.2)

        self.play(FadeIn(def_label))
        self.play(
            Write(fraction),
            Write(equals),
            Write(result),
            Create(rect_def),
            run_time=2
        )

        # 3. 长度单位(米)的演进 (时间轴可视化)
        timeline_y = DOWN * 1.5

        # 定义四个阶段的数据
        stages = [
            {"year": "古代", "desc": "人体(指/尺)", "color": GREY_B},
            {"year": "1790", "desc": "地球子午线", "color": TEAL},
            {"year": "1927", "desc": "镉(Cd)光谱", "color": BLUE},
            {"year": "1983", "desc": "光速定义", "color": GOLD},
        ]

        stage_mobjects = VGroup()

        for i, stage in enumerate(stages):
            # 年份/时期
            year_text = Text(stage["year"], font="AR PL UKai CN", font_size=20, color=stage["color"], weight=BOLD)
            # 描述
            desc_text = Text(stage["desc"], font="AR PL UKai CN", font_size=18, color=WHITE)

            # 组合单个节点
            item_group = VGroup(year_text, desc_text).arrange(DOWN, buff=0.15)

            #以此创建背景框
            bg_rect = SurroundingRectangle(item_group, color=stage["color"], fill_opacity=0.1, buff=0.1)

            full_item = VGroup(bg_rect, item_group)
            stage_mobjects.add(full_item)

        # 水平排列所有阶段
        stage_mobjects.arrange(RIGHT, buff=0.6).move_to(timeline_y)

        # 创建连接箭头
        arrows = VGroup()
        for i in range(len(stage_mobjects) - 1):
            arrow = Arrow(
                start=stage_mobjects[i].get_right(),
                end=stage_mobjects[i+1].get_left(),
                buff=0.1,
                color=GREY,
                max_tip_length_to_length_ratio=0.15
            )
            arrows.add(arrow)

        # 演进标题
        evo_label = Text("标准单位(米)的演进历史", font="AR PL UKai CN", font_size=24, color=ORANGE)
        evo_label.next_to(stage_mobjects, UP, buff=0.5)

        self.play(Write(evo_label), run_time=1)

        # 逐步显示演进过程
        self.play(
            LaggedStart(
                *[FadeIn(stage, shift=UP*0.2) for stage in stage_mobjects],
                lag_ratio=0.4
            ),
            LaggedStart(
                *[Create(arrow) for arrow in arrows],
                lag_ratio=0.4
            ),
            run_time=3
        )

        # 4. 最终强调 1983年定义
        final_highlight = SurroundingRectangle(stage_mobjects[-1], color=RED, buff=0.15, stroke_width=4)
        final_text = Text("当前定义", font="AR PL UKai CN", font_size=16, color=RED).next_to(final_highlight, DOWN, buff=0.1)

        self.play(
            Create(final_highlight),
            Write(final_text),
            run_time=1
        )
