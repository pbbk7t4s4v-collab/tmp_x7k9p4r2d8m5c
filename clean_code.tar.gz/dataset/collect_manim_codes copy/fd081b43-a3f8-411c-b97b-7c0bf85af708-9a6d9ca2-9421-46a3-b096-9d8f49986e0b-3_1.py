from manim import *

class IntegralAccumulation(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("定积分的几何意义：面积累积",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("18", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 坐标系与函数图像设置
        # 创建坐标系
        axes = Axes(
            x_range=[0, 6, 1],
            y_range=[0, 5, 1],
            x_length=6,
            y_length=4,
            axis_config={"include_tip": True, "tip_shape": ArrowTriangleFilledTip},
            tips=False
        )

        # 定义函数 f(x) = 0.1*(x-2)^2 + 1.5，平滑曲线适合展示面积
        func = axes.plot(lambda x: 0.1 * (x - 2)**2 + 1.5, x_range=[0, 5.5], color=BLUE)
        func_label = MathTex("f(x)", color=BLUE).next_to(func, UP, buff=0.1)

        # 将图表组合并放置在屏幕左侧，留出右侧给文字
        plot_group = VGroup(axes, func, func_label)
        plot_group.scale(0.9).to_edge(LEFT, buff=1).shift(DOWN * 0.5)

        # 3. 动态面积累积逻辑
        # 定义积分起点 a = 1
        a_val = 1
        # 使用 ValueTracker 控制动态终点 x
        x_tracker = ValueTracker(a_val)

        # 动态绘制面积区域 (always_redraw 确保每一帧更新)
        area = always_redraw(lambda: axes.get_area(
            func,
            x_range=[a_val, x_tracker.get_value()],
            color=TEAL,
            opacity=0.5
        ))

        # 动态绘制垂直线 x，指示当前积分位置
        v_line = always_redraw(lambda: axes.get_vertical_line(
            axes.c2p(x_tracker.get_value(), func.underlying_function(x_tracker.get_value())),
            color=YELLOW
        ))

        # 动态标签 x
        x_label = always_redraw(lambda: MathTex("x").next_to(
            axes.c2p(x_tracker.get_value(), 0), DOWN
        ))

        # 起点标签 a
        a_label = MathTex("a").next_to(axes.c2p(a_val, 0), DOWN)

        # 4. 右侧文字说明与公式
        explanation_text = Text(
            "定积分表示曲线下的面积",
            font="AR PL UKai CN",
            font_size=24,
            color=WHITE
        )

        # 核心公式
        formula = MathTex(
            r"S(x) = \int_a^x f(t) dt",
            font_size=38
        )

        # 解释：随着 x 移动，面积增加
        process_text = Text(
            "随着 x 向右移动，\n面积 S(x) 不断累积",
            font="AR PL UKai CN",
            font_size=24,
            line_spacing=1.2,
            color=YELLOW
        )

        # 布局右侧内容
        text_group = VGroup(explanation_text, formula, process_text)
        text_group.arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        text_group.next_to(plot_group, RIGHT, buff=1).shift(UP * 0.5)

        # 5. 动画流程
        # 第一步：显示坐标系和函数
        self.play(Create(axes), Create(func), Write(func_label))

        # 第二步：显示文字概念和公式
        self.play(FadeIn(explanation_text), Write(formula))

        # 强调公式
        box = SurroundingRectangle(formula, color=YELLOW, buff=0.15)
        self.play(Create(box))

        # 第三步：准备演示累积过程
        self.play(Write(a_label), FadeIn(process_text))
        self.add(area, v_line, x_label) # 添加动态元素

        # 第四步：执行扫描动画 (核心)
        # 移动 x 从 1 到 5，模拟积分过程
        self.play(
            x_tracker.animate.set_value(5),
            run_time=5,
            rate_func=linear
        )
