from manim import *

class CoqKeywordSuggestions(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (标准模板)
        # ---------------------------------------------------------
        title = Text("Coq 命题关键字使用建议",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局与生成
        # ---------------------------------------------------------

        def create_entry(keyword, desc_text, color=BLUE):
            """创建一个关键字项：上方是关键字，下方是说明"""
            kw = Text(keyword, font="Monospace", font_size=28, color=color, weight=BOLD)
            desc = Text(desc_text, font="AR PL UKai CN", font_size=20, color=WHITE)
            # 左对齐排列
            return VGroup(kw, desc).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # 左侧列表：基础/通用类
        left_items = VGroup(
            create_entry("Example", "用于教学演示或简单的特例验证", color="#4ECDC4"),
            create_entry("Fact", "无需复杂推导的公认事实", color="#4ECDC4"),
            create_entry("Proposition", "用于一般性的数学命题", color="#4ECDC4")
        ).arrange(DOWN, buff=0.6, aligned_edge=LEFT)

        # 右侧列表：结构/证明类 (存在逻辑关系)
        right_items = VGroup(
            create_entry("Lemma", "引理：证明大定理的辅助步骤", color=YELLOW),
            create_entry("Theorem", "定理：核心的、具有重要意义的结论", color=RED),
            create_entry("Corollary", "推论：从定理中直接推导出的结论", color=ORANGE)
        ).arrange(DOWN, buff=0.6, aligned_edge=LEFT)

        # 整体布局
        content_group = VGroup(left_items, right_items).arrange(RIGHT, buff=1.5)
        content_group.next_to(title_line, DOWN, buff=0.5)

        # ---------------------------------------------------------
        # 3. 动画演示
        # ---------------------------------------------------------

        # 左侧淡入
        self.play(
            FadeIn(left_items, shift=RIGHT * 0.5),
            run_time=1.0
        )

        # 右侧淡入
        self.play(
            FadeIn(right_items, shift=LEFT * 0.5),
            run_time=1.0
        )

        # 强调 Theorem (核心)
        theorem_item = right_items[1] # 获取中间的 Theorem
        highlight_box = SurroundingRectangle(theorem_item, color=RED, buff=0.15)
        highlight_text = Text("核心结论", font="AR PL UKai CN", font_size=18, color=RED)
        highlight_text.next_to(highlight_box, RIGHT)

        self.play(
            Create(highlight_box),
            Write(highlight_text),
            run_time=1.0
        )

        # 简单的逻辑连接线 (Lemma -> Theorem -> Corollary)
        # 获取各组件的中心点用于画线
        lemma_bottom = right_items[0].get_bottom()
        theorem_top = right_items[1].get_top()
        theorem_bottom = right_items[1].get_bottom()
        corollary_top = right_items[2].get_top()

        arrow1 = Arrow(start=lemma_bottom, end=theorem_top, buff=0.1, color=YELLOW, max_tip_length_to_length_ratio=0.15)
        arrow2 = Arrow(start=theorem_bottom, end=corollary_top, buff=0.1, color=ORANGE, max_tip_length_to_length_ratio=0.15)

        self.play(
            GrowArrow(arrow1),
            GrowArrow(arrow2),
            run_time=1.0
        )
