from manim import *

class DeterminantExercises(Scene):
    def construct(self):

        # 1. 标题部分 (严格按照模板要求)
        title = Text("行列式计算方法与练习",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：核心解题策略列表
        # 使用VGroup手动构建列表以确保中文字体支持和布局控制
        list_header = Text("核心解题策略：", font_size=28, font="AR PL UKai CN", color=BLUE_B)

        # 列表项
        item1 = Text("1. 利用性质化为上三角形", font_size=24, font="AR PL UKai CN")
        item2 = Text("2. 按行(列)展开降阶", font_size=24, font="AR PL UKai CN")
        item3 = Text("3. 递推公式与数学归纳法", font_size=24, font="AR PL UKai CN")
        item4 = Text("4. 范德蒙德行列式应用", font_size=24, font="AR PL UKai CN")

        # 组合列表
        list_items = VGroup(item1, item2, item3, item4).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        list_group = VGroup(list_header, list_items).arrange(DOWN, aligned_edge=LEFT, buff=0.4)

        # 定位左侧
        list_group.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 3. 右侧：可视化演示 (化三角形法)
        # 初始矩阵
        matrix_tex = MathTex(
            r"\begin{vmatrix} a_{11} & a_{12} & a_{13} \\ a_{21} & a_{22} & a_{23} \\ a_{31} & a_{32} & a_{33} \end{vmatrix}",
            font_size=30
        )

        # 变换箭头
        arrow = Arrow(LEFT, RIGHT, color=YELLOW, buff=0.2).scale(0.8)
        op_text = MathTex(r"r_i + k r_j", font_size=20, color=YELLOW).next_to(arrow, UP, buff=0.1)

        # 目标上三角矩阵
        tri_matrix_tex = MathTex(
            r"\begin{vmatrix} p_{11} & p_{12} & p_{13} \\ 0 & p_{22} & p_{23} \\ 0 & 0 & p_{33} \end{vmatrix}",
            font_size=30
        )

        # 组合右侧流程
        process_group = VGroup(matrix_tex, arrow, tri_matrix_tex).arrange(RIGHT, buff=0.2)
        process_group.to_edge(RIGHT, buff=1).shift(UP * 0.5)

        # 结果公式
        result_eq = MathTex(r"D = p_{11} \cdot p_{22} \cdot p_{33}", font_size=32, color=GREEN)
        result_eq.next_to(tri_matrix_tex, DOWN, buff=0.4)

        # 强调框
        box = SurroundingRectangle(process_group, color=BLUE, buff=0.2)
        box_label = Text("最常用方法示例", font_size=20, font="AR PL UKai CN", color=BLUE)
        box_label.next_to(box, UP, buff=0.1)

        # 4. 动画流程
        # 步骤1: 显示左侧列表
        self.play(FadeIn(list_group, shift=RIGHT), run_time=1.2)

        # 步骤2: 显示右侧可视化框架
        self.play(
            Create(box),
            Write(box_label),
            FadeIn(matrix_tex)
        )

        # 步骤3: 演示变换过程
        self.play(
            GrowArrow(arrow),
            Write(op_text),
            TransformFromCopy(matrix_tex, tri_matrix_tex)
        )

        # 步骤4: 强调对角线元素并显示结果
        # 获取对角线元素的大致位置进行强调 (索引可能因MathTex结构略有不同,这里使用通用覆盖)
        diag_rect = SurroundingRectangle(result_eq, color=GREEN, buff=0.1)

        self.play(
            Write(result_eq),
            Create(diag_rect)
        )
