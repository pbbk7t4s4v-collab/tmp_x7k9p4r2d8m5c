from manim import *

class HaldaneBackground(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("Haldane模型背景与任务",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：模型重要性
        importance_title = Text("模型重要性", font="AR PL UKai CN", font_size=28, color=BLUE)

        # 使用VGroup手动构建列表，避免BulletedList的兼容性问题
        p1 = Text("• 量子霍尔效应的无磁场原型", font="AR PL UKai CN", font_size=24)
        p2 = Text("• 晶格对称性破缺产生拓扑非平庸", font="AR PL UKai CN", font_size=24)

        left_group = VGroup(importance_title, p1, p2).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        left_group.to_edge(LEFT, buff=1).shift(UP * 0.5)

        self.play(FadeIn(left_group, shift=RIGHT))

        # 3. 右侧：核心目标流程图
        goal_title = Text("核心计算流程", font="AR PL UKai CN", font_size=28, color=BLUE)

        # 流程节点
        step1 = MathTex(r"H(k)", color=YELLOW)
        arrow1 = Arrow(start=LEFT, end=RIGHT, buff=0.1, color=WHITE).scale(0.5)
        step2 = MathTex(r"\text{Chern}", color=YELLOW)
        arrow2 = Arrow(start=LEFT, end=RIGHT, buff=0.1, color=WHITE).scale(0.5)
        step3 = Text("拓扑相图", font="AR PL UKai CN", font_size=20, color=YELLOW)

        flow_chart = VGroup(step1, arrow1, step2, arrow2, step3).arrange(RIGHT, buff=0.15)

        right_group = VGroup(goal_title, flow_chart).arrange(DOWN, buff=0.5)
        right_group.next_to(left_group, RIGHT, buff=1.5).align_to(left_group, UP)

        self.play(Write(right_group))

        # 4. 底部：本题任务
        task_label = Text("本题任务", font="AR PL UKai CN", font_size=26, color=ORANGE)

        # 代码模拟
        code_text = Text("def calc_hamiltonian(k): ...", font="AR PL UKai CN", font_size=24, color=GREEN)
        verify_text = Text("通过数值测试验证正确性", font="AR PL UKai CN", font_size=24, color=WHITE)

        task_content = VGroup(task_label, code_text, verify_text).arrange(DOWN, buff=0.2)
        task_box = SurroundingRectangle(task_content, color=TEAL, buff=0.3)
        task_group = VGroup(task_box, task_content)

        task_group.to_edge(DOWN, buff=0.8)

        self.play(
            Create(task_box),
            Write(task_content)
        )
