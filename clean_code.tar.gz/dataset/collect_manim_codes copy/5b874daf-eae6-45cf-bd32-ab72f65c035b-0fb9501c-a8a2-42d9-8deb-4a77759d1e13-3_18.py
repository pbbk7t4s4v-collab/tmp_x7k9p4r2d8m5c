from manim import *

class LevelOrderTraversalScene(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("二叉树的层序遍历 - Python 实现",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("20", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Content Sections
        # Foundational Period
        foundational_title = Text("代码展示", font="AR PL UKai CN",weight=BOLD, font_size=28)
        foundational_desc = Text("展示 Python 实现的层序遍历代码", font="AR PL UKai CN", font_size=24).next_to(foundational_title, DOWN, aligned_edge=LEFT, buff=0.15)
        foundational_group = VGroup(foundational_title, foundational_desc)

        # Viscosity and Vorticity
        viscosity_title = Text("可视化二叉树结构",font="AR PL UKai CN", weight=BOLD, font_size=28)
        viscosity_desc = Text("绘制节点和边，表示层序遍历的输入数据", font="AR PL UKai CN", font_size=24).next_to(viscosity_title, DOWN, aligned_edge=LEFT, buff=0.15)
        viscosity_group = VGroup(viscosity_title, viscosity_desc)

        # Boundary Layer Revolution
        boundary_title = Text("模拟遍历过程",font="AR PL UKai CN", weight=BOLD, font_size=28)
        boundary_desc = Text("高亮代码行，依次访问节点，显示结果数组", font="AR PL UKai CN", font_size=24).next_to(boundary_title, DOWN, aligned_edge=LEFT, buff=0.15)
        boundary_group = VGroup(boundary_title, boundary_desc)

        # Turbulence Theory
        turbulence_title = Text("最终遍历结果", weight=BOLD, font_size=28)
        turbulence_desc = Text("按顺序输出节点值，例如 [1, 2, 3, 4, 5, 6]", font="AR PL UKai CN", font_size=24).next_to(turbulence_title, DOWN, aligned_edge=LEFT, buff=0.15)
        turbulence_group = VGroup(turbulence_title, turbulence_desc)

        # 3. Layout and Animation
        content_group = VGroup(
            foundational_group,
            viscosity_group,
            boundary_group,
            turbulence_group
        ).arrange(DOWN, buff=0.5, aligned_edge=LEFT)

        content_group.next_to(title_group, DOWN, buff=0.5).to_edge(LEFT, buff=1.0)

        self.play(FadeIn(foundational_group, shift=UP*0.5), run_time=1)
        self.play(FadeIn(viscosity_group, shift=UP*0.5), run_time=1)
        self.play(FadeIn(boundary_group, shift=UP*0.5), run_time=1)
        self.play(FadeIn(turbulence_group, shift=UP*0.5), run_time=1)
