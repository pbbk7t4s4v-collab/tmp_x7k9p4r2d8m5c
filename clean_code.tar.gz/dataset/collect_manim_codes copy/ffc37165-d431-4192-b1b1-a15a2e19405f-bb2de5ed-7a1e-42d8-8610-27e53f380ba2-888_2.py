from manim import *

class PrimAlgorithmDemo(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("Prim算法：基于顶点的贪心扩展",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：图解可视化
        # 定义节点位置
        p_root = np.array([-5, 0.5, 0])      # U中已有点
        p_target1 = np.array([-2.5, 1.5, 0]) # 候选点1
        p_target2 = np.array([-2.5, -1.5, 0]) # 候选点2 (最近)

        # 绘制节点
        node_root = Dot(p_root, radius=0.2, color=GREEN) # 绿色表示在U中
        node_t1 = Dot(p_target1, radius=0.2, color=WHITE)
        node_t2 = Dot(p_target2, radius=0.2, color=WHITE)

        label_root = Text("U", font="AR PL UKai CN", font_size=24).next_to(node_root, LEFT)
        label_t1 = Text("V-U", font="AR PL UKai CN", font_size=24).next_to(node_t1, RIGHT)

        # 绘制边
        line1 = Line(p_root, p_target1, color=GRAY)
        line2 = Line(p_root, p_target2, color=GRAY)

        # 权重标签
        weight1 = MathTex("10", color=GRAY).next_to(line1, UP)
        weight2 = MathTex("2", color=YELLOW).next_to(line2, DOWN) # 较小的权重

        graph_group = VGroup(line1, line2, node_root, node_t1, node_t2, label_root, label_t1, weight1, weight2)

        # 集合U的包围框（示意）
        u_box = SurroundingRectangle(node_root, color=GREEN, buff=0.3)
        u_label = Text("已选集合 U", font="AR PL UKai CN", font_size=20, color=GREEN).next_to(u_box, UP)

        self.play(FadeIn(graph_group), Create(u_box), Write(u_label))

        # 3. 右侧：核心逻辑与数据结构
        # 使用VGroup手动排列文本，避免BulletList的问题
        text_start_x = 1.0
        text_y_start = 1.5
        line_spacing = 0.9

        # 核心思想
        txt_core = Text("核心：贪心策略，维护集合U", font="AR PL UKai CN", font_size=26, color=BLUE)
        txt_core.move_to(RIGHT * 4 + UP * text_y_start).align_to(RIGHT * text_start_x, LEFT)

        # 关键步骤1
        txt_step1 = Text("1. 在V-U中选dist最小点入U", font="AR PL UKai CN", font_size=24)
        txt_step1.next_to(txt_core, DOWN, buff=line_spacing).align_to(txt_core, LEFT)

        # 关键步骤2
        txt_step2 = Text("2. 松弛操作：刷新邻接点dist", font="AR PL UKai CN", font_size=24)
        txt_step2.next_to(txt_step1, DOWN, buff=line_spacing).align_to(txt_core, LEFT)

        # 复杂度
        txt_comp = VGroup(
            Text("适用：稠密图，复杂度", font="AR PL UKai CN", font_size=24, color=YELLOW),
            MathTex("O(n^2)", font_size=28, color=YELLOW)
        ).arrange(RIGHT, buff=0.1)
        txt_comp.next_to(txt_step2, DOWN, buff=line_spacing).align_to(txt_core, LEFT)

        # 动画展示文本
        self.play(Write(txt_core))
        self.play(FadeIn(txt_step1))

        # 4. 结合动画演示选择过程
        # 高亮选中的边和点
        highlight_line = line2.copy().set_color(YELLOW).set_stroke(width=6)
        highlight_node = node_t2.copy().set_color(GREEN) # 变绿表示加入U

        arrow_pointer = Arrow(start=RIGHT, end=LEFT, color=YELLOW).next_to(node_t2, RIGHT)
        dist_label = Text("dist=2 (最小)", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(arrow_pointer, RIGHT)

        self.play(
            Create(highlight_line),
            FadeIn(arrow_pointer),
            Write(dist_label)
        )

        # 扩展集合U的框
        new_u_box = SurroundingRectangle(VGroup(node_root, node_t2), color=GREEN, buff=0.3)

        self.play(
            Transform(node_t2, highlight_node),
            Transform(u_box, new_u_box),
            FadeOut(arrow_pointer),
            FadeOut(dist_label)
        )

        # 显示剩余文本
        self.play(Write(txt_step2))
        self.play(FadeIn(txt_comp))
