from manim import *

class MedicalApplicationsScene(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Applications in Medicine & Bioengineering",
                     font_size=30,  # 修复：字体稍减小以优化整体布局
                     color=WHITE,
                     weight=BOLD)
        title.scale(0.95)  # 修复：整体缩放调整减少宽度，提升安全边距
        title.to_edge(UP, buff=0.6)  # 修复：上边距由0.5改为0.6，避免过近顶部

        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.15)  # 修复：略增加buff优化行间距
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # 2. Key Application Areas
        applications_list = BulletedList(
            "Cardiovascular System: Modeling blood flow to study diseases like atherosclerosis.",
            "Medical Devices: Designing artificial hearts and pumps considering shear stress and pulsatile flow.",
            "Biofluid Systems: Analyzing respiratory airflow to improve artificial ventilators.",
            font_size=26  # 修复：减小字体防止左侧紧贴边界
        ).scale(0.95)  # 修复：整体缩放以减少宽度
        applications_list.next_to(title_group, DOWN, buff=0.6).to_edge(LEFT, buff=1.2)  # 修复：增加左侧边距至1.2

        # 3. Animate each point sequentially
        for item in applications_list:
            self.play(FadeIn(item, shift=UP*0.2), run_time=1.5)
