from manim import *

class PythonNumberTypes(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("Python中的数值类型",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容定义
        font_style = "AR PL UKai CN"

        # --- 整数部分 ---
        int_title = Text("整数 (int)", font=font_style, font_size=28, color=BLUE_A)
        int_desc = Text("没有小数部分的数字", font=font_style, font_size=20, color=GRAY)
        int_ex1 = Text("age = 18", font=font_style, font_size=24, color=YELLOW)
        int_ex2 = Text("count = -5", font=font_style, font_size=24, color=YELLOW)

        int_group = VGroup(int_title, int_desc, int_ex1, int_ex2)
        int_group.arrange(DOWN, buff=0.3)

        int_box = SurroundingRectangle(int_group, color=BLUE, buff=0.2)
        int_full = VGroup(int_box, int_group)

        # --- 浮点数部分 ---
        float_title = Text("浮点数 (float)", font=font_style, font_size=28, color=GREEN_A)
        float_desc = Text("带有小数点的数字", font=font_style, font_size=20, color=GRAY)
        float_ex1 = Text("height = 1.75", font=font_style, font_size=24, color=YELLOW)
        float_ex2 = Text("pi = 3.14159", font=font_style, font_size=24, color=YELLOW)

        float_group = VGroup(float_title, float_desc, float_ex1, float_ex2)
        float_group.arrange(DOWN, buff=0.3)

        float_box = SurroundingRectangle(float_group, color=GREEN, buff=0.2)
        float_full = VGroup(float_box, float_group)

        # --- 常量部分 ---
        const_title = Text("常量 (Constant)", font=font_style, font_size=28, color=RED_A)
        const_desc = Text("约定使用全大写字母", font=font_style, font_size=20, color=GRAY)
        const_ex1 = Text("MAX_SPEED = 120", font=font_style, font_size=24, color=YELLOW)
        const_ex2 = Text("PI = 3.14", font=font_style, font_size=24, color=YELLOW)

        const_group = VGroup(const_title, const_desc, const_ex1, const_ex2)
        const_group.arrange(DOWN, buff=0.3)

        const_box = SurroundingRectangle(const_group, color=RED, buff=0.2)
        const_full = VGroup(const_box, const_group)

        # 3. 布局位置
        # 将三个板块横向排列
        all_groups = VGroup(int_full, float_full, const_full)
        all_groups.arrange(RIGHT, buff=0.8)
        all_groups.move_to(ORIGIN).shift(DOWN * 0.3) # 稍微下移,避开标题

        # 4. 动画展示
        # 依次展示三个部分
        self.play(FadeIn(int_full, shift=UP), run_time=1)

        self.play(FadeIn(float_full, shift=UP), run_time=1)

        self.play(FadeIn(const_full, shift=UP), run_time=1)
