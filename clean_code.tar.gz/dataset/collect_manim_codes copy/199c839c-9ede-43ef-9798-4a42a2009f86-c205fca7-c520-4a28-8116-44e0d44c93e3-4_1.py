from manim import *

class AIFutureTrend(Scene):
    def construct(self):

        # --- 1. 标题部分 (标准模板) ---
        title = Text("AI 的未来趋势:第二大脑",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- 2. 核心概念对比 ---
        # 左侧:错误的观点(替代者)
        wrong_text = Text("替代者", font="AR PL UKai CN", font_size=36, color=RED_C)
        wrong_cross = Cross(wrong_text, stroke_width=6)
        wrong_group = VGroup(wrong_text, wrong_cross)

        # 右侧:正确的观点(第二大脑)
        right_text = Text("第二大脑", font="AR PL UKai CN", font_size=36, color=GREEN_C)
        right_rect = SurroundingRectangle(right_text, color=GREEN, buff=0.2)
        right_group = VGroup(right_text, right_rect)

        # 布局对比文本
        comparison_group = VGroup(wrong_group, right_group).arrange(RIGHT, buff=3)
        comparison_group.next_to(title_group, DOWN, buff=1.0)

        # 动画展示对比
        self.play(FadeIn(wrong_text))
        self.play(Create(wrong_cross))

        # 展示正确的概念
        self.play(
            FadeIn(right_text),
            Create(right_rect)
        )

        # --- 3. 视觉化演示 (人 + AI) ---
        # 创建简单的几何图形代表人类和AI

        # 人类节点
        human_circle = Circle(radius=0.7, color=BLUE, fill_opacity=0.3)
        human_label = Text("人类", font="AR PL UKai CN", font_size=24).move_to(human_circle)
        human_group = VGroup(human_circle, human_label)

        # AI节点
        ai_square = Square(side_length=1.4, color=TEAL, fill_opacity=0.3)
        ai_label = Text("AI", font="AR PL UKai CN", font_size=24).move_to(ai_square)
        ai_group = VGroup(ai_square, ai_label)

        # 符号
        plus_sign = MathTex("+", font_size=50)

        # 组合布局
        equation_group = VGroup(human_group, plus_sign, ai_group).arrange(RIGHT, buff=0.5)
        equation_group.next_to(comparison_group, DOWN, buff=1.0)

        # 结果文字
        result_text = Text("能力增强 (Augmentation)", font="AR PL UKai CN", font_size=28, color=YELLOW)
        result_text.next_to(equation_group, DOWN, buff=0.5)

        # 动画展示公式
        self.play(
            DrawBorderThenFill(human_group),
            Write(plus_sign),
            DrawBorderThenFill(ai_group)
        )
        self.play(Write(result_text))

        # --- 4. 讨论提示 ---
        discuss_box = RoundedRectangle(corner_radius=0.2, height=1.2, width=10, color=GREY)
        discuss_text = Text("课堂讨论:AI 如何成为你的"外挂"而不是对手?",
                           font="AR PL UKai CN", font_size=26, color=WHITE)
        discuss_group = VGroup(discuss_box, discuss_text)
        discuss_group.to_edge(DOWN, buff=0.5)

        self.play(FadeIn(discuss_group, shift=UP))
