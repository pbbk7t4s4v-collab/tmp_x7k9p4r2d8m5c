from manim import *

class RigidBodyMotionScene(Scene):
    def construct(self):

        # ---- Title Configuration (Strict Template) ----
        title = Text("Rigid Body Motion: Translation & Rotation",
                    font_size=34,  # Larger font size
                    color=WHITE,   # White text for contrast
                    weight=BOLD)   # Bold weight
        title.to_edge(UP, buff=0.5)  # Position at top

        # Add bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Group title elements
        title_group = VGroup(title, title_line)

        # Title Animation - Scale and Fade In
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---- Visual Elements (Left Side) ----
        # Representation of a Rigid Body (Square with local frame)
        body_color = BLUE
        body = Square(side_length=2.5, color=body_color, fill_opacity=0.4)

        # Local Coordinate System attached to the body
        x_axis = Arrow(ORIGIN, RIGHT, color=RED, buff=0).scale(0.8)
        y_axis = Arrow(ORIGIN, UP, color=GREEN, buff=0).scale(0.8)
        frame_origin = body.get_center()
        local_frame = VGroup(x_axis, y_axis).move_to(frame_origin)

        # Points to illustrate constant distance
        p1 = Dot(point=frame_origin + LEFT*0.6 + DOWN*0.6, color=YELLOW)
        p2 = Dot(point=frame_origin + RIGHT*0.6 + UP*0.6, color=YELLOW)
        dist_line = DashedLine(p1.get_center(), p2.get_center(), color=YELLOW)
        dist_text = MathTex("d = const", color=YELLOW, font_size=24).next_to(dist_line, RIGHT, buff=0.1)

        # Group all visual elements
        rigid_obj = VGroup(body, local_frame, p1, p2, dist_line, dist_text)
        rigid_obj.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # ---- Text Elements (Right Side) ----
        # 1. Definition
        txt_def_title = Text("Rigid Body Definition:", font_size=28, color=BLUE_B, weight=BOLD)
        txt_def_body = Text("Distance between any two points\nremains constant.", font_size=24, line_spacing=0.5)
        group_def = VGroup(txt_def_title, txt_def_body).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # 2. Motion Types
        txt_trans = Text("1. Position (Translation)", font_size=28, color=RED_B, weight=BOLD)
        txt_rot = Text("2. Orientation (Rotation)", font_size=28, color=GREEN_B, weight=BOLD)

        # 3. DOF Summary
        math_dof = MathTex(r"6 \text{ DOF} = 3 \text{ Trans.} + 3 \text{ Rot.}", font_size=36, color=ORANGE)

        # Arrange all text on the right
        text_column = VGroup(group_def, txt_trans, txt_rot, math_dof)
        text_column.arrange(DOWN, aligned_edge=LEFT, buff=0.6)
        text_column.to_edge(RIGHT, buff=1.0).shift(UP * 0.2)

        # ---- Animations ----

        # 1. Show Rigid Body and Definition
        self.play(
            FadeIn(rigid_obj, shift=RIGHT),
            FadeIn(group_def, shift=LEFT),
            run_time=1.5
        )

        # 2. Demonstrate Translation (Position)
        # Move the object while highlighting text
        self.play(
            FadeIn(txt_trans, shift=LEFT),
            rigid_obj.animate.shift(RIGHT * 1.5 + UP * 0.5),
            run_time=1.5
        )

        # 3. Demonstrate Rotation (Orientation)
        # Rotate the object while highlighting text
        self.play(
            FadeIn(txt_rot, shift=LEFT),
            Rotate(rigid_obj, angle=-PI/6, about_point=rigid_obj.get_center()),
            run_time=1.5
        )

        # 4. Conclusion: 6 DOF
        rect = SurroundingRectangle(math_dof, color=ORANGE, buff=0.2)
        self.play(
            Write(math_dof),
            Create(rect),
            run_time=1.5
        )
