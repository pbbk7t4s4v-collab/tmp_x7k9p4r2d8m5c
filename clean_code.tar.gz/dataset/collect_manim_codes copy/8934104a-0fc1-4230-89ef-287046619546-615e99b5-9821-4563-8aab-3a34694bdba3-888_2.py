from manim import *

class SupervisedLearningIntro(Scene):
    def construct(self):

        # 1. 标题模块
        title = Text("监督学习核心任务：分类与回归",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容模块 - 分为左右两列
        # 左侧：分类问题
        class_text = Text("分类问题", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        class_desc = Text("预测离散类别标签", font="AR PL UKai CN", font_size=20, color=WHITE)

        # 图片1：图像分类
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/615e99b5-9821-4563-8aab-3a34694bdba3/pictures/888_2/1.png") # 这里期望是一张展示图像分类任务的照片，画面中心是一只清晰可爱的金毛犬或猫咪，背景虚化或简洁，用于说明机器如何识别图像中的物体，写实风格
        img1.height = 2.2
        img1.width = 2.2 # 保持1:1比例大致视觉

        left_group = Group(class_text, class_desc, img1).arrange(DOWN, buff=0.2)
        left_group.to_edge(LEFT, buff=1.5).shift(UP*0.5)

        # 右侧：回归问题
        reg_text = Text("回归问题", font="AR PL UKai CN", font_size=28, color=GREEN_A)
        reg_desc = Text("预测连续数值输出", font="AR PL UKai CN", font_size=20, color=WHITE)

        # 图片2：胡克定律回归
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/615e99b5-9821-4563-8aab-3a34694bdba3/pictures/888_2/2.png") # 这里期望是一张物理实验中验证胡克定律的实验装置示意图，包含一个悬挂在支架上的金属弹簧，弹簧下方挂着砝码，旁边竖立着一把刻度尺用于测量伸长量，教科书插图风格，线条清晰，背景为纯白或浅色
        img2.height = 2.2
        img2.width = 2.2

        right_group = Group(reg_text, reg_desc, img2).arrange(DOWN, buff=0.2)
        right_group.to_edge(RIGHT, buff=1.5).shift(UP*0.5)

        # 3. 底部模块 - 最小二乘法（连接回归问题）
        ls_label = Text("线性模型：最小二乘法", font="AR PL UKai CN", font_size=24, color=YELLOW).move_to(DOWN * 2.0)

        # 公式：寻找距离平方和最小
        ls_formula = MathTex(r"\min \sum_{i=1}^{n} (y_i - (ax_i + b))^2", font_size=28)
        ls_formula.next_to(ls_label, DOWN, buff=0.2)

        ls_group = VGroup(ls_label, ls_formula)

        # 强调框
        rect = SurroundingRectangle(ls_group, color=YELLOW, buff=0.15, stroke_width=2)

        # 4. 动画展示流程
        # 展示左右两类基本问题
        self.play(
            FadeIn(left_group, shift=RIGHT),
            FadeIn(right_group, shift=LEFT),
            run_time=1.5
        )

        # 强调回归问题引出的最小二乘法
        self.play(
            Write(ls_label),
            FadeIn(ls_formula, shift=UP),
        )
        self.play(Create(rect))

        # 5. 几何意义简述（文字出现）
        geo_text = Text("几何意义：寻找欧氏距离最短的投影", font="AR PL UKai CN", font_size=20, color=GRAY_A)
        geo_text.next_to(rect, DOWN, buff=0.2)
        self.play(FadeIn(geo_text, scale=0.8))
