from manim import *

class LegalConsciousness(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("法律意识的社会建构",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("15", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心定义部分
        # 保持简洁，避免遮挡
        def_text = Text("定义：个体对法律的认知、理解与情感态度", font="AR PL UKai CN", font_size=26)
        def_sub = Text("（非静态知识，而是日常生活中动态建构的意义系统）", font="AR PL UKai CN", font_size=22, color=LIGHT_GRAY)

        def_group = VGroup(def_text, def_sub).arrange(DOWN, buff=0.2)
        def_group.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(def_group, shift=DOWN))

        # 3. 三种典型形态 (Ewick & Silbey)
        # 使用三个方框展示分类，逻辑清晰

        # 类型 1: 法律之前
        t1_label = Text("1. 法律之前\n(Before the Law)", font="AR PL UKai CN", font_size=24, color=BLUE)
        t1_desc = Text("视为客观权威\n个体服从规则", font="AR PL UKai CN", font_size=20, line_spacing=1.2)
        t1_group = VGroup(t1_label, t1_desc).arrange(DOWN, buff=0.3)
        t1_box = SurroundingRectangle(t1_group, color=BLUE, buff=0.2)
        t1_all = VGroup(t1_box, t1_group)

        # 类型 2: 法律共处
        t2_label = Text("2. 法律共处\n(With the Law)", font="AR PL UKai CN", font_size=24, color=GREEN)
        t2_desc = Text("视为策略资源\n服务个人目标", font="AR PL UKai CN", font_size=20, line_spacing=1.2)
        t2_group = VGroup(t2_label, t2_desc).arrange(DOWN, buff=0.3)
        t2_box = SurroundingRectangle(t2_group, color=GREEN, buff=0.2)
        t2_all = VGroup(t2_box, t2_group)

        # 类型 3: 对抗法律
        t3_label = Text("3. 对抗法律\n(Against the Law)", font="AR PL UKai CN", font_size=24, color=RED)
        t3_desc = Text("视为压迫工具\n采取抵抗规避", font="AR PL UKai CN", font_size=20, line_spacing=1.2)
        t3_group = VGroup(t3_label, t3_desc).arrange(DOWN, buff=0.3)
        t3_box = SurroundingRectangle(t3_group, color=RED, buff=0.2)
        t3_all = VGroup(t3_box, t3_group)

        # 排列三个方框
        types_group = VGroup(t1_all, t2_all, t3_all).arrange(RIGHT, buff=0.4)
        types_group.next_to(def_group, DOWN, buff=0.8)

        # 展示分类标题
        category_title = Text("Ewick & Silbey 的三种法律意识形态", font="AR PL UKai CN", font_size=24, color=YELLOW)
        category_title.next_to(types_group, UP, buff=0.2)

        self.play(Write(category_title))
        self.play(
            Create(t1_box), Write(t1_group),
            Create(t2_box), Write(t2_group),
            Create(t3_box), Write(t3_group),
            run_time=2.5
        )

        # 4. 底部补充信息 (社会位置影响)
        footer_text = Text("注：法律意识受阶级、性别、种族等社会位置深刻影响",
                          font="AR PL UKai CN", font_size=20, color=GRAY_B)
        footer_text.to_edge(DOWN, buff=0.5)

        self.play(FadeIn(footer_text))

        # 停顿以供阅读
