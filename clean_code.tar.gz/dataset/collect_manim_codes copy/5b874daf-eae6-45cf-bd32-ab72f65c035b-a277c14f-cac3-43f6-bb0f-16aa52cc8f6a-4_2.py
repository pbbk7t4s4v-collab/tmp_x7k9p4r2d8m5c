from manim import *

class FeaturePolyVieta(Scene):
    def construct(self):
        # ==========================================
        # 0. 视觉风格配置 (Visual Config)
        # ==========================================
        # 字体
        FONT_MAIN = "AR PL UKai CN"

        # 配色 (更轻盈的玻璃质感)
        COLOR_ACCENT = "#FFD700"     # 金色
        COLOR_CARD_BG = "#2E2E2E"    # 略微提亮的深灰背景
        COLOR_CARD_BORDER = WHITE    # 细白边框
        COLOR_TEXT_MAIN = WHITE

        # 透明度设置
        OPACITY_BG_OVERLAY = 0.8     # 背景压暗程度
        OPACITY_CARD_FILL = 0.6      # 卡片透明度
        OPACITY_CARD_STROKE = 0.3    # 边框透明度

        # ==========================================
        # 1. 背景与氛围 (Background)
        # ==========================================
        # 尝试加载背景图
        try:
            bg = ImageMobject("/home/TeachMasterAppV2/backend/SAI.png")
            bg.set_z_index(-100)
            bg.scale(max(config.frame_width/bg.width, config.frame_height/bg.height))
            bg.move_to(ORIGIN)
            self.add(bg)
        except:
            self.camera.background_color = "#111111"

        # [关键修复]: 全局遮罩 (去掉了白边)
        bg_overlay = Rectangle(
            # 让遮罩比屏幕稍微大一点点 (0.1)，防止边缘有缝隙
            width=config.frame_width + 0.1,
            height=config.frame_height + 0.1,
            fill_color=BLACK,
            fill_opacity=OPACITY_BG_OVERLAY,
            stroke_width=0  # <--- [修复点] 这一行去掉了白边
        ).set_z_index(-99)
        self.add(bg_overlay)

        # ==========================================
        # 2. 布局容器：大尺寸英雄卡片
        # ==========================================
        # 卡片主体 (12x7)
        hero_card = RoundedRectangle(
            corner_radius=0.5, width=12.0, height=7.0,
            fill_color=COLOR_CARD_BG, fill_opacity=OPACITY_CARD_FILL,
            stroke_color=COLOR_CARD_BORDER, stroke_width=2, stroke_opacity=OPACITY_CARD_STROKE
        ).move_to(ORIGIN)

        # 顶部装饰线 (位于标题下方)
        # 计算线条宽度：比卡片略窄 (左右各留 1.0 的边距)
        line_width = 12.0 - 2.0

        header_line = Line(LEFT * (line_width/2), RIGHT * (line_width/2), color=COLOR_ACCENT)
        # 将线条放在卡片顶部向下一点的位置
        header_line.next_to(hero_card.get_top(), DOWN, buff=1.2)

        # 标题 (位于线条上方)
        title_text = "特征多项式与韦达定理"
        title = Text(title_text, font=FONT_MAIN, font_size=42, color=COLOR_TEXT_MAIN, weight=BOLD)
        title.next_to(header_line, UP, buff=0.25)

        # Page number
        page_number = Text("33", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)

        # 入场动画
        self.play(
            FadeIn(hero_card, scale=0.95),
            Create(header_line),
            Write(title),
            FadeIn(page_number),
            run_time=1.5
        )

        # ==========================================
        # 3. 内容填充区 (Content Area)
        # ==========================================

        # 2. 特征多项式定义部分
        # 文本说明
        def_text = Text("对于 n×n 矩阵 A，其特征多项式为：", font=FONT_MAIN, font_size=24, color=BLUE_B)

        # 公式：det(A - lambda I) = 0
        def_math = MathTex(r"\det(A - \lambda I) = 0", font_size=36)

        # 组合定义部分
        def_group = VGroup(def_text, def_math).arrange(DOWN, buff=0.2)
        def_group.next_to(header_line, DOWN, buff=0.5)

        self.play(FadeIn(def_group, shift=DOWN))

        # 3. 展开形式部分
        # 使用箭头表示展开
        arrow = Arrow(start=UP, end=DOWN, buff=0.1, color=GREY).scale(0.6)
        arrow.next_to(def_group, DOWN, buff=0.1)

        # 多项式展开公式
        # P(lambda) = c_n lambda^n + ...
        poly_math = MathTex(
            r"P(\lambda) = c_n \lambda^n + c_{n-1} \lambda^{n-1} + \dots + c_1 \lambda + c_0",
            font_size=28
        )
        poly_math.next_to(arrow, DOWN, buff=0.1)

        self.play(Create(arrow), Write(poly_math))

        # 4. 韦达定理部分 (核心展示)
        # 提示文本
        vieta_title = Text("根据韦达定理 (Vieta's Formulas)：", font=FONT_MAIN, font_size=22, color=YELLOW)
        vieta_title.next_to(poly_math, DOWN, buff=0.4)

        # 根之和公式
        sum_label = Text("根之和 (Sum)", font=FONT_MAIN, font_size=18, color=WHITE)
        sum_math = MathTex(r"\sum_{i=1}^{n} \lambda_i = - \frac{c_{n-1}}{c_n}", font_size=26)
        sum_group = VGroup(sum_label, sum_math).arrange(DOWN, buff=0.15)

        # 根之积公式
        prod_label = Text("根之积 (Product)", font=FONT_MAIN, font_size=18, color=WHITE)
        prod_math = MathTex(r"\prod_{i=1}^{n} \lambda_i = (-1)^n \frac{c_0}{c_n}", font_size=26)
        prod_group = VGroup(prod_label, prod_math).arrange(DOWN, buff=0.15)

        # 将两个公式左右排列
        formulas_group = VGroup(sum_group, prod_group).arrange(RIGHT, buff=1.5)
        formulas_group.next_to(vieta_title, DOWN, buff=0.3)

        # 添加外框强调
        box = SurroundingRectangle(formulas_group, color=YELLOW, buff=0.2)

        # 动画播放
        self.play(Write(vieta_title))
        self.play(
            FadeIn(sum_group, shift=RIGHT),
            FadeIn(prod_group, shift=LEFT)
        )
        self.play(Create(box))

        # 5. 底部总结 (关联矩阵性质)
        # 简单的文本连接
        summary_text = Text("系数与矩阵性质(迹、行列式)直接相关", font=FONT_MAIN, font_size=18, color=GREY_A)
        summary_text.next_to(box, DOWN, buff=0.25)

        self.play(FadeIn(summary_text))

        # 停顿以展示内容

        to_fade = [m for m in self.mobjects if m != bg and m != bg_overlay]
        self.play(FadeOut(*to_fade))
