from manim import *

class ImageStructureAndModeling(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("图像数据的结构特征与建模动机",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念文本：高维性与冗余性
        # 使用MathTex展示维度计算，体现高维特征
        dim_formula = MathTex(r"256 \times 256 \times 3 \approx 200,000", color=BLUE_B, font_size=32)
        dim_text = Text("高维数据但存在大量结构冗余", font="AR PL UKai CN", font_size=24, color=WHITE)

        header_group = VGroup(dim_formula, dim_text).arrange(DOWN, buff=0.2)
        header_group.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(header_group, shift=DOWN))

        # 3. 图片展示部分
        # 左侧：局部相关性
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/f17d9f3a-0a79-4f68-98c6-09d03f13bb91/pictures/888_1/1.png") # 这里期望是一张高清晰度的自然图像（如花朵或风景）的局部特写，画面上叠加了明显的像素网格。其中一个中心像素及其周围的邻域像素被高亮显示，展示出颜色的连续性和相似性，用于解释'像素间的局部相关性'，写实风
        img1.height = 3.0 # 设置固定高度，保持比例
        img1.to_edge(LEFT, buff=1.5).shift(DOWN * 0.5)

        label1 = Text("局部相关性", font="AR PL UKai CN", font_size=26, color=YELLOW)
        label1.next_to(img1, UP, buff=0.2)

        sub_label1 = Text("相邻像素关联强", font="AR PL UKai CN", font_size=20, color=GRAY_B)
        sub_label1.next_to(img1, DOWN, buff=0.2)

        # 右侧：平移不变性
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/8934104a-0fc1-4230-89ef-287046619546/f17d9f3a-0a79-4f68-98c6-09d03f13bb91/pictures/888_1/2.png") # 这里期望是一张可爱的猫咪照片，背景简洁（最好是纯白），主体清晰。这张图片将用于演示'平移不变性'，即猫咪位于画面左侧或右侧时，模型都能将其识别为猫，写实风
        img2.height = 3.0
        img2.to_edge(RIGHT, buff=1.5).shift(DOWN * 0.5)

        label2 = Text("平移不变性", font="AR PL UKai CN", font_size=26, color=GREEN)
        label2.next_to(img2, UP, buff=0.2)

        sub_label2 = Text("位置变化不改语义", font="AR PL UKai CN", font_size=20, color=GRAY_B)
        sub_label2.next_to(img2, DOWN, buff=0.2)

        # 4. 动画展示流程
        # 展示左侧图片及概念
        self.play(
            FadeIn(img1, shift=RIGHT),
            Write(label1),
            FadeIn(sub_label1)
        )

        # 使用方框强调图片内容
        rect1 = SurroundingRectangle(img1, color=YELLOW, buff=0.05)
        self.play(Create(rect1, run_time=0.5))

        # 展示右侧图片及概念
        self.play(
            FadeIn(img2, shift=LEFT),
            Write(label2),
            FadeIn(sub_label2)
        )

        # 使用方框强调图片内容
        rect2 = SurroundingRectangle(img2, color=GREEN, buff=0.05)
        self.play(Create(rect2, run_time=0.5))

        # 5. 总结性连接
        # 在底部简要说明这导致了权重共享机制
        final_text = Text("结论：局部连接与权重共享是必要的", font="AR PL UKai CN", font_size=24, color=ORANGE)
        final_text.to_edge(DOWN, buff=0.5)

        self.play(Write(final_text))
