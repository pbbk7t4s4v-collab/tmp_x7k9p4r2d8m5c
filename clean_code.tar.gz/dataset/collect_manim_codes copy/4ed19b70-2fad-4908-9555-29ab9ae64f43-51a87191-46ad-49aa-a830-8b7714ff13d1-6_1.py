from manim import *

class ProgrammingConceptsOverview(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("程序设计核心概念概览",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("13", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念节点 (中心)
        center_font = "AR PL UKai CN"
        center_text = Text("计算机编程", font=center_font, font_size=40, color=BLUE_A)
        center_rect = SurroundingRectangle(center_text, color=BLUE, buff=0.3, stroke_width=2)
        center_group = VGroup(center_rect, center_text).move_to(ORIGIN).shift(DOWN * 0.5)

        # 3. 周围分支概念 (四个角)
        # 左上:语言与范例
        node1_text = Text("编程语言与范例", font=center_font, font_size=28, color=YELLOW)
        node1_pos = center_group.get_center() + UP * 2 + LEFT * 3.5
        node1_text.move_to(node1_pos)

        # 右上:程序设计
        node2_text = Text("程序设计", font=center_font, font_size=28, color=GREEN)
        node2_pos = center_group.get_center() + UP * 2 + RIGHT * 3.5
        node2_text.move_to(node2_pos)

        # 右下:测试与文档
        node3_text = Text("程序测试和文档", font=center_font, font_size=28, color=RED)
        node3_pos = center_group.get_center() + DOWN * 2 + RIGHT * 3.5
        node3_text.move_to(node3_pos)

        # 左下:面向对象
        node4_text = Text("面向对象编程", font=center_font, font_size=28, color=TEAL)
        node4_pos = center_group.get_center() + DOWN * 2 + LEFT * 3.5
        node4_text.move_to(node4_pos)

        nodes = VGroup(node1_text, node2_text, node3_text, node4_text)

        # 4. 连接线 (从中心指向四周)
        lines = VGroup()
        for node in nodes:
            # 计算从中心矩形边缘到文字边缘的向量
            start_point = center_rect.get_edge_center(normalize(node.get_center() - center_group.get_center()))
            end_point = node.get_edge_center(normalize(center_group.get_center() - node.get_center()))

            line = Arrow(start_point, end_point, buff=0.1, color=GRAY_C, stroke_width=2, max_tip_length_to_length_ratio=0.15)
            lines.add(line)

        # 5. 动画流程展示
        # 第一步:显示中心核心
        self.play(FadeIn(center_group, scale=0.8), run_time=1)

        # 第二步:射出连接线
        self.play(LaggedStart(*[GrowArrow(l) for l in lines], lag_ratio=0.1), run_time=1.5)

        # 第三步:显示四个维度的文字
        self.play(LaggedStart(
            Write(node1_text),
            Write(node2_text),
            Write(node3_text),
            Write(node4_text),
            lag_ratio=0.2
        ), run_time=2)

        # 6. 简单的高亮强调 (强调循环逻辑)
        # 使用简单的圆框依次闪烁强调各个部分
        highlights = VGroup()
        for node, col in zip(nodes, [YELLOW, GREEN, RED, TEAL]):
            rect = SurroundingRectangle(node, color=col, buff=0.15, stroke_width=1)
            highlights.add(rect)

        self.play(ShowPassingFlash(
            highlights.copy().set_stroke(width=4, opacity=1),
            time_width=0.5,
            run_time=2
        ))
