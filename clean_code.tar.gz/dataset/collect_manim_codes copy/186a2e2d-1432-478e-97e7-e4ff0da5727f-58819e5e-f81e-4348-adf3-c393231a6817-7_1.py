from manim import *

class GradientDescentSummary(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("梯度下降法:核心梳理与结论",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("21", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心梳理流程图 (Flowchart)
        # ---------------------------------------------------------
        # 定义流程节点文本
        t1 = Text("梯度本质", font="AR PL UKai CN", font_size=24, color=WHITE)
        t2 = Text("三大变种", font="AR PL UKai CN", font_size=24, color=WHITE)
        t3 = Text("改进算法", font="AR PL UKai CN", font_size=24, color=WHITE)
        t4 = Text("实践步骤", font="AR PL UKai CN", font_size=24, color=WHITE)

        # 定义节点背景框
        def get_box(mob, color=BLUE):
            return SurroundingRectangle(mob, color=color, fill_opacity=0.2, fill_color=color, corner_radius=0.2, buff=0.2)

        # 布局:水平排列
        flow_group = VGroup(t1, t2, t3, t4).arrange(RIGHT, buff=1.5)
        flow_group.move_to(UP * 0.5) # 放置在屏幕中上方

        # 生成框和箭头
        boxes = VGroup(*[get_box(t) for t in flow_group])

        arrows = VGroup()
        for i in range(len(boxes) - 1):
            arrow = Arrow(start=boxes[i].get_right(), end=boxes[i+1].get_left(), buff=0.1, color=GREY)
            arrows.add(arrow)

        # 动画展示流程
        self.play(FadeIn(flow_group), Create(boxes), run_time=1.5)
        self.play(GrowFromCenter(arrows), run_time=1)

        # ---------------------------------------------------------
        # 3. 关键结论对比 (Comparison Box)
        # ---------------------------------------------------------
        # 左侧:Adam
        adam_title = Text("多数场景首选", font="AR PL UKai CN", font_size=24, color=YELLOW)
        adam_content = Text("Adam 优化器", font="AR PL UKai CN", font_size=32, color=WHITE)
        adam_group = VGroup(adam_title, adam_content).arrange(DOWN, buff=0.2)

        # 右侧:SGD
        sgd_title = Text("简单模型(如线性回归)", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        sgd_content = Text("SGD 更高效", font="AR PL UKai CN", font_size=32, color=WHITE)
        sgd_group = VGroup(sgd_title, sgd_content).arrange(DOWN, buff=0.2)

        # 组合结论区域
        conclusion_content = VGroup(adam_group, sgd_group).arrange(RIGHT, buff=2.0)
        conclusion_content.next_to(boxes, DOWN, buff=1.5)

        # 结论外框
        conclusion_box = SurroundingRectangle(
            conclusion_content,
            color=GREEN,
            buff=0.4,
            corner_radius=0.1
        )
        conclusion_label = Text("关键结论", font="AR PL UKai CN", font_size=20, color=GREEN)
        conclusion_label.next_to(conclusion_box, UP, buff=0.1).align_to(conclusion_box, LEFT)

        # ---------------------------------------------------------
        # 4. 最终动画执行
        # ---------------------------------------------------------
        self.play(
            Create(conclusion_box),
            Write(conclusion_label),
            run_time=1
        )

        self.play(
            FadeIn(adam_group, shift=UP),
            FadeIn(sgd_group, shift=UP),
            run_time=1.5
        )

        # 稍微停顿
