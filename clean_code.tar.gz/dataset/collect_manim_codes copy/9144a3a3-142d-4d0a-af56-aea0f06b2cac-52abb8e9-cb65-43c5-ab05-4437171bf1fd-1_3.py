from manim import *
import numpy as np

class HighDimDataChallenge(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (根据模板)
        # ---------------------------------------------------------
        title = Text("高维图像数据的挑战:以猫狗分类为例",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 图像输入展示 (左侧)
        # ---------------------------------------------------------
        # 使用占位图像数组代表输入的猫/狗图像
        placeholder_array = np.ones((224, 224, 3), dtype=np.uint8) * 200
        input_image = ImageMobject(placeholder_array)
        input_image.height = 2.5
        input_image.to_edge(LEFT, buff=1.0).shift(UP * 0.5)

        # 图像维度标注
        dim_tex = MathTex(r"224 \times 224 \times 3", font_size=30, color=BLUE)
        dim_tex.next_to(input_image, DOWN, buff=0.2)

        pixel_info = Text("= 150,528 像素值", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        pixel_info.next_to(dim_tex, DOWN, buff=0.1)

        # ---------------------------------------------------------
        # 3. 全连接层结构示意 (中间到右侧)
        # ---------------------------------------------------------
        # 箭头表示展平和连接过程
        arrow = Arrow(start=LEFT, end=RIGHT, buff=0.1, color=WHITE)
        arrow.next_to(input_image, RIGHT, buff=0.8)

        process_text = Text("展平并全连接", font="AR PL UKai CN", font_size=20, color=YELLOW)
        process_text.next_to(arrow, UP, buff=0.1)

        # 隐藏层示意图
        hidden_layer_box = Rectangle(height=3.0, width=0.8, color=GREEN, fill_opacity=0.3)
        hidden_layer_box.next_to(arrow, RIGHT, buff=0.5)

        hidden_text = Text("隐藏层\n1000\n神经元", font="AR PL UKai CN", font_size=22, line_spacing=1.2)
        hidden_text.move_to(hidden_layer_box.get_center())

        # ---------------------------------------------------------
        # 4. 动画展示第一部分:结构
        # ---------------------------------------------------------
        self.play(
            FadeIn(input_image, shift=RIGHT),
            Write(dim_tex),
            run_time=1.0
        )
        self.play(Write(pixel_info), run_time=0.8)

        self.play(
            GrowArrow(arrow),
            FadeIn(process_text),
            Create(hidden_layer_box),
            Write(hidden_text),
            run_time=1.2
        )

        # ---------------------------------------------------------
        # 5. 参数量爆炸计算 (底部)
        # ---------------------------------------------------------
        # 这里的逻辑是:输入维度 * 隐藏层神经元数 = 权重矩阵大小

        calc_label = Text("参数量计算 (权重矩阵 W):", font="AR PL UKai CN", font_size=28, color=GREY_A)
        calc_label.move_to(LEFT * 3 + DOWN * 2.0)

        # 公式
        math_formula = MathTex(
            r"150,528", r"\times", r"1000", r"\approx", r"1.5 \times 10^8",
            font_size=36
        )
        math_formula.next_to(calc_label, RIGHT, buff=0.3)
        # 设置颜色区分不同部分
        math_formula[0].set_color(BLUE)  # 输入
        math_formula[2].set_color(GREEN) # 神经元

        # 结论文字
        result_text = Text("约 1.5 亿个参数!", font="AR PL UKai CN", font_size=36, color=RED)
        result_text.next_to(math_formula, DOWN, buff=0.4)
        result_text.align_to(math_formula, LEFT)

        # 强调框
        surround_rect = SurroundingRectangle(result_text, color=RED, buff=0.15)

        # ---------------------------------------------------------
        # 6. 动画展示第二部分:计算与结论
        # ---------------------------------------------------------
        self.play(Write(calc_label), run_time=0.8)
        self.play(
            Write(math_formula[0]),
            Write(math_formula[1]),
            Write(math_formula[2]),
            run_time=1.0
        )
        self.play(
            Write(math_formula[3]),
            Write(math_formula[4]),
            run_time=0.8
        )

        # 强调巨大的参数量
        self.play(
            FadeIn(result_text, scale=1.2),
            Create(surround_rect),
            run_time=1.0
        )
