from manim import *

class AgileCoreFramework(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("敏捷核心框架",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念引入
        # ---------------------------------------------------------
        intro_text = Text("敏捷不是一种具体方法，而是一套价值观和原则的集合",
                         font_size=24,
                         font="AR PL UKai CN",
                         color=LIGHT_GREY)
        intro_text.next_to(title_line, DOWN, buff=0.4)
        self.play(FadeIn(intro_text, shift=DOWN), run_time=1)

        # ---------------------------------------------------------
        # 3. 构建金字塔层次结构 (使用 SurroundingRectangle)
        # ---------------------------------------------------------
        # 数据结构：(层级名称, 描述详情, 颜色, 宽度系数)
        layers_data = [
            ("价值观层", "4大价值观:定义"什么更重要"", RED_D, 3.5),
            ("原则层", "12条原则:指导具体实践", ORANGE, 4.5),
            ("实践层", "Scrum、Kanban、XP等具体方法", TEAL_D, 5.5),
            ("文化层", "信任、透明、持续改进的文化", BLUE_D, 6.5),
        ]

        pyramid_group = VGroup()
        details_group = VGroup()

        # 初始位置参考点
        current_y = 1.5

        for name, detail, color, width_scale in layers_data:
            # 1. 创建层级名称文本
            layer_text = Text(name, font="AR PL UKai CN", font_size=24, color=WHITE)

            # 2. 使用 SurroundingRectangle 创建块状背景
            # 注意:这里通过调整 buff 来控制矩形的大小,模拟金字塔形状
            # 为了做成梯形效果比较复杂,这里使用不同宽度的矩形堆叠示意

            # 先创建一个占位的矩形框来确定大小
            base_rect = Rectangle(height=0.8, width=width_scale, color=color, fill_opacity=0.8, fill_color=color)
            # 将文本放到矩形中心
            layer_text.move_to(base_rect.get_center())

            # 组合成一个单元
            layer_block = VGroup(base_rect, layer_text)

            # 设置位置
            if len(pyramid_group) == 0:
                layer_block.move_to(UP * 0.5) # 第一层位置
            else:
                layer_block.next_to(pyramid_group[-1], DOWN, buff=0.1) # 后续层紧跟上一层

            pyramid_group.add(layer_block)

            # 3. 创建右侧详情说明
            # 箭头
            arrow = Arrow(start=LEFT, end=RIGHT, color=WHITE, buff=0.1).scale(0.5)
            arrow.next_to(layer_block, RIGHT, buff=0.2)

            # 详情文字
            detail_text = Text(detail, font="AR PL UKai CN", font_size=20, color=color)
            detail_text.next_to(arrow, RIGHT, buff=0.1)
            # 保持左对齐
            detail_text.align_to(arrow, LEFT).shift(RIGHT * 0.8)

            details_group.add(VGroup(arrow, detail_text))

        # 整体调整位置,确保居中且不遮挡标题
        full_content = VGroup(pyramid_group, details_group)
        full_content.move_to(ORIGIN).shift(DOWN * 0.5)

        # ---------------------------------------------------------
        # 4. 动画展示
        # ---------------------------------------------------------
        # 逐层显示:从上到下 (符合列表顺序)
        for i in range(len(layers_data)):
            block = pyramid_group[i]
            detail = details_group[i]

            self.play(
                FadeIn(block, shift=UP * 0.2),
                Write(detail),
                run_time=0.8
            )
            # 稍微停顿强调
            if i < len(layers_data) - 1:

        # ---------------------------------------------------------
        # 5. 总结框 (使用 SurroundingRectangle 强调整体)
        # ---------------------------------------------------------
        final_rect = SurroundingRectangle(pyramid_group, color=YELLOW, buff=0.1, stroke_width=2)
        self.play(Create(final_rect), run_time=1)
