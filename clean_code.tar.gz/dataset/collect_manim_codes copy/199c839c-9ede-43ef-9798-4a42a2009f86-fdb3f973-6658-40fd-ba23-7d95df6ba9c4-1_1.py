from manim import *

class DeterminantConcept(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("行列式的基本概念",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容展示:定义与记号
        # ---------------------------------------------------------
        # 定义文本
        def_text = Text("定义:行列式是赋予方阵的一个标量(数值)",
                       font="AR PL UKai CN", font_size=28, color=LIGHT_GREY)

        # 记号公式
        notation_tex = MathTex(r"\det(A)", r"=", r"|A|", font_size=36)

        # 组合定义部分
        def_group = VGroup(def_text, notation_tex).arrange(DOWN, buff=0.3)
        def_group.next_to(title_group, DOWN, buff=0.8)

        self.play(FadeIn(def_text, shift=UP))
        self.play(Write(notation_tex))

        # ---------------------------------------------------------
        # 3. 核心可视化:二阶行列式计算 (ad - bc)
        # ---------------------------------------------------------
        # 使用 MathTex 分块编写公式以便后续染色和连线
        # 索引参考:
        # 0: | matrix |
        # 1: =
        # 2: ad
        # 3: -
        # 4: bc
        formula = MathTex(
            r"\left| \begin{matrix} a & b \\ c & d \end{matrix} \right|",
            r"=",
            r"ad",
            r"-",
            r"bc",
            font_size=48
        )
        formula.next_to(def_group, DOWN, buff=1.0)

        # 强调主对角线 (ad) 和 副对角线 (bc)
        formula[2].set_color(GREEN) # ad
        formula[4].set_color(RED)   # bc

        self.play(Write(formula))

        # 添加交叉相乘的视觉辅助线
        # 获取矩阵部分的左上、右下、右上、左下坐标
        matrix_part = formula[0]

        # 简单的几何连线模拟交叉相乘
        # 主对角线箭头 (a -> d)
        arrow_main = Arrow(
            start=matrix_part.get_corner(UL) + RIGHT*0.2 + DOWN*0.2,
            end=matrix_part.get_corner(DR) + LEFT*0.2 + UP*0.2,
            color=GREEN, buff=0, stroke_width=3, tip_length=0.15
        )

        # 副对角线箭头 (b -> c)
        arrow_anti = Arrow(
            start=matrix_part.get_corner(UR) + LEFT*0.2 + DOWN*0.2,
            end=matrix_part.get_corner(DL) + RIGHT*0.2 + UP*0.2,
            color=RED, buff=0, stroke_width=3, tip_length=0.15
        )

        self.play(Create(arrow_main), run_time=0.5)
        self.play(Indicate(formula[2], color=GREEN, scale_factor=1.2)) # 强调结果 ad

        self.play(Create(arrow_anti), run_time=0.5)
        self.play(Indicate(formula[4], color=RED, scale_factor=1.2))   # 强调结果 bc

        # ---------------------------------------------------------
        # 4. 几何意义与总结
        # ---------------------------------------------------------
        geo_text = Text("几何意义:线性变换下的面积/体积缩放因子",
                       font="AR PL UKai CN", font_size=26, color=YELLOW)

        # 使用 SurroundingRectangle 框住几何意义
        geo_box = SurroundingRectangle(geo_text, color=BLUE, buff=0.15, stroke_width=2)
        geo_group = VGroup(geo_box, geo_text)

        # 放置在公式下方
        geo_group.next_to(formula, DOWN, buff=0.8)

        self.play(FadeIn(geo_group, shift=UP))

        # 最终停顿
