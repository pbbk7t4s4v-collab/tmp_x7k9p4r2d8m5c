from manim import *

class AbstractAlgebraHistory(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("抽象代数的体系化与发展",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 第一部分:体系化进程 (Euler -> Dedekind -> Abstraction)

        # 欧拉节点
        euler_text = Text("欧拉:整数与函数中的代数思想", font="AR PL UKai CN", font_size=26, color=BLUE_A)

        # 箭头
        arrow = Arrow(start=UP, end=DOWN, color=GREY, buff=0.1).scale(0.6)

        # 狄德金节点
        dedekind_text = Text("狄德金:提出"理想"等结构概念", font="AR PL UKai CN", font_size=26, color=BLUE_B)

        # 结果节点
        result_text = Text("代数系统严密化、抽象化", font="AR PL UKai CN", font_size=28, color=YELLOW)
        result_box = SurroundingRectangle(result_text, color=YELLOW, buff=0.15)
        result_group = VGroup(result_box, result_text)

        # 布局排列
        process_group = VGroup(euler_text, arrow, dedekind_text, result_group).arrange(DOWN, buff=0.4)
        process_group.move_to(UP * 0.5) # 整体上移

        # 3. 第二部分:常数问题

        # 分隔线
        sep_line = Line(LEFT, RIGHT, color=GREY_C).match_width(title_line).scale(1.2)
        sep_line.next_to(process_group, DOWN, buff=0.5)

        # 常数内容
        const_intro = Text("近现代关注常数的代数性质:", font="AR PL UKai CN", font_size=24, color=WHITE)

        # 数学符号
        math_consts = MathTex("e", "\\quad", "\\pi", font_size=48)
        math_consts.set_color_by_tex("e", GREEN)
        math_consts.set_color_by_tex("\\pi", RED)

        # 性质标注
        prop_text = Text("(超越性)", font="AR PL UKai CN", font_size=24, color=ORANGE)

        # 底部组合布局
        bottom_row = VGroup(const_intro, math_consts, prop_text).arrange(RIGHT, buff=0.3)
        bottom_row.next_to(sep_line, DOWN, buff=0.4)

        # 4. 动画展示流程

        # 展示体系化流程
        self.play(FadeIn(euler_text, shift=DOWN))
        self.play(Create(arrow))
        self.play(FadeIn(dedekind_text, shift=DOWN))
        self.play(
            Create(result_box),
            Write(result_text)
        )

        # 展示常数部分
        self.play(Create(sep_line))
        self.play(
            FadeIn(const_intro),
            Write(math_consts),
            FadeIn(prop_text, shift=LEFT)
        )
