from manim import *

class ConservationDerivation(Scene):
    def construct(self):

        # 1. Standardized Title Template
        title = Text("Quantity Change & Flux in Domain D",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Visualizing the Domain (Left Side)
        # Create an arbitrary smooth domain D
        domain = Circle(radius=1.8, color=BLUE_C, fill_opacity=0.2)
        domain.stretch(1.2, dim=0) # Make it slightly elliptical
        domain.stretch(0.8, dim=1)
        domain.shift(LEFT * 3.5 + DOWN * 0.5)

        label_D = MathTex("D", font_size=40, color=BLUE).move_to(domain.get_center())
        label_boundary = MathTex(r"\partial D", font_size=30, color=BLUE_A)
        label_boundary.next_to(domain, UP, buff=0.1)

        # Visualizing Vectors on the boundary
        # Point on the boundary
        p_boundary = domain.point_at_angle(30 * DEGREES)

        # Normal vector (Outward)
        vec_n = Arrow(start=p_boundary, end=p_boundary + np.array([0.8, 0.4, 0]), color=YELLOW, buff=0)
        label_n = MathTex(r"\vec{n}", font_size=28, color=YELLOW).next_to(vec_n.get_end(), UP, buff=0.1)

        # Flux vector (Arbitrary direction)
        vec_F = Arrow(start=p_boundary, end=p_boundary + np.array([0.8, -0.2, 0]), color=RED, buff=0)
        label_F = MathTex(r"\vec{F}", font_size=28, color=RED).next_to(vec_F.get_end(), RIGHT, buff=0.1)

        # Grouping visuals
        visuals = VGroup(domain, label_D, label_boundary, vec_n, label_n, vec_F, label_F)

        # 3. Equations (Right Side)
        # Equation 1: Quantity Increase
        text_q1 = Text("Increase in Quantity:", font_size=24, color=WHITE).to_edge(RIGHT, buff=2.0)
        text_q1.shift(UP * 1.5)

        eq1 = MathTex(
            r"Q_1 = \int_D (u(t_2, x) - u(t_1, x)) \, dx",
            font_size=32
        )
        eq1.next_to(text_q1, DOWN, buff=0.2)
        eq1.align_to(text_q1, LEFT)

        # Equation 2: Inflow
        text_q2 = Text("Inflow via Boundary:", font_size=24, color=WHITE)
        text_q2.next_to(eq1, DOWN, buff=1.0)
        text_q2.align_to(text_q1, LEFT)

        # Note: Using t_1 to t_2 for logical consistency with time period [t1, t2]
        eq2 = MathTex(
            r"Q_2 = \int_{t_1}^{t_2} \int_{\partial D} \vec{F} \cdot (-\vec{n}) \, ds \, dt",
            font_size=32
        )
        eq2.next_to(text_q2, DOWN, buff=0.2)
        eq2.align_to(text_q2, LEFT)

        # Highlight box for Q2 (Flux definition is key)
        box_q2 = SurroundingRectangle(eq2, color=ORANGE, buff=0.15)

        # 4. Animations
        # Show Geometry
        self.play(FadeIn(domain), Write(label_D), run_time=1.0)
        self.play(Write(label_boundary), run_time=0.5)

        # Show Vectors
        self.play(GrowArrow(vec_n), FadeIn(label_n), run_time=0.8)
        self.play(GrowArrow(vec_F), FadeIn(label_F), run_time=0.8)

        # Show Equations
        self.play(FadeIn(text_q1, shift=LEFT), Write(eq1), run_time=1.5)
        self.play(FadeIn(text_q2, shift=LEFT), Write(eq2), run_time=1.5)

        # Highlight
        self.play(Create(box_q2), run_time=1.0)
