from manim import *

class HeapPriorityQueue(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("堆的应用场景:优先队列",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 概念文本 (左侧布局)
        # ---------------------------------------------------------
        # 主题文本
        topic_text = Text("优先队列 (Priority Queue)", font_size=28, font="AR PL UKai CN", color=BLUE)
        topic_text.to_edge(LEFT, buff=1).shift(UP * 1)

        # 概念描述
        concept_text = Text(
            "概念:元素带有优先级,\n优先级最高的元素最先出队。",
            font_size=24,
            font="AR PL UKai CN",
            line_spacing=0.8,
            color=GRAY_B
        )
        concept_text.next_to(topic_text, DOWN, buff=0.3, aligned_edge=LEFT)

        self.play(FadeIn(topic_text), Write(concept_text))

        # ---------------------------------------------------------
        # 3. 可视化演示 (右侧布局)
        # ---------------------------------------------------------
        # 创建队列容器示意图
        queue_box = Rectangle(height=1.2, width=4, color=WHITE)
        queue_box.to_edge(RIGHT, buff=1).shift(UP * 0.5)

        queue_label = Text("队列示意", font_size=20, font="AR PL UKai CN", color=GRAY)
        queue_label.next_to(queue_box, UP, buff=0.1)

        # 创建带有优先级的元素 (圆圈+数字)
        # 元素1: 优先级 10
        c1 = Circle(radius=0.3, color=WHITE, fill_opacity=0.3)
        t1 = Text("10", font_size=20).move_to(c1.get_center())
        item1 = VGroup(c1, t1)

        # 元素2: 优先级 99 (最高,红色高亮)
        c2 = Circle(radius=0.35, color=RED, fill_opacity=0.8)
        t2 = Text("99", font_size=24, weight=BOLD).move_to(c2.get_center())
        item2 = VGroup(c2, t2)

        # 元素3: 优先级 20
        c3 = Circle(radius=0.3, color=WHITE, fill_opacity=0.3)
        t3 = Text("20", font_size=20).move_to(c3.get_center())
        item3 = VGroup(c3, t3)

        # 排列元素
        items = VGroup(item1, item3, item2).arrange(RIGHT, buff=0.5)
        items.move_to(queue_box.get_center())

        self.play(Create(queue_box), FadeIn(queue_label))
        self.play(FadeIn(items, shift=LEFT))

        # 动画:高优先级元素"插队"或直接出队
        # 这里演示直接从中间飞出,表示优先处理
        self.play(
            item2.animate.shift(UP * 1.5),
            run_time=1
        )

        out_text = Text("优先出队!", font_size=20, font="AR PL UKai CN", color=RED)
        out_text.next_to(item2, UP, buff=0.1)
        self.play(FadeIn(out_text))

        # ---------------------------------------------------------
        # 4. 堆的联系与效率 (底部)
        # ---------------------------------------------------------
        # 连接文本
        connection_title = Text("为什么使用堆 (Heap)?", font_size=26, font="AR PL UKai CN", color=GOLD)
        connection_title.next_to(concept_text, DOWN, buff=1.5).align_to(topic_text, LEFT)

        # 效率说明
        eff_label = Text("插入和删除操作效率最高:", font_size=24, font="AR PL UKai CN", color=WHITE)
        eff_math = MathTex(r"O(\log n)", color=GREEN)

        eff_group = VGroup(eff_label, eff_math).arrange(RIGHT)
        eff_group.next_to(connection_title, DOWN, buff=0.3, aligned_edge=LEFT)

        # 强调框
        rect = SurroundingRectangle(eff_group, color=GREEN, buff=0.15)

        self.play(Write(connection_title))
        self.play(FadeIn(eff_group))
        self.play(Create(rect))
