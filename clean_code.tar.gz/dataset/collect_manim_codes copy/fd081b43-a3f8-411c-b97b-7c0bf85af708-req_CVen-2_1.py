from manim import *

class ImageFormationAndPixels(Scene):
    def construct(self):

        # 1. Title Setup (Template)
        title = Text("Image Formation & Pixel Representation",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # 2. Left Side: Continuous World
        # Represents the real world object before digitization
        real_circle = Circle(radius=1.2, color=BLUE, fill_opacity=0.5)
        real_label = Text("Continuous Scene", font_size=24, color=BLUE_B)
        real_label.next_to(real_circle, DOWN, buff=0.2)

        left_group = VGroup(real_circle, real_label)
        left_group.to_edge(LEFT, buff=1.5)
        left_group.shift(DOWN * 0.5)

        self.play(FadeIn(left_group, shift=RIGHT))

        # 3. Transition: Sampling
        arrow = Arrow(start=LEFT, end=RIGHT, color=GREY)
        arrow.next_to(real_circle, RIGHT, buff=0.5)
        sampling_text = Text("Sampling & Quantization", font_size=20, color=GREY)
        sampling_text.next_to(arrow, UP, buff=0.1)

        self.play(Create(arrow), Write(sampling_text))

        # 4. Right Side: Discrete Grid (Pixels)
        # Create a 6x6 grid to represent pixels
        grid_size = 6
        square_size = 0.5
        grid = VGroup()

        # Logic to simulate rasterizing the circle
        for i in range(grid_size):
            for j in range(grid_size):
                # Calculate distance from center relative to grid indices
                x = (j - grid_size/2 + 0.5)
                y = (grid_size/2 - i - 0.5)
                dist = (x**2 + y**2)**0.5

                square = Square(side_length=square_size)
                square.set_stroke(width=1, color=WHITE)

                # If inside "circle", color it (simulating pixel value)
                if dist < 2.0:
                    intensity = 0.8  # Simulating high intensity
                    square.set_fill(color=BLUE, opacity=intensity)
                else:
                    square.set_fill(color=BLACK, opacity=0.0)

                grid.add(square)

        grid.arrange_in_grid(rows=grid_size, cols=grid_size, buff=0)
        grid.next_to(arrow, RIGHT, buff=0.5)

        grid_label = Text("Digital Image (Pixels)", font_size=24, color=WHITE)
        grid_label.next_to(grid, UP, buff=0.2)

        self.play(
            FadeIn(grid_label, shift=DOWN),
            Create(grid, lag_ratio=0.05, run_time=2)
        )

        # 5. Highlight a specific Pixel and show Matrix notation
        # Select a pixel near the center
        target_pixel_index = 2 * grid_size + 3  # Arbitrary index inside the circle shape
        target_pixel = grid[target_pixel_index]

        highlight_rect = SurroundingRectangle(target_pixel, color=YELLOW, buff=0.05)

        # Info box for the pixel
        pixel_info = MathTex(r"I(x, y) = 204", font_size=30, color=YELLOW)
        pixel_info.next_to(grid, DOWN, buff=0.5)

        matrix_notation = MathTex(r"I \in \mathbb{R}^{H \times W}", font_size=30)
        matrix_notation.next_to(pixel_info, DOWN, buff=0.2)

        self.play(Create(highlight_rect))
        self.play(Write(pixel_info))
        self.play(Write(matrix_notation))

        # 6. Final explanation text regarding range
        range_text = Text("Pixel Value: [0, 255]", font_size=24, color=GREY_A)
        range_text.next_to(matrix_notation, DOWN, buff=0.2)

        self.play(FadeIn(range_text))
