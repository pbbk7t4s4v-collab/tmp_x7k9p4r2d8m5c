from manim import *

class SolderingOverview(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("焊接基础与PCB操作规范",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心内容布局
        # 中心核心概念
        center_text = Text("焊接实践基础", font="AR PL UKai CN", font_size=36, color=YELLOW)
        center_rect = SurroundingRectangle(center_text, color=YELLOW, buff=0.3, corner_radius=0.2)
        center_group = VGroup(center_rect, center_text).move_to(ORIGIN).shift(DOWN * 0.5)

        # 四个分支内容
        # 分支1: 电烙铁使用 (左上)
        topic1_text = Text("1. 电烙铁使用", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        topic1_box = SurroundingRectangle(topic1_text, color=BLUE, buff=0.2)
        topic1_group = VGroup(topic1_box, topic1_text)
        topic1_group.move_to(center_group.get_center() + UP * 2 + LEFT * 3.5)

        # 分支2: PCB结构认知 (右上)
        topic2_text = Text("2. PCB结构认知", font="AR PL UKai CN", font_size=28, color=TEAL_A)
        topic2_box = SurroundingRectangle(topic2_text, color=TEAL, buff=0.2)
        topic2_group = VGroup(topic2_box, topic2_text)
        topic2_group.move_to(center_group.get_center() + UP * 2 + RIGHT * 3.5)

        # 分支3: 标准焊接流程 (左下)
        topic3_text = Text("3. 标准焊接流程", font="AR PL UKai CN", font_size=28, color=GREEN_A)
        topic3_box = SurroundingRectangle(topic3_text, color=GREEN, buff=0.2)
        topic3_group = VGroup(topic3_box, topic3_text)
        topic3_group.move_to(center_group.get_center() + DOWN * 2 + LEFT * 3.5)

        # 分支4: 常见问题解决 (右下)
        topic4_text = Text("4. 常见问题解决", font="AR PL UKai CN", font_size=28, color=RED_A)
        topic4_box = SurroundingRectangle(topic4_text, color=RED, buff=0.2)
        topic4_group = VGroup(topic4_box, topic4_text)
        topic4_group.move_to(center_group.get_center() + DOWN * 2 + RIGHT * 3.5)

        # 连接箭头
        arrow1 = Arrow(center_rect.get_top(), topic1_box.get_right(), color=BLUE, buff=0.1, stroke_width=3)
        arrow2 = Arrow(center_rect.get_top(), topic2_box.get_left(), color=TEAL, buff=0.1, stroke_width=3)
        arrow3 = Arrow(center_rect.get_bottom(), topic3_box.get_right(), color=GREEN, buff=0.1, stroke_width=3)
        arrow4 = Arrow(center_rect.get_bottom(), topic4_box.get_left(), color=RED, buff=0.1, stroke_width=3)

        # 3. 动画演示流程
        # 显示中心
        self.play(FadeIn(center_group, shift=UP), run_time=1)

        # 依次显示分支
        # 左上
        self.play(GrowArrow(arrow1), FadeIn(topic1_group, shift=LEFT), run_time=0.8)
        # 右上
        self.play(GrowArrow(arrow2), FadeIn(topic2_group, shift=RIGHT), run_time=0.8)
        # 左下
        self.play(GrowArrow(arrow3), FadeIn(topic3_group, shift=LEFT), run_time=0.8)
        # 右下
        self.play(GrowArrow(arrow4), FadeIn(topic4_group, shift=RIGHT), run_time=0.8)

        # 4. 总结强调
        # 简单的闪烁效果强调这是基础
        self.play(
            Indicate(center_rect, scale_factor=1.1, color=WHITE),
            run_time=1.5
        )
