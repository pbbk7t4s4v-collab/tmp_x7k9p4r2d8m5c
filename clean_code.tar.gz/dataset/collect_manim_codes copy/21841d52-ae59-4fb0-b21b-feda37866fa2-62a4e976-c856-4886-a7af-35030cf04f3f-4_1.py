from manim import *

class ODEClassicalStage(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("常微分方程经典阶段：求解与挑战",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 第一部分：求解流程 (顶部区域)
        # 展示从方程到通解再到物理意义的逻辑流
        eq_tex = MathTex(r"F(x, y, y') = 0", color=BLUE_B)
        arrow1 = Arrow(LEFT, RIGHT, color=GREY, buff=0.1).scale(0.6)
        sol_tex = MathTex(r"y = \varphi(x, C)", color=GREEN_B)
        arrow2 = Arrow(LEFT, RIGHT, color=GREY, buff=0.1).scale(0.6)
        meaning_text = Text("物理性质预测", font="AR PL UKai CN", font_size=24, color=YELLOW)

        flow_group = VGroup(eq_tex, arrow1, sol_tex, arrow2, meaning_text)
        flow_group.arrange(RIGHT, buff=0.4)
        flow_group.next_to(title_line, DOWN, buff=0.8)

        self.play(FadeIn(flow_group, shift=UP))

        # 3. 第二部分：核心困难 (中部区域)
        # 使用方框强调"无通用解法"这一核心痛点
        difficulty_label = Text("核心困难", font="AR PL UKai CN", font_size=26, color=RED_A)
        difficulty_desc = Text("不存在普遍适用的通用解法", font="AR PL UKai CN", font_size=30, color=WHITE)

        difficulty_group = VGroup(difficulty_label, difficulty_desc).arrange(DOWN, buff=0.2)

        # 使用SurroundingRectangle强调
        diff_box = SurroundingRectangle(difficulty_group, color=RED, buff=0.3)

        full_difficulty_group = VGroup(difficulty_group, diff_box)
        full_difficulty_group.next_to(flow_group, DOWN, buff=0.8)

        self.play(
            Write(difficulty_label),
            Write(difficulty_desc),
            Create(diff_box)
        )

        # 4. 第三部分：应对策略与代表人物 (底部区域)
        # 展示当时的数学家转向研究特定类型的方程
        strategy_text = Text("应对策略：聚焦特定类型的微分方程解法",
                           font="AR PL UKai CN", font_size=24, color=BLUE_C)
        strategy_text.next_to(full_difficulty_group, DOWN, buff=0.6)

        # 代表人物列表
        names = ["Newton", "Leibniz", "Bernoulli", "Riccatti", "Euler"]
        names_group = VGroup()
        for name in names:
            names_group.add(Text(name, font="AR PL UKai CN", font_size=22, color=GREY_B))

        names_group.arrange(RIGHT, buff=0.6)
        names_group.next_to(strategy_text, DOWN, buff=0.3)

        self.play(FadeIn(strategy_text, shift=UP))
        self.play(
            AnimationGroup(
                *[FadeIn(n, scale=0.8) for n in names_group],
                lag_ratio=0.1
            )
        )
