from manim import *

class BorrowingAndContact(Scene):
    def construct(self):

        # 1. Title Configuration (Standard Template)
        title = Text("Language Change: Borrowing and Contact",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # Add bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Combine title elements
        title_group = VGroup(title, title_line)

        # Title Animation
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Visualizing Languages as Distinct Spaces
        # Left Language (Source)
        circle_a = Circle(radius=1.2, color=BLUE, fill_opacity=0.2)
        circle_a.shift(LEFT * 3)
        label_a = Text("Language A", font_size=24).next_to(circle_a, UP)

        # Right Language (Target)
        circle_b = Circle(radius=1.2, color=GREEN, fill_opacity=0.2)
        circle_b.shift(RIGHT * 3)
        label_b = Text("Language B", font_size=24).next_to(circle_b, UP)

        group_languages = VGroup(circle_a, label_a, circle_b, label_b)
        self.play(FadeIn(group_languages, shift=UP))

        # 3. Visualizing Contact
        # Arrow representing interaction
        contact_arrow = DoubleArrow(
            circle_a.get_right(),
            circle_b.get_left(),
            buff=0.2,
            color=YELLOW
        )
        contact_label = Text("Contact", font_size=20, color=YELLOW).next_to(contact_arrow, UP, buff=0.1)

        self.play(
            GrowFromCenter(contact_arrow),
            FadeIn(contact_label)
        )

        # 4. Visualizing Borrowing (Transfer of a feature)
        # Create a "feature" (e.g., a word) inside Language A
        feature = Text("Loanword", font_size=20, weight=BOLD)
        feature.move_to(circle_a.get_center())

        self.play(Write(feature))

        # Animate the transfer from A to B
        self.play(
            feature.animate.move_to(circle_b.get_center()),
            run_time=2,
            rate_func=smooth
        )

        # Highlight the borrowed element in the new environment
        highlight_rect = SurroundingRectangle(feature, color=WHITE, buff=0.15)
        borrowing_text = Text("Borrowing Occurred", font_size=20).next_to(highlight_rect, DOWN)

        self.play(
            Create(highlight_rect),
            FadeIn(borrowing_text, shift=DOWN)
        )

        # 5. Key Concepts Summary
        summary_box = VGroup(
            Text("• Contact: Social interaction between speakers", font_size=24),
            Text("• Borrowing: Transfer of lexical/structural items", font_size=24)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)

        summary_box.to_edge(DOWN, buff=0.8)

        self.play(Write(summary_box))
