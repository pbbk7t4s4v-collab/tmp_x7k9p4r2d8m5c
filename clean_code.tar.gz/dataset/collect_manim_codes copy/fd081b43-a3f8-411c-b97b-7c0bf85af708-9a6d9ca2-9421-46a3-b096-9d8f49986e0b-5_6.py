from manim import *

class GradientApplications(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("梯度的正交性：实际意义与应用",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("37", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 右侧可视化：等高线与梯度 (核心概念展示)
        # 创建等高线 (椭圆)
        ellipse_1 = Ellipse(width=3, height=2, color=BLUE_A)
        ellipse_2 = Ellipse(width=4, height=3, color=BLUE_C)
        ellipse_3 = Ellipse(width=5, height=4, color=BLUE_E)
        contours = VGroup(ellipse_1, ellipse_2, ellipse_3)

        # 梯度向量 (垂直于切线)
        # 在中间椭圆上选一点
        point_angle = PI / 4
        point_on_curve = ellipse_2.point_at_angle(point_angle)

        # 简单的切线方向近似 (用于画直角符号)
        tangent_vector = rotate_vector(UP, point_angle) # 仅示意
        # 梯度方向 (从中心向外)
        gradient_vector = point_on_curve - ellipse_2.get_center()
        gradient_arrow = Arrow(start=point_on_curve, end=point_on_curve + normalize(gradient_vector) * 1.5, color=YELLOW, buff=0)

        # 标注
        label_contour = MathTex(r"f(x)=c", color=BLUE).next_to(ellipse_3, DOWN, buff=0.1)
        label_grad = MathTex(r"\nabla f", color=YELLOW).next_to(gradient_arrow.get_end(), RIGHT, buff=0.1)

        # 直角标记
        # 为了几何准确性，这里做一个简单的垂直线段示意正交
        line_tangent = Line(LEFT, RIGHT).set_length(1).rotate(35*DEGREES).move_to(point_on_curve) # 近似切线
        right_angle = RightAngle(line_tangent, gradient_arrow, length=0.2, quadrant=(-1,1))

        visual_group = VGroup(contours, gradient_arrow, label_contour, label_grad, right_angle)
        visual_group.scale(0.8).to_edge(RIGHT, buff=1.0).shift(DOWN*0.5)

        # 3. 左侧文字内容 (应用列表)
        # 使用 Text 确保中文字体正确
        def create_list_item(text_str):
            dot = Dot(color=ORANGE).scale(0.8)
            text = Text(text_str, font="AR PL UKai CN", font_size=24, color=WHITE)
            # 避免对齐参数报错，使用 VGroup 排版
            item = VGroup(dot, text).arrange(RIGHT, buff=0.2, aligned_edge=LEFT)
            return item

        item1 = create_list_item("优化问题：梯度下降寻找最小值")
        item2 = create_list_item("物理应用：热流方向垂直等温线")
        item3 = create_list_item("地形分析：最陡上升垂直等高线")
        item4 = create_list_item("图像处理：利用梯度识别边缘")

        text_group = VGroup(item1, item2, item3, item4)
        text_group.arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        text_group.next_to(visual_group, LEFT, buff=1.0).shift(LEFT * 0.5)

        # 4. 强调框
        rect = SurroundingRectangle(visual_group, color=WHITE, buff=0.2, stroke_width=1)
        rect_label = Text("几何直观", font="AR PL UKai CN", font_size=20, color=GRAY).next_to(rect, DOWN)

        # 5. 动画流程
        # 步骤 1: 显示核心几何概念
        self.play(Create(contours), run_time=1.5)
        self.play(GrowArrow(gradient_arrow), FadeIn(label_grad), FadeIn(label_contour))
        self.play(Create(right_angle), run_time=0.5)
        self.play(Create(rect), FadeIn(rect_label))

        # 步骤 2: 逐条展示应用意义
        for item in text_group:
            self.play(
                FadeIn(item[0], scale=0.5), # Dot
                Write(item[1]),             # Text
                run_time=0.8
            )
