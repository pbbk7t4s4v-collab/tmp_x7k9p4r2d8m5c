from manim import *

class TrainingLevelImprovements(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (符合模板要求)
        # ---------------------------------------------------------
        title = Text("训练层面:多偏好与多解性",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("24", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局 - 分左右两部分展示两个核心概念
        # ---------------------------------------------------------

        # --- 左侧:多偏好奖励模型 ---
        # 概念文本
        text_preference = Text("1. 多偏好奖励模型", font_size=26, font="AR PL UKai CN", color=BLUE_B)

        # 可视化:一个模型输出多个维度的评分
        rm_box = RoundedRectangle(height=1.2, width=1.8, corner_radius=0.2, color=BLUE, fill_opacity=0.2)
        rm_text = Text("奖励\n模型", font_size=20, font="AR PL UKai CN", color=WHITE).move_to(rm_box)
        rm_group = VGroup(rm_box, rm_text)

        # 多个偏好维度箭头
        pref_arrows = VGroup()
        pref_labels = VGroup()
        pref_names = ["有用性", "安全性", "多样性"]
        pref_colors = [GREEN, YELLOW, RED_C]

        for i, (name, col) in enumerate(zip(pref_names, pref_colors)):
            # 计算箭头位置:从盒子右侧出发,向右散开
            start = rm_box.get_right()
            end = start + RIGHT * 1.5 + UP * (0.8 - i * 0.8)
            arrow = Arrow(start, end, buff=0.1, color=col, stroke_width=3, max_tip_length_to_length_ratio=0.2)
            label = Text(name, font_size=18, font="AR PL UKai CN", color=col).next_to(arrow, RIGHT, buff=0.1)
            pref_arrows.add(arrow)
            pref_labels.add(label)

        vis_preference = VGroup(rm_group, pref_arrows, pref_labels).scale(0.9)

        # 组合左侧内容
        group_left = VGroup(text_preference, vis_preference).arrange(DOWN, buff=0.5)

        # --- 右侧:多解性 vs 单一最佳 ---
        # 概念文本
        text_plurality = Text("2. 支持"多解性"而非"单一最佳"", font_size=26, font="AR PL UKai CN", color=BLUE_B)

        # 可视化:一个输入对应多个有效输出
        input_dot = Dot(color=WHITE, radius=0.1)
        input_label = Text("输入", font_size=16, font="AR PL UKai CN").next_to(input_dot, LEFT, buff=0.1)

        # 输出节点
        output_dots = VGroup()
        output_paths = VGroup()
        valid_marks = VGroup()

        positions = [UP * 0.8, ORIGIN, DOWN * 0.8]
        colors = [TEAL, TEAL, TEAL]

        for pos, col in zip(positions, colors):
            dot = Dot(color=col).move_to(RIGHT * 2 + pos)
            path = CurvedArrow(input_dot.get_center(), dot.get_center(), angle=0, color=GREY_B)
            # 添加对勾表示都是合理的解
            mark = MathTex(r"\checkmark", color=GREEN).scale(0.6).next_to(dot, RIGHT, buff=0.1)

            output_dots.add(dot)
            output_paths.add(path)
            valid_marks.add(mark)

        vis_plurality = VGroup(input_dot, input_label, output_dots, output_paths, valid_marks).scale(0.9)

        # 组合右侧内容
        group_right = VGroup(text_plurality, vis_plurality).arrange(DOWN, buff=0.5)

        # ---------------------------------------------------------
        # 3. 整体布局与动画执行
        # ---------------------------------------------------------

        # 将左右两组内容并排,居中放置在标题下方
        content_group = VGroup(group_left, group_right).arrange(RIGHT, buff=1.0)
        content_group.next_to(title_line, DOWN, buff=0.8)

        # 左侧动画
        self.play(FadeIn(text_preference, shift=UP))
        self.play(Create(rm_box), Write(rm_text))
        self.play(
            LaggedStart(
                *[AnimationGroup(GrowArrow(a), FadeIn(l)) for a, l in zip(pref_arrows, pref_labels)],
                lag_ratio=0.3
            )
        )

        # 右侧动画
        self.play(FadeIn(text_plurality, shift=UP))
        self.play(Create(input_dot), Write(input_label))
        self.play(Create(output_paths), Create(output_dots))
        self.play(Write(valid_marks, run_time=0.8))

        # 强调框
        surround_rect = SurroundingRectangle(content_group, color=YELLOW, buff=0.2, stroke_width=2)
        self.play(Create(surround_rect))
