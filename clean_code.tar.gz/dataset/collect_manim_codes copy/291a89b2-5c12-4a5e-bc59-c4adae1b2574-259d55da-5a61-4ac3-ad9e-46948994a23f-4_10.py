from manim import *

class DataPrivacyShift(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("数据隐私权的范式转型",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("53", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局内容:左右对比结构
        # 左侧:传统范式
        left_title = Text("传统范式", font="AR PL UKai CN", font_size=28, color=BLUE)
        left_content = Text("知情同意\n个人控制", font="AR PL UKai CN", font_size=24, color=WHITE)
        left_group = VGroup(left_title, left_content).arrange(DOWN, buff=0.3)
        left_group.shift(LEFT * 4 + UP * 0.5)

        # 右侧:新范式
        right_title = Text("新范式", font="AR PL UKai CN", font_size=28, color=GREEN)
        right_content = Text("数据最小化\n目的限制", font="AR PL UKai CN", font_size=24, color=WHITE)
        right_group = VGroup(right_title, right_content).arrange(DOWN, buff=0.3)
        right_group.shift(RIGHT * 4 + UP * 0.5)

        # 中间:转变原因(聚合与推断)
        arrow = Arrow(start=LEFT, end=RIGHT, color=YELLOW).match_width(Line(LEFT*2, RIGHT*2))
        arrow.next_to(left_group, RIGHT, buff=0.5)

        cause_text = Text("挑战:数据聚合与推断", font="AR PL UKai CN", font_size=20, color=YELLOW)
        cause_text.next_to(arrow, UP, buff=0.1)

        # 3. 动画展示对比
        self.play(FadeIn(left_group, shift=RIGHT))
        self.play(GrowArrow(arrow), Write(cause_text))
        self.play(FadeIn(right_group, shift=LEFT))

        # 4. 可视化:数据聚合导致隐私泄露
        # 创建三个看似无害的小数据点
        dot1 = Dot(color=BLUE_B).move_to(arrow.get_center() + DOWN * 0.5 + LEFT * 1)
        dot2 = Dot(color=BLUE_B).move_to(arrow.get_center() + DOWN * 0.5)
        dot3 = Dot(color=BLUE_B).move_to(arrow.get_center() + DOWN * 0.5 + RIGHT * 1)

        dots = VGroup(dot1, dot2, dot3)

        # 标签:无害数据
        safe_label = Text("分散无害", font="AR PL UKai CN", font_size=16, color=BLUE_B)
        safe_label.next_to(dots, DOWN, buff=0.1)

        self.play(FadeIn(dots), FadeIn(safe_label))

        # 聚合动画:点汇聚并变红
        target_point = arrow.get_center() + DOWN * 0.5
        sensitive_dot = Dot(color=RED, radius=0.2).move_to(target_point)
        sensitive_label = Text("敏感隐私", font="AR PL UKai CN", font_size=16, color=RED)
        sensitive_label.next_to(sensitive_dot, DOWN, buff=0.1)

        self.play(
            dot1.animate.move_to(target_point),
            dot3.animate.move_to(target_point),
            FadeOut(safe_label),
            run_time=1.0
        )
        self.play(
            Transform(dots, sensitive_dot),
            FadeIn(sensitive_label),
            run_time=0.5
        )

        # 5. 底部难点强调:关系性产物
        bottom_text = Text("难点:数据是关系性产物(如社交网络),个体难以完全控制",
                          font="AR PL UKai CN", font_size=22, color=ORANGE)
        bottom_text.to_edge(DOWN, buff=1.0)

        rect = SurroundingRectangle(bottom_text, color=ORANGE, buff=0.2)

        self.play(Write(bottom_text), Create(rect))
