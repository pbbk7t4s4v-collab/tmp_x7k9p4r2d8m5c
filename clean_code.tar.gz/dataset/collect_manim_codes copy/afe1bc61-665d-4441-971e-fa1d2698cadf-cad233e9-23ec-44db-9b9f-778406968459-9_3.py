from manim import *

class ProjectSuccessIndicators(Scene):
    def construct(self):

        # 1. 标题部分 (严格遵守模板)
        title = Text("项目成功的标志",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("40", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 使用 t2c (text to color) 参数来高亮 Markdown 中的重点词汇

        # 左侧:核心约束 (时间、成本、质量、范围)
        text_font = "AR PL UKai CN"
        text_size = 24

        item1 = Text("1. 在规定时间内完成", font=text_font, font_size=text_size,
                     t2c={"时间内": YELLOW})
        item2 = Text("2. 成本控制在预算之内", font=text_font, font_size=text_size,
                     t2c={"成本控制": YELLOW})
        item3 = Text("3. 功能特性达到质量要求", font=text_font, font_size=text_size,
                     t2c={"质量": YELLOW})
        item4 = Text("4. 项目范围变化最小/可控", font=text_font, font_size=text_size,
                     t2c={"范围": YELLOW})

        left_content = VGroup(item1, item2, item3, item4).arrange(DOWN, buff=0.5, aligned_edge=LEFT)

        # 右侧:组织与验收 (验收、流程、文化)
        item5 = Text("5. 通过客户或用户的验收", font=text_font, font_size=text_size,
                     t2c={"验收": YELLOW})
        item6 = Text("6. 不干扰主要工作流程", font=text_font, font_size=text_size,
                     t2c={"工作流程": YELLOW})
        item7 = Text("7. 维护或改进公司文化", font=text_font, font_size=text_size,
                     t2c={"公司文化": YELLOW})

        right_content = VGroup(item5, item6, item7).arrange(DOWN, buff=0.5, aligned_edge=LEFT)

        # 3. 容器与布局
        # 创建两个矩形框来区分不同类别的标志

        # 左侧框
        left_box = SurroundingRectangle(left_content, color=BLUE, buff=0.3)
        left_label = Text("核心约束指标", font=text_font, font_size=20, color=BLUE)
        left_label.next_to(left_box, UP)
        left_group = VGroup(left_label, left_box, left_content)

        # 右侧框
        right_box = SurroundingRectangle(right_content, color=GREEN, buff=0.3)
        right_label = Text("组织与验收指标", font=text_font, font_size=20, color=GREEN)
        right_label.next_to(right_box, UP)
        right_group = VGroup(right_label, right_box, right_content)

        # 整体排列
        main_group = VGroup(left_group, right_group).arrange(RIGHT, buff=1.0)
        main_group.move_to(ORIGIN).shift(DOWN * 0.5) # 稍微下移,避开标题

        # 4. 动画展示
        # 渐入左侧
        self.play(
            Create(left_box),
            FadeIn(left_label, shift=DOWN),
            run_time=1
        )
        self.play(Write(left_content), run_time=2.5)

        # 渐入右侧
        self.play(
            Create(right_box),
            FadeIn(right_label, shift=DOWN),
            run_time=1
        )
        self.play(Write(right_content), run_time=2)

        # 最后的停顿
