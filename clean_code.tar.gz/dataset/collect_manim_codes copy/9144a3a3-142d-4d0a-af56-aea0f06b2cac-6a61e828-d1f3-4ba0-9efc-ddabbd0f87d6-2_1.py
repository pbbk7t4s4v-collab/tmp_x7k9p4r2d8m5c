from manim import *

class CVCoreQuestion(Scene):
    def construct(self):

        # 1. 标题设置 (模板代码)
        title = Text("计算机视觉的核心挑战",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心问题文本
        question_text = Text("如何让模型识别的特征不受干扰？",
                           font="AR PL UKai CN",
                           font_size=28,
                           color=BLUE_A)
        question_text.next_to(title_group, DOWN, buff=0.5)
        self.play(FadeIn(question_text, shift=DOWN))

        # 3. 可视化演示：特征的不变性挑战
        # 创建一个简单的几何特征（模拟材料结构或图像特征）
        def create_feature(color=BLUE, opacity=1.0, rotation=0):
            shape = Square(side_length=1.0, color=color, fill_opacity=opacity)
            # 在内部加一个不对称图形以显示旋转
            inner = Triangle(color=WHITE, fill_opacity=1).scale(0.3).move_to(shape.get_center())
            group = VGroup(shape, inner)
            group.rotate(rotation)
            return group

        # 原始特征
        original = create_feature()
        original_label = Text("原始输入", font="AR PL UKai CN", font_size=20).next_to(original, UP, buff=0.1)
        center_group = VGroup(original, original_label).move_to(ORIGIN).shift(UP*0.5)

        self.play(FadeIn(center_group))

        # 干扰因素展示
        # 3.1 位置变化 (平移)
        pos_feature = create_feature(color=BLUE)
        pos_feature.shift(RIGHT * 3 + UP * 0.5) # 模拟位置改变
        pos_arrow = Arrow(original.get_right(), pos_feature.get_left(), buff=0.2, color=GRAY)
        pos_label = Text("位置改变", font="AR PL UKai CN", font_size=18, color=YELLOW).next_to(pos_feature, DOWN)

        # 3.2 角度变化 (旋转)
        rot_feature = create_feature(rotation=PI/4)
        rot_feature.shift(LEFT * 3 + UP * 0.5)
        rot_arrow = Arrow(original.get_left(), rot_feature.get_right(), buff=0.2, color=GRAY)
        rot_label = Text("角度改变", font="AR PL UKai CN", font_size=18, color=YELLOW).next_to(rot_feature, DOWN)

        # 3.3 光照变化 (颜色/透明度)
        light_feature = create_feature(color=GREY, opacity=0.3) # 变暗
        light_feature.shift(DOWN * 2 + UP * 0.5)
        light_arrow = Arrow(original.get_bottom(), light_feature.get_top(), buff=0.2, color=GRAY)
        light_label = Text("光照/强度", font="AR PL UKai CN", font_size=18, color=YELLOW).next_to(light_feature, RIGHT)

        # 组合动画
        self.play(
            GrowArrow(pos_arrow), FadeIn(pos_feature), Write(pos_label),
            GrowArrow(rot_arrow), FadeIn(rot_feature), Write(rot_label),
            GrowArrow(light_arrow), FadeIn(light_feature), Write(light_label),
            run_time=2
        )

        # 4. 引入核心概念：不变性与等变性
        # 放在底部
        concept_text = Text("关键原则：不变性 (Invariance) & 等变性 (Equivariance)",
                          font="AR PL UKai CN",
                          font_size=26,
                          color=WHITE)
        concept_text.to_edge(DOWN, buff=1.0)

        # 强调框
        box = SurroundingRectangle(concept_text, color=RED, buff=0.2)

        self.play(
            Write(concept_text),
            Create(box),
            run_time=1.5
        )
