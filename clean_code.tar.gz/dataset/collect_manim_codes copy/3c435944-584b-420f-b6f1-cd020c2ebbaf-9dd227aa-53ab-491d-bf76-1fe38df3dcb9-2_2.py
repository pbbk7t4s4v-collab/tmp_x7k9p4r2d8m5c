from manim import *

class JensenInequalityScene(Scene):
    def construct(self):

        # 1. Standardized Title
        title = Text("Jensen's Inequality: Convexity Definition",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("14", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Visual Setup (Graph) - Left Side
        ax = Axes(
            x_range=[-2, 3, 1],
            y_range=[-1, 5, 1],
            x_length=5,
            y_length=4.5,
            axis_config={"include_tip": True, "tip_shape": StealthTip}
        ).to_edge(LEFT, buff=0.8).shift(DOWN * 0.3)

        labels = ax.get_axis_labels(x_label="x", y_label="f(x)")

        # Convex Function f(x) = x^2 (shifted for visibility)
        def func(x):
            return 0.4 * (x ** 2)

        curve = ax.plot(func, x_range=[-2, 2.8], color=BLUE, stroke_width=4)
        curve_label = MathTex("f(x)", color=BLUE, font_size=24).next_to(curve, UP, buff=0.1)

        # Geometric Interpretation (k=2 case)
        x1, x2 = -1.5, 2.5
        p1 = ax.c2p(x1, func(x1))
        p2 = ax.c2p(x2, func(x2))

        # Secant line (Chord)
        secant_line = Line(p1, p2, color=ORANGE, stroke_width=3)

        # Points on curve
        dot1 = Dot(p1, color=WHITE, radius=0.06)
        dot2 = Dot(p2, color=WHITE, radius=0.06)

        # Weighted average point (e.g., theta = 0.5)
        theta = 0.5
        x_avg = theta * x1 + (1 - theta) * x2
        y_avg_curve = func(x_avg)          # f(sum theta x)
        y_avg_line = theta * func(x1) + (1 - theta) * func(x2) # sum theta f(x)

        p_curve = ax.c2p(x_avg, y_avg_curve)
        p_line = ax.c2p(x_avg, y_avg_line)

        dot_lhs = Dot(p_curve, color=GREEN, radius=0.08) # LHS of inequality
        dot_rhs = Dot(p_line, color=RED, radius=0.08)    # RHS of inequality

        # Dashed line showing the gap
        gap_line = DashedLine(p_curve, p_line, color=YELLOW)

        graph_group = VGroup(ax, labels, curve, curve_label, secant_line, dot1, dot2, gap_line, dot_lhs, dot_rhs)

        # 3. Formula and Text - Right Side
        # The Inequality
        formula = MathTex(
            r"f\left(\sum_{i=1}^k \theta_i x_i\right) \leq \sum_{i=1}^k \theta_i f(x_i)",
            font_size=32
        )

        # Conditions
        conditions = MathTex(
            r"\text{where } \theta_i \geq 0, \sum \theta_i = 1",
            font_size=26,
            color=GRAY_A
        )

        # Labels for the geometric visualization
        geo_labels = VGroup(
            MathTex(r"\text{Chord (RHS)}", color=RED, font_size=24).next_to(dot_rhs, RIGHT, buff=0.1),
            MathTex(r"\text{Curve (LHS)}", color=GREEN, font_size=24).next_to(dot_lhs, RIGHT, buff=0.1).shift(DOWN*0.2)
        )

        # Arrange Right Side
        right_content = VGroup(formula, conditions).arrange(DOWN, buff=0.4, aligned_edge=LEFT)
        right_content.to_edge(RIGHT, buff=0.8).shift(UP * 0.5)

        # Highlight Box
        box = SurroundingRectangle(right_content, color=BLUE, buff=0.2, corner_radius=0.1)

        label_text = Text("Convex Function Definition", font_size=24, color=YELLOW).next_to(box, UP, aligned_edge=LEFT)

        # 4. Animations
        # Show graph and curve
        self.play(Create(ax), Write(labels), Create(curve), FadeIn(curve_label), run_time=1.5)

        # Show geometric construction (Secant > Curve)
        self.play(
            FadeIn(dot1), FadeIn(dot2),
            Create(secant_line),
            run_time=1.0
        )

        self.play(
            Create(gap_line),
            FadeIn(dot_lhs), FadeIn(dot_rhs),
            Write(geo_labels),
            run_time=1.5
        )

        # Show Formula
        self.play(
            FadeIn(label_text),
            Write(formula),
            FadeIn(conditions),
            Create(box),
            run_time=2.0
        )
