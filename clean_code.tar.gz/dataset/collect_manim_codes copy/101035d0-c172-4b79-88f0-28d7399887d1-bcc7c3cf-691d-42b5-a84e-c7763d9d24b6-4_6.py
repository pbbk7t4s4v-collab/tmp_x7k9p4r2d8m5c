from manim import *

class CanPronunciation(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("发音提示：can 与 can't 的辨析",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("11", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容构建
        # 左侧：can 的内容
        can_word = Text("can", font_size=60, color=GREEN)
        can_ipa = Text("/kæn/ , /kən/", font_size=36)
        can_desc = Text("句中通常弱读", font="AR PL UKai CN", font_size=30, color=GREEN_B)

        left_group = VGroup(can_word, can_ipa, can_desc).arrange(DOWN, buff=0.4)

        # 右侧：can't 的内容
        cant_word = Text("can't", font_size=60, color=RED)
        cant_ipa = Text("/kɑːnt/ , /kænt/", font_size=36)
        cant_desc = Text("清晰并重读", font="AR PL UKai CN", font_size=30, color=RED_B)

        right_group = VGroup(cant_word, cant_ipa, cant_desc).arrange(DOWN, buff=0.4)

        # 整体布局
        main_content = VGroup(left_group, right_group).arrange(RIGHT, buff=3)
        main_content.next_to(title_line, DOWN, buff=0.8)

        # 边框
        rect_left = SurroundingRectangle(left_group, color=GREEN, buff=0.3)
        rect_right = SurroundingRectangle(right_group, color=RED, buff=0.3)

        # 底部特殊情况
        note_title = Text("特殊情况:", font="AR PL UKai CN", font_size=32, color=YELLOW)
        note_example = Text('Yes, he can.', font_size=36)
        # 将"can"标红表示重读
        note_example[-4:-1].set_color(YELLOW)
        note_desc = Text("句末或强调时需重读", font="AR PL UKai CN", font_size=28, color=WHITE)

        bottom_group = VGroup(note_title, note_example, note_desc).arrange(RIGHT, buff=0.4)
        bottom_group.next_to(main_content, DOWN, buff=1.0)

        # 3. 动画演示
        # 显示左侧 can
        self.play(
            FadeIn(left_group, shift=UP),
            Create(rect_left),
            run_time=1.5
        )

        # 显示右侧 can't
        self.play(
            FadeIn(right_group, shift=UP),
            Create(rect_right),
            run_time=1.5
        )

        # 显示底部提示
        self.play(
            Write(bottom_group),
            run_time=1.5
        )

        # 强调底部
        self.play(Indicate(note_example[-4:-1], color=YELLOW, scale_factor=1.2))
