from manim import *

class GraphDefinition(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("图的定义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心公式展示
        # G = (V, E)
        formula = MathTex(
            "G", "=", "(", "V", ",", "E", ")",
            font_size=60
        )
        formula.set_color_by_tex("V", BLUE)
        formula.set_color_by_tex("E", YELLOW)
        formula.next_to(title_group, DOWN, buff=1.0)

        self.play(Write(formula))

        # 3. 文字解释（左侧）
        # 使用Text而不是BulletedList以避免LaTeX和字体问题
        text_v = Text("V：顶点集合 (非空)", font="AR PL UKai CN", font_size=28, color=BLUE)
        text_e = Text("E：边/弧集合 (可空)", font="AR PL UKai CN", font_size=28, color=YELLOW)

        text_group = VGroup(text_v, text_e).arrange(DOWN, buff=0.8, aligned_edge=LEFT)
        text_group.move_to(LEFT * 3 + DOWN * 0.5)

        # 4. 图形化演示（右侧）
        # 创建顶点
        dot_radius = 0.15
        p1 = UP * 0.5 + RIGHT * 2
        p2 = DOWN * 1.5 + RIGHT * 1
        p3 = DOWN * 1.5 + RIGHT * 3

        dot1 = Dot(point=p1, color=BLUE, radius=dot_radius)
        dot2 = Dot(point=p2, color=BLUE, radius=dot_radius)
        dot3 = Dot(point=p3, color=BLUE, radius=dot_radius)
        dots = VGroup(dot1, dot2, dot3)

        # 创建边
        line1 = Line(p1, p2, color=YELLOW, stroke_width=4)
        line2 = Line(p2, p3, color=YELLOW, stroke_width=4)
        line3 = Line(p3, p1, color=YELLOW, stroke_width=4)
        lines = VGroup(line1, line2, line3)

        # 整体图形位置调整
        visual_group = VGroup(lines, dots)
        visual_group.move_to(RIGHT * 3.5 + DOWN * 0.5)

        # 5. 逐步展示动画
        # 展示 V 的定义和顶点
        self.play(
            FadeIn(text_v, shift=RIGHT),
            FadeIn(dots, scale=0.5),
            Flash(dot1, color=BLUE, run_time=0.8)
        )

        # 展示 E 的定义和边
        self.play(
            FadeIn(text_e, shift=RIGHT),
            Create(lines),
            run_time=1.2
        )

        # 6. 并不是所有的点都必须有边（强调E可空的概念，这里展示一个孤立点作为补充更严谨，但为了画面简洁，我们用强调框强调公式）
        rect = SurroundingRectangle(formula, color=ORANGE, buff=0.2)
        self.play(Create(rect))
