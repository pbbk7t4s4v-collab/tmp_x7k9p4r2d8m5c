from manim import *
import numpy as np

class DotProductCalculation(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("点积计算与相移来源",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("11", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 公式推导部分
        # 定义公式
        eq1 = MathTex(r"k \cdot a_1 = k_x a \frac{\sqrt{3}}{2} + k_y \frac{a}{2}", font_size=32)
        eq2 = MathTex(r"k \cdot a_2 = k_x a \frac{\sqrt{3}}{2} - k_y \frac{a}{2}", font_size=32)

        # 分割线模拟减法运算
        calc_line = Line(LEFT, RIGHT, color=GRAY).match_width(eq1)

        # 结果公式 - 重点
        eq3 = MathTex(r"k \cdot (a_1 - a_2) = k_y a", font_size=38, color=YELLOW)

        # 组合并排版
        math_group = VGroup(eq1, eq2, calc_line, eq3).arrange(DOWN, buff=0.35)
        math_group.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 对齐处理
        eq2.align_to(eq1, LEFT)
        calc_line.align_to(eq1, LEFT)
        eq3.align_to(eq1, LEFT)

        # 3. 几何可视化部分 (右侧)
        # 定义原点和缩放比例
        origin = RIGHT * 3 + DOWN * 1
        scale = 2.0

        # 定义向量坐标
        vec_a1 = np.array([np.sqrt(3)/2, 0.5, 0]) * scale
        vec_a2 = np.array([np.sqrt(3)/2, -0.5, 0]) * scale
        vec_diff = np.array([0, 1, 0]) * scale  # a1 - a2 = (0, 1) * a

        # 创建箭头对象
        arrow_a1 = Arrow(start=origin, end=origin + vec_a1, buff=0, color=BLUE)
        arrow_a2 = Arrow(start=origin, end=origin + vec_a2, buff=0, color=BLUE)
        arrow_diff = Arrow(start=origin, end=origin + vec_diff, buff=0, color=RED)

        # 向量标签
        label_a1 = MathTex("a_1", color=BLUE, font_size=28).next_to(arrow_a1.get_end(), RIGHT, buff=0.1)
        label_a2 = MathTex("a_2", color=BLUE, font_size=28).next_to(arrow_a2.get_end(), RIGHT, buff=0.1)
        label_diff = MathTex(r"a_1 - a_2", color=RED, font_size=28).next_to(arrow_diff.get_end(), UP, buff=0.1)

        # 4. 关键结论说明文字
        note_text = Text("关键：沿y轴方向的次近邻跃迁",
                        font="AR PL UKai CN",
                        font_size=26,
                        color=YELLOW)
        note_text.next_to(math_group, DOWN, buff=0.5).align_to(math_group, LEFT)

        # 重点框
        surround_rect = SurroundingRectangle(eq3, color=YELLOW, buff=0.1)

        # 5. 动画流程
        # 步骤1: 展示基础点积公式
        self.play(
            Write(eq1),
            Write(eq2),
            run_time=1.5
        )

        # 步骤2: 展示几何向量 a1 和 a2
        self.play(
            GrowArrow(arrow_a1),
            GrowArrow(arrow_a2),
            FadeIn(label_a1),
            FadeIn(label_a2),
            run_time=1
        )

        # 步骤3: 进行减法运算展示结果
        self.play(Create(calc_line))
        self.play(Write(eq3))

        # 步骤4: 几何上展示差值向量 (a1-a2) 是垂直的
        self.play(
            TransformFromCopy(VGroup(arrow_a1, arrow_a2), arrow_diff),
            Write(label_diff),
            Create(surround_rect),
            run_time=1.5
        )

        # 步骤5: 展示结论文字
        self.play(FadeIn(note_text))
