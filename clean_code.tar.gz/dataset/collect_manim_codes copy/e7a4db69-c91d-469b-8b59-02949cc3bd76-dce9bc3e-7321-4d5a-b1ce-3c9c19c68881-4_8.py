from manim import *

class AntennaSignalInfluence(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("天线位置对信号强度的影响",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("60", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 左侧内容:磁棒天线方向性示意图
        # ---------------------------------------------------------
        # 绘制磁棒
        ferrite_rod = RoundedRectangle(
            corner_radius=0.1, height=0.3, width=3,
            color=GRAY, fill_opacity=0.9, stroke_color=WHITE
        )
        rod_label = Text("磁棒天线", font="AR PL UKai CN", font_size=20, color=GRAY_A)\
            .next_to(ferrite_rod, DOWN, buff=0.1)

        # 绘制"8"字型方向图 (使用两个椭圆表示接收波瓣)
        # 垂直于磁棒方向信号最强,所以在上下方绘制波瓣
        lobe_up = Ellipse(width=1.5, height=2.2, color=BLUE, fill_opacity=0.3)\
            .next_to(ferrite_rod, UP, buff=0)
        lobe_down = Ellipse(width=1.5, height=2.2, color=BLUE, fill_opacity=0.3)\
            .next_to(ferrite_rod, DOWN, buff=0)

        lobe_label = Text("接收灵敏度(8字型)", font="AR PL UKai CN", font_size=18, color=BLUE)\
            .next_to(lobe_up, UP, buff=0.1)

        # 绘制强弱信号箭头指示
        # 强信号:垂直方向
        arrow_strong = Arrow(start=UP*2, end=UP*0.5, color=GREEN, buff=0)
        text_strong = Text("最强 (垂直)", font="AR PL UKai CN", font_size=18, color=GREEN)\
            .next_to(arrow_strong, UP, buff=0.05)
        strong_group = VGroup(arrow_strong, text_strong).next_to(lobe_up, RIGHT, buff=0.2)

        # 弱信号:轴线方向
        arrow_weak = Arrow(start=LEFT*2, end=LEFT*1.6, color=RED, buff=0)
        text_weak = Text("最弱 (轴线)", font="AR PL UKai CN", font_size=18, color=RED)\
            .next_to(arrow_weak, LEFT, buff=0.05)
        weak_group = VGroup(arrow_weak, text_weak).next_to(ferrite_rod, LEFT, buff=0.1)

        # 组合左侧元素
        left_group = VGroup(
            ferrite_rod, rod_label,
            lobe_up, lobe_down, lobe_label,
            strong_group, weak_group
        )
        left_group.scale(0.85).to_edge(LEFT, buff=1).shift(DOWN*0.5)

        # ---------------------------------------------------------
        # 3. 右侧内容:接收技巧与环境影响
        # ---------------------------------------------------------
        # 列表标题
        list_header = Text("信号优化策略", font="AR PL UKai CN", font_size=26, color=YELLOW)

        # 列表内容(避免使用可能调用 LaTeX 的 BulletedList,改用 Text 组合)
        tips_items = [
            "旋转机身:寻找最强音量角度",
            "避开地面:减少反射与吸收",
            "高度影响:抬高1-2米 (信号+30%)",
            "位置选择:窗边优于房间中央",
        ]
        tips_list = VGroup(*[
            Text(f"• {item}", font="AR PL UKai CN", font_size=22)
            for item in tips_items
        ]).arrange(DOWN, aligned_edge=LEFT, buff=0.35)

        # 组合右侧元素并布局
        right_group = VGroup(list_header, tips_list).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        right_group.to_edge(RIGHT, buff=1).shift(DOWN*0.5)

        # 添加外框强调
        box = SurroundingRectangle(right_group, color=BLUE_C, buff=0.3, stroke_width=2)

        # ---------------------------------------------------------
        # 4. 动画展示流程
        # ---------------------------------------------------------
        # 步骤1:展示天线和方向图
        self.play(
            FadeIn(ferrite_rod),
            Write(rod_label),
            run_time=1
        )
        self.play(
            FadeIn(lobe_up),
            FadeIn(lobe_down),
            Write(lobe_label),
            run_time=1
        )

        # 步骤2:展示强弱方向
        self.play(
            GrowArrow(arrow_strong), Write(text_strong),
            GrowArrow(arrow_weak), Write(text_weak),
            run_time=1.5
        )

        # 步骤3:展示右侧列表策略
        self.play(Write(list_header))
        self.play(
            FadeIn(tips_list, shift=LEFT),
            run_time=1.5
        )
        self.play(Create(box))
