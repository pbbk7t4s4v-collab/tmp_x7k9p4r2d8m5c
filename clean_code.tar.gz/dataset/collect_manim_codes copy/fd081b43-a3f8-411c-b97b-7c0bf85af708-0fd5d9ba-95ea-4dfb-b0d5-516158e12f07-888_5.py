from manim import *

class DatasetManagementDimensions(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("数据集管理的关键维度",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 中心核心概念
        center_text = Text("数据集\n管理", font="AR PL UKai CN", font_size=36, line_spacing=1.2)
        center_bg = Circle(radius=1.2, color=BLUE_E, fill_opacity=0.5)
        center_border = Circle(radius=1.2, color=BLUE)
        center_group = VGroup(center_bg, center_border, center_text).move_to(ORIGIN + DOWN * 0.5)

        self.play(DrawBorderThenFill(center_group), run_time=1)

        # 3. 定义四个维度的内容生成函数
        def create_dimension_node(title_str, sub_str, color, pos):
            # 标题
            t = Text(title_str, font="AR PL UKai CN", font_size=28, color=color)
            # 副标题（核心要点）
            sub = Text(sub_str, font="AR PL UKai CN", font_size=20, color=WHITE)

            # 组合文本
            content = VGroup(t, sub).arrange(DOWN, buff=0.2)

            # 外框
            box = SurroundingRectangle(content, color=color, buff=0.2, corner_radius=0.2)

            # 整体组合并定位
            group = VGroup(box, content).move_to(pos)
            return group, box

        # 4. 创建四个维度的节点
        # 左上：数据质量
        node_quality, box_q = create_dimension_node(
            "数据质量", "校验规则 / 拒绝噪声",
            RED_C, LEFT * 4 + UP * 1.5
        )

        # 右上：数据分布
        node_dist, box_d = create_dimension_node(
            "数据分布", "真实代表性 / 避免漂移",
            GREEN_C, RIGHT * 4 + UP * 1.5
        )

        # 左下：版本管理
        node_ver, box_v = create_dimension_node(
            "版本管理", "唯一指纹 / 可追溯",
            YELLOW_C, LEFT * 4 + DOWN * 2.5
        )

        # 右下：标注一致性
        node_cons, box_c = create_dimension_node(
            "标注一致性", "消除偏差 / 统一标准",
            PURPLE_C, RIGHT * 4 + DOWN * 2.5
        )

        # 5. 创建连接箭头
        arrow_q = Arrow(center_border.get_top(), box_q.get_right(), color=GRAY, buff=0.1)
        arrow_d = Arrow(center_border.get_top(), box_d.get_left(), color=GRAY, buff=0.1)
        arrow_v = Arrow(center_border.get_bottom(), box_v.get_right(), color=GRAY, buff=0.1)
        arrow_c = Arrow(center_border.get_bottom(), box_c.get_left(), color=GRAY, buff=0.1)

        # 6. 动画展示
        # 第一组：上方两点（质量与分布）
        self.play(
            GrowArrow(arrow_q),
            FadeIn(node_quality, shift=LEFT),
            GrowArrow(arrow_d),
            FadeIn(node_dist, shift=RIGHT),
            run_time=1.5
        )

        # 第二组：下方两点（版本与一致性）
        self.play(
            GrowArrow(arrow_v),
            FadeIn(node_ver, shift=LEFT),
            GrowArrow(arrow_c),
            FadeIn(node_cons, shift=RIGHT),
            run_time=1.5
        )

        # 7. 强调核心逻辑 (Garbage In, Garbage Out)
        gigo_text = Text("GIGO铁律", font="AR PL UKai CN", font_size=24, color=RED)
        gigo_text.next_to(node_quality, UP, buff=0.1)

        self.play(Write(gigo_text), run_time=1)
        self.play(Indicate(node_quality), run_time=1)
