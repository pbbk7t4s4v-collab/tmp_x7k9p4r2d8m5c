from manim import *

class FeedbackMindset(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("反馈驱动思维",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("26", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局设计
        # 左侧:反馈循环示意图 (Action -> Feedback -> Improve)
        # 右侧:核心观点列表
        # ---------------------------------------------------------

        # 定义节点样式
        node_config = {"radius": 0.7, "color": BLUE_D, "fill_opacity": 0.3, "fill_color": BLUE_A}
        font_config = {"font": "AR PL UKai CN", "font_size": 24, "color": WHITE}

        # 创建循环节点
        # 顶部:行动
        c_action = Circle(**node_config)
        t_action = Text("行动", **font_config).move_to(c_action)
        g_action = VGroup(c_action, t_action)

        # 右下:反馈
        c_feedback = Circle(**node_config)
        t_feedback = Text("反馈", **font_config).move_to(c_feedback)
        g_feedback = VGroup(c_feedback, t_feedback)

        # 左下:改进
        c_improve = Circle(**node_config)
        t_improve = Text("改进", **font_config).move_to(c_improve)
        g_improve = VGroup(c_improve, t_improve)

        # 排列成三角形
        triangle_center = LEFT * 3.5 + DOWN * 0.5
        g_action.move_to(triangle_center + UP * 1.5)
        g_feedback.move_to(triangle_center + DOWN * 1.2 + RIGHT * 1.5)
        g_improve.move_to(triangle_center + DOWN * 1.2 + LEFT * 1.5)

        # 创建连接箭头
        arrow1 = CurvedArrow(g_action.get_right() + DOWN*0.2, g_feedback.get_top(), angle=-TAU/5, color=GREY_B)
        arrow2 = CurvedArrow(g_feedback.get_left(), g_improve.get_right(), angle=-TAU/5, color=GREY_B)
        arrow3 = CurvedArrow(g_improve.get_top(), g_action.get_left() + DOWN*0.2, angle=-TAU/5, color=GREY_B)

        loop_group = VGroup(g_action, g_feedback, g_improve, arrow1, arrow2, arrow3)

        # 创建右侧文字列表
        list_config = {"font": "AR PL UKai CN", "font_size": 26, "line_spacing": 1.5}

        item1 = Text("1. 主动寻求反馈 (非等待)", **list_config)
        item2 = Text("2. 视作改进机会 (非批评)", **list_config)
        item3 = Text("3. 建立快速反馈循环", **list_config)

        text_group = VGroup(item1, item2, item3).arrange(DOWN, buff=0.8, aligned_edge=LEFT)
        text_group.next_to(loop_group, RIGHT, buff=1.5)
        # 稍微向上调整以垂直居中
        text_group.shift(UP * 0.5)

        # ---------------------------------------------------------
        # 3. 动画流程
        # ---------------------------------------------------------

        # 第一步:展示"主动寻求"
        self.play(FadeIn(g_action), FadeIn(g_feedback))
        self.play(Write(item1), run_time=1)

        # 强调反馈节点
        rect_feedback = SurroundingRectangle(g_feedback, color=YELLOW, buff=0.1)
        self.play(Create(rect_feedback), run_time=0.5)

        # 第二步:展示"改进机会"
        self.play(Write(item2), run_time=1)

        # 视觉辅助:将反馈变为改进
        arrow_transform = Arrow(g_feedback.get_left(), g_improve.get_right(), color=GREEN, buff=0.1)
        self.play(
            FadeIn(g_improve),
            ReplacementTransform(rect_feedback, SurroundingRectangle(g_improve, color=GREEN, buff=0.1)),
            run_time=1
        )

        # 第三步:展示"快速闭环"
        self.play(Write(item3), run_time=1)

        # 完成循环动画
        self.play(
            Create(arrow1),
            Create(arrow2),
            Create(arrow3),
            run_time=1.5
        )

        # 最后的循环强调
        self.play(
            Indicate(loop_group, color=BLUE_E, scale_factor=1.05),
            run_time=1
        )
