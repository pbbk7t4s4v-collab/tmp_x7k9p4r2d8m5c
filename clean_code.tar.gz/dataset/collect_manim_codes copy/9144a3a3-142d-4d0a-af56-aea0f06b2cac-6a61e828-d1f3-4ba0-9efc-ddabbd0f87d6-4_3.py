from manim import *

class ConvolutionVsCrossCorrelation(Scene):
    def construct(self):

        # --- 1. 标题设置 ---
        title = Text("卷积与互相关的核心区别",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("18", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- 2. 核心公式展示 ---
        intro_text = Text("深度学习中实际使用的是"互相关"：", font_size=26, font="AR PL UKai CN", color=YELLOW)
        intro_text.next_to(title_line, DOWN, buff=0.5)

        # 互相关公式
        formula = MathTex(
            r"(f \star g)[i,j] = \sum_{a} \sum_{b} f[a,b] \cdot g[i+a, j+b]",
            font_size=38
        )
        formula.next_to(intro_text, DOWN, buff=0.3)

        self.play(FadeIn(intro_text), Write(formula))

        # --- 3. 对比展示 (左右布局) ---

        # 左侧:数学卷积
        left_title = Text("数学卷积", font_size=28, font="AR PL UKai CN", color=BLUE)
        left_eq = MathTex(r"g[i-a, j-b]", font_size=32, color=BLUE_A)

        # 可视化:卷积需要翻转核
        # 使用字母 'F' 来明显展示翻转效果
        conv_box = Square(side_length=1.2, color=BLUE, fill_opacity=0.1)
        conv_f = Text("F", font_size=48, color=WHITE).move_to(conv_box)
        conv_visual = VGroup(conv_box, conv_f)

        left_desc = Text("核翻转 (Flip)", font_size=24, font="AR PL UKai CN", color=GREY_B)

        left_group = VGroup(left_title, left_eq, conv_visual, left_desc)
        left_group.arrange(DOWN, buff=0.35)

        # 右侧:互相关
        right_title = Text("互相关 (DL)", font_size=28, font="AR PL UKai CN", color=GREEN)
        right_eq = MathTex(r"g[i+a, j+b]", font_size=32, color=GREEN_A)

        # 可视化:互相关直接滑动
        corr_box = Square(side_length=1.2, color=GREEN, fill_opacity=0.1)
        corr_f = Text("F", font_size=48, color=WHITE).move_to(corr_box)
        corr_visual = VGroup(corr_box, corr_f)

        right_desc = Text("直接滑动 (Slide)", font_size=24, font="AR PL UKai CN", color=GREY_B)

        right_group = VGroup(right_title, right_eq, corr_visual, right_desc)
        right_group.arrange(DOWN, buff=0.35)

        # 整体布局
        comparison_group = VGroup(left_group, right_group)
        comparison_group.arrange(RIGHT, buff=2.5)
        comparison_group.next_to(formula, DOWN, buff=0.6)

        # 动画展示对比
        self.play(
            FadeIn(left_group, shift=RIGHT),
            FadeIn(right_group, shift=LEFT)
        )

        # --- 4. 动作演示 ---
        # 卷积:旋转180度
        # 互相关:平移
        self.play(
            Rotate(conv_visual, angle=PI, run_time=1.5), # 翻转
            corr_visual.animate.shift(RIGHT * 0.5).set_run_time(1.5), # 滑动
            Indicate(left_eq, color=BLUE),
            Indicate(right_eq, color=GREEN)
        )

        # --- 5. 总结框 ---
        # 强调深度学习使用的是右侧
        surround_rect = SurroundingRectangle(right_group, color=YELLOW, buff=0.15)
        summary_text = Text("深度学习不需要翻转核", font_size=22, font="AR PL UKai CN", color=YELLOW)
        summary_text.next_to(surround_rect, DOWN, buff=0.1)

        self.play(
            Create(surround_rect),
            Write(summary_text)
        )
