from manim import *

class PoetrySatireScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("诗歌情感:怨与讽谏",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局设计
        # 左侧:核心概念 "怨"
        # 右侧:具体案例展示
        # ---------------------------------------------------------

        # --- 左侧部分:核心概念 ---

        # 主字
        yuan_text = Text("怨", font="AR PL UKai CN", font_size=72, color=RED_C)

        # 核心内涵解释
        meaning_title = Text("核心内涵", font="AR PL UKai CN", font_size=28, color=YELLOW)
        meaning_desc = Text("讽刺讽谏\n表达不满\n针砭时弊",
                           font="AR PL UKai CN",
                           font_size=24,
                           line_spacing=1.5)

        # 组合左侧元素
        left_group = VGroup(yuan_text, meaning_title, meaning_desc).arrange(DOWN, buff=0.4)
        left_group.to_edge(LEFT, buff=2.0).shift(DOWN * 0.5)

        # 给左侧添加一个框,表示概念集合
        left_box = SurroundingRectangle(left_group, color=RED_B, buff=0.3)
        left_label = Text("情感基调", font="AR PL UKai CN", font_size=20, color=RED_B)
        left_label.next_to(left_box, UP)

        # --- 右侧部分:案例展示 ---

        # 案例1:左思
        case1_title = Text("案例一:左思《咏史》", font="AR PL UKai CN", font_size=26, color=BLUE_C)
        case1_content = Text("世胄蹑高位,英俊沉下僚", font="AR PL UKai CN", font_size=22, color=WHITE)
        case1_group = VGroup(case1_title, case1_content).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        # 案例1背景框
        case1_box = SurroundingRectangle(case1_group, color=BLUE_D, buff=0.2, fill_opacity=0.1, fill_color=BLUE_E)
        case1_full = VGroup(case1_box, case1_group)

        # 案例2:杜甫
        case2_title = Text("案例二:杜甫《梦李白》", font="AR PL UKai CN", font_size=26, color=BLUE_C)
        case2_content = Text("冠盖满京华,斯人独憔悴", font="AR PL UKai CN", font_size=22, color=WHITE)
        case2_group = VGroup(case2_title, case2_content).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        # 案例2背景框
        case2_box = SurroundingRectangle(case2_group, color=BLUE_D, buff=0.2, fill_opacity=0.1, fill_color=BLUE_E)
        case2_full = VGroup(case2_box, case2_group)

        # 组合右侧元素
        right_group = VGroup(case1_full, case2_full).arrange(DOWN, buff=0.6)
        right_group.to_edge(RIGHT, buff=1.5).shift(DOWN * 0.5)

        # --- 连接箭头 ---
        arrow1 = Arrow(left_box.get_right(), case1_full.get_left(), color=GRAY, buff=0.1)
        arrow2 = Arrow(left_box.get_right(), case2_full.get_left(), color=GRAY, buff=0.1)

        # ---------------------------------------------------------
        # 3. 动画流程
        # ---------------------------------------------------------

        # 步骤1:展示核心概念
        self.play(
            FadeIn(left_group, shift=RIGHT),
            Create(left_box),
            Write(left_label),
            run_time=1.5
        )

        # 步骤2:展示案例1
        self.play(
            GrowArrow(arrow1),
            FadeIn(case1_full, shift=LEFT),
            run_time=1.2
        )

        # 步骤3:展示案例2
        self.play(
            GrowArrow(arrow2),
            FadeIn(case2_full, shift=LEFT),
            run_time=1.2
        )

        # 停顿以供阅读
