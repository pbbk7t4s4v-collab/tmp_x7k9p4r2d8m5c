from manim import *

class VortexFormationAndEvolution(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("涡旋的形成与演化机制",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("84", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局 (左侧文本，右侧示意图)
        # ---------------------------------------------------------

        # 左侧文本步骤
        text_group = VGroup(
            Text("1. 流体剪切：流速差异产生剪切力", font="AR PL UKai CN", font_size=24, color=BLUE_B),
            Text("2. 卷吸作用：流体微团发生旋转", font="AR PL UKai CN", font_size=24, color=BLUE_B),
            Text("3. 涡旋形成：涡量高度集中区域", font="AR PL UKai CN", font_size=24, color=BLUE_B),
            Text("4. 演化耗散：能量转化与逐渐衰减", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.6)

        text_group.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 右侧可视化区域
        visual_center = RIGHT * 3.5 + UP * 0.5

        # 阶段一：层流 (平行的箭头)
        laminar_arrows = VGroup(*[
            Arrow(start=LEFT, end=RIGHT, color=WHITE, buff=0).set_length(3)
            for _ in range(3)
        ]).arrange(DOWN, buff=0.5).move_to(visual_center)

        laminar_label = Text("层流状态", font="AR PL UKai CN", font_size=20, color=GRAY).next_to(laminar_arrows, DOWN)

        # 阶段二：涡旋 (旋转的箭头)
        # 创建一个简单的漩涡示意图
        vortex_arrows = VGroup()
        for i in range(8):
            angle = i * TAU / 8
            # 切向箭头
            arrow = Arrow(
                start=ORIGIN,
                end=RIGHT * 1.5,
                buff=0,
                color=BLUE
            ).rotate(angle + PI/2).shift(
                np.array([np.cos(angle), np.sin(angle), 0]) * 1.0
            )
            # 让箭头稍微弯曲一点（这里用直线模拟，视觉上像旋转即可）
            vortex_arrows.add(arrow)

        vortex_arrows.move_to(visual_center)

        # 中心添加一个核心点
        core = Dot(color=RED).move_to(visual_center)
        vortex_group = VGroup(vortex_arrows, core)

        vortex_label = Text("涡旋结构", font="AR PL UKai CN", font_size=20, color=BLUE).next_to(vortex_group, DOWN)

        # ---------------------------------------------------------
        # 3. 动画演示流程
        # ---------------------------------------------------------

        # 3.1 显示左侧文本步骤
        for i, text_item in enumerate(text_group):
            self.play(FadeIn(text_item, shift=RIGHT), run_time=0.5)
            if i == 1: # 在讲到旋转时，开始展示右侧
                self.play(FadeIn(laminar_arrows), Write(laminar_label), run_time=0.8)

        # 3.2 核心概念转换：从层流变涡旋
        # 移除层流标签
        self.play(FadeOut(laminar_label), run_time=0.3)

        # 变换动画：直线流变为旋转流
        self.play(
            ReplacementTransform(laminar_arrows, vortex_arrows),
            FadeIn(core),
            run_time=1.2
        )
        self.play(Write(vortex_label), run_time=0.5)

        # 3.3 旋转动画效果 (让涡旋转一圈)
        self.play(
            Rotate(vortex_arrows, angle=TAU, about_point=visual_center, run_time=2, rate_func=smooth)
        )

        # ---------------------------------------------------------
        # 4. 数学定义与强调
        # ---------------------------------------------------------

        # 涡量公式
        formula = MathTex(r"\vec{\omega} = \nabla \times \vec{v} \neq 0", color=YELLOW)
        formula.scale(0.9)
        formula.next_to(text_group, DOWN, buff=1)

        # 这里的矩形框强调公式
        rect = SurroundingRectangle(formula, color=YELLOW, buff=0.2)
        formula_label = Text("涡量定义", font="AR PL UKai CN", font_size=18, color=YELLOW).next_to(rect, RIGHT)

        self.play(Write(formula), run_time=0.8)
        self.play(Create(rect), FadeIn(formula_label), run_time=0.8)
