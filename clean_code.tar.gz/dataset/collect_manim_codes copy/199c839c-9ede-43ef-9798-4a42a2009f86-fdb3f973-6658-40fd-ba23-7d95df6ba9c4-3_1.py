from manim import *

class DeterminantCalculationMethods(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("行列式的计算方法",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局与可视化
        # ---------------------------------------------------------

        # 方法一:对角线法则 (针对低阶)
        method1_title = Text("1. 对角线法则 (二阶/三阶)", font="AR PL UKai CN", font_size=28, color=BLUE_A)

        # 2x2 矩阵示例公式
        method1_math = MathTex(
            r"\begin{vmatrix} a & b \\ c & d \end{vmatrix}",
            r"=",
            r"ad - bc"
        )
        method1_math.scale(0.9)

        # 组合方法一的内容
        group1 = VGroup(method1_title, method1_math).arrange(DOWN, buff=0.3)

        # 方法二:化三角形法 (针对高阶/通用)
        method2_title = Text("2. 化三角形法 (利用性质)", font="AR PL UKai CN", font_size=28, color=GREEN_A)

        # 上三角矩阵示例公式
        method2_math = MathTex(
            r"D = \begin{vmatrix} d_1 & * & \cdots & * \\ 0 & d_2 & \cdots & * \\ \vdots & \vdots & \ddots & \vdots \\ 0 & 0 & \cdots & d_n \end{vmatrix}",
            r"=",
            r"\prod_{i=1}^{n} d_i"
        )
        method2_math.scale(0.8) # 稍微缩小以防溢出

        # 组合方法二的内容
        group2 = VGroup(method2_title, method2_math).arrange(DOWN, buff=0.3)

        # 整体布局:上下排列
        content_group = VGroup(group1, group2).arrange(DOWN, buff=0.8).next_to(title_line, DOWN, buff=0.5)

        # 添加外框强调
        rect1 = SurroundingRectangle(group1, color=BLUE, buff=0.15, stroke_width=2)
        rect2 = SurroundingRectangle(group2, color=GREEN, buff=0.15, stroke_width=2)

        # ---------------------------------------------------------
        # 3. 动画演示
        # ---------------------------------------------------------

        # 展示第一种方法
        self.play(FadeIn(method1_title, shift=RIGHT))
        self.play(Write(method1_math))
        self.play(Create(rect1))

        # 展示第二种方法
        self.play(FadeIn(method2_title, shift=RIGHT))
        self.play(Write(method2_math))
        self.play(Create(rect2))

        # 强调主对角线乘积结果
        # method2_math[2] 对应的是乘积公式部分
        highlight_box = SurroundingRectangle(method2_math[2], color=YELLOW, buff=0.1)
        self.play(Create(highlight_box))
