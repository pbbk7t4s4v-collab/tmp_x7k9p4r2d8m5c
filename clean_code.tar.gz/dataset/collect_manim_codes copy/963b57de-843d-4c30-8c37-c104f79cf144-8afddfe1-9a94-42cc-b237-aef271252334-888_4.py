from manim import *

class CourseResourcesAndAttendance(Scene):
    def construct(self):

        # Title Setup based on template
        title = Text("Resources & Attendance",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Animate Title
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # Left Side: Tools & Resources
        tools_header = Text("Required Tools", font_size=28, color=TEAL)
        tools_items = BulletedList(
            "Essential Textbooks",
            "Digital Platforms",
            "Supplementary Materials",
            font_size=24,
            buff=0.25
        )
        # Group header and list
        tools_group = VGroup(tools_header, tools_items)
        tools_group.arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        tools_group.to_edge(LEFT, buff=1.5).shift(DOWN * 0.5)

        # Right Side: Attendance Requirements
        att_header = Text("Attendance Policy", font_size=28, color=BLUE)
        att_items = BulletedList(
            "University Regulations",
            "Maximum Absences",
            "Leave Procedures",
            font_size=24,
            buff=0.25
        )
        # Group header and list
        att_group = VGroup(att_header, att_items)
        att_group.arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        att_group.to_edge(RIGHT, buff=1.5).match_y(tools_group)

        # Visual Boxes
        box_tools = SurroundingRectangle(tools_group, color=TEAL, buff=0.2)
        box_att = SurroundingRectangle(att_group, color=BLUE, buff=0.2)

        # Animation Sequence
        # Part 1: Tools
        self.play(FadeIn(tools_header, shift=DOWN), run_time=0.8)
        self.play(Write(tools_items), run_time=1.2)
        self.play(Create(box_tools), run_time=0.8)

        # Part 2: Attendance
        self.play(FadeIn(att_header, shift=DOWN), run_time=0.8)
        self.play(Write(att_items), run_time=1.2)
        self.play(Create(box_att), run_time=0.8)

        # Hold for reading
