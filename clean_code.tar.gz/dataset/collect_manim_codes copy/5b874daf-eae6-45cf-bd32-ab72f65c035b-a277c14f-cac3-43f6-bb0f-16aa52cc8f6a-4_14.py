from manim import *

class MatrixEigenMisconception(Scene):
    def construct(self):

        # 1. 标题设置 (标准模板)
        title = Text("易错点：方阵与特征值的关系",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("40", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心结论文本
        conclusion_text = Text("核心结论：只有方阵 (Square Matrix) 才有特征值！",
                             font_size=28,
                             font="AR PL UKai CN",
                             color=YELLOW)
        conclusion_text.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(conclusion_text, shift=DOWN))

        # 3. 左右对比展示逻辑
        # 左侧：方阵的情况
        left_group = VGroup()

        l_title = Text("方阵 (正确)", font_size=24, color=GREEN, font="AR PL UKai CN")
        l_matrix = MathTex(r"A_{n \times n}")
        l_map = MathTex(r"T: \mathbb{R}^n \to \mathbb{R}^n")
        l_eq = MathTex(r"A \mathbf{v} = \lambda \mathbf{v}")
        l_desc = Text("输入输出维度相同\n向量在同一空间", font_size=20, font="AR PL UKai CN", color=LIGHT_GREY)

        left_group.add(l_title, l_matrix, l_map, l_eq, l_desc)
        left_group.arrange(DOWN, buff=0.4)
        left_group.to_edge(LEFT, buff=2.0).shift(DOWN * 0.5)

        # 左侧高亮框
        l_box = SurroundingRectangle(left_group, color=GREEN, buff=0.2)
        l_check = MathTex(r"\checkmark", color=GREEN).next_to(l_box, UP)

        # 右侧：非方阵的情况
        right_group = VGroup()

        r_title = Text("非方阵 (错误)", font_size=24, color=RED, font="AR PL UKai CN")
        r_matrix = MathTex(r"A_{m \times n} \quad (m \neq n)")
        r_map = MathTex(r"T: \mathbb{R}^n \to \mathbb{R}^m")
        r_eq = MathTex(r"A \mathbf{v} \neq \lambda \mathbf{v}")
        r_desc = Text("输入输出维度不同\n无法按比例比较", font_size=20, font="AR PL UKai CN", color=LIGHT_GREY)

        right_group.add(r_title, r_matrix, r_map, r_eq, r_desc)
        right_group.arrange(DOWN, buff=0.4)
        right_group.to_edge(RIGHT, buff=2.0).match_y(left_group)

        # 右侧高亮框
        r_box = SurroundingRectangle(right_group, color=RED, buff=0.2)
        r_cross = MathTex(r"\times", color=RED).next_to(r_box, UP)

        # 4. 动画演示
        # 展示左侧正确逻辑
        self.play(
            Create(l_box),
            FadeIn(left_group, shift=RIGHT),
            run_time=1.5
        )
        self.play(Write(l_check))

        # 展示右侧错误逻辑
        self.play(
            Create(r_box),
            FadeIn(right_group, shift=LEFT),
            run_time=1.5
        )
        self.play(Write(r_cross))

        # 5. 强调对比
        # 连接两个维度的箭头示意 (Visualizing the dimension mismatch)
        arrow_group = VGroup()

        # 在右侧公式旁边加注维度提示
        dim_hint_n = MathTex(r"\in \mathbb{R}^n", font_size=24, color=BLUE).next_to(r_eq[0][1], DOWN, buff=0.1)
        dim_hint_m = MathTex(r"\in \mathbb{R}^m", font_size=24, color=RED).next_to(r_eq[0][0:2], UP, buff=0.1) # Av部分

        self.play(
            Write(dim_hint_n),
            Write(dim_hint_m)
        )
