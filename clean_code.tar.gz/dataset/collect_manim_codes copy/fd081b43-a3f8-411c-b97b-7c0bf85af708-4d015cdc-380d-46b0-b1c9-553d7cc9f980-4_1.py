from manim import *
import math

class ExpLogCurveFeatures(Scene):
    def construct(self):

        # 1. 标题设置 (模板样式)
        title = Text("指数与对数函数的曲线特征",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局划分：左侧文本，右侧图表
        # 创建右侧坐标系
        axes = Axes(
            x_range=[-1, 6, 1],
            y_range=[-2, 6, 1],
            x_length=6,
            y_length=5,
            axis_config={"include_numbers": False, "tip_shape": ArrowTriangleFilledTip},
        ).to_edge(RIGHT, buff=0.5).shift(DOWN * 0.3)

        axis_labels = axes.get_axis_labels(x_label="x", y_label="y")

        # 3. 左侧内容设计
        # 指数函数部分
        exp_title = Text("指数函数 (Explosion)", font="AR PL UKai CN", font_size=24, color=RED)
        exp_formula = MathTex(r"y = a^x \quad (a > 1)", color=RED, font_size=32)
        exp_group = VGroup(exp_title, exp_formula).arrange(DOWN, buff=0.15, aligned_edge=LEFT)

        # 对数函数部分
        log_title = Text("对数函数 (Slow Growth)", font="AR PL UKai CN", font_size=24, color=BLUE)
        log_formula = MathTex(r"y = \log_a x", color=BLUE, font_size=32)
        log_group = VGroup(log_title, log_formula).arrange(DOWN, buff=0.15, aligned_edge=LEFT)

        # 对称性性质
        sym_title = Text("几何性质：", font="AR PL UKai CN", font_size=26, color=YELLOW)
        sym_desc = Text("关于 y = x 对称", font="AR PL UKai CN", font_size=24, color=WHITE)
        sym_desc2 = Text("互为反函数", font="AR PL UKai CN", font_size=24, color=WHITE)
        sym_group = VGroup(sym_title, sym_desc, sym_desc2).arrange(DOWN, buff=0.15, aligned_edge=LEFT)

        # 整体左侧布局
        left_content = VGroup(exp_group, log_group, sym_group).arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        left_content.to_edge(LEFT, buff=0.8).shift(UP * 0.2)

        # 4. 绘制函数曲线
        # 指数曲线 y = 2^x
        exp_graph = axes.plot(lambda x: 2**x, x_range=[-1, 2.5], color=RED)
        exp_label = MathTex(r"y=2^x", color=RED, font_size=24).next_to(axes.c2p(2.5, 5.6), LEFT)

        # 对数曲线 y = log_2(x)
        # 注意：log 定义域 x > 0，这里从 0.25 开始避免无穷大问题
        log_graph = axes.plot(lambda x: math.log(x, 2), x_range=[0.25, 6], color=BLUE)
        log_label = MathTex(r"y=\log_2 x", color=BLUE, font_size=24).next_to(axes.c2p(5, 2.3), DOWN)

        # 对称轴 y = x
        line_y_x = DashedLine(
            start=axes.c2p(-1, -1),
            end=axes.c2p(5, 5),
            color=WHITE,
            stroke_opacity=0.6
        )
        line_label = MathTex("y=x", color=WHITE, font_size=20).next_to(line_y_x.get_end(), UP)

        # 5. 动画流程
        # 步骤1：显示坐标系
        self.play(Create(axes), Write(axis_labels), run_time=1.0)

        # 步骤2：显示指数函数
        self.play(
            FadeIn(exp_group, shift=RIGHT),
            Create(exp_graph),
            run_time=1.5
        )
        self.play(Write(exp_label), run_time=0.5)

        # 步骤3：显示对数函数
        self.play(
            FadeIn(log_group, shift=RIGHT),
            Create(log_graph),
            run_time=1.5
        )
        self.play(Write(log_label), run_time=0.5)

        # 步骤4：展示对称性
        self.play(
            FadeIn(sym_group),
            Create(line_y_x),
            Write(line_label),
            run_time=1.5
        )

        # 强调框
        rect = SurroundingRectangle(sym_group, color=YELLOW, buff=0.15)
        self.play(Create(rect), run_time=0.8)
