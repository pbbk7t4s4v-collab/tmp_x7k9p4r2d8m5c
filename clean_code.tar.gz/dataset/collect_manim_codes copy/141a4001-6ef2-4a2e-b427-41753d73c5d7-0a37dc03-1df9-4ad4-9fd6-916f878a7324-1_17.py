from manim import *

class CoqPoseProofExample(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("Coq 证明示例：使用 pose proof",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("16", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 代码展示区域
        # 注意：Code类不支持直接设置font_size，需使用scale缩放
        coq_code_str = """Example quad_ex1: forall x y: Z,
  x * x + 2 * x * y + y * y + x + y + 1 >= 0.
Proof.
  intros.
  pose proof sum_of_sqr1 (x + y) (-1).
  nia.
Qed."""

        # 使用文本行构造代码块以避免 Code 类不兼容参数的问题
        code_lines = VGroup(*[
            Text(line, font="Monospace", font_size=28, color=WHITE)
            for line in coq_code_str.split("\n")
        ])
        code_lines.arrange(DOWN, aligned_edge=LEFT, buff=0.1)
        code_block = code_lines
        code_block.scale(0.85).move_to(UP * 0.5)

        # 3. 结果展示区域 (生成的命题)
        # 这里的数学公式对应 pose proof 生成的内容
        label_text = Text("生成的命题 (Hypothesis):", font="AR PL UKai CN", font_size=28, color=BLUE_A)

        # 将 (x + y) * (x + y) + -1 * -1 >= (x + y) * -1 转换为 LaTeX
        # 使用 \cdot 表示乘法更清晰
        math_prop = MathTex(
            r"(x + y) \cdot (x + y) + (-1) \cdot (-1) \ge (x + y) \cdot (-1)",
            color=YELLOW
        ).scale(0.9)

        result_group = VGroup(label_text, math_prop).arrange(DOWN, buff=0.3)
        result_group.next_to(code_block, DOWN, buff=0.8)

        # 4. 动画流程

        # 4.1 显示代码块
        self.play(FadeIn(code_block, shift=UP))

        # 4.2 强调 pose proof 这一行 (第4行，索引为3)
        # code_block 的第4行
        target_line = code_block[3]
        rect = SurroundingRectangle(target_line, color=RED, buff=0.05, stroke_width=2)

        # 添加说明文字
        note_text = Text("引用已证结论 sum_of_sqr1", font="AR PL UKai CN", font_size=24, color=RED)
        note_text.next_to(rect, RIGHT, buff=0.2)

        self.play(
            Create(rect),
            FadeIn(note_text, shift=LEFT)
        )

        # 4.3 演示实例化过程（箭头指向结果）
        arrow = Arrow(start=rect.get_bottom(), end=result_group.get_top(), color=WHITE, buff=0.1)

        self.play(GrowArrow(arrow))

        # 4.4 显示生成的命题
        self.play(
            FadeIn(label_text, shift=UP),
            Write(math_prop)
        )

        # 4.5 最后的 nia 说明
        nia_line = code_block[4]
        nia_rect = SurroundingRectangle(nia_line, color=GREEN, buff=0.05)
        nia_text = Text("非线性整数算术求解", font="AR PL UKai CN", font_size=24, color=GREEN)
        nia_text.next_to(nia_rect, RIGHT, buff=0.2)

        self.play(
            ReplacementTransform(rect, nia_rect),
            ReplacementTransform(note_text, nia_text)
        )
