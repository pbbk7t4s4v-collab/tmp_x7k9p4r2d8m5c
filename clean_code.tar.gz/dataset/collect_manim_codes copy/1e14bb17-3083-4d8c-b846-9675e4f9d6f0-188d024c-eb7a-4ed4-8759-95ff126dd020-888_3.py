from manim import *

class CNNApplicationsAndExercises(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("CNN的应用与课后练习",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：应用领域内容
        # 插入图片
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/1e14bb17-3083-4d8c-b846-9675e4f9d6f0/188d024c-eb7a-4ed4-8759-95ff126dd020/pictures/888_3/1.png") # 这里期望是一张展示计算机视觉核心任务的科技风插画。画面中包含自动驾驶视角下的道路场景，对车辆和行人进行了绿色边框标记（代表目标检测）；同时包含一个人脸被数字网格扫描的特写（代表人脸识别）。整体色调为深蓝色背景配亮蓝色线条，风格为现代科幻风，突出AI识别的过程。

        # 调整图片大小和位置
        img1.height = 3.5
        img1.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # 应用领域的文本说明
        app_label = Text("应用领域：计算机视觉 & NLP", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        app_label.next_to(img1, UP, buff=0.2)

        app_desc_1 = Text("• 视觉：分类、检测、人脸识别", font="AR PL UKai CN", font_size=20)
        app_desc_2 = Text("• 非图像：文本分类、语音识别", font="AR PL UKai CN", font_size=20)

        app_desc_group = VGroup(app_desc_1, app_desc_2).arrange(DOWN, buff=0.15, aligned_edge=LEFT)
        app_desc_group.next_to(img1, DOWN, buff=0.2)

        left_group = Group(app_label, img1, app_desc_group)

        # 3. 右侧：课后习题内容
        ex_header = Text("课后重点练习", font="AR PL UKai CN", font_size=28, color=YELLOW)

        # 习题内容
        q1_text = Text("1. 推导卷积后特征图尺寸", font="AR PL UKai CN", font_size=24)
        q2_text = Text("   及参数数量 (Params)", font="AR PL UKai CN", font_size=24)
        q3_text = Text("2. 分析 Padding 与 Stride", font="AR PL UKai CN", font_size=24)
        q4_text = Text("   对输出结果的具体影响", font="AR PL UKai CN", font_size=24)

        questions = VGroup(q1_text, q2_text, q3_text, q4_text).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        # 组合右侧整体
        right_content = VGroup(ex_header, questions).arrange(DOWN, buff=0.5)
        right_content.to_edge(RIGHT, buff=1.5).match_y(img1)

        # 添加边框强调
        box = SurroundingRectangle(right_content, color=TEAL, buff=0.3)
        right_group = VGroup(box, right_content)

        # 4. 动画展示流程
        # 展示左侧图片和文字
        self.play(FadeIn(img1, shift=UP), Write(app_label))
        self.play(Write(app_desc_group), run_time=1.0)

        # 展示右侧习题
        self.play(Create(box), FadeIn(right_content, shift=LEFT))

        # 停留片刻
