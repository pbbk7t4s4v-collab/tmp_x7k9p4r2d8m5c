from manim import *

class FluidMechanicsImportance(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板要求)
        title = Text("流体力学的作用与重要性",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念展示
        # 核心节点
        core_text = Text("流体力学", font="AR PL UKai CN", font_size=40, color=BLUE_A)
        core_rect = SurroundingRectangle(core_text, color=BLUE, buff=0.2)
        core_group = VGroup(core_rect, core_text).shift(UP * 1.5)

        self.play(FadeIn(core_group, shift=DOWN))

        # 3. 三大应用领域 (展示重要性)
        # 定义子节点文字
        font_style = {"font": "AR PL UKai CN", "font_size": 28, "color": WHITE}

        # 左侧：工程领域
        app1_text = Text("航空航天与交通", **font_style)
        app1_desc = Text("飞机升力、汽车风阻", font="AR PL UKai CN", font_size=20, color=GRAY_B)
        app1_group = VGroup(app1_text, app1_desc).arrange(DOWN, buff=0.1)
        app1_group.move_to(LEFT * 4 + DOWN * 0.5)

        # 右侧：能源环境
        app2_text = Text("能源与环境工程", **font_style)
        app2_desc = Text("风力发电、大气扩散", font="AR PL UKai CN", font_size=20, color=GRAY_B)
        app2_group = VGroup(app2_text, app2_desc).arrange(DOWN, buff=0.1)
        app2_group.move_to(RIGHT * 4 + DOWN * 0.5)

        # 下方：生命科学
        app3_text = Text("生物与医学工程", **font_style)
        app3_desc = Text("血液循环、呼吸系统", font="AR PL UKai CN", font_size=20, color=GRAY_B)
        app3_group = VGroup(app3_text, app3_desc).arrange(DOWN, buff=0.1)
        app3_group.move_to(DOWN * 2.5)

        # 创建连接箭头
        arrow1 = Arrow(core_rect.get_bottom(), app1_group.get_top(), color=TEAL_C, buff=0.1)
        arrow2 = Arrow(core_rect.get_bottom(), app2_group.get_top(), color=TEAL_C, buff=0.1)
        arrow3 = Arrow(core_rect.get_bottom(), app3_group.get_top(), color=TEAL_C, buff=0.1)

        # 4. 动画展示分支
        self.play(
            GrowArrow(arrow1),
            GrowArrow(arrow2),
            GrowArrow(arrow3),
            run_time=1
        )

        self.play(
            FadeIn(app1_group, shift=RIGHT),
            FadeIn(app2_group, shift=LEFT),
            FadeIn(app3_group, shift=UP),
            run_time=1.5
        )

        # 5. 总结性描述 (底部)
        summary_box = Rectangle(height=1.2, width=10, color=YELLOW, fill_opacity=0.1)
        summary_text = Text("流体力学是现代工业的基石，\n不仅解释自然现象，更是工程设计的核心依据。",
                           font="AR PL UKai CN", font_size=26, line_spacing=1.2)
        summary_group = VGroup(summary_box, summary_text).to_edge(DOWN, buff=0.5)

        self.play(Create(summary_box), Write(summary_text), run_time=2)
