from manim import *

class JudicialParadox(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("司法透明与算法黑箱的悖论",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("51", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心冲突展示 (上部分)
        # 左侧:司法要求
        justice_label = Text("司法公正要求", font="AR PL UKai CN", font_size=24, color=BLUE)
        justice_desc = Text("可见、可质疑", font="AR PL UKai CN", font_size=20, color=BLUE_A)
        justice_group = VGroup(justice_label, justice_desc).arrange(DOWN, buff=0.15)
        justice_box = SurroundingRectangle(justice_group, color=BLUE, buff=0.2)
        justice_full = VGroup(justice_box, justice_group).to_edge(LEFT, buff=1.5).shift(UP*1.5)

        # 右侧:算法现实
        algo_label = Text("算法逻辑特性", font="AR PL UKai CN", font_size=24, color=PURPLE)
        algo_desc = Text("复杂、黑箱", font="AR PL UKai CN", font_size=20, color=PURPLE_A)
        algo_group = VGroup(algo_label, algo_desc).arrange(DOWN, buff=0.15)
        algo_box = SurroundingRectangle(algo_group, color=PURPLE, buff=0.2)
        algo_full = VGroup(algo_box, algo_group).to_edge(RIGHT, buff=1.5).match_y(justice_full)

        # 中间冲突符号
        conflict_icon = MathTex(r"\nleftrightarrow", color=RED, font_size=48).move_to((justice_full.get_center() + algo_full.get_center()) / 2)

        self.play(
            FadeIn(justice_full, shift=RIGHT),
            FadeIn(algo_full, shift=LEFT),
            Write(conflict_icon)
        )

        # 3. 后果 (中间部分)
        consequence_text = Text("判决难以理解 → 程序正义受损", font="AR PL UKai CN", font_size=24, color=YELLOW)
        consequence_text.next_to(conflict_icon, DOWN, buff=0.8)

        self.play(Write(consequence_text))

        # 4. 深层悖论/困境 (下部分 - 左右分叉)
        paradox_title = Text("深层困境:如何公开?", font="AR PL UKai CN", font_size=22, color=WHITE).next_to(consequence_text, DOWN, buff=0.6)

        # 左分支:完全公开
        branch_left_title = Text("完全公开算法", font="AR PL UKai CN", font_size=20, color=GREEN)
        arrow_left = Arrow(start=paradox_title.get_bottom(), end=paradox_title.get_bottom() + DL * 1.5 + LEFT*0.5, color=GREY, buff=0.1)
        branch_left_title.next_to(arrow_left, DL)

        result_left = Text("风险:对抗性利用\n(策略性操纵)", font="AR PL UKai CN", font_size=18, color=RED_B)
        result_left.next_to(branch_left_title, DOWN, buff=0.2)

        # 右分支:保持黑箱
        branch_right_title = Text("保持算法黑箱", font="AR PL UKai CN", font_size=20, color=GREY_B)
        arrow_right = Arrow(start=paradox_title.get_bottom(), end=paradox_title.get_bottom() + DR * 1.5 + RIGHT*0.5, color=GREY, buff=0.1)
        branch_right_title.next_to(arrow_right, DR)

        result_right = Text("风险:损害公信力\n(无法解释推理)", font="AR PL UKai CN", font_size=18, color=RED_B)
        result_right.next_to(branch_right_title, DOWN, buff=0.2)

        # 动画播放
        self.play(FadeIn(paradox_title, shift=UP))
        self.play(
            Create(arrow_left),
            FadeIn(branch_left_title, shift=DL),
            Create(arrow_right),
            FadeIn(branch_right_title, shift=DR)
        )
        self.play(
            Write(result_left),
            Write(result_right)
        )
