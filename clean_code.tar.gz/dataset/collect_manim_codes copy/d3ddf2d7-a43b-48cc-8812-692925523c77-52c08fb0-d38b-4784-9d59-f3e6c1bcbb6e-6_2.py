from manim import *

class BaiJuyiDescriptionAnalysis(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("白居易描述的科学性辨析",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("17", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 左侧:原文描述
        quotes_content = [
            "壳如红缯 (像红丝绸)",
            "膜如紫绡 (像紫丝绸)",
            "瓤肉莹白如冰雪",
            "浆液甘酸如醴酪"
        ]

        # 右侧:科学判定
        verdicts_content = [
            "× 错 (荔枝壳是粗糙的)",
            "× 错 (作者认为是误作)",
            "√ 正确",
            "√ 正确"
        ]

        verdict_colors = [RED, RED, GREEN, GREEN]

        # 创建左侧文本组
        quotes_group = VGroup()
        for text in quotes_content:
            quotes_group.add(Text(text, font="AR PL UKai CN", font_size=26, color=WHITE))
        quotes_group.arrange(DOWN, buff=0.7, aligned_edge=LEFT)

        # 创建右侧文本组
        verdicts_group = VGroup()
        for text, color in zip(verdicts_content, verdict_colors):
            verdicts_group.add(Text(text, font="AR PL UKai CN", font_size=26, color=color))
        verdicts_group.arrange(DOWN, buff=0.7, aligned_edge=LEFT)

        # 组合左右两列,调整间距
        content_group = VGroup(quotes_group, verdicts_group).arrange(RIGHT, buff=1.0)
        content_group.move_to(ORIGIN).shift(UP * 0.5)

        # 3. 结论部分
        conclusion_text = Text("结论:白居易的描述在科学性上不够准确",
                             font="AR PL UKai CN", font_size=30, color=YELLOW)
        conclusion_text.next_to(content_group, DOWN, buff=0.8)

        # 使用 SurroundingRectangle 强调结论
        conclusion_box = SurroundingRectangle(conclusion_text, color=BLUE, buff=0.2, stroke_width=2)

        # 4. 动画展示流程
        # 逐行展示对比
        for i in range(len(quotes_content)):
            # 每一行的箭头连接(可选,这里直接用简单的左右对应出现)
            arrow = Arrow(start=quotes_group[i].get_right(), end=verdicts_group[i].get_left(), buff=0.2, color=GREY)

            self.play(
                FadeIn(quotes_group[i], shift=RIGHT*0.5),
                run_time=0.6
            )
            self.play(
                GrowArrow(arrow),
                FadeIn(verdicts_group[i], shift=LEFT*0.2),
                run_time=0.6
            )

        # 展示结论
        self.play(
            Write(conclusion_text),
            Create(conclusion_box),
            run_time=1.5
        )
