from manim import *

class GaussTheoremGeometric(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("高斯定理的几何意义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("29", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心公式展示
        # 使用分块MathTex以便分别着色
        formula = MathTex(
            r"\iint_{\partial \Omega} \mathbf{F} \cdot \mathbf{n} \, dS",  # LHS: 表面积分
            r"=",
            r"\iiint_{\Omega} (\nabla \cdot \mathbf{F}) \, dV"            # RHS: 体积分
        ).scale(1.2)

        # 调整位置
        formula.next_to(title_line, DOWN, buff=0.8)

        # 着色强调：左边黄色（表面），右边蓝色（体积）
        formula[0].set_color(YELLOW)
        formula[2].set_color(BLUE)

        self.play(FadeIn(formula, shift=UP))

        # 3. 几何可视化 - 左侧图示
        # 创建代表体积 Omega 的圆形
        volume_circle = Circle(radius=1.5, color=BLUE, fill_opacity=0.3)
        volume_label = MathTex(r"\Omega", color=BLUE_A).move_to(volume_circle.get_center())

        # 创建代表边界 partial Omega 的轮廓
        boundary_label = MathTex(r"\partial \Omega", color=YELLOW).next_to(volume_circle, UL, buff=0.1)

        # 创建代表通量的箭头 (从圆心向外辐射)
        vectors = VGroup()
        for angle in range(0, 360, 45):
            vec = Arrow(
                start=volume_circle.get_center(),
                end=volume_circle.get_center() + 2.0 * np.array([np.cos(angle*DEGREES), np.sin(angle*DEGREES), 0]),
                buff=0,
                color=YELLOW,
                stroke_width=3,
                max_tip_length_to_length_ratio=0.15
            )
            # 只显示超出圆的部分，模拟穿过表面
            # 这里为了简单直接画箭头，视觉上表示向外穿透
            vectors.add(vec)

        # 组合图形元素
        diagram_group = VGroup(volume_circle, volume_label, boundary_label, vectors)
        diagram_group.scale(0.8).to_edge(LEFT, buff=1.5).shift(DOWN * 0.5)

        # 4. 文字解释 - 右侧对应
        # 左侧公式解释
        text_lhs = Text("宏观：穿过闭合曲面的通量", font="AR PL UKai CN", font_size=24, color=YELLOW)
        text_lhs.next_to(diagram_group, RIGHT, buff=1.0).shift(UP * 0.8)

        # 右侧公式解释
        text_rhs = Text("微观：内部各点散度的总和", font="AR PL UKai CN", font_size=24, color=BLUE)
        text_rhs.next_to(text_lhs, DOWN, buff=0.8, aligned_edge=LEFT)

        # 连接线或箭头
        arrow_lhs = Arrow(start=formula[0].get_bottom(), end=text_lhs.get_top(), color=YELLOW, buff=0.1, stroke_width=2)
        arrow_rhs = Arrow(start=formula[2].get_bottom(), end=text_rhs.get_top(), color=BLUE, buff=0.1, stroke_width=2)

        # 5. 动画播放序列
        # 显示几何图形
        self.play(
            Create(volume_circle),
            Write(volume_label),
            Write(boundary_label),
            run_time=1
        )
        self.play(*[GrowArrow(v) for v in vectors], run_time=1)

        # 显示对应文字解释
        self.play(
            FadeIn(text_lhs, shift=LEFT),
            Create(arrow_lhs),
            run_time=1
        )
        self.play(
            FadeIn(text_rhs, shift=LEFT),
            Create(arrow_rhs),
            run_time=1
        )

        # 6. 总结框
        summary_rect = SurroundingRectangle(VGroup(text_lhs, text_rhs), color=WHITE, buff=0.2)
        summary_text = Text("整体流出量 = 内部源强度之和", font="AR PL UKai CN", font_size=20, color=ORANGE)
        summary_text.next_to(summary_rect, DOWN, buff=0.2)

        self.play(
            Create(summary_rect),
            Write(summary_text)
        )
