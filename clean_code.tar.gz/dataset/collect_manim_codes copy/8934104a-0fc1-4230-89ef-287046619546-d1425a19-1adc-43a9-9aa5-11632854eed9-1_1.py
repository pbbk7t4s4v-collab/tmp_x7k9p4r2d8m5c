from manim import *

class AIParadigms(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("AI 的两大任务范式",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 分左右两栏

        # --- 左侧：预测型任务 ---
        left_header = Text("预测型任务", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        left_sub = Text("(Supervised / Unsupervised)", font_size=18, color=GRAY).next_to(left_header, DOWN, buff=0.1)

        # 简单的图示：数据点 -> 结果
        # 数据点网格
        dots = VGroup(*[Dot(radius=0.08, color=BLUE) for _ in range(9)]).arrange_in_grid(3, 3, buff=0.2)
        arrow_pred = Arrow(start=LEFT, end=RIGHT, color=WHITE).next_to(dots, RIGHT, buff=0.3)
        result_box = SurroundingRectangle(Text("Label", font_size=16), color=BLUE, buff=0.1)
        result_text = Text("预测/生成", font="AR PL UKai CN", font_size=20).move_to(result_box)
        result_group = VGroup(result_box, result_text).next_to(arrow_pred, RIGHT, buff=0.3)

        left_visual = VGroup(dots, arrow_pred, result_group).arrange(RIGHT, buff=0.2)
        left_visual.next_to(left_sub, DOWN, buff=0.8)

        # 底部描述
        left_desc_1 = Text("• 基于静态数据", font="AR PL UKai CN", font_size=20, color=WHITE)
        left_desc_2 = Text("• 图像分类/语音识别", font="AR PL UKai CN", font_size=20, color=WHITE)
        left_desc = VGroup(left_desc_1, left_desc_2).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        left_desc.next_to(left_visual, DOWN, buff=0.8)

        left_group = VGroup(left_header, left_sub, left_visual, left_desc)

        # --- 右侧：决策型任务 ---
        right_header = Text("决策型任务", font="AR PL UKai CN", font_size=28, color=GREEN_A)
        right_sub = Text("(Reinforcement Learning)", font_size=18, color=GRAY).next_to(right_header, DOWN, buff=0.1)

        # 简单的图示：智能体 <-> 环境 (循环)
        agent = Circle(radius=0.4, color=GREEN, fill_opacity=0.3)
        agent_label = Text("Agent", font_size=14).move_to(agent)
        agent_group = VGroup(agent, agent_label)

        env = Square(side_length=0.8, color=YELLOW, fill_opacity=0.3)
        env_label = Text("Env", font_size=14).move_to(env)
        env_group = VGroup(env, env_label)

        # 布局位置
        agent_group.move_to(left_visual.get_center() + RIGHT * 5 + UP * 0.5)
        env_group.next_to(agent_group, DOWN, buff=1.0)

        # 交互箭头
        # 动作箭头 (Agent -> Env)
        action_arrow = CurvedArrow(agent_group.get_right(), env_group.get_right(), angle=-TAU/4, color=WHITE)
        action_label = Text("动作", font="AR PL UKai CN", font_size=16).next_to(action_arrow, RIGHT, buff=0.1)

        # 状态/奖励箭头 (Env -> Agent)
        state_arrow = CurvedArrow(env_group.get_left(), agent_group.get_left(), angle=-TAU/4, color=WHITE)
        state_label = Text("状态/奖励", font="AR PL UKai CN", font_size=16).next_to(state_arrow, LEFT, buff=0.1)

        right_visual = VGroup(agent_group, env_group, action_arrow, action_label, state_arrow, state_label)

        # 对齐右侧标题
        right_header.next_to(left_header, RIGHT, buff=4)
        right_header.match_y(left_header)
        right_sub.next_to(right_header, DOWN, buff=0.1)

        # 调整右侧图示位置居中于标题
        right_visual.move_to(right_header.get_center() + DOWN * 2.5)

        # 底部描述
        right_desc_1 = Text("• 动态环境交互", font="AR PL UKai CN", font_size=20, color=WHITE)
        right_desc_2 = Text("• 最大化长期奖励", font="AR PL UKai CN", font_size=20, color=WHITE)
        right_desc = VGroup(right_desc_1, right_desc_2).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        right_desc.match_y(left_desc)
        right_desc.match_x(right_header)

        right_group = VGroup(right_header, right_sub, right_visual, right_desc)

        # 分割线
        separator = DashedLine(UP*2, DOWN*2, color=GRAY).move_to((left_group.get_center() + right_group.get_center()) / 2)

        # 3. 动画演示

        # 左侧入场
        self.play(
            FadeIn(left_header, shift=DOWN),
            FadeIn(left_sub, shift=DOWN),
            Create(dots),
            run_time=1
        )
        self.play(
            GrowArrow(arrow_pred),
            FadeIn(result_group),
            run_time=0.8
        )
        self.play(Write(left_desc), run_time=1)

        self.play(Create(separator), run_time=0.5)

        # 右侧入场
        self.play(
            FadeIn(right_header, shift=DOWN),
            FadeIn(right_sub, shift=DOWN),
            run_time=0.8
        )

        # 循环动画展示
        self.play(
            FadeIn(agent_group),
            FadeIn(env_group),
            run_time=0.8
        )
        self.play(
            Create(action_arrow),
            Write(action_label),
            run_time=0.8
        )
        self.play(
            Create(state_arrow),
            Write(state_label),
            run_time=0.8
        )

        # 强调右侧关键点
        highlight_rect = SurroundingRectangle(right_desc, color=YELLOW, buff=0.1)
        self.play(
            Write(right_desc),
            Create(highlight_rect),
            run_time=1.5
        )
