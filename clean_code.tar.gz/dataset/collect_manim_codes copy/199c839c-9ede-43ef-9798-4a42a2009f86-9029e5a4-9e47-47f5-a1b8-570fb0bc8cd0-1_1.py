from manim import *

class FluidMechanicsIntroScene(Scene):
    def construct(self):

        # 1. Title
        title = Text("What is Fluid Mechanics?",
                     font_size=34,
                     color=WHITE,
                     weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Definition
        definition = Text(
            "The study of liquids and gases in motion and their interaction laws.",
            font_size=28,
            line_spacing=1.2
        ).next_to(title_group, DOWN, buff=0.7)
        definition.set_width(self.camera.frame_width - 2)

        self.play(FadeIn(definition, shift=DOWN), run_time=1.5)

        # 3. Importance and Applications
        importance_label = Text("Key Application Areas:", font_size=28, weight=BOLD, color=YELLOW)
        importance_label.next_to(definition, DOWN, buff=1.0).to_edge(LEFT, buff=1.0)

        applications = BulletedList(
            "Engineering", "Industry", "Medicine", "Environmental Science",
            font_size=28
        )
        applications.next_to(importance_label, DOWN, buff=0.3, aligned_edge=LEFT)

        self.play(Write(importance_label), run_time=1)
        self.play(FadeIn(applications, lag_ratio=0.5), run_time=2)

        # 4. Core Function
        function_group = VGroup()
        function_title = Text("Core Function:", font_size=28, weight=BOLD, color=BLUE)
        function_text = Text(
            "Provide models to predict velocity, pressure, and forces.",
            font_size=28
        ).next_to(function_title, DOWN, buff=0.3)

        function_group.add(function_title, function_text)
        function_group.arrange(DOWN, center=False, aligned_edge=LEFT)
        function_group.next_to(importance_label, RIGHT, buff=1.5)

        self.play(FadeIn(function_group, shift=UP), run_time=1.5)

        box = SurroundingRectangle(function_group, buff=0.2, color=BLUE, corner_radius=0.1)
        self.play(Create(box), run_time=1)
