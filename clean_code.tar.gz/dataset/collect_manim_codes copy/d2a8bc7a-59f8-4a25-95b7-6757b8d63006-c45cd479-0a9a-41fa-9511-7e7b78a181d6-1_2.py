from manim import *

class CrossMediaSoftwareDesign(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("跨媒体大模型软件设计与开发",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容构建:左侧输入数据
        # 使用简单的文本和矩形框表示不同的模态输入
        input_texts = ["文本数据", "图像数据", "音频数据"]
        input_mobs = VGroup()

        for text in input_texts:
            t = Text(text, font="AR PL UKai CN", font_size=20)
            box = SurroundingRectangle(t, color=BLUE_C, buff=0.15, corner_radius=0.1)
            input_mobs.add(VGroup(box, t))

        input_mobs.arrange(DOWN, buff=0.4)
        input_mobs.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # 3. 内容构建:中间核心模型
        core_box = Rectangle(width=4, height=3, color=GREEN)
        core_text = Text("跨媒体\n大模型引擎", font="AR PL UKai CN", font_size=28, line_spacing=1.2)
        core_group = VGroup(core_box, core_text).next_to(input_mobs, RIGHT, buff=1.5)

        # 4. 内容构建:右侧应用接口
        app_box = Rectangle(width=2.5, height=3, color=ORANGE)
        app_text = Text("软件应用\nAPI接口", font="AR PL UKai CN", font_size=24, line_spacing=1.2)
        app_group = VGroup(app_box, app_text).next_to(core_group, RIGHT, buff=1.5)

        # 5. 连接箭头
        arrows_in = VGroup()
        for mob in input_mobs:
            arrow = Arrow(start=mob.get_right(), end=core_box.get_left(), buff=0.1, color=GREY_B)
            arrows_in.add(arrow)

        arrow_out = Arrow(start=core_box.get_right(), end=app_box.get_left(), buff=0.1, color=GREY_B)

        # 6. 动画展示流程
        # 步骤1: 展示多模态输入
        self.play(FadeIn(input_mobs, shift=RIGHT, lag_ratio=0.2))

        # 步骤2: 数据流入核心模型
        self.play(
            GrowFromPoint(arrows_in, input_mobs.get_center()),
            Create(core_box),
            Write(core_text)
        )

        # 步骤3: 核心处理注释
        process_note = Text("特征对齐与融合", font="AR PL UKai CN", font_size=18, color=YELLOW)
        process_note.next_to(core_box, UP, buff=0.1)
        self.play(FadeIn(process_note))

        # 步骤4: 输出到应用层
        self.play(
            GrowArrow(arrow_out),
            FadeIn(app_group, shift=LEFT)
        )

        # 7. 整体架构框
        # 强调这是一个完整的软件系统设计
        full_system_rect = SurroundingRectangle(
            VGroup(input_mobs, app_group),
            color=WHITE,
            buff=0.3,
            stroke_width=2
        )
        system_label = Text("系统架构全景", font="AR PL UKai CN", font_size=22, color=WHITE)
        system_label.next_to(full_system_rect, DOWN, buff=0.15)

        self.play(
            Create(full_system_rect),
            Write(system_label)
        )
