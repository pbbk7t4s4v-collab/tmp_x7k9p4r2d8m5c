from manim import *

class MultiplierDeterminants(Scene):
    def construct(self):

        # 1. 标题设置 (按照模板要求)
        title = Text("乘数大小的决定因素",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念公式展示
        # 公式：k_G = 1 / (1-c)
        formula = MathTex(r"k_G = \frac{1}{1-c}", font_size=60)
        formula.next_to(title_line, DOWN, buff=0.8)

        # 核心逻辑文本
        concept_text = Text("边际消费倾向 c 越大，乘数 k_G 越大",
                           font="AR PL UKai CN",
                           font_size=32,
                           color=YELLOW)
        concept_text.next_to(formula, DOWN, buff=0.5)

        self.play(
            Write(formula),
            FadeIn(concept_text, shift=UP)
        )

        # 3. 实例对比展示
        # 左侧示例：c = 0.8
        case1_c = MathTex(r"c = 0.8", color=BLUE_A)
        case1_k = MathTex(r"k_G = \frac{1}{1-0.8} = 5", color=BLUE)
        group_case1 = VGroup(case1_c, case1_k).arrange(DOWN, buff=0.3)

        # 右侧示例：c = 0.5
        case2_c = MathTex(r"c = 0.5", color=RED_A)
        case2_k = MathTex(r"k_G = \frac{1}{1-0.5} = 2", color=RED)
        group_case2 = VGroup(case2_c, case2_k).arrange(DOWN, buff=0.3)

        # 将两个示例并排排列
        examples_group = VGroup(group_case1, group_case2).arrange(RIGHT, buff=2.5)
        examples_group.next_to(concept_text, DOWN, buff=1.0)

        # 动画展示实例
        self.play(
            FadeIn(group_case1, shift=RIGHT),
            FadeIn(group_case2, shift=LEFT)
        )

        # 4. 强调结论
        # 使用方框强调较大的乘数
        highlight_rect = SurroundingRectangle(group_case1, color=BLUE, buff=0.2)
        highlight_text = Text("乘数效应更显著",
                             font="AR PL UKai CN",
                             font_size=24,
                             color=BLUE)
        highlight_text.next_to(highlight_rect, DOWN, buff=0.1)

        self.play(
            Create(highlight_rect),
            Write(highlight_text)
        )
