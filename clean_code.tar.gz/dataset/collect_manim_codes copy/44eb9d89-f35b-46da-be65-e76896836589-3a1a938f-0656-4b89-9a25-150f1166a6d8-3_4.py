from manim import *

class SymbolicismScene(Scene):
    def construct(self):

        # 1. 标题设置 (标准模板)
        title = Text("三大流派：符号主义 (Symbolicism)",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("11", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念布局
        # 左侧：符号主义标签
        main_label = Text("符号主义", font="AR PL UKai CN", font_size=40, color=BLUE_A)
        main_box = SurroundingRectangle(main_label, color=BLUE, buff=0.3, corner_radius=0.2)
        main_group = VGroup(main_box, main_label).move_to(LEFT * 3 + UP * 0.5)

        # 右侧：核心思想 "认知 = 计算"
        # 使用 Text 处理中文，MathTex 处理数学符号，避免字体问题
        core_text_1 = Text("认知", font="AR PL UKai CN", font_size=36, color=YELLOW)
        core_eq = MathTex("=", font_size=48, color=WHITE)
        core_text_2 = Text("计算", font="AR PL UKai CN", font_size=36, color=YELLOW)

        core_group = VGroup(core_text_1, core_eq, core_text_2).arrange(RIGHT, buff=0.3)
        core_group.next_to(main_group, RIGHT, buff=2)

        # 连接箭头
        arrow = Arrow(main_box.get_right(), core_group.get_left(), color=WHITE, buff=0.2)

        # 补充说明：逻辑推理
        logic_text = Text("基于逻辑推理与符号操作", font="AR PL UKai CN", font_size=24, color=GREY_B)
        logic_text.next_to(core_group, DOWN, buff=0.4)

        # 3. 代表应用布局 (底部)
        app_title = Text("代表应用：", font="AR PL UKai CN", font_size=28, color=GREEN)

        # 应用1：专家系统
        app1_txt = Text("专家系统", font="AR PL UKai CN", font_size=26)
        app1_box = SurroundingRectangle(app1_txt, color=GREEN_B, buff=0.2)
        app1_group = VGroup(app1_box, app1_txt)

        # 应用2：知识图谱
        app2_txt = Text("知识图谱", font="AR PL UKai CN", font_size=26)
        app2_box = SurroundingRectangle(app2_txt, color=GREEN_B, buff=0.2)
        app2_group = VGroup(app2_box, app2_txt)

        # 排列底部元素
        apps_content = VGroup(app1_group, app2_group).arrange(RIGHT, buff=0.8)
        bottom_group = VGroup(app_title, apps_content).arrange(RIGHT, buff=0.5)
        bottom_group.to_edge(DOWN, buff=1.5)

        # 4. 动画流程
        # 步骤1: 展示符号主义主体
        self.play(
            Create(main_box),
            Write(main_label),
            run_time=1
        )

        # 步骤2: 箭头指向核心思想
        self.play(
            GrowArrow(arrow),
            FadeIn(core_group, shift=RIGHT),
            run_time=1
        )

        # 步骤3: 显示逻辑推理文字
        self.play(
            Write(logic_text),
            run_time=1
        )

        # 步骤4: 展示代表应用
        self.play(
            FadeIn(bottom_group, shift=UP),
            run_time=1.5
        )

        # 停顿,展示全貌
