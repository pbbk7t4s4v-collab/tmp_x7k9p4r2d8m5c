from manim import *

class DeterminantZeroProperty(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格按照模板要求)
        # ---------------------------------------------------------
        title = Text("行列式的零性质",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容部分：分左右两边展示两种情况
        # ---------------------------------------------------------

        # --- 左侧：某一行全为零 ---

        # 创建一个中间行全为0的行列式
        # 注意：Matrix 默认是方括号,行列式需要用竖线 "|"
        m1_values = [
            [2, 5, 1],
            [0, 0, 0],
            [3, 8, 4]
        ]
        matrix1 = Matrix(m1_values, left_bracket="|", right_bracket="|")
        eq1 = MathTex("= 0", font_size=40).next_to(matrix1, RIGHT)

        # 组合并放置在左侧
        group1 = VGroup(matrix1, eq1).scale(0.8).move_to(LEFT * 3.5 + UP * 0.5)

        # 说明文字
        label1 = Text("某一行(列)全为零", font="AR PL UKai CN", font_size=24, color=YELLOW)
        label1.next_to(group1, DOWN, buff=0.5)

        # 高亮框：框住中间那行 (row index 1)
        # Matrix.get_rows() 返回的是 VGroup，可以直接索引
        rect1 = SurroundingRectangle(matrix1.get_rows()[1], color=YELLOW, buff=0.1)

        # --- 右侧：两行成比例 ---

        # 创建一个第一行和第二行成比例的行列式 (1:2)
        m2_values = [
            [1, 2, 3],
            [2, 4, 6],
            [5, 9, 7]
        ]
        matrix2 = Matrix(m2_values, left_bracket="|", right_bracket="|")
        eq2 = MathTex("= 0", font_size=40).next_to(matrix2, RIGHT)

        # 组合并放置在右侧
        group2 = VGroup(matrix2, eq2).scale(0.8).move_to(RIGHT * 3.5 + UP * 0.5)

        # 说明文字
        label2 = Text("两行(列)成比例", font="AR PL UKai CN", font_size=24, color=BLUE)
        label2.next_to(group2, DOWN, buff=0.5)

        # 高亮框：框住第一行和第二行
        # 这里需要框住两行，创建一个包含这两行的 VGroup 来生成框
        rows_to_highlight = VGroup(matrix2.get_rows()[0], matrix2.get_rows()[1])
        rect2 = SurroundingRectangle(rows_to_highlight, color=BLUE, buff=0.1)

        # 比例说明箭头 (可选，增强理解)
        arrow = Arrow(start=matrix2.get_rows()[0].get_left() + LEFT*0.2,
                      end=matrix2.get_rows()[1].get_left() + LEFT*0.2,
                      buff=0.1, color=BLUE, max_tip_length_to_length_ratio=0.3)
        scale_text = MathTex(r"\times 2", color=BLUE, font_size=24).next_to(arrow, LEFT, buff=0.1)

        # ---------------------------------------------------------
        # 3. 动画流程
        # ---------------------------------------------------------

        # 展示左侧情况
        self.play(FadeIn(group1, shift=UP))
        self.play(Create(rect1), Write(label1))

        # 展示右侧情况
        self.play(FadeIn(group2, shift=UP))
        self.play(Create(rect2), Write(label2))
        self.play(GrowArrow(arrow), FadeIn(scale_text))

        # 总结
        summary = Text("行列式值为零", font="AR PL UKai CN", font_size=36, color=RED)
        summary.move_to(DOWN * 2.5)

        # 强调最后的结论
        self.play(Write(summary))
        self.play(Indicate(summary, color=ORANGE))
