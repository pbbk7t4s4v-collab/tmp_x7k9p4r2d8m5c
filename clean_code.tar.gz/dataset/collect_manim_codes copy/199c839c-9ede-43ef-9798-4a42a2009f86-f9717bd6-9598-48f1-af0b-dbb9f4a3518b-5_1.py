from manim import *

class BSTIntroduction(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("二叉搜索树(BST)：查找优化",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("21", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念定义
        # ---------------------------------------------------------
        # 使用 MathTex 展示不等式关系,更清晰
        concept_text = Text("核心性质:", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        inequality = MathTex(r"\text{Left} < \text{Root} < \text{Right}", font_size=36)

        concept_group = VGroup(concept_text, inequality).arrange(RIGHT, buff=0.3)
        concept_group.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(concept_group, shift=DOWN))

        # ---------------------------------------------------------
        # 3. 构建二叉搜索树可视乎 (简单的 3 节点结构 + 扩展)
        # ---------------------------------------------------------
        # 节点位置
        root_pos = UP * 0.5
        left_pos = root_pos + LEFT * 2.5 + DOWN * 1.5
        right_pos = root_pos + RIGHT * 2.5 + DOWN * 1.5

        # 辅助函数:创建节点
        def create_node(number, position, color=WHITE):
            circle = Circle(radius=0.5, color=color, fill_opacity=0.2, fill_color=color)
            circle.move_to(position)
            num = MathTex(str(number), font_size=30).move_to(position)
            return VGroup(circle, num)

        # 创建节点
        node_root = create_node(8, root_pos, color=GOLD)
        node_left = create_node(3, left_pos, color=BLUE)   # 3 < 8
        node_right = create_node(10, right_pos, color=RED) # 10 > 8

        # 创建连线
        line_l = Line(node_root.get_bottom(), node_left.get_top(), color=GREY)
        line_r = Line(node_root.get_bottom(), node_right.get_top(), color=GREY)

        tree_group = VGroup(line_l, line_r, node_root, node_left, node_right)

        self.play(Create(tree_group), run_time=1.5)

        # ---------------------------------------------------------
        # 4. 演示查找优化逻辑 (寻找 10)
        # ---------------------------------------------------------
        # 说明文字
        search_text = Text("目标:查找 10", font="AR PL UKai CN", font_size=24, color=YELLOW)
        search_text.next_to(node_root, RIGHT, buff=1.5)

        self.play(Write(search_text))

        # 步骤 1: 比较根节点
        # 10 > 8 -> 向右
        compare_text = MathTex(r"10 > 8 \rightarrow \text{Right}", font_size=28)
        compare_text.next_to(search_text, DOWN, buff=0.2, aligned_edge=LEFT)

        self.play(
            Indicate(node_root, color=YELLOW),
            Write(compare_text)
        )

        # 步骤 2: 剪枝左侧 (用半透明矩形遮罩表示排除)
        mask = SurroundingRectangle(node_left, color=GREY, buff=0.2)
        mask.set_fill(BLACK, opacity=0.7)
        mask_text = Text("排除左子树", font="AR PL UKai CN", font_size=20, color=GREY_A)
        mask_text.next_to(mask, DOWN)

        self.play(
            FadeIn(mask),
            Write(mask_text),
            node_left.animate.set_opacity(0.3), # 变淡
            line_l.animate.set_opacity(0.3)
        )

        # 步骤 3: 找到目标
        path_arrow = Arrow(node_root.get_center(), node_right.get_center(), color=YELLOW, buff=0.6)

        found_box = SurroundingRectangle(node_right, color=GREEN, buff=0.1)

        self.play(
            GrowArrow(path_arrow),
            Create(found_box),
            Indicate(node_right, color=GREEN)
        )

        # ---------------------------------------------------------
        # 5. 总结效率
        # ---------------------------------------------------------
        complexity = MathTex(r"O(\log n)", color=GREEN, font_size=36)
        complexity_label = Text("时间复杂度:", font="AR PL UKai CN", font_size=26)

        final_group = VGroup(complexity_label, complexity).arrange(RIGHT)
        final_group.move_to(DOWN * 2.5)

        self.play(FadeIn(final_group, shift=UP))
