from manim import *

class Page10(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("智能的演进与人工智能定义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # 讲稿片段1：引入
        # "接下来我们要思考一个核心问题，什么是人工智能？要回答这个问题，我们不妨从智能本身的演进历程说起。智能并不是突然出现的，它经历了一个从简单到复杂的发展过程。"

        # 2. 生物智能 (Biological Intelligence)
        bio_circle = Circle(radius=1.0, color=GREEN, fill_opacity=0.2)
        bio_label = Text("生物智能", font="AR PL UKai CN", font_size=24).move_to(bio_circle.get_center())
        bio_sub = Text("本能反应\n(生存/繁衍)", font="AR PL UKai CN", font_size=18, color=GRAY_B).next_to(bio_circle, DOWN)
        bio_group = VGroup(bio_circle, bio_label, bio_sub)

        # 布局：左侧
        bio_group.to_edge(LEFT, buff=1.5).shift(DOWN * 0.5)

        self.play(FadeIn(bio_group, shift=RIGHT))

        # 讲稿片段2：生物智能
        # "最初级的是生物智能，这是低等动物为了生存和繁衍而产生的本能反应，比如觅食时的嗅觉追踪，遇到危险时的快速躲避，这些都是写在基因里的生理机制。"

        # 3. 人类智能 (Human Intelligence)
        human_square = Square(side_length=2.0, color=BLUE, fill_opacity=0.2)
        human_label = Text("人类智能", font="AR PL UKai CN", font_size=24).move_to(human_square.get_center())
        human_sub = Text("中枢神经\n(记忆/思维)", font="AR PL UKai CN", font_size=18, color=GRAY_B).next_to(human_square, DOWN)
        human_group = VGroup(human_square, human_label, human_sub)

        # 布局：中间
        human_group.move_to(ORIGIN).shift(DOWN * 0.5)

        # 箭头1
        arrow1 = Arrow(bio_circle.get_right(), human_square.get_left(), buff=0.2, color=WHITE)

        self.play(GrowArrow(arrow1), FadeIn(human_group, shift=UP))

        # 讲稿片段3：人类智能介绍
        # "随着进化的推进，智能发展到了更高的层次，也就是人类智能。人类智能的本质是我们中枢神经系统的功能，它让我们拥有了记忆能力、思维能力，以及大脑中数以千亿计的神经元进行并行分布处理的能力。"

        # 讲稿片段4：人类智能的复杂性
        # "但有趣的是，尽管我们每天都在使用自己的大脑，我们对人脑的奥秘却依然知之甚少，这也是为什么给智能下一个严格的定义如此困难。"

        # 4. 人工智能 (Artificial Intelligence)
        ai_hex = RegularPolygon(n=6, color=RED, fill_opacity=0.2).scale(1.2)
        ai_label = Text("人工智能", font="AR PL UKai CN", font_size=24).move_to(ai_hex.get_center())
        ai_sub = Text("机器实现\n(模拟智能)", font="AR PL UKai CN", font_size=18, color=GRAY_B).next_to(ai_hex, DOWN)
        ai_group = VGroup(ai_hex, ai_label, ai_sub)

        # 布局：右侧
        ai_group.to_edge(RIGHT, buff=1.5).shift(DOWN * 0.5)

        # 箭头2
        arrow2 = Arrow(human_square.get_right(), ai_hex.get_left(), buff=0.2, color=WHITE)

        self.play(GrowArrow(arrow2), FadeIn(ai_group, shift=LEFT))

        # 讲稿片段5：人工智能定义（人工）
        # "那么什么是人工智能呢？我们可以把这个词拆开来看，人工指的是人造的、非自然的，就像人造卫星、克隆技术一样，是人类创造出来的东西；"

        # 讲稿片段6：人工智能定义（智能）
        # "而智能，则是指我们要在机器上实现的那些智能行为。简单来说，人工智能就是让机器也能像生物、像人类一样表现出智能的技术。"

        # 强调人工智能
        rect = SurroundingRectangle(ai_group, color=YELLOW, buff=0.15)
        self.play(Create(rect))
