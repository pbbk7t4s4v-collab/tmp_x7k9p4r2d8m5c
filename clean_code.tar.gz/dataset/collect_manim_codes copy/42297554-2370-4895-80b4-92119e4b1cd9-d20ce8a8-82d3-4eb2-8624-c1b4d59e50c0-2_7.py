from manim import *

class AbstractAlgebraHistory(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("抽象代数的体系化进程",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 左侧：欧拉部分
        euler_title = Text("欧拉 (Euler)", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        euler_content = VGroup(*[
            Text(f"• {s}", font="AR PL UKai CN", font_size=22)
            for s in [
                "研究整数性质 (Integers)",
                "发展函数概念 (Functions)",
                "萌发代数思想",
            ]
        ]).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        euler_math = Text("ℤ, f(x)", color=BLUE_B, font="AR PL UKai CN").scale(0.8)

        # 组合欧拉部分
        euler_group = VGroup(euler_title, euler_math, euler_content).arrange(DOWN, buff=0.2)
        euler_box = SurroundingRectangle(euler_group, color=BLUE, buff=0.2)
        euler_full = VGroup(euler_box, euler_group).move_to(LEFT * 3.5 + UP * 0.5)

        # 右侧：狄德金部分
        dedekind_title = Text("狄德金 (Dedekind)", font="AR PL UKai CN", font_size=28, color=GREEN_A)
        dedekind_content = VGroup(*[
            Text(f"• {s}", font="AR PL UKai CN", font_size=22)
            for s in [
                "提出"理想" (Ideal)",
                "定义代数结构",
                "建立公理体系",
            ]
        ]).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        dedekind_math = Text("I ⊲ R", color=GREEN_B, font="AR PL UKai CN").scale(0.8)

        # 组合狄德金部分
        dedekind_group = VGroup(dedekind_title, dedekind_math, dedekind_content).arrange(DOWN, buff=0.2)
        dedekind_box = SurroundingRectangle(dedekind_group, color=GREEN, buff=0.2)
        dedekind_full = VGroup(dedekind_box, dedekind_group).move_to(RIGHT * 3.5 + UP * 0.5)

        # 底部：结果部分
        result_text = Text("代数系统:严密化 & 抽象化", font="AR PL UKai CN", font_size=32, color=YELLOW)
        result_box = SurroundingRectangle(result_text, color=YELLOW, buff=0.3, fill_opacity=0.1, fill_color=YELLOW_E)
        result_full = VGroup(result_box, result_text).move_to(DOWN * 2.5)

        # 箭头连接
        arrow_left = Arrow(start=euler_box.get_bottom(), end=result_box.get_top(), color=GREY, buff=0.1)
        arrow_right = Arrow(start=dedekind_box.get_bottom(), end=result_box.get_top(), color=GREY, buff=0.1)

        # 3. 动画展示流程
        # 展示两位数学家的贡献
        self.play(
            FadeIn(euler_full, shift=RIGHT),
            FadeIn(dedekind_full, shift=LEFT),
            run_time=1.5
        )

        # 展示汇聚过程
        self.play(
            GrowArrow(arrow_left),
            GrowArrow(arrow_right),
            run_time=1.0
        )

        # 展示最终结果
        self.play(
            Write(result_text),
            Create(result_box),
            run_time=1.5
        )
