from manim import *

class MagneticCoreTypes(Scene):
    def construct(self):

        # 1. 标题设置 (符合模板要求)
        title = Text("磁芯材料的分类与特性",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 表格数据准备
        data = [
            ["铁氧体", "高频低损耗", "开关电源、射频滤波"],
            ["铁粉芯", "高饱和电流", "储能电感、功率扼流圈"],
            ["坡莫合金", "高磁导率", "精密互感器、音频变压器"]
        ]

        # 3. 创建表格对象
        # 使用 element_to_mobject_config 统一设置中文字体
        table = Table(
            data,
            col_labels=[
                Text("磁芯材料", font="AR PL UKai CN", font_size=24, color=YELLOW, weight=BOLD),
                Text("特性", font="AR PL UKai CN", font_size=24, color=YELLOW, weight=BOLD),
                Text("典型应用", font="AR PL UKai CN", font_size=24, color=YELLOW, weight=BOLD)
            ],
            include_outer_lines=True,
            element_to_mobject_config={
                "font": "AR PL UKai CN",
                "font_size": 22,
                "color": WHITE
            },
            line_config={"stroke_width": 1.5, "color": BLUE_E},
            h_buff=0.8, # 水平间距
            v_buff=0.6  # 垂直间距
        )

        # 调整表格位置和大小
        table.scale(0.85)
        table.next_to(title_line, DOWN, buff=0.5)

        # 4. 动画展示流程

        # 第一步:展示表格框架(网格线)
        self.play(
            Create(table.get_horizontal_lines()),
            Create(table.get_vertical_lines()),
            run_time=1
        )

        # 第二步:展示表头
        self.play(Write(table.get_col_labels()), run_time=1)

        # 第三步:逐行展示数据,并配合高亮框强调
        # table.get_rows() 返回行列表,索引0是表头,索引1开始是数据行
        rows = table.get_rows()

        for i in range(1, len(rows)):
            row = rows[i]

            # 书写当前行内容
            self.play(Write(row), run_time=0.8)

            # 使用 SurroundingRectangle 强调当前讲解的材料行
            # 颜色区分:奇数行用 Teal,偶数行用 Blue
            highlight_color = TEAL if i % 2 != 0 else BLUE
            rect = SurroundingRectangle(row, color=highlight_color, buff=0.1, stroke_width=2)

            self.play(Create(rect), run_time=0.5)
            self.play(FadeOut(rect), run_time=0.3)

        # 5. 结尾定格
