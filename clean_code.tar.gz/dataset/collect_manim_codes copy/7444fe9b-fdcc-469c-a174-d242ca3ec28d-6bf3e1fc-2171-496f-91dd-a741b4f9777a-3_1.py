from manim import *

class CloudAmountIntro(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("学习科学标准:云量",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念文本
        # 引导语
        intro_text = Text("我们需要一个统一的标准来区分天气",
                         font="AR PL UKai CN",
                         font_size=26,
                         color=LIGHT_GREY)
        intro_text.next_to(title_group, DOWN, buff=0.6)

        # 定义
        def_label = Text("云量:", font="AR PL UKai CN", font_size=32, color=YELLOW)
        def_content = Text("云遮蔽天空面积的比例", font="AR PL UKai CN", font_size=32, color=WHITE)
        definition_group = VGroup(def_label, def_content).arrange(RIGHT, buff=0.1)
        definition_group.next_to(intro_text, DOWN, buff=0.5)

        # 强调框
        def_rect = SurroundingRectangle(definition_group, color=BLUE, buff=0.2)

        # 播放文本动画
        self.play(FadeIn(intro_text, shift=UP))
        self.play(
            Write(definition_group),
            Create(def_rect)
        )

        # 3. 可视化展示 (使用饼图概念展示比例)
        # 创建一个辅助函数来生成天空圆和云层扇形
        def create_cloud_visual(percentage, label_str):
            # 天空背景 (蓝色圆)
            sky = Circle(radius=1.0, color=BLUE_E, fill_opacity=1, fill_color=BLUE_E)
            # 云层覆盖 (白色扇形)
            # percentage 0-1
            cloud = Sector(
                radius=1.0,
                angle=2 * PI * percentage,
                start_angle=PI/2,
                color=WHITE,
                fill_opacity=0.8
            )
            # 标签
            label = Text(label_str, font="AR PL UKai CN", font_size=20).next_to(sky, DOWN, buff=0.2)
            # 比例文字
            percent_text = MathTex(f"{int(percentage*100)}\\%", font_size=24, color=BLACK)
            if percentage > 0.1: # 只有云量足够大才显示中间的数字
                percent_text.move_to(cloud.point_from_proportion(0.5)).scale(0.8)
            else:
                percent_text = VGroup() # 空对象

            return VGroup(sky, cloud, label, percent_text)

        # 生成三个不同云量的示例
        visual_low = create_cloud_visual(0.1, "晴天 (云量少)")
        visual_mid = create_cloud_visual(0.5, "多云 (云量适中)")
        visual_high = create_cloud_visual(0.9, "阴天 (云量多)")

        # 排列位置
        visuals = VGroup(visual_low, visual_mid, visual_high)
        visuals.arrange(RIGHT, buff=1.5)
        visuals.next_to(def_rect, DOWN, buff=0.8)

        # 播放可视化动画
        self.play(
            FadeIn(visuals, shift=UP, run_time=1.5)
        )

        # 4. 总结提示
        conclusion = Text("根据云量多少来区分天气状况",
                         font="AR PL UKai CN",
                         font_size=24,
                         color=ORANGE)
        conclusion.next_to(visuals, DOWN, buff=0.4)

        self.play(Write(conclusion))

        # 停顿
