from manim import *

class CoqNiaDemo(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("非线性整数运算求解 (nia)",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 分左右两栏对比
        # 左侧：nia 成功案例
        left_label = Text("nia 的能力：证明非线性性质", font="AR PL UKai CN", color=BLUE_B).scale(0.6)

        # 公式 x^2 + y^2 >= xy
        left_math = MathTex(r"x^2 + y^2 \ge x \cdot y", color=YELLOW).scale(0.8)

        # 代码字符串 - 保持缩进
        code_str_success = """Fact sum_of_sqr1: forall x y: Z,
  x * x + y * y >= x * y.
Proof. nia. Qed."""

        left_code = Text(
            code_str_success,
            font="Monospace"
        ).scale(0.5) # Code不支持font_size，需使用scale

        # 组合左侧元素
        left_group = VGroup(left_label, left_math, left_code).arrange(DOWN, buff=0.4)

        # 右侧：nia 失败案例
        right_label = Text("nia 的局限：不保证完备性", font="AR PL UKai CN", color=RED_B).scale(0.6)

        # 公式 x^2 + y^2 >= 2xy
        right_math = MathTex(r"x^2 + y^2 \ge 2xy", color=YELLOW).scale(0.8)

        # 代码字符串 - 保持缩进
        code_str_fail = """Fact sum_of_sqr2: forall x y: Z,
  x * x + y * y >= 2 * x * y.
Proof. Fail nia. Abort."""

        right_code = Text(
            code_str_fail,
            font="Monospace"
        ).scale(0.5)

        # 组合右侧元素
        right_group = VGroup(right_label, right_math, right_code).arrange(DOWN, buff=0.4)

        # 整体布局
        content_group = VGroup(left_group, right_group).arrange(RIGHT, buff=1.0)
        content_group.next_to(title_line, DOWN, buff=0.5)

        # 3. 动画展示流程

        # 展示左侧成功案例
        self.play(FadeIn(left_group, shift=UP))

        # 强调左侧结果
        success_rect = SurroundingRectangle(left_code, color=GREEN, buff=0.1)
        success_text = Text("自动证明成功", font="AR PL UKai CN", color=GREEN).scale(0.5)
        success_text.next_to(success_rect, DOWN)

        self.play(
            Create(success_rect),
            Write(success_text)
        )

        # 展示右侧失败案例
        self.play(FadeIn(right_group, shift=UP))

        # 强调右侧结果
        fail_rect = SurroundingRectangle(right_code, color=RED, buff=0.1)
        fail_text = Text("自动证明失败 (需人工)", font="AR PL UKai CN", color=RED).scale(0.5)
        fail_text.next_to(fail_rect, DOWN)

        self.play(
            Create(fail_rect),
            Write(fail_text)
        )

        # 4. 总结对比
        summary_text = Text("注：nia 不同于 lia,简单命题也可能无法自动求解",
                           font="AR PL UKai CN",
                           color=GRAY_B,
                           slant=ITALIC).scale(0.4)
        summary_text.to_edge(DOWN, buff=0.2)

        self.play(FadeIn(summary_text))
