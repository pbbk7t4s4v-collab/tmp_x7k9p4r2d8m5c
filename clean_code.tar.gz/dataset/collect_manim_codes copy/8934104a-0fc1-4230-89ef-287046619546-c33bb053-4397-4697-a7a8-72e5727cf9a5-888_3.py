from manim import *

class CatchMultipleExceptions(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("捕获多个异常",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 代码展示 (左侧)
        # 注意保持缩进
        code_str = """def safe_convert(value):
    try:
        return int(value)
    except ValueError:
        print("无法转换整数")
    except TypeError:
        print("类型错误")"""

        code_lines = code_str.split("\n")
        code_obj = VGroup(
            *[Text(line, font="Monospace", font_size=24, color=WHITE) for line in code_lines]
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.1).scale(0.7).to_edge(LEFT, buff=0.8).shift(DOWN * 0.5)

        # 3. 可视化逻辑 (右侧)
        # 场景1：ValueError
        input_1 = Text("输入: \"abc\"", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        arrow_1 = Arrow(LEFT, RIGHT, buff=0.2, color=WHITE).scale(0.6)
        result_1 = Text("捕获 ValueError", font="AR PL UKai CN", font_size=24, color=RED_B)
        group_1 = VGroup(input_1, arrow_1, result_1).arrange(RIGHT)

        # 场景2：TypeError
        input_2 = Text("输入: None", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        arrow_2 = Arrow(LEFT, RIGHT, buff=0.2, color=WHITE).scale(0.6)
        result_2 = Text("捕获 TypeError", font="AR PL UKai CN", font_size=24, color=RED_B)
        group_2 = VGroup(input_2, arrow_2, result_2).arrange(RIGHT)

        # 组合右侧元素并定位
        right_group = VGroup(group_1, group_2).arrange(DOWN, buff=1.5)
        right_group.next_to(code_obj, RIGHT, buff=1.0)

        # 4. 动画流程
        self.play(FadeIn(code_obj))

        # 演示第一种异常
        # code_obj.code[x] 对应代码行，索引从0开始
        # line 3 is except ValueError
        rect_1 = SurroundingRectangle(code_obj[3], color=YELLOW, buff=0.05)

        self.play(
            FadeIn(group_1, shift=LEFT),
            Create(rect_1)
        )

        # 演示第二种异常
        # line 5 is except TypeError
        rect_2 = SurroundingRectangle(code_obj[5], color=YELLOW, buff=0.05)

        self.play(
            FadeIn(group_2, shift=LEFT),
            ReplacementTransform(rect_1, rect_2)
        )
