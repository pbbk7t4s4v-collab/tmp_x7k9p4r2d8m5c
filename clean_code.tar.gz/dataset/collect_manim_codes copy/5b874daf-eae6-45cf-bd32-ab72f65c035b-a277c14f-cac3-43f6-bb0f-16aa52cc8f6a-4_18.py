from manim import *

class EigenvectorCheck(Scene):
    def construct(self):

        # 1. 标题部分 (严格按照模板)
        title = Text("特征向量求解易错点与自检",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("43", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心方程展示
        # 展示求解特征向量的基本方程
        equation = MathTex(r"(A - \lambda I)x = 0", color=BLUE)
        equation.scale(1.3)
        equation.next_to(title_line, DOWN, buff=0.5)

        # 提示文本
        hint_text = Text("求解零空间时的重要自检技巧",
                       font="AR PL UKai CN", font_size=26, color=LIGHT_GRAY)
        hint_text.next_to(equation, DOWN, buff=0.3)

        self.play(Write(equation), FadeIn(hint_text))

        # 3. 对比展示：错误情况 vs 正确迹象

        # 左侧：错误的情况（满秩）
        matrix_wrong = MathTex(r"\begin{bmatrix} * & * \\ 0 & 1 \end{bmatrix}")
        desc_wrong_1 = Text("化简得到满秩矩阵", font="AR PL UKai CN", font_size=24)
        desc_wrong_2 = Text("只有零解 x=0", font="AR PL UKai CN", font_size=24, color=RED_B)
        result_wrong = Text("结论：λ 计算错误！", font="AR PL UKai CN", font_size=26, color=RED)

        group_wrong = VGroup(matrix_wrong, desc_wrong_1, desc_wrong_2, result_wrong)
        group_wrong.arrange(DOWN, buff=0.2)

        rect_wrong = SurroundingRectangle(group_wrong, color=RED, buff=0.2)
        label_wrong = Text("错误情形", font="AR PL UKai CN", font_size=24, color=RED).next_to(rect_wrong, UP)

        container_wrong = VGroup(rect_wrong, label_wrong, group_wrong)

        # 右侧：正确的情况（有零行）
        matrix_right = MathTex(r"\begin{bmatrix} * & * \\ 0 & 0 \end{bmatrix}")
        desc_right_1 = Text("必然出现全零行", font="AR PL UKai CN", font_size=24)
        desc_right_2 = Text("存在非零向量", font="AR PL UKai CN", font_size=24, color=GREEN_B)
        result_right = Text("结论：验证通过", font="AR PL UKai CN", font_size=26, color=GREEN)

        group_right = VGroup(matrix_right, desc_right_1, desc_right_2, result_right)
        group_right.arrange(DOWN, buff=0.2)

        rect_right = SurroundingRectangle(group_right, color=GREEN, buff=0.2)
        label_right = Text("正确迹象", font="AR PL UKai CN", font_size=24, color=GREEN).next_to(rect_right, UP)

        container_right = VGroup(rect_right, label_right, group_right)

        # 整体布局
        comparison_group = VGroup(container_wrong, container_right)
        comparison_group.arrange(RIGHT, buff=1.5)
        comparison_group.next_to(hint_text, DOWN, buff=0.6)

        # 4. 动画展示对比
        self.play(
            Create(rect_wrong),
            Write(label_wrong),
            FadeIn(group_wrong)
        )
        self.play(
            Create(rect_right),
            Write(label_right),
            FadeIn(group_right)
        )
