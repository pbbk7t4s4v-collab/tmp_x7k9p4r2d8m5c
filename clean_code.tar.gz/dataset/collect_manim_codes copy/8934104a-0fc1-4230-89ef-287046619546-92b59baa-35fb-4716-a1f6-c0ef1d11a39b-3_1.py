from manim import *

class AlphaGeometryNeuroSymbolic(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("AlphaGeometry：神经符号范式",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心组件布局
        # 左侧：LLM (直觉)
        llm_text = Text("大语言模型\n(提供直觉/构造)", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        llm_rect = SurroundingRectangle(llm_text, color=BLUE, buff=0.3, fill_opacity=0.1, fill_color=BLUE)
        llm_group = VGroup(llm_rect, llm_text).shift(LEFT * 3.5 + UP * 0.5)

        # 右侧：符号引擎 (严谨)
        sym_text = Text("符号引擎\n(逻辑推导/验证)", font="AR PL UKai CN", font_size=24, color=GREEN_A)
        sym_rect = SurroundingRectangle(sym_text, color=GREEN, buff=0.3, fill_opacity=0.1, fill_color=GREEN)
        sym_group = VGroup(sym_rect, sym_text).shift(RIGHT * 3.5 + UP * 0.5)

        # 3. 循环流程箭头
        # 上方箭头：符号引擎 -> LLM (僵局)
        arrow_stuck = CurvedArrow(
            start_point=sym_rect.get_top(),
            end_point=llm_rect.get_top(),
            angle=PI/4,
            color=RED
        )
        stuck_label = Text("推导陷入僵局", font="AR PL UKai CN", font_size=20, color=RED).next_to(arrow_stuck, UP)

        # 下方箭头：LLM -> 符号引擎 (辅助线)
        arrow_idea = CurvedArrow(
            start_point=llm_rect.get_bottom(),
            end_point=sym_rect.get_bottom(),
            angle=PI/4,
            color=YELLOW
        )
        idea_label = Text("提出辅助点/线", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(arrow_idea, DOWN)

        # 4. 示例可视化：等腰三角形辅助线
        # 在屏幕下方展示
        triangle = Polygon(
            [-1, -1, 0], [1, -1, 0], [0, 1.5, 0],
            color=WHITE
        ).scale(0.6).shift(DOWN * 2.5)

        # 辅助线 (中线)
        mid_point = (triangle.get_vertices()[0] + triangle.get_vertices()[1]) / 2
        top_point = triangle.get_vertices()[2]
        aux_line = DashedLine(top_point, mid_point, color=YELLOW)

        example_label = Text("示例：LLM建议连接中点", font="AR PL UKai CN", font_size=20, color=WHITE).next_to(triangle, RIGHT)

        # 5. 动画流程
        # 展示核心模块
        self.play(FadeIn(llm_group), FadeIn(sym_group))

        # 展示遇到僵局
        self.play(Create(arrow_stuck), Write(stuck_label))

        # 展示LLM介入
        self.play(Create(arrow_idea), Write(idea_label))

        # 展示具体几何示例
        self.play(Create(triangle))
        self.play(Create(aux_line), FadeIn(example_label))

        # 总结优势
        summary = Text("优势：解决幻觉问题 + 缩减搜索空间", font="AR PL UKai CN", font_size=24, color=ORANGE)
        summary.move_to(ORIGIN).shift(UP * 2.5) # 放在上方空位
        self.play(Write(summary))
