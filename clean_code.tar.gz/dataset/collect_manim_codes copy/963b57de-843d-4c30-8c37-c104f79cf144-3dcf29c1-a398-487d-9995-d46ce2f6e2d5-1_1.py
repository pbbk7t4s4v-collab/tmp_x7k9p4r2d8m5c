from manim import *

class FluidMechanicsRole(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("流体力学的作用与重要性",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念展示
        # 中心节点
        core_text = Text("流体力学", font="AR PL UKai CN", font_size=40, color=BLUE_A)
        core_text.next_to(title_line, DOWN, buff=1.0)

        core_box = SurroundingRectangle(core_text, color=BLUE, buff=0.2)

        self.play(FadeIn(core_text), Create(core_box))

        # 3. 分类展示 (左右布局)
        # 左侧：自然界
        nature_title = Text("自然现象", font="AR PL UKai CN", font_size=32, color=GREEN)
        nature_items = VGroup(
            Text("• 气象变化 (台风、降雨)", font="AR PL UKai CN", font_size=24),
            Text("• 生物流动 (血液循环)", font="AR PL UKai CN", font_size=24),
            Text("• 海洋洋流", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        nature_group = VGroup(nature_title, nature_items).arrange(DOWN, buff=0.3)
        nature_group.next_to(core_box, DL, buff=1.5).shift(LEFT * 0.5)

        # 右侧：工程界
        engine_title = Text("工程应用", font="AR PL UKai CN", font_size=32, color=YELLOW)
        engine_items = VGroup(
            Text("• 航空航天 (升力设计)", font="AR PL UKai CN", font_size=24),
            Text("• 能源输送 (石油管道)", font="AR PL UKai CN", font_size=24),
            Text("• 水利设施 (大坝设计)", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        engine_group = VGroup(engine_title, engine_items).arrange(DOWN, buff=0.3)
        engine_group.next_to(core_box, DR, buff=1.5).shift(RIGHT * 0.5)

        # 连线箭头
        arrow_left = Arrow(core_box.get_left(), nature_group.get_top(), color=GREEN_B, buff=0.1)
        arrow_right = Arrow(core_box.get_right(), engine_group.get_top(), color=YELLOW_B, buff=0.1)

        # 4. 动画播放分类内容
        self.play(
            GrowArrow(arrow_left),
            FadeIn(nature_group, shift=DOWN)
        )
        self.play(
            GrowArrow(arrow_right),
            FadeIn(engine_group, shift=DOWN)
        )

        # 5. 底部总结
        summary = Text("它是解释自然奥秘与推动工程技术发展的基石",
                      font="AR PL UKai CN",
                      font_size=28,
                      color=ORANGE)
        summary.to_edge(DOWN, buff=1.0)

        # 简单的装饰线
        line_left = Line(LEFT, RIGHT, color=GREY).set_width(2).next_to(summary, LEFT)
        line_right = Line(LEFT, RIGHT, color=GREY).set_width(2).next_to(summary, RIGHT)

        self.play(
            Write(summary),
            Create(line_left),
            Create(line_right)
        )
