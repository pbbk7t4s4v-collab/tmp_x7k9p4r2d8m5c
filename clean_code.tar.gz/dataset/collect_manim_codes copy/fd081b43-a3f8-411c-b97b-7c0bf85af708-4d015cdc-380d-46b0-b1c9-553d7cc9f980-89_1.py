from manim import *
import numpy as np

class GalaxyRotationCurveScene(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("星系旋转曲线：暗物质存在的证据",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("89", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 坐标系建立
        # 调整位置以防遮挡标题，放在画面中心偏左下
        axes = Axes(
            x_range=[0, 10, 1],
            y_range=[0, 6, 1],
            x_length=7.5,
            y_length=4.5,
            axis_config={"include_tip": True, "color": GREY},
            tips=False
        ).shift(DOWN * 0.5)

        # 中文坐标轴标签
        x_label = Text("距离星系中心的距离 (r)", font="AR PL UKai CN", font_size=20).next_to(axes.x_axis, DOWN, buff=0.2)
        y_label = Text("旋转速度 (v)", font="AR PL UKai CN", font_size=20).next_to(axes.y_axis, UP, buff=0.2).shift(RIGHT)

        # 3. 定义曲线函数
        # 理论预测曲线 (牛顿力学/开普勒下降): 核心外 v ~ 1/sqrt(r)
        def theo_func(x):
            # 简单的分段模拟：先线性上升，后下降
            if x < 1.5:
                return 2.0 * x
            else:
                return 3.0 / np.sqrt(x) + 0.55 # 模拟下降趋势

        # 实际观测曲线: 趋于平坦
        def obs_func(x):
             if x < 1.5:
                return 2.0 * x
             else:
                return 3.0 + 0.02 * x # 保持平坦

        # 绘制曲线
        theo_curve = axes.plot(theo_func, x_range=[0, 9.5], color=BLUE)
        obs_curve = axes.plot(obs_func, x_range=[0, 9.5], color=RED)

        # 曲线标签
        theo_label = Text("牛顿力学预测", font="AR PL UKai CN", font_size=18, color=BLUE)\
            .next_to(axes.c2p(9.5, theo_func(9.5)), DOWN, buff=0.1)

        obs_label = Text("实际观测数据", font="AR PL UKai CN", font_size=18, color=RED)\
            .next_to(axes.c2p(9.5, obs_func(9.5)), UP, buff=0.1)

        # 4. 动画展示过程
        self.play(Create(axes), FadeIn(x_label), FadeIn(y_label), run_time=1.0)

        # 同时绘制两条线对比
        self.play(
            Create(theo_curve),
            Create(obs_curve),
            run_time=2.0
        )
        self.play(FadeIn(theo_label), FadeIn(obs_label))

        # 5. 强调差异与核心概念
        # 在右侧画一个双箭头表示差距
        check_x = 7
        p1 = axes.c2p(check_x, theo_func(check_x))
        p2 = axes.c2p(check_x, obs_func(check_x))
        diff_arrow = DoubleArrow(p1, p2, buff=0, color=YELLOW, tip_length=0.2)

        # 差异说明
        diff_text_group = VGroup(
            Text("缺失的引力源", font="AR PL UKai CN", font_size=20, color=YELLOW),
            MathTex(r"\Rightarrow", color=YELLOW),
            Text("暗物质", font="AR PL UKai CN", font_size=24, color=YELLOW, weight=BOLD)
        ).arrange(RIGHT, buff=0.1).next_to(diff_arrow, RIGHT, buff=0.2)

        self.play(GrowFromCenter(diff_arrow), Write(diff_text_group))

        # 6. 总结框
        # 确保总结文字不遮挡
        summary_text = Text("观测速度未随距离下降，表明存在大量不可见的质量。",
                           font="AR PL UKai CN", font_size=24, color=WHITE)

        # 放置在底部，稍微上移一点
        summary_text.to_edge(DOWN, buff=0.5)

        # 使用 SurroundingRectangle
        box = SurroundingRectangle(summary_text, color=ORANGE, buff=0.15)

        self.play(FadeIn(summary_text), Create(box))
