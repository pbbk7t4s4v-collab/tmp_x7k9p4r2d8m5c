from manim import *

class CPUInterruptContext(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("CPU 中断响应与现场保护",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("66", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局划分
        # 左侧：中断向量表 (IDT) - 对应 12.4
        # 右侧：内核栈现场保护 - 对应 12.5

        # 左侧内容：IDT 示意图
        idt_label = Text("中断描述符表 (IDT)", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        idt_label.shift(LEFT * 4 + UP * 1.5)

        idt_box = VGroup()
        entries = ["向量 0x00 (除零)", "...", "向量 0x80 (系统调用)", "...", "向量 0xFF"]

        for i, text in enumerate(entries):
            rect = Rectangle(width=3.5, height=0.6, color=WHITE)
            content = Text(text, font="AR PL UKai CN", font_size=20)
            if "0x80" in text:
                content.set_color(YELLOW)
                rect.set_fill(YELLOW, opacity=0.2)
                target_rect = rect # 保存引用以便后续强调

            entry_group = VGroup(rect, content)
            idt_box.add(entry_group)

        idt_box.arrange(DOWN, buff=0)
        idt_box.next_to(idt_label, DOWN, buff=0.2)

        # 3. 左侧动画：CPU 查表
        cpu_text = Text("CPU", font="AR PL UKai CN", font_size=28, weight=BOLD)
        cpu_text.next_to(idt_box, LEFT, buff=1)

        lookup_arrow = Arrow(start=cpu_text.get_right(), end=target_rect.get_left(), color=YELLOW)
        lookup_label = Text("读取门描述符", font="AR PL UKai CN", font_size=16, color=YELLOW).next_to(lookup_arrow, UP, buff=0.05)

        self.play(FadeIn(idt_label), Create(idt_box), run_time=1.5)
        self.play(Write(cpu_text), GrowArrow(lookup_arrow), FadeIn(lookup_label), run_time=1)

        # 强调选中 0x80
        surround_rect = SurroundingRectangle(target_rect, color=RED, buff=0.05)
        self.play(Create(surround_rect), run_time=0.5)

        # 4. 右侧内容：内核栈现场保护
        stack_label = Text("内核栈 (Kernel Stack)", font="AR PL UKai CN", font_size=24, color=GREEN_B)
        stack_label.shift(RIGHT * 3.5 + UP * 1.5)

        # 栈的容器
        stack_container = VGroup(
            Line(LEFT, RIGHT).set_length(3), # Bottom
            Line(DOWN, UP).set_length(3.5),  # Left Wall
            Line(DOWN, UP).set_length(3.5)   # Right Wall
        )
        stack_container[1].move_to(stack_container[0].get_left() + UP * 1.75)
        stack_container[2].move_to(stack_container[0].get_right() + UP * 1.75)
        stack_container.next_to(stack_label, DOWN, buff=0.2)

        # 寄存器列表 (模拟压栈顺序，通常是 SS, ESP, EFLAGS, CS, EIP, 然后是通用寄存器)
        # 这里简化展示核心现场
        regs_to_save = ["SS & ESP (用户栈)", "EFLAGS (标志位)", "CS & EIP (返回地址)", "EAX, EBX... (通用寄存器)"]
        stack_items = VGroup()

        for reg in regs_to_save:
            item_box = Rectangle(width=2.8, height=0.5, color=GREY, fill_opacity=0.5)
            item_text = Text(reg, font="AR PL UKai CN", font_size=18, color=WHITE)
            item = VGroup(item_box, item_text)
            stack_items.add(item)

        stack_items.arrange(UP, buff=0.1) # 栈是从下往上增长（可视化上）
        stack_items.move_to(stack_container.get_bottom() + UP * (stack_items.height/2 + 0.2))

        # 5. 连接动画：从 IDT 到 现场保护
        transition_arrow = Arrow(
            start=target_rect.get_right(),
            end=stack_container.get_left(),
            buff=0.5,
            path_arc=-0.5,
            color=WHITE
        )
        transition_text = Text("跳转至入口函数\n开始现场保护", font="AR PL UKai CN", font_size=18).next_to(transition_arrow, UP, buff=0.1)

        self.play(Create(stack_label), Create(stack_container), run_time=1)
        self.play(GrowArrow(transition_arrow), Write(transition_text), run_time=1)

        # 6. 压栈动画
        self.play(
            LaggedStart(
                *[FadeIn(item, shift=DOWN) for item in stack_items],
                lag_ratio=0.5
            ),
            run_time=2
        )

        # 总结框
        summary_text = Text("保存硬件上下文 (pt_regs)", font="AR PL UKai CN", font_size=20, color=ORANGE)
        summary_text.next_to(stack_container, DOWN, buff=0.3)
        self.play(Write(summary_text))
