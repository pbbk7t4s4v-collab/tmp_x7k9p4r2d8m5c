from manim import *
import numpy as np

class CNNApplicationsAndExample(Scene):
    def construct(self):

        # 1. Title Configuration (Strict Template)
        title = Text("CNN Applications: Surveillance & Face Rec",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # Bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Combine title elements
        title_group = VGroup(title, title_line)

        # Title Animation
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Main Content - Split Screen Layout

        # --- Left Side: Security Surveillance ---
        # Icon: A stylized camera view frame with 'people' dots
        surv_frame = Rectangle(height=2.0, width=3.0, color=BLUE_C)
        surv_dots = VGroup(*[
            Dot(point=surv_frame.get_center() + np.array([x, y, 0]), radius=0.08, color=BLUE_A)
            for x, y in [(-0.8, 0.5), (0.2, -0.3), (0.9, 0.4), (-0.3, -0.6)]
        ])
        surv_icon = VGroup(surv_frame, surv_dots)

        surv_title = Text("Security Surveillance", font_size=24, color=BLUE, weight=BOLD)
        surv_title.next_to(surv_icon, UP, buff=0.2)

        surv_list = BulletedList(
            "Anomaly Detection",
            "Crowd Density Est.",
            font_size=20,
            buff=0.15
        )
        surv_list.next_to(surv_icon, DOWN, buff=0.2)

        surv_group = VGroup(surv_title, surv_icon, surv_list)
        surv_group.to_edge(LEFT, buff=1.0).shift(UP*0.5)

        # --- Right Side: Facial Recognition ---
        # Icon: A square face frame with keypoints
        face_frame = Square(side_length=2.0, color=GREEN_C)
        face_features = VGroup(
            Dot(point=face_frame.get_center() + UL*0.4, radius=0.08, color=GREEN_A), # Left Eye
            Dot(point=face_frame.get_center() + UR*0.4, radius=0.08, color=GREEN_A), # Right Eye
            Line(start=face_frame.get_center() + DL*0.3 + DOWN*0.2,
                 end=face_frame.get_center() + DR*0.3 + DOWN*0.2, color=GREEN_A)     # Mouth
        )
        face_icon = VGroup(face_frame, face_features)

        face_title = Text("Facial Recognition", font_size=24, color=GREEN, weight=BOLD)
        face_title.next_to(face_icon, UP, buff=0.2)

        face_list = BulletedList(
            "Identity Verification",
            "Social Tagging",
            font_size=20,
            buff=0.15
        )
        face_list.next_to(face_icon, DOWN, buff=0.2)

        face_group = VGroup(face_title, face_icon, face_list)
        face_group.to_edge(RIGHT, buff=1.0).align_to(surv_group, UP)

        # --- Bottom: Example 1 Practice Process ---
        # Visualizing the "Detailed Solution Process" flow
        ex_label = Text("Example 1: Problem Solving Pipeline", font_size=24, color=YELLOW)

        # Pipeline steps
        step1 = Text("Problem Analysis", font_size=18)
        arrow1 = Arrow(LEFT, RIGHT, buff=0.1, max_tip_length_to_length_ratio=0.2).scale(0.5)
        step2 = Text("Model Selection", font_size=18)
        arrow2 = Arrow(LEFT, RIGHT, buff=0.1, max_tip_length_to_length_ratio=0.2).scale(0.5)
        step3 = Text("Result Interpretation", font_size=18)

        flow_chart = VGroup(step1, arrow1, step2, arrow2, step3).arrange(RIGHT, buff=0.2)

        ex_content = VGroup(ex_label, flow_chart).arrange(DOWN, buff=0.2)
        ex_content.to_edge(DOWN, buff=0.8)

        # Highlight box for the example
        ex_box = SurroundingRectangle(ex_content, color=YELLOW, buff=0.15, corner_radius=0.1)

        # 3. Animations
        self.play(FadeIn(surv_group, shift=RIGHT))
        self.play(FadeIn(face_group, shift=LEFT))

        self.play(
            Create(ex_box),
            Write(ex_content, run_time=2.0)
        )
