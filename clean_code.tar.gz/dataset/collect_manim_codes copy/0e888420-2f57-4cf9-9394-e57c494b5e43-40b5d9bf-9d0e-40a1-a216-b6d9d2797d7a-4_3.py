from manim import *

class InfoCombatPlatformsAndTrends(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("陆海空信息化作战平台及趋势",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧:陆海空平台架构图
        # 中心节点:信息网络
        center_node = Circle(radius=0.7, color=BLUE, fill_opacity=0.3).shift(LEFT * 3.5 + DOWN * 0.5)
        center_text = Text("信息\n网络", font="AR PL UKai CN", font_size=20).move_to(center_node)

        # 周围节点
        # 空中平台
        air_node = Text("空: 战机/无人机", font="AR PL UKai CN", font_size=20, color=BLUE).next_to(center_node, UP, buff=1.5)
        # 陆上平台
        land_node = Text("陆: 坦克/战车", font="AR PL UKai CN", font_size=20, color=GREEN).next_to(center_node, DL, buff=1.0)
        # 海上平台
        sea_node = Text("海: 舰艇/潜艇", font="AR PL UKai CN", font_size=20, color=BLUE_C).next_to(center_node, DR, buff=1.0)

        # 连接线
        line_air = Line(center_node.get_top(), air_node.get_bottom(), color=GREY)
        line_land = Line(center_node.get_left(), land_node.get_right(), color=GREY)
        line_sea = Line(center_node.get_right(), sea_node.get_left(), color=GREY)

        diagram_group = VGroup(center_node, center_text, air_node, land_node, sea_node, line_air, line_land, line_sea)

        # 3. 右侧:发展趋势列表
        trend_header = Text("主要发展趋势", font="AR PL UKai CN", font_size=26, color=YELLOW).shift(RIGHT * 2.5 + UP * 1.0)

        # 使用Text对象手动创建列表,避免BulletedList的潜在问题
        t1 = Text("1. 装备体系一体化", font="AR PL UKai CN", font_size=22).next_to(trend_header, DOWN, buff=0.4).align_to(trend_header, LEFT)
        t2 = Text("2. 作战平台无人化", font="AR PL UKai CN", font_size=22).next_to(t1, DOWN, buff=0.3).align_to(trend_header, LEFT)
        t3 = Text("3. 系统控制智能化", font="AR PL UKai CN", font_size=22).next_to(t2, DOWN, buff=0.3).align_to(trend_header, LEFT)
        t4 = Text("4. 打击隐身精准化", font="AR PL UKai CN", font_size=22).next_to(t3, DOWN, buff=0.3).align_to(trend_header, LEFT)

        list_group = VGroup(t1, t2, t3, t4)

        # 外框强调
        rect = SurroundingRectangle(list_group, color=WHITE, buff=0.2)

        # 4. 动画流程
        # 4.1 显示中心网络
        self.play(DrawBorderThenFill(center_node), Write(center_text), run_time=1)

        # 4.2 辐射出三个领域
        self.play(
            Create(line_air), Create(line_land), Create(line_sea),
            FadeIn(air_node, shift=UP), FadeIn(land_node, shift=LEFT), FadeIn(sea_node, shift=RIGHT),
            run_time=1.5
        )

        # 4.3 显示右侧趋势标题
        self.play(Write(trend_header), run_time=0.8)

        # 4.4 逐条显示趋势
        self.play(
            AnimationGroup(
                FadeIn(t1, shift=LEFT),
                FadeIn(t2, shift=LEFT),
                FadeIn(t3, shift=LEFT),
                FadeIn(t4, shift=LEFT),
                lag_ratio=0.3
            )
        )

        # 4.5 加上强调框
        self.play(Create(rect), run_time=0.8)
