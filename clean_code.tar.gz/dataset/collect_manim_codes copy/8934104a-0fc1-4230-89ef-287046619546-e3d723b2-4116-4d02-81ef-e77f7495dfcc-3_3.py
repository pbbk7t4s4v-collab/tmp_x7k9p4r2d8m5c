from manim import *

class CNNBasics(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("卷积神经网络(CNN)基础",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧核心概念文本
        # 使用VGroup手动构建列表，避免BulletedList的潜在问题
        bullet_config = {"font": "AR PL UKai CN", "font_size": 22, "color": LIGHT_GRAY}
        content_config = {"font": "AR PL UKai CN", "font_size": 24, "color": WHITE}

        item1_dot = Text("•", **bullet_config)
        item1_text = Text("核心定位：具有平移不变性和局部感知能力", **content_config)
        item1 = VGroup(item1_dot, item1_text).arrange(RIGHT, buff=0.2)

        item2_dot = Text("•", **bullet_config)
        item2_text = Text("功能：强大的图像特征提取能力", **content_config)
        item2 = VGroup(item2_dot, item2_text).arrange(RIGHT, buff=0.2)

        item3_dot = Text("•", **bullet_config)
        item3_text = Text("基本构成：输入 -> 卷积计算 -> 输出特征图", **content_config)
        item3 = VGroup(item3_dot, item3_text).arrange(RIGHT, buff=0.2)

        text_group = VGroup(item1, item2, item3).arrange(DOWN, buff=0.4, aligned_edge=LEFT)
        text_group.to_edge(LEFT, buff=0.8).shift(UP*0.5)

        self.play(FadeIn(text_group, shift=RIGHT), run_time=1.5)

        # 3. 右侧可视化：卷积计算过程
        # 创建5x5输入特征图
        grid_vals = [
            [-1, 0, 1, 0, 0],
            [0, 1, 0, 0, 0],
            [1, 0, -1, 0, 0],
            [0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0]
        ]

        grid_group = VGroup()
        square_size = 0.6

        for i in range(5):
            for j in range(5):
                sq = Square(side_length=square_size, color=BLUE_C, stroke_width=2)
                val = grid_vals[i][j]
                # 只显示非零值以减少视觉杂乱，或者显示顶部3x3区域的值
                if i < 3 and j < 3:
                    num = Text(str(val), font_size=16, font="AR PL UKai CN").move_to(sq.get_center())
                else:
                    num = Text("", font_size=16).move_to(sq.get_center()) # 占位

                sq_group = VGroup(sq, num)
                sq_group.move_to(np.array([j * square_size, -i * square_size, 0]))
                grid_group.add(sq_group)

        grid_group.move_to(RIGHT * 3.2 + UP * 0.5)

        # 标签
        grid_label = Text("输入特征图 (5x5)", font="AR PL UKai CN", font_size=20, color=BLUE).next_to(grid_group, UP)

        self.play(Create(grid_group), Write(grid_label))

        # 4. 卷积核窗口 (3x3)
        # 对应位置是 grid_group中的前3行前3列
        # 直接计算位置绘制矩形
        top_left_sq = grid_group[0]
        bottom_right_roi_sq = grid_group[12] # row 2, col 2 -> index 2*5 + 2 = 12

        kernel_rect = SurroundingRectangle(
            VGroup(top_left_sq, bottom_right_roi_sq),
            color=YELLOW,
            buff=0.05,
            stroke_width=4
        )
        kernel_label = Text("3x3 卷积核", font="AR PL UKai CN", font_size=18, color=YELLOW).next_to(kernel_rect, RIGHT)

        self.play(Create(kernel_rect), FadeIn(kernel_label))

        # 5. 展示计算公式
        # 示例：-1×1+0×2+1×3+0×4+1×5+0×6+1×7+0×8+(-1)×9=5
        # 为了美观，分两行展示
        formula_str1 = r"(-1 \cdot 1) + (0 \cdot 2) + (1 \cdot 3) + (0 \cdot 4) + (1 \cdot 5)"
        formula_str2 = r"+ (0 \cdot 6) + (1 \cdot 7) + (0 \cdot 8) + (-1 \cdot 9) = \mathbf{5}"

        math_formula1 = MathTex(formula_str1, font_size=22, color=YELLOW)
        math_formula2 = MathTex(formula_str2, font_size=22, color=YELLOW)

        math_group = VGroup(math_formula1, math_formula2).arrange(DOWN, buff=0.1)
        math_group.next_to(grid_group, DOWN, buff=0.5)

        # 背景框，突出公式
        formula_bg = SurroundingRectangle(math_group, color=GRAY, fill_opacity=0.2, buff=0.1)

        self.play(
            FadeIn(formula_bg),
            Write(math_group, run_time=2)
        )

        # 6. 显示结果输出
        output_box = Square(side_length=square_size, color=GREEN, fill_opacity=0.5)
        output_val = Text("5", font="AR PL UKai CN", font_size=24).move_to(output_box)
        output_group = VGroup(output_box, output_val).next_to(math_group, RIGHT, buff=1)

        # 箭头
        arrow = Arrow(start=math_group.get_right(), end=output_group.get_left(), buff=0.1, color=WHITE)
        output_label = Text("输出", font="AR PL UKai CN", font_size=18).next_to(output_group, UP)

        self.play(
            GrowArrow(arrow),
            FadeIn(output_group),
            Write(output_label)
        )
