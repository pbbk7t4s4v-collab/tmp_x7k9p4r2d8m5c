from manim import *

class IntegralAccumulationScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (严格遵守模板)
        # ---------------------------------------------------------
        title = Text("积分的面积累积图像",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 坐标系与函数构建
        # ---------------------------------------------------------
        # 创建坐标系,位于左侧
        axes = Axes(
            x_range=[0, 6, 1],
            y_range=[0, 5, 1],
            x_length=6,
            y_length=4,
            axis_config={"color": GREY, "include_tip": True},
        ).to_edge(LEFT, buff=1).shift(DOWN * 0.5)

        axes_labels = axes.get_axis_labels(x_label="x", y_label="y")

        # 定义函数 f(t) = 0.1*t^2 + 1 (平滑且恒正,便于展示面积)
        def func_def(x):
            return 0.1 * (x)**2 + 1

        graph = axes.plot(func_def, x_range=[0, 5.5], color=BLUE)
        graph_label = MathTex("f(t)", color=BLUE).next_to(graph, UP, buff=0.1)

        # ---------------------------------------------------------
        # 3. 动态面积与辅助元素
        # ---------------------------------------------------------
        # 变量追踪器,控制 x 的位置
        x_tracker = ValueTracker(0)

        # 动态绘制面积:使用 always_redraw 实时更新
        area = always_redraw(lambda: axes.get_area(
            graph,
            x_range=[0, x_tracker.get_value()],
            color=BLUE_C,
            opacity=0.5
        ))

        # 动态垂直线,指示当前的 x 位置
        v_line = always_redraw(lambda: axes.get_vertical_line(
            axes.c2p(x_tracker.get_value(), func_def(x_tracker.get_value())),
            line_config={"dashed_ratio": 0.5, "color": YELLOW}
        ))

        # 当前 x 轴坐标的标签
        x_label_val = always_redraw(lambda: MathTex("x", font_size=24, color=YELLOW).next_to(
            axes.c2p(x_tracker.get_value(), 0), DOWN, buff=0.1
        ))

        # ---------------------------------------------------------
        # 4. 右侧公式与说明
        # ---------------------------------------------------------
        formula = MathTex(r"A(x) = \int_0^x f(t) \, dt", font_size=42)
        formula.to_edge(RIGHT, buff=1.5).shift(UP * 0.5)

        # 说明文字
        desc_text = Text("面积随上限 x 的\n增加而不断累积", font="AR PL UKai CN", font_size=24, color=WHITE)
        desc_text.next_to(formula, DOWN, buff=0.5, aligned_edge=LEFT)

        # 强调框
        box = SurroundingRectangle(formula, color=YELLOW, buff=0.2)

        # ---------------------------------------------------------
        # 5. 动画流程
        # ---------------------------------------------------------
        # 展示坐标系和静态函数
        self.play(
            Create(axes),
            Write(axes_labels),
            Create(graph),
            Write(graph_label),
            run_time=1.5
        )

        # 展示公式和说明
        self.play(
            Write(formula),
            FadeIn(desc_text),
            Create(box)
        )

        # 添加动态元素(初始状态面积为0,不可见)
        self.add(area, v_line, x_label_val)

        # 播放累积过程:x 从 0 变化到 5
        self.play(
            x_tracker.animate.set_value(5),
            run_time=5,
            rate_func=linear
        )
