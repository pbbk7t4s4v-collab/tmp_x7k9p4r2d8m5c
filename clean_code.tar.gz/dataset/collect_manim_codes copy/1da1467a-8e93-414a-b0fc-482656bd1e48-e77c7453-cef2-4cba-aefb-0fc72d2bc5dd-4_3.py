from manim import *

class LocalityPrinciple(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("局部性原理：存储层次设计的依据",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("18", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 分左右两块展示时间局部性和空间局部性

        # 左侧：时间局部性
        time_title = Text("时间局部性", font="AR PL UKai CN", font_size=28, color=BLUE)
        time_desc = Text("刚被访问过的单元，\n不久后可能再次被访问",
                        font="AR PL UKai CN", font_size=20, line_spacing=0.8).next_to(time_title, DOWN, buff=0.3)

        # 简单的循环示意图表示时间局部性
        loop_arrow = CurvedArrow(start_point=LEFT, end_point=RIGHT, angle=-TAU/1.5, color=BLUE_B).scale(0.5)
        loop_text = Text("Loop / 循环", font="AR PL UKai CN", font_size=16, color=GRAY).next_to(loop_arrow, DOWN, buff=0.1)
        loop_group = VGroup(loop_arrow, loop_text).next_to(time_desc, DOWN, buff=0.3)

        left_group = VGroup(time_title, time_desc, loop_group)
        left_group.move_to(LEFT * 3.5 + UP * 0.5)

        left_rect = SurroundingRectangle(left_group, color=BLUE, buff=0.3)

        # 右侧：空间局部性
        space_title = Text("空间局部性", font="AR PL UKai CN", font_size=28, color=GREEN)
        space_desc = Text("被访问单元的邻近单元，\n不久后可能被访问",
                         font="AR PL UKai CN", font_size=20, line_spacing=0.8).next_to(space_title, DOWN, buff=0.3)

        # 简单的数组示意图表示空间局部性
        squares = VGroup(*[Square(side_length=0.4, color=WHITE) for _ in range(5)]).arrange(RIGHT, buff=0.1)
        squares[1].set_fill(GREEN, opacity=0.8) # 当前访问
        squares[2].set_fill(GREEN_B, opacity=0.5) # 邻近未来访问

        array_text = Text("Array / 顺序存储", font="AR PL UKai CN", font_size=16, color=GRAY).next_to(squares, DOWN, buff=0.2)
        space_visual = VGroup(squares, array_text).next_to(space_desc, DOWN, buff=0.3)

        right_group = VGroup(space_title, space_desc, space_visual)
        right_group.move_to(RIGHT * 3.5 + UP * 0.5)

        right_rect = SurroundingRectangle(right_group, color=GREEN, buff=0.3)

        # 3. 动画展示左右部分
        self.play(
            FadeIn(left_group, shift=RIGHT),
            Create(left_rect),
            run_time=1.5
        )
        self.play(
            FadeIn(right_group, shift=LEFT),
            Create(right_rect),
            run_time=1.5
        )

        # 4. 底部结论：为什么这是优化的依据
        conclusion_arrow_1 = Arrow(start=left_rect.get_bottom(), end=left_rect.get_bottom() + DOWN * 1.2, color=YELLOW)
        conclusion_arrow_2 = Arrow(start=right_rect.get_bottom(), end=right_rect.get_bottom() + DOWN * 1.2, color=YELLOW)

        # 汇聚点
        target_point = (conclusion_arrow_1.get_end() + conclusion_arrow_2.get_end()) / 2 + DOWN * 0.2

        conclusion_box = RoundedRectangle(corner_radius=0.2, height=1.2, width=8, color=YELLOW)
        conclusion_box.move_to(target_point)

        conclusion_text = Text("结论：将活跃数据集中在高速小容量存储中 (Cache)",
                              font="AR PL UKai CN", font_size=24, color=YELLOW)
        conclusion_text.move_to(conclusion_box.get_center())

        # 调整箭头指向框体
        conclusion_arrow_1.put_start_and_end_on(left_rect.get_bottom(), conclusion_box.get_top() + LEFT*2)
        conclusion_arrow_2.put_start_and_end_on(right_rect.get_bottom(), conclusion_box.get_top() + RIGHT*2)

        self.play(
            GrowArrow(conclusion_arrow_1),
            GrowArrow(conclusion_arrow_2),
            Create(conclusion_box),
            Write(conclusion_text),
            run_time=2
        )
