from manim import *

class HardVsSoftMargin(Scene):
    def construct(self):

        # 1. 标题设置 (严格遵守模板要求)
        title = Text("SVM: 硬间隔与软间隔",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("15", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左右分栏
        # 左侧:硬间隔 (Hard Margin)
        # 右侧:软间隔 (Soft Margin)

        # --- 左侧内容构建 ---
        left_center = LEFT * 3.5 + DOWN * 0.5

        # 数据点
        h_blue_dots = VGroup(
            Dot(point=left_center + UP*1 + LEFT*0.5, color=BLUE),
            Dot(point=left_center + UP*1.5 + LEFT*1.2, color=BLUE),
            Dot(point=left_center + UP*0.8 + LEFT*1.5, color=BLUE)
        )
        h_red_dots = VGroup(
            Dot(point=left_center + DOWN*1 + RIGHT*0.5, color=RED),
            Dot(point=left_center + DOWN*1.5 + RIGHT*1.2, color=RED),
            Dot(point=left_center + DOWN*0.8 + RIGHT*1.5, color=RED)
        )

        # 分类边界
        h_line = Line(left_center + LEFT*2 + UP*0.5, left_center + RIGHT*2 + DOWN*0.5, color=WHITE)
        # 间隔边界 (虚线)
        h_margin_up = DashedLine(left_center + LEFT*2 + UP*1.2, left_center + RIGHT*2 + UP*0.2, color=BLUE_A)
        h_margin_down = DashedLine(left_center + LEFT*2 + DOWN*0.2, left_center + RIGHT*2 + DOWN*1.2, color=RED_A)

        h_label = Text("硬间隔: 零容忍", font="AR PL UKai CN", font_size=24, color=YELLOW).next_to(h_line, UP, buff=1.5)
        h_desc = Text("要求数据线性可分\n不允许任何误分类", font="AR PL UKai CN", font_size=20, line_spacing=0.8).next_to(h_red_dots, DOWN, buff=0.5)

        left_group = VGroup(h_blue_dots, h_red_dots, h_line, h_margin_up, h_margin_down, h_label, h_desc)

        # --- 右侧内容构建 ---
        right_center = RIGHT * 3.5 + DOWN * 0.5

        # 复制基础点
        s_blue_dots = h_blue_dots.copy().move_to(right_center + UP*1.1 + LEFT*1) # 整体调整位置
        s_red_dots = h_red_dots.copy().move_to(right_center + DOWN*1.1 + RIGHT*1)

        # 添加噪声点 (异常值)
        outlier = Dot(point=right_center + UP*0.5, color=RED) # 一个红点跑到了上方区域

        # 分类边界 (保持较好的泛化能力,不因噪声改变)
        s_line = Line(right_center + LEFT*2 + UP*0.5, right_center + RIGHT*2 + DOWN*0.5, color=WHITE)
        s_margin_up = DashedLine(right_center + LEFT*2 + UP*1.2, right_center + RIGHT*2 + UP*0.2, color=BLUE_A)
        s_margin_down = DashedLine(right_center + LEFT*2 + DOWN*0.2, right_center + RIGHT*2 + DOWN*1.2, color=RED_A)

        # 标注松弛变量
        xi_line = Line(outlier.get_center(), s_line.get_projection(outlier.get_center()), color=ORANGE)
        xi_label = MathTex(r"\xi_i", color=ORANGE, font_size=24).next_to(xi_line, RIGHT, buff=0.1)

        s_label = Text("软间隔: 允许误差", font="AR PL UKai CN", font_size=24, color=GREEN).next_to(s_line, UP, buff=1.5)
        s_desc = Text("引入松弛变量\n提高模型鲁棒性", font="AR PL UKai CN", font_size=20, line_spacing=0.8).next_to(s_red_dots, DOWN, buff=0.5)

        right_group = VGroup(s_blue_dots, s_red_dots, outlier, s_line, s_margin_up, s_margin_down, xi_line, xi_label, s_label, s_desc)

        # 3. 动画展示

        # 展示硬间隔
        self.play(FadeIn(h_blue_dots), FadeIn(h_red_dots))
        self.play(Create(h_line), Create(h_margin_up), Create(h_margin_down))
        self.play(Write(h_label), Write(h_desc))

        # 使用框强调
        rect_left = SurroundingRectangle(left_group, color=BLUE, buff=0.2)
        self.play(Create(rect_left))

        # 展示软间隔
        self.play(FadeIn(s_blue_dots), FadeIn(s_red_dots), FadeIn(outlier))
        # 这里的线和左边一样,暗示没有因为异常点而剧烈变化
        self.play(Create(s_line), Create(s_margin_up), Create(s_margin_down))
        self.play(Create(xi_line), Write(xi_label))
        self.play(Write(s_label), Write(s_desc))

        # 使用框强调
        rect_right = SurroundingRectangle(right_group, color=GREEN, buff=0.2)
        self.play(Create(rect_right))

        # 4. 底部公式总结
        formula = MathTex(r"\min_{w,b} \frac{1}{2}||w||^2 + C\sum_{i=1}^N \xi_i", font_size=28)
        formula.to_edge(DOWN, buff=0.5)

        note = Text("目标函数:最大化间隔 + 最小化误分类", font="AR PL UKai CN", font_size=20, color=GRAY)
        note.next_to(formula, UP, buff=0.1)

        self.play(Write(note), FadeIn(formula))
