from manim import *

class DiodeMeasurementAndVoltage(Scene):
    def construct(self):

        # --- 标题部分 ---
        title = Text("二极管导通压降测量与典型值",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("28", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- 左侧:测量方法示意 ---
        # 绘制二极管符号
        triangle = Triangle(color=WHITE, fill_opacity=0).rotate(-90*DEGREES).scale(0.2)
        bar = Line(UP, DOWN, color=WHITE).scale(0.2).next_to(triangle, RIGHT, buff=0)
        wire_l = Line(LEFT, RIGHT, color=WHITE).scale(0.4).next_to(triangle, LEFT, buff=0)
        wire_r = Line(LEFT, RIGHT, color=WHITE).scale(0.4).next_to(bar, RIGHT, buff=0)

        diode_symbol = VGroup(wire_l, triangle, bar, wire_r)

        # 标注阳极阴极
        anode_txt = Text("阳极 (+)", font="AR PL UKai CN", font_size=20, color=RED).next_to(wire_l, UP, buff=0.1)
        cathode_txt = Text("阴极 (-)", font="AR PL UKai CN", font_size=20, color=BLUE).next_to(wire_r, UP, buff=0.1)

        diode_group = VGroup(diode_symbol, anode_txt, cathode_txt)
        diode_group.to_edge(LEFT, buff=1.0).shift(UP * 1.5)

        # 测量步骤文本
        step1 = Text("1. 正向测量 (红接阳, 黑接阴):", font="AR PL UKai CN", font_size=22, color=YELLOW)
        step1_res = Text("   → 显示导通压降 (如 0.6V)", font="AR PL UKai CN", font_size=20)

        step2 = Text("2. 反向测量 (红接阴, 黑接阳):", font="AR PL UKai CN", font_size=22, color=YELLOW)
        step2_res = Text("   → 显示 'OL' (截止)", font="AR PL UKai CN", font_size=20)

        steps_group = VGroup(step1, step1_res, step2, step2_res).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        steps_group.next_to(diode_group, DOWN, buff=0.5).align_to(diode_group, LEFT)

        # --- 右侧:典型压降表格 ---
        # 使用 Text 对象构建表格内容以避免 LaTeX 中文问题
        header_type = Text("二极管类型", font="AR PL UKai CN", font_size=24, weight=BOLD)
        header_vol = Text("正向压降(V)", font="AR PL UKai CN", font_size=24, weight=BOLD)

        row1_type = Text("锗二极管", font="AR PL UKai CN", font_size=22)
        row1_vol = MathTex("0.2 \\sim 0.3", font_size=24)

        row2_type = Text("硅二极管", font="AR PL UKai CN", font_size=22)
        row2_vol = MathTex("0.5 \\sim 0.7", font_size=24)

        row3_type = Text("红色 LED", font="AR PL UKai CN", font_size=22)
        row3_vol = MathTex("1.6 \\sim 1.9", font_size=24)

        row4_type = Text("蓝/白 LED", font="AR PL UKai CN", font_size=22)
        row4_vol = MathTex("2.8 \\sim 3.2", font_size=24)

        # 构建表格
        table = MobjectTable(
            [[row1_type, row1_vol],
             [row2_type, row2_vol],
             [row3_type, row3_vol],
             [row4_type, row4_vol]],
            col_labels=[header_type, header_vol],
            include_outer_lines=True,
            line_config={"stroke_width": 1, "color": BLUE_B}
        )
        table.scale(0.8).to_edge(RIGHT, buff=0.8).shift(DOWN * 0.5)

        # --- 动画流程 ---
        # 1. 显示左侧二极管和标注
        self.play(Create(diode_symbol), FadeIn(anode_txt), FadeIn(cathode_txt))

        # 2. 显示测量步骤
        self.play(Write(steps_group))

        # 3. 显示表格
        self.play(Create(table))

        # 4. 强调硅二极管(常用)
        # get_rows()[2] 对应硅二极管行 (0是表头, 1是锗, 2是硅)
        highlight_rect = SurroundingRectangle(table.get_rows()[2], color=YELLOW, buff=0.05)
        self.play(Create(highlight_rect))
