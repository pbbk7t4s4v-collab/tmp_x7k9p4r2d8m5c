from manim import *

class CapacitorSelection(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("电容选型要点:电解 vs 陶瓷",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 电解电容部分 (Electrolytic Capacitor)
        # 绘制简易电解电容图标 (圆柱体)
        elec_body = Rectangle(width=0.8, height=1.2, color=BLUE_E, fill_opacity=1)
        elec_stripe = Rectangle(width=0.2, height=1.2, color=WHITE, fill_opacity=0.3)
        elec_stripe.align_to(elec_body, LEFT)
        elec_leg1 = Line(elec_body.get_bottom() + LEFT*0.2, elec_body.get_bottom() + LEFT*0.2 + DOWN*0.4, color=GRAY)
        elec_leg2 = Line(elec_body.get_bottom() + RIGHT*0.2, elec_body.get_bottom() + RIGHT*0.2 + DOWN*0.4, color=GRAY)
        elec_icon = VGroup(elec_leg1, elec_leg2, elec_body, elec_stripe)

        # 电解电容文本
        elec_title = Text("电解电容", font="AR PL UKai CN", font_size=28, color=BLUE)
        elec_cap = Text("大容量: 1μF ~ 数千μF", font="AR PL UKai CN", font_size=24, color=WHITE)
        elec_use = Text("用途: 滤波、耦合", font="AR PL UKai CN", font_size=24, color=GRAY_A)

        elec_text_group = VGroup(elec_title, elec_cap, elec_use).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # 组合图标和文本
        elec_full_group = VGroup(elec_icon, elec_text_group).arrange(RIGHT, buff=0.8)

        # 3. 陶瓷电容部分 (Ceramic Capacitor)
        # 绘制简易陶瓷电容图标 (圆片)
        cer_body = Circle(radius=0.4, color=ORANGE, fill_opacity=1)
        cer_leg1 = Line(cer_body.get_bottom() + LEFT*0.15, cer_body.get_bottom() + LEFT*0.15 + DOWN*0.4, color=GRAY)
        cer_leg2 = Line(cer_body.get_bottom() + RIGHT*0.15, cer_body.get_bottom() + RIGHT*0.15 + DOWN*0.4, color=GRAY)
        cer_icon = VGroup(cer_leg1, cer_leg2, cer_body)

        # 陶瓷电容文本
        cer_title = Text("陶瓷电容", font="AR PL UKai CN", font_size=28, color=ORANGE)
        cer_cap = Text("小容量: 几pF ~ 1μF", font="AR PL UKai CN", font_size=24, color=WHITE)
        cer_use = Text("用途: 高频旁路、谐振电路", font="AR PL UKai CN", font_size=24, color=GRAY_A)

        cer_text_group = VGroup(cer_title, cer_cap, cer_use).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # 组合图标和文本
        cer_full_group = VGroup(cer_icon, cer_text_group).arrange(RIGHT, buff=0.8)

        # 4. 整体布局与动画
        # 将两组内容上下排列
        content_group = VGroup(elec_full_group, cer_full_group).arrange(DOWN, buff=1.2, aligned_edge=LEFT)
        content_group.move_to(ORIGIN).shift(DOWN * 0.3) # 稍微下移避开标题

        # 确保左侧图标对齐
        elec_icon.move_to(cer_icon.get_center() + UP * (elec_full_group.get_y() - cer_full_group.get_y()))
        # 重新对齐文本以适应图标调整
        elec_text_group.next_to(elec_icon, RIGHT, buff=0.8)

        # 动画展示:电解电容
        elec_box = SurroundingRectangle(elec_full_group, color=BLUE, buff=0.2)
        self.play(
            FadeIn(elec_icon, shift=RIGHT),
            Write(elec_text_group),
            run_time=1.5
        )
        self.play(Create(elec_box), run_time=0.8)

        # 动画展示:陶瓷电容
        cer_box = SurroundingRectangle(cer_full_group, color=ORANGE, buff=0.2)
        self.play(
            FadeIn(cer_icon, shift=RIGHT),
            Write(cer_text_group),
            run_time=1.5
        )
        self.play(Create(cer_box), run_time=0.8)
