from manim import *

class LocalMinVsSaddle(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("局部最小值与鞍点",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("47", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧内容:局部最小值 (Local Minimum)
        # 创建坐标系
        axes_min = Axes(
            x_range=[-2, 2, 1],
            y_range=[0, 4, 1],
            x_length=4,
            y_length=3,
            tips=False,
            axis_config={"color": GREY}
        )

        # 绘制抛物线 y = x^2
        graph_min = axes_min.plot(lambda x: x**2, color=YELLOW)
        # 标记最低点
        dot_min = Dot(axes_min.c2p(0, 0), color=RED)

        # 标签与说明
        label_min = Text("局部最小值", font="AR PL UKai CN", font_size=24, color=YELLOW)
        label_min.next_to(axes_min, UP)

        math_min = MathTex(r"\nabla L = 0", font_size=28).next_to(axes_min, DOWN)
        desc_min = Text("四周函数值均上升", font="AR PL UKai CN", font_size=20, color=WHITE).next_to(math_min, DOWN, buff=0.1)

        # 组合左侧元素
        group_min = VGroup(label_min, axes_min, graph_min, dot_min, math_min, desc_min)
        group_min.to_edge(LEFT, buff=1.0).shift(DOWN * 0.3)

        # 3. 右侧内容:鞍点 (Saddle Point)
        # 注意:此处使用 placeholder.png 展示 3D 马鞍面形状,因为 2D 难以直观展示鞍点结构
        try:
            saddle_img = ImageMobject("placeholder.png")
            saddle_img.height = 3
            saddle_img.width = 4
        except OSError:
            saddle_img = Rectangle(width=4, height=3, color=ORANGE, fill_color=ORANGE, fill_opacity=0.2)

        label_saddle = Text("鞍点", font="AR PL UKai CN", font_size=24, color=ORANGE)
        label_saddle.next_to(saddle_img, UP)

        math_saddle = MathTex(r"\nabla L = 0", font_size=28).next_to(saddle_img, DOWN)
        desc_saddle = Text("部分方向上升,部分下降", font="AR PL UKai CN", font_size=20, color=WHITE).next_to(math_saddle, DOWN, buff=0.1)

        # 组合右侧元素
        group_saddle = VGroup(label_saddle, saddle_img, math_saddle, desc_saddle)
        group_saddle.to_edge(RIGHT, buff=1.0).match_y(group_min)

        # 4. 动画展示流程

        # 展示左侧局部最小值
        self.play(FadeIn(group_min, shift=RIGHT), run_time=1.5)

        # 强调梯度为0的点
        box_min = SurroundingRectangle(dot_min, color=RED, buff=0.1)
        self.play(Create(box_min), run_time=0.5)
        self.play(Uncreate(box_min))

        # 展示右侧鞍点
        self.play(FadeIn(group_saddle, shift=LEFT), run_time=1.5)

        # 5. 底部总结对比
        summary_box = VGroup()
        summary_text = Text(
            "共同点:梯度均为 0 (临界点)\n不同点:Hessian 矩阵正定性不同",
            font="AR PL UKai CN",
            font_size=24,
            color=BLUE_B,
            line_spacing=0.8
        )
        summary_text.move_to(DOWN * 3)

        self.play(Write(summary_text))

        # 最终停留
