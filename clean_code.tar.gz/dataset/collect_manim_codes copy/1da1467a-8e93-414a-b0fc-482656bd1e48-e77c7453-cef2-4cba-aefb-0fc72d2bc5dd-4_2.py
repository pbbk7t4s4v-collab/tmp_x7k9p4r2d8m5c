from manim import *

class StorageHierarchyDiff(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("层级之间速度/价格/容量差异",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("17", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 构建存储层次金字塔结构
        # ---------------------------------------------------------

        # 定义每一层的属性
        # 顶层：速度快、贵、小
        top_rect = Rectangle(width=3, height=1, color=RED, fill_opacity=0.5)
        top_text = Text("寄存器 / 缓存", font="AR PL UKai CN", font_size=24).move_to(top_rect)
        top_group = VGroup(top_rect, top_text)

        # 中层：适中
        mid_rect = Rectangle(width=5, height=1, color=BLUE, fill_opacity=0.5)
        mid_text = Text("主存储器 (RAM)", font="AR PL UKai CN", font_size=24).move_to(mid_rect)
        mid_group = VGroup(mid_rect, mid_text)

        # 底层：速度慢、便宜、大
        bot_rect = Rectangle(width=7, height=1, color=GREEN, fill_opacity=0.5)
        bot_text = Text("辅助存储器 (硬盘/磁带)", font="AR PL UKai CN", font_size=24).move_to(bot_rect)
        bot_group = VGroup(bot_rect, bot_text)

        # 排列位置：从上到下
        pyramid = VGroup(top_group, mid_group, bot_group).arrange(DOWN, buff=0)
        pyramid.move_to(ORIGIN).shift(DOWN * 0.5) # 整体稍微下移，留出标题空间

        # ---------------------------------------------------------
        # 3. 添加趋势箭头和说明文字
        # ---------------------------------------------------------

        # 左侧箭头：向上（速度、价格）
        left_arrow = Arrow(start=bot_rect.get_left() + LEFT * 0.5,
                           end=top_rect.get_left() + LEFT * 0.5 + UP * 0.5,
                           buff=0.2, color=YELLOW)

        speed_text = Text("速度越快", font="AR PL UKai CN", font_size=20, color=YELLOW)
        price_text = Text("价格越高", font="AR PL UKai CN", font_size=20, color=YELLOW)

        # 将文字放在箭头左侧
        left_labels = VGroup(speed_text, price_text).arrange(DOWN, buff=0.2).next_to(left_arrow, LEFT)

        # 右侧箭头：向下（容量）
        right_arrow = Arrow(start=top_rect.get_right() + RIGHT * 0.5,
                            end=bot_rect.get_right() + RIGHT * 0.5 + DOWN * 0.5,
                            buff=0.2, color=TEAL)

        capacity_text = Text("容量越大", font="AR PL UKai CN", font_size=20, color=TEAL)
        right_labels = VGroup(capacity_text).next_to(right_arrow, RIGHT)

        # ---------------------------------------------------------
        # 4. 动画展示流程
        # ---------------------------------------------------------

        # 逐步显示金字塔层级
        self.play(FadeIn(bot_group, shift=UP), run_time=0.8)
        self.play(FadeIn(mid_group, shift=UP), run_time=0.8)
        self.play(FadeIn(top_group, shift=UP), run_time=0.8)

        # 显示左侧趋势（速度/价格）
        self.play(
            GrowArrow(left_arrow),
            Write(left_labels),
            run_time=1.2
        )

        # 显示右侧趋势（容量）
        self.play(
            GrowArrow(right_arrow),
            Write(right_labels),
            run_time=1.2
        )

        # 强调框：突出顶层和底层的对比
        rect_highlight = SurroundingRectangle(top_group, color=YELLOW, buff=0.05)
        self.play(Create(rect_highlight), run_time=0.5)
        self.play(rect_highlight.animate.move_to(bot_group), run_time=1)
        self.play(FadeOut(rect_highlight), run_time=0.5)
