from manim import *

class MedicalRehabilitationScene(Scene):
    def construct(self):

        # 1. 标题
        title = Text("AI驱动的医疗康复：下肢外骨骼机器人",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 创建患者与外骨骼的简化图形
        patient_head = Circle(radius=0.2, color=BLUE_C).shift(UP*1.5)
        patient_body = Line(patient_head.get_bottom(), patient_head.get_bottom() + DOWN*1.2, color=BLUE_C)
        patient_legs = VGroup(
            Line(patient_body.get_end(), patient_body.get_end() + DL*1, color=BLUE_C),
            Line(patient_body.get_end(), patient_body.get_end() + DR*1, color=BLUE_C)
        )
        patient_figure = VGroup(patient_head, patient_body, patient_legs)
        exo_legs = VGroup(
            Line(patient_body.get_end(), patient_body.get_end() + DL*1.1, color=YELLOW, stroke_width=7),
            Line(patient_body.get_end(), patient_body.get_end() + DR*1.1, color=YELLOW, stroke_width=7)
        )
        patient_group = VGroup(patient_figure, exo_legs).scale(1.2).to_edge(LEFT, buff=1.5)
        patient_label = Text("患者与外骨骼", font="AR PL UKai CN", font_size=28).next_to(patient_group, DOWN, buff=0.3)

        self.play(FadeIn(patient_group, shift=UP*0.5), Write(patient_label))

        # 3. 创建系统流程图
        font_style = {"font": "AR PL UKai CN", "font_size": 26}

        # 输入模块
        input1_text = Text("肌电信号 (EMG)", **font_style)
        input1_box = SurroundingRectangle(input1_text, buff=0.2, corner_radius=0.1, color=TEAL)
        input1 = VGroup(input1_text, input1_box)

        input2_text = Text("身体姿态 (IMU)", **font_style)
        input2_box = SurroundingRectangle(input2_text, buff=0.2, corner_radius=0.1, color=TEAL)
        input2 = VGroup(input2_text, input2_box)

        inputs_group = VGroup(input1, input2).arrange(DOWN, buff=0.5).shift(RIGHT*2.5 + UP*2)

        # AI模型模块
        ai_text = Text("AI模型\n预测步伐意图", **font_style, line_spacing=0.8)
        ai_box = SurroundingRectangle(ai_text, buff=0.25, color=ORANGE, corner_radius=0.1)
        ai_model = VGroup(ai_text, ai_box).next_to(inputs_group, DOWN, buff=1.2)

        # 输出模块
        output_text = Text("关节电机", **font_style)
        output_box = SurroundingRectangle(output_text, buff=0.2, corner_radius=0.1, color=MAROON_B)
        output_model = VGroup(output_text, output_box).next_to(ai_model, DOWN, buff=1.2)

        # 4. 动画化展示流程
        self.play(FadeIn(inputs_group))

        arrow_to_ai_1 = Arrow(input1.get_bottom(), ai_model.get_top(), buff=0.1)
        arrow_to_ai_2 = Arrow(input2.get_bottom(), ai_model.get_top(), buff=0.1)
        self.play(
            FadeIn(ai_model),
            Create(arrow_to_ai_1),
            Create(arrow_to_ai_2),
            run_time=1.0
        )

        arrow_to_output = Arrow(ai_model.get_bottom(), output_model.get_top(), buff=0.1)
        self.play(
            FadeIn(output_model),
            Create(arrow_to_output),
            run_time=1.0
        )

        # 5. 执行与反馈循环
        action_arrow = CurvedArrow(output_model.get_left(), patient_group.get_right() + DOWN*0.5, angle=-PI/2, color=YELLOW)
        action_text = Text("提供助力扭矩", font="AR PL UKai CN", font_size=24, color=YELLOW).next_to(action_arrow, UP, buff=-0.2)
        self.play(Create(action_arrow), Write(action_text))

        feedback_arrow = CurvedArrow(patient_group.get_top() + RIGHT*0.5, inputs_group.get_left(), angle=PI*0.8, color=GREEN)
        feedback_text = Text("逐步减少辅助\n促进主动康复", font="AR PL UKai CN", font_size=24, color=GREEN, line_spacing=0.7).next_to(feedback_arrow, UP, buff=0.1).shift(RIGHT*0.5)

        self.play(Create(feedback_arrow), Write(feedback_text))
