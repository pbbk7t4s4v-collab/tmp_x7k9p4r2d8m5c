from manim import *

class CubicEquationHistory(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("三次方程突破与复数萌芽",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心数学问题展示
        # 顶部展示三次方程
        equation = MathTex(r"x^3 + px + q = 0", color=BLUE_B, font_size=48)
        equation_label = Text("三次方程求解问题", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        equation_label.next_to(equation, UP, buff=0.1)

        eq_group = VGroup(equation, equation_label).move_to(UP * 1.5)

        self.play(FadeIn(eq_group, shift=DOWN))

        # 3. 历史人物与事件流程
        # 左侧:最早求解者
        solver_text = Text("菲奥尔 & 塔塔利亚\n(最早求解)", font="AR PL UKai CN", font_size=24, line_spacing=1.2)
        solver_box = SurroundingRectangle(solver_text, color=YELLOW, buff=0.2)
        solver_group = VGroup(solver_box, solver_text).move_to(LEFT * 3.5 + DOWN * 0.5)

        # 右侧:卡当与大术
        cardano_text = Text("卡当 (1545)\n发表《大术》", font="AR PL UKai CN", font_size=24, line_spacing=1.2)
        cardano_box = SurroundingRectangle(cardano_text, color=ORANGE, buff=0.2)
        cardano_group = VGroup(cardano_box, cardano_text).move_to(RIGHT * 3.5 + DOWN * 0.5)

        # 箭头连接
        arrow_solve = Arrow(start=eq_group.get_bottom(), end=solver_box.get_top(), color=GREY)
        arrow_transfer = Arrow(start=solver_box.get_right(), end=cardano_box.get_left(), color=WHITE, buff=0.1)
        transfer_label = Text("解法流传", font="AR PL UKai CN", font_size=18, color=GREY_A).next_to(arrow_transfer, UP, buff=0.05)

        self.play(
            Create(arrow_solve),
            Write(solver_group),
            run_time=1.5
        )
        self.play(
            GrowArrow(arrow_transfer),
            FadeIn(transfer_label),
            Write(cardano_group),
            run_time=1.5
        )

        # 4. 产生的影响(底部)
        # 影响1:复数
        impact_complex = VGroup(
            Text("复数雏形", font="AR PL UKai CN", font_size=26, color=GREEN),
            MathTex(r"\sqrt{-1}", color=GREEN)
        ).arrange(DOWN, buff=0.1)

        # 影响2:争端
        impact_dispute = VGroup(
            Text("优先权争端", font="AR PL UKai CN", font_size=26, color=RED),
            Text("数学史公案", font="AR PL UKai CN", font_size=20, color=RED_B)
        ).arrange(DOWN, buff=0.1)

        impact_group = VGroup(impact_complex, impact_dispute).arrange(RIGHT, buff=4).move_to(DOWN * 2.5)

        # 从卡当指向影响的线条
        line_to_complex = DashedLine(cardano_box.get_bottom(), impact_complex.get_top(), color=GREEN_B)
        line_to_dispute = DashedLine(cardano_box.get_bottom(), impact_dispute.get_top(), color=RED_B)

        self.play(
            Create(line_to_complex),
            Create(line_to_dispute),
            FadeIn(impact_group, shift=UP),
            run_time=2
        )
