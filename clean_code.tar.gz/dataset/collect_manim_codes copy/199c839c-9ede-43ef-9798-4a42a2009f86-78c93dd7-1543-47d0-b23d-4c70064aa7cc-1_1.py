from manim import *

class PhilosophyObjectChange(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (按照模板要求)
        # ---------------------------------------------------------
        title = Text("哲学对象的转变:从抽象的人到现实的人",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局设计
        # ---------------------------------------------------------

        # 左侧:旧哲学
        left_label = Text("旧哲学", font="AR PL UKai CN", font_size=28, color=GREY_B)
        left_concept = Text("抽象的人", font="AR PL UKai CN", font_size=40, color=BLUE)
        left_desc = Text("脱离社会关系\n孤立的个体\n仅靠精神活动",
                        font="AR PL UKai CN", font_size=20, color=BLUE_C, line_spacing=0.8)

        left_group = VGroup(left_label, left_concept, left_desc).arrange(DOWN, buff=0.4)
        left_box = SurroundingRectangle(left_group, color=BLUE, buff=0.3)
        left_full = VGroup(left_box, left_group).to_edge(LEFT, buff=1.5).shift(DOWN * 0.5)

        # 右侧:马克思主义哲学
        right_label = Text("马克思主义哲学", font="AR PL UKai CN", font_size=28, color=ORANGE)
        right_concept = Text("现实的人", font="AR PL UKai CN", font_size=40, color=RED)
        right_desc = Text("一切社会关系的总和\n从事物质生产\n历史的、具体的",
                         font="AR PL UKai CN", font_size=20, color=RED_C, line_spacing=0.8)

        right_group = VGroup(right_label, right_concept, right_desc).arrange(DOWN, buff=0.4)
        right_box = SurroundingRectangle(right_group, color=RED, buff=0.3)
        right_full = VGroup(right_box, right_group).to_edge(RIGHT, buff=1.5).shift(DOWN * 0.5)

        # 中间:转变过程箭头
        arrow = Arrow(start=left_box.get_right(), end=right_box.get_left(), color=YELLOW, buff=0.2)
        arrow_text = Text("革命性变革", font="AR PL UKai CN", font_size=24, color=YELLOW).next_to(arrow, UP, buff=0.1)

        # ---------------------------------------------------------
        # 3. 动画展示流程
        # ---------------------------------------------------------

        # 第一步:展示旧哲学观念
        self.play(
            Create(left_box),
            FadeIn(left_group, shift=UP),
            run_time=1.5
        )

        # 第二步:展示变革过程(箭头)
        self.play(
            GrowArrow(arrow),
            Write(arrow_text),
            run_time=1.0
        )

        # 第三步:展示马克思主义哲学观念
        self.play(
            Create(right_box),
            FadeIn(right_group, shift=UP),
            run_time=1.5
        )

        # 第四步:强调核心区别(高亮两个核心概念)
        self.play(
            Indicate(left_concept, color=PURE_BLUE),
            Indicate(right_concept, color=PURE_RED),
            run_time=1.0
        )
