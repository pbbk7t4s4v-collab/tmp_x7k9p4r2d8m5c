from manim import *

class PreOrderTraversalScene(Scene):
    def construct(self):

        # 1. 创建标题
        title = Text("二叉树的前序遍历",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 创建二叉树节点和边
        nodes = {}
        node_positions = {
            'A': UP * 2,
            'B': LEFT * 2,
            'C': RIGHT * 2,
            'D': LEFT * 3.5 + DOWN * 1.5,
            'E': LEFT * 0.5 + DOWN * 1.5,
            'F': RIGHT * 3.5 + DOWN * 1.5
        }

        for name, pos in node_positions.items():
            circle = Circle(radius=0.35, color=BLUE, fill_opacity=0.8)
            text = Text(name, font_size=28, color=WHITE)
            nodes[name] = VGroup(circle, text).move_to(pos)

        edges = VGroup(
            Line(nodes['A'].get_bottom(), nodes['B'].get_top(), buff=0.1),
            Line(nodes['A'].get_bottom(), nodes['C'].get_top(), buff=0.1),
            Line(nodes['B'].get_bottom(), nodes['D'].get_top(), buff=0.1),
            Line(nodes['B'].get_bottom(), nodes['E'].get_top(), buff=0.1),
            Line(nodes['C'].get_bottom(), nodes['F'].get_top(), buff=0.1)
        )

        tree = VGroup(*nodes.values(), edges)
        tree.scale(0.8).move_to(LEFT * 3.5 + DOWN * 0.5)

        self.play(Create(edges), FadeIn(*nodes.values(), scale=0.5), run_time=1.5)

        # 3. 展示前序遍历顺序和解析
        right_panel = VGroup().move_to(RIGHT * 3.5)

        # 遍历顺序标题
        order_title = Text("前序遍历顺序为：", font="AR PL UKai CN", font_size=28)
        order_title.next_to(right_panel, UP, buff=0).align_to(right_panel, LEFT)

        # 遍历顺序文本
        sequence = MathTex("A", "\\rightarrow", "B", "\\rightarrow", "D", "\\rightarrow", "E", "\\rightarrow", "C", "\\rightarrow", "F", font_size=40)
        sequence.next_to(order_title, DOWN, buff=0.4)

        self.play(Write(order_title))

        # 4. 动态展示遍历过程
        traversal_order = ['A', 'B', 'D', 'E', 'C', 'F']
        highlight_box = SurroundingRectangle(nodes['A'], color=YELLOW, buff=0.1)

        self.play(Create(highlight_box))
        self.play(Write(sequence[0])) # A

        for i, node_name in enumerate(traversal_order[1:]):
            self.play(highlight_box.animate.move_to(nodes[node_name].get_center()), run_time=0.6)
            self.play(Write(sequence[2*i+1:2*i+3]), run_time=0.4) # -> B, -> D, etc.

        self.play(FadeOut(highlight_box))

        # 5. 显示解析步骤
        explanation_title = Text("解析:", font="AR PL UKai CN", font_size=24, weight=BOLD)
        explanation_items = VGroup(
            Text("1. 首先访问根节点 A", font="AR PL UKai CN", font_size=24),
            Text("2. 遍历左子树 (根 B → 左 D → 右 E)", font="AR PL UKai CN", font_size=24),
            Text("3. 遍历右子树 (根 C → 左空 → 右 F)", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.25)

        explanation = VGroup(explanation_title, explanation_items).arrange(DOWN, aligned_edge=LEFT, buff=0.3)
        explanation.next_to(sequence, DOWN, buff=0.8).align_to(order_title, LEFT)

        self.play(FadeIn(explanation, shift=UP))
