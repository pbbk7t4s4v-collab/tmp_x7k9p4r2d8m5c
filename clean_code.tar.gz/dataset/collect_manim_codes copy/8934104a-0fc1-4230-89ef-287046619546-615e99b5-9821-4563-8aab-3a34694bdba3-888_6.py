from manim import *

class DecisionTreeCoreConcepts(Scene):
    def construct(self):

        # 1. 标题部分
        title = Text("决策树生成的三个核心问题",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧：可视化“分而治之”与递归
        # 定义节点样式
        node_radius = 0.4
        root_node = Circle(radius=node_radius, color=BLUE, fill_opacity=0.8)
        root_text = Text("数据集", font="AR PL UKai CN", font_size=18).move_to(root_node)
        root_group = VGroup(root_node, root_text).move_to(LEFT * 3.5 + UP * 0.5)

        # 子节点
        left_node = Circle(radius=node_radius*0.8, color=GREEN, fill_opacity=0.8)
        left_text = Text("子集1", font="AR PL UKai CN", font_size=16).move_to(left_node)
        left_group = VGroup(left_node, left_text).move_to(LEFT * 5 + DOWN * 1.5)

        right_node = Circle(radius=node_radius*0.8, color=GREEN, fill_opacity=0.8)
        right_text = Text("子集2", font="AR PL UKai CN", font_size=16).move_to(right_node)
        right_group = VGroup(right_node, right_text).move_to(LEFT * 2 + DOWN * 1.5)

        # 连线
        line_l = Line(root_node.get_bottom(), left_node.get_top(), color=GREY)
        line_r = Line(root_node.get_bottom(), right_node.get_top(), color=GREY)

        # 策略说明文字
        strategy_label = Text("策略：分而治之 / 递归", font="AR PL UKai CN", font_size=24, color=YELLOW)
        strategy_label.next_to(root_group, UP, buff=0.5)

        # 动画展示左侧结构
        self.play(FadeIn(root_group), Write(strategy_label))
        self.play(
            Create(line_l), Create(line_r),
            GrowFromCenter(left_group), GrowFromCenter(right_group),
            run_time=1.5
        )

        # 3. 右侧：三个核心问题列表
        # 使用VGroup手动排版以确保对齐和无重叠

        # 问题1：划分标准
        q1_title = Text("1. 划分标准 (Splitting)", font="AR PL UKai CN", font_size=26, color=BLUE_A)
        q1_detail = Text("如何量化属性重要性？选择谁分裂？", font="AR PL UKai CN", font_size=20, color=WHITE)
        q1_group = VGroup(q1_title, q1_detail).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # 问题2：停止条件
        q2_title = Text("2. 停止条件 (Stopping)", font="AR PL UKai CN", font_size=26, color=BLUE_B)
        q2_detail = Text("何时停止？纯度达标或深度限制？", font="AR PL UKai CN", font_size=20, color=WHITE)
        q2_group = VGroup(q2_title, q2_detail).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # 问题3：泛化能力
        q3_title = Text("3. 泛化能力 (Generalization)", font="AR PL UKai CN", font_size=26, color=BLUE_C)
        q3_detail = Text("如何避免过拟合？预测新数据？", font="AR PL UKai CN", font_size=20, color=WHITE)
        q3_group = VGroup(q3_title, q3_detail).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        # 组合右侧内容
        text_block = VGroup(q1_group, q2_group, q3_group).arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        text_block.move_to(RIGHT * 2.5)

        # 添加外框强调
        frame = SurroundingRectangle(text_block, color=TEAL, buff=0.3)

        # 依次展示右侧问题
        self.play(Create(frame), run_time=0.5)
        self.play(
            FadeIn(q1_group, shift=LEFT),
            run_time=0.8
        )
        self.play(
            FadeIn(q2_group, shift=LEFT),
            run_time=0.8
        )
        self.play(
            FadeIn(q3_group, shift=LEFT),
            run_time=0.8
        )

        # 4. 这里的箭头指向说明关联
        arrow = Arrow(start=right_group.get_right(), end=frame.get_left(), buff=0.2, color=YELLOW)
        arrow_text = Text("核心难点", font="AR PL UKai CN", font_size=18, color=YELLOW).next_to(arrow, UP, buff=0.05)

        self.play(GrowArrow(arrow), Write(arrow_text))
