from manim import *

class SingleProgramToDisk(Scene):
    def construct(self):

        # 1. 标题部分 (严格按照模板)
        title = Text("单道程序低效与磁盘技术的引入",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("20", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧展示：单道程序的低效问题
        # 创建 CPU 和 I/O 框图
        cpu_rect = Rectangle(width=2, height=1.5, color=BLUE)
        cpu_text = Text("CPU", font="AR PL UKai CN", font_size=24).move_to(cpu_rect.get_center())
        cpu_group = VGroup(cpu_rect, cpu_text)

        io_rect = Rectangle(width=2, height=1.5, color=GREEN)
        io_text = Text("I/O设备", font="AR PL UKai CN", font_size=24).move_to(io_rect.get_center())
        io_group = VGroup(io_rect, io_text)

        # 布局：左侧上下排列，或者水平排列
        hw_group = VGroup(cpu_group, io_group).arrange(RIGHT, buff=2)
        hw_group.move_to(LEFT * 3 + UP * 0.5)

        # 创建“程序”块
        program = Rectangle(width=0.8, height=0.8, fill_color=YELLOW, fill_opacity=0.8, color=YELLOW)
        program_label = Text("程序", font="AR PL UKai CN", font_size=20, color=BLACK).move_to(program)
        prog_group = VGroup(program, program_label)

        # 初始位置在 CPU
        prog_group.move_to(cpu_rect.get_center())

        # 标签：单道处理
        section_label = Text("单道处理模式", font="AR PL UKai CN", font_size=28, color=GREY_B)
        section_label.next_to(hw_group, UP, buff=0.5)

        self.play(
            FadeIn(section_label),
            Create(cpu_group),
            Create(io_group),
            FadeIn(prog_group)
        )

        # 动画：程序请求 I/O，离开 CPU
        arrow = Arrow(cpu_rect.get_right(), io_rect.get_left(), color=WHITE, buff=0.1)
        io_req_text = Text("请求I/O", font="AR PL UKai CN", font_size=18).next_to(arrow, UP, buff=0.05)

        self.play(GrowArrow(arrow), FadeIn(io_req_text))
        self.play(prog_group.animate.move_to(io_rect.get_center()), run_time=1.5)

        # 强调 CPU 空闲
        idle_text = Text("CPU 闲置！", font="AR PL UKai CN", font_size=30, color=RED)
        idle_text.move_to(cpu_rect.get_center())

        idle_rect = SurroundingRectangle(cpu_rect, color=RED, buff=0.1)

        self.play(
            FadeIn(idle_text),
            Create(idle_rect)
        )

        # 3. 右侧展示：磁盘设备的引入（解决方案）
        # 引入图片
        img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/1da1467a-8e93-414a-b0fc-482656bd1e48/96b02fe1-9dea-47ad-af3d-c0d2f4cb13e7/pictures/888_20/1.png") # 这里期望是一张展示机械硬盘内部结构的特写图片，要求画面清晰展示银色的圆形磁盘盘片和悬停在上面的机械读写磁头臂，写实科技风

        # 设置图片大小和位置
        img.height = 3.0  # 控制高度
        img.to_edge(RIGHT, buff=1).shift(UP * 0.5)

        # 图片说明
        disk_title = Text("磁盘设备出现", font="AR PL UKai CN", font_size=28, color=YELLOW)
        disk_title.next_to(img, UP, buff=0.2)

        feature_text = Text("特性：随机访问", font="AR PL UKai CN", font_size=24)
        feature_text.next_to(img, DOWN, buff=0.2)

        result_text = Text("支持程序快速切换", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        result_text.next_to(feature_text, DOWN, buff=0.2)

        # 播放右侧动画
        self.play(
            FadeIn(img),
            Write(disk_title)
        )
        self.play(
            Write(feature_text),
            Write(result_text)
        )

        # 4. 建立联系
        # 从磁盘指向左侧，暗示解决了问题
        connection_arrow = Arrow(img.get_left(), idle_rect.get_right(), color=YELLOW)
        solve_text = Text("允许多道程序驻留内存", font="AR PL UKai CN", font_size=22, color=YELLOW)
        solve_text.next_to(connection_arrow, UP, buff=0.1)

        self.play(
            GrowArrow(connection_arrow),
            FadeIn(solve_text)
        )
