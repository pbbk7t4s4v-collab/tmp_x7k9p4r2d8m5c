from manim import *

class PreorderRecursiveImplementation(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("前序遍历的递归实现",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("23", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 代码展示区域 (左侧)
        # ---------------------------------------------------------
        code_str = """def preorder(node):
    if node is None:
        return
    visit(node)
    preorder(node.left)
    preorder(node.right)"""

        # 创建代码对象(自定义,兼容当前环境)
        code_lines_list = []
        for i, line in enumerate(code_str.split("\n"), start=1):
            code_line = Text(f"{i:>2} {line}", font="Monospace", font_size=24, color=WHITE)
            code_lines_list.append(code_line)
        code_lines_group = VGroup(*code_lines_list).arrange(DOWN, buff=0.2, aligned_edge=LEFT)

        code_bg = SurroundingRectangle(code_lines_group, color=GRAY_B, fill_opacity=0.15, buff=0.3)
        header_bar = Rectangle(width=code_bg.width, height=0.3, color=GRAY_B, fill_opacity=0.2)
        header_bar.move_to(code_bg.get_top(), aligned_edge=UP)

        code_obj = VGroup(code_bg, header_bar, code_lines_group)

        # 调整代码大小和位置
        code_obj.scale(0.85).to_edge(LEFT, buff=1).shift(DOWN * 0.5)

        # ---------------------------------------------------------
        # 3. 逻辑说明区域 (右侧)
        # ---------------------------------------------------------
        # 使用简单的文本展示核心步骤
        step1 = Text("1. 访问根节点 (Root)", font="AR PL UKai CN", font_size=26, color=YELLOW)
        step2 = Text("2. 递归遍历左子树 (Left)", font="AR PL UKai CN", font_size=26, color=BLUE)
        step3 = Text("3. 递归遍历右子树 (Right)", font="AR PL UKai CN", font_size=26, color=GREEN)

        steps_group = VGroup(step1, step2, step3).arrange(DOWN, buff=0.8, aligned_edge=LEFT)
        steps_group.next_to(code_obj, RIGHT, buff=1.5)

        # ---------------------------------------------------------
        # 4. 动画流程
        # ---------------------------------------------------------

        # 淡入代码块
        self.play(FadeIn(code_obj))

        # 获取代码行对象 (code_obj[2] 是代码内容的 VGroup)
        # 索引对应:0:def, 1:if, 2:return, 3:visit, 4:preorder(left), 5:preorder(right)
        code_lines = code_obj[2]

        # 步骤 1: visit(node)
        rect1 = SurroundingRectangle(code_lines[3], color=YELLOW, buff=0.05, stroke_width=2)
        self.play(
            Create(rect1),
            Write(step1),
            run_time=1
        )

        # 步骤 2: preorder(node.left)
        rect2 = SurroundingRectangle(code_lines[4], color=BLUE, buff=0.05, stroke_width=2)
        self.play(
            ReplacementTransform(rect1, rect2),
            Write(step2),
            run_time=1
        )

        # 步骤 3: preorder(node.right)
        rect3 = SurroundingRectangle(code_lines[5], color=GREEN, buff=0.05, stroke_width=2)
        self.play(
            ReplacementTransform(rect2, rect3),
            Write(step3),
            run_time=1
        )

        # 最后的强调效果
        full_rect = SurroundingRectangle(steps_group, color=WHITE, buff=0.3)
        self.play(Create(full_rect), run_time=1)
