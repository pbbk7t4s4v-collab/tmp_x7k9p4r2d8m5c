from manim import *

class HighDimExamples(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (标准模板)
        # ---------------------------------------------------------
        title = Text("高维复杂函数的直观实例：围棋与人脸识别",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 左侧：围棋例子 (极大的状态空间)
        # ---------------------------------------------------------
        # 创建一个简化的围棋盘面示意图
        board_bg = Square(side_length=2.5, color="#DCB35C", fill_opacity=1) # 木色背景
        grid_lines = VGroup()
        for i in range(5):
            # 横线
            h_line = Line(start=board_bg.get_left() + RIGHT*0.25 + UP*(1-i*0.5),
                          end=board_bg.get_right() + LEFT*0.25 + UP*(1-i*0.5),
                          color=BLACK, stroke_width=2)
            # 竖线
            v_line = Line(start=board_bg.get_top() + DOWN*0.25 + RIGHT*(1-i*0.5),
                          end=board_bg.get_bottom() + UP*0.25 + RIGHT*(1-i*0.5),
                          color=BLACK, stroke_width=2)
            grid_lines.add(h_line, v_line)

        # 添加几颗棋子
        stones = VGroup(
            Dot(point=grid_lines[0].get_center() + LEFT*0.5, color=BLACK, radius=0.15),
            Dot(point=grid_lines[0].get_center() + RIGHT*0.5 + UP*0.5, color=WHITE, radius=0.15),
            Dot(point=grid_lines[0].get_center() + DOWN*0.5, color=BLACK, radius=0.15),
        )

        go_visual = VGroup(board_bg, grid_lines, stones)

        # 围棋说明文字
        go_title = Text("围棋 (Go)", font="AR PL UKai CN", font_size=28, color=YELLOW)
        go_desc1 = Text("规则简单,状态无限", font="AR PL UKai CN", font_size=20)
        go_desc2 = Text("目标:寻找最优策略", font="AR PL UKai CN", font_size=20)

        # 核心映射公式
        go_math = MathTex(r"f(\text{Board}) \to \text{BestMove}", font_size=26)

        # 组合左侧内容
        left_content = VGroup(go_title, go_visual, go_desc1, go_desc2, go_math)
        left_content.arrange(DOWN, buff=0.3)
        left_content.to_edge(LEFT, buff=1.5).shift(DOWN*0.5)

        # ---------------------------------------------------------
        # 3. 右侧:人脸识别 (高维特征提取)
        # ---------------------------------------------------------
        # 此处使用placeholder图片,实际教学中替换为具体人脸图
        # 注释:这里展示一张人脸图像的占位符,代表高维像素输入
        try:
            face_image = ImageMobject("placeholder.png")
            face_image.height = 2.5
            face_image.width = 2.5
        except Exception:
            face_image = None
        # 如果没有图片,用一个带文字的方框代替,防止报错,保证代码可运行
        face_placeholder = VGroup(
            Square(side_length=2.5, color=BLUE, fill_opacity=0.2),
            Text("Input Image\n(Pixels)", font="AR PL UKai CN", font_size=20)
        )

        face_title = Text("人脸识别", font="AR PL UKai CN", font_size=28, color=BLUE)

        # 使用VGroup手动创建列表,避免BulletList的排版问题
        face_challenges = VGroup(
            Text("• 挑战:光照、角度、表情", font="AR PL UKai CN", font_size=20),
            Text("• 提取稳定的身份特征", font="AR PL UKai CN", font_size=20)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        # 核心映射公式
        face_math = MathTex(r"g(\text{Pixels}) \to \text{Identity}", font_size=26)

        # 组合右侧内容
        right_content = VGroup(face_title, face_placeholder, face_challenges, face_math)
        right_content.arrange(DOWN, buff=0.3)
        right_content.to_edge(RIGHT, buff=1.5).shift(DOWN*0.5)

        # ---------------------------------------------------------
        # 4. 底部总结:深度神经网络的作用
        # ---------------------------------------------------------
        summary_text = Text("深度神经网络:逼近从输入到输出的高维映射",
                           font="AR PL UKai CN", font_size=24, color=ORANGE)
        summary_box = SurroundingRectangle(summary_text, color=WHITE, buff=0.2)
        summary_group = VGroup(summary_box, summary_text)
        summary_group.to_edge(DOWN, buff=0.5)

        # ---------------------------------------------------------
        # 5. 动画播放流程
        # ---------------------------------------------------------
        # 分别显示左右两部分
        self.play(FadeIn(left_content, shift=RIGHT), run_time=1.5)
        self.play(FadeIn(right_content, shift=LEFT), run_time=1.5)

        # 强调中间的数学映射关系
        self.play(
            Indicate(go_math, color=YELLOW),
            Indicate(face_math, color=BLUE)
        )

        # 显示底部总结
        self.play(Create(summary_box), Write(summary_text))
