from manim import *

class MLPvsCNN(Scene):
    def construct(self):

        # ---------------------------------------------------------------------
        # 1. 标题设置 (严格遵守模板)
        # ---------------------------------------------------------------------
        title = Text("传统MLP的局限与CNN的引入",
                    font_size=51,  # 原34 * 1.5 = 51
                    font="AR PL UKai CN", # 字体
                    color=BLUE,   # 改为蓝色
                    weight=BOLD,   # 加粗
                    slant=ITALIC)   # 斜体
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------------------
        # 2. 页面布局规划 (左右分栏)
        # ---------------------------------------------------------------------
        # 左侧:MLP 问题
        left_center = LEFT * 3.5
        # 右侧:CNN 优势
        right_center = RIGHT * 3.5

        # 分隔线
        separator = DashedLine(UP * 2, DOWN * 2, color=GRAY)
        self.play(Create(separator))

        # ---------------------------------------------------------------------
        # 3. 左侧内容:传统 MLP 的问题
        # ---------------------------------------------------------------------

        # 3.2 可视化:图片展平
        # 创建一个 3x3 的网格代表图像
        grid_mlp = VGroup(*[Square(side_length=0.4) for _ in range(9)])
        grid_mlp.arrange_in_grid(3, 3, buff=0)
        grid_mlp.move_to(left_center + UP * 0.5)

        # 箭头指向
        arrow_mlp = Arrow(start=UP, end=DOWN, color=WHITE).next_to(grid_mlp, DOWN, buff=0.2)
        arrow_mlp.scale(0.6)

        # 展平后的向量 (长条)
        flattened_vector = VGroup(*[Square(side_length=0.2, fill_opacity=0.5, fill_color=BLUE) for _ in range(9)])
        flattened_vector.arrange(RIGHT, buff=0.05)
        flattened_vector.next_to(arrow_mlp, DOWN, buff=0.2)

        # 3.3 缺点文本
        issue_1 = Text("输入需展平:丢失空间结构", font="AR PL UKai CN", font_size=20, color=RED_A)
        issue_2 = Text("全连接:参数量过大", font="AR PL UKai CN", font_size=20, color=RED_A)

        issue_group = VGroup(issue_1, issue_2).arrange(DOWN, buff=0.2)
        issue_group.next_to(flattened_vector, DOWN, buff=0.5)

        # 动画展示左侧
        self.play(Create(grid_mlp))
        self.play(GrowArrow(arrow_mlp), TransformFromCopy(grid_mlp, flattened_vector))
        self.play(Write(issue_group))

        # ---------------------------------------------------------------------
        # 4. 右侧内容:CNN 的引入
        # ---------------------------------------------------------------------

        # 4.1 CNN 标题
        cnn_part1 = Text("卷积神经网络", font="AR PL UKai CN", font_size=32, color=YELLOW, weight=BOLD)
        cnn_part2 = Text(" (CNN)", font="AR PL UKai CN", font_size=28, color=GREEN_B)
        cnn_title = VGroup(cnn_part1, cnn_part2).arrange(RIGHT, buff=0)
        cnn_title.move_to(right_center + UP * 2)

        # 4.2 可视化:局部连接
        # 同样的 3x3 网格
        grid_cnn = VGroup(*[Square(side_length=0.4, color=WHITE) for _ in range(9)])
        grid_cnn.arrange_in_grid(3, 3, buff=0)
        grid_cnn.move_to(right_center + UP * 0.5)

        # 卷积核 (黄色框)
        kernel_rect = SurroundingRectangle(grid_cnn[0:2], color=YELLOW, buff=0.05)
        # 注意:这里只是简单示意左上角的局部区域,不严格对应 grid 索引逻辑,仅做视觉演示
        # 实际上 Manim 的 Grid 索引可能不同,这里手动创建一个框盖住左上角
        kernel_visual = Square(side_length=0.85, color=YELLOW, stroke_width=4).move_to(grid_cnn.get_corner(UL) + DR * 0.42)

        # 箭头
        arrow_cnn = Arrow(start=LEFT, end=RIGHT, color=WHITE).next_to(grid_cnn, RIGHT, buff=0.2)
        arrow_cnn.scale(0.6)

        # 特征图 (Feature Map) - 较小的网格
        feature_map = VGroup(*[Square(side_length=0.4, fill_opacity=0.5, fill_color=GREEN) for _ in range(4)])
        feature_map.arrange_in_grid(2, 2, buff=0)
        feature_map.next_to(arrow_cnn, RIGHT, buff=0.2)

        # 4.3 优点文本
        benefit_1 = Text("局部连接:保留空间特征", font="AR PL UKai CN", font_size=20, color=GREEN_A)
        benefit_2 = Text("权值共享:大幅减少参数", font="AR PL UKai CN", font_size=20, color=GREEN_A)

        benefit_group = VGroup(benefit_1, benefit_2).arrange(DOWN, buff=0.2)
        benefit_group.move_to(issue_group.get_center() + RIGHT * 7) # 与左侧文本水平对齐

        # 4.4 添加RNN文字
        rnn_part1 = Text("循环神经网络", font="AR PL UKai CN", font_size=32, color=GREEN, weight=BOLD)
        rnn_part2 = Text(" (RNN)", font="AR PL UKai CN", font_size=28, color=GREEN)
        rnn_title = VGroup(rnn_part1, rnn_part2).arrange(RIGHT, buff=0)
        rnn_title.next_to(benefit_1, UP, buff=0.3)

        # 动画展示右侧
        self.play(FadeIn(cnn_title))
        self.play(Create(grid_cnn))
        self.play(Create(kernel_visual))
        self.play(
            GrowArrow(arrow_cnn),
            FadeIn(feature_map, shift=LEFT)
        )
        self.play(Write(benefit_group))
        self.play(FadeIn(rnn_title))

        # ---------------------------------------------------------------------
        # 5. 结尾停顿
        # ---------------------------------------------------------------------
