from manim import *

class MedicalBiomechanicsScene(Scene):
    def construct(self):

        # 1. Title setup
        title = Text("Applications in Medicine & Biomechanics",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Central Concept: Fluid Motion in the Body
        central_concept = Text("Fluid Motion in the Human Body", font_size=28, color=BLUE)
        central_concept.move_to(UP * 1.5)
        central_box = SurroundingRectangle(central_concept, color=BLUE, buff=0.2)

        self.play(FadeIn(central_concept, shift=DOWN*0.5), Create(central_box))

        # 3. Create two main branches: Blood and Air
        blood_text = Text("Blood Circulation", font_size=28)
        air_text = Text("Air Respiration", font_size=28)

        branches = VGroup(blood_text, air_text).arrange(RIGHT, buff=3)
        branches.next_to(central_concept, DOWN, buff=1.5)

        arrow_blood = Arrow(central_box.get_bottom(), blood_text.get_top(), buff=0.2, color=RED)
        arrow_air = Arrow(central_box.get_bottom(), air_text.get_top(), buff=0.2, color=CYAN)

        self.play(
            GrowArrow(arrow_blood),
            GrowArrow(arrow_air),
            Write(blood_text),
            Write(air_text)
        )

        # 4. Applications stemming from each branch
        # Blood applications
        cardio_text = Text("Cardiovascular Disease Analysis", font_size=24, color=YELLOW)
        device_text = Text("Design of Stents & Artificial Hearts", font_size=24, color=YELLOW)
        blood_apps = VGroup(cardio_text, device_text).arrange(DOWN, buff=0.3, aligned_edge=LEFT)
        blood_apps.next_to(blood_text, DOWN, buff=0.5)

        # Air applications
        med_device_text = Text("Improve Medical Device Performance", font_size=24, color=YELLOW)
        precision_med_text = Text("Promote Precision Medicine", font_size=24, color=YELLOW)
        air_apps = VGroup(med_device_text, precision_med_text).arrange(DOWN, buff=0.3, aligned_edge=LEFT)
        air_apps.next_to(air_text, DOWN, buff=0.5)

        # Animate the applications
        self.play(
            FadeIn(blood_apps, shift=UP*0.5, lag_ratio=0.5),
            run_time=1.5
        )
        self.play(
            FadeIn(air_apps, shift=UP*0.5, lag_ratio=0.5),
            run_time=1.5
        )
