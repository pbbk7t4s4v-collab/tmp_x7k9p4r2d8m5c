from manim import *

class FluidMechanicsInMedicine(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Applications in Medicine and Biology",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Introduce Biological Fluid Dynamics
        bio_title = Text("Biological Fluid Dynamics", font_size=30, color=BLUE_C).next_to(title_group, DOWN, buff=0.5)
        bio_title.align_to(title_group, LEFT)

        bio_list = BulletedList(
            "Blood Circulation",
            "Respiratory Airflow",
            "Water Transport in Plants",
            font_size=28
        ).next_to(bio_title, DOWN, buff=0.2, aligned_edge=LEFT)

        bio_group = VGroup(bio_title, bio_list)

        self.play(FadeIn(bio_group, shift=DOWN), run_time=1.5)

        # 3. Introduce Medical Applications
        med_title = Text("Medical Applications", font_size=30, color=GREEN_C)
        med_title.next_to(bio_group, DOWN, buff=0.7).align_to(bio_group, LEFT)

        med_list = BulletedList(
            "Analyze blood flow resistance",
            "Evaluate heart pumping efficiency",
            "Study pressure in aneurysms",
            font_size=28
        ).next_to(med_title, DOWN, buff=0.2, aligned_edge=LEFT)

        med_group = VGroup(med_title, med_list)

        self.play(Write(med_group), run_time=2)

        # 4. Highlight specific examples
        all_content = VGroup(bio_group, med_group)
        self.play(all_content.animate.to_edge(LEFT, buff=0.8))

        example_title = Text("Key Examples", font_size=30, color=ORANGE)
        example_title.to_edge(RIGHT, buff=1.5).align_to(bio_title, UP)

        example1 = Text("Artificial Heart Valves:\nOptimize design to reduce\nthrombosis risk.", font_size=24, line_spacing=0.8)
        example1.next_to(example_title, DOWN, buff=0.3)

        example2 = Text("Airway Flow Analysis:\nDesign respiratory devices and\ndiagnose diseases.", font_size=24, line_spacing=0.8)
        example2.next_to(example1, DOWN, buff=0.5)

        examples_group = VGroup(example_title, example1, example2)

        self.play(FadeIn(examples_group, shift=LEFT))

        box1 = SurroundingRectangle(example1, color=YELLOW, buff=0.1)
        box2 = SurroundingRectangle(example2, color=YELLOW, buff=0.1)

        self.play(Create(box1), run_time=0.8)
        self.play(Create(box2), run_time=0.8)
