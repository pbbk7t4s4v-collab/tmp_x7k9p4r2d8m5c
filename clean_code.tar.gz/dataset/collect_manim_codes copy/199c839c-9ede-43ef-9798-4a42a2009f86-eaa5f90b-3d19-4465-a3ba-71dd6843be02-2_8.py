from manim import *

class ConstantsTranscendence(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("常数 e 与 π 的超越性及其意义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心概念:超越数定义
        # 使用VGroup布局避免遮挡
        concept_text = Text("超越数 (Transcendental Number)", font_size=28, font="AR PL UKai CN", color=BLUE)
        concept_desc = Text("不是任何整系数多项式方程的根", font_size=24, font="AR PL UKai CN", color=GRAY_B)

        concept_math = MathTex(r"a_n x^n + \dots + a_1 x + a_0 \neq 0", color=YELLOW)

        concept_group = VGroup(concept_text, concept_desc, concept_math).arrange(DOWN, buff=0.2)
        concept_group.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(concept_group, shift=DOWN))

        # 3. 历史里程碑:e 和 pi
        # 左侧展示 e
        e_val = MathTex(r"e \approx 2.718", color=GREEN).scale(1.2)
        e_name = Text("Hermite (1873)", font_size=24, font="AR PL UKai CN")
        e_status = Text("证明 e 是超越数", font_size=24, font="AR PL UKai CN", color=GREEN)
        e_group = VGroup(e_val, e_name, e_status).arrange(DOWN, buff=0.15)

        # 右侧展示 pi
        pi_val = MathTex(r"\pi \approx 3.141", color=RED).scale(1.2)
        pi_name = Text("Lindemann (1882)", font_size=24, font="AR PL UKai CN")
        pi_status = Text("证明 π 是超越数", font_size=24, font="AR PL UKai CN", color=RED)
        pi_group = VGroup(pi_val, pi_name, pi_status).arrange(DOWN, buff=0.15)

        # 布局左右两块
        milestones = VGroup(e_group, pi_group).arrange(RIGHT, buff=2.0)
        milestones.next_to(concept_group, DOWN, buff=0.8)

        self.play(
            Write(e_group),
            Write(pi_group)
        )

        # 添加强调框
        rect_e = SurroundingRectangle(e_group, color=GREEN, buff=0.15)
        rect_pi = SurroundingRectangle(pi_group, color=RED, buff=0.15)
        self.play(Create(rect_e), Create(rect_pi))

        # 4. 几何意义结论(化圆为方)
        conclusion_text = Text("结论:古希腊难题"化圆为方"不可能尺规作图解决",
                             font_size=26, font="AR PL UKai CN", color=ORANGE)
        conclusion_text.next_to(milestones, DOWN, buff=0.6)

        # 简单的几何示意:圆 -> 方 (打叉)
        circle = Circle(radius=0.3, color=RED, fill_opacity=0.5)
        arrow = Arrow(LEFT, RIGHT, buff=0.1).scale(0.5)
        square = Square(side_length=0.5, color=BLUE, fill_opacity=0.5)

        geo_visual = VGroup(circle, arrow, square).arrange(RIGHT)
        geo_visual.next_to(conclusion_text, DOWN, buff=0.2)

        cross = Cross(geo_visual).scale(0.8)

        self.play(FadeIn(conclusion_text))
        self.play(
            FadeIn(geo_visual),
            Create(cross)
        )
