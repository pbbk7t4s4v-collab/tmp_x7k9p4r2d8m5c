from manim import *

class SysCallAndContext(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置
        # ---------------------------------------------------------
        title = Text("系统调用号传递与上下文保存",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("62", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 布局区域划分 (用户态 vs 内核态)
        # ---------------------------------------------------------
        # 左侧：用户态寄存器
        user_zone_text = Text("用户态: 寄存器传参", font="AR PL UKai CN", font_size=24, color=BLUE_B)
        user_zone_text.to_edge(LEFT, buff=1).shift(UP * 1.5)

        # 右侧：内核态栈
        kernel_zone_text = Text("内核态: 栈保存上下文", font="AR PL UKai CN", font_size=24, color=RED_B)
        kernel_zone_text.to_edge(RIGHT, buff=1).shift(UP * 1.5)

        self.play(FadeIn(user_zone_text), FadeIn(kernel_zone_text))

        # ---------------------------------------------------------
        # 3. 步骤一：系统调用号与参数 (寄存器)
        # ---------------------------------------------------------
        # EAX 存放系统调用号
        eax_box = Rectangle(height=0.8, width=2.5, color=BLUE, fill_opacity=0.5)
        eax_text = Text("EAX: 调用号", font="AR PL UKai CN", font_size=20).move_to(eax_box)
        eax_group = VGroup(eax_box, eax_text).next_to(user_zone_text, DOWN, buff=0.5)

        # EBX 存放参数
        ebx_box = Rectangle(height=0.8, width=2.5, color=BLUE_C, fill_opacity=0.5)
        ebx_text = Text("EBX: 参数1", font="AR PL UKai CN", font_size=20).move_to(ebx_box)
        ebx_group = VGroup(ebx_box, ebx_text).next_to(eax_group, DOWN, buff=0.2)

        reg_group = VGroup(eax_group, ebx_group)

        self.play(
            Create(eax_box), Write(eax_text),
            Create(ebx_box), Write(ebx_text),
            run_time=1.5
        )

        # ---------------------------------------------------------
        # 4. 步骤二：查表与中断 (流转)
        # ---------------------------------------------------------
        # 中间：中断向量表/系统调用表
        table_rect = Rectangle(height=2.5, width=2, color=GREY)
        table_lines = VGroup(*[Line(table_rect.get_left() + UP*i*0.5, table_rect.get_right() + UP*i*0.5, color=GREY) for i in range(-2, 3)])
        table_title = Text("IDT / 入口表", font="AR PL UKai CN", font_size=18).next_to(table_rect, UP, buff=0.1)
        table_group = VGroup(table_rect, table_lines, table_title).move_to(ORIGIN).shift(DOWN*0.5)

        # 箭头：从寄存器指向表
        arrow_call = Arrow(reg_group.get_right(), table_group.get_left(), buff=0.1, color=YELLOW)
        int_text = Text("int 0x80 / sysenter", font="AR PL UKai CN", font_size=16, color=YELLOW).next_to(arrow_call, UP, buff=0.05)

        self.play(FadeIn(table_group), GrowArrow(arrow_call), Write(int_text))

        # ---------------------------------------------------------
        # 5. 步骤三：CPU状态保护 (压栈)
        # ---------------------------------------------------------
        # 内核栈结构
        stack_base = Line(LEFT, RIGHT, color=RED).set_width(2.5)
        stack_left = Line(UP*2, ORIGIN, color=RED).next_to(stack_base, UP, aligned_edge=LEFT, buff=0)
        stack_right = Line(UP*2, ORIGIN, color=RED).next_to(stack_base, UP, aligned_edge=RIGHT, buff=0)
        stack_container = VGroup(stack_base, stack_left, stack_right).next_to(kernel_zone_text, DOWN, buff=0.5)

        stack_label = Text("内核栈 (Kernel Stack)", font="AR PL UKai CN", font_size=18).next_to(stack_container, DOWN, buff=0.2)

        self.play(Create(stack_container), Write(stack_label))

        # 模拟压栈动画 (Context Save)
        context_block = Rectangle(height=0.5, width=2.3, color=ORANGE, fill_opacity=0.8, stroke_width=1)
        context_text = Text("CPU上下文(EIP, EFLAGS...)", font="AR PL UKai CN", font_size=16, color=BLACK).move_to(context_block)
        context_item = VGroup(context_block, context_text)

        # 初始位置在表那里，移动到栈中
        context_item.move_to(table_group.get_right())

        # 箭头：从表指向栈
        arrow_save = Arrow(table_group.get_right(), stack_container.get_left(), buff=0.2, color=RED)

        self.play(GrowArrow(arrow_save))

        # 移动并放入栈底
        target_pos = stack_base.get_center() + UP * 0.35
        self.play(
            context_item.animate.move_to(target_pos),
            run_time=1.5
        )

        # 强调框
        highlight = SurroundingRectangle(context_item, color=YELLOW, buff=0.05)
        protect_text = Text("保护现场", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(highlight, RIGHT)

        self.play(Create(highlight), Write(protect_text))
