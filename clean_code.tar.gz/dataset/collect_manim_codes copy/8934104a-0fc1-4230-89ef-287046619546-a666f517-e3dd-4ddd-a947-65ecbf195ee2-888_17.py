from manim import *

class KMeansLimitationAndMotivation(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("K-means局限与概率建模动机",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.5)
        )

        # Page number
        page_number = Text("17", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. K-means 特点与局限 (上半部分)
        # ---------------------------------------------------------
        # 优点
        pro_label = Text("优点：", font="AR PL UKai CN", font_size=26, color=GREEN)
        pro_desc = Text("简单高效，适合球状分布", font="AR PL UKai CN", font_size=26, color=WHITE)
        pro_group = VGroup(pro_label, pro_desc).arrange(RIGHT, buff=0.1)

        # 局限
        con_label = Text("局限：", font="AR PL UKai CN", font_size=26, color=RED)
        con_desc = Text("易陷局部最优，难处理非凸簇", font="AR PL UKai CN", font_size=26, color=WHITE)
        con_group = VGroup(con_label, con_desc).arrange(RIGHT, buff=0.1)

        # 布局
        analysis_group = VGroup(pro_group, con_group).arrange(DOWN, buff=0.5, aligned_edge=LEFT)
        analysis_group.next_to(title_line, DOWN, buff=0.8)

        # 可视化辅助：简单的球状与非凸形状示意
        # 球状 (Green Circle)
        circle_shape = Circle(radius=0.25, color=GREEN, fill_opacity=0.2)
        circle_shape.next_to(pro_group, RIGHT, buff=0.5)

        # 非凸 (Red Arc/Crescent concept)
        arc_shape = Arc(radius=0.3, start_angle=0, angle=PI, color=RED)
        arc_shape.next_to(con_group, RIGHT, buff=0.5)

        self.play(
            FadeIn(analysis_group, shift=UP),
            Create(circle_shape),
            Create(arc_shape)
        )

        # ---------------------------------------------------------
        # 3. 过渡到概率建模 (下半部分)
        # ---------------------------------------------------------
        # 分隔线
        sep_line = DashedLine(LEFT*5, RIGHT*5, color=GREY).next_to(analysis_group, DOWN, buff=0.6)
        self.play(Create(sep_line, run_time=0.5))

        # 动机标题
        motivation_text = Text("动机：从硬划分转向软划分", font="AR PL UKai CN", font_size=30, color=YELLOW)
        motivation_text.next_to(sep_line, DOWN, buff=0.4)
        self.play(Write(motivation_text))

        # 硬划分 vs 软划分 对比
        # 左侧：硬划分
        hard_label = Text("硬划分 (K-means)", font="AR PL UKai CN", font_size=22, color=BLUE)
        hard_math = MathTex(r"x \in C_k", color=BLUE_A)
        hard_vgroup = VGroup(hard_label, hard_math).arrange(DOWN, buff=0.2)

        # 中间：箭头
        arrow = Arrow(LEFT, RIGHT, color=WHITE, buff=0.2).scale(0.6)

        # 右侧：软划分
        soft_label = Text("软划分 (概率分布)", font="AR PL UKai CN", font_size=22, color=PURPLE)
        soft_math = MathTex(r"P(C_k | x)", color=PURPLE_A)
        soft_vgroup = VGroup(soft_label, soft_math).arrange(DOWN, buff=0.2)

        # 底部整体布局
        bottom_row = VGroup(hard_vgroup, arrow, soft_vgroup).arrange(RIGHT, buff=1.0)
        bottom_row.next_to(motivation_text, DOWN, buff=0.5)

        # 动画展示对比
        self.play(FadeIn(hard_vgroup, shift=RIGHT))
        self.play(GrowArrow(arrow))
        self.play(FadeIn(soft_vgroup, shift=LEFT))

        # 强调重点：概率密度
        focus_rect = SurroundingRectangle(soft_vgroup, color=PURPLE, buff=0.15)
        self.play(Create(focus_rect))
