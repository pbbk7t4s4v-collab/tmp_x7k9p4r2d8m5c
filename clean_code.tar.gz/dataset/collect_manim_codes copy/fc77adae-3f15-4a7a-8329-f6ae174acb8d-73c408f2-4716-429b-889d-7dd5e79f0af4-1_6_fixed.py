from manim import *
import numpy as np
CYAN = "#00FFFF"

class FluidMechanicsInIndustry(Scene):
    def construct(self):

        # 1. Title
        title = Text("Fluid Mechanics in Industrial Processes",
                     font_size=34,
                     color=WHITE,
                     weight=BOLD)
        title.scale(0.95)  # 修复：轻微缩放避免宽度接近边界
        title.to_edge(UP, buff=0.6)  # 修复：增加顶部缓冲，保持安全距离
        title_line = Line(LEFT, RIGHT, color=YELLOW).match_width(title).next_to(title, DOWN, buff=0.15)  # 修复：微调缓冲避免与标题贴近
        title_group = VGroup(title, title_line)
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # 2. Left side: Abstract industrial process diagram
        flow_path = VGroup(*[
            Arrow(start=np.array([-1, 1.5, 0]), end=np.array([0, 0.5, 0]), color=CYAN, stroke_width=3, max_tip_length_to_length_ratio=0.1),
            Arrow(start=np.array([1, 1.5, 0]), end=np.array([0, 0, 0]), color=CYAN, stroke_width=3, max_tip_length_to_length_ratio=0.1),
            Arrow(start=np.array([-0.5, -1.5, 0]), end=np.array([-0.2, -0.2, 0]), color=CYAN, stroke_width=3, max_tip_length_to_length_ratio=0.1)
        ])

        reactor_box = SurroundingRectangle(flow_path, color=BLUE, buff=0.4)
        process_label = Text("Process", font_size=24).next_to(reactor_box, DOWN)

        diagram = VGroup(reactor_box, flow_path, process_label)
        diagram.scale(0.9)  # 修复：整体缩小，留出右侧文本空间
        diagram.shift(LEFT * 3.8)  # 修复：微调左移，保持文本右侧布局均衡

        self.play(
            FadeIn(diagram, shift=RIGHT),
            run_time=2.0
        )

        # 3. Right side: Text content explaining concepts
        examples_title = Text("Common Examples:", font_size=26, weight=BOLD, color=YELLOW)  # 修复：字体从28降为26避免与左图过近
        examples_list = VGroup(
            Text("• Chemical reactors", font_size=26),
            Text("• Spray molding", font_size=26),
            Text("• Food processing lines", font_size=26),
        ).arrange(DOWN, buff=0.25, aligned_edge=LEFT)  # 修复：增加垂直间距

        benefits_title = Text("Key Benefits:", font_size=26, weight=BOLD, color=YELLOW)  # 修复：字体从28降为26
        benefits_list = VGroup(
            Text("• Optimize production processes", font_size=26),
            Text("• Improve heat & mass transfer", font_size=26),
            Text("• Control fluid mixing quality", font_size=26),
            Text("• Reduce pollutant emissions", font_size=26),
        ).arrange(DOWN, buff=0.25, aligned_edge=LEFT)

        text_content = VGroup(examples_title, examples_list, benefits_title, benefits_list)
        text_content.arrange(DOWN, buff=0.5, aligned_edge=LEFT)  # 修复：延长组间缓冲
        text_content.shift(RIGHT * 0.3)  # 修复：轻微右移确保与图形安全距离
        text_content.next_to(diagram, RIGHT, buff=1.0)

        self.play(
            Write(examples_title),
            FadeIn(examples_list, shift=UP),
            run_time=2.5
        )

        self.play(
            Write(benefits_title),
            FadeIn(benefits_list, shift=UP),
            run_time=3
        )
