from manim import *

class RadioDebuggingIntro(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("整机调试与选台机制",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("53", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 中心图示:收音机抽象模型
        # 机身
        radio_body = RoundedRectangle(corner_radius=0.3, width=4.5, height=2.8, color=BLUE_C, fill_opacity=0.2)

        # 扬声器部分
        speaker_outer = Circle(radius=0.9, color=WHITE, stroke_width=2).move_to(radio_body.get_left() + RIGHT * 1.2)
        speaker_inner = Circle(radius=0.6, color=GREY_B, stroke_width=1).move_to(speaker_outer)
        speaker_center = Dot(color=GREY_A).move_to(speaker_outer)
        speaker_group = VGroup(speaker_outer, speaker_inner, speaker_center)

        # 调谐旋钮
        tuning_knob = Circle(radius=0.4, color=GOLD, fill_opacity=0.8).move_to(radio_body.get_right() + LEFT * 1.0)
        knob_label = Text("Tuning", font_size=12, color=BLACK).move_to(tuning_knob)
        knob_group = VGroup(tuning_knob, knob_label)

        # 天线
        antenna_start = radio_body.get_top() + RIGHT * 1.5
        antenna_end = antenna_start + UP * 1.2 + RIGHT * 0.5
        antenna = Line(antenna_start, antenna_end, color=LIGHT_GREY, stroke_width=4)

        radio_full = VGroup(antenna, radio_body, speaker_group, knob_group).shift(DOWN * 0.2)

        self.play(FadeIn(radio_full, scale=0.8), run_time=1.5)

        # 3. 四个核心学习目标 (使用简单的几何连接)

        # 定义四个方向的内容
        # 格式: (文字, 颜色, 位置向量, 对齐方向)
        concepts = [
            ("整机调试", YELLOW, UL, RIGHT),
            ("信号调优", GREEN, UR, LEFT),
            ("选台技巧", BLUE, DL, RIGHT),
            ("环境抗扰", RED, DR, LEFT)
        ]

        concept_groups = VGroup()

        for text_str, color, direction, align_dir in concepts:
            # 文字
            txt = Text(text_str, font="AR PL UKai CN", font_size=26, color=color)

            # 定位:基于收音机四角向外延伸
            # 获取收音机边界框的对应角
            corner_point = radio_body.get_corner(direction)

            # 计算文字位置
            if direction[1] > 0: # 上方
                target_pos = corner_point + direction * 0.8 + UP * 0.2
            else: # 下方
                target_pos = corner_point + direction * 0.8 + DOWN * 0.2

            txt.move_to(target_pos)

            # 连接线/箭头
            arrow = Arrow(
                start=txt.get_edge_center(align_dir),
                end=corner_point,
                color=color,
                buff=0.1,
                stroke_width=3,
                max_tip_length_to_length_ratio=0.15
            )

            # 组合并添加到主组
            group = VGroup(txt, arrow)
            concept_groups.add(group)

            # 动画:文字淡入 + 箭头生长
            self.play(
                FadeIn(txt, shift=direction * 0.5),
                Create(arrow),
                run_time=0.6
            )

        # 4. 底部总结框
        summary_text = Text("目标:掌握调试流程,实现稳定收听", font="AR PL UKai CN", font_size=24, color=WHITE)
        summary_text.to_edge(DOWN, buff=0.8)

        summary_box = SurroundingRectangle(summary_text, color=TEAL, buff=0.2, stroke_width=2)

        self.play(
            Write(summary_text),
            Create(summary_box),
            run_time=1.5
        )
