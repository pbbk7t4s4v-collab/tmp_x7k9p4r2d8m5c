from manim import *

class GovernmentSpendingMultiplier(Scene):
    def construct(self):

        # --- 1. 标题设置 ---
        title = Text("政府支出增加的乘数效应",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("39", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- 2. 场景条件设定 ---
        # 描述政府支出的变化
        condition_text = Text("假设政府购买从 80 亿元提高到 100 亿元",
                            font="AR PL UKai CN", font_size=26, color=LIGHT_GREY)

        # 核心变量展示
        delta_g_eq = MathTex(r"\Delta G = 100 - 80 = 20 \text{ (billion)}", font_size=32)

        # 组合条件部分
        condition_group = VGroup(condition_text, delta_g_eq).arrange(DOWN, buff=0.2)
        condition_group.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(condition_text, shift=DOWN))
        self.play(Write(delta_g_eq))

        # --- 3. 第一步:计算乘数 ---
        # 步骤标题
        step1_title = Text("第一步:计算政府支出乘数", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        step1_title.align_to(condition_group, LEFT) # 左对齐

        # 公式推导
        # c = 0.8 是隐含条件,这里直接展示计算过程
        step1_math = MathTex(
            r"k_G = \frac{1}{1-c} = \frac{1}{1-0.8} = \frac{1}{0.2} = 5",
            font_size=36
        )

        # 布局
        step1_group = VGroup(step1_title, step1_math).arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        step1_group.next_to(condition_group, DOWN, buff=0.6)

        self.play(FadeIn(step1_title, shift=RIGHT))
        self.play(Write(step1_math))

        # --- 4. 第二步:计算收入变化 ---
        # 步骤标题
        step2_title = Text("第二步:计算均衡收入的变化", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        step2_title.align_to(step1_group, LEFT)

        # 计算公式与结果
        step2_math = MathTex(
            r"\Delta Y = k_G \times \Delta G",
            r"= 5 \times 20",
            r"= 100 \text{ (billion)}",
            font_size=36
        )

        # 布局
        step2_group = VGroup(step2_title, step2_math).arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        step2_group.next_to(step1_group, DOWN, buff=0.6)

        self.play(FadeIn(step2_title, shift=RIGHT))
        self.play(Write(step2_math[0])) # 显示公式
        self.play(ReplacementTransform(step2_math[0].copy(), step2_math[1])) # 代入数值
        self.play(Write(step2_math[2])) # 显示结果

        # --- 5. 强调结果 ---
        # 使用 SurroundingRectangle 强调最终结果
        result_box = SurroundingRectangle(step2_math[2], color=YELLOW, buff=0.1)
        result_label = Text("最终增量", font="AR PL UKai CN", font_size=20, color=YELLOW)
        result_label.next_to(result_box, RIGHT, buff=0.2)

        self.play(
            Create(result_box),
            FadeIn(result_label)
        )
