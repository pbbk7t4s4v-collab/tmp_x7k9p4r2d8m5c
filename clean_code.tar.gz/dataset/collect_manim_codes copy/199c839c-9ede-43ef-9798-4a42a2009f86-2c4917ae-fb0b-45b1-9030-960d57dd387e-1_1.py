from manim import *

class BrainstormingIntro(Scene):
    def construct(self):

        # ---- Background Configuration ----

        # ---- Title Section (Strict Template) ----
        title = Text("课堂创意激发工具集",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---- Main Content Visualization ----

        # 1. Central Concept: Brainstorming
        center_circle = Circle(radius=1.2, color=BLUE_C, fill_opacity=0.2, fill_color=BLUE_E).move_to(UP * 0.5)
        center_text = Text("头脑风暴", font="AR PL UKai CN", font_size=40, color=WHITE)
        center_text.move_to(center_circle.get_center())
        center_group = VGroup(center_circle, center_text)

        # 2. Left Branch: Common Misconception
        # Use VGroup to arrange text lines manually to avoid alignment issues
        mis_line1 = Text("仅仅是", font="AR PL UKai CN", font_size=24, color=GREY_B)
        mis_line2 = Text(""想点子"？", font="AR PL UKai CN", font_size=24, color=GREY_B)
        mis_group = VGroup(mis_line1, mis_line2).arrange(DOWN, buff=0.1)
        mis_group.move_to(DL * 2 + RIGHT * 1.5)

        arrow_left = Arrow(start=center_circle.get_left(), end=mis_group.get_top(), color=GREY, buff=0.1)

        # Cross mark for misconception
        cross = Cross(mis_group, color=RED, stroke_width=4, scale_factor=1.2)

        # 3. Right Branch: The Solution (Toolset)
        sol_line1 = Text("成体系的", font="AR PL UKai CN", font_size=28, color=GOLD)
        sol_line2 = Text("创意工具库", font="AR PL UKai CN", font_size=28, color=GOLD)
        sol_group = VGroup(sol_line1, sol_line2).arrange(DOWN, buff=0.1)
        sol_group.move_to(DR * 2 + LEFT * 1.5)

        arrow_right = Arrow(start=center_circle.get_right(), end=sol_group.get_top(), color=GOLD, buff=0.1)

        # Emphasis Box
        emphasis_rect = SurroundingRectangle(sol_group, color=YELLOW, buff=0.2)
        emphasis_label = Text("本课核心", font="AR PL UKai CN", font_size=20, color=YELLOW)
        emphasis_label.next_to(emphasis_rect, DOWN, buff=0.1)

        # ---- Animation Sequence ----

        # Step 1: Show Central Concept
        self.play(FadeIn(center_group, scale=0.8))

        # Step 2: Show Misconception
        self.play(GrowArrow(arrow_left), run_time=0.8)
        self.play(Write(mis_group), run_time=1)
        self.play(Create(cross), run_time=0.5)

        # Step 3: Show Solution
        self.play(GrowArrow(arrow_right), run_time=0.8)
        self.play(Write(sol_group), run_time=1)

        # Step 4: Highlight Solution
        self.play(
            Create(emphasis_rect),
            FadeIn(emphasis_label, shift=UP*0.2)
        )
