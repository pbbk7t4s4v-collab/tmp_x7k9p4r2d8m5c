from manim import *

class DifferentialApproximation(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("微分近似计算实例",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("15", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容部分
        # 步骤1：建立模型
        step1_label = Text("1. 建立模型：", font="AR PL UKai CN", font_size=28, color=BLUE)
        step1_math = MathTex(r"f(x) = \sqrt{x}, \quad x_0 = 100, \quad \Delta x = 1", font_size=32)
        step1_group = VGroup(step1_label, step1_math).arrange(RIGHT, buff=0.5)

        # 步骤2：计算导数
        step2_label = Text("2. 计算导数：", font="AR PL UKai CN", font_size=28, color=BLUE)
        step2_math = MathTex(r"f'(100) = \frac{1}{2\sqrt{100}} = \frac{1}{20} = 0.05", font_size=32)
        step2_group = VGroup(step2_label, step2_math).arrange(RIGHT, buff=0.5)

        # 步骤3：近似公式应用
        step3_label = Text("3. 近似计算：", font="AR PL UKai CN", font_size=28, color=BLUE)
        # 分两行展示核心公式，避免过长
        step3_math_1 = MathTex(r"\sqrt{101} \approx f(100) + f'(100) \cdot 1", font_size=36)
        step3_math_2 = MathTex(r"= 10 + 0.05 = 10.05", font_size=36, color=YELLOW)

        # 对齐公式
        step3_math_group = VGroup(step3_math_1, step3_math_2).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        step3_group = VGroup(step3_label, step3_math_group).arrange(RIGHT, buff=0.5, aligned_edge=UP)

        # 步骤4：结果对比
        step4_text = Text("对比：实际值 ", font="AR PL UKai CN", font_size=26)
        step4_val = MathTex(r"\sqrt{101} \approx 10.0498...", font_size=30, color=GREEN)
        step4_concl = Text("，误差极小。", font="AR PL UKai CN", font_size=26)
        step4_group = VGroup(step4_text, step4_val, step4_concl).arrange(RIGHT, buff=0.1)

        # 整体排版
        content_group = VGroup(step1_group, step2_group, step3_group, step4_group)
        content_group.arrange(DOWN, aligned_edge=LEFT, buff=0.7)
        content_group.move_to(ORIGIN).shift(DOWN * 0.3) # 稍微下移，避开标题

        # 确保左对齐美观
        step1_group.align_to(content_group, LEFT)
        step2_group.align_to(content_group, LEFT)
        step3_group.align_to(content_group, LEFT)
        step4_group.move_to(content_group.get_bottom() + DOWN * 0.5) # 对比放在最下面居中一点

        # 3. 动画演示
        # 步骤1
        self.play(FadeIn(step1_label, shift=RIGHT), Write(step1_math), run_time=1.5)

        # 步骤2
        self.play(FadeIn(step2_label, shift=RIGHT), Write(step2_math), run_time=1.5)

        # 步骤3
        self.play(FadeIn(step3_label, shift=RIGHT))
        self.play(Write(step3_math_1), run_time=1.5)
        self.play(TransformFromCopy(step3_math_1, step3_math_2), run_time=1.0)

        # 强调结果
        result_rect = SurroundingRectangle(step3_math_2, color=YELLOW, buff=0.15)
        self.play(Create(result_rect), run_time=0.8)

        # 步骤4：对比
        self.play(FadeIn(step4_group, shift=UP), run_time=1.2)
