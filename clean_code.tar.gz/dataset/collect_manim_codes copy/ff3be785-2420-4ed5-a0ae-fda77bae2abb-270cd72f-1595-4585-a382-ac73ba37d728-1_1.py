from manim import *

class BMIIntro(Scene):
    def construct(self):

        # 1. 标题设置 (严格遵守模板)
        title = Text("体重背后的科学——BMI与健康",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧内容：体重秤与心情 (简单的几何图形模拟)
        # 模拟体重秤
        scale_base = Square(side_length=2.5, color=BLUE_C, fill_opacity=0.2)
        scale_window = Rectangle(height=0.8, width=1.8, color=WHITE).move_to(scale_base.get_top() + DOWN*0.8)
        weight_num = Text("60.5 kg", font="AR PL UKai CN", font_size=36, color=YELLOW).move_to(scale_window)

        # 底部心情文字
        mood_text = Text("心情随数字波动？", font="AR PL UKai CN", font_size=28, color=RED_B)
        mood_text.next_to(scale_base, DOWN, buff=0.3)

        left_group = VGroup(scale_base, scale_window, weight_num, mood_text)
        left_group.to_edge(LEFT, buff=1.5).shift(DOWN*0.5)

        # 3. 中间过渡：否定符号
        not_equal = MathTex(r"\neq", font_size=60, color=RED).move_to(ORIGIN).shift(DOWN*0.5)
        health_text = Text("健康", font="AR PL UKai CN", font_size=32, color=GREEN).next_to(not_equal, UP, buff=0.5)

        # 4. 右侧内容：BMI 解锁密码
        # 核心概念文字
        bmi_label = Text("更科学的密码", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        bmi_main = Text("BMI", font="AR PL UKai CN", font_size=60, weight=BOLD, color=GOLD)
        bmi_desc = Text("身体质量指数", font="AR PL UKai CN", font_size=24, color=WHITE)

        # 排版右侧
        bmi_main.next_to(bmi_label, DOWN, buff=0.4)
        bmi_desc.next_to(bmi_main, DOWN, buff=0.3)

        # 强调框
        bmi_box = SurroundingRectangle(bmi_main, color=GOLD, buff=0.3)

        right_group = VGroup(bmi_label, bmi_main, bmi_desc, bmi_box)
        right_group.to_edge(RIGHT, buff=1.5).shift(DOWN*0.5)

        # 5. 动画流程
        # 展示左侧：体重秤
        self.play(
            FadeIn(scale_base),
            Create(scale_window),
            Write(weight_num),
            run_time=1.5
        )
        self.play(Write(mood_text), run_time=1)

        # 展示中间：单一数字不等于健康
        self.play(
            FadeIn(not_equal),
            FadeIn(health_text),
            run_time=1
        )

        # 展示右侧：引出BMI
        self.play(
            FadeIn(right_group, shift=LEFT),
            run_time=1.5
        )

        # 强调 BMI
        self.play(
            Indicate(bmi_main, scale_factor=1.2, color=YELLOW),
            Create(bmi_box),
            run_time=1
        )
