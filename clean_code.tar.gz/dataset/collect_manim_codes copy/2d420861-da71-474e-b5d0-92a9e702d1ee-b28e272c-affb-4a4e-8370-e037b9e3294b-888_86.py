from manim import *
import numpy as np

class DLVOTheoryScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (标准模板)
        # ---------------------------------------------------------
        title = Text("DLVO理论：胶体稳定性核心模型",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("85", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心公式展示
        # ---------------------------------------------------------
        # W_total = W_vdw + W_dl
        formula = MathTex(
            r"W_{total}(D) = W_{vdw}(D) + W_{dl}(D)",
            font_size=40
        )
        formula.next_to(title_line, DOWN, buff=0.5)

        # 强调框
        formula_box = SurroundingRectangle(formula, color=YELLOW, buff=0.2)

        self.play(Write(formula))
        self.play(Create(formula_box))

        # ---------------------------------------------------------
        # 3. 内容布局：左侧文字说明，右侧能量曲线图
        # ---------------------------------------------------------

        # 左侧文本说明 (使用VGroup手动排列避免BulletList问题)
        text_vdw = Text("• 范德华力 (Attraction):", font="AR PL UKai CN", font_size=24, color=BLUE)
        text_vdw_desc = Text("  短程吸引，导致粒子聚集", font="AR PL UKai CN", font_size=22, color=WHITE)

        text_dl = Text("• 双电层力 (Repulsion):", font="AR PL UKai CN", font_size=24, color=RED)
        text_dl_desc = Text("  长程排斥，源于扩散双电层", font="AR PL UKai CN", font_size=22, color=WHITE)

        text_kappa = Text("• 德拜长度 (Debye Length):", font="AR PL UKai CN", font_size=24, color=GREEN)
        text_kappa_desc = Text("  控制排斥范围，受离子强度影响", font="AR PL UKai CN", font_size=22, color=WHITE)

        # 组合文本块
        group_vdw = VGroup(text_vdw, text_vdw_desc).arrange(DOWN, aligned_edge=LEFT, buff=0.1)
        group_dl = VGroup(text_dl, text_dl_desc).arrange(DOWN, aligned_edge=LEFT, buff=0.1)
        group_kappa = VGroup(text_kappa, text_kappa_desc).arrange(DOWN, aligned_edge=LEFT, buff=0.1)

        text_content = VGroup(group_vdw, group_dl, group_kappa).arrange(DOWN, aligned_edge=LEFT, buff=0.4)
        text_content.to_edge(LEFT, buff=1.0).shift(DOWN * 0.5)

        # 右侧坐标系与曲线
        ax = Axes(
            x_range=[0, 4, 1],
            y_range=[-3, 3, 1],
            x_length=5,
            y_length=4,
            axis_config={"include_tip": True, "color": GREY},
        ).to_edge(RIGHT, buff=0.5).shift(DOWN * 0.5)

        labels = ax.get_axis_labels(x_label="D", y_label="W")

        # 定义曲线函数
        # 范德华力：吸引势 (负值，随距离衰减)
        def vdw_func(x):
            return -0.5 / (x**2 + 0.1) # 加0.1避免除零

        # 双电层力：排斥势 (正值，指数衰减)
        def dl_func(x):
            return 2.5 * np.exp(-1.5 * x)

        # 总势能
        def total_func(x):
            return vdw_func(x) + dl_func(x)

        curve_vdw = ax.plot(vdw_func, x_range=[0.2, 3.8], color=BLUE)
        curve_dl = ax.plot(dl_func, x_range=[0, 3.8], color=RED)
        curve_total = ax.plot(total_func, x_range=[0.2, 3.8], color=GREEN, stroke_width=4)

        # 曲线标签
        label_vdw = MathTex("W_{vdw}", color=BLUE, font_size=24).next_to(curve_vdw, DOWN, buff=0.1)
        label_dl = MathTex("W_{dl}", color=RED, font_size=24).next_to(curve_dl, UP, buff=0.1)
        label_total = MathTex("W_{total}", color=GREEN, font_size=24).move_to(ax.c2p(1.5, 0.5))

        # ---------------------------------------------------------
        # 4. 动画流程
        # ---------------------------------------------------------

        # 显示左侧文字
        self.play(FadeIn(text_content, shift=RIGHT))

        # 显示坐标系
        self.play(Create(ax), Write(labels))

        # 分步显示力的叠加
        # 1. 范德华力
        self.play(Create(curve_vdw), FadeIn(label_vdw), run_time=1)

        # 2. 双电层力
        self.play(Create(curve_dl), FadeIn(label_dl), run_time=1)

        # 3. 总相互作用势 (叠加)
        self.play(
            TransformFromCopy(VGroup(curve_vdw, curve_dl), curve_total),
            Write(label_total),
            run_time=1.5
        )
