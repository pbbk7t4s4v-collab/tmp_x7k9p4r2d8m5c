from manim import *
import random

class FluidMechanicsForEnvironment(Scene):
    def construct(self):

        # 1. 创建标题
        title = Text("环境保护与可持续发展",
                     font_size=34,
                     color=WHITE)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧内容：污染物扩散
        left_title = Text("污染物扩散与治理", font_size=28)
        left_title.to_edge(LEFT, buff=1.5).shift(UP * 2)

        # 污染物扩散示意图
        chimney = Rectangle(height=1.2, width=0.3, color=GRAY_BROWN, fill_opacity=1)
        chimney.next_to(left_title, DOWN, buff=1.0).align_to(left_title, LEFT)

        dots = VGroup(*[Dot(chimney.get_top() + UP*0.1, radius=0.03, color=DARK_GRAY) for _ in range(40)])

        # 污染物扩散要点
        pollutant_text = BulletedList(
            "预测污染物迁移过程",
            "建立流体动力学模型",
            "制定合理治理策略",
            font_size=24,
            buff=0.3,
            bullet="•"
        ).next_to(chimney, RIGHT, buff=0.8)

        self.play(FadeIn(left_title, shift=DOWN))
        self.play(FadeIn(chimney, shift=UP), run_time=1)

        # 污染物扩散动画
        self.play(
            LaggedStart(
                *[d.animate.shift(UP * 0.5 + RIGHT * (1.5 + 0.8 * random.random())).set_opacity(0) for d in dots],
                lag_ratio=0.1,
                run_time=2
            )
        )
        self.play(Write(pollutant_text), run_time=2)

        # 3. 右侧内容：可再生能源
        right_title = Text("可再生能源开发", font_size=28)
        right_title.to_edge(RIGHT, buff=1.5).shift(UP * 2)

        # 风力发电机示意图
        pole = Line(ORIGIN, UP * 1.2, color=WHITE, stroke_width=6).shift(DOWN*0.6)
        blades = VGroup(*[
            Line(ORIGIN, RIGHT * 0.6, color=WHITE, stroke_width=5).rotate(i * 2 * PI / 3, about_point=ORIGIN)
            for i in range(3)
        ])
        hub = Circle(radius=0.05, color=WHITE, fill_opacity=1)
        wind_turbine = VGroup(pole, blades, hub).move_to(pole.get_end())
        wind_turbine.next_to(right_title, DOWN, buff=1.0).align_to(right_title, LEFT).shift(LEFT*0.5)

        # 可再生能源要点
        energy_text = BulletedList(
            "风能与水能资源评估",
            "设备选址与效率提升",
            "促进可持续能源利用",
            font_size=24,
            buff=0.3,
            bullet="•"
        ).next_to(wind_turbine, RIGHT, buff=0.8)

        self.play(FadeIn(right_title, shift=DOWN))
        self.play(Create(wind_turbine), run_time=1.5)
        self.play(Write(energy_text), run_time=2)
