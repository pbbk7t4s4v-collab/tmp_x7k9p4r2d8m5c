from manim import *

class SeriesConvergenceRelations(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("级数和的收敛性关系思考",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("9", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 表头定义
        # 使用 MathTex 展示公式符号
        header_u = MathTex(r"\sum u_n", color=BLUE_B).scale(1.2)
        header_plus = MathTex(r"+").scale(1.2)
        header_v = MathTex(r"\sum v_n", color=BLUE_B).scale(1.2)
        header_arrow = MathTex(r"\Rightarrow").scale(1.2)
        header_sum = MathTex(r"\sum (u_n + v_n)", color=BLUE_B).scale(1.2)

        # 组合表头布局
        headers = VGroup(header_u, header_plus, header_v, header_arrow, header_sum)
        headers.arrange(RIGHT, buff=0.8)
        headers.next_to(title_line, DOWN, buff=0.8)

        self.play(FadeIn(headers, shift=UP))

        # 3. 定义通用样式函数
        def create_row(t1_str, t1_color, t2_str, t2_color, res_str, res_color):
            t1 = Text(t1_str, font="AR PL UKai CN", font_size=28, color=t1_color)
            plus = MathTex("+", font_size=34)
            t2 = Text(t2_str, font="AR PL UKai CN", font_size=28, color=t2_color)
            arrow = MathTex(r"\rightarrow", font_size=34)
            res = Text(res_str, font="AR PL UKai CN", font_size=28, color=res_color)

            # 对齐逻辑
            t1.move_to(header_u.get_center() + DOWN * row_offset)
            plus.move_to(header_plus.get_center() + DOWN * row_offset)
            t2.move_to(header_v.get_center() + DOWN * row_offset)
            arrow.move_to(header_arrow.get_center() + DOWN * row_offset)
            res.move_to(header_sum.get_center() + DOWN * row_offset)

            return VGroup(t1, plus, t2, arrow, res)

        # 4. 创建三行内容
        # 行间距
        dy = 1.2

        # 第一种情况:收敛 + 收敛 -> 收敛
        row_offset = dy * 1
        row1 = create_row("收敛", GREEN, "收敛", GREEN, "收敛", GREEN)

        # 第二种情况:收敛 + 发散 -> 发散
        row_offset = dy * 2
        row2 = create_row("收敛", GREEN, "发散", RED, "发散", RED)

        # 第三种情况:发散 + 发散 -> 不确定
        row_offset = dy * 3
        row3 = create_row("发散", RED, "发散", RED, "不确定 (可能收敛)", YELLOW)

        # 5. 动画播放
        # 逐行显示
        self.play(Write(row1), run_time=1)

        self.play(Write(row2), run_time=1)

        self.play(Write(row3), run_time=1)

        # 6. 强调第三种情况(易错点)
        box = SurroundingRectangle(row3, color=YELLOW, buff=0.15)
        label = Text("注意:发散+发散结果不唯一", font="AR PL UKai CN", font_size=24, color=YELLOW)
        label.next_to(box, DOWN, buff=0.2)

        self.play(
            Create(box),
            FadeIn(label, shift=UP)
        )
