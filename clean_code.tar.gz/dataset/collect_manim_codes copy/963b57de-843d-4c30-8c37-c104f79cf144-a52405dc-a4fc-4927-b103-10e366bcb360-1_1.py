from manim import *
import numpy as np

class FluidMechanicsIntro(Scene):
    def construct(self):

        # 1. 标题部分 (严格遵守模板)
        title = Text("流体力学的作用与重要性",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心定义展示
        # 使用简洁的文字描述流体力学的定义
        definition_text = Text(
            "研究流体(液体、气体)的宏观运动与受力规律",
            font="AR PL UKai CN",
            font_size=26,
            color=BLUE_B
        )
        definition_text.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(definition_text, shift=DOWN))

        # 3. 应用领域可视化
        # 创建四个代表不同领域的图标和文字

        # 3.1 航空航天 (简单的飞机/空气动力学示意)
        aero_icon = VGroup(
            Triangle(color=BLUE, fill_opacity=0.5).rotate(-PI/2).scale(0.3),
            Line(LEFT, RIGHT, color=WHITE).scale(0.5).next_to(Triangle(), DOWN, buff=0.1)
        ).arrange(DOWN, buff=0.1)
        aero_text = Text("航空航天", font="AR PL UKai CN", font_size=24)
        aero_group = VGroup(aero_icon, aero_text).arrange(DOWN, buff=0.2)

        # 3.2 土木水利 (波浪示意)
        civil_icon = FunctionGraph(lambda x: 0.2 * np.sin(3 * x), x_range=[-1, 1], color=TEAL).scale(0.5)
        civil_text = Text("土木水利", font="AR PL UKai CN", font_size=24)
        civil_group = VGroup(civil_icon, civil_text).arrange(DOWN, buff=0.2)

        # 3.3 能源环境 (风机/圆形示意)
        energy_icon = VGroup(
            Circle(radius=0.3, color=YELLOW),
            Cross(scale_factor=0.2, color=YELLOW)
        )
        energy_text = Text("能源环境", font="AR PL UKai CN", font_size=24)
        energy_group = VGroup(energy_icon, energy_text).arrange(DOWN, buff=0.2)

        # 3.4 生物医疗 (简单的管道/血管示意)
        bio_icon = VGroup(
            Line(LEFT, RIGHT, color=RED, stroke_width=8).scale(0.4),
            Line(LEFT, RIGHT, color=RED, stroke_width=8).scale(0.4).shift(DOWN*0.2)
        )
        bio_text = Text("生物医疗", font="AR PL UKai CN", font_size=24)
        bio_group = VGroup(bio_icon, bio_text).arrange(DOWN, buff=0.2)

        # 组合所有领域
        domains = VGroup(aero_group, civil_group, energy_group, bio_group)
        # 2x2 网格排列
        domains.arrange_in_grid(rows=2, cols=2, buff=(2.0, 0.8))
        domains.next_to(definition_text, DOWN, buff=0.8)

        # 为每个领域添加边框
        frames = VGroup()
        for domain in domains:
            rect = SurroundingRectangle(domain, color=WHITE, buff=0.2, corner_radius=0.1, stroke_width=2)
            frames.add(rect)

        # 4. 动画播放
        # 依次显示四个领域
        self.play(
            LaggedStart(
                *[AnimationGroup(Create(frame), FadeIn(content, shift=UP))
                  for frame, content in zip(frames, domains)],
                lag_ratio=0.3
            ),
            run_time=3
        )

        # 5. 底部总结
        conclusion = Text("流体力学是连接基础科学与工程应用的桥梁",
                         font="AR PL UKai CN",
                         font_size=28,
                         color=YELLOW)
        conclusion.to_edge(DOWN, buff=0.5)

        self.play(Write(conclusion))
