from manim import *

class PressureVesselHazards(Scene):
    def construct(self):

        # 1. Title Configuration
        title = Text("Potential Hazards of Pressure Vessels",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("41", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Visual Elements (Images)
        # Image 1: Normal Vessel
        vessel_img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_41/1.png") # A realistic illustration of a laboratory pressure vessel, such as a stainless steel reactor or an autoclave, set against a clean white background. The style should be professional and educational, highlighting the robust metal construction.
        vessel_img.height = 4.0
        vessel_img.to_edge(LEFT, buff=1.5)
        vessel_img.shift(DOWN * 0.5)

        # Image 2: Rupture (Explosion)
        rupture_img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_41/2.png") # A schematic warning illustration depicting a pressure vessel rupturing with a visible shockwave and gas cloud expanding outwards. The style should be flat vector art using hazard colors like yellow and red to symbolize danger and explosion.
        rupture_img.height = 4.0
        rupture_img.move_to(vessel_img.get_center())

        # 3. Text Content (Hazards)
        # Using VGroup for manual list construction to ensure control

        # Point 1: Stored Energy
        p1_dot = Dot(color=BLUE)
        p1_text = Text("Pressure differential creates large stored energy", font_size=24)
        p1_group = VGroup(p1_dot, p1_text).arrange(RIGHT, buff=0.2)

        # Point 2: Shockwave
        p2_dot = Dot(color=RED)
        p2_text = Text("Gases expand violently during rupture (Shockwave)", font_size=24)
        p2_group = VGroup(p2_dot, p2_text).arrange(RIGHT, buff=0.2)

        # Point 3: Toxic Media
        p3_dot = Dot(color=PURPLE)
        p3_text = Text("Toxic media increase danger (Chemical Release)", font_size=24)
        p3_group = VGroup(p3_dot, p3_text).arrange(RIGHT, buff=0.2)

        # Aligning text parts
        list_group = VGroup(p1_group, p2_group, p3_group).arrange(DOWN, aligned_edge=LEFT, buff=0.5)
        # Manually aligning text labels to start at the same x-coordinate
        p1_text.align_to(p2_text, LEFT)
        p3_text.align_to(p2_text, LEFT)

        list_group.next_to(vessel_img, RIGHT, buff=1.0)
        list_group.shift(UP * 0.5)

        # 4. Bottom Relation Logic
        relation = MathTex(r"\text{Higher Pressure/Volume} \rightarrow \text{More Severe Consequences}", font_size=28, color=YELLOW)
        relation.next_to(list_group, DOWN, buff=1.0)
        relation.align_to(list_group, LEFT)

        relation_box = SurroundingRectangle(relation, color=YELLOW, buff=0.15)

        # 5. Animation Sequence

        # Step 1: Show Vessel and Stored Energy concept
        self.play(FadeIn(vessel_img, shift=RIGHT), FadeIn(p1_group, shift=LEFT))

        # Step 2: Show Rupture and Shockwave
        self.play(
            FadeOut(vessel_img),
            FadeIn(rupture_img, scale=1.1),
            FadeIn(p2_group, shift=LEFT)
        )

        # Step 3: Toxic danger
        self.play(FadeIn(p3_group, shift=LEFT))

        # Step 4: Summary Relation
        self.play(
            Write(relation),
            Create(relation_box)
        )
