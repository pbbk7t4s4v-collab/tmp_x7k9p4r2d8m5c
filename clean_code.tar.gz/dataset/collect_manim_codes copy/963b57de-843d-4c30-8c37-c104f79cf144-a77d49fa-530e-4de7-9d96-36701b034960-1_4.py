from manim import *

class FluidMechanicsApplicationsScene(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Fluid Mechanics: Industrial & Energy Applications",
                     font_size=34,
                     color=WHITE,
                     weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Industrial Manufacturing Section
        industrial_header = Text("Industrial Manufacturing", font_size=28, weight=BOLD)
        industrial_header.next_to(title_group, DOWN, buff=0.5)

        industrial_points = BulletedList(
            "Chemical Reactors: Gas-liquid mixing",
            "Pipelines: Multiphase fluid transport",
            "Heat Exchangers: Coolant circulation",
            "Goal: Enhance efficiency and reduce pollution",
            font_size=26,
            buff=0.2
        )
        industrial_points.next_to(industrial_header, DOWN, buff=0.3).align_to(industrial_header, LEFT)

        industrial_group = VGroup(industrial_header, industrial_points)

        self.play(FadeIn(industrial_header, shift=DOWN*0.5), run_time=0.8)
        self.play(Write(industrial_points), run_time=3.0)

        # 3. Transition to Energy Section
        self.play(FadeOut(industrial_group, shift=DOWN*0.5), run_time=1.0)

        # 4. Energy Utilization Section
        energy_header = Text("Energy Utilization", font_size=28, weight=BOLD)
        energy_header.next_to(title_group, DOWN, buff=0.5)

        energy_points = BulletedList(
            "Wind Turbines: Blade design to maximize energy capture",
            "Hydroelectric Plants: Flow analysis to boost power generation",
            font_size=26,
            buff=0.3
        )
        energy_points.next_to(energy_header, DOWN, buff=0.3).align_to(energy_header, LEFT)

        energy_group = VGroup(energy_header, energy_points)

        self.play(FadeIn(energy_header, shift=DOWN*0.5), run_time=0.8)
        self.play(Write(energy_points), run_time=3.0)

        # 5. Final Wait
