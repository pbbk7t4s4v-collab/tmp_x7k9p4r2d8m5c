from manim import *

class WhatIsFluidMechanics(Scene):
    def construct(self):

        # 1. 标题
        title = Text(
            "流体力学是什么",
            font_size=34,
            font="AR PL UKai CN",
            color=WHITE,
            weight=BOLD
        )
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心定义
        definition = Text(
            "一门研究流体（液体、气体）力学行为的科学。",
            font="AR PL UKai CN",
            font_size=28,
            t2c={"液体": BLUE_C, "气体": GREEN_C}
        ).next_to(title_group, DOWN, buff=0.4)
        self.play(Write(definition), run_time=2.5)

        # 3. 可视化液体和气体
        # 液体
        liquid_label = Text("液体", font="AR PL UKai CN", font_size=28, color=BLUE_C)
        beaker = VGroup(
            Line(UP*0.8 + LEFT*0.6, DOWN*0.8 + LEFT*0.6),
            Line(DOWN*0.8 + LEFT*0.6, DOWN*0.8 + RIGHT*0.6),
            Line(DOWN*0.8 + RIGHT*0.6, UP*0.8 + RIGHT*0.6)
        )
        water = Rectangle(
            height=1.0, width=1.2, fill_color=BLUE_C, fill_opacity=0.6, stroke_width=0
        ).align_to(beaker, DOWN)
        liquid_visual = VGroup(water, beaker)
        liquid_group = VGroup(liquid_visual, liquid_label).arrange(DOWN, buff=0.2)

        # 气体
        gas_label = Text("气体", font="AR PL UKai CN", font_size=28, color=GREEN_C)
        gas_box = Square(side_length=1.6, color=WHITE)
        dots = VGroup(*[Dot(radius=0.04, color=WHITE).move_to(gas_box.get_center() +
                                              np.random.uniform(-0.7, 0.7, 3)) for _ in range(20)])
        gas_visual = VGroup(gas_box, dots)
        gas_group = VGroup(gas_visual, gas_label).arrange(DOWN, buff=0.2)

        # 并排排列
        fluid_types_group = VGroup(liquid_group, gas_group).arrange(RIGHT, buff=2.5)
        fluid_types_group.next_to(definition, DOWN, buff=0.6)
        self.play(FadeIn(fluid_types_group, shift=UP), run_time=1.5)

        # 4. 流体力学的主要分支
        # 流体静力学
        statics_title = Text("流体静力学", font="AR PL UKai CN", font_size=28, color=BLUE_C)
        statics_desc = Text("研究静止状态的流体", font="AR PL UKai CN", font_size=24)
        statics_group = VGroup(statics_title, statics_desc).arrange(DOWN, buff=0.15)
        statics_group.next_to(liquid_group, DOWN, buff=0.7)

        # 流体动力学
        dynamics_title = Text("流体动力学", font="AR PL UKai CN", font_size=28, color=GREEN_C)
        dynamics_desc = Text("研究运动状态的流体", font="AR PL UKai CN", font_size=24)
        dynamics_group = VGroup(dynamics_title, dynamics_desc).arrange(DOWN, buff=0.15)
        dynamics_group.next_to(gas_group, DOWN, buff=0.7)

        self.play(
            FadeIn(statics_group, shift=UP),
            FadeIn(dynamics_group, shift=UP),
            run_time=1.5
        )

        # 5. 将分支与可视化联系起来
        statics_rect = SurroundingRectangle(VGroup(liquid_group, statics_group), color=BLUE_C, buff=0.2)
        dynamics_rect = SurroundingRectangle(VGroup(gas_group, dynamics_group), color=GREEN_C, buff=0.2)

        self.play(
            Create(statics_rect),
            run_time=1.0
        )
        self.play(
            Create(dynamics_rect),
            run_time=1.0
        )
