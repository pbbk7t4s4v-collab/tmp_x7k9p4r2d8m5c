from manim import *

class FluidDynamicsApplications(Scene):
    def construct(self):

        # 1. Create Title
        title = Text("Fluid Dynamics in Engineering",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.scale(0.95)  # 修复：轻微缩放标题避免组宽接近边界
        title.to_edge(UP, buff=0.6)  # 修复：上移缓冲增加防止整体高度过高
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.15)  # 修复：增大间距以优化层次感
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.35)  # 修复：稍微增加右下角缓冲，防止靠近边界
        self.play(FadeIn(page_number))

        # 2. General Statement
        intro_text = Text(
            "Fluid dynamics is crucial for system efficiency and safety.",
            font_size=28,
            color=BLUE_C
        )
        intro_text.scale(0.95)  # 修复：轻微缩小防止与标题组及列表元素接近边界
        intro_text.next_to(title_group, DOWN, buff=0.55)  # 修复：略增buff以减少遮挡风险
        self.play(FadeIn(intro_text, shift=DOWN), run_time=1.5)

        # 3. Bulleted List of Applications
        applications_list = BulletedList(
            "Aerospace Engineering: Optimizing airfoil lift and drag for performance and fuel economy.",
            "Space Engineering: Designing rocket nozzles for maximum thrust efficiency.",
            "Energy Engineering: Shaping turbine blades to maximize energy conversion.",
            font_size=26
        )
        applications_list.scale(0.92)  # 修复：缩小列表避免左侧过近边界
        applications_list.next_to(intro_text, DOWN, buff=0.55).to_edge(LEFT, buff=0.9)  # 修复：略增左边距以安全排版

        # Animate list items one by one
        for item in applications_list:
            self.play(Write(item), run_time=2)
