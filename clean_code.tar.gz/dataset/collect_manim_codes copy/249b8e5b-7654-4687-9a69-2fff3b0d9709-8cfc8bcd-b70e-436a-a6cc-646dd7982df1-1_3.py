from manim import *

class BarChartExplanation(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("柱状图：类别比较与多组展示",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 垂直柱状图 (基础比较)
        # ---------------------------------------------------------
        # 左侧区域
        left_axes = Axes(
            x_range=[0, 4, 1],
            y_range=[0, 5, 1],
            x_length=4,
            y_length=3,
            axis_config={"include_tip": False, "color": GRAY},
        ).shift(LEFT * 3.5 + DOWN * 0.5)

        # 数据：[3, 4, 2]
        data_v = [3, 4, 2]
        bars_v = VGroup()
        for i, val in enumerate(data_v):
            bar = Rectangle(
                width=0.6,
                height=val * 0.6, # 比例缩放以适应坐标轴
                color=BLUE,
                fill_opacity=0.8
            )
            # 将柱子底部对齐x轴,水平位置对应
            bar.move_to(left_axes.c2p(i + 1, 0), aligned_edge=DOWN)
            bars_v.add(bar)

        label_v = Text("垂直柱状图 (plt.bar)", font="AR PL UKai CN", font_size=24, color=BLUE)
        label_v.next_to(left_axes, DOWN)

        # 动画展示左侧
        self.play(Create(left_axes), run_time=1)
        self.play(
            LaggedStart(
                *[GrowFromEdge(bar, DOWN) for bar in bars_v],
                lag_ratio=0.2
            ),
            FadeIn(label_v),
            run_time=1.5
        )

        # ---------------------------------------------------------
        # 3. 水平柱状图 (barh)
        # ---------------------------------------------------------
        # 右侧区域
        right_axes = Axes(
            x_range=[0, 5, 1],
            y_range=[0, 4, 1],
            x_length=3,
            y_length=3,
            axis_config={"include_tip": False, "color": GRAY},
        ).shift(RIGHT * 3.5 + DOWN * 0.5)

        data_h = [2, 3, 4]
        bars_h = VGroup()
        for i, val in enumerate(data_h):
            bar = Rectangle(
                width=val * 0.6, # 宽度代表数值
                height=0.6,
                color=GREEN,
                fill_opacity=0.8
            )
            # 将柱子左侧对齐y轴
            bar.move_to(right_axes.c2p(0, i + 1), aligned_edge=LEFT)
            bars_h.add(bar)

        label_h = Text("水平柱状图 (plt.barh)", font="AR PL UKai CN", font_size=24, color=GREEN)
        label_h.next_to(right_axes, DOWN)

        # 动画展示右侧
        self.play(Create(right_axes), run_time=1)
        self.play(
            LaggedStart(
                *[GrowFromEdge(bar, LEFT) for bar in bars_h],
                lag_ratio=0.2
            ),
            FadeIn(label_h),
            run_time=1.5
        )

        # ---------------------------------------------------------
        # 4. 多组数据对比 (在左侧图上添加一组数据)
        # ---------------------------------------------------------
        # 新的一组数据 [2, 3, 1]
        data_v2 = [2, 3, 1]
        bars_v2 = VGroup()

        # 调整原柱子位置(变瘦并向左移,腾出空间)
        new_bars_v_anims = []
        for bar in bars_v:
            new_bars_v_anims.append(
                bar.animate.stretch_to_fit_width(0.3).shift(LEFT * 0.15)
            )

        # 创建第二组柱子
        for i, val in enumerate(data_v2):
            bar = Rectangle(
                width=0.3,
                height=val * 0.6,
                color=ORANGE,
                fill_opacity=0.8
            )
            # 放在原位置的右侧一点
            ref_point = left_axes.c2p(i + 1, 0)
            bar.move_to(ref_point, aligned_edge=DOWN).shift(RIGHT * 0.15)
            bars_v2.add(bar)

        label_multi = Text("多组数据对比", font="AR PL UKai CN", font_size=24, color=ORANGE)
        label_multi.next_to(label_v, DOWN, buff=0.2)

        # 强调框
        rect = SurroundingRectangle(VGroup(left_axes, bars_v, bars_v2), color=YELLOW, buff=0.2)

        self.play(
            *new_bars_v_anims,
            LaggedStart(
                *[GrowFromEdge(bar, DOWN) for bar in bars_v2],
                lag_ratio=0.1
            ),
            Transform(label_v, label_v), # 保持原标签不动
            Write(label_multi),
            Create(rect),
            run_time=2
        )
