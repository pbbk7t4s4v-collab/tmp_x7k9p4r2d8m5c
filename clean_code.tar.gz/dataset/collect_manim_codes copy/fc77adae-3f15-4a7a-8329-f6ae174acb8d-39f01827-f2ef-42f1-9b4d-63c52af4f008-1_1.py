from manim import *

class FluidMechanicsIntroScene(Scene):
    def construct(self):

        # 1. Title setup
        title = Text("What is Fluid Mechanics?",
                     font_size=34,
                     color=WHITE,
                     weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.2),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Subtitle
        subtitle = Text("Role and Importance", font_size=28, color=BLUE_C)
        subtitle.next_to(title_group, DOWN, buff=0.4)
        self.play(FadeIn(subtitle, shift=DOWN*0.5), run_time=0.8)

        # 3. Core Definition
        definition_text = Text(
            "The science of fluid (liquids, gases) motion and its interactions.",
            font_size=26,
            line_spacing=1.1
        ).next_to(subtitle, DOWN, buff=0.7)

        self.play(Write(definition_text), run_time=2.0)

        highlight_box = SurroundingRectangle(definition_text, color=YELLOW, buff=0.2)
        self.play(Create(highlight_box), run_time=0.8)
        self.play(FadeOut(highlight_box), run_time=0.5)

        # 4. Scope of Fluid Mechanics using BulletedList
        scope_intro = Text("It covers:", font_size=26).next_to(definition_text, DOWN, buff=0.7).to_edge(LEFT, buff=1.0)

        scope_list = BulletedList(
            "Macroscopic properties of continuous media",
            "Statistical laws of microscopic molecular motion",
            "Flow behavior under complex boundary conditions",
            font_size=24,
            buff=0.3
        ).next_to(scope_intro, DOWN, buff=0.3, aligned_edge=LEFT)

        self.play(Write(scope_intro), run_time=0.8)

        for item in scope_list:
            self.play(FadeIn(item, shift=RIGHT*0.2), run_time=0.7)

        # 5. Final Importance Statement
        importance_text = Text(
            "Plays an irreplaceable role in engineering, natural sciences, and economics.",
            font_size=26,
            color=GREEN_C
        ).next_to(scope_list, DOWN, buff=0.7)

        self.play(FadeIn(importance_text), run_time=1.5)
