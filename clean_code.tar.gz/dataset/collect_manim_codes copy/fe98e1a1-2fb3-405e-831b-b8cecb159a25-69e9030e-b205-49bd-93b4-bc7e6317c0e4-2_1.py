from manim import *

class CourseIntroScene(Scene):
    def construct(self):

        # 1. 标题部分 - 严格按照模板
        title = Text("神奇的AI画家：课程概览",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 图片展示 - 左侧
        # 严格遵守Planner建议和格式
        img = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/fe98e1a1-2fb3-405e-831b-b8cecb159a25/69e9030e-b205-49bd-93b4-bc7e6317c0e4/pictures/2_1/1.png") # 这里期望是一张展示AI机器人画家的图片，要求画面造型可爱的AI机器人画家,戴着艺术家的贝雷帽,手持画笔,正在画布上绘制出充满魔法光彩的绚丽图像,象征着'从想象到图像的魔法',写实风

        # 调整图片大小和位置，保持1:1比例
        img.height = 4.0
        img.width = 4.0
        img.to_edge(LEFT, buff=1.0)
        img.shift(DOWN * 0.2)

        # 3. 课程信息文本 - 右侧
        # 使用 Text 组合构建列表，避免 BulletedList 的潜在 LaTeX 问题

        # 定义样式
        label_style = {"font": "AR PL UKai CN", "font_size": 24, "color": TEAL}
        text_style = {"font": "AR PL UKai CN", "font_size": 24, "color": WHITE}

        # 第一行：课程主题
        row1_label = Text("课程主题：", **label_style)
        row1_text = Text("图像生成人工智能的科普与体验", **text_style)
        row1 = VGroup(row1_label, row1_text).arrange(RIGHT, buff=0.1)

        # 第二行：课程形式
        row2_label = Text("课程形式：", **label_style)
        row2_text = Text("互动讲解 + 实时演示 + 辩论赛", **text_style)
        row2 = VGroup(row2_label, row2_text).arrange(RIGHT, buff=0.1)

        # 第三行：核心目标
        row3_label = Text("核心目标：", **label_style)
        row3_text = Text("理解原理 / 掌握提示词 / 辩证思考", **text_style)
        row3 = VGroup(row3_label, row3_text).arrange(RIGHT, buff=0.1)

        # 组合文本块
        text_group = VGroup(row1, row2, row3).arrange(DOWN, buff=0.6, aligned_edge=LEFT)
        text_group.next_to(img, RIGHT, buff=1.0)
        text_group.shift(UP * 0.5) # 稍微上移，给下方留空间

        # 4. 底部适用人群提示框
        note_text = Text("适用对象：零基础初学者 (无需编程或美术基础)",
                        font="AR PL UKai CN", font_size=20, color=YELLOW)

        # 使用 SurroundingRectangle
        note_box = SurroundingRectangle(note_text, color=YELLOW, buff=0.2, stroke_width=2)
        note_group = VGroup(note_box, note_text)

        # 定位在文本组下方
        note_group.next_to(text_group, DOWN, buff=0.8)
        note_group.align_to(text_group, LEFT)

        # 5. 动画流程
        # 图片淡入
        self.play(FadeIn(img, shift=RIGHT))

        # 文本逐行显示
        self.play(
            LaggedStart(
                Write(row1),
                Write(row2),
                Write(row3),
                lag_ratio=0.5,
                run_time=3.0
            )
        )

        # 底部提示框出现
        self.play(
            Create(note_box),
            Write(note_text)
        )
