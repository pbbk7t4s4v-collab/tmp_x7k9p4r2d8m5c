from manim import *

class NumberSymbolExplosion(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("数字符号的文明大爆发",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计

        # 左侧：原始阶段(结绳与刻痕)
        # 绘制简单的绳结示意图
        rope = Line(UP*1.25, DOWN*1.25, color=GREY_B).set_stroke(width=4)
        knot1 = Dot(radius=0.12, color=GREY_B).move_to(rope.get_center() + UP*0.5)
        knot2 = Dot(radius=0.12, color=GREY_B).move_to(rope.get_center() + DOWN*0.5)
        rope_group = VGroup(rope, knot1, knot2)

        # 绘制简单的刻痕骨头示意图
        bone = RoundedRectangle(corner_radius=0.2, height=2.5, width=0.6, color=BEIGE, fill_opacity=0.5, fill_color=BLACK)
        notch1 = Line(LEFT*0.2, RIGHT*0.2, color=BEIGE).move_to(bone.get_center() + UP*0.6)
        notch2 = Line(LEFT*0.2, RIGHT*0.2, color=BEIGE).move_to(bone.get_center())
        notch3 = Line(LEFT*0.2, RIGHT*0.2, color=BEIGE).move_to(bone.get_center() + DOWN*0.6)
        bone_group = VGroup(bone, notch1, notch2, notch3)

        # 组合左侧元素
        left_visuals = VGroup(rope_group, bone_group).arrange(RIGHT, buff=0.5)
        left_label = Text("简单记录：结绳/刻痕", font="AR PL UKai CN", font_size=20, color=GREY_A).next_to(left_visuals, DOWN)
        left_section = VGroup(left_visuals, left_label)

        # 中间：演变过程(箭头与原因)
        arrow = Arrow(LEFT, RIGHT, color=YELLOW, buff=0.2).scale(1.2)
        reason_text = Text("社会发展\n需求复杂", font="AR PL UKai CN", font_size=18, color=YELLOW).next_to(arrow, UP, buff=0.1)
        mid_section = VGroup(arrow, reason_text)

        # 右侧：文明大爆发(符号的多样性)
        # 使用几何图形代表不同文明的符号系统

        # 古埃及(象形) - 用简单的矩形框模拟
        civ1_shape = Square(side_length=0.8, color=BLUE)
        civ1_text = Text("古埃及", font="AR PL UKai CN", font_size=16).move_to(civ1_shape)
        civ1 = VGroup(civ1_shape, civ1_text)

        # 古巴比伦(楔形) - 用倒三角形模拟
        civ2_shape = Triangle(color=GREEN).scale(0.6).rotate(PI)
        civ2_text = Text("巴比伦", font="AR PL UKai CN", font_size=16).move_to(civ2_shape).shift(UP*0.1)
        civ2 = VGroup(civ2_shape, civ2_text)

        # 古中国(甲骨) - 用六边形模拟
        civ3_shape = RegularPolygon(n=6, color=RED).scale(0.6)
        civ3_text = Text("古中国", font="AR PL UKai CN", font_size=16).move_to(civ3_shape)
        civ3 = VGroup(civ3_shape, civ3_text)

        # 布局右侧符号：呈现"爆发"状
        civ_icons = VGroup(civ1, civ2, civ3).arrange(DOWN, buff=0.4)
        # 将中间的向右推一点，形成三角形布局
        civ2.shift(RIGHT*0.5)
        civ1.shift(LEFT*0.2)
        civ3.shift(LEFT*0.2)

        right_label = Text("创造专属符号体系", font="AR PL UKai CN", font_size=24, color=ORANGE).next_to(civ_icons, UP, buff=0.3)
        right_section = VGroup(right_label, civ_icons)

        # 3. 整体布局定位
        # 将三部分编组并居中
        main_content = VGroup(left_section, mid_section, right_section).arrange(RIGHT, buff=0.8)
        main_content.move_to(ORIGIN).shift(DOWN*0.3) # 稍微下移避开标题

        # 4. 动画流程
        # 第一步：展示原始状态
        self.play(FadeIn(left_section, shift=UP), run_time=1)

        # 第二步：展示转变原因
        self.play(GrowArrow(arrow), Write(reason_text), run_time=1)

        # 第三步：展示符号爆发
        self.play(
            FadeIn(right_label, scale=0.8),
            AnimationGroup(
                GrowFromCenter(civ1),
                GrowFromCenter(civ2),
                GrowFromCenter(civ3),
                lag_ratio=0.2
            ),
            run_time=1.5
        )

        # 第四步：强调框
        rect = SurroundingRectangle(right_section, color=ORANGE, buff=0.2)
        self.play(Create(rect))
