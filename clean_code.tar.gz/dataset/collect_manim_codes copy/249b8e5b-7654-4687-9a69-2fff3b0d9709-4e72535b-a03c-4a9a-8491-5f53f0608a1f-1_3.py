from manim import *

class ListTraversalLoop(Scene):
    def construct(self):

        # 1. 标题设置 (符合模板要求)
        title = Text("Python列表遍历：for循环",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("3", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局设计 - 左侧代码,右侧可视化

        # 模拟代码显示 (使用Text避免Code类的font_size问题)
        code_str = 'fruits = ["苹果", "香蕉", "橙子"]\n\nfor fruit in fruits:\n    print(fruit)'
        code_text = Text(
            code_str,
            font="Monospace",
            font_size=24,
            line_spacing=1.2,
            t2c={"for": ORANGE, " in ": ORANGE, "print": BLUE, "fruits": YELLOW, '"苹果"': GREEN, '"香蕉"': GREEN, '"橙子"': GREEN}
        )
        code_text.to_edge(LEFT, buff=1).shift(UP * 0.5)

        # 代码框
        code_box = SurroundingRectangle(code_text, color=GRAY, buff=0.2)
        code_label = Text("代码逻辑", font="AR PL UKai CN", font_size=20, color=GRAY).next_to(code_box, UP, aligned_edge=LEFT)

        # 3. 列表可视化对象
        data_items = ["苹果", "香蕉", "橙子"]
        list_group = VGroup()

        for item in data_items:
            box = Square(side_length=1.2, color=BLUE_C, fill_opacity=0.2, fill_color=BLUE_E)
            txt = Text(item, font="AR PL UKai CN", font_size=22)
            item_group = VGroup(box, txt)
            list_group.add(item_group)

        list_group.arrange(RIGHT, buff=0.1)
        list_group.to_edge(RIGHT, buff=1).align_to(code_text, UP)

        list_name = Text("列表: fruits", font="AR PL UKai CN", font_size=24, color=YELLOW).next_to(list_group, UP, buff=0.2)

        # 4. 变量与指针
        arrow = Arrow(start=UP, end=DOWN, color=ORANGE).scale(0.8)
        variable_label = Text("当前变量 fruit", font="AR PL UKai CN", font_size=24, color=ORANGE)
        variable_val = Text("?", font="AR PL UKai CN", font_size=24)

        variable_group = VGroup(variable_label, variable_val).arrange(DOWN, buff=0.2)
        variable_group.next_to(list_group, DOWN, buff=1.5)

        # 5. 动画流程
        # 展示代码和列表结构
        self.play(
            FadeIn(code_label),
            Write(code_text),
            Create(code_box),
            run_time=1
        )
        self.play(
            Write(list_name),
            Create(list_group),
            FadeIn(variable_group),
            run_time=1
        )

        # 循环动画
        last_val_text = variable_val

        # 为了控制时长,只演示前两个元素的遍历
        for i in range(2):
            target_box = list_group[i]
            item_text = data_items[i]

            # 移动箭头指向当前元素
            arrow_anim = arrow.animate.next_to(target_box, UP, buff=0.1)
            if i == 0:
                arrow.next_to(target_box, UP, buff=0.1)
                arrow_anim = FadeIn(arrow)

            # 更新变量值
            new_val_text = Text(f'"{item_text}"', font="AR PL UKai CN", font_size=24, color=GREEN)
            new_val_text.move_to(last_val_text.get_center())

            self.play(
                arrow_anim,
                Transform(last_val_text, new_val_text),
                Indicate(target_box, color=ORANGE, scale_factor=1.1),
                run_time=0.8
            )

            # 模拟打印效果(在变量下方闪烁一下)
            print_effect = Text(f"print: {item_text}", font="Monospace", font_size=20, color=BLUE)
            print_effect.next_to(variable_group, DOWN, buff=0.2)
            self.play(FadeIn(print_effect, shift=UP*0.2), run_time=0.5)
            self.play(FadeOut(print_effect), run_time=0.3)

            last_val_text = new_val_text

        # 结束定格
