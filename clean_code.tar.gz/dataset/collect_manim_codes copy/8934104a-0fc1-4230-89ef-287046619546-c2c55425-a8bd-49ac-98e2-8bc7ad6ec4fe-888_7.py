from manim import *

class GeneratorSendMethod(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("生成器的send()方法",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 布局设计：左侧为交互示意图，右侧为核心代码逻辑

        # --- 左侧：主程序与生成器的交互 ---
        left_group = VGroup()

        # 主程序框
        main_box = RoundedRectangle(corner_radius=0.2, width=3, height=1.5, color=BLUE)
        main_text = Text("主程序", font="AR PL UKai CN", font_size=24).move_to(main_box)
        main_group = VGroup(main_box, main_text)

        # 生成器框
        gen_box = RoundedRectangle(corner_radius=0.2, width=3, height=1.5, color=GREEN)
        gen_text = Text("生成器", font="AR PL UKai CN", font_size=24).move_to(gen_box)
        gen_group = VGroup(gen_box, gen_text)

        # 垂直排列
        main_group.move_to(LEFT * 3.5 + UP * 1)
        gen_group.next_to(main_group, DOWN, buff=1.5)

        # 箭头交互
        # 1. next() 启动/继续
        arrow_next = Arrow(start=main_group.get_bottom() + LEFT*0.5,
                          end=gen_group.get_top() + LEFT*0.5,
                          buff=0.1, color=YELLOW)
        label_next = Text("next(gen)", font_size=18, font="AR PL UKai CN", color=YELLOW).next_to(arrow_next, LEFT)

        # 2. yield 返回值
        arrow_yield = Arrow(start=gen_group.get_top() + RIGHT*0.5,
                           end=main_group.get_bottom() + RIGHT*0.5,
                           buff=0.1, color=WHITE)
        label_yield = Text("yield value", font_size=18, font="AR PL UKai CN").next_to(arrow_yield, RIGHT)

        # 3. send() 发送数据 (这里用曲线表示特殊的注入通道)
        arrow_send = CurvedArrow(main_group.get_right(), gen_group.get_right(), angle=-TAU/4, color=RED)
        label_send = Text("gen.send(msg)", font_size=18, font="AR PL UKai CN", color=RED).next_to(arrow_send, RIGHT)

        left_content = VGroup(main_group, gen_group, arrow_next, label_next, arrow_yield, label_yield, arrow_send, label_send)

        # --- 右侧：关键代码逻辑 ---

        # 代码背景框
        code_bg = SurroundingRectangle(left_content, color=GRAY, buff=0.2).set_opacity(0).move_to(RIGHT * 3)

        # 核心语法展示
        syntax_title = Text("核心语法逻辑", font="AR PL UKai CN", font_size=28, color=TEAL).move_to(RIGHT * 3.5 + UP * 1.5)

        # 模拟代码行
        code_line = MathTex(r"\text{received} = \text{yield } \text{value}", font_size=36).next_to(syntax_title, DOWN, buff=0.8)

        # 解释说明
        expl_1 = Text("1. yield暂停并产出value", font="AR PL UKai CN", font_size=20, color=WHITE).next_to(code_line, DOWN, buff=0.5).align_to(code_line, LEFT)
        expl_2 = Text("2. send传入值赋给received", font="AR PL UKai CN", font_size=20, color=RED).next_to(expl_1, DOWN, buff=0.3).align_to(expl_1, LEFT)

        # 结论
        conclusion = Text("实现双向通信", font="AR PL UKai CN", font_size=32, color=YELLOW, weight=BOLD).next_to(expl_2, DOWN, buff=0.8).move_to(RIGHT * 3.5 + DOWN * 2)

        # 3. 动画流程

        # 显示左侧框架
        self.play(FadeIn(main_group), FadeIn(gen_group))

        # 演示交互流程
        self.play(GrowArrow(arrow_next), Write(label_next))
        self.play(GrowArrow(arrow_yield), Write(label_yield))

        # 强调 send 方法
        self.play(Create(arrow_send), Write(label_send))

        # 显示右侧语法解析
        self.play(Write(syntax_title))
        self.play(Write(code_line))

        # 分步解释代码
        # 框选 yield value
        box_yield = SurroundingRectangle(code_line[0][9:], color=WHITE, buff=0.05)
        self.play(Create(box_yield), FadeIn(expl_1))

        # 框选 received
        box_recv = SurroundingRectangle(code_line[0][:8], color=RED, buff=0.05)
        self.play(ReplacementTransform(box_yield, box_recv), FadeIn(expl_2))

        # 总结
        self.play(FadeIn(conclusion), FadeOut(box_recv))
