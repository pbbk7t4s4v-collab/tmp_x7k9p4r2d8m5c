from manim import *

class TsFileComparison(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("TsFile与主流文件格式对比",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("18", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧 CSV
        csv_title = Text("CSV格式", font="AR PL UKai CN", font_size=30, color=RED_C)
        csv_items = VGroup(
            Text("优点：易于阅读", font="AR PL UKai CN", font_size=24, color=GRAY_A),
            Text("缺点：存储冗余大", font="AR PL UKai CN", font_size=24, color=RED_B),
            Text("缺点：解析速度慢", font="AR PL UKai CN", font_size=24, color=RED_B),
            Text("缺点：不支持复杂类型", font="AR PL UKai CN", font_size=24, color=RED_B)
        ).arrange(DOWN, buff=0.3, aligned_edge=LEFT)

        csv_group = VGroup(csv_title, csv_items).arrange(DOWN, buff=0.5)
        csv_box = SurroundingRectangle(csv_group, color=RED_D, buff=0.3)
        csv_full = VGroup(csv_box, csv_group).to_edge(LEFT, buff=1).shift(DOWN*0.5)

        # 3. 内容布局 - 右侧 Parquet/Arrow
        pa_title = Text("Parquet / Arrow", font="AR PL UKai CN", font_size=30, color=BLUE_C)
        pa_items = VGroup(
            Text("优点：通用列存格式", font="AR PL UKai CN", font_size=24, color=GREEN_B),
            Text("优点：查询性能较好", font="AR PL UKai CN", font_size=24, color=GREEN_B),
            Text("缺点：乱序写入开销大", font="AR PL UKai CN", font_size=24, color=ORANGE),
            Text("缺点：时序场景适配弱", font="AR PL UKai CN", font_size=24, color=ORANGE)
        ).arrange(DOWN, buff=0.3, aligned_edge=LEFT)

        pa_group = VGroup(pa_title, pa_items).arrange(DOWN, buff=0.5)
        pa_box = SurroundingRectangle(pa_group, color=BLUE_D, buff=0.3)
        pa_full = VGroup(pa_box, pa_group).to_edge(RIGHT, buff=1).shift(DOWN*0.5)

        # 4. 动画展示
        # 左侧入场
        self.play(Create(csv_box), FadeIn(csv_title))
        self.play(Write(csv_items), run_time=2)

        # 右侧入场
        self.play(Create(pa_box), FadeIn(pa_title))
        self.play(Write(pa_items), run_time=2)

        # 5. 总结强调箭头（可选，视时间而定，这里简单强调对比）
        vs_text = Text("VS", font="AR PL UKai CN", font_size=40, color=YELLOW, weight=BOLD)
        vs_text.move_to((csv_full.get_center() + pa_full.get_center()) / 2)

        self.play(FadeIn(vs_text, scale=1.5))
