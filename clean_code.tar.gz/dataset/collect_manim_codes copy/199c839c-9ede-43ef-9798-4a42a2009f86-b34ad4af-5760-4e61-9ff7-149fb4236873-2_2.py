from manim import *

class GovernmentExpenditureMultiplier(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("政府支出乘数公式推导",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 聚焦财政政策说明
        # 这一步是为了引出公式的前提
        intro_text = Text("聚焦财政政策：只考虑政府支出 G 的变化",
                         font_size=26,
                         font="AR PL UKai CN",
                         color=LIGHT_GRAY)
        intro_text.next_to(title_line, DOWN, buff=0.5)
        self.play(FadeIn(intro_text))

        # 3. 增量公式展示
        # 使用 MathTex 展示数学公式
        delta_formula = MathTex(r"\Delta Y", r"=", r"\frac{1}{1 - c}", r"\Delta G")
        delta_formula.scale(1.2)
        delta_formula.next_to(intro_text, DOWN, buff=0.5)
        # 强调系数部分
        delta_formula[2].set_color(YELLOW)

        self.play(Write(delta_formula))

        # 4. 推导乘数定义
        # 添加推导箭头
        arrow_down = Arrow(start=delta_formula.get_bottom(), end=delta_formula.get_bottom() + DOWN*1.2, color=WHITE, buff=0.1)

        # 乘数公式 k_G
        multiplier_eq = MathTex(r"k_G", r"=", r"\frac{\Delta Y}{\Delta G}", r"=", r"\frac{1}{1 - c}")
        multiplier_eq.scale(1.3)
        multiplier_eq.next_to(arrow_down, DOWN, buff=0.1)
        multiplier_eq[0].set_color(BLUE) # k_G
        multiplier_eq[4].set_color(YELLOW) # 1/(1-c)

        # 为最终公式添加边框
        box = SurroundingRectangle(multiplier_eq, color=BLUE, buff=0.2)
        box_label = Text("政府支出乘数", font_size=22, font="AR PL UKai CN", color=BLUE)
        box_label.next_to(box, RIGHT, buff=0.2)

        self.play(GrowArrow(arrow_down))
        self.play(Write(multiplier_eq))
        self.play(Create(box), FadeIn(box_label))

        # 5. 结论与可视化
        # 结论文字：因为 0 < c < 1，所以乘数 > 1
        conclusion_group = VGroup()
        cond_text = MathTex(r"0 < c < 1 \Rightarrow \frac{1}{1-c} > 1")
        effect_text = Text("存在"放大效应"", font_size=28, font="AR PL UKai CN", color=RED)

        conclusion_group.add(cond_text, effect_text)
        conclusion_group.arrange(DOWN, buff=0.2, aligned_edge=LEFT)
        conclusion_group.to_edge(DOWN, buff=1.0).to_edge(LEFT, buff=1.5)

        # 可视化：小方块变成大方块
        viz_group = VGroup()

        # 输入：Delta G
        square_g = Square(side_length=0.6, color=WHITE, fill_opacity=0.5)
        label_g = MathTex(r"\Delta G").scale(0.6).move_to(square_g)
        group_g = VGroup(square_g, label_g)

        # 箭头
        viz_arrow = Arrow(LEFT, RIGHT, color=YELLOW)

        # 输出：Delta Y (更大的方块)
        square_y = Square(side_length=1.2, color=ORANGE, fill_opacity=0.8)
        label_y = MathTex(r"\Delta Y").scale(0.8).move_to(square_y)
        group_y = VGroup(square_y, label_y)

        viz_group.add(group_g, viz_arrow, group_y)
        viz_group.arrange(RIGHT, buff=0.3)
        viz_group.next_to(conclusion_group, RIGHT, buff=1.5)
        # 对齐垂直中心
        viz_group.match_y(conclusion_group)

        # 播放底部动画
        self.play(
            Write(cond_text),
            FadeIn(group_g, shift=UP)
        )
        self.play(
            Write(effect_text),
            GrowArrow(viz_arrow),
            TransformFromCopy(group_g, group_y)
        )

        # 最后强调一下放大效应文字
        self.play(Indicate(effect_text, scale_factor=1.2, color=RED))
