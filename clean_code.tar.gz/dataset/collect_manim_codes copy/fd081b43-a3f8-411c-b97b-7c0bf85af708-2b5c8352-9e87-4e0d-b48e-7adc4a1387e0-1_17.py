from manim import *

class MacroEquilibriumDerivation(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("宏观经济均衡条件推导",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("17", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 第一部分:板书均衡条件
        label_1 = Text("板书均衡条件:", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        # Y = C + I + G
        # 将 C 单独分出来以便后续强调
        eq_1 = MathTex("Y", "=", "C", "+", "I", "+", "G", font_size=48)
        eq_1.set_color_by_tex("C", YELLOW) # 强调 C

        group_1 = VGroup(label_1, eq_1).arrange(DOWN, buff=0.3)
        group_1.shift(UP * 1.2)

        # 第二部分:代入消费函数
        label_2 = Text("代入消费函数:", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        # Y = C0 + cY + I + G
        eq_2 = MathTex("Y", "=", "C_0 + cY", "+", "I", "+", "G", font_size=48)
        eq_2.set_color_by_tex("C_0 + cY", YELLOW) # 强调替换后的部分

        group_2 = VGroup(label_2, eq_2).arrange(DOWN, buff=0.3)
        group_2.next_to(group_1, DOWN, buff=1.0)

        # 连接箭头
        arrow = Arrow(start=eq_1.get_bottom(), end=eq_2.get_top(), color=GREY_B, buff=0.2)

        # 第三部分:底部说明
        note_text = Text("说明:这个简单方程就是我们推导乘数效应的起点",
                         font="AR PL UKai CN", font_size=24, color=GREY_A)
        note_rect = SurroundingRectangle(note_text, color=WHITE, buff=0.2, stroke_width=1)
        note_group = VGroup(note_rect, note_text).to_edge(DOWN, buff=0.8)

        # 3. 动画展示
        # 展示第一步
        self.play(
            FadeIn(label_1, shift=RIGHT),
            Write(eq_1)
        )

        # 展示箭头和第二步
        self.play(
            GrowArrow(arrow),
            FadeIn(label_2, shift=RIGHT)
        )

        # 强调替换过程
        self.play(
            TransformMatchingShapes(eq_1.copy(), eq_2), # 变换动画展示代入过程
            run_time=1.5
        )

        # 展示底部说明
        self.play(
            Create(note_rect),
            Write(note_text)
        )
