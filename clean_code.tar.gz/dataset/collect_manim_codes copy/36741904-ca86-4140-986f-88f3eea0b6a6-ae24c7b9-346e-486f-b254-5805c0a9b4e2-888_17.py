from manim import *

class GloveDoffingAndHygiene(Scene):
    def construct(self):

        # Title Setup
        title = Text("Glove Doffing & Hand Hygiene",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        # Title Animation
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("17", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # Content Definition

        # Section 1: Doffing Technique
        # Image setup with strictly required comment
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_17/1.png") # Scientific illustration showing the correct technique for removing medical gloves. One hand pinches the outside of the glove near the wrist to peel it off without touching the skin. Clean, instructional style, white background.
        img1.height = 2.2  # Adjust size to fit layout

        lbl1 = Text("1. Doffing Technique", font_size=24, color=BLUE_A)
        txt1 = Text(
            "• Pinch outer edge & invert\n• Finger under cuff (clean)",
            font_size=16,
            line_spacing=0.8,
            t2c={"outer edge": YELLOW, "under cuff": YELLOW}
        )
        group1 = VGroup(lbl1, img1, txt1).arrange(DOWN, buff=0.2)
        box1 = SurroundingRectangle(group1, color=BLUE, buff=0.15, stroke_width=2)

        # Section 2: Disposal
        # Image setup with strictly required comment
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_17/2.png") # A yellow biohazard waste bag standing open, featuring the standard black three-circle biohazard symbol. 3D realistic style, white background.
        img2.height = 2.2

        lbl2 = Text("2. Proper Disposal", font_size=24, color=RED_A)
        txt2 = Text(
            "• Biohazard waste bags\n• High-temp disinfection",
            font_size=16,
            line_spacing=0.8,
            t2c={"Biohazard": RED}
        )
        group2 = VGroup(lbl2, img2, txt2).arrange(DOWN, buff=0.2)
        box2 = SurroundingRectangle(group2, color=RED, buff=0.15, stroke_width=2)

        # Section 3: Hygiene
        # Image setup with strictly required comment
        img3 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_17/3.png") # Vector illustration of hands being washed thoroughly with soap bubbles under a running water tap. Clean, blue and white medical safety style.
        img3.height = 2.2

        lbl3 = Text("3. Hand Hygiene", font_size=24, color=GREEN_A)
        txt3 = Text(
            "• Wash immediately\n• After glove removal",
            font_size=16,
            line_spacing=0.8,
            t2c={"immediately": GREEN}
        )
        group3 = VGroup(lbl3, img3, txt3).arrange(DOWN, buff=0.2)
        box3 = SurroundingRectangle(group3, color=GREEN, buff=0.15, stroke_width=2)

        # Layout Arrangement
        main_content = VGroup(group1, group2, group3).arrange(RIGHT, buff=0.8)
        main_content.next_to(title_line, DOWN, buff=0.5)

        # Adjust boxes to new positions
        box1.move_to(group1)
        box2.move_to(group2)
        box3.move_to(group3)

        # Animations
        # Step 1
        self.play(FadeIn(group1, shift=UP*0.5), Create(box1), run_time=1)

        # Step 2
        self.play(FadeIn(group2, shift=UP*0.5), Create(box2), run_time=1)

        # Step 3
        self.play(FadeIn(group3, shift=UP*0.5), Create(box3), run_time=1)
