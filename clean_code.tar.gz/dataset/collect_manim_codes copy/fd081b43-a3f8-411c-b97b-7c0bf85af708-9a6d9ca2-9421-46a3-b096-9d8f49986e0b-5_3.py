from manim import *

class GradientGeometricMeaning(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("梯度向量的几何意义",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("34", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左侧公式与定义，右侧几何可视化

        # 左侧：公式
        # 简化公式展示，避免太长
        formula = MathTex(
            r"\nabla f = \left(\frac{\partial f}{\partial x}, \frac{\partial f}{\partial y}\right)",
            font_size=38
        )
        formula.shift(UP * 1.5 + LEFT * 3)

        # 给公式加框
        formula_box = SurroundingRectangle(formula, color=BLUE, buff=0.2)
        formula_label = Text("定义", font="AR PL UKai CN", font_size=24, color=BLUE)
        formula_label.next_to(formula_box, UP, aligned_edge=LEFT)

        # 左侧：文字说明 (使用VGroup手动排列，避免BulletedList的坑)
        # 1. 方向性
        text_dir_label = Text("方向：", font="AR PL UKai CN", font_size=28, color=YELLOW)
        text_dir_val = Text("函数值增长最快", font="AR PL UKai CN", font_size=28, color=WHITE)
        group_dir = VGroup(text_dir_label, text_dir_val).arrange(RIGHT, buff=0.1)

        # 2. 大小
        text_mag_label = Text("大小：", font="AR PL UKai CN", font_size=28, color=GREEN)
        text_mag_val = Text("最大变化率", font="AR PL UKai CN", font_size=28, color=WHITE)
        group_mag = VGroup(text_mag_label, text_mag_val).arrange(RIGHT, buff=0.1)

        # 3. 负梯度
        text_neg_label = Text("负梯度：", font="AR PL UKai CN", font_size=28, color=RED)
        text_neg_val = Text("下降最快方向", font="AR PL UKai CN", font_size=28, color=WHITE)
        group_neg = VGroup(text_neg_label, text_neg_val).arrange(RIGHT, buff=0.1)

        # 排列左侧文本组
        text_group = VGroup(group_dir, group_mag, group_neg).arrange(DOWN, buff=0.5, aligned_edge=LEFT)
        text_group.next_to(formula_box, DOWN, buff=0.8).align_to(formula_box, LEFT)

        # 右侧：几何可视化 (等高线图)
        # 创建坐标系 (隐藏轴线，只展示等高线概念)
        axes_origin = RIGHT * 3.5 + DOWN * 0.5

        # 绘制等高线 (同心圆/椭圆代表山峰)
        # 使用不规则椭圆更像地形
        c1 = Ellipse(width=2.0, height=1.5, color=BLUE_E).move_to(axes_origin)
        c2 = Ellipse(width=3.5, height=2.5, color=BLUE_C).move_to(axes_origin)
        c3 = Ellipse(width=5.0, height=3.5, color=BLUE_A).move_to(axes_origin)

        contours = VGroup(c3, c2, c1)
        contour_label = Text("等高线图", font="AR PL UKai CN", font_size=20, color=GRAY).next_to(c3, DOWN)

        # 选定一点 P
        # 在 c2 上的一个点 (大约45度位置)
        # 椭圆参数方程 x = a cos t, y = b sin t
        # a=1.75, b=1.25
        p_x = 1.75 * 0.707 # cos(45)
        p_y = 1.25 * 0.707 # sin(45)
        p_point = axes_origin + np.array([p_x, p_y, 0])

        dot = Dot(p_point, color=WHITE)
        dot_label = MathTex("P", font_size=24).next_to(dot, UL, buff=0.1)

        # 梯度向量 (垂直于切线向外)
        # 椭圆切线法向量近似计算或视觉模拟
        # 视觉上向右上方指
        vec_dir = np.array([1.0, 1.0, 0]) # 近似方向
        vec_dir = vec_dir / np.linalg.norm(vec_dir)

        arrow_grad = Arrow(start=p_point, end=p_point + vec_dir * 1.5, color=YELLOW, buff=0)
        label_grad = MathTex(r"\nabla f", color=YELLOW, font_size=28).next_to(arrow_grad.get_end(), UP, buff=0.1)

        # 负梯度向量
        arrow_neg = Arrow(start=p_point, end=p_point - vec_dir * 1.5, color=RED, buff=0)
        label_neg = MathTex(r"-\nabla f", color=RED, font_size=28).next_to(arrow_neg.get_end(), DOWN, buff=0.1)

        # 3. 动画流程
        # 第一步：显示定义公式
        self.play(
            Create(formula_box),
            Write(formula),
            FadeIn(formula_label),
            run_time=1.5
        )

        # 第二步：显示等高线和点
        self.play(
            Create(contours),
            FadeIn(contour_label),
            FadeIn(dot),
            FadeIn(dot_label),
            run_time=1.5
        )

        # 第三步：显示梯度向量及其意义 (方向和大小)
        self.play(
            GrowArrow(arrow_grad),
            Write(label_grad),
            FadeIn(group_dir),
            FadeIn(group_mag),
            run_time=1.5
        )

        # 第四步：显示负梯度及其意义
        self.play(
            GrowArrow(arrow_neg),
            Write(label_neg),
            FadeIn(group_neg),
            run_time=1.5
        )
