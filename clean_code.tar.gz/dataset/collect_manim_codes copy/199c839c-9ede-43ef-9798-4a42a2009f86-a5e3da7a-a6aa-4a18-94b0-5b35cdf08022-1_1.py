from manim import *

class FluidMechanicsIntroScene(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("What is Fluid Mechanics?",
                     font_size=34,
                     color=WHITE,
                     weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("1", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Definition of Fluid Mechanics
        definition = Text(
            "The science studying the motion of liquids and gases\n"
            "and their interaction with the environment.",
            font_size=28,
            line_spacing=0.8
        ).next_to(title_group, DOWN, buff=0.7)

        self.play(Write(definition, run_time=3))

        # 3. Importance and Applications
        importance_title = Text(
            "Its applications are extremely broad:",
            font_size=30,
            weight=BOLD,
            color=BLUE_C
        ).next_to(definition, DOWN, buff=0.8)

        self.play(FadeIn(importance_title, shift=DOWN*0.5))

        applications_list = BulletedList(
            "Aerospace Engineering",
            "Environmental Protection",
            "Energy Development",
            "Medical Technology",
            font_size=28
        ).next_to(importance_title, DOWN, buff=0.4).shift(LEFT*1)

        self.play(LaggedStart(*[FadeIn(item, shift=RIGHT) for item in applications_list], lag_ratio=0.5, run_time=4))

        # 4. Highlight key areas with boxes
        box1 = SurroundingRectangle(applications_list[0], color=YELLOW_D, buff=0.1)
        box2 = SurroundingRectangle(applications_list[3], color=GREEN_C, buff=0.1)

        self.play(Create(box1), run_time=0.7)
        self.play(Create(box2), run_time=0.7)
