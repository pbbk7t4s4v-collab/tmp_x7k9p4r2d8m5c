from manim import *

class HydrophobicAndPotential(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("疏水相互作用与势能模型构建",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("11", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 左侧：疏水相互作用 (熵驱动)
        # ---------------------------------------------------------
        left_group = VGroup()

        # 左侧子标题
        sub_title_1 = Text("疏水效应：熵驱动", font="AR PL UKai CN", font_size=24, color=BLUE_A)

        # 示意图：两个非极性分子
        molecule1 = Circle(radius=0.6, color=YELLOW, fill_opacity=0.6).set_z_index(2)
        molecule2 = Circle(radius=0.6, color=YELLOW, fill_opacity=0.6).set_z_index(2)
        molecule1.move_to(LEFT * 4.5 + DOWN * 0.5)
        molecule2.move_to(LEFT * 2.5 + DOWN * 0.5)

        molecules = VGroup(molecule1, molecule2)

        # 聚集后的位置
        target_pos = LEFT * 3.5 + DOWN * 0.5

        # 解释文字
        desc_1 = Text("非极性分子聚集", font="AR PL UKai CN", font_size=20)
        desc_1.next_to(molecules, UP, buff=0.2)

        desc_2 = Text("减少破坏水氢键网络", font="AR PL UKai CN", font_size=18, color=GREY_A)
        desc_2.next_to(desc_1, DOWN, buff=2.5) # 放在下方

        entropy_math = MathTex(r"\Delta S_{sys} > 0", color=GREEN).next_to(desc_2, DOWN, buff=0.1)

        left_group.add(sub_title_1, molecules, desc_1, desc_2, entropy_math)
        left_group.arrange(DOWN, buff=0.3).to_edge(LEFT, buff=1.0)

        # 重新调整分子位置以便动画
        molecule1.move_to(target_pos + LEFT*0.8)
        molecule2.move_to(target_pos + RIGHT*0.8)

        # ---------------------------------------------------------
        # 右侧：经验势模型 (分段建模)
        # ---------------------------------------------------------
        right_group = VGroup()

        sub_title_2 = Text("分子间势能的分段建模", font="AR PL UKai CN", font_size=24, color=BLUE_A)

        # 坐标系
        axes = Axes(
            x_range=[0.5, 3.5, 1],
            y_range=[-1.5, 2, 1],
            x_length=4.5,
            y_length=3.5,
            axis_config={"include_tip": True, "tip_shape": StealthTip},
        )
        labels = axes.get_axis_labels(x_label="r", y_label="V(r)")

        # 绘制 Lennard-Jones 势能曲线 V = 4((1/r)^12 - (1/r)^6)
        # 简单模拟形状即可
        def potential_func(x):
            if x < 0.8: return 2 # Clamp for display
            val = 4 * ((1/x)**12 - (1/x)**6)
            return min(val, 2) # Clamp high values

        curve = axes.plot(potential_func, x_range=[0.85, 3.2], color=TEAL)

        # 标注三个区域
        # 1. 短程排斥
        text_repulsion = Text("短程排斥", font="AR PL UKai CN", font_size=16, color=RED)
        text_repulsion.move_to(axes.c2p(1.0, 1.5))

        # 2. 中程势阱
        text_well = Text("中程势阱", font="AR PL UKai CN", font_size=16, color=YELLOW)
        text_well.move_to(axes.c2p(1.5, -1.2))

        # 3. 长程吸引
        text_attr = Text("长程吸引", font="AR PL UKai CN", font_size=16, color=GREEN)
        text_attr.move_to(axes.c2p(2.8, 0.3))

        # 虚线指示
        line_well = DashedLine(axes.c2p(1.12, -1), text_well.get_top(), color=YELLOW, stroke_width=2)

        plot_group = VGroup(axes, labels, curve, text_repulsion, text_well, text_attr, line_well)
        right_group.add(sub_title_2, plot_group)
        right_group.arrange(DOWN, buff=0.3).to_edge(RIGHT, buff=1.0)

        # 对齐调整
        sub_title_2.align_to(sub_title_1, UP)

        # ---------------------------------------------------------
        # 动画流程
        # ---------------------------------------------------------

        # 分隔线
        separator = Line(UP*2, DOWN*2, color=GREY).move_to(ORIGIN)

        # 1. 显示左侧内容
        self.play(
            FadeIn(sub_title_1),
            FadeIn(desc_1),
            FadeIn(molecule1),
            FadeIn(molecule2),
        )

        # 疏水聚集动画
        self.play(
            molecule1.animate.shift(RIGHT*0.5),
            molecule2.animate.shift(LEFT*0.5),
            run_time=1.5
        )

        # 显示熵增加结论
        self.play(
            Write(desc_2),
            Write(entropy_math),
            run_time=1.0
        )

        # 2. 显示右侧内容
        self.play(
            Create(separator),
            FadeIn(sub_title_2),
            Create(axes),
            Write(labels),
        )

        self.play(
            Create(curve, run_time=1.5),
            FadeIn(text_repulsion, shift=DOWN*0.2),
            FadeIn(text_well, shift=UP*0.2),
            Create(line_well),
            FadeIn(text_attr, shift=LEFT*0.2),
        )

        # 强调框
        rect = SurroundingRectangle(right_group, color=BLUE, buff=0.1, stroke_width=1)
        self.play(Create(rect, run_time=1.0))
