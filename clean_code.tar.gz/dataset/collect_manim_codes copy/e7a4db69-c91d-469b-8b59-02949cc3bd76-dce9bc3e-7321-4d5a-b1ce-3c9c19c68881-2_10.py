from manim import *

class IFAmplifierCharacteristics(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("中放级的增益与滤波特性",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("27", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 字体配置
        my_font = "AR PL UKai CN"
        text_color = LIGHT_GRAY

        # 2. 构建两级中放的框图结构
        # 第一中放模块
        box1 = RoundedRectangle(height=1.2, width=2.5, corner_radius=0.2, color=BLUE)
        label1 = Text("第一中放管", font=my_font, font_size=24).move_to(box1)

        # 第一中放详细参数
        detail1_text = VGroup(
            Text("负载: IFT2 (双调谐)", font=my_font, font_size=18, color=text_color),
            Text("增益: 30-50倍 (30-34dB)", font=my_font, font_size=18, color=text_color),
            Text("通频带: ±5kHz", font=my_font, font_size=18, color=text_color)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        detail1_text.next_to(box1, DOWN, buff=0.2)

        group1 = VGroup(box1, label1, detail1_text).move_to(LEFT * 3.5 + UP * 0.5)

        # 第二中放模块
        box2 = RoundedRectangle(height=1.2, width=2.5, corner_radius=0.2, color=GREEN)
        label2 = Text("第二中放管", font=my_font, font_size=24).move_to(box2)

        # 第二中放详细参数
        detail2_text = VGroup(
            Text("负载: IFT3", font=my_font, font_size=18, color=text_color),
            Text("增益: 20-40倍 (26-32dB)", font=my_font, font_size=18, color=text_color),
            Text("信号: μV级 → mV级", font=my_font, font_size=18, color=YELLOW)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        detail2_text.next_to(box2, DOWN, buff=0.2)

        group2 = VGroup(box2, label2, detail2_text).move_to(RIGHT * 3.5 + UP * 0.5)

        # 连接箭头与总增益
        arrow = Arrow(start=box1.get_right(), end=box2.get_left(), buff=0.2, color=WHITE)
        total_gain_label = Text("总增益 60-80dB", font=my_font, font_size=20, color=RED)
        total_gain_label.next_to(arrow, UP, buff=0.1)

        # 3. AGC 模块 (底部展示)
        agc_box = SurroundingRectangle(VGroup(group1, group2), color=GREY, buff=0.1) # 这里的SurroundingRectangle暂时不用,下面重新定义区域

        agc_title = Text("自动增益控制 (AGC)", font=my_font, font_size=24, color=ORANGE)
        agc_desc = VGroup(
            Text("原理: 检波级反馈直流电压 → 控制基极/栅极", font=my_font, font_size=20),
            Text("作用: 强信号 → 负偏压↑ → 增益↓ → 防失真", font=my_font, font_size=20),
            Text("结果: 输出音量保持相对稳定", font=my_font, font_size=20, color=YELLOW)
        ).arrange(DOWN, buff=0.15)

        agc_group = VGroup(agc_title, agc_desc).arrange(DOWN, buff=0.3)
        agc_group.to_edge(DOWN, buff=0.8)

        agc_rect = SurroundingRectangle(agc_group, color=ORANGE, buff=0.2, corner_radius=0.1)

        # 4. 动画流程
        # 显示两级放大结构
        self.play(
            FadeIn(group1, shift=RIGHT),
            FadeIn(group2, shift=LEFT),
            run_time=1.5
        )

        # 显示连接和总增益
        self.play(
            GrowArrow(arrow),
            Write(total_gain_label),
            run_time=1
        )

        # 显示AGC部分
        self.play(
            Create(agc_rect),
            Write(agc_group),
            run_time=1.5
        )

        # 简单的强调动画:反馈路径示意(用虚线箭头从右下指向左下)
        feedback_arrow = DashedLine(
            start=agc_rect.get_right() + RIGHT*0.5,
            end=agc_rect.get_left() + LEFT*0.5,
            color=ORANGE
        ).add_tip()

        # 这里的箭头路径只是示意,实际上是从检波(右侧后续)回到中放(左侧)
        # 为了视觉效果,我们在底部画一个从右向左的反馈示意
        feedback_path = CurvedArrow(
            start_point=group2.get_bottom() + DOWN*0.2,
            end_point=group1.get_bottom() + DOWN*0.2,
            angle=-PI/4,
            color=ORANGE
        )
        feedback_text = Text("反馈调节", font=my_font, font_size=16, color=ORANGE).next_to(feedback_path, DOWN, buff=0)

        self.play(
            Create(feedback_path),
            FadeIn(feedback_text),
            run_time=1.5
        )
