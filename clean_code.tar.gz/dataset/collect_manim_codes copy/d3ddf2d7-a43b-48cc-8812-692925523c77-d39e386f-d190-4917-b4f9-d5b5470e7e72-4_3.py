from manim import *

class LycheeStructurePartOne(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("文章第一部分结构梳理",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("10", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局设计
        # 核心主题
        main_topic = Text("第一部分：荔枝的生态知识", font="AR PL UKai CN", font_size=30, color=YELLOW)
        main_topic.next_to(title_line, DOWN, buff=0.5)

        # 创建三个层级的文本节点
        # 第1层
        node1_text = Text("第1层 (1段)\n引出说明对象", font="AR PL UKai CN", font_size=24, line_spacing=0.8)
        node1_box = SurroundingRectangle(node1_text, color=BLUE, buff=0.2, corner_radius=0.2)
        node1_group = VGroup(node1_box, node1_text)

        # 第2层
        node2_text = Text("第2层 (2-5段)\n果实外部形态", font="AR PL UKai CN", font_size=24, line_spacing=0.8)
        node2_box = SurroundingRectangle(node2_text, color=GREEN, buff=0.2, corner_radius=0.2)
        node2_group = VGroup(node2_box, node2_text)

        # 第3层
        node3_text = Text("第3层 (6-10段)\n果实内部组织", font="AR PL UKai CN", font_size=24, line_spacing=0.8)
        node3_box = SurroundingRectangle(node3_text, color=TEAL, buff=0.2, corner_radius=0.2)
        node3_group = VGroup(node3_box, node3_text)

        # 排列位置：垂直排列
        nodes = VGroup(node1_group, node2_group, node3_group).arrange(DOWN, buff=0.6)
        nodes.next_to(main_topic, DOWN, buff=0.5).shift(LEFT * 2)

        # 连接箭头
        arrow1 = Arrow(start=node1_box.get_bottom(), end=node2_box.get_top(), buff=0.1, color=GRAY)
        arrow2 = Arrow(start=node2_box.get_bottom(), end=node3_box.get_top(), buff=0.1, color=GRAY)

        # 说明顺序总结（右侧展示）
        order_title = Text("说明顺序", font="AR PL UKai CN", font_size=28, color=ORANGE)
        order_desc1 = Text("由表及里", font="AR PL UKai CN", font_size=26)
        order_desc2 = Text("从主到次", font="AR PL UKai CN", font_size=26)

        order_group = VGroup(order_title, order_desc1, order_desc2).arrange(DOWN, buff=0.4)
        order_box = SurroundingRectangle(order_group, color=WHITE, buff=0.3)
        right_panel = VGroup(order_box, order_group)
        right_panel.next_to(nodes, RIGHT, buff=1.5)

        # 辅助箭头指向右侧总结
        order_arrow = Arrow(start=nodes.get_right(), end=right_panel.get_left(), color=YELLOW)

        # 3. 动画播放序列
        # 显示核心主题
        self.play(FadeIn(main_topic, shift=DOWN))

        # 逐步显示层级结构
        self.play(Create(node1_group), run_time=1)
        self.play(GrowArrow(arrow1), run_time=0.5)

        self.play(Create(node2_group), run_time=1)
        self.play(GrowArrow(arrow2), run_time=0.5)

        self.play(Create(node3_group), run_time=1)

        # 显示说明顺序总结
        self.play(
            GrowArrow(order_arrow),
            FadeIn(right_panel, shift=LEFT),
            run_time=1.5
        )

        # 停留片刻
