from manim import *

class InstitutionalEffectVerification(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (按照模板要求)
        # ---------------------------------------------------------
        title = Text("制度效应的量化检验",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("76", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 核心概念逻辑流 (顶部区域)
        # ---------------------------------------------------------
        # 定义文本
        law_text = Text("法律制度", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        arrow = Arrow(LEFT, RIGHT, buff=0.2, color=WHITE)
        behavior_text = Text("社会行为", font="AR PL UKai CN", font_size=28, color=GREEN_A)

        # 组合并定位
        concept_group = VGroup(law_text, arrow, behavior_text).arrange(RIGHT, buff=0.5)
        concept_group.next_to(title_line, DOWN, buff=0.5)

        # 核心问题标注
        method_text = Text("准实验设计", font="AR PL UKai CN", font_size=24, color=YELLOW)
        method_text.next_to(arrow, UP, buff=0.1)

        # 绘制概念流
        self.play(FadeIn(concept_group), Write(method_text))

        # ---------------------------------------------------------
        # 3. 准实验设计可视化 - 差异比较 (中部及底部区域)
        # ---------------------------------------------------------

        # 创建坐标系
        axes = Axes(
            x_range=[0, 6, 1],
            y_range=[0, 5, 1],
            x_length=7,
            y_length=3.5,
            axis_config={"color": GREY, "include_tip": True},
        ).next_to(concept_group, DOWN, buff=0.5)

        # 坐标轴标签
        x_label = Text("时间", font="AR PL UKai CN", font_size=20).next_to(axes.x_axis, RIGHT)
        y_label = Text("行为指标", font="AR PL UKai CN", font_size=20).next_to(axes.y_axis, UP)

        self.play(Create(axes), Write(x_label), Write(y_label))

        # 法律实施时间点 (垂直虚线)
        intervention_x = 3
        intervention_line = DashedLine(
            start=axes.c2p(intervention_x, 0),
            end=axes.c2p(intervention_x, 4.5),
            color=RED
        )
        intervention_text = Text("法律实施", font="AR PL UKai CN", font_size=20, color=RED)
        intervention_text.next_to(intervention_line, UP)

        self.play(Create(intervention_line), FadeIn(intervention_text))

        # 绘制曲线
        # 1. 对照组 (Control Group) - 未实施法律的地区/情况 - 平稳增长
        control_points = [
            axes.c2p(0, 1),
            axes.c2p(3, 1.5),
            axes.c2p(6, 2)
        ]
        control_line = VMobject(color=BLUE)
        control_line.set_points_as_corners(control_points)
        control_label = Text("对照组", font="AR PL UKai CN", font_size=20, color=BLUE)
        control_label.next_to(control_line, RIGHT)

        # 2. 实验组 (Treatment Group) - 实施法律后发生变化
        treatment_points_pre = [
            axes.c2p(0, 1.5),
            axes.c2p(3, 2)
        ]
        treatment_points_post = [
            axes.c2p(3, 2),
            axes.c2p(6, 4) # 明显上升
        ]
        treatment_line = VMobject(color=GREEN)
        treatment_line.set_points_as_corners(treatment_points_pre + treatment_points_post[1:])
        treatment_label = Text("实验组", font="AR PL UKai CN", font_size=20, color=GREEN)
        treatment_label.next_to(treatment_line, RIGHT)

        # 动画绘制线条
        self.play(
            Create(control_line),
            Create(treatment_line),
            run_time=2
        )
        self.play(FadeIn(control_label), FadeIn(treatment_label))

        # ---------------------------------------------------------
        # 4. 强调制度效应 (Double Arrow or Brace)
        # ---------------------------------------------------------

        # 在 T=6 处标记差异
        end_point_control = control_points[-1]
        end_point_treatment = treatment_points_post[-1]

        brace = BraceBetweenPoints(end_point_control, end_point_treatment, direction=LEFT, color=YELLOW)
        effect_text = Text("制度效应", font="AR PL UKai CN", font_size=24, color=YELLOW)
        effect_text.next_to(brace, LEFT)

        # 强调区域矩形
        highlight_rect = SurroundingRectangle(VGroup(effect_text, brace), color=YELLOW, buff=0.1)

        self.play(GrowFromCenter(brace), Write(effect_text))
        self.play(Create(highlight_rect))
