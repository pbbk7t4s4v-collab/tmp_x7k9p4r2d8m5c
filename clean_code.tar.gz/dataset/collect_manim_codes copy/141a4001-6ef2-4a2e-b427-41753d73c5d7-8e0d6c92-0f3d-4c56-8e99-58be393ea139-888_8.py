from manim import *

class ImplicationSymbolScene(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("蕴涵符号 -> 的含义",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 核心可视化内容：P -> Q
        # 使用 MathTex 展示逻辑公式
        p_term = MathTex("P", font_size=72, color=BLUE)
        arrow = MathTex(r"\rightarrow", font_size=72)
        q_term = MathTex("Q", font_size=72, color=GREEN)

        # 组合并排列
        logic_chain = VGroup(p_term, arrow, q_term).arrange(RIGHT, buff=1.5)
        logic_chain.move_to(UP * 0.5) # 稍微上移，给下方文字留空间

        # 添加中文标注
        label_p = Text("前提", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        label_p.next_to(p_term, DOWN, buff=0.3)

        label_q = Text("结论", font="AR PL UKai CN", font_size=24, color=GREEN_A)
        label_q.next_to(q_term, DOWN, buff=0.3)

        # 强调框
        rect_p = SurroundingRectangle(p_term, color=BLUE, buff=0.2)
        rect_q = SurroundingRectangle(q_term, color=GREEN, buff=0.2)

        # 3. 解释性文字列表 (手动构建以避免BulletedList的潜在字体/LaTeX问题)
        text_1 = Text("• 构建逻辑推导链", font="AR PL UKai CN", font_size=28, color=WHITE)
        text_2 = Text("• 定义前提与结论的因果关系", font="AR PL UKai CN", font_size=28, color=WHITE)

        # 排版文字
        desc_group = VGroup(text_1, text_2).arrange(DOWN, buff=0.3, aligned_edge=LEFT)
        desc_group.next_to(logic_chain, DOWN, buff=2.0)
        # 确保文字居中
        desc_group.move_to([0, -2.5, 0])

        # 4. 动画流程
        # 出现前提
        self.play(
            FadeIn(p_term, shift=UP),
            Create(rect_p),
            Write(label_p)
        )

        # 出现蕴涵符号（推导过程）
        self.play(Write(arrow))

        # 出现结论
        self.play(
            FadeIn(q_term, shift=UP),
            Create(rect_q),
            Write(label_q)
        )

        # 出现解释文字
        self.play(FadeIn(desc_group, shift=UP))
