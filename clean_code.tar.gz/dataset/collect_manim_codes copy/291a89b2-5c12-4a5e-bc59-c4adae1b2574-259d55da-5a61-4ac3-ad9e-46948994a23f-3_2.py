from manim import *

class LawModernization(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("法律在现代化进程中的工具性角色",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("32", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 第一部分：韦伯的理性法逻辑 (上半部分)
        # 核心逻辑：形式理性法 -> 降低交易成本 -> 市场经济

        # 定义文本节点
        node_font_size = 24
        t1 = Text("形式理性法", font="AR PL UKai CN", font_size=node_font_size)
        t2 = Text("可预期规则", font="AR PL UKai CN", font_size=node_font_size)
        t3 = Text("市场经济", font="AR PL UKai CN", font_size=node_font_size)

        # 创建边框
        rect1 = SurroundingRectangle(t1, color=BLUE, corner_radius=0.1)
        rect2 = SurroundingRectangle(t2, color=BLUE, corner_radius=0.1)
        rect3 = SurroundingRectangle(t3, color=GREEN, corner_radius=0.1)

        # 组合节点
        g1 = VGroup(rect1, t1)
        g2 = VGroup(rect2, t2)
        g3 = VGroup(rect3, t3)

        # 水平排列
        top_flow = VGroup(g1, g2, g3).arrange(RIGHT, buff=2.0)
        top_flow.move_to(UP * 1.5) # 放置在屏幕上半部分

        # 连接箭头
        arrow1 = Arrow(rect1.get_right(), rect2.get_left(), buff=0.1, color=WHITE)
        arrow2 = Arrow(rect2.get_right(), rect3.get_left(), buff=0.1, color=WHITE)

        # 箭头上的说明文字
        label1 = Text("降低交易成本", font="AR PL UKai CN", font_size=16, color=YELLOW).next_to(arrow1, UP, buff=0.05)
        label2 = Text("保障契约自由", font="AR PL UKai CN", font_size=16, color=YELLOW).next_to(arrow2, UP, buff=0.05)

        # 播放第一部分动画
        self.play(
            FadeIn(g1), FadeIn(g2), FadeIn(g3),
            Create(arrow1), Create(arrow2),
            Write(label1), Write(label2)
        )

        # 3. 第二部分:移植与本土化的张力 (下半部分)
        # 核心逻辑:法律移植 + 本土化 -> 适应性改造

        # 左侧:移植
        transplant_text = Text("法律移植\n(制度借鉴)", font="AR PL UKai CN", font_size=22, color=BLUE_A)
        transplant_text.move_to(LEFT * 3 + DOWN * 1.5)

        # 右侧:本土化
        local_text = Text("本土化\n(社会土壤)", font="AR PL UKai CN", font_size=22, color=RED_A)
        local_text.move_to(RIGHT * 3 + DOWN * 1.5)

        # 中间下方:适应性改造
        result_text = Text("适应性改造", font="AR PL UKai CN", font_size=28, weight=BOLD, color=GOLD)
        result_rect = SurroundingRectangle(result_text, color=GOLD, buff=0.2)
        result_group = VGroup(result_rect, result_text)
        result_group.move_to(DOWN * 3)

        # 连接箭头
        arrow_left = Arrow(transplant_text.get_bottom(), result_group.get_top(), color=GREY, buff=0.1)
        arrow_right = Arrow(local_text.get_bottom(), result_group.get_top(), color=GREY, buff=0.1)

        # 播放第二部分动画
        self.play(
            FadeIn(transplant_text, shift=DOWN),
            FadeIn(local_text, shift=DOWN)
        )
        self.play(
            Create(arrow_left),
            Create(arrow_right)
        )
        self.play(
            GrowFromCenter(result_rect),
            Write(result_text)
        )

        # 4. 最终停留
