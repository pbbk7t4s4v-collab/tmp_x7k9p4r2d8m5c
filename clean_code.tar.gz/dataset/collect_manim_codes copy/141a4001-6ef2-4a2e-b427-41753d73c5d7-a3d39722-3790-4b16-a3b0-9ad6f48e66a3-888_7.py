from manim import *

class CoqTypeAnnotation(Scene):
    def construct(self):

        # 标题设置
        title = Text("Coq 中的类型标注",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("7", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 1. 显式标注部分
        # 标签
        lbl_expl = Text("显式标注", font="AR PL UKai CN", font_size=28, color=YELLOW)
        lbl_expl.to_edge(LEFT, buff=1.5).shift(UP * 1.5)

        # 代码部分 - 使用VGroup拼接Text以方便定位和加框
        # 内容: forall (x: Z) (y: Z), ...
        t1 = Text("forall", font="Monospace", font_size=26)
        t2 = Text("(x: Z)", font="Monospace", font_size=26)
        t3 = Text("(y: Z)", font="Monospace", font_size=26)
        t4 = Text(", ...", font="Monospace", font_size=26)

        # 组合代码片段，buff=0.2 模拟空格
        group_expl = VGroup(t1, t2, t3, t4).arrange(RIGHT, buff=0.2)
        group_expl.next_to(lbl_expl, DOWN, buff=0.4).align_to(lbl_expl, LEFT)

        # 强调框：框住类型标注部分
        rect_expl_1 = SurroundingRectangle(t2, color=BLUE, buff=0.05, stroke_width=2)
        rect_expl_2 = SurroundingRectangle(t3, color=BLUE, buff=0.05, stroke_width=2)

        # 说明文字
        desc_expl = Text("显式写出每个变量的类型，适合复杂情况", font="AR PL UKai CN", font_size=22, color=GRAY_B)
        desc_expl.next_to(group_expl, DOWN, buff=0.3).align_to(group_expl, LEFT)

        # 2. 隐式推断部分
        # 标签
        lbl_impl = Text("隐式推断", font="AR PL UKai CN", font_size=28, color=YELLOW)
        lbl_impl.next_to(desc_expl, DOWN, buff=1.0).align_to(lbl_expl, LEFT)

        # 代码部分
        # 内容: forall (x: Z) y, ...
        q1 = Text("forall (x: Z)", font="Monospace", font_size=26)
        q2 = Text("y", font="Monospace", font_size=26)
        q3 = Text(", ...", font="Monospace", font_size=26)

        group_impl = VGroup(q1, q2, q3).arrange(RIGHT, buff=0.2)
        group_impl.next_to(lbl_impl, DOWN, buff=0.4).align_to(lbl_impl, LEFT)

        # 强调框：框住被推断的变量
        rect_impl = SurroundingRectangle(q2, color=GREEN, buff=0.05, stroke_width=2)

        # 说明文字
        desc_impl = Text("Coq 根据上下文自动推断 y 的类型", font="AR PL UKai CN", font_size=22, color=GRAY_B)
        desc_impl.next_to(group_impl, DOWN, buff=0.3).align_to(group_impl, LEFT)

        # 动画序列展示
        # 显式标注动画
        self.play(FadeIn(lbl_expl, shift=RIGHT), run_time=0.8)
        self.play(Write(group_expl), run_time=1.0)
        self.play(Create(rect_expl_1), Create(rect_expl_2), run_time=0.8)
        self.play(FadeIn(desc_expl), run_time=0.8)

        # 隐式推断动画
        self.play(FadeIn(lbl_impl, shift=RIGHT), run_time=0.8)
        self.play(Write(group_impl), run_time=1.0)
        self.play(Create(rect_impl), run_time=0.8)
        self.play(FadeIn(desc_impl), run_time=0.8)
