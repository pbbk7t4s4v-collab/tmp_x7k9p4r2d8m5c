from manim import *

class ParenthesesPriority(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (严格按照模板)
        # ---------------------------------------------------------
        title = Text("括号的作用:改变运算优先级",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局 - 左右对比
        # ---------------------------------------------------------

        # 左侧:无括号的情况
        left_label = Text("无括号算式", font="AR PL UKai CN", font_size=24, color=BLUE).shift(LEFT * 3.5 + UP * 1.5)
        # 7 + 3 * 2
        eq_left_1 = MathTex("7", "+", "3", "\\times", "2", font_size=36).next_to(left_label, DOWN, buff=0.5)

        # 右侧:有括号的情况
        right_label = Text("有括号算式", font="AR PL UKai CN", font_size=24, color=GREEN).shift(RIGHT * 3.5 + UP * 1.5)
        # (7 + 3) * 2
        eq_right_1 = MathTex("(", "7", "+", "3", ")", "\\times", "2", font_size=36).next_to(right_label, DOWN, buff=0.5)

        # 展示初始算式
        self.play(
            FadeIn(left_label),
            Write(eq_left_1),
            FadeIn(right_label),
            Write(eq_right_1)
        )

        # ---------------------------------------------------------
        # 3. 演示计算过程
        # ---------------------------------------------------------

        # --- 左侧演示 (乘法优先) ---
        # 高亮先算的部分 3 * 2
        # 索引注意:0:7, 1:+, 2:3, 3:\times, 4:2
        rect_left = SurroundingRectangle(eq_left_1[2:], color=YELLOW, buff=0.1)
        hint_left = Text("先算乘法", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(rect_left, UP, buff=0.1)

        self.play(Create(rect_left), FadeIn(hint_left), run_time=0.8)

        # 变换为下一步: 7 + 6
        eq_left_2 = MathTex("7", "+", "6", font_size=36).move_to(eq_left_1.get_center())

        self.play(
            TransformMatchingTex(eq_left_1, eq_left_2),
            FadeOut(rect_left),
            FadeOut(hint_left),
            run_time=1
        )

        # 最终结果: 13
        eq_left_3 = MathTex("13", font_size=40, color=BLUE).next_to(eq_left_2, DOWN, buff=0.5)
        arrow_left = Arrow(start=eq_left_2.get_bottom(), end=eq_left_3.get_top(), buff=0.1, color=GREY)

        self.play(GrowArrow(arrow_left), Write(eq_left_3))

        # --- 右侧演示 (括号优先) ---
        # 高亮先算的部分 (7 + 3)
        # 索引:0:(, 1:7, 2:+, 3:3, 4:), 5:\times, 6:2
        rect_right = SurroundingRectangle(eq_right_1[0:5], color=RED, buff=0.1)
        hint_right = Text("括号最优先", font="AR PL UKai CN", font_size=20, color=RED).next_to(rect_right, UP, buff=0.1)

        self.play(Create(rect_right), FadeIn(hint_right), run_time=0.8)

        # 变换为下一步: 10 * 2
        eq_right_2 = MathTex("10", "\\times", "2", font_size=36).move_to(eq_right_1.get_center())

        self.play(
            TransformMatchingTex(eq_right_1, eq_right_2),
            FadeOut(rect_right),
            FadeOut(hint_right),
            run_time=1
        )

        # 最终结果: 20
        eq_right_3 = MathTex("20", font_size=40, color=GREEN).next_to(eq_right_2, DOWN, buff=0.5)
        arrow_right = Arrow(start=eq_right_2.get_bottom(), end=eq_right_3.get_top(), buff=0.1, color=GREY)

        self.play(GrowArrow(arrow_right), Write(eq_right_3))

        # ---------------------------------------------------------
        # 4. 总结结论
        # ---------------------------------------------------------
        conclusion_box = VGroup()
        conclusion_text = Text("结论:括号能改变运算顺序,\n必须先算括号里面的内容!",
                             font="AR PL UKai CN",
                             font_size=28,
                             color=YELLOW,
                             line_spacing=0.8)

        conclusion_rect = SurroundingRectangle(conclusion_text, color=WHITE, buff=0.3)
        conclusion_box.add(conclusion_rect, conclusion_text)
        conclusion_box.move_to(DOWN * 2.5)

        self.play(FadeIn(conclusion_box, shift=UP), run_time=1.2)
