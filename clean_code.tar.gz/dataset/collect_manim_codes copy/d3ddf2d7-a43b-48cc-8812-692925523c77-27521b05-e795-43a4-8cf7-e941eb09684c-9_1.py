from manim import *

class MainThemeSummary(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (标准模板)
        # ---------------------------------------------------------
        title = Text("文章主旨：南州六月荔枝丹",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", # 字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("26", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容布局设计
        # ---------------------------------------------------------

        # 左侧部分：说明对象与内容
        left_title = Text("说明对象", font="AR PL UKai CN", font_size=28, color=YELLOW)
        left_items = VGroup(
            Text("• 荔枝的形态", font="AR PL UKai CN", font_size=24),
            Text("• 果实特征", font="AR PL UKai CN", font_size=24),
            Text("• 生产情况", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, buff=0.3, aligned_edge=LEFT)

        left_block = VGroup(left_title, left_items).arrange(DOWN, buff=0.4)
        left_block.move_to(LEFT * 3.5 + UP * 0.5)

        left_rect = SurroundingRectangle(left_block, color=BLUE, buff=0.3)
        left_label = Text("科学准确", font="AR PL UKai CN", font_size=20, color=BLUE).next_to(left_rect, UP)

        # 右侧部分：知识融合
        right_title = Text("知识融合", font="AR PL UKai CN", font_size=28, color=YELLOW)
        right_items = VGroup(
            Text("• 科学知识", font="AR PL UKai CN", font_size=24),
            Text("• 历史知识", font="AR PL UKai CN", font_size=24),
            Text("• 文学知识", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, buff=0.3, aligned_edge=LEFT)

        right_block = VGroup(right_title, right_items).arrange(DOWN, buff=0.4)
        right_block.move_to(RIGHT * 3.5 + UP * 0.5)

        right_rect = SurroundingRectangle(right_block, color=GREEN, buff=0.3)
        right_label = Text("丰富生动", font="AR PL UKai CN", font_size=20, color=GREEN).next_to(right_rect, UP)

        # 底部部分：核心评价
        bottom_text = Text("高度统一：思想性 · 科学性 · 艺术性", font="AR PL UKai CN", font_size=32, color=ORANGE)
        bottom_text.move_to(DOWN * 2.5)

        # ---------------------------------------------------------
        # 3. 动画演示
        # ---------------------------------------------------------

        # 展示左右两块内容
        self.play(
            FadeIn(left_block, shift=UP),
            Create(left_rect),
            FadeIn(left_label),
            run_time=1.5
        )
        self.play(
            FadeIn(right_block, shift=UP),
            Create(right_rect),
            FadeIn(right_label),
            run_time=1.5
        )

        # 连接箭头
        arrow_l = Arrow(start=left_rect.get_bottom(), end=bottom_text.get_top(), color=WHITE, buff=0.1)
        arrow_r = Arrow(start=right_rect.get_bottom(), end=bottom_text.get_top(), color=WHITE, buff=0.1)

        # 展示总结
        self.play(
            GrowArrow(arrow_l),
            GrowArrow(arrow_r),
            run_time=1.0
        )
        self.play(
            Write(bottom_text),
            run_time=1.5
        )
