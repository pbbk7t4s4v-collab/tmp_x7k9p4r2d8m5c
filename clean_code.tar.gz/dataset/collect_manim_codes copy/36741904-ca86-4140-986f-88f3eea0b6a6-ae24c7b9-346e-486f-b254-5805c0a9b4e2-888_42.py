from manim import *

class PressureVesselSafety(Scene):
    def construct(self):

        # Title Setup
        title = Text("Pressure Vessel Accidents & Safety Management",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # Add bottom emphasis line
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # Group title elements
        title_group = VGroup(title, title_line)

        # Animated Title
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("42", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # --- Left Side: Accident Causes ---
        # Header for the left section
        causes_header = Text("Common Accident Causes", font_size=28, color=RED_B)
        causes_header.move_to(UP * 2 + LEFT * 3.5)

        # Bullet points for causes
        # Note: escaping & for LaTeX if needed, though simple text usually fine.
        causes_list = BulletedList(
            "Unauthorized production or use",
            "Overpressure (safety valve failure)",
            "Corrosion or wear",
            "Example: Wenling tank truck explosion",
            font_size=22,
            buff=0.15
        )
        causes_list.set_color(WHITE)
        causes_list.next_to(causes_header, DOWN, aligned_edge=LEFT, buff=0.2)

        # Images for visualization
        # Image 1: Corroded valve
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_42/1.png") # A close-up illustration of a corroded and worn-out metal safety valve on a pressure vessel, showing rust and cracks to represent equipment failure, realistic industrial style, white background.
        img1.height = 1.8
        img1.next_to(causes_list, DOWN, buff=0.3).align_to(causes_list, LEFT)

        # Image 2: Explosion
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/36741904-ca86-4140-986f-88f3eea0b6a6/ae24c7b9-346e-486f-b254-5805c0a9b4e2/pictures/888_42/2.png") # A dramatic scene of a liquefied gas tank truck exploding on a highway, with fire and smoke, representing the Wenling tank truck accident, realistic style to show destructive power.
        img2.height = 1.8
        img2.next_to(img1, RIGHT, buff=0.5)

        # --- Right Side: Safety Management ---
        # Header for the right section
        mgmt_header = Text("Safety Management", font_size=28, color=GREEN_B)
        mgmt_header.move_to(UP * 2 + RIGHT * 3.5)

        # Bullet points for management
        # Using \\& to escape the ampersand in LaTeX environment of BulletedList
        mgmt_list = BulletedList(
            "Traceability \\& Documentation",
            "Maintain technical files",
            "Keep original documents",
            "Record usage \\& inspection data",
            "Operating procedures",
            "Emergency measures",
            font_size=22,
            buff=0.15
        )
        mgmt_list.set_color(WHITE)
        mgmt_list.next_to(mgmt_header, DOWN, aligned_edge=LEFT, buff=0.2)

        # Box around management section
        mgmt_box = SurroundingRectangle(VGroup(mgmt_header, mgmt_list), color=GREEN, buff=0.2)

        # --- Animations ---
        # 1. Reveal Left Side (Causes)
        self.play(FadeIn(causes_header))
        self.play(Write(causes_list, run_time=2))

        # 2. Show Images
        self.play(FadeIn(img1), FadeIn(img2))

        # 3. Reveal Right Side (Management)
        self.play(FadeIn(mgmt_header))
        self.play(Write(mgmt_list, run_time=2))

        # 4. Highlight Management
        self.play(Create(mgmt_box))
