from manim import *
import numpy as np

class WaveEquationScene(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题部分 (标准模板)
        # ---------------------------------------------------------
        title = Text("典型方程：波动方程",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 左侧：概念与原理 (文本展示)
        # ---------------------------------------------------------
        # 使用VGroup手动排版以确保对齐和字体支持,避免BulletedList的潜在问题

        # 物理背景模块
        bg_title = Text("1. 物理背景", font="AR PL UKai CN", font_size=28, color=BLUE)
        bg_items = VGroup(
            Text("• 弦的微小横振动", font="AR PL UKai CN", font_size=24),
            Text("• 声波传播", font="AR PL UKai CN", font_size=24),
            Text("• 电磁波传播", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        bg_items.next_to(bg_title, DOWN, aligned_edge=LEFT, buff=0.2).shift(RIGHT * 0.5)

        # 导出原理模块
        principle_title = Text("2. 导出原理", font="AR PL UKai CN", font_size=28, color=BLUE)
        principle_items = VGroup(
            Text("• 牛顿第二定律 (F=ma)", font="AR PL UKai CN", font_size=24),
            Text("• 胡克定律 (张力分析)", font="AR PL UKai CN", font_size=24)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)
        principle_items.next_to(principle_title, DOWN, aligned_edge=LEFT, buff=0.2).shift(RIGHT * 0.5)

        # 组合左侧内容
        left_content = VGroup(bg_title, bg_items, principle_title, principle_items)
        left_content.arrange(DOWN, aligned_edge=LEFT, buff=0.6)
        left_content.to_edge(LEFT, buff=1.0).shift(UP * 0.5)

        # ---------------------------------------------------------
        # 3. 右侧：可视化与方程展示
        # ---------------------------------------------------------

        # 简单的弦振动示意图坐标系
        axes = Axes(
            x_range=[0, 2*PI, PI],
            y_range=[-1.5, 1.5, 1],
            x_length=5,
            y_length=2.5,
            axis_config={"color": GREY, "include_tip": True},
        )
        axes_labels = axes.get_axis_labels(x_label="x", y_label="u")

        # 绘制一条正弦曲线代表某一时刻的波形
        wave_curve = axes.plot(lambda x: np.sin(x), color=YELLOW)
        wave_label = Text("一维弦振动示意", font="AR PL UKai CN", font_size=20, color=YELLOW)
        wave_label.next_to(axes, UP, buff=0.1)

        graph_group = VGroup(axes, axes_labels, wave_curve, wave_label)
        graph_group.to_edge(RIGHT, buff=1.0).shift(UP * 1.0)

        # 方程展示 (MathTex)
        # 一维波动方程
        eq_tex = MathTex(
            r"\frac{\partial^2 u}{\partial t^2} = a^2 \frac{\partial^2 u}{\partial x^2}",
            font_size=40
        )
        eq_tex.next_to(graph_group, DOWN, buff=0.6)

        # 方程分类标签
        class_label = Text("二阶双曲型方程", font="AR PL UKai CN", font_size=26, color=ORANGE)
        class_label.next_to(eq_tex, DOWN, buff=0.2)

        # 强调框
        eq_box = SurroundingRectangle(eq_tex, color=BLUE, buff=0.2)

        # ---------------------------------------------------------
        # 4. 动画流程
        # ---------------------------------------------------------

        # 展示左侧文本
        self.play(
            FadeIn(left_content, shift=RIGHT),
            run_time=1.5
        )

        # 展示右侧图示
        self.play(
            Create(axes),
            Write(axes_labels),
            run_time=1.0
        )
        self.play(
            Create(wave_curve),
            FadeIn(wave_label),
            run_time=1.0
        )

        # 展示方程和分类
        self.play(
            Write(eq_tex),
            run_time=1.0
        )
        self.play(
            Create(eq_box),
            FadeIn(class_label, shift=UP),
            run_time=1.0
        )
