from manim import *

class OSFunctionSummary(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("操作系统演化总结与核心功能",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("27", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 上部分：8.10 小结 - 演化公式
        # 硬件形态 + 应用场景 -> 操作系统多样性
        t_hw = Text("硬件形态", font="AR PL UKai CN", font_size=24, color=BLUE)
        t_plus = Text("+", font_size=24, color=WHITE)
        t_app = Text("应用场景", font="AR PL UKai CN", font_size=24, color=GREEN)
        t_arrow = MathTex(r"\rightarrow", color=WHITE)
        t_result = Text("OS多样性", font="AR PL UKai CN", font_size=24, color=YELLOW)

        formula_group = VGroup(t_hw, t_plus, t_app, t_arrow, t_result)
        formula_group.arrange(RIGHT, buff=0.2)
        formula_group.next_to(title_line, DOWN, buff=0.5)

        self.play(FadeIn(formula_group, shift=UP), run_time=1.0)

        # 3. 下部分：9.1 & 9.2 五大子系统与资源管理
        # 核心圆圈
        core_circle = Circle(radius=0.8, color=WHITE, fill_opacity=0.2, fill_color=GREY)
        core_text = Text("操作系统\n核心", font="AR PL UKai CN", font_size=20)
        core_group = VGroup(core_circle, core_text).move_to(DOWN * 1.5)

        # 左侧：物理资源 (处理器, 存储器, 设备)
        t_proc = Text("处理器管理", font="AR PL UKai CN", font_size=20, color=BLUE_A)
        t_mem = Text("存储器管理", font="AR PL UKai CN", font_size=20, color=BLUE_B)
        t_dev = Text("设备管理", font="AR PL UKai CN", font_size=20, color=BLUE_C)

        left_group = VGroup(t_proc, t_mem, t_dev).arrange(DOWN, buff=0.6)
        left_group.next_to(core_group, LEFT, buff=2.0)

        # 右侧：信息资源 (文件, 用户接口)
        t_file = Text("文件管理", font="AR PL UKai CN", font_size=20, color=GREEN_A)
        t_ui = Text("用户接口", font="AR PL UKai CN", font_size=20, color=GREEN_B)

        right_group = VGroup(t_file, t_ui).arrange(DOWN, buff=0.8) # 稍微宽一点以平衡
        right_group.next_to(core_group, RIGHT, buff=2.0)

        # 连线
        lines = VGroup()
        for item in left_group:
            lines.add(Line(core_circle.get_left(), item.get_right(), color=GREY_B))
        for item in right_group:
            lines.add(Line(core_circle.get_right(), item.get_left(), color=GREY_B))

        # 4. 资源分类框 (9.2 内容)
        # 物理资源框
        rect_phys = SurroundingRectangle(left_group, color=BLUE, buff=0.2)
        label_phys = Text("物理资源", font="AR PL UKai CN", font_size=18, color=BLUE)
        label_phys.next_to(rect_phys, UP)

        # 信息资源框
        rect_info = SurroundingRectangle(right_group, color=GREEN, buff=0.2)
        label_info = Text("信息资源", font="AR PL UKai CN", font_size=18, color=GREEN)
        label_info.next_to(rect_info, UP)

        # 动画流程
        self.play(
            FadeIn(core_group),
            Create(lines, run_time=1.5),
            LaggedStart(
                Write(left_group),
                Write(right_group),
                lag_ratio=0.2
            )
        )

        self.play(
            Create(rect_phys), Write(label_phys),
            Create(rect_info), Write(label_info),
            run_time=1.5
        )
