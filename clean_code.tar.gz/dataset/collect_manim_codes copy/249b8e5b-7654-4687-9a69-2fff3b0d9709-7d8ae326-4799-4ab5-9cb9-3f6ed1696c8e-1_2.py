from manim import *

class CommonPythonPackages(Scene):
    def construct(self):

        # 1. 标题部分 (严格按照模板)
        title = Text("常见的第三方Python包",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("2", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容定义
        # 数据结构：(包名, 描述, 颜色)
        pkg_data = [
            ("NumPy", "科学计算", BLUE),
            ("Pandas", "数据分析", GREEN),
            ("Matplotlib", "数据可视化", YELLOW),
            ("Requests", "发送网络请求", RED)
        ]

        # 创建内容组
        content_groups = VGroup()

        for name, desc, color in pkg_data:
            # 包名
            name_text = Text(name, font_size=40, color=color, weight=BOLD)
            # 描述 (使用指定中文字体)
            desc_text = Text(desc, font="AR PL UKai CN", font_size=28, color=WHITE)

            # 垂直组合
            item_group = VGroup(name_text, desc_text).arrange(DOWN, buff=0.3)
            content_groups.add(item_group)

        # 3. 布局排版
        # 使用网格布局：2行2列
        content_groups.arrange_in_grid(rows=2, cols=2, buff=(2.0, 1.0))
        # 整体居中并位于标题下方
        content_groups.move_to(ORIGIN).next_to(title_line, DOWN, buff=0.8)

        # 4. 动画展示
        for item in content_groups:
            # 使用 SurroundingRectangle 框选强调
            rect = SurroundingRectangle(item, color=GRAY, buff=0.3, stroke_width=2)

            # 动画流程：画框 -> 写包名 -> 淡入描述
            self.play(
                Create(rect),
                Write(item[0]), # 包名
                run_time=0.8
            )
            self.play(
                FadeIn(item[1], shift=UP * 0.2), # 描述
                run_time=0.6
            )
            # 短暂停顿,保持节奏
