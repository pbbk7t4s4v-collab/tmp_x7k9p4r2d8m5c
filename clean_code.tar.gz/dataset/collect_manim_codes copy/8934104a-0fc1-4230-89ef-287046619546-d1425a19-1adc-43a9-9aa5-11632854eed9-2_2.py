from manim import *

class AgentEnvironmentLoop(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("智能体-环境交互循环 (Agent-Environment Loop)",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 定义主要实体：智能体 和 环境
        # 智能体在上方
        agent_text = Text("智能体 (Agent)", font="AR PL UKai CN", font_size=28, color=BLUE_A)
        agent_brain = Text("🧠", font_size=40).next_to(agent_text, UP, buff=0.1)
        agent_group_content = VGroup(agent_brain, agent_text).move_to(UP * 1.5)

        agent_box = SurroundingRectangle(agent_group_content, color=BLUE, buff=0.2, fill_opacity=0.1, fill_color=BLUE)
        agent_full = VGroup(agent_group_content, agent_box)

        # 环境在下方
        env_text = Text("环境 (Environment)", font="AR PL UKai CN", font_size=28, color=GREEN_A)
        env_icon = Text("🌍", font_size=40).next_to(env_text, DOWN, buff=0.1)
        env_group_content = VGroup(env_icon, env_text).move_to(DOWN * 1.5)

        env_box = SurroundingRectangle(env_group_content, color=GREEN, buff=0.2, fill_opacity=0.1, fill_color=GREEN)
        env_full = VGroup(env_group_content, env_box)

        # 播放实体出现动画
        self.play(
            FadeIn(agent_full, shift=DOWN),
            FadeIn(env_full, shift=UP),
            run_time=1.0
        )

        # 3. 绘制交互箭头和标签

        # 动作箭头：从智能体右侧指向环境右侧 (顺时针曲线)
        # 使用 start_point 和 end_point 确保位置准确
        arrow_action = CurvedArrow(
            start_point=agent_box.get_right(),
            end_point=env_box.get_right(),
            angle=-TAU/4,
            color=YELLOW
        )

        # 动作标签 A_t
        action_label = MathTex("A_t", color=YELLOW, font_size=36).next_to(arrow_action, RIGHT, buff=0.1)
        action_text = Text("执行动作", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(action_label, RIGHT, buff=0.1)

        # 反馈箭头：从环境左侧指向智能体左侧 (顺时针曲线)
        arrow_feedback = CurvedArrow(
            start_point=env_box.get_left(),
            end_point=agent_box.get_left(),
            angle=-TAU/4,
            color=ORANGE
        )

        # 反馈标签 O_{t+1}, R_{t+1}
        feedback_label = MathTex("O_{t+1}, R_{t+1}", color=ORANGE, font_size=36).next_to(arrow_feedback, LEFT, buff=0.1)
        feedback_text = Text("新观察 & 奖励", font="AR PL UKai CN", font_size=20, color=ORANGE).next_to(feedback_label, LEFT, buff=0.1)

        # 4. 动画展示循环过程

        # 第一步：动作 A_t
        self.play(
            Create(arrow_action),
            Write(action_label),
            FadeIn(action_text),
            run_time=1.2
        )

        # 稍微停顿

        # 第二步：环境反馈 O, R
        self.play(
            Create(arrow_feedback),
            Write(feedback_label),
            FadeIn(feedback_text),
            run_time=1.2
        )

        # 5. 强调循环
        # 创建一个覆盖在箭头上的动态效果
        self.play(
            Indicate(agent_box, color=WHITE),
            Indicate(env_box, color=WHITE),
            run_time=1.0
        )
