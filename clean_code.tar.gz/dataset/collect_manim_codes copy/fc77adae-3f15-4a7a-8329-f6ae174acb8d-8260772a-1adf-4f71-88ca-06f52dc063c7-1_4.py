from manim import *

class FluidMechanicsInBiologyScene(Scene):
    def construct(self):

        # 1. Title Setup
        title = Text("Applications in Biology and Medicine",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("4", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Content Setup - Bulleted List
        concepts_list = BulletedList(
            "Blood flow analysis helps assess cardiovascular health.",
            "Respiratory system airflow is studied with fluid dynamics.",
            "Drug diffusion in body fluids follows fluid mechanics principles.",
            font_size=28
        ).to_edge(LEFT, buff=1).shift(UP*0.5)

        # 3. Animate Bullet Points and Corresponding Visuals

        # Point 1: Blood Flow
        self.play(FadeIn(concepts_list[0], shift=RIGHT, run_time=1))

        # Visual for Blood Flow
        artery = Line(LEFT*2, RIGHT*2, color=RED_D, stroke_width=8).shift(RIGHT*3 + UP*1.5)
        vein = Line(LEFT*2, RIGHT*2, color=BLUE_D, stroke_width=12).next_to(artery, DOWN, buff=0.5)
        artery_label = Text("Artery", font_size=24).next_to(artery, RIGHT)
        vein_label = Text("Vein", font_size=24).next_to(vein, RIGHT)

        blood_cells = VGroup(*[Dot(color=RED, radius=0.05) for _ in range(10)])
        blood_cells.arrange_in_grid(2, 5, buff=0.1).move_to(artery.get_start())

        blood_flow_group = VGroup(artery, vein, artery_label, vein_label)
        self.play(FadeIn(blood_flow_group, shift=UP))
        self.play(MoveAlongPath(blood_cells, artery, run_time=2, rate_func=linear))

        # Point 2: Respiratory System
        self.play(FadeIn(concepts_list[1], shift=RIGHT, run_time=1))

        # Visual for Respiratory System
        trachea = Line(UP, DOWN*1.5, stroke_width=8, color=ORANGE).shift(RIGHT*3 + UP*1.5)
        bronchi_l = Line(trachea.get_end(), trachea.get_end() + DL*1, stroke_width=6, color=ORANGE)
        bronchi_r = Line(trachea.get_end(), trachea.get_end() + DR*1, stroke_width=6, color=ORANGE)
        airflow_in = Arrow(UP*2, ORIGIN, buff=0).next_to(trachea, UP, buff=0)
        airflow_label = Text("Airflow", font_size=24).next_to(airflow_in, UP)

        respiratory_group = VGroup(trachea, bronchi_l, bronchi_r, airflow_in, airflow_label)

        self.play(FadeOut(VGroup(blood_flow_group, blood_cells), shift=DOWN))
        self.play(Create(respiratory_group), Write(airflow_label))

        # Point 3: Drug Diffusion
        self.play(FadeIn(concepts_list[2], shift=RIGHT, run_time=1))

        # Visual for Drug Diffusion
        container = Square(side_length=2.5, color=BLUE_A).shift(RIGHT*3 + DOWN*0.5)
        drug_particles = VGroup(*[Dot(color=GREEN, radius=0.05) for _ in range(30)]).move_to(container.get_center())

        diffusion_group = VGroup(container, drug_particles)

        self.play(FadeOut(respiratory_group, shift=DOWN))
        self.play(FadeIn(diffusion_group, scale=0.5))

        # Animate diffusion
        target_positions = [
            container.get_center() + np.array([np.random.uniform(-1.0, 1.0), np.random.uniform(-1.0, 1.0), 0])
            for _ in drug_particles
        ]
        anims = [dot.animate.move_to(pos) for dot, pos in zip(drug_particles, target_positions)]
        self.play(*anims, run_time=2)

        to_fade = [m for m in self.mobjects if m != bg]
        self.play(FadeOut(Group(*to_fade)))
