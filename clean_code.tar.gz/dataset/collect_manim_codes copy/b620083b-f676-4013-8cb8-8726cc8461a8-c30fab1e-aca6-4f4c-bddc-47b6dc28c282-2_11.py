from manim import *

class UncertaintySynthesisAndResult(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("不确定度合成与结果表示",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.0),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("19", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 分为左、右、下三部分

        # 左侧:不确定度合成 (公式 + 几何示意)
        left_label = Text("不确定度合成方法", font="AR PL UKai CN", font_size=24, color=BLUE)
        left_eq = MathTex(r"u_x = \sqrt{\Delta_a^2 + \Delta_b^2}", font_size=30)

        # 简单的直角三角形示意图,辅助理解平方和开根号
        tri_a = Line(ORIGIN, RIGHT*1.5, color=WHITE)
        tri_b = Line(RIGHT*1.5, RIGHT*1.5 + UP*1.0, color=WHITE)
        tri_c = Line(ORIGIN, RIGHT*1.5 + UP*1.0, color=YELLOW) # 斜边高亮

        tri_label_a = MathTex(r"\Delta_a", font_size=20).next_to(tri_a, DOWN, buff=0.1)
        tri_label_b = MathTex(r"\Delta_b", font_size=20).next_to(tri_b, RIGHT, buff=0.1)
        tri_label_c = MathTex(r"u_x", font_size=20, color=YELLOW).next_to(tri_c, UP, buff=0.1).shift(LEFT*0.5)

        triangle_group = VGroup(tri_a, tri_b, tri_c, tri_label_a, tri_label_b, tri_label_c)

        # 组合左侧元素
        left_group = VGroup(left_label, left_eq, triangle_group).arrange(DOWN, buff=0.4)
        left_group.to_edge(LEFT, buff=1.5).shift(UP*0.5)

        # 右侧:相对不确定度
        right_label = Text("相对不确定度", font="AR PL UKai CN", font_size=24, color=BLUE)
        # 注意 LaTeX 中百分号需要转义
        right_eq = MathTex(r"u_{rx} = \frac{u_x}{\bar{x}} \times 100\%", font_size=30)

        right_group = VGroup(right_label, right_eq).arrange(DOWN, buff=0.5)
        # 对齐左侧组的顶部
        right_group.move_to(left_group.get_center())
        right_group.to_edge(RIGHT, buff=1.5)

        # 底部:测量结果表示
        bottom_label = Text("最终测量结果表示", font="AR PL UKai CN", font_size=24, color=GREEN)
        bottom_eq = MathTex(r"x = \bar{x} \pm u_x", font_size=36)

        bottom_group = VGroup(bottom_label, bottom_eq).arrange(DOWN, buff=0.3)
        bottom_group.to_edge(DOWN, buff=1.0)

        # 强调框
        box = SurroundingRectangle(bottom_eq, color=YELLOW, buff=0.2)

        # 3. 动画展示流程

        # 展示左侧:合成公式与几何意义
        self.play(FadeIn(left_label, shift=DOWN), Write(left_eq))
        self.play(Create(triangle_group), run_time=1.5)

        # 展示右侧:相对不确定度
        self.play(FadeIn(right_label, shift=DOWN), Write(right_eq))

        # 展示底部:结果表示
        self.play(FadeIn(bottom_group, shift=UP))
        self.play(Create(box))
