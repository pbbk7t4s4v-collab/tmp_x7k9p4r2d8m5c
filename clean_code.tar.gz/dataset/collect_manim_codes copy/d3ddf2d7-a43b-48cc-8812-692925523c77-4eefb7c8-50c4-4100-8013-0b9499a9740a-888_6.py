from manim import *

class JiaZuZhangWorksAndStyle(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("贾祖璋先生著作与风格",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("6", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 图片布局 (左侧)
        # 第一张图片：旧书
        img1 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/d3ddf2d7-a43b-48cc-8812-692925523c77/4eefb7c8-50c4-4100-8013-0b9499a9740a/pictures/888_6/1.png") # 这里期望是一张具有年代感的旧书，封面上竖排繁体字写着《鸟类概论》，书旁配有一只栩栩如生的工笔画风格的鸟类插图，整体色调泛黄，营造出1930年代的历史感和学术感。复古写实风格。
        img1.height = 2.2

        # 第二张图片：作者
        img2 = ImageMobject("/home/TeachMasterAppV2/backend/generated_content/d3ddf2d7-a43b-48cc-8812-692925523c77/4eefb7c8-50c4-4100-8013-0b9499a9740a/pictures/888_6/2.png") # 这里期望是一位民国时期的学者（贾祖璋）正在书房内观察生物标本或伏案写作，穿着中山装或长衫，戴着眼镜，背景是摆满书籍和植物标本的书架。水墨或淡彩插画风格，体现科学与文学的融合。
        img2.height = 2.2

        # 组合图片并竖向排列
        imgs_group = Group(img1, img2).arrange(DOWN, buff=0.6)
        imgs_group.to_edge(LEFT, buff=1).shift(DOWN * 0.3)

        # 3. 文本内容 (右侧)
        # 文本1：关于《鸟类概论》
        text1 = Text("1931年出版《鸟类概论》\n我国最早的现代鸟类学著作",
                     font="AR PL UKai CN", font_size=24, line_spacing=1.5)

        # 文本2：科普作品特点
        text2 = Text("作品特点：\n将科学知识、历史典故\n与文学笔法有机融合",
                     font="AR PL UKai CN", font_size=24, line_spacing=1.5)

        # 文本3：核心评价
        text3 = Text("兼具严谨的科学性\n深刻的思想性与优美的文学性",
                     font="AR PL UKai CN", font_size=24, line_spacing=1.5, color=YELLOW)

        # 组合文本并竖向排列，左对齐
        text_group = VGroup(text1, text2, text3).arrange(DOWN, buff=0.8, aligned_edge=LEFT)
        text_group.next_to(imgs_group, RIGHT, buff=1)

        # 强调框
        rect = SurroundingRectangle(text3, color=BLUE, buff=0.15)

        # 4. 动画展示流程
        # 展示第一部分：书与介绍
        self.play(FadeIn(img1, shift=RIGHT), run_time=1)
        self.play(Write(text1), run_time=1.2)

        # 展示第二部分：作者与特点
        self.play(FadeIn(img2, shift=RIGHT), run_time=1)
        self.play(Write(text2), run_time=1.2)

        # 展示第三部分：总结评价与强调
        self.play(Write(text3), run_time=1.5)
        self.play(Create(rect), run_time=0.8)
