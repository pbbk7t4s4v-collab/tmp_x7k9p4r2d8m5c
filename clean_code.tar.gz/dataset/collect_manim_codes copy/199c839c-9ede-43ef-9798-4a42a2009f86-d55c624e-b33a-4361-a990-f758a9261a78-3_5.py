from manim import *

class AlgorithmControlStructures(Scene):
    def construct(self):

        # ---------------------------------------------------------
        # 1. 标题设置 (模板代码)
        # ---------------------------------------------------------
        title = Text("算法流程图的三种基本控制结构",
                    font_size=34,  # 增大字号
                    font="AR PL UKai CN", #字体
                    color=WHITE,   # 白色文字提高对比度
                    weight=BOLD)   # 加粗
        title.to_edge(UP, buff=0.5)  # 向上调整位置
        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        # 组合标题元素
        title_group = VGroup(title, title_line)
        # 更生动的标题动画 - 先缩放再淡入
        self.play(
            Write(title, run_time=1.5),  # 延长书写时间
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("12", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # ---------------------------------------------------------
        # 2. 内容可视化设计
        # ---------------------------------------------------------

        # 通用配置
        box_config = {"height": 0.6, "width": 1.2, "color": BLUE, "fill_opacity": 0.2, "fill_color": BLUE}
        diamond_config = {"side_length": 0.8, "color": GREEN, "fill_opacity": 0.2, "fill_color": GREEN}
        text_font = "AR PL UKai CN"
        label_size = 20
        desc_size = 18

        # --- 第一部分:顺序结构 (Sequence) ---
        # 几何图形
        seq_box1 = Rectangle(**box_config)
        seq_box1_text = Text("操作A", font=text_font, font_size=16).move_to(seq_box1)

        seq_arrow = Arrow(start=UP, end=DOWN, buff=0, color=WHITE).scale(0.5)

        seq_box2 = Rectangle(**box_config)
        seq_box2_text = Text("操作B", font=text_font, font_size=16).move_to(seq_box2)

        # 组合顺序结构
        seq_visual = VGroup(VGroup(seq_box1, seq_box1_text), seq_arrow, VGroup(seq_box2, seq_box2_text))
        seq_visual.arrange(DOWN, buff=0.2)

        seq_label = Text("顺序结构", font=text_font, font_size=label_size, color=YELLOW).next_to(seq_visual, UP, buff=0.3)
        seq_desc = Text("按先后顺序执行", font=text_font, font_size=desc_size, color=GRAY_B).next_to(seq_visual, DOWN, buff=0.3)

        group_sequence = VGroup(seq_label, seq_visual, seq_desc)

        # --- 第二部分:选择结构 (Selection) ---
        # 几何图形
        sel_diamond = Square(**diamond_config).rotate(PI/4)
        sel_diamond_text = Text("条件?", font=text_font, font_size=14).move_to(sel_diamond)

        # 分支箭头
        sel_arrow_l = Arrow(start=sel_diamond.get_left(), end=sel_diamond.get_left() + LEFT*0.8 + DOWN*0.8, buff=0, color=WHITE, stroke_width=2)
        sel_arrow_r = Arrow(start=sel_diamond.get_right(), end=sel_diamond.get_right() + RIGHT*0.8 + DOWN*0.8, buff=0, color=WHITE, stroke_width=2)

        # 分支框
        sel_box_l = Rectangle(height=0.5, width=0.8, color=BLUE)
        sel_text_l = Text("分支1", font=text_font, font_size=14).move_to(sel_box_l)

        sel_box_r = Rectangle(height=0.5, width=0.8, color=BLUE)
        sel_text_r = Text("分支2", font=text_font, font_size=14).move_to(sel_box_r)

        # 定位
        sel_box_l.next_to(sel_arrow_l.get_end(), DOWN, buff=0.1).shift(UP*0.3) # 微调
        sel_text_l.move_to(sel_box_l)
        sel_box_r.next_to(sel_arrow_r.get_end(), DOWN, buff=0.1).shift(UP*0.3)
        sel_text_r.move_to(sel_box_r)

        sel_visual = VGroup(
            VGroup(sel_diamond, sel_diamond_text),
            sel_arrow_l, sel_arrow_r,
            VGroup(sel_box_l, sel_text_l),
            VGroup(sel_box_r, sel_text_r)
        )

        sel_label = Text("选择结构", font=text_font, font_size=label_size, color=YELLOW).next_to(sel_visual, UP, buff=0.3)
        # 保持标签高度一致
        sel_label.align_to(seq_label, UP)
        sel_desc = Text("根据条件分支", font=text_font, font_size=desc_size, color=GRAY_B).next_to(sel_visual, DOWN, buff=0.3)
        sel_desc.align_to(seq_desc, DOWN)

        group_selection = VGroup(sel_label, sel_visual, sel_desc)

        # --- 第三部分:循环结构 (Iteration) ---
        # 几何图形
        loop_box = Rectangle(**box_config)
        loop_box_text = Text("循环体", font=text_font, font_size=16).move_to(loop_box)

        loop_arrow1 = Arrow(start=UP, end=DOWN, buff=0, color=WHITE).scale(0.5)

        loop_diamond = Square(**diamond_config).rotate(PI/4)
        loop_diamond_text = Text("结束?", font=text_font, font_size=14).move_to(loop_diamond)

        # 组合主体
        loop_main = VGroup(VGroup(loop_box, loop_box_text), loop_arrow1, VGroup(loop_diamond, loop_diamond_text))
        loop_main.arrange(DOWN, buff=0.2)

        # 回路箭头 (曲线)
        # 从菱形右侧出来,回到方块右侧
        p1 = loop_diamond.get_right()
        p2 = loop_diamond.get_right() + RIGHT * 0.5
        p3 = loop_box.get_right() + RIGHT * 0.5
        p4 = loop_box.get_right()

        loop_path = VMobject(color=WHITE)
        loop_path.set_points_as_corners([p1, p2, p3, p4])
        # 添加箭头尖端
        loop_tip = ArrowTriangleFilledTip(color=WHITE).scale(0.5)
        loop_tip.rotate(PI) # 向左指
        loop_tip.move_to(p4)
        loop_back_arrow = VGroup(loop_path, loop_tip)

        loop_visual = VGroup(loop_main, loop_back_arrow)

        loop_label = Text("循环结构", font=text_font, font_size=label_size, color=YELLOW).next_to(loop_visual, UP, buff=0.3)
        loop_label.align_to(seq_label, UP)
        loop_desc = Text("反复执行直到终止", font=text_font, font_size=desc_size, color=GRAY_B).next_to(loop_visual, DOWN, buff=0.3)
        loop_desc.align_to(seq_desc, DOWN)

        group_loop = VGroup(loop_label, loop_visual, loop_desc)

        # ---------------------------------------------------------
        # 3. 整体布局与动画
        # ---------------------------------------------------------

        # 将三组结构横向排列
        all_structures = VGroup(group_sequence, group_selection, group_loop)
        all_structures.arrange(RIGHT, buff=1.0)
        all_structures.move_to(ORIGIN).shift(DOWN * 0.5)

        # 动画播放
        # 分步展示三个结构,体现逻辑连贯性

        # 1. 顺序结构
        self.play(FadeIn(group_sequence, shift=UP), run_time=1.5)

        # 2. 选择结构
        self.play(FadeIn(group_selection, shift=UP), run_time=1.5)

        # 3. 循环结构
        self.play(FadeIn(group_loop, shift=UP), run_time=1.5)

        # 最终强调
        surround_rect = SurroundingRectangle(all_structures, color=BLUE_B, buff=0.2, stroke_width=2)
        self.play(Create(surround_rect), run_time=1.5)
