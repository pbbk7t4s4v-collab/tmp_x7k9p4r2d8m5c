from manim import *

class FluidMechanicsImpactScene(Scene):
    def construct(self):

        # 1. Title
        title = Text("Economic & Environmental Impact",
                    font_size=34,
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)
        title_line = Line(LEFT, RIGHT, color=YELLOW).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("5", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Core Concept: Fluid Mechanics Role
        role_text = Text("Fluid mechanics enables:", font_size=30).shift(UP * 2)
        self.play(Write(role_text))

        # 3. Main applications: Energy Saving and Environmental Protection
        app1_text = Text("Energy Saving", font_size=32, color=GREEN)
        app2_text = Text("Environmental Protection", font_size=32, color=TEAL)

        applications = VGroup(app1_text, app2_text).arrange(RIGHT, buff=1.5)
        applications.next_to(role_text, DOWN, buff=0.5)

        self.play(
            FadeIn(app1_text, shift=DOWN),
            FadeIn(app2_text, shift=DOWN),
            run_time=1.5
        )

        # 4. How it's achieved: Optimization
        how_text = Text("By optimizing fluid flow processes", font_size=30)
        how_box = SurroundingRectangle(how_text, color=BLUE, buff=0.2, corner_radius=0.1)
        how_group = VGroup(how_text, how_box).move_to(ORIGIN)

        self.play(FadeIn(how_group))

        # 5. Example and result
        example_title = Text("Example: Chemical Production", font_size=28, color=WHITE)
        example_title.to_edge(LEFT, buff=1).shift(DOWN * 1.5)

        self.play(Write(example_title))

        flow_diagram = VGroup(
            Text("Optimized Piping", font_size=26),
            Arrow(RIGHT, color=YELLOW),
            Text("↓ Pump Power\n↓ CO2 Emissions", font_size=26, color=YELLOW)
        ).arrange(RIGHT, buff=0.5)
        flow_diagram.next_to(example_title, DOWN, buff=0.4, aligned_edge=LEFT)

        self.play(FadeIn(flow_diagram, shift=RIGHT), run_time=2)
