from manim import *

class BatchProcessingScene(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("批处理系统与I/O中断技术",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        title_group = VGroup(title, title_line)

        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("26", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 左侧展示：批处理与Monitor (Section 6.6)
        # 定义监控程序框
        monitor_box = Rectangle(height=1.5, width=3, color=BLUE, fill_opacity=0.2)
        monitor_text = Text("监控程序\n(Monitor)", font="AR PL UKai CN", font_size=24, color=BLUE_A)
        monitor_group = VGroup(monitor_box, monitor_text).shift(LEFT * 3.5 + UP * 0.5)

        # 定义作业队列 (JCL defined jobs)
        job_1 = Rectangle(height=0.8, width=0.8, color=WHITE)
        job_text_1 = Text("J1", font_size=20)
        job_2 = Rectangle(height=0.8, width=0.8, color=WHITE)
        job_text_2 = Text("J2", font_size=20)

        jobs = VGroup(VGroup(job_1, job_text_1), VGroup(job_2, job_text_2))
        jobs.arrange(RIGHT, buff=0.2)
        jobs.next_to(monitor_group, DOWN, buff=0.5)

        # JCL 标签
        jcl_arrow = Arrow(start=jobs.get_left() + LEFT, end=jobs.get_left(), buff=0.1, color=YELLOW)
        jcl_text = Text("作业控制语言(JCL)", font="AR PL UKai CN", font_size=20, color=YELLOW).next_to(jcl_arrow, UP, buff=0.1)

        # 3. 右侧展示：I/O中断与流程 (Section 6.7)
        # 定义 CPU 和 I/O 设备
        cpu_box = Rectangle(height=1.2, width=1.5, color=GREEN, fill_opacity=0.2)
        cpu_text = Text("CPU", font_size=24, color=GREEN_B)
        cpu_group = VGroup(cpu_box, cpu_text).shift(RIGHT * 2 + UP * 1.5)

        io_box = Rectangle(height=1.2, width=1.5, color=RED, fill_opacity=0.2)
        io_text = Text("I/O设备", font="AR PL UKai CN", font_size=24, color=RED_B)
        io_group = VGroup(io_box, io_text).next_to(cpu_group, DOWN, buff=1.5)

        # 定义交互箭头
        arrow_start_io = Arrow(start=cpu_group.get_bottom(), end=io_group.get_top(), buff=0.1, color=WHITE)
        arrow_interrupt = CurvedArrow(start_point=io_group.get_right(), end_point=cpu_group.get_right(), angle=TAU/4, color=ORANGE)

        interrupt_label = Text("I/O完成 -> 发送中断", font="AR PL UKai CN", font_size=18, color=ORANGE)
        interrupt_label.next_to(arrow_interrupt, RIGHT, buff=0.1)

        # 4. 底部总结：单道串行限制
        summary_rect = SurroundingRectangle(VGroup(cpu_group, io_group), color=GREY, buff=0.2)
        limit_text = Text("尽管引入中断，仍受限于单道串行", font="AR PL UKai CN", font_size=22, color=GREY_A)
        limit_text.next_to(summary_rect, DOWN, buff=0.2)

        # 5. 动画流程
        # 左侧入场
        self.play(FadeIn(monitor_group), run_time=1)
        self.play(
            GrowArrow(jcl_arrow),
            Write(jcl_text),
            FadeIn(jobs),
            run_time=1
        )

        # 右侧入场
        self.play(
            FadeIn(cpu_group),
            FadeIn(io_group),
            run_time=1
        )

        # 演示中断机制
        self.play(GrowArrow(arrow_start_io), run_time=0.5)
        self.play(
            Create(arrow_interrupt),
            Write(interrupt_label),
            run_time=1
        )

        # 强调单道限制
        self.play(
            Create(summary_rect),
            Write(limit_text),
            run_time=1.5
        )
