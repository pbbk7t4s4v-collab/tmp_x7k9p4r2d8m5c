from manim import *

class CompilerSimplification(Scene):
    def construct(self):

        # 1. 标题设置 (严格按照模板)
        title = Text("汇编/编译器简化程序执行",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)

        # 组合标题元素
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("30", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. 内容布局 - 左右结构展示转化过程

        # 左侧：人类可读的代码 (汇编/高级语言)
        # 使用 Text 模拟代码块，避免使用 Code() 对象
        source_code_lines = VGroup(
            Text("LOAD  R1, [Data]", font="Monospace", font_size=24, color=BLUE_A),
            Text("ADD   R1, 10", font="Monospace", font_size=24, color=BLUE_A),
            Text("STORE [Res], R1", font="Monospace", font_size=24, color=BLUE_A)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        source_label = Text("助记符 / 源代码", font="AR PL UKai CN", font_size=20, color=BLUE)\
            .next_to(source_code_lines, UP, buff=0.2)

        source_group = VGroup(source_label, source_code_lines)
        source_group.move_to(LEFT * 4.5)

        # 中间：编译器/汇编器 (核心机制)
        translator_text = Text("汇编器 / 编译器", font="AR PL UKai CN", font_size=24, color=GREEN)
        translator_box = SurroundingRectangle(translator_text, color=GREEN, buff=0.3, fill_opacity=0.1, fill_color=GREEN)
        translator_group = VGroup(translator_box, translator_text)
        translator_group.move_to(ORIGIN)

        # 右侧：机器代码 (二进制)
        machine_code_lines = VGroup(
            Text("10100001 00000000", font="Monospace", font_size=24, color=RED_A),
            Text("00000101 00001010", font="Monospace", font_size=24, color=RED_A),
            Text("10100011 00000100", font="Monospace", font_size=24, color=RED_A)
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.15)

        machine_label = Text("机器指令 (0/1)", font="AR PL UKai CN", font_size=20, color=RED)\
            .next_to(machine_code_lines, UP, buff=0.2)

        machine_group = VGroup(machine_label, machine_code_lines)
        machine_group.move_to(RIGHT * 4.5)

        # 箭头连接
        arrow_in = Arrow(source_group.get_right(), translator_group.get_left(), buff=0.2, color=GREY)
        arrow_out = Arrow(translator_group.get_right(), machine_group.get_left(), buff=0.2, color=GREY)

        # 3. 动画流程

        # 第一步：展示源代码输入
        self.play(FadeIn(source_group, shift=RIGHT))

        # 第二步：出现转换器
        self.play(
            Create(translator_box),
            Write(translator_text),
            GrowArrow(arrow_in)
        )

        # 第三步：模拟转换过程 (高亮一下盒子)
        self.play(
            translator_box.animate.set_fill(opacity=0.4),
            run_time=0.5
        )
        self.play(
            translator_box.animate.set_fill(opacity=0.1),
            run_time=0.5
        )

        # 第四步：输出机器码
        self.play(
            GrowArrow(arrow_out),
            FadeIn(machine_group, shift=RIGHT)
        )

        # 4. 总结文本 (底部)
        summary_text = Text("核心价值：自动翻译，将程序员从繁琐的二进制编码中解放出来",
                           font="AR PL UKai CN",
                           font_size=26,
                           color=YELLOW)
        summary_text.next_to(translator_group, DOWN, buff=1.5)

        # 添加边框强调总结
        summary_rect = SurroundingRectangle(summary_text, color=YELLOW, buff=0.2, stroke_width=1)

        self.play(Write(summary_text))
        self.play(Create(summary_rect))
