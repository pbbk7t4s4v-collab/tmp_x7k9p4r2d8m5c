from manim import *

class GraphConcepts(Scene):
    def construct(self):

        # 1. 标题设置
        title = Text("Floyd算法补充与AOV/AOE网",
                    font_size=34,
                    font="AR PL UKai CN",
                    color=WHITE,
                    weight=BOLD)
        title.to_edge(UP, buff=0.5)

        # 添加底部强调线
        title_line = Line(LEFT, RIGHT, color=ORANGE).next_to(title, DOWN, buff=0.1)
        title_line.match_width(title)
        title_group = VGroup(title, title_line)

        # 标题动画
        self.play(
            Write(title, run_time=1.5),
            GrowFromCenter(title_line, run_time=0.8)
        )

        # Page number
        page_number = Text("8", font_size=20, color=GRAY_C)
        page_number.to_corner(DR, buff=0.3)
        self.play(FadeIn(page_number))

        # 2. Floyd 算法补充内容 (上半部分展示)
        # 布局容器
        floyd_content = VGroup()

        # 路径恢复点
        p1_label = Text("1. 路径恢复：", font="AR PL UKai CN", font_size=26, color=BLUE)
        p1_text = Text("维护 pre[i][j] 记录中介点 k，递归回溯还原路径", font="AR PL UKai CN", font_size=24)
        row1 = VGroup(p1_label, p1_text).arrange(RIGHT, buff=0.2)

        # 复杂度点
        p2_label = Text("2. 复杂度：", font="AR PL UKai CN", font_size=26, color=BLUE)
        p2_math = MathTex(r"O(n^3)", color=YELLOW)
        p2_text = Text("，支持负权边 (但在负权回路下失效)", font="AR PL UKai CN", font_size=24)
        row2 = VGroup(p2_label, p2_math, p2_text).arrange(RIGHT, buff=0.2)

        floyd_content.add(row1, row2).arrange(DOWN, buff=0.4, aligned_edge=LEFT)
        floyd_content.next_to(title_line, DOWN, buff=0.5)

        # 展示 Floyd 内容
        self.play(FadeIn(floyd_content, shift=UP))

        # 3. 切换到 AOV 与 AOE 的对比 (清空 Floyd 内容)
        self.play(FadeOut(floyd_content, shift=UP))

        # AOV 部分 (左侧)
        # 标题与描述
        aov_header = Text("AOV 网 (Activity On Vertex)", font="AR PL UKai CN", font_size=26, color=YELLOW)
        aov_desc1 = Text("顶点 = 活动", font="AR PL UKai CN", font_size=22)
        aov_desc2 = Text("边 = 优先关系 (先后约束)", font="AR PL UKai CN", font_size=22)

        # AOV 可视化图示
        c1 = Circle(radius=0.4, color=WHITE).set_fill(BLUE_E, opacity=0.8)
        t1 = Text("课程A", font="AR PL UKai CN", font_size=16).move_to(c1)
        c2 = Circle(radius=0.4, color=WHITE).set_fill(BLUE_E, opacity=0.8)
        t2 = Text("课程B", font="AR PL UKai CN", font_size=16).move_to(c2)

        # 手动布局图示
        visual_aov_group = VGroup(c1, t1, c2, t2)
        group_c1 = VGroup(c1, t1).move_to(LEFT * 4.5 + DOWN * 1.5)
        group_c2 = VGroup(c2, t2).move_to(LEFT * 2.0 + DOWN * 1.5)

        arrow_aov = Arrow(group_c1.get_right(), group_c2.get_left(), buff=0.1, color=YELLOW)

        aov_visual = VGroup(group_c1, group_c2, arrow_aov)
        aov_text_group = VGroup(aov_header, aov_desc1, aov_desc2).arrange(DOWN, buff=0.2)
        aov_full = VGroup(aov_text_group, aov_visual).arrange(DOWN, buff=0.5).move_to(LEFT * 3.2)

        # AOE 部分 (右侧)
        # 标题与描述
        aoe_header = Text("AOE 网 (Activity On Edge)", font="AR PL UKai CN", font_size=26, color=GREEN)
        aoe_desc1 = Text("边 = 活动 (持续时间)", font="AR PL UKai CN", font_size=22)
        aoe_desc2 = Text("顶点 = 事件 (瞬间状态)", font="AR PL UKai CN", font_size=22)

        # AOE 可视化图示
        n1 = Dot(radius=0.15, color=GREY)
        n2 = Dot(radius=0.15, color=GREY)
        n1_grp = VGroup(n1, Text("V1", font_size=16).next_to(n1, DOWN, buff=0.1)).move_to(RIGHT * 2.0 + DOWN * 1.5)
        n2_grp = VGroup(n2, Text("V2", font_size=16).next_to(n2, DOWN, buff=0.1)).move_to(RIGHT * 4.5 + DOWN * 1.5)

        arrow_aoe = Arrow(n1.get_center(), n2.get_center(), buff=0.2, color=GREEN)
        edge_label = Text("施工:5天", font="AR PL UKai CN", font_size=18, color=GREEN_A).next_to(arrow_aoe, UP, buff=0.05)

        aoe_visual = VGroup(n1_grp, n2_grp, arrow_aoe, edge_label)
        aoe_text_group = VGroup(aoe_header, aoe_desc1, aoe_desc2).arrange(DOWN, buff=0.2)
        aoe_full = VGroup(aoe_text_group, aoe_visual).arrange(DOWN, buff=0.5).move_to(RIGHT * 3.2)

        # 中央分隔线
        sep_line = DashedLine(UP * 1.5, DOWN * 3, color=GREY)

        # 动画展示 AOV/AOE 对比
        self.play(Create(sep_line))
        self.play(
            FadeIn(aov_full, shift=RIGHT),
            FadeIn(aoe_full, shift=LEFT)
        )

        # 核心概念强调框
        rect_aov = SurroundingRectangle(aov_desc1, color=YELLOW, buff=0.1)
        rect_aoe = SurroundingRectangle(aoe_desc1, color=GREEN, buff=0.1)

        self.play(
            Create(rect_aov),
            Create(rect_aoe)
        )
