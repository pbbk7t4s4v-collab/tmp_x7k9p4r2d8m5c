import os
import re
import subprocess
import shutil
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm

def get_scene_class(file_path):
    """解析代码，获取继承自 Scene 的类名"""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    # 匹配 class ClassName(Scene): 或 (LinearScene) 等
    match = re.search(r'class\s+(\w+)\((?:Scene|MovingCameraScene|ThreeDScene|VectorScene|RestoredScene)', content)
    return match.group(1) if match else None

def render_manim_file(py_file, output_root):
    """单个文件渲染逻辑"""
    py_file = Path(py_file)
    output_root = Path(output_root)
    file_stem = py_file.stem  # 不带后缀的文件名
    
    # 1. 获取类名
    scene_class = get_scene_class(py_file)
    if not scene_class:
        return False, py_file.name, "未找到 Scene 类"

    # 2. 准备临时媒体目录，避免多进程冲突
    temp_media_dir = output_root / f"temp_{file_stem}"
    
    # 3. 执行 Manim 命令
    # -ql: 最低画质 (480p 15fps)
    # --media_dir: 指定临时输出路径
    # -o: 指定输出文件名
    cmd = [
        "manim", "-ql", 
        str(py_file), scene_class, 
        "--media_dir", str(temp_media_dir),
        "-o", f"{file_stem}.mp4",
        "--progress_bar", "none" # 禁用内建进度条，避免干扰 tqdm
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        
        # 4. 移动视频到目标文件夹根目录
        # Manim 的输出路径通常是 temp_media_dir/videos/文件名/480p15/文件名.mp4
        source_video = temp_media_dir / "videos" / file_stem / "480p15" / f"{file_stem}.mp4"
        dest_video = output_root / f"{file_stem}.mp4"
        
        if source_video.exists():
            shutil.move(str(source_video), str(dest_video))
            # 清理临时目录
            shutil.rmtree(temp_media_dir)
            return True, py_file.name, None
        else:
            return False, py_file.name, "渲染完成但未找到视频文件"
            
    except subprocess.CalledProcessError as e:
        if temp_media_dir.exists():
            shutil.rmtree(temp_media_dir)
        return False, py_file.name, e.stderr

def batch_render(input_dir, output_dir, max_workers=4):
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    # 收集待处理文件
    py_files = list(input_path.glob("*.py"))
    if not py_files:
        print("文件夹中没有发现 .py 文件。")
        return

    failed_log = []
    
    print(f"开始渲染任务，线程数: {max_workers}")
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        # 提交任务
        futures = {executor.submit(render_manim_file, f, output_path): f for f in py_files}
        
        # 进度条处理
        with tqdm(total=len(py_files), desc="渲染进度", unit="file") as pbar:
            for future in as_completed(futures):
                success, filename, error_msg = future.result()
                if not success:
                    failed_log.append((filename, error_msg))
                pbar.update(1)

    # 打印总结
    print("\n" + "="*30)
    print(f"任务完成！成功: {len(py_files) - len(failed_log)} | 失败: {len(failed_log)}")
    
    if failed_log:
        print("\n失败文件列表及原因:")
        for name, err in failed_log:
            print(f"- {name}: {str(err)[:100]}...") # 只显示前100字符
        
        # 写入日志文件
        with open(output_path / "render_errors.log", "w", encoding="utf-8") as log_f:
            for name, err in failed_log:
                log_f.write(f"File: {name}\nError: {err}\n" + "-"*20 + "\n")
        print(f"\n详细错误日志已保存至: {output_path / 'render_errors.log'}")

# --- 配置区域 ---
if __name__ == "__main__":
    SOURCE_DIR = "/home/TeachMasterAppV2/dataset/collect_manim_codes"  # 刚才清洗后的代码文件夹
    VIDEO_OUTPUT_DIR = "/home/TeachMasterAppV2/dataset/rendered_videos" # 视频存放文件夹
    
    batch_render(SOURCE_DIR, VIDEO_OUTPUT_DIR, max_workers=4)