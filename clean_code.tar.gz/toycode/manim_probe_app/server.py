#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import ast
import mimetypes
import subprocess
import sys
import time
import uuid
import importlib.util
import shutil
import tempfile
from pathlib import Path
from typing import Any

try:
    from fastapi import FastAPI, HTTPException, Response, Request
    from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
    from fastapi.staticfiles import StaticFiles
    from pydantic import BaseModel, Field
except Exception as exc:  # pragma: no cover
    raise SystemExit(
        "Missing dependencies. Install: fastapi uvicorn pydantic\n"
        f"Import error: {exc}"
    )


WORKSPACE_ROOT = Path(__file__).resolve().parents[2]
TOYCODE_DIR = WORKSPACE_ROOT / "toycode"
PROBE_SCRIPT = TOYCODE_DIR / "postion.py"
UI_DIR = Path(__file__).resolve().parent / "ui"

DRAG_LOG_DIR = Path(__file__).resolve().parent / "drag_logs"
DRAG_LOG_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_TIMEOUT_SEC = float(os.getenv("MANIM_PROBE_TIMEOUT_SEC", "60"))

VIDEO_EXT_ALLOWLIST = {".mp4", ".webm", ".ogv", ".mov", ".m4v"}


def _is_within_root(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def _resolve_user_path(path_str: str) -> Path:
    p = Path(path_str)
    if not p.is_absolute():
        p = (WORKSPACE_ROOT / p).resolve()
    else:
        p = p.resolve()
    if not _is_within_root(p, WORKSPACE_ROOT):
        raise HTTPException(status_code=400, detail="path must be within workspace")
    if not p.exists():
        raise HTTPException(status_code=400, detail="path does not exist")
    if not p.is_file():
        raise HTTPException(status_code=400, detail="path must be a file")
    return p


def _resolve_user_path_for_write(path_str: str) -> Path:
    p = Path(path_str)
    if not p.is_absolute():
        p = (WORKSPACE_ROOT / p).resolve()
    else:
        p = p.resolve()
    if not _is_within_root(p, WORKSPACE_ROOT):
        raise HTTPException(status_code=400, detail="path must be within workspace")
    if p.exists() and (not p.is_file()):
        raise HTTPException(status_code=400, detail="path must be a file")
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _session_log_path(session_id: str) -> Path:
    safe = "".join(ch for ch in session_id if ch.isalnum() or ch in {"-", "_"})
    if not safe:
        raise HTTPException(status_code=400, detail="invalid session_id")
    path = (DRAG_LOG_DIR / f"{safe}.json").resolve()
    if not _is_within_root(path, DRAG_LOG_DIR):
        raise HTTPException(status_code=400, detail="invalid session_id")
    return path


def _append_event_to_session_json(path: Path, event: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8") or "[]")
            if not isinstance(data, list):
                data = []
        except Exception:
            data = []
    else:
        data = []

    data.append(event)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _load_llm_client():
    llm_api_path = (WORKSPACE_ROOT / "toycode" / "llm_api.py").resolve()
    if not llm_api_path.exists():
        raise HTTPException(status_code=500, detail=f"llm_api.py not found: {llm_api_path}")
    spec = importlib.util.spec_from_file_location("toycode_llm_api", llm_api_path)
    if spec is None or spec.loader is None:
        raise HTTPException(status_code=500, detail="failed to load llm_api module spec")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore[attr-defined]
    client_cls = getattr(mod, "LLMAPIClient", None)
    if client_cls is None:
        raise HTTPException(status_code=500, detail="LLMAPIClient not found in llm_api.py")
    try:
        return client_cls()  # config.json resolution handled inside
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"failed to initialize LLM client: {exc}")


def _strip_code_fences(text: str) -> str:
    s = (text or "").strip()
    if "```" not in s:
        return s
    parts = s.split("```")
    if len(parts) < 3:
        return s.replace("```", "").strip()
    # take first fenced block content
    block = parts[1]
    lines = block.splitlines()
    if lines and lines[0].strip().lower() in {"python", "py"}:
        lines = lines[1:]
    return "\n".join(lines).strip()


def _find_latest_mp4(root: Path) -> Path | None:
    best: tuple[float, Path] | None = None
    for p in root.rglob("*.mp4"):
        try:
            mt = p.stat().st_mtime
        except Exception:
            continue
        if best is None or mt > best[0]:
            best = (mt, p)
    return best[1] if best else None


def _render_manim_video_to(src_file: Path, scene_name: str, dest_video_path: Path, timeout_sec: float = 1800) -> None:
    """
    Render manim video for (src_file, scene_name) and overwrite dest_video_path.
    Requires manim installed in the runtime environment.
    """
    with tempfile.TemporaryDirectory(prefix="manim_probe_render_", dir=str((Path(__file__).resolve().parent))) as tmp:
        tmp_dir = Path(tmp).resolve()
        cmd = [
            sys.executable,
            "-m",
            "manim",
            "-q",
            "l",
            "--format",
            "mp4",
            "--media_dir",
            str(tmp_dir),
            str(src_file),
            scene_name,
        ]
        proc = subprocess.run(
            cmd,
            cwd=str(WORKSPACE_ROOT),
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            check=False,
        )
        if proc.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail={
                    "message": "manim render failed",
                    "returncode": proc.returncode,
                    "stderr": (proc.stderr or "")[-4000:],
                    "stdout": (proc.stdout or "")[-4000:],
                },
            )

        mp4 = _find_latest_mp4(tmp_dir)
        if mp4 is None or (not mp4.exists()):
            raise HTTPException(status_code=500, detail="manim render produced no mp4")

        tmp_out = dest_video_path.with_suffix(dest_video_path.suffix + ".tmp")
        shutil.copyfile(mp4, tmp_out)
        os.replace(tmp_out, dest_video_path)


def _run_probe(file_path: Path, scene_name: str, timeout_sec: float) -> dict[str, Any]:
    if not PROBE_SCRIPT.exists():
        raise HTTPException(status_code=500, detail=f"probe script not found: {PROBE_SCRIPT}")

    cmd = [sys.executable, str(PROBE_SCRIPT), str(file_path), scene_name]
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(WORKSPACE_ROOT),
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            check=False,
        )
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=504, detail=f"probe timed out after {timeout_sec:.0f}s")

    stdout = (proc.stdout or "").strip()
    stderr = (proc.stderr or "").strip()

    if proc.returncode != 0:
        raise HTTPException(
            status_code=500,
            detail={
                "message": "probe process failed",
                "returncode": proc.returncode,
                "stderr": stderr[-4000:],
                "stdout": stdout[-4000:],
            },
        )

    try:
        return json.loads(stdout)
    except Exception:
        raise HTTPException(
            status_code=500,
            detail={
                "message": "probe returned non-JSON output",
                "stderr": stderr[-4000:],
                "stdout": stdout[-4000:],
            },
        )


class ProbeRequest(BaseModel):
    path: str = Field(min_length=1)


class DragEvent(BaseModel):
    session_id: str = Field(min_length=1)
    element_id: str = Field(min_length=1)
    element_name: str | None = None
    dx: float
    dy: float
    ts: str = Field(min_length=1)

class SaveRequest(BaseModel):
    path: str = Field(min_length=1)
    session_id: str = Field(min_length=1)
    video_path: str | None = None


app = FastAPI(title="Manim Probe Viewer (toycode)")
app.mount("/ui", StaticFiles(directory=UI_DIR, html=True), name="ui")


@app.get("/")
def root():
    return FileResponse(UI_DIR / "index.html")

@app.get("/favicon.ico")
def favicon():
    return Response(status_code=204)


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "python": sys.version.split()[0],
        "workspace_root": str(WORKSPACE_ROOT),
        "probe_script": str(PROBE_SCRIPT),
    }

def _infer_first_scene_class(file_path: Path) -> str:
    try:
        src = file_path.read_text(encoding="utf-8")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"failed to read file: {exc}")

    try:
        tree = ast.parse(src, filename=str(file_path))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"failed to parse python file: {exc}")

    def _base_name(base: ast.expr) -> str | None:
        if isinstance(base, ast.Name):
            return base.id
        if isinstance(base, ast.Attribute):
            return base.attr
        return None

    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        for base in node.bases:
            nm = _base_name(base)
            if not nm:
                continue
            if nm == "Scene" or nm.endswith("Scene"):
                return node.name

    raise HTTPException(
        status_code=400,
        detail="no Scene subclass found in file (expected: class YourScene(Scene): ...)",
    )

def _parse_range_header(range_header: str | None, size: int) -> tuple[int, int] | None:
    if not range_header:
        return None
    # Only support single range: bytes=start-end
    range_header = range_header.strip()
    if not range_header.startswith("bytes="):
        return None
    spec = range_header[len("bytes="):].split(",")[0].strip()
    if "-" not in spec:
        return None
    start_s, end_s = spec.split("-", 1)
    start_s = start_s.strip()
    end_s = end_s.strip()

    if start_s == "" and end_s == "":
        return None

    if start_s == "":
        # suffix bytes: last N bytes
        try:
            length = int(end_s)
        except Exception:
            return None
        if length <= 0:
            return None
        start = max(0, size - length)
        end = size - 1
        return (start, end)

    try:
        start = int(start_s)
    except Exception:
        return None
    if start < 0 or start >= size:
        return None

    if end_s == "":
        end = size - 1
    else:
        try:
            end = int(end_s)
        except Exception:
            return None
        end = min(end, size - 1)
        if end < start:
            return None

    return (start, end)


def _iter_file_range(path: Path, start: int, end: int, chunk_size: int = 1024 * 1024):
    with path.open("rb") as f:
        f.seek(start)
        remaining = end - start + 1
        while remaining > 0:
            chunk = f.read(min(chunk_size, remaining))
            if not chunk:
                break
            remaining -= len(chunk)
            yield chunk


@app.post("/api/probe")
def probe(req: ProbeRequest):
    file_path = _resolve_user_path(req.path)
    if file_path.suffix.lower() != ".py":
        raise HTTPException(status_code=400, detail="path must point to a .py file")

    started = time.time()
    scene_name = _infer_first_scene_class(file_path)
    result = _run_probe(file_path=file_path, scene_name=scene_name, timeout_sec=DEFAULT_TIMEOUT_SEC)
    result["_meta"] = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "elapsed_sec": round(time.time() - started, 3),
        "selected_scene": scene_name,
    }
    return JSONResponse(result)


@app.post("/api/drag-sessions")
def create_drag_session():
    session_id = uuid.uuid4().hex
    path = _session_log_path(session_id)
    if not path.exists():
        path.write_text("[]", encoding="utf-8")
    return {"session_id": session_id}

@app.post("/api/save")
def save_modified_code(req: SaveRequest):
    src_file = _resolve_user_path(req.path)
    if src_file.suffix.lower() != ".py":
        raise HTTPException(status_code=400, detail="path must point to a .py file")

    session_path = _session_log_path(req.session_id)
    if not session_path.exists():
        raise HTTPException(status_code=400, detail="drag session not found (refresh page to create a new session)")

    try:
        moves = json.loads(session_path.read_text(encoding="utf-8") or "[]")
        if not isinstance(moves, list):
            moves = []
    except Exception:
        moves = []

    try:
        original_code = src_file.read_text(encoding="utf-8")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"failed to read source file: {exc}")

    # Build a compact instruction for the LLM
    moves_compact: list[dict[str, Any]] = []
    for m in moves:
        if not isinstance(m, dict):
            continue
        moves_compact.append(
            {
                "ts": m.get("ts", ""),
                "element_name": m.get("element_name") or "",
                "element_id": m.get("element_id") or "",
                "dx": m.get("dx", 0),
                "dy": m.get("dy", 0),
            }
        )

    prompt = (
        "你是一个 Manim(Scene) 代码修改器。\n"
        "输入：原始 Manim Python 代码 + 用户在前端拖动元素的日志（dx/dy 为 Manim 坐标系单位：x 向右、y 向上）。\n"
        "任务：根据日志把对应元素在画面中的位置做相同位移。优先通过在该元素已有的 to_edge/shift/move_to/next_to 等之后追加 .shift(...) 来实现，尽量少改动其余逻辑。\n"
        "注意：\n"
        "- element_name 若为空，可参考 element_id，但 element_id 可能不稳定；尽量匹配源码中的变量名。\n"
        "- 保持代码可运行；不要输出解释；只输出完整的 Python 代码（不要 Markdown 代码块）。\n\n"
        "【拖动日志 JSON】\n"
        f"{json.dumps(moves_compact, ensure_ascii=False, indent=2)}\n\n"
        "【原始代码】\n"
        f"{original_code}\n"
    )

    client = _load_llm_client()
    try:
        llm_text = client.call_api_with_text(prompt)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"LLM call failed: {exc}")

    modified_code = _strip_code_fences(llm_text)
    if not modified_code.strip():
        raise HTTPException(status_code=500, detail="LLM returned empty code")

    # manim CLI expects a valid python script path (must end with .py)
    tmp_code_path = src_file.with_name(f"{src_file.stem}.tmp_{uuid.uuid4().hex}.py")
    tmp_code_path.write_text(modified_code, encoding="utf-8")

    try:
        # Probe (validate and regenerate latest bbox JSON) before overwriting source
        started = time.time()
        selected_scene = _infer_first_scene_class(tmp_code_path)
        probe_result = _run_probe(file_path=tmp_code_path, scene_name=selected_scene, timeout_sec=DEFAULT_TIMEOUT_SEC)

        # Render video (optional) before overwriting source
        video_path_out: str | None = None
        if req.video_path and req.video_path.strip():
            dest_video = _resolve_user_path_for_write(req.video_path)
            _render_manim_video_to(tmp_code_path, selected_scene, dest_video_path=dest_video)
            video_path_out = str(dest_video)

        # All good -> overwrite original source atomically
        os.replace(tmp_code_path, src_file)
    except Exception:
        try:
            tmp_code_path.unlink(missing_ok=True)
        except Exception:
            pass
        raise

    probe_result["_meta"] = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "elapsed_sec": round(time.time() - started, 3),
        "selected_scene": selected_scene,
    }
    try:
        probe_result["file"] = str(src_file.resolve())
    except Exception:
        pass
    return {
        "ok": True,
        "overwritten_path": str(src_file),
        "video_path": video_path_out,
        "probe": probe_result,
    }


@app.get("/api/video")
def get_video(path: str, request: Request):
    file_path = _resolve_user_path(path)
    if file_path.suffix.lower() not in VIDEO_EXT_ALLOWLIST:
        raise HTTPException(status_code=400, detail=f"unsupported video type: {file_path.suffix}")

    try:
        size = file_path.stat().st_size
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"failed to stat file: {exc}")

    media_type, _ = mimetypes.guess_type(str(file_path))
    media_type = media_type or "application/octet-stream"

    byte_range = _parse_range_header(request.headers.get("range"), size)
    if byte_range is None:
        return FileResponse(
            file_path,
            media_type=media_type,
            headers={"Accept-Ranges": "bytes"},
        )

    start, end = byte_range
    headers = {
        "Content-Range": f"bytes {start}-{end}/{size}",
        "Accept-Ranges": "bytes",
        "Content-Length": str(end - start + 1),
    }
    return StreamingResponse(
        _iter_file_range(file_path, start, end),
        status_code=206,
        media_type=media_type,
        headers=headers,
    )


@app.post("/api/drags")
def record_drag(ev: DragEvent):
    payload = ev.model_dump()
    path = _session_log_path(payload["session_id"])
    _append_event_to_session_json(path, payload)
    return {"ok": True}


@app.get("/api/drags")
def list_drags(session_id: str, limit: int = 200):
    if limit < 1 or limit > 2000:
        raise HTTPException(status_code=400, detail="limit must be 1..2000")
    path = _session_log_path(session_id)
    if not path.exists():
        return {"items": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8") or "[]")
        if not isinstance(data, list):
            return {"items": []}
    except Exception:
        return {"items": []}
    return {"items": data[-limit:]}


if __name__ == "__main__":  # pragma: no cover
    try:
        import uvicorn
    except Exception as exc:
        raise SystemExit(f"Missing uvicorn. Install uvicorn.\nImport error: {exc}")

    uvicorn.run(app, host="127.0.0.1", port=int(os.getenv("PORT", "8008")))
