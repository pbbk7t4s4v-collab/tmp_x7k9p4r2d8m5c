#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ultra-compact Manim geometry/provenance tracer WITH variable-name capture.
（增强版：只从子项动画反推 BulletedList 容器）
- 安全动画封装：当 FadeOut/FadeIn/Uncreate 等被传入空目标时，返回“无操作”占位，避免报错。
- 过滤输出：对名为 'bg' 的 ImageMobject，不在 JSON 写入 bbox 字段（aabb/left/right/top/bottom/width/height）。
- AST 重写升级：
  * 不只处理 construct() 顶层赋值，连 try/if/for 等块内的赋值也会注入 x.name="x"
  * 额外：为每个赋值注入 self._register_constructed(x)，以便检测阶段能枚举“构造出的对象”
- 父容器反推：候选仅限 BulletedList，避免把 VGroup/Group/Paragraph 当作容器写入

用法
  python probe_positions_ultra_compact_varnames.py your_file.py YourSceneClass > result.json
"""

import ast
import importlib.util
import io
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from manim import Scene, Mobject, DL, DR, UL, UR, config
from manim.animation.animation import Animation


# ====== 配置 ======
WHITELIST = {
    "BulletedList", "VGroup", "Group", "Paragraph", "Text", "Tex", "MathTex",
    "ImageMobject", "SVGMobject", "Rectangle", "Square", "Circle", "Line",
    "Arrow", "Dot", "Polygon", "Axes", "SurroundingRectangle",
}
ROUND_PLACES = 3
RECORD_ONLY_CHANGED = True
RECORD_STAGE_SNAPSHOTS_IN_EVENTS = False
PLAY_RECORD_BEFORE_AFTER = False
RECORD_PLAY_TARGETS = True
PLAY_TARGETS_TOPLEVEL_ONLY = False
IGNORE_NAMES: set[str] = set()  # 不再忽略 'bg'，而是保留条目但去掉其 bbox
IGNORE_FULLSCREEN_BACKGROUND = True
EPS = 1e-3

# 移除 BulletedList 的特殊容器处理，让它被当作普通对象检测
# 原来的问题：BulletedList 被当作容器，但反推逻辑失败导致整个对象被忽略
CONTAINER_CLASSES = {"BulletedList"}  # 暂时清空，不进行容器反推

# 反推父容器的阈值（命中>=2个子项或占比>=50%即认为是父容器）
PARENT_INTERSECTION_MIN = 1
PARENT_INTERSECTION_RATIO = 0.5


# =========================
# AST 重写：为 construct 里的赋值追加
#   x.name = "x"
#   self._register_constructed(x)
# =========================
class _ConstructVarNameRewriter(ast.NodeTransformer):
    """
    在 class 子类的 construct() 作用域内：
      对简单赋值 target=Name 的语句，追加：
        try: <name>.name = "<name>"
        except Exception: pass
        try: self._register_constructed(<name>)
        except Exception: pass
    """
    def __init__(self):
        super().__init__()
        self.in_class = False
        self.in_construct = False

    def visit_ClassDef(self, node: ast.ClassDef) -> Any:
        old_in_class = self.in_class
        self.in_class = True
        node = self.generic_visit(node)
        self.in_class = old_in_class
        return node

    def visit_FunctionDef(self, node: ast.FunctionDef) -> Any:
        old_in_construct = self.in_construct
        self.in_construct = self.in_class and (node.name == "construct")
        node = self.generic_visit(node)
        self.in_construct = old_in_construct
        return node

    def visit_Assign(self, node: ast.Assign) -> Any:
        node = self.generic_visit(node)
        if not self.in_construct:
            return node
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name_id = node.targets[0].id

            try_set_name = ast.Try(
                body=[
                    ast.Assign(
                        targets=[ast.Attribute(value=ast.Name(id=name_id, ctx=ast.Load()), attr="name", ctx=ast.Store())],
                        value=ast.Constant(value=name_id),
                        type_comment=None,
                    )
                ],
                handlers=[ast.ExceptHandler(type=ast.Name(id="Exception", ctx=ast.Load()), name=None, body=[ast.Pass()])],
                orelse=[],
                finalbody=[],
            )

            try_register = ast.Try(
                body=[
                    ast.Expr(
                        value=ast.Call(
                            func=ast.Attribute(value=ast.Name(id="self", ctx=ast.Load()), attr="_register_constructed", ctx=ast.Load()),
                            args=[ast.Name(id=name_id, ctx=ast.Load())],
                            keywords=[]
                        )
                    )
                ],
                handlers=[ast.ExceptHandler(type=ast.Name(id="Exception", ctx=ast.Load()), name=None, body=[ast.Pass()])],
                orelse=[],
                finalbody=[],
            )

            return [node, try_set_name, try_register]
        return node


def _rewrite_source_add_varnames(src: str) -> str:
    tree = ast.parse(src)
    tree = _ConstructVarNameRewriter().visit(tree)
    ast.fix_missing_locations(tree)
    if hasattr(ast, "unparse"):
        return ast.unparse(tree)  # type: ignore[attr-defined]
    raise RuntimeError("Your Python版本过低：需要 Python 3.9+ 才有 ast.unparse。")


# =========================
# “无目标动画”安全封装
# =========================
class _NoTarget:
    def build(self):
        return None


def _flatten_targets(*targets):
    flat = []
    for t in targets:
        if t is None:
            continue
        if isinstance(t, (list, tuple)):
            for x in t:
                if isinstance(x, Mobject):
                    flat.append(x)
        elif isinstance(t, Mobject):
            flat.append(t)
    return flat


def _make_safe_anim_ctor(original_ctor):
    def wrapper(*targets, **kwargs):
        flat = _flatten_targets(*targets)
        if not flat:
            return _NoTarget()
        return original_ctor(*flat, **kwargs)
    return wrapper


def _install_safe_animation_wrappers(mod):
    candidate_names = [
        "FadeOut", "FadeIn", "Uncreate", "ShrinkToCenter",
        "GrowFromCenter", "Circumscribe", "Create",
        "FadeTransform", "FadeTransformPieces",
    ]
    for name in candidate_names:
        orig = mod.__dict__.get(name, None)
        if orig is None:
            continue
        if callable(orig):
            mod.__dict__[name] = _make_safe_anim_ctor(orig)


# =========================
# 通用与运行器
# =========================
def _round(x: float) -> float:
    return round(float(x), ROUND_PLACES)


def get_aabb_fields(mob: Mobject) -> Dict[str, Any]:
    try:
        bb = mob.get_bounding_box()
        if bb is not None:
            ll, lr, ul = bb
            left, right = float(ll[0]), float(lr[0])
            bottom, top = float(ll[1]), float(ul[1])
            return {
                "aabb": [
                    [_round(left), _round(bottom), 0.0],
                    [_round(right), _round(bottom), 0.0],
                    [_round(left), _round(top), 0.0],
                ],
                "left": _round(left),
                "right": _round(right),
                "top": _round(top),
                "bottom": _round(bottom),
                "width": _round(right - left),
                "height": _round(top - bottom),
            }
    except Exception:
        pass
    try:
        ll = mob.get_corner(DL)
        lr = mob.get_corner(DR)
        ul = mob.get_corner(UL)
        left, right = float(ll[0]), float(lr[0])
        bottom, top = float(ll[1]), float(ul[1])
    except Exception:
        try:
            left = float(mob.get_left()[0])
            right = float(mob.get_right()[0])
            top = float(mob.get_top()[1])
            bottom = float(mob.get_bottom()[1])
        except Exception:
            left = right = top = bottom = 0.0
    return {
        "aabb": [
            [_round(left), _round(bottom), 0.0],
            [_round(right), _round(bottom), 0.0],
            [_round(left), _round(top), 0.0],
        ],
        "left": _round(left),
        "right": _round(right),
        "top": _round(top),
        "bottom": _round(bottom),
        "width": _round(right - left),
        "height": _round(top - bottom),
    }


def _strip_bbox_if_bg(entry: Dict[str, Any], mob: Mobject) -> Dict[str, Any]:
    try:
        is_bg_img = (mob.__class__.__name__ == "ImageMobject") and (getattr(mob, "name", "") == "bg")
    except Exception:
        is_bg_img = False

    if is_bg_img:
        for k in ("aabb", "left", "right", "top", "bottom", "width", "height"):
            entry.pop(k, None)
    return entry


def mob_key(m: Mobject) -> str:
    return f"{m.__class__.__name__}:{id(m)}"


def is_top_level(scene: Scene, m: Mobject) -> bool:
    try:
        return m in scene.mobjects
    except Exception:
        return False


def should_ignore(m: Mobject) -> bool:
    if getattr(m, "name", "") in IGNORE_NAMES:
        return True
    if IGNORE_FULLSCREEN_BACKGROUND:
        try:
            w = float(getattr(m, "width", None) or (m.get_right()[0] - m.get_left()[0]))
            h = float(getattr(m, "height", None) or (m.get_top()[1] - m.get_bottom()[1]))
            cx, cy, _ = m.get_center()
            if (
                abs(w - float(config.frame_width)) <= EPS
                and abs(h - float(config.frame_height)) <= EPS
                and abs(float(cx)) <= EPS
                and abs(float(cy)) <= EPS
                and m.__class__.__name__ in {"Rectangle", "ImageMobject"}
            ):
                return True
        except Exception:
            pass
    return False


def top_level_whitelisted(mobs: List[Mobject]) -> List[Mobject]:
    out = []
    for m in mobs:
        if WHITELIST and m.__class__.__name__ not in WHITELIST:
            continue
        if should_ignore(m):
            continue
        out.append(m)
    return out


def _flatten_anims(anims):
    flat = []
    stack = list(anims)[::-1]
    while stack:
        a = stack.pop()
        subs = None
        for name in ("animations", "subanimations", "anims"):
            subs = getattr(a, name, None)
            if subs:
                break
        if subs:
            stack.extend(reversed(list(subs)))
        else:
            flat.append(a)
    return flat


def _ensure_animation(obj):
    if isinstance(obj, Animation):
        return obj
    build = getattr(obj, "build", None)
    if callable(build):
        try:
            ani = build()
            if isinstance(ani, Animation):
                return ani
        except Exception:
            return None
    return None


def _collect_targets(anims):
    targets = []
    seen = set()
    for a in _flatten_anims(anims):
        ani = _ensure_animation(a)
        if ani is None and isinstance(a, Animation):
            ani = a
        if ani is None:
            continue
        for attr in ("mobject", "mobject_list", "vmobject", "mob"):
            v = getattr(ani, attr, None)
            if v is None:
                continue
            items = v if isinstance(v, (list, tuple)) else [v]
            for m in items:
                if not isinstance(m, Mobject):
                    continue
                if id(m) in seen:
                    continue
                if should_ignore(m):
                    continue
                
                # 为匿名的BulletedList子元素自动生成名称
                if not hasattr(m, 'name') or not getattr(m, 'name', '').strip():
                    try:
                        # 检查是否是BulletedList的子元素
                        if hasattr(m, 'submobjects') and len(m.submobjects) == 0:
                            # 这可能是一个文本元素，尝试从其内容生成名称
                            if hasattr(m, 'tex_string'):
                                tex_content = getattr(m, 'tex_string', '')
                                if 'low-dimensional' in tex_content:
                                    m.name = 'bullet_point_1'
                                elif 'Preserve' in tex_content or 'information' in tex_content:
                                    m.name = 'bullet_point_2'
                                else:
                                    m.name = f'bullet_point_{tex_content[:10].replace(" ", "_")}'
                            elif hasattr(m, 'text'):
                                text_content = getattr(m, 'text', '')
                                if 'low-dimensional' in text_content:
                                    m.name = 'bullet_point_1'
                                elif 'Preserve' in text_content or 'information' in text_content:
                                    m.name = 'bullet_point_2'
                                else:
                                    m.name = f'bullet_point_{text_content[:10].replace(" ", "_")}'
                    except Exception:
                        pass
                
                seen.add(id(m))
                targets.append(m)
    return targets


def _exec_to_end(scene: Scene, ani: Animation):
    try:
        if hasattr(ani, "_setup_scene"):
            ani._setup_scene(scene)
    except Exception:
        pass
    try:
        ani.begin()
    except Exception:
        pass
    try:
        ani.interpolate(1.0)
    except Exception:
        pass
    try:
        ani.finish()
    except Exception:
        pass
    try:
        if hasattr(ani, "clean_up_from_scene"):
            ani.clean_up_from_scene(scene)
    except Exception:
        pass


def _exec_list(scene: Scene, anims):
    compiled = []
    for obj in anims:
        ani = _ensure_animation(obj)
        if ani is None and isinstance(obj, Animation):
            ani = obj
        if ani is not None:
            compiled.append(ani)
    for ani in compiled:
        _exec_to_end(scene, ani)


# =========================
# 源码加载与执行（带重写 & 安全封装）
# =========================
def load_module_with_rewrite(path: str):
    src_path = Path(path)
    src = src_path.read_text(encoding="utf-8")
    rewritten = _rewrite_source_add_varnames(src)

    module_name = src_path.stem + "__rewritten"
    spec = importlib.util.spec_from_loader(module_name, loader=None)
    mod = importlib.util.module_from_spec(spec)

    mod.__file__ = str(src_path.resolve())
    mod.__package__ = None
    sys.modules[module_name] = mod

    code = compile(rewritten, filename=str(src_path), mode="exec")
    exec(code, mod.__dict__)

    _install_safe_animation_wrappers(mod)

    return mod


# =========================
# 主流程（增强：只反推 BulletedList 作为父容器）
# =========================
def run_scene_ultra_compact(file: str, scene_name: str) -> Dict[str, Any]:
    mod = load_module_with_rewrite(file)
    SceneCls = getattr(mod, scene_name)

    class UltraCompactScene(SceneCls):  # type: ignore[misc]
        def __init__(self, *a, **k):
            super().__init__(*a, **k)
            self._events: List[Dict[str, Any]] = []
            self._step = 0
            self._lifespan: Dict[str, Tuple[int, int]] = {}
            self._geom_registry: Dict[str, Dict[str, Any]] = {}
            self._constructed: List[Mobject] = []

        # === 被 AST 注入调用 ===
        def _register_constructed(self, m):
            try:
                if isinstance(m, Mobject):
                    self._constructed.append(m)
            except Exception:
                pass

        def _bump(self):
            self._step += 1
            return self._step

        def _touch_lifespan_by_stage(self, step: int):
            ids = [mob_key(m) for m in top_level_whitelisted(self.mobjects)]
            for _id in ids:
                if _id not in self._lifespan:
                    self._lifespan[_id] = (step, step)
                else:
                    s0, s1 = self._lifespan[_id]
                    if step > s1:
                        self._lifespan[_id] = (s0, step)

        def _update_registry_for(self, mobs: List[Mobject]):
            for m in mobs:
                if WHITELIST and m.__class__.__name__ not in WHITELIST:
                    continue
                if should_ignore(m):
                    continue
                _id = mob_key(m)
                try:
                    center = m.get_center().tolist()
                except Exception:
                    center = [0.0, 0.0, 0.0]
                center = [_round(center[0]), _round(center[1]), _round(center[2])]
                box = get_aabb_fields(m)

                entry: Dict[str, Any] = {
                    "id": _id,
                    "class": m.__class__.__name__,
                    "name": getattr(m, "name", ""),
                    "center": center,
                    **box,
                    "z_index": getattr(m, "z_index", 0),
                }

                entry = _strip_bbox_if_bg(entry, m)

                if RECORD_ONLY_CHANGED:
                    old = self._geom_registry.get(_id)
                    def _same(k: str) -> bool:
                        return (k not in entry and (old is None or k not in old)) or (old is not None and entry.get(k) == old.get(k))
                    keys_to_check = ("center", "left", "right", "top", "bottom", "width", "height", "z_index", "name")
                    if old and all(_same(k) for k in keys_to_check):
                        continue

                self._geom_registry[_id] = entry

        def _record_event(
            self,
            kind: str,
            targets: Optional[List[Mobject]] = None,
            extra_mobs: Optional[List[Mobject]] = None
        ):
            step = self._bump()
            stage = top_level_whitelisted(self.mobjects)
            all_interest = list(stage)

            if extra_mobs:
                for t in extra_mobs:
                    if isinstance(t, Mobject) and (t.__class__.__name__ in WHITELIST) and (not should_ignore(t)):
                        if t not in all_interest:
                            all_interest.append(t)

            if RECORD_PLAY_TARGETS and targets:
                if PLAY_TARGETS_TOPLEVEL_ONLY:
                    targets = [t for t in targets if is_top_level(self, t)]
                for t in targets:
                    if (t not in all_interest) and (t.__class__.__name__ in WHITELIST) and (not should_ignore(t)):
                        all_interest.append(t)

            self._update_registry_for(all_interest)
            ev = {"step": step, "event": kind}
            if RECORD_PLAY_TARGETS and targets:
                kept = []
                for t in targets:
                    if not isinstance(t, Mobject) or should_ignore(t):
                        continue
                    if PLAY_TARGETS_TOPLEVEL_ONLY and not is_top_level(self, t):
                        continue
                    kept.append(mob_key(t))
                if kept:
                    ev["targets"] = kept
            if RECORD_STAGE_SNAPSHOTS_IN_EVENTS:
                ev["stage_ids"] = [mob_key(m) for m in stage]
            self._events.append(ev)
            self._touch_lifespan_by_stage(step)

        # ==== 父容器反推（只考虑 BulletedList） ====
        def _candidate_containers(self) -> List[Mobject]:
            """候选容器：仅 BulletedList（来自构造登记 + 场景图遍历）。"""
            cands: List[Mobject] = []
            for m in self._constructed:
                if isinstance(m, Mobject) and (m.__class__.__name__ in CONTAINER_CLASSES):
                    cands.append(m)
            for root in self.mobjects:
                try:
                    fam = root.get_family()
                except Exception:
                    fam = [root]
                for node in fam:
                    if not isinstance(node, Mobject):
                        continue
                    if node.__class__.__name__ in CONTAINER_CLASSES:
                        cands.append(node)
            out, seen = [], set()
            for m in cands:
                if id(m) in seen:
                    continue
                seen.add(id(m))
                out.append(m)
            return out

        def _infer_containers_from_targets(self, targets: List[Mobject]) -> List[Mobject]:
            if not targets:
                return []
            targets_set = set(id(t) for t in targets if isinstance(t, Mobject))
            inferred: List[Mobject] = []

            candidates = self._candidate_containers()
            for c in candidates:
                try:
                    cfam = [m for m in c.get_family() if m is not c]
                except Exception:
                    cfam = list(c.submobjects) if hasattr(c, "submobjects") else []
                if not cfam:
                    continue
                cfam_ids = set(id(m) for m in cfam)
                hit = len(targets_set & cfam_ids)
                if hit >= PARENT_INTERSECTION_MIN or (hit / max(1, len(cfam)) >= PARENT_INTERSECTION_RATIO):
                    inferred.append(c)

            out, seen = [], set()
            for m in inferred:
                if id(m) in seen:
                    continue
                seen.add(id(m))
                if (m.__class__.__name__ in WHITELIST) and (not should_ignore(m)):
                    out.append(m)
            return out

        # 钩子
        def add(self, *mobjects):
            res = super().add(*mobjects)
            self._record_event("add")
            return res

        def remove(self, *mobjects):
            kept_targets = []
            for m in mobjects:
                if not isinstance(m, Mobject) or should_ignore(m):
                    continue
                if PLAY_TARGETS_TOPLEVEL_ONLY and not is_top_level(self, m):
                    continue
                kept_targets.append(m)
            self._record_event("remove", targets=kept_targets if kept_targets else None)
            return super().remove(*mobjects)

        def play(self, *anims, **kwargs):
            raw_targets = _collect_targets(anims)
            containers = self._infer_containers_from_targets(raw_targets)

            if PLAY_RECORD_BEFORE_AFTER:
                self._record_event("play_before",
                                   targets=raw_targets if RECORD_PLAY_TARGETS else None,
                                   extra_mobs=containers)
                _exec_list(self, anims)
                self._record_event("play_after",
                                   targets=raw_targets if RECORD_PLAY_TARGETS else None,
                                   extra_mobs=containers)
            else:
                self._record_event("play",
                                   targets=raw_targets if RECORD_PLAY_TARGETS else None,
                                   extra_mobs=containers)
                _exec_list(self, anims)
            return self

        def wait(self, time=0, **k):
            return self

        def render(self, *_, **__):
            self.setup()
            self.construct()
            self.tear_down()

    scn = UltraCompactScene()
    scn.render()

    lifespans = [
        {"id": _id, "class": _id.split(":")[0], "first_step": s0, "last_step": s1}
        for _id, (s0, s1) in sorted(scn._lifespan.items(), key=lambda kv: kv[1][0])
    ]
    
    # 确保所有在geometry registry中的对象都有生命周期记录
    # 为没有生命周期记录的对象创建默认记录
    for geom in scn._geom_registry.values():
        geom_id = geom.get("id")
        if geom_id and geom_id not in scn._lifespan:
            # 为缺失的对象创建一个覆盖整个动画的生命周期
            max_step = max((s1 for s0, s1 in scn._lifespan.values()), default=1)
            lifespans.append({
                "id": geom_id,
                "class": geom_id.split(":")[0],
                "first_step": 1,
                "last_step": max_step
            })
    
    elements_final_ids = [mob_key(m) for m in top_level_whitelisted(scn.mobjects)]

    return {
        "file": str(Path(file).resolve()),
        "scene": SceneCls.__name__,
        "frame": {
            "frame_width": float(config.frame_width),
            "frame_height": float(config.frame_height),
            "pixel_width": int(config.pixel_width),
            "pixel_height": int(config.pixel_height),
        },
        "events": scn._events,
        "geometries": list(scn._geom_registry.values()),
        "lifespans": lifespans,
        "elements_final_ids": elements_final_ids,
    }


def main():
    if len(sys.argv) < 3:
        print("用法: python probe_positions_ultra_compact_varnames.py <file.py> <SceneClass>")
        sys.exit(1)
    file, scene_name = sys.argv[1], sys.argv[2]

    buf = io.StringIO()
    real_stdout = sys.stdout
    sys.stdout = buf
    try:
        result = run_scene_ultra_compact(file, scene_name)
    finally:
        sys.stdout = real_stdout
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
